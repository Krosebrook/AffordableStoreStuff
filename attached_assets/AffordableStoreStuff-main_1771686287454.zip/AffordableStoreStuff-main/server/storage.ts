import {
  users,
  products,
  categories,
  cartItems,
  orders,
  orderItems,
  passwordResetTokens,
  publishingQueue,
  safeguardAuditLog,
  platformConnections,
  productConcepts,
  type User,
  type InsertUser,
  type Product,
  type InsertProduct,
  type Category,
  type InsertCategory,
  type CartItem,
  type InsertCartItem,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type CartItemWithProduct,
  type OrderWithItems,
  type PublishingQueueItem,
  type InsertPublishingQueueItem,
  type SafeguardAuditEntry,
  type PlatformConnection,
  type ProductConcept,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, lte } from "drizzle-orm";

// Password reset token types
interface PasswordResetToken {
  id: string;
  userId: string;
  token: string;
  expiresAt: Date;
  usedAt: Date | null;
  createdAt: Date;
}

interface InsertPasswordResetToken {
  userId: string;
  token: string;
  expiresAt: Date;
}

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Cart
  getCartItems(userId?: string, sessionId?: string): Promise<CartItemWithProduct[]>;
  getCartItem(id: string): Promise<CartItem | undefined>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: string): Promise<boolean>;
  clearCart(userId?: string, sessionId?: string): Promise<boolean>;

  // Orders
  getOrders(userId?: string): Promise<Order[]>;
  getOrder(id: string): Promise<OrderWithItems | undefined>;
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;

  // Password Reset Tokens
  createPasswordResetToken(data: InsertPasswordResetToken): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenUsed(token: string): Promise<void>;
  deletePasswordResetTokensForUser(userId: string): Promise<void>;
  updateUserPassword(userId: string, hashedPassword: string): Promise<void>;

  // Publishing Queue
  getPublishingQueue(status?: string): Promise<PublishingQueueItem[]>;
  getPendingPublishingItems(limit?: number): Promise<PublishingQueueItem[]>;
  createPublishingQueueItem(item: InsertPublishingQueueItem): Promise<PublishingQueueItem>;
  updatePublishingQueueItem(id: string, update: Partial<PublishingQueueItem>): Promise<PublishingQueueItem | undefined>;

  // Safeguards & Audits
  createSafeguardAudit(entry: typeof safeguardAuditLog.$inferInsert): Promise<SafeguardAuditEntry>;
  getSafeguardAuditLog(productId: string): Promise<SafeguardAuditEntry[]>;

  // Platform Connections
  getPlatformConnections(userId: string): Promise<PlatformConnection[]>;
  getPlatformConnection(userId: string, platform: string): Promise<PlatformConnection | undefined>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return db.select().from(products).orderBy(desc(products.featured));
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.slug, slug));
    return product || undefined;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db.update(products).set(product).where(eq(products.id, id)).returning();
    return updated || undefined;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return true;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories);
  }

  async getCategory(id: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category || undefined;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  // Cart
  async getCartItems(userId?: string, sessionId?: string): Promise<CartItemWithProduct[]> {
    const condition = userId
      ? eq(cartItems.userId, userId)
      : sessionId
        ? eq(cartItems.sessionId, sessionId)
        : undefined;

    if (!condition) return [];

    const results = await db
      .select({
        id: cartItems.id,
        userId: cartItems.userId,
        sessionId: cartItems.sessionId,
        productId: cartItems.productId,
        quantity: cartItems.quantity,
        product: products,
      })
      .from(cartItems)
      .leftJoin(products, eq(cartItems.productId, products.id))
      .where(condition);

    // Filter out rows where the product was not found (shouldn't happen with FK constraint)
    return results
      .filter(r => r.product !== null)
      .map(r => ({
        id: r.id,
        userId: r.userId,
        sessionId: r.sessionId,
        productId: r.productId,
        quantity: r.quantity,
        product: r.product!,
      }));
  }

  async getCartItem(id: string): Promise<CartItem | undefined> {
    const [item] = await db.select().from(cartItems).where(eq(cartItems.id, id));
    return item || undefined;
  }

  async addToCart(item: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    let existingItems: CartItem[] = [];
    if (item.userId) {
      existingItems = await db
        .select()
        .from(cartItems)
        .where(and(eq(cartItems.userId, item.userId), eq(cartItems.productId, item.productId)));
    } else if (item.sessionId) {
      existingItems = await db
        .select()
        .from(cartItems)
        .where(and(eq(cartItems.sessionId, item.sessionId), eq(cartItems.productId, item.productId)));
    }

    if (existingItems.length > 0) {
      const existing = existingItems[0];
      const [updated] = await db
        .update(cartItems)
        .set({ quantity: existing.quantity + (item.quantity || 1) })
        .where(eq(cartItems.id, existing.id))
        .returning();
      return updated;
    }

    const [newItem] = await db.insert(cartItems).values(item).returning();
    return newItem;
  }

  async updateCartItem(id: string, quantity: number): Promise<CartItem | undefined> {
    const [updated] = await db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    return updated || undefined;
  }

  async removeFromCart(id: string): Promise<boolean> {
    await db.delete(cartItems).where(eq(cartItems.id, id));
    return true;
  }

  async clearCart(userId?: string, sessionId?: string): Promise<boolean> {
    if (userId) {
      await db.delete(cartItems).where(eq(cartItems.userId, userId));
    } else if (sessionId) {
      await db.delete(cartItems).where(eq(cartItems.sessionId, sessionId));
    }
    return true;
  }

  // Orders
  async getOrders(userId?: string): Promise<Order[]> {
    if (userId) {
      return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
    }
    return db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrder(id: string): Promise<OrderWithItems | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;

    const items = await db
      .select({
        id: orderItems.id,
        orderId: orderItems.orderId,
        productId: orderItems.productId,
        productName: orderItems.productName,
        productImage: orderItems.productImage,
        price: orderItems.price,
        quantity: orderItems.quantity,
        product: products,
      })
      .from(orderItems)
      .leftJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, id));

    return {
      ...order,
      items: items.map((item) => ({
        ...item,
        product: item.product ?? undefined,
      })),
    };
  }

  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();

    for (const item of items) {
      await db.insert(orderItems).values({ ...item, orderId: newOrder.id });
    }

    return newOrder;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const [updated] = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
    return updated || undefined;
  }

  // Password Reset Tokens
  async createPasswordResetToken(data: InsertPasswordResetToken): Promise<PasswordResetToken> {
    const [token] = await db.insert(passwordResetTokens).values(data).returning();
    return token;
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const [resetToken] = await db.select().from(passwordResetTokens).where(eq(passwordResetTokens.token, token));
    return resetToken || undefined;
  }

  async markPasswordResetTokenUsed(token: string): Promise<void> {
    await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.token, token));
  }

  async deletePasswordResetTokensForUser(userId: string): Promise<void> {
    await db.delete(passwordResetTokens).where(eq(passwordResetTokens.userId, userId));
  }

  async updateUserPassword(userId: string, hashedPassword: string): Promise<void> {
    await db.update(users).set({ password: hashedPassword }).where(eq(users.id, userId));
  }

  // Publishing Queue
  async getPublishingQueue(status?: string): Promise<PublishingQueueItem[]> {
    if (status) {
      return db.select().from(publishingQueue).where(eq(publishingQueue.status, status)).orderBy(desc(publishingQueue.createdAt));
    }
    return db.select().from(publishingQueue).orderBy(desc(publishingQueue.createdAt));
  }

  async getPendingPublishingItems(limit: number = 10): Promise<PublishingQueueItem[]> {
    return db.select()
      .from(publishingQueue)
      .where(and(
        eq(publishingQueue.status, "pending"),
        lte(publishingQueue.scheduledFor, new Date())
      ))
      .orderBy(desc(publishingQueue.priority), asc(publishingQueue.createdAt))
      .limit(limit);
  }

  async createPublishingQueueItem(item: InsertPublishingQueueItem): Promise<PublishingQueueItem> {
    const [newItem] = await db.insert(publishingQueue).values(item).returning();
    return newItem;
  }

  async updatePublishingQueueItem(id: string, update: Partial<PublishingQueueItem>): Promise<PublishingQueueItem | undefined> {
    const [updated] = await db.update(publishingQueue).set(update).where(eq(publishingQueue.id, id)).returning();
    return updated || undefined;
  }

  // Safeguards & Audits
  async createSafeguardAudit(entry: typeof safeguardAuditLog.$inferInsert): Promise<SafeguardAuditEntry> {
    const [newEntry] = await db.insert(safeguardAuditLog).values(entry).returning();
    return newEntry;
  }

  async getSafeguardAuditLog(productId: string): Promise<SafeguardAuditEntry[]> {
    return db.select().from(safeguardAuditLog).where(eq(safeguardAuditLog.productId, productId)).orderBy(desc(safeguardAuditLog.assessedAt));
  }

  // Platform Connections
  async getPlatformConnections(userId: string): Promise<PlatformConnection[]> {
    return db.select().from(platformConnections).where(eq(platformConnections.userId, userId));
  }

  async getPlatformConnection(userId: string, platform: string): Promise<PlatformConnection | undefined> {
    const [connection] = await db.select().from(platformConnections)
      .where(and(eq(platformConnections.userId, userId), eq(platformConnections.platform, platform)));
    return connection || undefined;
  }
}

export const storage = new DatabaseStorage();
