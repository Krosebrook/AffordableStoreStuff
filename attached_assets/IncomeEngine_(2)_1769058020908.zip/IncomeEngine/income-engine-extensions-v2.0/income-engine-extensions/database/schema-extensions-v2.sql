-- ═══════════════════════════════════════════════════════════════
-- INCOME ENGINE EXTENSIONS - Database Schema v2.0
-- Run AFTER the base schema-extensions.sql
-- ═══════════════════════════════════════════════════════════════

-- ═══════════════════════════════════════════════════════════════
-- AMAZON KDP BOOKS TABLE
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS kdp_books (
    id TEXT PRIMARY KEY,
    
    -- Classification
    book_type TEXT NOT NULL, -- journal, planner, coloring-book, etc.
    niche TEXT NOT NULL,
    sub_niche TEXT,
    
    -- Content
    title TEXT NOT NULL,
    subtitle TEXT,
    description TEXT NOT NULL,
    keywords TEXT[] NOT NULL, -- Max 7
    categories TEXT[] NOT NULL, -- 2 BISAC codes
    
    -- Specifications
    trim_size TEXT NOT NULL DEFAULT '6x9',
    page_count INTEGER NOT NULL DEFAULT 120,
    paper_type TEXT NOT NULL DEFAULT 'white', -- white, cream
    cover_finish TEXT NOT NULL DEFAULT 'matte', -- matte, glossy
    interior_type TEXT NOT NULL, -- lined, blank, planner-weekly, coloring, etc.
    
    -- Cover specifications
    cover_width_inches DECIMAL(5,3),
    cover_height_inches DECIMAL(5,3),
    spine_width_inches DECIMAL(5,3),
    cover_image_url TEXT,
    interior_pdf_url TEXT,
    full_cover_pdf_url TEXT, -- Combined front + spine + back
    
    -- Pricing
    print_cost DECIMAL(6,2),
    min_price DECIMAL(6,2),
    recommended_price DECIMAL(6,2),
    actual_price DECIMAL(6,2),
    estimated_royalty DECIMAL(6,2),
    
    -- KDP specific
    asin TEXT, -- Amazon Standard Identification Number (after publishing)
    kdp_url TEXT, -- Link to KDP dashboard
    amazon_url TEXT, -- Public Amazon listing URL
    
    -- Status
    status TEXT NOT NULL DEFAULT 'draft', -- draft, generated, uploading, review, published, rejected
    rejection_reason TEXT,
    
    -- Tracking
    platform TEXT NOT NULL DEFAULT 'kdp',
    ai_cost DECIMAL(6,4),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    published_at TIMESTAMPTZ
);

-- Index for KDP queries
CREATE INDEX IF NOT EXISTS idx_kdp_books_status ON kdp_books(status);
CREATE INDEX IF NOT EXISTS idx_kdp_books_niche ON kdp_books(niche);
CREATE INDEX IF NOT EXISTS idx_kdp_books_book_type ON kdp_books(book_type);

-- ═══════════════════════════════════════════════════════════════
-- REDBUBBLE PRODUCTS TABLE
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS redbubble_products (
    id TEXT PRIMARY KEY,
    generated_product_id TEXT REFERENCES generated_products(id),
    
    -- Redbubble specific
    work_id TEXT, -- Redbubble work ID
    work_url TEXT, -- Public URL
    
    -- Content
    title TEXT NOT NULL,
    description TEXT,
    tags TEXT[] NOT NULL,
    
    -- Design
    image_url TEXT NOT NULL,
    
    -- Products enabled (Redbubble has many product types per work)
    enabled_products JSONB DEFAULT '{}', -- {"tshirt": true, "sticker": true, etc.}
    
    -- Pricing (Redbubble uses markup percentage)
    default_markup INTEGER DEFAULT 20, -- percentage
    product_markups JSONB DEFAULT '{}', -- {"tshirt": 25, "sticker": 15}
    
    -- Status
    status TEXT NOT NULL DEFAULT 'pending', -- pending, uploading, published, failed
    error_message TEXT,
    
    -- Tracking
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    published_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_redbubble_status ON redbubble_products(status);
CREATE INDEX IF NOT EXISTS idx_redbubble_work_id ON redbubble_products(work_id);

-- ═══════════════════════════════════════════════════════════════
-- TEEPUBLIC PRODUCTS TABLE
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS teepublic_products (
    id TEXT PRIMARY KEY,
    generated_product_id TEXT REFERENCES generated_products(id),
    
    -- TeePublic specific
    design_id TEXT,
    design_url TEXT,
    
    -- Content
    title TEXT NOT NULL,
    description TEXT,
    tags TEXT[] NOT NULL,
    
    -- Design
    image_url TEXT NOT NULL,
    
    -- Categories
    primary_category TEXT,
    secondary_category TEXT,
    
    -- Pricing (TeePublic sets base prices, artists get fixed royalty)
    royalty_per_sale DECIMAL(6,2) DEFAULT 4.00, -- TeePublic pays ~$4 per sale
    
    -- Status
    status TEXT NOT NULL DEFAULT 'pending',
    error_message TEXT,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    published_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_teepublic_status ON teepublic_products(status);

-- ═══════════════════════════════════════════════════════════════
-- SOCIETY6 PRODUCTS TABLE
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS society6_products (
    id TEXT PRIMARY KEY,
    generated_product_id TEXT REFERENCES generated_products(id),
    
    -- Society6 specific
    artwork_id TEXT,
    artwork_url TEXT,
    
    -- Content
    title TEXT NOT NULL,
    description TEXT,
    tags TEXT[] NOT NULL,
    
    -- Design
    image_url TEXT NOT NULL,
    
    -- Products (Society6 has art prints, home decor focus)
    enabled_products JSONB DEFAULT '{}',
    
    -- Pricing (Society6 uses markup on base price)
    markup_percentage INTEGER DEFAULT 10,
    
    -- Status
    status TEXT NOT NULL DEFAULT 'pending',
    error_message TEXT,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    published_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_society6_status ON society6_products(status);

-- ═══════════════════════════════════════════════════════════════
-- ZAZZLE PRODUCTS TABLE
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS zazzle_products (
    id TEXT PRIMARY KEY,
    generated_product_id TEXT REFERENCES generated_products(id),
    
    -- Zazzle specific
    product_id TEXT,
    product_url TEXT,
    store_id TEXT,
    
    -- Content
    title TEXT NOT NULL,
    description TEXT,
    tags TEXT[] NOT NULL,
    
    -- Design
    image_url TEXT NOT NULL,
    template_id TEXT, -- Zazzle template used
    
    -- Pricing
    royalty_percentage INTEGER DEFAULT 15,
    
    -- Status
    status TEXT NOT NULL DEFAULT 'pending',
    error_message TEXT,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    published_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_zazzle_status ON zazzle_products(status);

-- ═══════════════════════════════════════════════════════════════
-- EXTENDED NICHES TABLE
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS extended_niches (
    name TEXT PRIMARY KEY,
    category TEXT NOT NULL,
    
    -- Scoring
    demand_score INTEGER NOT NULL,
    competition_level TEXT NOT NULL, -- low, medium, high
    seasonal_boost DECIMAL(3,2) DEFAULT 1.0,
    final_score INTEGER,
    trend_direction TEXT DEFAULT 'stable', -- rising, stable, declining
    
    -- Products
    recommended_products TEXT[] NOT NULL,
    sub_niches TEXT[] NOT NULL,
    keywords TEXT[] NOT NULL,
    avoid_words TEXT[] DEFAULT '{}',
    
    -- Targeting
    target_demographic TEXT,
    price_point TEXT DEFAULT 'mid', -- budget, mid, premium
    best_platforms TEXT[] DEFAULT '{"etsy", "amazon"}',
    
    -- Seasonal peaks (months 1-12)
    seasonal_peaks INTEGER[] DEFAULT '{}',
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    last_scanned TIMESTAMPTZ,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_extended_niches_category ON extended_niches(category);
CREATE INDEX IF NOT EXISTS idx_extended_niches_score ON extended_niches(final_score DESC);
CREATE INDEX IF NOT EXISTS idx_extended_niches_active ON extended_niches(is_active) WHERE is_active = true;

-- ═══════════════════════════════════════════════════════════════
-- EXTENDED PRODUCT TYPES TABLE
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS extended_product_types (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL, -- pod, digital
    subcategory TEXT NOT NULL, -- apparel, home, accessories, etc.
    
    -- Design specs as JSONB
    design_specs JSONB NOT NULL,
    
    -- Pricing
    base_cost DECIMAL(6,2),
    recommended_price DECIMAL(6,2),
    premium_price DECIMAL(6,2),
    margin_percent INTEGER,
    
    -- Platform availability as JSONB
    platforms JSONB DEFAULT '{}',
    
    -- Marketing
    default_tags TEXT[],
    target_audience TEXT[],
    best_niches TEXT[],
    seasonal_peak INTEGER[], -- months
    
    -- Fulfillment
    avg_production_days INTEGER DEFAULT 3,
    shipping_weight TEXT,
    fragile BOOLEAN DEFAULT false,
    
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_product_types_category ON extended_product_types(category);
CREATE INDEX IF NOT EXISTS idx_product_types_active ON extended_product_types(is_active) WHERE is_active = true;

-- ═══════════════════════════════════════════════════════════════
-- MULTI-PLATFORM PUBLISH TRACKER
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS multi_platform_status (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    generated_product_id TEXT NOT NULL REFERENCES generated_products(id),
    
    -- Platform statuses
    printify_status TEXT DEFAULT 'pending',
    printify_id TEXT,
    printify_url TEXT,
    
    etsy_status TEXT DEFAULT 'pending',
    etsy_id TEXT,
    etsy_url TEXT,
    
    gumroad_status TEXT DEFAULT 'pending',
    gumroad_id TEXT,
    gumroad_url TEXT,
    
    redbubble_status TEXT DEFAULT 'pending',
    redbubble_id TEXT,
    redbubble_url TEXT,
    
    teepublic_status TEXT DEFAULT 'pending',
    teepublic_id TEXT,
    teepublic_url TEXT,
    
    society6_status TEXT DEFAULT 'pending',
    society6_id TEXT,
    society6_url TEXT,
    
    zazzle_status TEXT DEFAULT 'pending',
    zazzle_id TEXT,
    zazzle_url TEXT,
    
    amazon_status TEXT DEFAULT 'pending',
    amazon_id TEXT,
    amazon_url TEXT,
    
    -- Summary
    platforms_published INTEGER DEFAULT 0,
    platforms_failed INTEGER DEFAULT 0,
    total_platforms_target INTEGER DEFAULT 3,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_multi_platform_product ON multi_platform_status(generated_product_id);

-- ═══════════════════════════════════════════════════════════════
-- CROSS-PLATFORM REVENUE VIEW
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE VIEW v_cross_platform_revenue AS
SELECT 
    DATE_TRUNC('day', created_at) as date,
    platform,
    COUNT(*) as sales_count,
    SUM(gross_amount) as gross_revenue,
    SUM(platform_fees) as total_fees,
    SUM(net_amount) as net_revenue
FROM revenue_records
GROUP BY DATE_TRUNC('day', created_at), platform
ORDER BY date DESC, platform;

-- ═══════════════════════════════════════════════════════════════
-- NICHE PERFORMANCE VIEW
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE VIEW v_niche_performance AS
SELECT 
    gp.niche,
    COUNT(DISTINCT gp.id) as total_products,
    COUNT(DISTINCT CASE WHEN gp.status = 'published' THEN gp.id END) as published_products,
    COUNT(DISTINCT rr.id) as total_sales,
    COALESCE(SUM(rr.net_amount), 0) as total_revenue,
    COALESCE(AVG(rr.net_amount), 0) as avg_order_value,
    ROUND(
        COUNT(DISTINCT rr.id)::numeric / NULLIF(COUNT(DISTINCT CASE WHEN gp.status = 'published' THEN gp.id END), 0) * 100, 
        2
    ) as conversion_rate
FROM generated_products gp
LEFT JOIN revenue_records rr ON gp.id = rr.product_id
GROUP BY gp.niche
ORDER BY total_revenue DESC;

-- ═══════════════════════════════════════════════════════════════
-- PRODUCT TYPE PERFORMANCE VIEW
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE VIEW v_product_type_performance AS
SELECT 
    gp.product_type,
    COUNT(DISTINCT gp.id) as total_products,
    COUNT(DISTINCT rr.id) as total_sales,
    COALESCE(SUM(rr.gross_amount), 0) as gross_revenue,
    COALESCE(SUM(rr.net_amount), 0) as net_revenue,
    COALESCE(AVG(rr.net_amount), 0) as avg_order_value
FROM generated_products gp
LEFT JOIN revenue_records rr ON gp.id = rr.product_id
GROUP BY gp.product_type
ORDER BY net_revenue DESC;

-- ═══════════════════════════════════════════════════════════════
-- RLS POLICIES FOR NEW TABLES
-- ═══════════════════════════════════════════════════════════════

-- KDP Books
ALTER TABLE kdp_books ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_kdp_books" ON kdp_books FOR ALL TO service_role USING (true);

-- Redbubble
ALTER TABLE redbubble_products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_redbubble" ON redbubble_products FOR ALL TO service_role USING (true);

-- TeePublic
ALTER TABLE teepublic_products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_teepublic" ON teepublic_products FOR ALL TO service_role USING (true);

-- Society6
ALTER TABLE society6_products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_society6" ON society6_products FOR ALL TO service_role USING (true);

-- Zazzle
ALTER TABLE zazzle_products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_zazzle" ON zazzle_products FOR ALL TO service_role USING (true);

-- Extended Niches
ALTER TABLE extended_niches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_extended_niches" ON extended_niches FOR ALL TO service_role USING (true);

-- Extended Product Types
ALTER TABLE extended_product_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_extended_product_types" ON extended_product_types FOR ALL TO service_role USING (true);

-- Multi-Platform Status
ALTER TABLE multi_platform_status ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_role_multi_platform" ON multi_platform_status FOR ALL TO service_role USING (true);

-- ═══════════════════════════════════════════════════════════════
-- UPDATE TRIGGERS
-- ═══════════════════════════════════════════════════════════════

CREATE TRIGGER update_kdp_books_updated_at
    BEFORE UPDATE ON kdp_books
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_redbubble_products_updated_at
    BEFORE UPDATE ON redbubble_products
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_teepublic_products_updated_at
    BEFORE UPDATE ON teepublic_products
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_society6_products_updated_at
    BEFORE UPDATE ON society6_products
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_zazzle_products_updated_at
    BEFORE UPDATE ON zazzle_products
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_extended_niches_updated_at
    BEFORE UPDATE ON extended_niches
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_extended_product_types_updated_at
    BEFORE UPDATE ON extended_product_types
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_multi_platform_status_updated_at
    BEFORE UPDATE ON multi_platform_status
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ═══════════════════════════════════════════════════════════════
-- HELPER FUNCTIONS
-- ═══════════════════════════════════════════════════════════════

-- Get seasonal boost for current month
CREATE OR REPLACE FUNCTION get_seasonal_boost(niche_name TEXT)
RETURNS DECIMAL AS $$
DECLARE
    current_month INTEGER;
    boost DECIMAL;
BEGIN
    current_month := EXTRACT(MONTH FROM CURRENT_DATE);
    
    SELECT seasonal_boost INTO boost
    FROM extended_niches
    WHERE name = niche_name
    AND current_month = ANY(seasonal_peaks);
    
    RETURN COALESCE(boost, 1.0);
END;
$$ LANGUAGE plpgsql;

-- Get top performing niches
CREATE OR REPLACE FUNCTION get_top_niches(limit_count INTEGER DEFAULT 10)
RETURNS TABLE (
    niche TEXT,
    score INTEGER,
    revenue DECIMAL,
    products_count INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        en.name as niche,
        en.final_score as score,
        COALESCE(SUM(rr.net_amount), 0) as revenue,
        COUNT(DISTINCT gp.id)::INTEGER as products_count
    FROM extended_niches en
    LEFT JOIN generated_products gp ON gp.niche = en.name
    LEFT JOIN revenue_records rr ON rr.product_id = gp.id
    WHERE en.is_active = true
    GROUP BY en.name, en.final_score
    ORDER BY en.final_score DESC, revenue DESC
    LIMIT limit_count;
END;
$$ LANGUAGE plpgsql;

-- Calculate multi-platform coverage
CREATE OR REPLACE FUNCTION get_platform_coverage(product_id TEXT)
RETURNS TABLE (
    platform TEXT,
    status TEXT,
    url TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 'printify'::TEXT, mps.printify_status, mps.printify_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id
    UNION ALL
    SELECT 'etsy'::TEXT, mps.etsy_status, mps.etsy_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id
    UNION ALL
    SELECT 'gumroad'::TEXT, mps.gumroad_status, mps.gumroad_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id
    UNION ALL
    SELECT 'redbubble'::TEXT, mps.redbubble_status, mps.redbubble_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id
    UNION ALL
    SELECT 'teepublic'::TEXT, mps.teepublic_status, mps.teepublic_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id
    UNION ALL
    SELECT 'society6'::TEXT, mps.society6_status, mps.society6_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id
    UNION ALL
    SELECT 'zazzle'::TEXT, mps.zazzle_status, mps.zazzle_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id
    UNION ALL
    SELECT 'amazon'::TEXT, mps.amazon_status, mps.amazon_url FROM multi_platform_status mps WHERE mps.generated_product_id = product_id;
END;
$$ LANGUAGE plpgsql;

-- ═══════════════════════════════════════════════════════════════
-- SEED SAMPLE DATA FOR EXTENDED NICHES
-- ═══════════════════════════════════════════════════════════════

-- Insert a few sample niches (the full list is in TypeScript files)
INSERT INTO extended_niches (name, category, demand_score, competition_level, seasonal_boost, final_score, trend_direction, recommended_products, sub_niches, keywords, target_demographic, price_point, best_platforms)
VALUES 
    ('dog-breed-specific', 'pets', 92, 'medium', 1.0, 92, 'stable', 
     ARRAY['pod_mug', 'pod_tshirt', 'pod_tote', 'pod_blanket'],
     ARRAY['golden-retriever', 'labrador', 'german-shepherd', 'french-bulldog', 'husky', 'corgi', 'poodle', 'beagle'],
     ARRAY['dog mom', 'dog dad', 'fur baby', 'puppy love', 'paw prints'],
     'Dog owners 25-55', 'mid', ARRAY['etsy', 'amazon']),
     
    ('teacher-appreciation', 'occupation', 85, 'medium', 1.0, 85, 'stable',
     ARRAY['pod_tote', 'pod_mug', 'pod_tshirt', 'pod_tumbler'],
     ARRAY['elementary-teacher', 'math-teacher', 'science-teacher', 'art-teacher', 'special-ed-teacher'],
     ARRAY['teach', 'educator', 'classroom', 'inspire', 'future'],
     'Teachers and gift-givers 25-60', 'mid', ARRAY['etsy', 'amazon']),
     
    ('gaming-retro', 'hobby', 88, 'high', 1.0, 82, 'rising',
     ARRAY['pod_poster', 'pod_tshirt', 'pod_mousepad', 'pod_hoodie'],
     ARRAY['8-bit-pixel', 'arcade-classic', 'console-gaming', 'pc-master-race', 'retro-gaming'],
     ARRAY['level up', 'game on', 'player', 'respawn', 'achievement'],
     'Gamers 15-45', 'mid', ARRAY['etsy', 'redbubble', 'teepublic'])
ON CONFLICT (name) DO NOTHING;

COMMENT ON TABLE kdp_books IS 'Amazon KDP low-content books (journals, planners, coloring books)';
COMMENT ON TABLE redbubble_products IS 'Redbubble marketplace products';
COMMENT ON TABLE teepublic_products IS 'TeePublic marketplace products';
COMMENT ON TABLE society6_products IS 'Society6 marketplace products (art prints, home decor focus)';
COMMENT ON TABLE zazzle_products IS 'Zazzle marketplace products (customizable products)';
COMMENT ON TABLE extended_niches IS 'Extended niche database with 50+ niches';
COMMENT ON TABLE extended_product_types IS 'Extended product type specifications (40+ types)';
COMMENT ON TABLE multi_platform_status IS 'Track product publication status across all platforms';
