/**
 * Income Engine Extensions v2.0
 * Unified index for extended niches, products, and platforms
 */

// ═══════════════════════════════════════════════════════════════
// NICHES
// ═══════════════════════════════════════════════════════════════
import { EXTENDED_NICHES, ExtendedNiche, SEASONAL_CALENDAR } from './niches/extended-niches-part1';
import { EXTENDED_NICHES_PART2 } from './niches/extended-niches-part2';

// Merge all niches
export const ALL_NICHES: Record<string, ExtendedNiche> = {
  ...EXTENDED_NICHES,
  ...EXTENDED_NICHES_PART2,
};

// ═══════════════════════════════════════════════════════════════
// PRODUCTS
// ═══════════════════════════════════════════════════════════════
import { EXTENDED_PRODUCT_TYPES, ProductTypeSpec } from './products/extended-product-types';

export { EXTENDED_PRODUCT_TYPES, ProductTypeSpec };

// ═══════════════════════════════════════════════════════════════
// PLATFORMS
// ═══════════════════════════════════════════════════════════════
import { AmazonKDPConnector, KDPBook, KDPBookType } from './platforms/amazon-kdp';
import { RedbubbleConnector } from './platforms/redbubble';
import { TeePublicConnector, Society6Connector } from './platforms/teepublic-society6';

export { AmazonKDPConnector, KDPBook, KDPBookType };
export { RedbubbleConnector };
export { TeePublicConnector, Society6Connector };

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Get all niches by category
 */
export function getNichesByCategory(category: string): ExtendedNiche[] {
  return Object.values(ALL_NICHES).filter(n => n.category === category);
}

/**
 * Get top niches by score
 */
export function getTopNiches(count: number = 10): ExtendedNiche[] {
  return Object.values(ALL_NICHES)
    .sort((a, b) => b.demandScore - a.demandScore)
    .slice(0, count);
}

/**
 * Get niches with low competition
 */
export function getLowCompetitionNiches(): ExtendedNiche[] {
  return Object.values(ALL_NICHES).filter(n => n.competitionLevel === 'low');
}

/**
 * Get rising trend niches
 */
export function getRisingNiches(): ExtendedNiche[] {
  return Object.values(ALL_NICHES).filter(n => n.trendDirection === 'rising');
}

/**
 * Get seasonally boosted niches for current month
 */
export function getSeasonalNiches(): ExtendedNiche[] {
  const currentMonth = new Date().getMonth() + 1;
  const seasonalInfo = SEASONAL_CALENDAR[currentMonth];
  
  if (!seasonalInfo) return [];
  
  return Object.values(ALL_NICHES).filter(n => 
    seasonalInfo.niches.includes(n.name)
  );
}

/**
 * Get product types by category
 */
export function getProductTypesByCategory(category: 'pod' | 'digital'): ProductTypeSpec[] {
  return Object.values(EXTENDED_PRODUCT_TYPES).filter(p => p.category === category);
}

/**
 * Get product types for a specific platform
 */
export function getProductTypesForPlatform(platform: string): ProductTypeSpec[] {
  return Object.values(EXTENDED_PRODUCT_TYPES).filter(p => 
    p.platforms && platform in p.platforms
  );
}

/**
 * Get best products for a niche
 */
export function getBestProductsForNiche(nicheName: string): ProductTypeSpec[] {
  const niche = ALL_NICHES[nicheName];
  if (!niche) return [];
  
  return niche.recommendedProducts
    .map(id => EXTENDED_PRODUCT_TYPES[id])
    .filter(Boolean);
}

/**
 * Calculate seasonal boost for a niche
 */
export function calculateSeasonalBoost(nicheName: string): number {
  const currentMonth = new Date().getMonth() + 1;
  const niche = ALL_NICHES[nicheName];
  
  if (!niche) return 1.0;
  
  // Check if current month is in seasonal peaks
  const seasonalInfo = SEASONAL_CALENDAR[currentMonth];
  if (seasonalInfo?.niches.includes(nicheName)) {
    return niche.seasonalBoost || 1.5;
  }
  
  return 1.0;
}

/**
 * Get all sub-niches for a niche
 */
export function getSubNiches(nicheName: string): string[] {
  return ALL_NICHES[nicheName]?.subNiches || [];
}

/**
 * Get keywords for a niche
 */
export function getKeywords(nicheName: string): string[] {
  return ALL_NICHES[nicheName]?.keywords || [];
}

/**
 * Get words to avoid for a niche
 */
export function getAvoidWords(nicheName: string): string[] {
  return ALL_NICHES[nicheName]?.avoidWords || [];
}

// ═══════════════════════════════════════════════════════════════
// STATISTICS
// ═══════════════════════════════════════════════════════════════

export const EXTENSION_STATS = {
  totalNiches: Object.keys(ALL_NICHES).length,
  totalProductTypes: Object.keys(EXTENDED_PRODUCT_TYPES).length,
  totalSubNiches: Object.values(ALL_NICHES).reduce((sum, n) => sum + n.subNiches.length, 0),
  
  nichesByCategory: {
    pets: getNichesByCategory('pets').length,
    occupation: getNichesByCategory('occupation').length,
    hobby: getNichesByCategory('hobby').length,
    lifestyle: getNichesByCategory('lifestyle').length,
    parenting: getNichesByCategory('parenting').length,
    seasonal: getNichesByCategory('seasonal').length,
    sports: getNichesByCategory('sports').length,
    food: getNichesByCategory('food').length,
  },
  
  productsByCategory: {
    pod: getProductTypesByCategory('pod').length,
    digital: getProductTypesByCategory('digital').length,
  },
  
  platforms: [
    'printify',
    'etsy', 
    'gumroad',
    'amazon-kdp',
    'redbubble',
    'teepublic',
    'society6',
    'zazzle',
  ],
};

// ═══════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════

export { 
  ALL_NICHES,
  SEASONAL_CALENDAR,
  ExtendedNiche,
};

export default {
  niches: ALL_NICHES,
  products: EXTENDED_PRODUCT_TYPES,
  stats: EXTENSION_STATS,
  helpers: {
    getNichesByCategory,
    getTopNiches,
    getLowCompetitionNiches,
    getRisingNiches,
    getSeasonalNiches,
    getProductTypesByCategory,
    getProductTypesForPlatform,
    getBestProductsForNiche,
    calculateSeasonalBoost,
    getSubNiches,
    getKeywords,
    getAvoidWords,
  },
};
