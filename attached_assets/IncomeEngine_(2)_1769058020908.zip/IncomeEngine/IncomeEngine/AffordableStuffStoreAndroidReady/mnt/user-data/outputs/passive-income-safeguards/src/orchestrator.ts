/**
 * ============================================================================
 * SAFEGUARDS ORCHESTRATOR
 * ============================================================================
 * 
 * Central coordination layer for all 8 safeguards:
 * 1. Rate Limiter (Anti-Suspension)
 * 2. Quality Gates (AI Originality)
 * 3. Trademark Screener (TESS)
 * 4. API Queue (Backoff)
 * 5. Provider Failover
 * 6. Tax Compliance
 * 7. Human-in-the-Loop
 * 8. Budget Circuit Breaker
 * 
 * Usage: Import this orchestrator and call processProduct() for the full pipeline
 */

import { RateLimiter } from './safeguards/rate-limiter';
import { QualityGate } from './safeguards/quality-gate';
import { TrademarkScreener } from './safeguards/trademark-screener';
import { ApiQueue } from './safeguards/api-queue';
import { ProviderFailover, healthCheckers } from './safeguards/provider-failover';
import { TaxCompliance } from './safeguards/tax-compliance';
import { HumanInTheLoop } from './safeguards/human-in-the-loop';
import { BudgetCircuitBreaker } from './safeguards/budget-circuit-breaker';

// =============================================================================
// TYPES
// =============================================================================

interface SafeguardConfig {
  supabaseUrl: string;
  supabaseKey: string;
  openaiKey: string;
  slackWebhook?: string;
  taxProvider?: 'shopify_tax' | 'taxjar' | 'avalara' | 'manual';
  taxJarApiKey?: string;
  shopifyAccessToken?: string;
  shopifyStoreUrl?: string;
}

interface ProductInput {
  id: string;
  type: string;
  niche: string;
  title: string;
  description: string;
  keywords: string[];
  imageUrl: string;
  imageBase64?: string;
  targetPlatforms: string[];
  estimatedCost?: number;
}

interface ProcessingResult {
  productId: string;
  status: 'approved' | 'queued' | 'rejected' | 'blocked';
  stage: string;
  details: Record<string, any>;
  errors: string[];
  warnings: string[];
  nextSteps: string[];
}

// =============================================================================
// ORCHESTRATOR CLASS
// =============================================================================

export class SafeguardsOrchestrator {
  private rateLimiter: RateLimiter;
  private qualityGate: QualityGate;
  private trademarkScreener: TrademarkScreener;
  private apiQueue: ApiQueue;
  private providerFailover: ProviderFailover;
  private taxCompliance: TaxCompliance;
  private humanInTheLoop: HumanInTheLoop;
  private budgetBreaker: BudgetCircuitBreaker;
  private config: SafeguardConfig;

  constructor(config: SafeguardConfig) {
    this.config = config;
    
    // Initialize all safeguards
    this.rateLimiter = new RateLimiter(config.supabaseUrl, config.supabaseKey);
    this.qualityGate = new QualityGate(config.supabaseUrl, config.supabaseKey, config.openaiKey);
    this.trademarkScreener = new TrademarkScreener(config.supabaseUrl, config.supabaseKey);
    this.apiQueue = new ApiQueue(config.supabaseUrl, config.supabaseKey);
    this.providerFailover = new ProviderFailover(config.supabaseUrl, config.supabaseKey);
    this.taxCompliance = new TaxCompliance(config.supabaseUrl, config.supabaseKey, {
      provider: config.taxProvider || 'manual',
      taxJarApiKey: config.taxJarApiKey,
      shopifyAccessToken: config.shopifyAccessToken,
      shopifyStoreUrl: config.shopifyStoreUrl
    });
    this.humanInTheLoop = new HumanInTheLoop(config.supabaseUrl, config.supabaseKey);
    this.budgetBreaker = new BudgetCircuitBreaker(config.supabaseUrl, config.supabaseKey, {
      slackWebhook: config.slackWebhook
    });

    // Configure notifications
    if (config.slackWebhook) {
      this.humanInTheLoop.setNotificationConfig({ slackWebhook: config.slackWebhook });
    }
  }

  /**
   * Process a product through all safeguards
   */
  async processProduct(product: ProductInput): Promise<ProcessingResult> {
    const result: ProcessingResult = {
      productId: product.id,
      status: 'approved',
      stage: 'init',
      details: {},
      errors: [],
      warnings: [],
      nextSteps: []
    };

    try {
      // =======================================================================
      // STAGE 1: Budget Check (Circuit Breaker)
      // =======================================================================
      result.stage = 'budget_check';
      
      const budgetCheck = await this.budgetBreaker.canSpend(product.estimatedCost || 0.50);
      result.details.budget = budgetCheck.budgetStatus;
      
      if (!budgetCheck.allowed) {
        result.status = 'blocked';
        result.errors.push(`Budget blocked: ${budgetCheck.reason}`);
        result.nextSteps.push('Wait for budget reset or increase limits');
        return result;
      }

      // Check per-product cost limit
      const productCostCheck = await this.budgetBreaker.checkProductCostLimit(
        product.id, 
        product.estimatedCost || 0
      );
      
      if (!productCostCheck.allowed) {
        result.status = 'blocked';
        result.errors.push(productCostCheck.reason!);
        return result;
      }

      // =======================================================================
      // STAGE 2: Trademark Screening
      // =======================================================================
      result.stage = 'trademark_screening';
      
      const trademarkResult = await this.trademarkScreener.screenProduct({
        id: product.id,
        title: product.title,
        description: product.description,
        keywords: product.keywords,
        niche: product.niche
      });
      
      result.details.trademark = {
        overallRisk: trademarkResult.overallRisk,
        blockedTerms: trademarkResult.blockedTerms,
        cautionTerms: trademarkResult.cautionTerms
      };

      if (trademarkResult.overallRisk === 'blocked') {
        result.status = 'rejected';
        result.errors.push(`Trademark conflict: ${trademarkResult.blockedTerms.join(', ')}`);
        result.nextSteps.push(...trademarkResult.recommendedActions);
        return result;
      }

      if (trademarkResult.overallRisk === 'caution') {
        result.warnings.push(`Potential trademark issues: ${trademarkResult.cautionTerms.join(', ')}`);
      }

      // =======================================================================
      // STAGE 3: Quality Assessment
      // =======================================================================
      result.stage = 'quality_assessment';
      
      const qualityResult = await this.qualityGate.assessProduct({
        id: product.id,
        type: product.type,
        niche: product.niche,
        title: product.title,
        description: product.description,
        keywords: product.keywords,
        imageUrl: product.imageUrl,
        imageBase64: product.imageBase64
      });
      
      result.details.quality = {
        overallScore: qualityResult.qualityScore,
        styleConsistency: qualityResult.styleConsistencyScore,
        nicheRelevance: qualityResult.nicheRelevanceScore,
        originality: qualityResult.originalityScore,
        composition: qualityResult.compositionScore,
        passed: qualityResult.passed,
        issues: qualityResult.issuesDetected
      };

      // Record the cost of quality assessment (OpenAI Vision API)
      await this.budgetBreaker.recordApiCost('openai', 'gpt-4o', 1, product.id);

      if (!qualityResult.passed) {
        const criticalIssues = qualityResult.issuesDetected.filter(i => i.severity === 'critical');
        
        if (criticalIssues.length > 0) {
          result.status = 'rejected';
          result.errors.push(...criticalIssues.map(i => i.message));
          result.nextSteps.push('Fix critical quality issues and resubmit');
          return result;
        }

        // Non-critical issues become warnings
        result.warnings.push(...qualityResult.issuesDetected.map(i => i.message));
      }

      // =======================================================================
      // STAGE 4: Rate Limit Check (per-platform)
      // =======================================================================
      result.stage = 'rate_limit_check';
      result.details.rateLimits = {};

      for (const platform of product.targetPlatforms) {
        const rateCheck = await this.rateLimiter.checkUploadAllowed(platform, product.id);
        
        result.details.rateLimits[platform] = {
          allowed: rateCheck.allowed,
          reason: rateCheck.reason,
          currentHourCount: rateCheck.currentHourCount,
          currentDayCount: rateCheck.currentDayCount,
          requiresHumanReview: rateCheck.requiresHumanReview
        };

        if (!rateCheck.allowed) {
          result.warnings.push(`${platform}: ${rateCheck.reason}`);
        }
      }

      // =======================================================================
      // STAGE 5: Human-in-the-Loop Check
      // =======================================================================
      result.stage = 'human_review_check';
      
      const humanReviewRequired = await this.humanInTheLoop.isHumanReviewRequired();
      result.details.humanReview = { required: humanReviewRequired };

      // Submit to approval queue
      const approvalResult = await this.humanInTheLoop.submitForApproval({
        id: product.id,
        type: product.type,
        data: {
          title: product.title,
          description: product.description,
          keywords: product.keywords,
          niche: product.niche,
          imageUrl: product.imageUrl
        },
        previewUrls: [product.imageUrl],
        qualityScore: qualityResult.qualityScore,
        targetPlatforms: product.targetPlatforms,
        priority: qualityResult.qualityScore >= 0.85 ? 3 : 5 // Higher quality = higher priority
      });

      result.details.approval = approvalResult;

      if (approvalResult.autoApproved) {
        result.status = 'approved';
        result.nextSteps.push('Product auto-approved. Ready for publishing.');
      } else if (approvalResult.queued) {
        result.status = 'queued';
        result.nextSteps.push(`Awaiting human review (queue position: ${approvalResult.queuePosition})`);
        result.nextSteps.push(approvalResult.reason);
      }

      // =======================================================================
      // STAGE 6: Provider Health Check
      // =======================================================================
      result.stage = 'provider_check';
      
      // Check if POD provider is available
      const podProvider = await this.providerFailover.getProvider('pod_fulfillment');
      result.details.provider = {
        podProvider: podProvider?.providerName || 'none',
        available: !!podProvider
      };

      if (!podProvider) {
        result.warnings.push('No POD fulfillment provider available');
      }

      // =======================================================================
      // FINAL: Compile Next Steps
      // =======================================================================
      result.stage = 'complete';

      if (result.status === 'approved') {
        result.nextSteps.push('Queue for publishing to target platforms');
        
        // Check rate limits for scheduling
        for (const platform of product.targetPlatforms) {
          const delay = await this.rateLimiter.getDelayBeforeUpload(platform);
          if (delay > 0) {
            result.nextSteps.push(`${platform}: Wait ${Math.round(delay / 1000)}s before upload`);
          }
        }
      }

      return result;

    } catch (error) {
      result.status = 'blocked';
      result.errors.push(`Processing error at stage ${result.stage}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return result;
    }
  }

  /**
   * Queue a publishing request through the API queue
   */
  async queuePublish(
    productId: string,
    platform: string,
    publishData: Record<string, any>
  ): Promise<string> {
    // Get the API endpoint for the platform
    const endpoints: Record<string, string> = {
      printify: 'https://api.printify.com/v1/shops/{shopId}/products.json',
      shopify: 'https://{store}.myshopify.com/admin/api/2024-01/products.json',
      etsy: 'https://openapi.etsy.com/v3/application/shops/{shopId}/listings',
      gumroad: 'https://api.gumroad.com/v2/products'
    };

    const endpoint = endpoints[platform];
    if (!endpoint) {
      throw new Error(`Unknown platform: ${platform}`);
    }

    return this.apiQueue.enqueue({
      apiName: platform,
      endpoint,
      method: 'POST',
      payload: publishData,
      priority: 5,
      maxAttempts: 3
    });
  }

  /**
   * Get comprehensive system status
   */
  async getSystemStatus(): Promise<{
    budget: any;
    queues: any;
    providers: any;
    approvalStats: any;
    circuitBreakers: any;
  }> {
    const [budget, queueStats, providers, approvalStats] = await Promise.all([
      this.budgetBreaker.getAllBudgetStatus(),
      this.apiQueue.getStats(),
      this.providerFailover.getStatus(),
      this.humanInTheLoop.getStats()
    ]);

    // Get circuit breaker states
    const breakerNames = ['budget_daily', 'budget_weekly', 'budget_monthly', 'workflow_main'];
    const circuitBreakers: Record<string, any> = {};
    
    for (const name of breakerNames) {
      circuitBreakers[name] = await this.budgetBreaker.getCircuitBreakerState(name);
    }

    return {
      budget,
      queues: queueStats,
      providers,
      approvalStats,
      circuitBreakers
    };
  }

  /**
   * Start all background processes
   */
  startBackgroundProcesses(): void {
    // Start API queue processing
    this.apiQueue.startProcessing(1000);

    // Start provider health checks
    this.providerFailover.startHealthChecks(60000);

    console.log('✅ Background processes started');
  }

  /**
   * Stop all background processes
   */
  stopBackgroundProcesses(): void {
    this.apiQueue.stopProcessing();
    this.providerFailover.stopHealthChecks();
    
    console.log('⏹️ Background processes stopped');
  }

  /**
   * Cleanup resources
   */
  async cleanup(): Promise<void> {
    this.stopBackgroundProcesses();
    await this.trademarkScreener.cleanup();
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createSafeguardsOrchestrator(): SafeguardsOrchestrator {
  const config: SafeguardConfig = {
    supabaseUrl: process.env.SUPABASE_URL!,
    supabaseKey: process.env.SUPABASE_SERVICE_KEY!,
    openaiKey: process.env.OPENAI_API_KEY!,
    slackWebhook: process.env.SLACK_WEBHOOK_URL,
    taxProvider: (process.env.TAX_PROVIDER as any) || 'manual',
    taxJarApiKey: process.env.TAXJAR_API_KEY,
    shopifyAccessToken: process.env.SHOPIFY_ACCESS_TOKEN,
    shopifyStoreUrl: process.env.SHOPIFY_STORE_URL
  };

  // Validate required config
  if (!config.supabaseUrl) throw new Error('SUPABASE_URL required');
  if (!config.supabaseKey) throw new Error('SUPABASE_SERVICE_KEY required');
  if (!config.openaiKey) throw new Error('OPENAI_API_KEY required');

  return new SafeguardsOrchestrator(config);
}

export default SafeguardsOrchestrator;
