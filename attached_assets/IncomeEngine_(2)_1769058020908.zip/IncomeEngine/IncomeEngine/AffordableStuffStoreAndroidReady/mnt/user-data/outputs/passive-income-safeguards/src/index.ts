/**
 * ============================================================================
 * PASSIVE INCOME SAFEGUARDS - MAIN ENTRY POINT
 * ============================================================================
 * 
 * Production-ready safeguards for automated content generation and publishing.
 * 
 * 8 Safeguard Modules:
 * 1. RateLimiter - Anti-suspension controls with jitter
 * 2. QualityGate - AI content originality and style consistency  
 * 3. TrademarkScreener - TESS database lookup
 * 4. ApiQueue - Exponential backoff queue
 * 5. ProviderFailover - Backup provider configuration
 * 6. TaxCompliance - Multi-state sales tax and VAT
 * 7. HumanInTheLoop - Approval system for first 50+ products
 * 8. BudgetCircuitBreaker - Daily caps and cost tracking
 */

// =============================================================================
// SAFEGUARD MODULES
// =============================================================================

export { RateLimiter } from './safeguards/rate-limiter';
export { QualityGate } from './safeguards/quality-gate';
export { TrademarkScreener, quickTrademarkCheck } from './safeguards/trademark-screener';
export { ApiQueue } from './safeguards/api-queue';
export { ProviderFailover, healthCheckers } from './safeguards/provider-failover';
export { TaxCompliance } from './safeguards/tax-compliance';
export { HumanInTheLoop } from './safeguards/human-in-the-loop';
export { BudgetCircuitBreaker } from './safeguards/budget-circuit-breaker';

// =============================================================================
// ORCHESTRATOR
// =============================================================================

export { 
  SafeguardsOrchestrator, 
  createSafeguardsOrchestrator 
} from './orchestrator';

// =============================================================================
// QUICK START
// =============================================================================

import { createSafeguardsOrchestrator } from './orchestrator';

/**
 * Quick start example
 */
async function main() {
  // Load environment variables
  require('dotenv').config();

  console.log('🛡️ Passive Income Safeguards System');
  console.log('===================================\n');

  // Validate environment
  const required = ['SUPABASE_URL', 'SUPABASE_SERVICE_KEY', 'OPENAI_API_KEY'];
  const missing = required.filter(key => !process.env[key]);
  
  if (missing.length > 0) {
    console.error('❌ Missing required environment variables:');
    missing.forEach(key => console.error(`   - ${key}`));
    console.error('\n📝 Copy .env.example to .env and fill in your values');
    process.exit(1);
  }

  try {
    // Create orchestrator
    const orchestrator = createSafeguardsOrchestrator();
    console.log('✅ Orchestrator initialized\n');

    // Get system status
    const status = await orchestrator.getSystemStatus();
    
    console.log('📊 System Status:');
    console.log('─────────────────');
    
    // Budget status
    console.log('\n💰 Budget:');
    for (const budget of status.budget) {
      const icon = budget.isExceeded ? '🔴' : budget.isWarning ? '🟡' : '🟢';
      console.log(`   ${icon} ${budget.period}: $${budget.currentSpend}/$${budget.limit} (${budget.percentUsed}%)`);
    }

    // Queue status
    console.log('\n📬 API Queue:');
    console.log(`   Queued: ${status.queues.queued}`);
    console.log(`   Processing: ${status.queues.processing}`);
    console.log(`   Rate Limited: ${status.queues.rateLimited}`);
    console.log(`   Dead Letter: ${status.queues.deadLetter}`);

    // Approval status
    console.log('\n👤 Human Review:');
    console.log(`   Approved: ${status.approvalStats.totalApproved}`);
    console.log(`   Rejected: ${status.approvalStats.totalRejected}`);
    console.log(`   Pending: ${status.approvalStats.pendingCount}`);
    console.log(`   Approval Rate: ${(status.approvalStats.approvalRate * 100).toFixed(1)}%`);

    // Circuit breakers
    console.log('\n🔌 Circuit Breakers:');
    for (const [name, state] of Object.entries(status.circuitBreakers)) {
      const icon = (state as any).isOpen ? '🔴 OPEN' : '🟢 CLOSED';
      console.log(`   ${name}: ${icon}`);
    }

    console.log('\n✅ System ready for processing');
    console.log('\n📝 Example usage:');
    console.log(`
    const result = await orchestrator.processProduct({
      id: 'product-123',
      type: 'coloring_book',
      niche: 'adult_coloring',
      title: 'Mandala Patterns Coloring Book',
      description: 'Beautiful mandala designs...',
      keywords: ['mandala', 'coloring', 'relaxation'],
      imageUrl: 'https://...',
      targetPlatforms: ['printify', 'etsy']
    });
    `);

    // Cleanup
    await orchestrator.cleanup();

  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

// Run if executed directly
if (require.main === module) {
  main().catch(console.error);
}
