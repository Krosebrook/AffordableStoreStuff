# Passive Income Automation Safeguards System

Production-ready safeguards for automated content generation and multi-platform publishing.

## 8 Core Safeguards Implemented

| # | Safeguard | Module | Status |
|---|-----------|--------|--------|
| 1 | Anti-Suspension Controls | `rate-limiter/` | ✅ |
| 2 | AI Quality Gates | `quality-gates/` | ✅ |
| 3 | Trademark Screening | `trademark-screen/` | ✅ |
| 4 | API Queue with Backoff | `api-queue/` | ✅ |
| 5 | Provider Failover | `provider-failover/` | ✅ |
| 6 | Tax Compliance | `tax-compliance/` | ✅ |
| 7 | Human-in-the-Loop | `hitl-approval/` | ✅ |
| 8 | Budget Circuit Breakers | `budget-limiter/` | ✅ |

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SAFEGUARDS ORCHESTRATOR                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │   Budget     │───▶│   Quality    │───▶│  Trademark   │                   │
│  │  Gate ($)    │    │   Gates      │    │  Screening   │                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
│         │                   │                   │                            │
│         ▼                   ▼                   ▼                            │
│  ┌───────────────────────────────────────────────────────┐                  │
│  │              HUMAN-IN-THE-LOOP APPROVAL               │                  │
│  │         (Required for first 50 products)              │                  │
│  └───────────────────────────────────────────────────────┘                  │
│                            │                                                 │
│         ┌──────────────────┼──────────────────┐                             │
│         ▼                  ▼                  ▼                              │
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐                        │
│  │ Rate Limiter│   │  API Queue  │   │  Provider   │                        │
│  │ (per-plat)  │   │ w/ Backoff  │   │  Failover   │                        │
│  └─────────────┘   └─────────────┘   └─────────────┘                        │
│         │                  │                  │                              │
│         └──────────────────┼──────────────────┘                             │
│                            ▼                                                 │
│  ┌───────────────────────────────────────────────────────┐                  │
│  │                 TAX COMPLIANCE LAYER                   │                  │
│  │            (Shopify Tax / TaxJar / Avalara)           │                  │
│  └───────────────────────────────────────────────────────┘                  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your API keys

# 3. Initialize database
npx supabase db push

# 4. Run safeguards tests
npm run test:safeguards

# 5. Deploy to n8n (or import workflow)
npm run deploy:n8n
```

## Environment Variables

See `.env.example` for all required configuration.

## Database Schema

All safeguard state is stored in Supabase. See `database/schema.sql`.

## n8n Workflows

Import `n8n-workflows/` JSON files into your n8n instance.

## License

MIT
