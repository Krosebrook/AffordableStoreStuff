# Android build (Capacitor)

This repo is a **Vite + React PWA** with an Express API server. For an Android Play Store build, we wrap the built web UI using Capacitor.

## Prereqs
- Node.js 20+
- Java 17 (Android Studio bundled JDK works)
- Android Studio (SDK installed)
- Android SDK Platform: API 35 (Android 15) to comply with Google Play policy effective Aug 31, 2025.

## One-shot commands
```bash
npm ci
npm run pwa:generate-icons || true
npm run build

npx cap init "AffordableStuffStore" "com.affordablestuffstore.app" --web-dir=dist/client
npx cap add android
npx cap sync android
npx cap open android
```

## Build AAB from CLI
```bash
npm run android:bundle
# output: android/app/build/outputs/bundle/release/app-release.aab
```

## Notes
- Update `android/app/build.gradle` to set `targetSdkVersion 35`.
- Configure signing in Android Studio (Generate Signed Bundle / APK).
