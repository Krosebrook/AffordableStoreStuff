import React, { useState, useEffect } from 'react';
import { Routes, Route, NavLink, useLocation } from 'react-router-dom';

// =============================================================================
// TYPES
// =============================================================================

interface BudgetStatus {
  period: string;
  currentSpend: number;
  limit: number;
  percentUsed: number;
  isWarning: boolean;
  isExceeded: boolean;
  remainingBudget: number;
}

interface SystemStatus {
  budget: BudgetStatus[];
  queues: {
    queued: number;
    processing: number;
    rateLimited: number;
    deadLetter: number;
    completedToday: number;
  };
  approvalStats: {
    totalApproved: number;
    totalRejected: number;
    approvalRate: number;
    pendingCount: number;
  };
  circuitBreakers: Record<string, { isOpen: boolean; openedReason?: string }>;
}

// =============================================================================
// API HOOKS
// =============================================================================

const useSystemStatus = () => {
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/status');
      if (!res.ok) throw new Error('Failed to fetch status');
      const data = await res.json();
      setStatus(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  return { status, loading, error, refresh: fetchStatus };
};

// =============================================================================
// COMPONENTS
// =============================================================================

// Status Badge
const StatusBadge: React.FC<{ status: 'ok' | 'warning' | 'error' }> = ({ status }) => {
  const colors = {
    ok: 'bg-green-500',
    warning: 'bg-yellow-500',
    error: 'bg-red-500'
  };
  
  return (
    <span className={`inline-block w-3 h-3 rounded-full ${colors[status]} animate-pulse`} />
  );
};

// Progress Ring
const ProgressRing: React.FC<{ percent: number; size?: number; warning?: boolean }> = ({ 
  percent, 
  size = 80,
  warning = false 
}) => {
  const strokeWidth = 8;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percent / 100) * circumference;
  
  const color = percent >= 100 ? '#ef4444' : percent >= 80 ? '#eab308' : '#22c55e';
  
  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="rgba(255,255,255,0.1)"
        strokeWidth={strokeWidth}
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
        className="transition-all duration-500"
      />
    </svg>
  );
};

// Dashboard Page
const DashboardPage: React.FC = () => {
  const { status, loading, error, refresh } = useSystemStatus();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="loading-spinner" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4">
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <h3 className="font-semibold text-red-400">Connection Error</h3>
          <p className="text-sm text-gray-400 mt-1">{error}</p>
          <button 
            onClick={refresh}
            className="mt-3 px-4 py-2 bg-red-500 rounded-lg text-sm font-medium"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!status) return null;

  // Check for any open circuit breakers
  const openBreakers = Object.entries(status.circuitBreakers)
    .filter(([_, state]) => state.isOpen);

  return (
    <div className="p-4 space-y-4">
      {/* Alert Banner */}
      {openBreakers.length > 0 && (
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">🚨</span>
            <span className="font-semibold">Circuit Breaker Active</span>
          </div>
          <p className="text-sm text-gray-300 mt-1">
            {openBreakers[0][1].openedReason || 'Budget limit exceeded'}
          </p>
        </div>
      )}

      {/* Budget Cards */}
      <div className="grid grid-cols-3 gap-3">
        {status.budget.map((b) => (
          <div key={b.period} className="bg-slate-800/50 rounded-xl p-3 text-center">
            <div className="flex justify-center mb-2">
              <div className="relative">
                <ProgressRing percent={b.percentUsed} size={60} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-bold">{b.percentUsed}%</span>
                </div>
              </div>
            </div>
            <p className="text-xs text-gray-400 capitalize">{b.period}</p>
            <p className="text-sm font-semibold">${b.currentSpend.toFixed(2)}</p>
          </div>
        ))}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl">📋</span>
            <StatusBadge status={status.approvalStats.pendingCount > 10 ? 'warning' : 'ok'} />
          </div>
          <p className="text-2xl font-bold mt-2">{status.approvalStats.pendingCount}</p>
          <p className="text-sm text-gray-400">Pending Approvals</p>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl">📊</span>
            <StatusBadge status={status.queues.deadLetter > 0 ? 'error' : 'ok'} />
          </div>
          <p className="text-2xl font-bold mt-2">{status.queues.queued}</p>
          <p className="text-sm text-gray-400">Queued Tasks</p>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl">✅</span>
          </div>
          <p className="text-2xl font-bold mt-2">{status.approvalStats.totalApproved}</p>
          <p className="text-sm text-gray-400">Total Approved</p>
        </div>
        
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl">📈</span>
          </div>
          <p className="text-2xl font-bold mt-2">
            {(status.approvalStats.approvalRate * 100).toFixed(0)}%
          </p>
          <p className="text-sm text-gray-400">Approval Rate</p>
        </div>
      </div>

      {/* Queue Status */}
      <div className="bg-slate-800/50 rounded-xl p-4">
        <h3 className="font-semibold mb-3">API Queue Status</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Queued</span>
            <span className="font-medium">{status.queues.queued}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Processing</span>
            <span className="font-medium text-blue-400">{status.queues.processing}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Rate Limited</span>
            <span className="font-medium text-yellow-400">{status.queues.rateLimited}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Dead Letter</span>
            <span className={`font-medium ${status.queues.deadLetter > 0 ? 'text-red-400' : ''}`}>
              {status.queues.deadLetter}
            </span>
          </div>
        </div>
      </div>

      {/* Refresh Button */}
      <button 
        onClick={refresh}
        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 rounded-xl font-medium transition-colors"
      >
        Refresh Status
      </button>
    </div>
  );
};

// Approvals Page
const ApprovalsPage: React.FC = () => {
  const [approvals, setApprovals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch pending approvals
    fetch('/api/approvals')
      .then(res => res.json())
      .then(data => {
        setApprovals(data.pending || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Pending Approvals</h2>
      
      {loading ? (
        <div className="flex justify-center py-8">
          <div className="loading-spinner" />
        </div>
      ) : approvals.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          <span className="text-4xl mb-4 block">✨</span>
          <p>No pending approvals</p>
          <p className="text-sm mt-1">All products have been reviewed</p>
        </div>
      ) : (
        <div className="space-y-3">
          {approvals.map((item, idx) => (
            <div key={idx} className="bg-slate-800/50 rounded-xl p-4">
              <div className="flex gap-3">
                <div className="w-16 h-16 bg-slate-700 rounded-lg flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium truncate">{item.title || 'Product'}</h3>
                  <p className="text-sm text-gray-400">{item.type}</p>
                  <div className="flex gap-2 mt-2">
                    <button className="px-3 py-1 bg-green-600 rounded text-sm">
                      Approve
                    </button>
                    <button className="px-3 py-1 bg-red-600 rounded text-sm">
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// Budget Page
const BudgetPage: React.FC = () => {
  const { status, loading } = useSystemStatus();

  if (loading || !status) {
    return (
      <div className="flex justify-center py-12">
        <div className="loading-spinner" />
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold">Budget Overview</h2>
      
      {status.budget.map((b) => (
        <div key={b.period} className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex justify-between items-center mb-3">
            <span className="font-medium capitalize">{b.period} Budget</span>
            <span className={`text-sm px-2 py-0.5 rounded ${
              b.isExceeded ? 'bg-red-500/20 text-red-400' :
              b.isWarning ? 'bg-yellow-500/20 text-yellow-400' :
              'bg-green-500/20 text-green-400'
            }`}>
              {b.isExceeded ? 'Exceeded' : b.isWarning ? 'Warning' : 'OK'}
            </span>
          </div>
          
          <div className="flex justify-between text-2xl font-bold mb-2">
            <span>${b.currentSpend.toFixed(2)}</span>
            <span className="text-gray-500">/ ${b.limit.toFixed(2)}</span>
          </div>
          
          <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all ${
                b.percentUsed >= 100 ? 'bg-red-500' :
                b.percentUsed >= 80 ? 'bg-yellow-500' : 'bg-green-500'
              }`}
              style={{ width: `${Math.min(b.percentUsed, 100)}%` }}
            />
          </div>
          
          <p className="text-sm text-gray-400 mt-2">
            ${b.remainingBudget.toFixed(2)} remaining
          </p>
        </div>
      ))}
    </div>
  );
};

// Settings Page
const SettingsPage: React.FC = () => {
  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold">Settings</h2>
      
      <div className="bg-slate-800/50 rounded-xl divide-y divide-slate-700">
        <div className="p-4 flex justify-between items-center">
          <div>
            <p className="font-medium">Push Notifications</p>
            <p className="text-sm text-gray-400">Get alerts on your phone</p>
          </div>
          <button className="w-12 h-6 bg-indigo-600 rounded-full relative">
            <span className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
          </button>
        </div>
        
        <div className="p-4 flex justify-between items-center">
          <div>
            <p className="font-medium">Auto-Approve</p>
            <p className="text-sm text-gray-400">After 50 approved products</p>
          </div>
          <button className="w-12 h-6 bg-slate-600 rounded-full relative">
            <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full" />
          </button>
        </div>
        
        <div className="p-4">
          <p className="font-medium">Daily Budget Limit</p>
          <input 
            type="number" 
            defaultValue={25}
            className="mt-2 w-full bg-slate-700 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>
      
      <div className="bg-slate-800/50 rounded-xl p-4">
        <p className="text-sm text-gray-400">App Version</p>
        <p className="font-medium">1.0.0</p>
      </div>
    </div>
  );
};

// =============================================================================
// MAIN APP
// =============================================================================

const App: React.FC = () => {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col">
      {/* Header */}
      <header className="bg-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <span className="text-xl">🛡️</span>
          <h1 className="font-bold">Safeguards</h1>
        </div>
        <StatusBadge status="ok" />
      </header>

      {/* Main Content */}
      <main className="flex-1 pb-20">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/approvals" element={<ApprovalsPage />} />
          <Route path="/budget" element={<BudgetPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Routes>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 px-4 py-2 safe-area-pb">
        <div className="flex justify-around items-center">
          <NavLink 
            to="/" 
            className={({ isActive }) => 
              `flex flex-col items-center py-2 px-4 rounded-lg transition-colors ${
                isActive ? 'text-indigo-400' : 'text-gray-400'
              }`
            }
          >
            <span className="text-xl mb-1">📊</span>
            <span className="text-xs">Dashboard</span>
          </NavLink>
          
          <NavLink 
            to="/approvals"
            className={({ isActive }) => 
              `flex flex-col items-center py-2 px-4 rounded-lg transition-colors ${
                isActive ? 'text-indigo-400' : 'text-gray-400'
              }`
            }
          >
            <span className="text-xl mb-1">📋</span>
            <span className="text-xs">Approvals</span>
          </NavLink>
          
          <NavLink 
            to="/budget"
            className={({ isActive }) => 
              `flex flex-col items-center py-2 px-4 rounded-lg transition-colors ${
                isActive ? 'text-indigo-400' : 'text-gray-400'
              }`
            }
          >
            <span className="text-xl mb-1">💰</span>
            <span className="text-xs">Budget</span>
          </NavLink>
          
          <NavLink 
            to="/settings"
            className={({ isActive }) => 
              `flex flex-col items-center py-2 px-4 rounded-lg transition-colors ${
                isActive ? 'text-indigo-400' : 'text-gray-400'
              }`
            }
          >
            <span className="text-xl mb-1">⚙️</span>
            <span className="text-xs">Settings</span>
          </NavLink>
        </div>
      </nav>
    </div>
  );
};

export default App;
