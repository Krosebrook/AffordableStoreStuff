/**
 * ============================================================================
 * SAFEGUARD #5: PROVIDER FAILOVER
 * ============================================================================
 * 
 * Purpose: Automatically switch to backup providers when primary fails
 * 
 * Features:
 * - Health checking with configurable intervals
 * - Automatic failover to backup providers
 * - Priority-based provider selection
 * - Capability matching (ensure backup supports required features)
 * - Recovery detection and failback
 * - Failover event logging
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// =============================================================================
// TYPES
// =============================================================================

type ProviderType = 'pod_fulfillment' | 'ai_generation' | 'storage' | 'payment';

interface Provider {
  id: string;
  providerType: ProviderType;
  providerName: string;
  isPrimary: boolean;
  isAvailable: boolean;
  healthScore: number;
  lastCheckAt: Date;
  lastFailureAt?: Date;
  failureCount24h: number;
  avgResponseTimeMs?: number;
  capabilities: Record<string, any>;
  priorityOrder: number;
}

interface FailoverEvent {
  id: string;
  providerType: ProviderType;
  fromProvider: string;
  toProvider: string;
  reason: string;
  triggeredAt: Date;
  resolvedAt?: Date;
  autoResolved: boolean;
}

interface HealthCheckResult {
  healthy: boolean;
  responseTimeMs: number;
  error?: string;
}

// =============================================================================
// PROVIDER FAILOVER CLASS
// =============================================================================

export class ProviderFailover {
  private supabase: SupabaseClient;
  private healthCheckInterval: NodeJS.Timer | null = null;
  private healthCheckers: Map<string, () => Promise<HealthCheckResult>> = new Map();

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * Get the best available provider for a type
   */
  async getProvider(
    providerType: ProviderType, 
    requiredCapabilities?: string[]
  ): Promise<Provider | null> {
    // Get all providers of this type, ordered by priority
    const { data: providers, error } = await this.supabase
      .from('provider_health')
      .select('*')
      .eq('provider_type', providerType)
      .eq('is_available', true)
      .order('is_primary', { ascending: false })
      .order('priority_order', { ascending: true })
      .order('health_score', { ascending: false });

    if (error || !providers || providers.length === 0) {
      console.error(`No available providers for type: ${providerType}`);
      return null;
    }

    // Filter by required capabilities if specified
    let eligibleProviders = providers;
    if (requiredCapabilities && requiredCapabilities.length > 0) {
      eligibleProviders = providers.filter(p => {
        const caps = p.capabilities || {};
        return requiredCapabilities.every(req => {
          // Check if capability exists in any form
          return Object.values(caps).some(v => 
            Array.isArray(v) ? v.includes(req) : v === req
          );
        });
      });
    }

    if (eligibleProviders.length === 0) {
      console.error(`No providers with required capabilities: ${requiredCapabilities}`);
      return null;
    }

    // Return the best available provider
    return eligibleProviders[0];
  }

  /**
   * Report a provider failure
   */
  async reportFailure(
    providerType: ProviderType, 
    providerName: string, 
    error: string
  ): Promise<Provider | null> {
    // Update failure stats
    await this.supabase
      .from('provider_health')
      .update({
        failure_count_24h: this.supabase.rpc('increment', { x: 1 }),
        last_failure_at: new Date().toISOString(),
        health_score: this.supabase.rpc('decrease_health', { amount: 0.1 })
      })
      .eq('provider_type', providerType)
      .eq('provider_name', providerName);

    // Check if we need to mark as unavailable
    const { data: provider } = await this.supabase
      .from('provider_health')
      .select('*')
      .eq('provider_type', providerType)
      .eq('provider_name', providerName)
      .single();

    if (provider && (provider.health_score < 0.3 || provider.failure_count_24h > 10)) {
      await this.markUnavailable(providerType, providerName);
    }

    // Get next best provider
    const nextProvider = await this.getProvider(providerType);
    
    if (nextProvider && nextProvider.providerName !== providerName) {
      // Log failover event
      await this.logFailover(providerType, providerName, nextProvider.providerName, error);
    }

    return nextProvider;
  }

  /**
   * Report a successful request
   */
  async reportSuccess(
    providerType: ProviderType, 
    providerName: string, 
    responseTimeMs: number
  ): Promise<void> {
    // Get current stats
    const { data: provider } = await this.supabase
      .from('provider_health')
      .select('avg_response_time_ms, health_score')
      .eq('provider_type', providerType)
      .eq('provider_name', providerName)
      .single();

    if (!provider) return;

    // Calculate new average response time
    const currentAvg = provider.avg_response_time_ms || responseTimeMs;
    const newAvg = Math.round((currentAvg * 0.9) + (responseTimeMs * 0.1));

    // Slightly increase health score on success
    const newHealthScore = Math.min(1.0, (provider.health_score || 0.5) + 0.01);

    await this.supabase
      .from('provider_health')
      .update({
        avg_response_time_ms: newAvg,
        health_score: newHealthScore,
        last_check_at: new Date().toISOString()
      })
      .eq('provider_type', providerType)
      .eq('provider_name', providerName);
  }

  /**
   * Mark a provider as unavailable
   */
  async markUnavailable(providerType: ProviderType, providerName: string): Promise<void> {
    await this.supabase
      .from('provider_health')
      .update({
        is_available: false,
        health_score: 0
      })
      .eq('provider_type', providerType)
      .eq('provider_name', providerName);

    console.warn(`Provider ${providerName} (${providerType}) marked as unavailable`);
  }

  /**
   * Mark a provider as available (recovery)
   */
  async markAvailable(providerType: ProviderType, providerName: string): Promise<void> {
    await this.supabase
      .from('provider_health')
      .update({
        is_available: true,
        health_score: 0.5, // Start with moderate health after recovery
        failure_count_24h: 0
      })
      .eq('provider_type', providerType)
      .eq('provider_name', providerName);

    // Check if this resolves any failover events
    await this.checkFailoverResolution(providerType, providerName);

    console.log(`Provider ${providerName} (${providerType}) marked as available`);
  }

  /**
   * Register a health check function for a provider
   */
  registerHealthChecker(
    providerType: ProviderType, 
    providerName: string, 
    checker: () => Promise<HealthCheckResult>
  ): void {
    const key = `${providerType}:${providerName}`;
    this.healthCheckers.set(key, checker);
  }

  /**
   * Run health checks on all registered providers
   */
  async runHealthChecks(): Promise<void> {
    const { data: providers } = await this.supabase
      .from('provider_health')
      .select('provider_type, provider_name, is_available');

    if (!providers) return;

    for (const provider of providers) {
      const key = `${provider.provider_type}:${provider.provider_name}`;
      const checker = this.healthCheckers.get(key);

      if (checker) {
        try {
          const result = await checker();
          
          if (result.healthy) {
            await this.reportSuccess(
              provider.provider_type as ProviderType,
              provider.provider_name,
              result.responseTimeMs
            );

            // If was unavailable, mark as available
            if (!provider.is_available) {
              await this.markAvailable(
                provider.provider_type as ProviderType,
                provider.provider_name
              );
            }
          } else {
            await this.reportFailure(
              provider.provider_type as ProviderType,
              provider.provider_name,
              result.error || 'Health check failed'
            );
          }
        } catch (error) {
          await this.reportFailure(
            provider.provider_type as ProviderType,
            provider.provider_name,
            error instanceof Error ? error.message : 'Health check error'
          );
        }
      }
    }

    // Reset 24h failure counts at midnight
    await this.resetDailyFailureCounts();
  }

  /**
   * Start automatic health checking
   */
  startHealthChecks(intervalMs: number = 60000): void {
    if (this.healthCheckInterval) {
      return;
    }

    this.healthCheckInterval = setInterval(() => {
      this.runHealthChecks().catch(console.error);
    }, intervalMs);

    // Run immediately
    this.runHealthChecks().catch(console.error);
  }

  /**
   * Stop automatic health checking
   */
  stopHealthChecks(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }

  /**
   * Log a failover event
   */
  private async logFailover(
    providerType: ProviderType,
    fromProvider: string,
    toProvider: string,
    reason: string
  ): Promise<void> {
    await this.supabase
      .from('failover_events')
      .insert({
        provider_type: providerType,
        from_provider: fromProvider,
        to_provider: toProvider,
        reason
      });

    console.warn(`FAILOVER: ${providerType} from ${fromProvider} to ${toProvider} - ${reason}`);
  }

  /**
   * Check if a recovery resolves pending failover events
   */
  private async checkFailoverResolution(
    providerType: ProviderType,
    providerName: string
  ): Promise<void> {
    // Get primary provider for this type
    const { data: primary } = await this.supabase
      .from('provider_health')
      .select('provider_name')
      .eq('provider_type', providerType)
      .eq('is_primary', true)
      .single();

    if (primary && primary.provider_name === providerName) {
      // Primary is back - resolve any failover events
      await this.supabase
        .from('failover_events')
        .update({
          resolved_at: new Date().toISOString(),
          auto_resolved: true
        })
        .eq('provider_type', providerType)
        .eq('from_provider', providerName)
        .is('resolved_at', null);
    }
  }

  /**
   * Reset 24h failure counts (call daily)
   */
  private async resetDailyFailureCounts(): Promise<void> {
    const now = new Date();
    if (now.getHours() === 0 && now.getMinutes() < 5) {
      await this.supabase
        .from('provider_health')
        .update({ failure_count_24h: 0 })
        .neq('failure_count_24h', 0);
    }
  }

  /**
   * Get provider status summary
   */
  async getStatus(): Promise<Record<ProviderType, Provider[]>> {
    const { data: providers } = await this.supabase
      .from('provider_health')
      .select('*')
      .order('provider_type')
      .order('priority_order');

    const result: Record<string, Provider[]> = {
      pod_fulfillment: [],
      ai_generation: [],
      storage: [],
      payment: []
    };

    for (const p of providers || []) {
      if (result[p.provider_type]) {
        result[p.provider_type].push(p);
      }
    }

    return result as Record<ProviderType, Provider[]>;
  }

  /**
   * Get recent failover events
   */
  async getRecentFailovers(limit: number = 10): Promise<FailoverEvent[]> {
    const { data } = await this.supabase
      .from('failover_events')
      .select('*')
      .order('triggered_at', { ascending: false })
      .limit(limit);

    return data || [];
  }
}

// =============================================================================
// PRE-BUILT HEALTH CHECKERS
// =============================================================================

export const healthCheckers = {
  /**
   * Printify health checker
   */
  printify: (apiKey: string) => async (): Promise<HealthCheckResult> => {
    const start = Date.now();
    try {
      const response = await fetch('https://api.printify.com/v1/shops.json', {
        headers: { 'Authorization': `Bearer ${apiKey}` }
      });
      
      return {
        healthy: response.ok,
        responseTimeMs: Date.now() - start,
        error: response.ok ? undefined : `HTTP ${response.status}`
      };
    } catch (error) {
      return {
        healthy: false,
        responseTimeMs: Date.now() - start,
        error: error instanceof Error ? error.message : 'Connection failed'
      };
    }
  },

  /**
   * OpenAI health checker
   */
  openai: (apiKey: string) => async (): Promise<HealthCheckResult> => {
    const start = Date.now();
    try {
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: { 'Authorization': `Bearer ${apiKey}` }
      });
      
      return {
        healthy: response.ok,
        responseTimeMs: Date.now() - start,
        error: response.ok ? undefined : `HTTP ${response.status}`
      };
    } catch (error) {
      return {
        healthy: false,
        responseTimeMs: Date.now() - start,
        error: error instanceof Error ? error.message : 'Connection failed'
      };
    }
  },

  /**
   * Replicate health checker
   */
  replicate: (apiToken: string) => async (): Promise<HealthCheckResult> => {
    const start = Date.now();
    try {
      const response = await fetch('https://api.replicate.com/v1/collections', {
        headers: { 'Authorization': `Token ${apiToken}` }
      });
      
      return {
        healthy: response.ok,
        responseTimeMs: Date.now() - start,
        error: response.ok ? undefined : `HTTP ${response.status}`
      };
    } catch (error) {
      return {
        healthy: false,
        responseTimeMs: Date.now() - start,
        error: error instanceof Error ? error.message : 'Connection failed'
      };
    }
  },

  /**
   * Generic HTTP health checker
   */
  http: (url: string, headers?: Record<string, string>) => async (): Promise<HealthCheckResult> => {
    const start = Date.now();
    try {
      const response = await fetch(url, { headers });
      
      return {
        healthy: response.ok,
        responseTimeMs: Date.now() - start,
        error: response.ok ? undefined : `HTTP ${response.status}`
      };
    } catch (error) {
      return {
        healthy: false,
        responseTimeMs: Date.now() - start,
        error: error instanceof Error ? error.message : 'Connection failed'
      };
    }
  }
};

export default ProviderFailover;
