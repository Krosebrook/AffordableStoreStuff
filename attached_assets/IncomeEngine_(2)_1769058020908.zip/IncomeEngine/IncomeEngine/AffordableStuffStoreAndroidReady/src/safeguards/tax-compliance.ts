/**
 * ============================================================================
 * SAFEGUARD #6: TAX COMPLIANCE
 * ============================================================================
 * 
 * Purpose: Ensure proper sales tax / VAT collection across jurisdictions
 * 
 * Features:
 * - Multi-state US sales tax calculation
 * - International VAT/GST support
 * - Nexus threshold monitoring
 * - Integration with Shopify Tax, TaxJar, Avalara
 * - Tax transaction logging for reporting
 * - Registration requirement alerts
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// =============================================================================
// TYPES
// =============================================================================

type TaxProvider = 'shopify_tax' | 'taxjar' | 'avalara' | 'manual';

interface TaxConfig {
  regionCode: string;
  regionName: string;
  taxType: 'sales_tax' | 'vat' | 'gst' | 'none';
  defaultRate: number;
  requiresRegistration: boolean;
  registrationThresholdUsd: number;
  taxProvider: TaxProvider;
}

interface TaxCalculation {
  orderId: string;
  platform: string;
  customerRegion: string;
  subtotalUsd: number;
  taxAmountUsd: number;
  taxRate: number;
  taxProvider: TaxProvider;
  breakdown?: TaxBreakdown[];
}

interface TaxBreakdown {
  jurisdiction: string;
  rate: number;
  amount: number;
  type: string;
}

interface NexusStatus {
  regionCode: string;
  regionName: string;
  currentSalesUsd: number;
  thresholdUsd: number;
  percentToThreshold: number;
  requiresRegistration: boolean;
  registrationRequired: boolean;
  alertLevel: 'ok' | 'warning' | 'action_required';
}

// =============================================================================
// TAX COMPLIANCE CLASS
// =============================================================================

export class TaxCompliance {
  private supabase: SupabaseClient;
  private provider: TaxProvider;
  private taxjarApiKey?: string;
  private avalaraConfig?: { accountId: string; licenseKey: string; environment: string };

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    provider: TaxProvider = 'shopify_tax',
    providerConfig?: {
      taxjarApiKey?: string;
      avalaraAccountId?: string;
      avalaraLicenseKey?: string;
      avalaraEnvironment?: string;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.provider = provider;
    this.taxjarApiKey = providerConfig?.taxjarApiKey;
    
    if (providerConfig?.avalaraAccountId) {
      this.avalaraConfig = {
        accountId: providerConfig.avalaraAccountId,
        licenseKey: providerConfig.avalaraLicenseKey || '',
        environment: providerConfig.avalaraEnvironment || 'production'
      };
    }
  }

  /**
   * Calculate tax for an order
   */
  async calculateTax(order: {
    orderId: string;
    platform: string;
    subtotalUsd: number;
    shippingUsd?: number;
    customerAddress: {
      country: string;
      state?: string;
      city?: string;
      postalCode?: string;
    };
    lineItems?: Array<{
      productType: string;
      amount: number;
      quantity: number;
    }>;
  }): Promise<TaxCalculation> {
    // Determine region code
    const regionCode = this.getRegionCode(
      order.customerAddress.country,
      order.customerAddress.state
    );

    // Get tax config for region
    const config = await this.getTaxConfig(regionCode);

    // Calculate based on provider
    let calculation: TaxCalculation;

    switch (this.provider) {
      case 'taxjar':
        calculation = await this.calculateWithTaxJar(order, config);
        break;
      case 'avalara':
        calculation = await this.calculateWithAvalara(order, config);
        break;
      case 'shopify_tax':
        calculation = await this.calculateWithShopifyTax(order, config);
        break;
      default:
        calculation = this.calculateManual(order, config);
    }

    // Log transaction
    await this.logTransaction(calculation);

    // Update nexus tracking
    await this.updateNexusTracking(regionCode, order.subtotalUsd);

    return calculation;
  }

  /**
   * Calculate using TaxJar API
   */
  private async calculateWithTaxJar(
    order: any,
    config: TaxConfig
  ): Promise<TaxCalculation> {
    if (!this.taxjarApiKey) {
      console.warn('TaxJar API key not configured, falling back to manual');
      return this.calculateManual(order, config);
    }

    try {
      const response = await fetch('https://api.taxjar.com/v2/taxes', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.taxjarApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          to_country: order.customerAddress.country,
          to_state: order.customerAddress.state,
          to_city: order.customerAddress.city,
          to_zip: order.customerAddress.postalCode,
          amount: order.subtotalUsd,
          shipping: order.shippingUsd || 0,
          line_items: order.lineItems?.map((item: any, idx: number) => ({
            id: `item_${idx}`,
            quantity: item.quantity,
            unit_price: item.amount / item.quantity,
            product_tax_code: this.getProductTaxCode(item.productType)
          }))
        })
      });

      if (!response.ok) {
        throw new Error(`TaxJar API error: ${response.status}`);
      }

      const data = await response.json();
      const tax = data.tax;

      return {
        orderId: order.orderId,
        platform: order.platform,
        customerRegion: config.regionCode,
        subtotalUsd: order.subtotalUsd,
        taxAmountUsd: tax.amount_to_collect,
        taxRate: tax.rate,
        taxProvider: 'taxjar',
        breakdown: tax.breakdown?.line_items?.map((item: any) => ({
          jurisdiction: item.state || config.regionName,
          rate: item.combined_tax_rate,
          amount: item.tax_collectable,
          type: config.taxType
        }))
      };

    } catch (error) {
      console.error('TaxJar calculation failed:', error);
      return this.calculateManual(order, config);
    }
  }

  /**
   * Calculate using Avalara API
   */
  private async calculateWithAvalara(
    order: any,
    config: TaxConfig
  ): Promise<TaxCalculation> {
    if (!this.avalaraConfig) {
      console.warn('Avalara not configured, falling back to manual');
      return this.calculateManual(order, config);
    }

    try {
      const baseUrl = this.avalaraConfig.environment === 'sandbox'
        ? 'https://sandbox-rest.avatax.com/api/v2'
        : 'https://rest.avatax.com/api/v2';

      const credentials = Buffer.from(
        `${this.avalaraConfig.accountId}:${this.avalaraConfig.licenseKey}`
      ).toString('base64');

      const response = await fetch(`${baseUrl}/transactions/create`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${credentials}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'SalesOrder',
          companyCode: 'DEFAULT',
          date: new Date().toISOString().split('T')[0],
          customerCode: 'CUSTOMER',
          addresses: {
            shipTo: {
              country: order.customerAddress.country,
              region: order.customerAddress.state,
              city: order.customerAddress.city,
              postalCode: order.customerAddress.postalCode
            }
          },
          lines: order.lineItems?.map((item: any, idx: number) => ({
            number: `${idx + 1}`,
            quantity: item.quantity,
            amount: item.amount,
            taxCode: this.getAvalaraTaxCode(item.productType)
          })) || [{
            number: '1',
            quantity: 1,
            amount: order.subtotalUsd
          }]
        })
      });

      if (!response.ok) {
        throw new Error(`Avalara API error: ${response.status}`);
      }

      const data = await response.json();

      return {
        orderId: order.orderId,
        platform: order.platform,
        customerRegion: config.regionCode,
        subtotalUsd: order.subtotalUsd,
        taxAmountUsd: data.totalTax,
        taxRate: data.totalTax / order.subtotalUsd,
        taxProvider: 'avalara',
        breakdown: data.lines?.map((line: any) => ({
          jurisdiction: line.details?.[0]?.jurisName || config.regionName,
          rate: line.details?.[0]?.rate || 0,
          amount: line.tax,
          type: config.taxType
        }))
      };

    } catch (error) {
      console.error('Avalara calculation failed:', error);
      return this.calculateManual(order, config);
    }
  }

  /**
   * Calculate using Shopify's built-in tax system
   * Note: This is handled by Shopify automatically when using their checkout
   * This method is for reference/validation
   */
  private async calculateWithShopifyTax(
    order: any,
    config: TaxConfig
  ): Promise<TaxCalculation> {
    // Shopify Tax handles this automatically in checkout
    // For API orders, we use their rate tables
    const taxAmount = order.subtotalUsd * config.defaultRate;

    return {
      orderId: order.orderId,
      platform: order.platform,
      customerRegion: config.regionCode,
      subtotalUsd: order.subtotalUsd,
      taxAmountUsd: Math.round(taxAmount * 100) / 100,
      taxRate: config.defaultRate,
      taxProvider: 'shopify_tax',
      breakdown: [{
        jurisdiction: config.regionName,
        rate: config.defaultRate,
        amount: taxAmount,
        type: config.taxType
      }]
    };
  }

  /**
   * Manual tax calculation using stored rates
   */
  private calculateManual(order: any, config: TaxConfig): TaxCalculation {
    const taxAmount = order.subtotalUsd * config.defaultRate;

    return {
      orderId: order.orderId,
      platform: order.platform,
      customerRegion: config.regionCode,
      subtotalUsd: order.subtotalUsd,
      taxAmountUsd: Math.round(taxAmount * 100) / 100,
      taxRate: config.defaultRate,
      taxProvider: 'manual',
      breakdown: [{
        jurisdiction: config.regionName,
        rate: config.defaultRate,
        amount: taxAmount,
        type: config.taxType
      }]
    };
  }

  /**
   * Get tax configuration for a region
   */
  private async getTaxConfig(regionCode: string): Promise<TaxConfig> {
    const { data } = await this.supabase
      .from('tax_configurations')
      .select('*')
      .eq('region_code', regionCode)
      .single();

    if (data) {
      return {
        regionCode: data.region_code,
        regionName: data.region_name,
        taxType: data.tax_type,
        defaultRate: parseFloat(data.default_rate),
        requiresRegistration: data.requires_registration,
        registrationThresholdUsd: parseFloat(data.registration_threshold_usd || 0),
        taxProvider: data.tax_provider
      };
    }

    // Default: no tax
    return {
      regionCode,
      regionName: regionCode,
      taxType: 'none',
      defaultRate: 0,
      requiresRegistration: false,
      registrationThresholdUsd: 0,
      taxProvider: 'manual'
    };
  }

  /**
   * Log tax transaction
   */
  private async logTransaction(calculation: TaxCalculation): Promise<void> {
    await this.supabase
      .from('tax_transactions')
      .insert({
        order_id: calculation.orderId,
        platform: calculation.platform,
        customer_region: calculation.customerRegion,
        subtotal_usd: calculation.subtotalUsd,
        tax_amount_usd: calculation.taxAmountUsd,
        tax_rate: calculation.taxRate,
        tax_provider: calculation.taxProvider,
        tax_provider_transaction_id: null // Set if provider returns one
      });
  }

  /**
   * Update nexus tracking for a region
   */
  private async updateNexusTracking(regionCode: string, saleAmount: number): Promise<void> {
    // This would track cumulative sales per region for nexus threshold monitoring
    // Implementation depends on your nexus tracking strategy
    const year = new Date().getFullYear();
    
    // Upsert into a nexus tracking table (you'd add this to schema)
    // For now, we'll log it
    console.log(`Nexus tracking: ${regionCode} +$${saleAmount} (${year})`);
  }

  /**
   * Get nexus status for all tracked regions
   */
  async getNexusStatus(): Promise<NexusStatus[]> {
    const { data: configs } = await this.supabase
      .from('tax_configurations')
      .select('*')
      .eq('requires_registration', true);

    if (!configs) return [];

    const statuses: NexusStatus[] = [];

    for (const config of configs) {
      // Get total sales for this region (current year)
      const year = new Date().getFullYear();
      const { data: sales } = await this.supabase
        .from('tax_transactions')
        .select('subtotal_usd')
        .eq('customer_region', config.region_code)
        .gte('calculated_at', `${year}-01-01`);

      const totalSales = sales?.reduce((sum, s) => sum + parseFloat(s.subtotal_usd), 0) || 0;
      const threshold = parseFloat(config.registration_threshold_usd || 0);
      const percent = threshold > 0 ? (totalSales / threshold) * 100 : 0;

      let alertLevel: 'ok' | 'warning' | 'action_required' = 'ok';
      if (percent >= 100) {
        alertLevel = 'action_required';
      } else if (percent >= 80) {
        alertLevel = 'warning';
      }

      statuses.push({
        regionCode: config.region_code,
        regionName: config.region_name,
        currentSalesUsd: totalSales,
        thresholdUsd: threshold,
        percentToThreshold: Math.round(percent),
        requiresRegistration: config.requires_registration,
        registrationRequired: percent >= 100,
        alertLevel
      });
    }

    return statuses.sort((a, b) => b.percentToThreshold - a.percentToThreshold);
  }

  /**
   * Get product tax code for TaxJar
   */
  private getProductTaxCode(productType: string): string {
    const codes: Record<string, string> = {
      'tshirt': '20010',      // Clothing
      'mug': '40030',         // Housewares
      'sticker': '20010',     // General tangible
      'poster': '20010',      // General tangible
      'coloring_book': '81100', // Books
      'journal': '81100',     // Books
      'planner': '81100',     // Books
      'digital': '31000',     // Digital goods
    };
    return codes[productType] || '00000';
  }

  /**
   * Get product tax code for Avalara
   */
  private getAvalaraTaxCode(productType: string): string {
    const codes: Record<string, string> = {
      'tshirt': 'PC040100',     // Clothing
      'mug': 'PF050001',        // Housewares
      'sticker': 'P0000000',    // General tangible
      'poster': 'P0000000',     // General tangible
      'coloring_book': 'PB100000', // Books
      'journal': 'PB100000',    // Books
      'planner': 'PB100000',    // Books
      'digital': 'D0000000',    // Digital goods
    };
    return codes[productType] || 'P0000000';
  }

  /**
   * Get region code from country/state
   */
  private getRegionCode(country: string, state?: string): string {
    const countryUpper = country.toUpperCase();
    
    if (countryUpper === 'US' && state) {
      return `US-${state.toUpperCase()}`;
    }
    
    if (['DE', 'FR', 'UK', 'GB', 'NL', 'IT', 'ES'].includes(countryUpper)) {
      return `EU-${countryUpper}`;
    }
    
    return countryUpper;
  }

  /**
   * Generate tax report for a period
   */
  async generateReport(startDate: Date, endDate: Date): Promise<{
    totalSales: number;
    totalTaxCollected: number;
    byRegion: Record<string, { sales: number; tax: number; transactions: number }>;
    byPlatform: Record<string, { sales: number; tax: number; transactions: number }>;
  }> {
    const { data: transactions } = await this.supabase
      .from('tax_transactions')
      .select('*')
      .gte('calculated_at', startDate.toISOString())
      .lte('calculated_at', endDate.toISOString());

    if (!transactions || transactions.length === 0) {
      return {
        totalSales: 0,
        totalTaxCollected: 0,
        byRegion: {},
        byPlatform: {}
      };
    }

    const byRegion: Record<string, { sales: number; tax: number; transactions: number }> = {};
    const byPlatform: Record<string, { sales: number; tax: number; transactions: number }> = {};

    let totalSales = 0;
    let totalTax = 0;

    for (const t of transactions) {
      const sales = parseFloat(t.subtotal_usd);
      const tax = parseFloat(t.tax_amount_usd);

      totalSales += sales;
      totalTax += tax;

      // By region
      if (!byRegion[t.customer_region]) {
        byRegion[t.customer_region] = { sales: 0, tax: 0, transactions: 0 };
      }
      byRegion[t.customer_region].sales += sales;
      byRegion[t.customer_region].tax += tax;
      byRegion[t.customer_region].transactions += 1;

      // By platform
      if (!byPlatform[t.platform]) {
        byPlatform[t.platform] = { sales: 0, tax: 0, transactions: 0 };
      }
      byPlatform[t.platform].sales += sales;
      byPlatform[t.platform].tax += tax;
      byPlatform[t.platform].transactions += 1;
    }

    return {
      totalSales: Math.round(totalSales * 100) / 100,
      totalTaxCollected: Math.round(totalTax * 100) / 100,
      byRegion,
      byPlatform
    };
  }
}

export default TaxCompliance;
