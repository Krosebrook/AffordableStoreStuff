/**
 * ============================================================================
 * SAFEGUARDS ORCHESTRATOR - REPLIT VERSION
 * ============================================================================
 * 
 * Simplified orchestrator for Replit deployment
 * Uses Replit Secrets for configuration
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// =============================================================================
// TYPES
// =============================================================================

interface ProductInput {
  id: string;
  type: string;
  niche: string;
  title: string;
  description: string;
  keywords: string[];
  imageUrl: string;
  targetPlatforms: string[];
  estimatedCost?: number;
}

interface ProcessingResult {
  productId: string;
  status: 'approved' | 'queued' | 'rejected' | 'blocked';
  stage: string;
  details: Record<string, any>;
  errors: string[];
  warnings: string[];
  nextSteps: string[];
}

interface SystemStatus {
  budget: Array<{
    period: string;
    currentSpend: number;
    limit: number;
    percentUsed: number;
    isWarning: boolean;
    isExceeded: boolean;
    remainingBudget: number;
  }>;
  queues: {
    queued: number;
    processing: number;
    rateLimited: number;
    deadLetter: number;
    completedToday: number;
  };
  approvalStats: {
    totalApproved: number;
    totalRejected: number;
    approvalRate: number;
    pendingCount: number;
  };
  providers: any;
  circuitBreakers: Record<string, any>;
}

// =============================================================================
// ORCHESTRATOR CLASS
// =============================================================================

export class SafeguardsOrchestrator {
  private supabase: SupabaseClient;

  constructor() {
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_KEY in Replit Secrets');
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * Process a product through all safeguards
   */
  async processProduct(product: ProductInput): Promise<ProcessingResult> {
    const result: ProcessingResult = {
      productId: product.id,
      status: 'approved',
      stage: 'init',
      details: {},
      errors: [],
      warnings: [],
      nextSteps: []
    };

    try {
      // Stage 1: Budget Check
      result.stage = 'budget_check';
      const budgetStatus = await this.getBudgetStatus('daily');
      result.details.budget = budgetStatus;

      if (budgetStatus.isExceeded) {
        result.status = 'blocked';
        result.errors.push('Daily budget exceeded');
        return result;
      }

      // Stage 2: Trademark Check
      result.stage = 'trademark_check';
      const blockedTerms = await this.checkBlockedTerms(product.title, product.keywords);
      result.details.trademark = { blockedTerms };

      if (blockedTerms.length > 0) {
        result.status = 'rejected';
        result.errors.push(`Blocked terms: ${blockedTerms.join(', ')}`);
        return result;
      }

      // Stage 3: Rate Limit Check
      result.stage = 'rate_limit_check';
      for (const platform of product.targetPlatforms) {
        const { data } = await this.supabase.rpc('check_upload_allowed', {
          p_platform: platform
        });
        
        if (data && !data[0]?.allowed) {
          result.warnings.push(`${platform}: Rate limited`);
        }
      }

      // Stage 4: Human Review Check
      result.stage = 'human_review';
      const { data: reviewRequired } = await this.supabase.rpc('is_human_review_required');

      if (reviewRequired) {
        // Queue for human review
        await this.supabase.from('approval_queue').insert({
          product_id: product.id,
          product_type: product.type,
          product_data: product,
          status: 'pending',
          target_platforms: product.targetPlatforms
        });

        result.status = 'queued';
        result.nextSteps.push('Awaiting human review');
      } else {
        result.status = 'approved';
        result.nextSteps.push('Auto-approved - ready for publishing');
      }

      result.stage = 'complete';
      return result;

    } catch (error) {
      result.status = 'blocked';
      result.errors.push(`Error at ${result.stage}: ${error instanceof Error ? error.message : 'Unknown'}`);
      return result;
    }
  }

  /**
   * Get system status
   */
  async getSystemStatus(): Promise<SystemStatus> {
    // Get budget status for all periods
    const budgetPromises = ['daily', 'weekly', 'monthly'].map(period => 
      this.getBudgetStatus(period)
    );
    const budget = await Promise.all(budgetPromises);

    // Get queue stats
    const { data: queueData } = await this.supabase
      .from('api_queue')
      .select('status');

    const queues = {
      queued: queueData?.filter(q => q.status === 'queued').length || 0,
      processing: queueData?.filter(q => q.status === 'processing').length || 0,
      rateLimited: queueData?.filter(q => q.status === 'rate_limited').length || 0,
      deadLetter: queueData?.filter(q => q.status === 'dead_letter').length || 0,
      completedToday: queueData?.filter(q => q.status === 'completed').length || 0
    };

    // Get approval stats
    const { data: approvalData } = await this.supabase
      .from('approval_queue')
      .select('status');

    const approved = approvalData?.filter(a => a.status === 'approved').length || 0;
    const rejected = approvalData?.filter(a => a.status === 'rejected').length || 0;
    const pending = approvalData?.filter(a => a.status === 'pending').length || 0;

    const approvalStats = {
      totalApproved: approved,
      totalRejected: rejected,
      approvalRate: approved + rejected > 0 ? approved / (approved + rejected) : 0,
      pendingCount: pending
    };

    // Get circuit breaker states
    const { data: breakerData } = await this.supabase
      .from('circuit_breaker_state')
      .select('*');

    const circuitBreakers: Record<string, any> = {};
    breakerData?.forEach(b => {
      circuitBreakers[b.breaker_name] = {
        isOpen: b.is_open,
        openedReason: b.opened_reason
      };
    });

    // Get provider health
    const { data: providerData } = await this.supabase
      .from('provider_health')
      .select('*');

    return {
      budget,
      queues,
      approvalStats,
      providers: providerData || [],
      circuitBreakers
    };
  }

  /**
   * Get budget status for a period
   */
  private async getBudgetStatus(period: string) {
    const { data } = await this.supabase.rpc('get_budget_status', {
      p_budget_type: period
    });

    if (!data || data.length === 0) {
      return {
        period,
        currentSpend: 0,
        limit: period === 'daily' ? 25 : period === 'weekly' ? 150 : 500,
        percentUsed: 0,
        isWarning: false,
        isExceeded: false,
        remainingBudget: period === 'daily' ? 25 : period === 'weekly' ? 150 : 500
      };
    }

    const d = data[0];
    return {
      period,
      currentSpend: d.current_spend || 0,
      limit: d.limit_amount || 0,
      percentUsed: d.percent_used || 0,
      isWarning: d.is_warning || false,
      isExceeded: d.is_exceeded || false,
      remainingBudget: Math.max(0, (d.limit_amount || 0) - (d.current_spend || 0))
    };
  }

  /**
   * Check for blocked trademark terms
   */
  private async checkBlockedTerms(title: string, keywords: string[]): Promise<string[]> {
    const allTerms = [
      ...title.toLowerCase().split(' '),
      ...keywords.map(k => k.toLowerCase())
    ].filter(t => t.length > 2);

    const { data } = await this.supabase
      .from('blocked_terms')
      .select('term')
      .in('term', allTerms);

    return data?.map(d => d.term) || [];
  }


  // =============================================================================
  // HUMAN REVIEW ACTIONS (Dashboard)
  // =============================================================================

  /**
   * Approve a pending approval_queue item.
   * NOTE: RLS should prevent untrusted clients from calling this directly.
   * The server uses the Supabase Service Role key.
   */
  async approveApproval(id: string, reviewerId: string, reviewerNotes?: string): Promise<void> {
    const { error } = await this.supabase
      .from('approval_queue')
      .update({
        status: 'approved',
        reviewer_id: reviewerId,
        reviewer_notes: reviewerNotes ?? null,
        reviewed_at: new Date().toISOString(),
        rejection_reason: null
      })
      .eq('id', id);

    if (error) throw new Error(`Failed to approve item: ${error.message}`);

    // Best-effort stats update (non-fatal)
    try {
      await this.supabase.rpc('refresh_approval_stats');
    } catch {
      // ignore
    }
  }

  /**
   * Reject a pending approval_queue item.
   */
  async rejectApproval(id: string, reviewerId: string, reason: string, reviewerNotes?: string): Promise<void> {
    const { error } = await this.supabase
      .from('approval_queue')
      .update({
        status: 'rejected',
        reviewer_id: reviewerId,
        reviewer_notes: reviewerNotes ?? null,
        rejection_reason: reason,
        reviewed_at: new Date().toISOString(),
      })
      .eq('id', id);

    if (error) throw new Error(`Failed to reject item: ${error.message}`);

    try {
      await this.supabase.rpc('refresh_approval_stats');
    } catch {
      // ignore
    }
  }

}

export function createSafeguardsOrchestrator(): SafeguardsOrchestrator {
  return new SafeguardsOrchestrator();
}

export default SafeguardsOrchestrator;
