/**
 * ============================================================================
 * SAFEGUARD #3: TRADEMARK SCREENING
 * ============================================================================
 * 
 * Purpose: Prevent copyright/trademark infringement by screening product content
 * against USPTO TESS database and known blocked terms.
 * 
 * Features:
 * - Instant blocking of known trademarked terms
 * - USPTO TESS database scraping (no public API)
 * - Fuzzy matching for trademark variants
 * - Celebrity/brand name detection
 * - Risk level categorization (clear, caution, blocked)
 * - Caching to reduce API calls
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { chromium, Browser, Page } from 'playwright';

// =============================================================================
// TYPES
// =============================================================================

interface TrademarkCheckResult {
  searchTerm: string;
  riskLevel: 'clear' | 'caution' | 'blocked';
  matchingMarks: TrademarkMatch[];
  blockedReason?: string;
  checkedAt: Date;
  fromCache: boolean;
}

interface TrademarkMatch {
  serialNumber: string;
  registrationNumber?: string;
  wordMark: string;
  owner: string;
  status: 'live' | 'dead' | 'pending';
  goodsServices: string;
  similarity: number;
}

interface BlockedTerm {
  term: string;
  reason: string;
  category: 'trademark' | 'copyright' | 'celebrity' | 'brand' | 'offensive';
}

interface ProductScreeningResult {
  productId: string;
  overallRisk: 'clear' | 'caution' | 'blocked';
  termResults: TrademarkCheckResult[];
  blockedTerms: string[];
  cautionTerms: string[];
  recommendedActions: string[];
}

// =============================================================================
// TRADEMARK SCREENER CLASS
// =============================================================================

export class TrademarkScreener {
  private supabase: SupabaseClient;
  private browser: Browser | null = null;
  private blockedTermsCache: Map<string, BlockedTerm> = new Map();
  private cacheLoaded: boolean = false;
  private tessRateLimit: number; // Requests per minute

  constructor(
    supabaseUrl: string, 
    supabaseKey: string,
    tessRateLimit: number = 5
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.tessRateLimit = tessRateLimit;
  }

  /**
   * Screen a product for trademark issues
   */
  async screenProduct(product: {
    id: string;
    title: string;
    description: string;
    keywords: string[];
    niche: string;
  }): Promise<ProductScreeningResult> {
    await this.loadBlockedTermsCache();

    // Extract terms to check
    const termsToCheck = this.extractTermsToCheck(product);
    
    const termResults: TrademarkCheckResult[] = [];
    const blockedTerms: string[] = [];
    const cautionTerms: string[] = [];
    const recommendedActions: string[] = [];

    // Check each term
    for (const term of termsToCheck) {
      const result = await this.checkTerm(term);
      termResults.push(result);

      if (result.riskLevel === 'blocked') {
        blockedTerms.push(term);
      } else if (result.riskLevel === 'caution') {
        cautionTerms.push(term);
      }
    }

    // Determine overall risk
    let overallRisk: 'clear' | 'caution' | 'blocked' = 'clear';
    
    if (blockedTerms.length > 0) {
      overallRisk = 'blocked';
      recommendedActions.push(`Remove blocked terms: ${blockedTerms.join(', ')}`);
      recommendedActions.push('Do NOT proceed with this product as-is');
    } else if (cautionTerms.length > 0) {
      overallRisk = 'caution';
      recommendedActions.push(`Review potentially problematic terms: ${cautionTerms.join(', ')}`);
      recommendedActions.push('Consider alternative wording or manual trademark search');
    }

    // Save screening result
    await this.saveScreeningResult(product.id, {
      overallRisk,
      termResults,
      blockedTerms,
      cautionTerms,
      recommendedActions
    });

    return {
      productId: product.id,
      overallRisk,
      termResults,
      blockedTerms,
      cautionTerms,
      recommendedActions
    };
  }

  /**
   * Check a single term for trademark issues
   */
  async checkTerm(term: string): Promise<TrademarkCheckResult> {
    const normalizedTerm = term.toLowerCase().trim();

    // 1. First check blocked terms cache (instant)
    const blockedCheck = this.checkBlockedTerms(normalizedTerm);
    if (blockedCheck) {
      return {
        searchTerm: term,
        riskLevel: 'blocked',
        matchingMarks: [],
        blockedReason: blockedCheck.reason,
        checkedAt: new Date(),
        fromCache: true
      };
    }

    // 2. Check database cache
    const cachedResult = await this.getCachedResult(normalizedTerm);
    if (cachedResult) {
      return {
        ...cachedResult,
        searchTerm: term,
        fromCache: true
      };
    }

    // 3. Query TESS database (rate limited)
    const tessResults = await this.queryTESS(normalizedTerm);

    // 4. Analyze results and determine risk
    const riskLevel = this.analyzeRiskLevel(tessResults);

    // 5. Cache result
    const result: TrademarkCheckResult = {
      searchTerm: term,
      riskLevel,
      matchingMarks: tessResults,
      checkedAt: new Date(),
      fromCache: false
    };

    await this.cacheResult(normalizedTerm, result);

    return result;
  }

  /**
   * Query USPTO TESS database
   * Note: No public API exists, using web scraping with rate limiting
   */
  private async queryTESS(term: string): Promise<TrademarkMatch[]> {
    // Rate limiting
    await this.rateLimitDelay();

    try {
      // Initialize browser if needed
      if (!this.browser) {
        this.browser = await chromium.launch({ headless: true });
      }

      const page = await this.browser.newPage();
      
      try {
        // Navigate to TESS
        await page.goto('https://tmsearch.uspto.gov/bin/gate.exe?f=login&p_lang=english&p_d=trmk', {
          timeout: 30000
        });

        // Accept disclaimer if present
        const disclaimerButton = await page.$('input[type="submit"][value*="I Agree"]');
        if (disclaimerButton) {
          await disclaimerButton.click();
          await page.waitForLoadState('networkidle');
        }

        // Navigate to word mark search
        await page.click('a:has-text("Word and/or Design Mark Search")');
        await page.waitForLoadState('networkidle');

        // Enter search term
        await page.fill('input[name="p_s_ALL"]', term);
        
        // Submit search
        await page.click('input[type="submit"][value="Submit Query"]');
        await page.waitForLoadState('networkidle');

        // Parse results
        const matches = await this.parseTESSResults(page);
        
        return matches;

      } finally {
        await page.close();
      }

    } catch (error) {
      console.error(`TESS query failed for "${term}":`, error);
      // Return empty results on error (fail open for TESS queries)
      // But blocked terms still block (fail closed)
      return [];
    }
  }

  /**
   * Parse TESS search results
   */
  private async parseTESSResults(page: Page): Promise<TrademarkMatch[]> {
    const matches: TrademarkMatch[] = [];

    // Check if no results
    const noResults = await page.$('text="No TESS records were found"');
    if (noResults) {
      return [];
    }

    // Check if too many results (indicates common term)
    const tooManyResults = await page.$('text="Too many records to list"');
    if (tooManyResults) {
      // Return a synthetic "caution" result
      return [{
        serialNumber: 'MULTIPLE',
        wordMark: 'Multiple matches',
        owner: 'Various',
        status: 'live',
        goodsServices: 'Various',
        similarity: 0.5
      }];
    }

    // Parse result table
    const rows = await page.$$('table tr');
    
    for (const row of rows.slice(1)) { // Skip header
      try {
        const cells = await row.$$('td');
        if (cells.length >= 4) {
          const serialNumber = await cells[0].textContent() || '';
          const wordMark = await cells[1].textContent() || '';
          const owner = await cells[2].textContent() || '';
          const status = await cells[3].textContent() || '';

          if (serialNumber && wordMark) {
            matches.push({
              serialNumber: serialNumber.trim(),
              wordMark: wordMark.trim(),
              owner: owner.trim(),
              status: status.toLowerCase().includes('dead') ? 'dead' : 'live',
              goodsServices: '',
              similarity: 1.0 // Exact match from TESS
            });
          }
        }
      } catch (e) {
        // Skip malformed rows
        continue;
      }
    }

    return matches.slice(0, 10); // Limit to top 10
  }

  /**
   * Check against blocked terms cache
   */
  private checkBlockedTerms(term: string): BlockedTerm | null {
    // Direct match
    if (this.blockedTermsCache.has(term)) {
      return this.blockedTermsCache.get(term)!;
    }

    // Partial match (term contains blocked word)
    for (const [blockedTerm, blockedInfo] of this.blockedTermsCache) {
      if (term.includes(blockedTerm) || blockedTerm.includes(term)) {
        return blockedInfo;
      }
    }

    return null;
  }

  /**
   * Analyze TESS results to determine risk level
   */
  private analyzeRiskLevel(matches: TrademarkMatch[]): 'clear' | 'caution' | 'blocked' {
    if (matches.length === 0) {
      return 'clear';
    }

    // Check for live registrations
    const liveMatches = matches.filter(m => m.status === 'live');
    
    if (liveMatches.length === 0) {
      // Only dead trademarks, proceed with caution
      return 'caution';
    }

    // Check for exact high-similarity matches
    const highSimilarityLive = liveMatches.filter(m => m.similarity >= 0.9);
    
    if (highSimilarityLive.length > 0) {
      return 'blocked';
    }

    // Some live matches but not exact
    return 'caution';
  }

  /**
   * Extract terms to check from product
   */
  private extractTermsToCheck(product: {
    title: string;
    description: string;
    keywords: string[];
    niche: string;
  }): string[] {
    const terms = new Set<string>();

    // Add title words (2+ characters)
    const titleWords = product.title
      .replace(/[^a-zA-Z0-9\s]/g, '')
      .split(/\s+/)
      .filter(w => w.length >= 2);
    
    titleWords.forEach(w => terms.add(w.toLowerCase()));

    // Add title phrases (2-3 word combinations)
    for (let i = 0; i < titleWords.length - 1; i++) {
      terms.add(`${titleWords[i]} ${titleWords[i + 1]}`.toLowerCase());
      if (i < titleWords.length - 2) {
        terms.add(`${titleWords[i]} ${titleWords[i + 1]} ${titleWords[i + 2]}`.toLowerCase());
      }
    }

    // Add keywords
    product.keywords.forEach(k => terms.add(k.toLowerCase()));

    // Remove common words that don't need checking
    const commonWords = new Set([
      'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
      'of', 'with', 'by', 'from', 'as', 'is', 'are', 'was', 'were', 'be',
      'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
      'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these',
      'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'what', 'which',
      'who', 'when', 'where', 'why', 'how', 'all', 'each', 'every', 'both',
      'few', 'more', 'most', 'other', 'some', 'such', 'no', 'not', 'only',
      'own', 'same', 'so', 'than', 'too', 'very', 'just', 'also', 'now'
    ]);

    return Array.from(terms).filter(t => !commonWords.has(t) && t.length >= 3);
  }

  /**
   * Load blocked terms from database into cache
   */
  private async loadBlockedTermsCache(): Promise<void> {
    if (this.cacheLoaded) return;

    const { data, error } = await this.supabase
      .from('blocked_terms')
      .select('term, reason, category');

    if (error) {
      console.error('Failed to load blocked terms:', error);
      return;
    }

    for (const item of data || []) {
      this.blockedTermsCache.set(item.term.toLowerCase(), {
        term: item.term,
        reason: item.reason,
        category: item.category
      });
    }

    this.cacheLoaded = true;
  }

  /**
   * Get cached TESS result
   */
  private async getCachedResult(term: string): Promise<TrademarkCheckResult | null> {
    const { data, error } = await this.supabase
      .from('trademark_checks')
      .select('*')
      .eq('search_term', term)
      .eq('search_type', 'word_mark')
      .gt('expires_at', new Date().toISOString())
      .single();

    if (error || !data) return null;

    return {
      searchTerm: data.search_term,
      riskLevel: data.risk_level,
      matchingMarks: data.matching_marks || [],
      checkedAt: new Date(data.checked_at),
      fromCache: true
    };
  }

  /**
   * Cache TESS result
   */
  private async cacheResult(term: string, result: TrademarkCheckResult): Promise<void> {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30); // Cache for 30 days

    await this.supabase
      .from('trademark_checks')
      .upsert({
        search_term: term,
        search_type: 'word_mark',
        tess_results: result.matchingMarks,
        risk_level: result.riskLevel,
        matching_marks: result.matchingMarks,
        checked_at: result.checkedAt.toISOString(),
        expires_at: expiresAt.toISOString()
      }, {
        onConflict: 'search_term,search_type'
      });
  }

  /**
   * Rate limit delay for TESS queries
   */
  private async rateLimitDelay(): Promise<void> {
    const delayMs = (60 / this.tessRateLimit) * 1000;
    await new Promise(resolve => setTimeout(resolve, delayMs));
  }

  /**
   * Save screening result
   */
  private async saveScreeningResult(
    productId: string, 
    result: Omit<ProductScreeningResult, 'productId'>
  ): Promise<void> {
    await this.supabase
      .from('products')
      .update({
        trademark_status: result.overallRisk,
        updated_at: new Date().toISOString()
      })
      .eq('id', productId);
  }

  /**
   * Add a new blocked term
   */
  async addBlockedTerm(
    term: string, 
    reason: string, 
    category: 'trademark' | 'copyright' | 'celebrity' | 'brand' | 'offensive'
  ): Promise<void> {
    await this.supabase
      .from('blocked_terms')
      .insert({
        term: term.toLowerCase(),
        reason,
        category
      });

    // Update cache
    this.blockedTermsCache.set(term.toLowerCase(), { term, reason, category });
  }

  /**
   * Cleanup browser on shutdown
   */
  async cleanup(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }
}

// =============================================================================
// QUICK CHECK FUNCTION (for n8n Code nodes)
// =============================================================================

export async function quickTrademarkCheck(
  term: string,
  supabaseUrl: string,
  supabaseKey: string
): Promise<{ blocked: boolean; reason?: string }> {
  const screener = new TrademarkScreener(supabaseUrl, supabaseKey);
  
  try {
    const result = await screener.checkTerm(term);
    return {
      blocked: result.riskLevel === 'blocked',
      reason: result.riskLevel === 'blocked' 
        ? result.blockedReason || 'Trademark conflict detected'
        : undefined
    };
  } finally {
    await screener.cleanup();
  }
}

export default TrademarkScreener;
