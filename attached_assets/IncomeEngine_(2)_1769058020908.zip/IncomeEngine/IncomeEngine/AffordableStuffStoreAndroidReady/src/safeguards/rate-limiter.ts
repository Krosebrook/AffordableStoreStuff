/**
 * ============================================================================
 * SAFEGUARD #1: RATE LIMITER WITH ANTI-SUSPENSION CONTROLS
 * ============================================================================
 * 
 * Purpose: Prevent account suspensions by enforcing platform-specific rate limits
 * with randomized delays (jitter) to appear more human-like.
 * 
 * Features:
 * - Per-platform configurable limits (hourly, daily)
 * - Randomized jitter between requests
 * - Cooldown periods after each upload
 * - Suspension risk level awareness
 * - Human review flags for high-risk platforms
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// =============================================================================
// TYPES
// =============================================================================

interface PlatformConfig {
  platform: string;
  max_uploads_per_day: number;
  max_uploads_per_hour: number;
  cooldown_minutes: number;
  jitter_min_seconds: number;
  jitter_max_seconds: number;
  require_human_review: boolean;
  suspension_risk_level: 'low' | 'medium' | 'high' | 'critical';
}

interface RateLimitResult {
  allowed: boolean;
  reason: string;
  nextAllowedAt: Date | null;
  currentHourCount: number;
  currentDayCount: number;
  waitMs: number;
  requiresHumanReview: boolean;
}

interface UploadEvent {
  id: string;
  platform: string;
  product_id: string;
  upload_status: 'pending' | 'in_progress' | 'success' | 'failed' | 'rate_limited' | 'suspended';
  attempt_number: number;
  error_message?: string;
  started_at: Date;
  completed_at?: Date;
  next_allowed_upload_at?: Date;
}

// =============================================================================
// RATE LIMITER CLASS
// =============================================================================

export class RateLimiter {
  private supabase: SupabaseClient;
  private configCache: Map<string, PlatformConfig> = new Map();
  private cacheExpiry: number = 5 * 60 * 1000; // 5 minutes
  private lastCacheUpdate: number = 0;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * Check if an upload is allowed for a given platform
   * Returns wait time with jitter if not immediately allowed
   */
  async checkUploadAllowed(platform: string, productId: string): Promise<RateLimitResult> {
    // Get platform config (with caching)
    const config = await this.getPlatformConfig(platform);
    
    if (!config) {
      return {
        allowed: false,
        reason: `Platform "${platform}" not configured. Add it to platform_rate_limits table.`,
        nextAllowedAt: null,
        currentHourCount: 0,
        currentDayCount: 0,
        waitMs: 0,
        requiresHumanReview: true
      };
    }

    // Query current counts using database function
    const { data, error } = await this.supabase
      .rpc('check_upload_allowed', { p_platform: platform });

    if (error) {
      console.error('Error checking rate limit:', error);
      // Fail closed - don't allow if we can't check
      return {
        allowed: false,
        reason: `Database error: ${error.message}`,
        nextAllowedAt: null,
        currentHourCount: 0,
        currentDayCount: 0,
        waitMs: 0,
        requiresHumanReview: true
      };
    }

    const result = data[0];

    if (!result.allowed) {
      return {
        allowed: false,
        reason: result.reason,
        nextAllowedAt: result.next_allowed_at ? new Date(result.next_allowed_at) : null,
        currentHourCount: result.current_hour_count,
        currentDayCount: result.current_day_count,
        waitMs: this.calculateWaitMs(result.next_allowed_at),
        requiresHumanReview: config.require_human_review
      };
    }

    // Calculate jitter delay to appear more human-like
    const jitterMs = this.calculateJitter(config.jitter_min_seconds, config.jitter_max_seconds);

    return {
      allowed: true,
      reason: 'OK',
      nextAllowedAt: null,
      currentHourCount: result.current_hour_count,
      currentDayCount: result.current_day_count,
      waitMs: jitterMs,
      requiresHumanReview: config.require_human_review
    };
  }

  /**
   * Record an upload attempt (call before starting upload)
   */
  async recordUploadStart(platform: string, productId: string): Promise<UploadEvent> {
    const { data, error } = await this.supabase
      .from('upload_events')
      .insert({
        platform,
        product_id: productId,
        upload_status: 'in_progress',
        started_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to record upload start: ${error.message}`);
    }

    return data;
  }

  /**
   * Record upload completion (success or failure)
   */
  async recordUploadComplete(
    uploadEventId: string, 
    status: 'success' | 'failed' | 'rate_limited' | 'suspended',
    errorMessage?: string
  ): Promise<void> {
    const config = await this.getConfigForUploadEvent(uploadEventId);
    const cooldownMs = (config?.cooldown_minutes || 30) * 60 * 1000;
    const nextAllowedAt = new Date(Date.now() + cooldownMs);

    const { error } = await this.supabase
      .from('upload_events')
      .update({
        upload_status: status,
        completed_at: new Date().toISOString(),
        error_message: errorMessage,
        next_allowed_upload_at: nextAllowedAt.toISOString()
      })
      .eq('id', uploadEventId);

    if (error) {
      console.error('Failed to record upload completion:', error);
    }

    // If suspended, trigger alert
    if (status === 'suspended') {
      await this.triggerSuspensionAlert(uploadEventId, errorMessage);
    }
  }

  /**
   * Get the delay to wait before next upload (with jitter)
   */
  async getDelayBeforeUpload(platform: string): Promise<number> {
    const config = await this.getPlatformConfig(platform);
    if (!config) return 60000; // Default 1 minute

    // Get last upload time
    const { data } = await this.supabase
      .from('upload_events')
      .select('completed_at, next_allowed_upload_at')
      .eq('platform', platform)
      .order('started_at', { ascending: false })
      .limit(1)
      .single();

    if (data?.next_allowed_upload_at) {
      const nextAllowed = new Date(data.next_allowed_upload_at);
      const waitMs = Math.max(0, nextAllowed.getTime() - Date.now());
      
      // Add jitter
      const jitter = this.calculateJitter(config.jitter_min_seconds, config.jitter_max_seconds);
      return waitMs + jitter;
    }

    // No recent uploads, just add jitter
    return this.calculateJitter(config.jitter_min_seconds, config.jitter_max_seconds);
  }

  /**
   * Check if platform requires human review
   */
  async requiresHumanReview(platform: string): Promise<boolean> {
    const config = await this.getPlatformConfig(platform);
    return config?.require_human_review ?? true;
  }

  /**
   * Get suspension risk level for a platform
   */
  async getSuspensionRiskLevel(platform: string): Promise<string> {
    const config = await this.getPlatformConfig(platform);
    return config?.suspension_risk_level ?? 'high';
  }

  /**
   * Get daily upload stats for a platform
   */
  async getDailyStats(platform: string): Promise<{
    uploadsToday: number;
    successRate: number;
    remainingDaily: number;
  }> {
    const config = await this.getPlatformConfig(platform);
    const maxDaily = config?.max_uploads_per_day ?? 5;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data, error } = await this.supabase
      .from('upload_events')
      .select('upload_status')
      .eq('platform', platform)
      .gte('started_at', today.toISOString());

    if (error || !data) {
      return { uploadsToday: 0, successRate: 0, remainingDaily: maxDaily };
    }

    const total = data.length;
    const successful = data.filter(e => e.upload_status === 'success').length;

    return {
      uploadsToday: total,
      successRate: total > 0 ? successful / total : 0,
      remainingDaily: Math.max(0, maxDaily - total)
    };
  }

  // =============================================================================
  // PRIVATE METHODS
  // =============================================================================

  private async getPlatformConfig(platform: string): Promise<PlatformConfig | null> {
    // Check cache
    if (this.configCache.has(platform) && Date.now() - this.lastCacheUpdate < this.cacheExpiry) {
      return this.configCache.get(platform)!;
    }

    // Fetch from database
    const { data, error } = await this.supabase
      .from('platform_rate_limits')
      .select('*')
      .eq('platform', platform)
      .single();

    if (error || !data) {
      return null;
    }

    this.configCache.set(platform, data);
    this.lastCacheUpdate = Date.now();

    return data;
  }

  private async getConfigForUploadEvent(uploadEventId: string): Promise<PlatformConfig | null> {
    const { data } = await this.supabase
      .from('upload_events')
      .select('platform')
      .eq('id', uploadEventId)
      .single();

    if (data?.platform) {
      return this.getPlatformConfig(data.platform);
    }
    return null;
  }

  private calculateJitter(minSeconds: number, maxSeconds: number): number {
    // Add randomness to delays to appear more human-like
    const minMs = minSeconds * 1000;
    const maxMs = maxSeconds * 1000;
    return Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
  }

  private calculateWaitMs(nextAllowedAt: string | null): number {
    if (!nextAllowedAt) return 0;
    const nextTime = new Date(nextAllowedAt).getTime();
    return Math.max(0, nextTime - Date.now());
  }

  private async triggerSuspensionAlert(uploadEventId: string, errorMessage?: string): Promise<void> {
    // Get upload details
    const { data } = await this.supabase
      .from('upload_events')
      .select('platform, product_id')
      .eq('id', uploadEventId)
      .single();

    if (!data) return;

    // This would integrate with your notification system
    console.error(`🚨 SUSPENSION ALERT: Platform ${data.platform} may have suspended account!`);
    console.error(`Upload Event: ${uploadEventId}`);
    console.error(`Error: ${errorMessage}`);

    // In production, send to Slack/Discord/Email
    // await notificationService.sendAlert({
    //   type: 'suspension',
    //   platform: data.platform,
    //   message: errorMessage,
    //   severity: 'critical'
    // });
  }
}

// =============================================================================
// USAGE EXAMPLE
// =============================================================================

export async function exampleUsage() {
  const rateLimiter = new RateLimiter(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_KEY!
  );

  const platform = 'amazon_kdp';
  const productId = 'product-uuid-here';

  // Step 1: Check if upload is allowed
  const check = await rateLimiter.checkUploadAllowed(platform, productId);

  if (!check.allowed) {
    console.log(`❌ Upload not allowed: ${check.reason}`);
    console.log(`⏰ Try again at: ${check.nextAllowedAt}`);
    return;
  }

  // Step 2: Wait for jitter delay (appear human-like)
  if (check.waitMs > 0) {
    console.log(`⏳ Waiting ${check.waitMs}ms before upload (jitter delay)...`);
    await new Promise(resolve => setTimeout(resolve, check.waitMs));
  }

  // Step 3: Check if human review required
  if (check.requiresHumanReview) {
    console.log(`👤 Human review required for ${platform} before publishing`);
    // Route to approval queue instead of direct upload
    return;
  }

  // Step 4: Record upload start
  const uploadEvent = await rateLimiter.recordUploadStart(platform, productId);

  try {
    // Step 5: Perform actual upload
    // await uploadToPlatform(platform, productId);

    // Step 6: Record success
    await rateLimiter.recordUploadComplete(uploadEvent.id, 'success');
    console.log(`✅ Upload successful!`);

  } catch (error) {
    // Step 7: Record failure
    const errorMsg = error instanceof Error ? error.message : 'Unknown error';
    
    // Check if it looks like a suspension
    const isSuspension = errorMsg.toLowerCase().includes('suspended') ||
                        errorMsg.toLowerCase().includes('blocked') ||
                        errorMsg.toLowerCase().includes('banned');
    
    await rateLimiter.recordUploadComplete(
      uploadEvent.id, 
      isSuspension ? 'suspended' : 'failed',
      errorMsg
    );

    console.error(`❌ Upload failed: ${errorMsg}`);
  }
}

export default RateLimiter;
