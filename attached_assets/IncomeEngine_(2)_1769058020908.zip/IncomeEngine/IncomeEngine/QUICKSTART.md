# Income Engine Quickstart Guide

## 🚀 Get Running in 30 Minutes

This is the complete passive income automation system. Follow these steps exactly.

---

## Step 1: Infrastructure (10 min)

### Option A: VPS (Recommended - $5-10/month)
```bash
# On fresh Ubuntu 22.04 VPS (Hetzner, DigitalOcean, etc.)
chmod +x setup-n8n.sh
sudo ./setup-n8n.sh
```

### Option B: Local Docker
```bash
docker run -d \
  --name n8n \
  -p 5678:5678 \
  -v n8n_data:/home/node/.n8n \
  n8nio/n8n
```

---

## Step 2: Database (5 min)

1. Create free Supabase project: https://supabase.com
2. Go to SQL Editor → New Query
3. Paste contents of `schema-extensions.sql`
4. Click "Run"
5. Save your Project URL and anon key

---

## Step 3: API Keys (10 min)

Get these credentials:

| Service | URL | Key Name |
|---------|-----|----------|
| Replicate | https://replicate.com/account/api-tokens | `REPLICATE_API_TOKEN` |
| OpenAI | https://platform.openai.com/api-keys | `OPENAI_API_KEY` |
| Printify | https://printify.com/app/account/api | `PRINTIFY_API_KEY` |
| Gumroad | https://gumroad.com/settings/advanced | `GUMROAD_ACCESS_TOKEN` |

Etsy requires OAuth app:
1. https://www.etsy.com/developers/your-apps
2. Create app, get Client ID + Secret

---

## Step 4: Configure n8n (5 min)

1. Access n8n at `http://your-ip:5678`
2. Go to Settings → Credentials
3. Add credentials:
   - **HTTP Header Auth** (for Replicate): Header `Authorization`, Value `Token YOUR_TOKEN`
   - **HTTP Header Auth** (for OpenAI): Header `Authorization`, Value `Bearer YOUR_KEY`
   - **HTTP Header Auth** (for Printify): Header `Authorization`, Value `Bearer YOUR_KEY`
   - **Supabase**: URL + Service Role Key

4. Set environment variables in n8n:
   - `PRINTIFY_SHOP_ID`
   - `ETSY_SHOP_ID`
   - `N8N_WEBHOOK_URL` (your n8n URL)

---

## Step 5: Import Workflows (5 min)

1. In n8n, go to Workflows → Import
2. Import each JSON file in order:
   - `01-niche-scanner.json`
   - `02-product-generator.json`
   - `03-printify-publisher.json`
   - `04-etsy-publisher.json`
   - `05-gumroad-publisher.json`
   - `06-revenue-aggregator.json`
   - `07-daily-report.json`
   - `08-batch-processor.json`
3. Update credential references in each workflow
4. Activate workflows 01, 03, 04, 05, 06, 07

---

## Step 6: First Test (5 min)

Test product generation:
```bash
curl -X POST "http://your-n8n:5678/webhook/generate-products" \
  -H "Content-Type: application/json" \
  -d '{
    "niche": "dog-breed-specific",
    "subNiche": "golden-retriever",
    "batchSize": 1,
    "productType": "pod_tshirt"
  }'
```

Check Supabase → `generated_products` table for your product!

---

## Step 7: MCP Server (Optional - 2 min)

If using Claude Code or other MCP-compatible AI assistants:

```bash
cd mcp-server
npm install
node index.js --test  # Verify setup
```

Add to your `.claude/mcp-servers.json`:
```json
{
  "servers": {
    "income-engine": {
      "command": "node",
      "args": ["mcp-server/index.js"]
    }
  }
}
```

Now Claude can manage platforms, products, and workflows directly.

---

## 📊 Expected Costs

| Component | Monthly Cost |
|-----------|-------------|
| VPS (n8n) | $5-10 |
| AI Generation | $15-30 |
| Supabase | $0 (free tier) |
| Printify | $0 (pay per order) |
| Etsy | $5-15 (listing fees) |
| Gumroad | $0 (% per sale) |
| **TOTAL** | **$25-55** |

---

## 🎯 Revenue Targets

| Month | Products | Revenue Target |
|-------|----------|----------------|
| 1 | 100 | $50-150 |
| 2 | 300 | $150-400 |
| 3 | 500 | $300-700 |
| 6 | 1000+ | $800-1500 |

---

## 📁 Files in This Package

```
income-engine-quickstart/
├── 01-niche-scanner.json       # Daily niche discovery
├── 02-product-generator.json   # AI product creation
├── 03-printify-publisher.json  # POD publishing
├── 04-etsy-publisher.json      # Etsy listings
├── 05-gumroad-publisher.json   # Digital products
├── 06-revenue-aggregator.json  # Sales tracking
├── 07-daily-report.json        # Daily metrics
├── 08-batch-processor.json     # Bulk generation
├── schema-extensions.sql       # Database schema
├── setup-n8n.sh               # VPS setup script
└── .env.example               # Environment template
```

---

## ⚡ Quick Commands

```bash
# Generate 10 products
curl -X POST "http://n8n:5678/webhook/batch-generate" \
  -d '{"niche":"mom-life-humor","totalProducts":10}'

# Check revenue
curl -X POST "http://n8n:5678/webhook/sync-revenue"

# Run niche scan
curl -X POST "http://n8n:5678/webhook/niche-scan"
```

---

## 🆘 Troubleshooting

| Problem | Solution |
|---------|----------|
| "Rate limit" | Wait 60s, reduce batch size |
| "Budget exhausted" | Wait until tomorrow or increase limit |
| "Trademark violation" | Remove flagged keywords |
| Products not publishing | Check platform credentials |
| Workflow errors | Check n8n execution logs |

---

## 📞 Support Resources

- **n8n Docs**: https://docs.n8n.io
- **Printify API**: https://developers.printify.com
- **Supabase Docs**: https://supabase.com/docs
- **MCP Integration**: See `docs/ai-tools/MCP-INTEGRATION.md`

---

**Full Documentation**: See `DEPLOYMENT.md`, `RUNBOOK.md`, and `docs/` folder.

---

*Income Engine v2.0.0 | Target: $1,000/month passive income*
