/**
 * ============================================================================
 * MIDDLEWARE INDEX
 * Re-exports all middleware for convenient importing
 * ============================================================================
 *
 * Usage:
 * ```typescript
 * import { errorHandler, validateRequest, createEndpointRateLimiter } from './middleware';
 * ```
 */

// Error handling exports
export {
  errorHandler,
  notFoundHandler,
  asyncHandler,
  validateBody,
  AppError,
  ValidationError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  RateLimitError,
  ServiceUnavailableError,
  ExternalServiceError,
  type ErrorCode,
  type ErrorDetails,
  type ErrorResponse,
} from './error-handler.js';

// Response optimization exports
export {
  responseTimeMiddleware,
  etagMiddleware,
  createEtagMiddleware,
  createEndpointRateLimiter,
  createSlidingWindowRateLimiter,
  validateRequest,
  compressionHints,
  conditionalGetMiddleware,
  transformResponse,
  wrapApiResponse,
  securityHeaders,
  limitRequestSize,
  apiVersionMiddleware,
  type RateLimitOptions,
  type RequestValidationSchema,
} from './response-optimizer.js';
