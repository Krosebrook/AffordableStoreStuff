/**
 * ============================================================================
 * API RESPONSE OPTIMIZATION MIDDLEWARE
 * Compression, ETags, rate limiting, and request validation
 * ============================================================================
 *
 * Features:
 * - Response compression (gzip/deflate)
 * - ETag generation for HTTP caching
 * - Per-endpoint rate limiting
 * - Request body validation with Zod
 * - Response time headers
 * - CORS optimization
 *
 * Usage:
 * ```typescript
 * import {
 *   etagMiddleware,
 *   responseTimeMiddleware,
 *   createEndpointRateLimiter,
 *   validateRequest,
 * } from './middleware/response-optimizer';
 *
 * // Add to Express app
 * app.use(responseTimeMiddleware);
 * app.use(etagMiddleware);
 *
 * // Per-endpoint rate limiting
 * app.post('/api/products', createEndpointRateLimiter({ max: 10, windowMs: 60000 }), handler);
 *
 * // Request validation
 * const schema = { body: z.object({ name: z.string() }) };
 * app.post('/api/items', validateRequest(schema), handler);
 * ```
 */

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { z, ZodType } from 'zod';
import { logger } from '../services/logger.js';
import { ValidationError } from './error-handler.js';

// =============================================================================
// TYPES
// =============================================================================

export interface RateLimitOptions {
  windowMs: number; // Time window in milliseconds
  max: number; // Max requests per window
  keyGenerator?: (req: Request) => string;
  message?: string;
  skipFailedRequests?: boolean;
  skipSuccessfulRequests?: boolean;
}

export interface RequestValidationSchema {
  body?: ZodType;
  query?: ZodType;
  params?: ZodType;
}

// =============================================================================
// RESPONSE TIME HEADER
// =============================================================================

/**
 * Adds X-Response-Time header to all responses
 * Helps identify slow endpoints
 */
export function responseTimeMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const start = process.hrtime.bigint();

  res.on('finish', () => {
    const end = process.hrtime.bigint();
    const durationMs = Number(end - start) / 1_000_000;
    res.setHeader('X-Response-Time', `${durationMs.toFixed(2)}ms`);
  });

  next();
}

// =============================================================================
// ETAG MIDDLEWARE
// =============================================================================

/**
 * Generates and validates ETags for response caching
 * Supports both strong and weak ETags
 */
export function etagMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Only apply to GET requests
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    next();
    return;
  }

  // Store original json function
  const originalJson = res.json.bind(res);

  // Override json to add ETag
  res.json = function (body: unknown): Response {
    // Generate ETag from response body
    const bodyString = JSON.stringify(body);
    const hash = crypto.createHash('md5').update(bodyString).digest('hex');
    const etag = `W/"${hash}"`;

    // Check If-None-Match header
    const ifNoneMatch = req.headers['if-none-match'];
    if (ifNoneMatch && ifNoneMatch === etag) {
      res.status(304);
      return res.end();
    }

    // Set ETag header
    res.setHeader('ETag', etag);

    // Set Cache-Control if not already set
    if (!res.getHeader('Cache-Control')) {
      // Default: cache for 30 seconds, must revalidate
      res.setHeader('Cache-Control', 'private, max-age=30, must-revalidate');
    }

    return originalJson(body);
  };

  next();
}

/**
 * Create ETag middleware with custom options
 */
export function createEtagMiddleware(options: {
  weak?: boolean;
  cacheControl?: string;
}) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      next();
      return;
    }

    const originalJson = res.json.bind(res);

    res.json = function (body: unknown): Response {
      const bodyString = JSON.stringify(body);
      const hash = crypto.createHash('md5').update(bodyString).digest('hex');
      const etag = options.weak !== false ? `W/"${hash}"` : `"${hash}"`;

      const ifNoneMatch = req.headers['if-none-match'];
      if (ifNoneMatch && ifNoneMatch === etag) {
        res.status(304);
        return res.end();
      }

      res.setHeader('ETag', etag);
      if (options.cacheControl) {
        res.setHeader('Cache-Control', options.cacheControl);
      }

      return originalJson(body);
    };

    next();
  };
}

// =============================================================================
// PER-ENDPOINT RATE LIMITING
// =============================================================================

const rateLimitStore = new Map<string, Map<string, { count: number; resetTime: number }>>();

/**
 * Create a rate limiter for a specific endpoint
 * More granular control than global rate limiting
 */
export function createEndpointRateLimiter(options: RateLimitOptions) {
  const {
    windowMs,
    max,
    keyGenerator = (req) => req.ip || 'anonymous',
    message = 'Too many requests to this endpoint',
    skipFailedRequests = false,
    skipSuccessfulRequests = false,
  } = options;

  const storeKey = `${windowMs}:${max}`;

  if (!rateLimitStore.has(storeKey)) {
    rateLimitStore.set(storeKey, new Map());
  }

  const store = rateLimitStore.get(storeKey)!;

  // Cleanup old entries periodically
  const cleanupInterval = setInterval(() => {
    const now = Date.now();
    for (const [key, value] of store.entries()) {
      if (now > value.resetTime) {
        store.delete(key);
      }
    }
  }, windowMs);

  // Don't prevent process from exiting (Node.js only)
  if (typeof cleanupInterval === 'object' && 'unref' in cleanupInterval) {
    (cleanupInterval as NodeJS.Timeout).unref();
  }

  return (req: Request, res: Response, next: NextFunction): void => {
    const key = keyGenerator(req);
    const now = Date.now();

    let record = store.get(key);

    // Initialize or reset if window expired
    if (!record || now > record.resetTime) {
      record = { count: 0, resetTime: now + windowMs };
      store.set(key, record);
    }

    // Check limit
    if (record.count >= max) {
      const retryAfter = Math.ceil((record.resetTime - now) / 1000);

      res.setHeader('Retry-After', retryAfter);
      res.setHeader('X-RateLimit-Limit', max);
      res.setHeader('X-RateLimit-Remaining', 0);
      res.setHeader('X-RateLimit-Reset', new Date(record.resetTime).toISOString());

      logger.warn('Rate limit exceeded', {
        key,
        path: req.path,
        limit: max,
        windowMs,
      });

      res.status(429).json({
        success: false,
        error: {
          message,
          code: 'RATE_LIMITED',
          retryAfter,
        },
      });
      return;
    }

    // Set headers
    res.setHeader('X-RateLimit-Limit', max);
    res.setHeader('X-RateLimit-Remaining', max - record.count - 1);
    res.setHeader('X-RateLimit-Reset', new Date(record.resetTime).toISOString());

    // Increment on response finish based on options
    res.on('finish', () => {
      const currentRecord = store.get(key);
      if (!currentRecord) return;

      const isSuccess = res.statusCode < 400;
      const shouldSkip =
        (skipFailedRequests && !isSuccess) ||
        (skipSuccessfulRequests && isSuccess);

      if (!shouldSkip) {
        currentRecord.count++;
      }
    });

    next();
  };
}

/**
 * Sliding window rate limiter (more accurate but slightly more expensive)
 */
export function createSlidingWindowRateLimiter(options: RateLimitOptions) {
  const {
    windowMs,
    max,
    keyGenerator = (req) => req.ip || 'anonymous',
    message = 'Too many requests',
  } = options;

  const requests = new Map<string, number[]>();

  return (req: Request, res: Response, next: NextFunction): void => {
    const key = keyGenerator(req);
    const now = Date.now();
    const windowStart = now - windowMs;

    // Get or initialize request timestamps
    let timestamps = requests.get(key) || [];

    // Remove old timestamps outside the window
    timestamps = timestamps.filter((t) => t > windowStart);

    if (timestamps.length >= max) {
      const oldestInWindow = timestamps[0];
      const retryAfter = Math.ceil((oldestInWindow + windowMs - now) / 1000);

      res.setHeader('Retry-After', retryAfter);
      res.status(429).json({
        success: false,
        error: {
          message,
          code: 'RATE_LIMITED',
          retryAfter,
        },
      });
      return;
    }

    // Add current request
    timestamps.push(now);
    requests.set(key, timestamps);

    // Cleanup periodically
    if (requests.size > 10000) {
      for (const [k, v] of requests.entries()) {
        if (v.length === 0 || v[v.length - 1] < windowStart) {
          requests.delete(k);
        }
      }
    }

    next();
  };
}

// =============================================================================
// REQUEST VALIDATION
// =============================================================================

/**
 * Validate request body, query, and params using Zod schemas
 */
export function validateRequest(schema: RequestValidationSchema) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const errors: { location: string; issues: z.ZodIssue[] }[] = [];

    // Validate body
    if (schema.body) {
      const result = schema.body.safeParse(req.body);
      if (!result.success) {
        errors.push({ location: 'body', issues: result.error.issues });
      } else {
        req.body = result.data;
      }
    }

    // Validate query
    if (schema.query) {
      const result = schema.query.safeParse(req.query);
      if (!result.success) {
        errors.push({ location: 'query', issues: result.error.issues });
      } else {
        req.query = result.data as typeof req.query;
      }
    }

    // Validate params
    if (schema.params) {
      const result = schema.params.safeParse(req.params);
      if (!result.success) {
        errors.push({ location: 'params', issues: result.error.issues });
      } else {
        req.params = result.data as typeof req.params;
      }
    }

    if (errors.length > 0) {
      const validationError = new ValidationError('Request validation failed', {
        errors: errors.map((e) => ({
          location: e.location,
          issues: e.issues.map((i) => ({
            path: i.path.join('.'),
            message: i.message,
            code: i.code,
          })),
        })),
      });
      next(validationError);
      return;
    }

    next();
  };
}

// =============================================================================
// RESPONSE COMPRESSION HINTS
// =============================================================================

/**
 * Add compression hints for specific content types
 * Works with compression middleware
 */
export function compressionHints(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Skip for already compressed content
  const contentEncoding = res.getHeader('Content-Encoding');
  if (contentEncoding) {
    next();
    return;
  }

  // Add Vary header for proper caching
  res.vary('Accept-Encoding');

  // Hint minimum size for compression (1KB)
  res.setHeader('X-Compression-Threshold', '1024');

  next();
}

// =============================================================================
// CONDITIONAL REQUEST HANDLING
// =============================================================================

/**
 * Handle If-Modified-Since header for conditional requests
 */
export function conditionalGetMiddleware(
  getLastModified: (req: Request) => Date | null
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      next();
      return;
    }

    const lastModified = getLastModified(req);
    if (!lastModified) {
      next();
      return;
    }

    // Set Last-Modified header
    res.setHeader('Last-Modified', lastModified.toUTCString());

    // Check If-Modified-Since
    const ifModifiedSince = req.headers['if-modified-since'];
    if (ifModifiedSince) {
      const clientDate = new Date(ifModifiedSince);
      if (clientDate >= lastModified) {
        res.status(304).end();
        return;
      }
    }

    next();
  };
}

// =============================================================================
// RESPONSE TRANSFORMATION
// =============================================================================

/**
 * Transform JSON responses (e.g., add metadata, filter fields)
 */
export function transformResponse(
  transformer: (body: unknown, req: Request, res: Response) => unknown
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const originalJson = res.json.bind(res);

    res.json = function (body: unknown): Response {
      const transformed = transformer(body, req, res);
      return originalJson(transformed);
    };

    next();
  };
}

/**
 * Add standard wrapper to all API responses
 */
export function wrapApiResponse(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Only wrap API routes
  if (!req.path.startsWith('/api/')) {
    next();
    return;
  }

  const originalJson = res.json.bind(res);

  res.json = function (body: unknown): Response {
    // If already wrapped or error, don't wrap again
    if (
      typeof body === 'object' &&
      body !== null &&
      ('success' in body || 'error' in body)
    ) {
      return originalJson(body);
    }

    return originalJson({
      success: true,
      data: body,
      timestamp: new Date().toISOString(),
    });
  };

  next();
}

// =============================================================================
// SECURITY HEADERS
// =============================================================================

/**
 * Add additional security headers beyond Helmet defaults
 */
export function securityHeaders(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Prevent caching of sensitive data
  if (req.path.includes('/auth/') || req.path.includes('/user/')) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }

  // Additional security headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  res.setHeader('X-Download-Options', 'noopen');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');

  next();
}

// =============================================================================
// REQUEST SIZE LIMITS
// =============================================================================

/**
 * Limit request body size for specific routes
 */
export function limitRequestSize(maxBytes: number) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const contentLength = parseInt(req.headers['content-length'] || '0', 10);

    if (contentLength > maxBytes) {
      res.status(413).json({
        success: false,
        error: {
          message: 'Request entity too large',
          code: 'PAYLOAD_TOO_LARGE',
          maxSize: maxBytes,
          actualSize: contentLength,
        },
      });
      return;
    }

    next();
  };
}

// =============================================================================
// API VERSION HEADER
// =============================================================================

/**
 * Add API version header to responses
 */
export function apiVersionMiddleware(version: string) {
  return (_req: Request, res: Response, next: NextFunction): void => {
    res.setHeader('X-API-Version', version);
    next();
  };
}

// =============================================================================
// EXPORTS
// =============================================================================

export default {
  responseTimeMiddleware,
  etagMiddleware,
  createEtagMiddleware,
  createEndpointRateLimiter,
  createSlidingWindowRateLimiter,
  validateRequest,
  compressionHints,
  conditionalGetMiddleware,
  transformResponse,
  wrapApiResponse,
  securityHeaders,
  limitRequestSize,
  apiVersionMiddleware,
};
