/**
 * ============================================================================
 * CENTRALIZED ERROR HANDLING MIDDLEWARE
 * Production-grade error handling with categorization and monitoring
 * ============================================================================
 *
 * Features:
 * - Centralized error handling for all routes
 * - Error categorization (validation, authentication, etc.)
 * - Structured error responses
 * - Error aggregation for monitoring
 * - Development vs production error details
 *
 * Usage:
 * ```typescript
 * import { errorHandler, notFoundHandler, AppError } from './middleware/error-handler';
 *
 * // At the end of your route definitions:
 * app.use(notFoundHandler);
 * app.use(errorHandler);
 *
 * // Throwing typed errors in routes:
 * throw new AppError('Resource not found', 404, 'NOT_FOUND');
 * throw new ValidationError('Invalid email format', { field: 'email' });
 * ```
 */

import { Request, Response, NextFunction } from 'express';
import { logger, logError, type RequestWithLogger } from '../services/logger.js';
import { errorMonitor } from '../services/monitoring.js';

// =============================================================================
// ERROR TYPES
// =============================================================================

export type ErrorCode =
  | 'VALIDATION_ERROR'
  | 'AUTHENTICATION_ERROR'
  | 'AUTHORIZATION_ERROR'
  | 'NOT_FOUND'
  | 'RATE_LIMITED'
  | 'CONFLICT'
  | 'SERVICE_UNAVAILABLE'
  | 'EXTERNAL_SERVICE_ERROR'
  | 'DATABASE_ERROR'
  | 'INTERNAL_ERROR'
  | 'BAD_REQUEST';

export interface ErrorDetails {
  field?: string;
  value?: unknown;
  constraint?: string;
  [key: string]: unknown;
}

/**
 * Custom application error with code and metadata
 */
export class AppError extends Error {
  public readonly statusCode: number;
  public readonly code: ErrorCode;
  public readonly details?: ErrorDetails;
  public readonly isOperational: boolean;
  public readonly timestamp: Date;

  constructor(
    message: string,
    statusCode: number = 500,
    code: ErrorCode = 'INTERNAL_ERROR',
    details?: ErrorDetails,
    isOperational: boolean = true
  ) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.isOperational = isOperational;
    this.timestamp = new Date();

    // Maintains proper stack trace for where error was thrown (V8 engines only)
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}

/**
 * Validation error for input validation failures
 */
export class ValidationError extends AppError {
  constructor(message: string, details?: ErrorDetails) {
    super(message, 400, 'VALIDATION_ERROR', details);
    this.name = 'ValidationError';
  }
}

/**
 * Authentication error for auth failures
 */
export class AuthenticationError extends AppError {
  constructor(message: string = 'Authentication required') {
    super(message, 401, 'AUTHENTICATION_ERROR');
    this.name = 'AuthenticationError';
  }
}

/**
 * Authorization error for permission failures
 */
export class AuthorizationError extends AppError {
  constructor(message: string = 'Permission denied') {
    super(message, 403, 'AUTHORIZATION_ERROR');
    this.name = 'AuthorizationError';
  }
}

/**
 * Not found error for missing resources
 */
export class NotFoundError extends AppError {
  constructor(resource: string = 'Resource') {
    super(`${resource} not found`, 404, 'NOT_FOUND');
    this.name = 'NotFoundError';
  }
}

/**
 * Rate limit error
 */
export class RateLimitError extends AppError {
  public readonly retryAfter: number;

  constructor(retryAfter: number = 60) {
    super('Too many requests', 429, 'RATE_LIMITED', { retryAfter });
    this.name = 'RateLimitError';
    this.retryAfter = retryAfter;
  }
}

/**
 * Service unavailable error
 */
export class ServiceUnavailableError extends AppError {
  constructor(service: string = 'Service') {
    super(`${service} is temporarily unavailable`, 503, 'SERVICE_UNAVAILABLE');
    this.name = 'ServiceUnavailableError';
  }
}

/**
 * External service error (for API calls to third parties)
 */
export class ExternalServiceError extends AppError {
  constructor(service: string, originalError?: Error) {
    super(
      `External service error: ${service}`,
      502,
      'EXTERNAL_SERVICE_ERROR',
      { service, originalMessage: originalError?.message }
    );
    this.name = 'ExternalServiceError';
  }
}

// =============================================================================
// ERROR RESPONSE FORMAT
// =============================================================================

export interface ErrorResponse {
  success: false;
  error: {
    message: string;
    code: ErrorCode;
    statusCode: number;
    details?: ErrorDetails;
    timestamp: string;
    requestId?: string;
    // Stack trace only in development
    stack?: string;
  };
}

/**
 * Formats an error into a consistent API response
 */
function formatErrorResponse(
  error: AppError,
  requestId?: string,
  includeStack: boolean = false
): ErrorResponse {
  return {
    success: false,
    error: {
      message: error.message,
      code: error.code,
      statusCode: error.statusCode,
      details: error.details,
      timestamp: error.timestamp.toISOString(),
      requestId,
      ...(includeStack && error.stack ? { stack: error.stack } : {}),
    },
  };
}

// =============================================================================
// ERROR CATEGORIZATION
// =============================================================================

/**
 * Converts unknown errors to AppError
 */
function normalizeError(error: unknown): AppError {
  // Already an AppError
  if (error instanceof AppError) {
    return error;
  }

  // Standard Error
  if (error instanceof Error) {
    // Check for common error types
    const message = error.message.toLowerCase();

    // Zod validation errors
    if (error.name === 'ZodError') {
      return new ValidationError('Validation failed', {
        issues: (error as Error & { issues?: unknown[] }).issues,
      });
    }

    // JWT errors
    if (message.includes('jwt') || message.includes('token')) {
      return new AuthenticationError(error.message);
    }

    // Database errors
    if (
      message.includes('database') ||
      message.includes('sql') ||
      message.includes('supabase')
    ) {
      return new AppError(
        'Database operation failed',
        500,
        'DATABASE_ERROR',
        undefined,
        true
      );
    }

    // Network errors
    if (
      message.includes('econnrefused') ||
      message.includes('timeout') ||
      message.includes('network')
    ) {
      return new ServiceUnavailableError('External service');
    }

    // Default: wrap as internal error
    const appError = new AppError(
      error.message,
      500,
      'INTERNAL_ERROR',
      undefined,
      false
    );
    appError.stack = error.stack;
    return appError;
  }

  // Unknown error type
  return new AppError(
    'An unexpected error occurred',
    500,
    'INTERNAL_ERROR',
    { originalError: String(error) },
    false
  );
}

// =============================================================================
// MIDDLEWARE
// =============================================================================

const isProduction = process.env.NODE_ENV === 'production';

/**
 * 404 Not Found handler
 * Place this after all route definitions
 */
export function notFoundHandler(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const error = new NotFoundError(`Route ${req.method} ${req.path}`);
  next(error);
}

/**
 * Global error handling middleware
 * Place this last in your middleware chain
 */
export function errorHandler(
  err: unknown,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const request = req as RequestWithLogger;
  const requestId = request.requestId;
  const reqLogger = request.logger || logger;

  // Normalize error to AppError
  const error = normalizeError(err);

  // Log the error
  logError(error, 'Request error', { requestId }, reqLogger);

  // Track error in monitoring
  errorMonitor.trackError(error, {
    path: req.path,
    method: req.method,
    requestId,
    statusCode: error.statusCode,
  });

  // Set rate limit header if applicable
  if (error instanceof RateLimitError) {
    res.setHeader('Retry-After', error.retryAfter);
  }

  // Send error response
  const response = formatErrorResponse(
    error,
    requestId,
    !isProduction
  );

  res.status(error.statusCode).json(response);

  // For non-operational errors in production, consider alerting
  if (!error.isOperational && isProduction) {
    // In production, non-operational errors are unexpected
    // You might want to alert on-call, trigger circuit breaker, etc.
    logger.error('Non-operational error occurred', {
      error: error.message,
      stack: error.stack,
      requestId,
    });
  }
}

/**
 * Async route handler wrapper
 * Catches async errors and passes them to error handler
 *
 * Usage:
 * ```typescript
 * app.get('/users', asyncHandler(async (req, res) => {
 *   const users = await userService.getAll();
 *   res.json(users);
 * }));
 * ```
 */
export function asyncHandler<T>(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<T>
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * Validate request body with Zod schema
 *
 * Usage:
 * ```typescript
 * import { z } from 'zod';
 *
 * const CreateUserSchema = z.object({
 *   email: z.string().email(),
 *   name: z.string().min(1),
 * });
 *
 * app.post('/users', validateBody(CreateUserSchema), asyncHandler(async (req, res) => {
 *   // req.body is now typed and validated
 * }));
 * ```
 */
export function validateBody<T>(schema: {
  parse: (data: unknown) => T;
  safeParse: (data: unknown) => { success: boolean; error?: { issues: unknown[] } };
}) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const result = schema.safeParse(req.body);

    if (!result.success) {
      const error = new ValidationError('Request validation failed', {
        issues: result.error?.issues,
      });
      next(error);
      return;
    }

    next();
  };
}

// =============================================================================
// EXPORTS
// =============================================================================

export default errorHandler;
