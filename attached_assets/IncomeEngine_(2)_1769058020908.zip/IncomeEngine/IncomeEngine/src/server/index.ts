/**
 * ============================================================================
 * REPLIT EXPRESS SERVER
 * Passive Income Safeguards - API & PWA Server
 * ============================================================================
 * 
 * This server provides:
 * 1. REST API endpoints for all 8 safeguards
 * 2. Static file serving for the PWA frontend
 * 3. Health checks for Replit deployments
 * 
 * Deployment: Autoscale (scales to zero when idle)
 */

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { fileURLToPath } from 'url';

// Import infrastructure services
import { logger, requestLoggerMiddleware, type RequestWithLogger } from './services/logger.js';
import {
  healthCheckHandler,
  readinessHandler,
  metricsHandler,
  metricsMiddleware,
  registerHealthCheck,
  registerReadinessCheck,
} from './services/monitoring.js';
import {
  errorHandler,
  notFoundHandler,
  asyncHandler,
} from './middleware/error-handler.js';
import {
  responseTimeMiddleware,
  etagMiddleware,
  apiVersionMiddleware,
  securityHeaders,
} from './middleware/response-optimizer.js';
import { cache, cachedQuery, createNamespacedCache } from './services/cache.js';

// Import safeguard modules
import { createSafeguardsOrchestrator } from '../safeguards/orchestrator.js';

// Import connector modules
import {
  createConnector,
  getAvailableConnectors,
  getConnectorMetadata,
  PODDigitalWorkflow,
  MarketplaceWorkflow,
  type ConnectorName,
  type ConnectorFactoryConfig,
} from '../connectors/index.js';

// Import analytics routes
import analyticsRouter from './routes/analytics.js';

// Import pricing optimizer
import { createPricingOptimizer, type PricingOptimizer } from '../services/pricing-optimizer/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// =============================================================================
// ENVIRONMENT CONFIGURATION
// =============================================================================

// Replit uses Secrets for environment variables
// Access via process.env - no .env file needed in production
const PORT = parseInt(process.env.PORT || '3000', 10);
const NODE_ENV = process.env.NODE_ENV || 'development';
const isProduction = NODE_ENV === 'production';
const API_VERSION = process.env.npm_package_version || '1.0.0';

// Validate required secrets
const requiredSecrets = ['SUPABASE_URL', 'SUPABASE_SERVICE_KEY', 'OPENAI_API_KEY'];
const missingSecrets = requiredSecrets.filter(key => !process.env[key]);

if (missingSecrets.length > 0 && isProduction) {
  logger.error('Missing required Replit Secrets', { missingSecrets });
  process.exit(1);
}

// Create cache namespaces
const statusCache = createNamespacedCache('status');
const connectorCache = createNamespacedCache('connectors');
const pricingCache = createNamespacedCache('pricing');

// =============================================================================
// EXPRESS APP SETUP
// =============================================================================

const app = express();

// =============================================================================
// INFRASTRUCTURE MIDDLEWARE (first in chain)
// =============================================================================

// Response time tracking
app.use(responseTimeMiddleware);

// Request logging with request ID
app.use(requestLoggerMiddleware);

// Metrics collection
app.use(metricsMiddleware);

// API version header
app.use(apiVersionMiddleware(API_VERSION));

// =============================================================================
// SECURITY MIDDLEWARE
// =============================================================================

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://*.supabase.co", "https://api.openai.com"]
    }
  }
}));

// Additional security headers
app.use(securityHeaders);

// CORS configuration
app.use(cors({
  origin: isProduction
    ? [/\.replit\.app$/, /\.repl\.co$/]
    : '*',
  credentials: true
}));

// Compression for faster responses
app.use(compression());

// ETag support for caching
app.use(etagMiddleware);

// JSON body parser
app.use(express.json({ limit: '10mb' }));

// Rate limiting to prevent abuse
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window
  message: { error: 'Too many requests, please try again later' },
  standardHeaders: true,
  legacyHeaders: false
});

app.use('/api/', apiLimiter);

// =============================================================================
// HEALTH CHECK ENDPOINTS (Required for Replit Autoscale)
// =============================================================================

// Enhanced health check with component status
app.get('/health', healthCheckHandler);

// Readiness check for load balancers
app.get('/ready', readinessHandler);

// Metrics endpoint for monitoring
app.get('/metrics', metricsHandler);

// Simple health check for Replit
app.get('/__replit_health', (_req: Request, res: Response) => {
  res.status(200).send('OK');
});

// Register Supabase health check
registerHealthCheck('supabase', async () => {
  if (!process.env.SUPABASE_URL) {
    return { status: 'warn', message: 'Supabase not configured' };
  }
  try {
    const response = await fetch(`${process.env.SUPABASE_URL}/rest/v1/`, {
      headers: { apikey: process.env.SUPABASE_ANON_KEY || '' },
      signal: AbortSignal.timeout(5000),
    });
    return response.ok
      ? { status: 'pass', message: 'Connected' }
      : { status: 'fail', message: `HTTP ${response.status}` };
  } catch (error) {
    return { status: 'fail', message: (error as Error).message };
  }
});

// Register readiness check for orchestrator
registerReadinessCheck('orchestrator', async () => {
  return !!getOrchestrator();
});

// =============================================================================
// API ROUTES
// =============================================================================

// Initialize orchestrator (lazy loading)
let orchestrator: ReturnType<typeof createSafeguardsOrchestrator> | null = null;

const getOrchestrator = () => {
  if (!orchestrator && process.env.SUPABASE_URL) {
    orchestrator = createSafeguardsOrchestrator();
  }
  return orchestrator;
};

// Initialize pricing optimizer (lazy loading)
let pricingOptimizer: PricingOptimizer | null = null;

const getPricingOptimizer = (): PricingOptimizer | null => {
  if (!pricingOptimizer && process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
    pricingOptimizer = createPricingOptimizer({
      supabaseUrl: process.env.SUPABASE_URL,
      supabaseKey: process.env.SUPABASE_SERVICE_KEY,
      enableCompetitorMonitoring: true,
      enableDemandAnalysis: true,
      enableABTesting: true,
    });
  }
  return pricingOptimizer;
};

// Get system status (cached for 30 seconds)
app.get('/api/status', asyncHandler(async (req: Request, res: Response) => {
  const orch = getOrchestrator();
  if (!orch) {
    return res.status(503).json({ error: 'Safeguards not configured' });
  }

  const status = await statusCache.query(
    'system',
    () => orch.getSystemStatus(),
    30000 // 30 second cache
  );

  const reqLogger = (req as RequestWithLogger).logger || logger;
  reqLogger.debug('System status retrieved', { cached: statusCache.has('system') });

  res.json(status);
}));

// Process a product through safeguards
app.post('/api/products/process', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const product = req.body;
    
    // Validate required fields
    if (!product.id || !product.title || !product.type) {
      return res.status(400).json({ 
        error: 'Missing required fields: id, title, type' 
      });
    }

    const result = await orch.processProduct(product);
    res.json(result);
  } catch (error) {
    console.error('Process error:', error);
    res.status(500).json({ error: 'Failed to process product' });
  }
});

// Get budget status
app.get('/api/budget', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json({ budget: status.budget, circuitBreakers: status.circuitBreakers });
  } catch (error) {
    console.error('Budget error:', error);
    res.status(500).json({ error: 'Failed to get budget status' });
  }
});

// Get approval queue
app.get('/api/approvals', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json(status.approvalStats);
  } catch (error) {
    console.error('Approvals error:', error);
    res.status(500).json({ error: 'Failed to get approvals' });
  }
});

// Approve a product
app.post('/api/approvals/:id/approve', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) return res.status(503).json({ error: 'Safeguards not configured' });

    const reviewerId = String(req.headers['x-reviewer-id'] ?? 'unknown');
    const { notes } = req.body ?? {};
    await orch.approveApproval(req.params.id, reviewerId, notes);
    res.json({ success: true, message: 'Product approved' });
  } catch (error) {
    console.error('Approve error:', error);
    res.status(500).json({ error: 'Failed to approve product' });
  }
});

// Reject a product
app.post('/api/approvals/:id/reject', async (req: Request, res: Response) => {
  try {
    const { reason } = req.body;
    const orch = getOrchestrator();
    if (!orch) return res.status(503).json({ error: 'Safeguards not configured' });

    const reviewerId = String(req.headers['x-reviewer-id'] ?? 'unknown');
    const { notes } = req.body ?? {};
    await orch.rejectApproval(req.params.id, reviewerId, String(reason ?? 'No reason provided'), notes);
    res.json({ success: true, message: 'Product rejected', reason: String(reason ?? 'No reason provided') });
  } catch (error) {
    console.error('Reject error:', error);
    res.status(500).json({ error: 'Failed to reject product' });
  }
});

// Get provider health
app.get('/api/providers', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json(status.providers);
  } catch (error) {
    console.error('Providers error:', error);
    res.status(500).json({ error: 'Failed to get provider status' });
  }
});

// Get API queue stats
app.get('/api/queue', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json(status.queues);
  } catch (error) {
    console.error('Queue error:', error);
    res.status(500).json({ error: 'Failed to get queue status' });
  }
});

// =============================================================================
// CONNECTOR API ROUTES
// =============================================================================

// Connector instances cache
const connectorInstances = new Map<ConnectorName, ReturnType<typeof createConnector>>();

// Workflow engine instances (lazy loaded)
let podWorkflow: PODDigitalWorkflow | null = null;
let marketplaceWorkflow: MarketplaceWorkflow | null = null;

// Initialize workflow engines
const getPODWorkflow = (): PODDigitalWorkflow => {
  if (!podWorkflow && process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
    podWorkflow = new PODDigitalWorkflow({
      supabaseUrl: process.env.SUPABASE_URL,
      supabaseKey: process.env.SUPABASE_SERVICE_KEY,
      enableSafeguards: true,
      maxRetries: 3,
      retryDelayMs: 1000,
      parallelPublishing: false,
      dryRun: process.env.DRY_RUN === 'true',
    });
  }
  return podWorkflow!;
};

const getMarketplaceWorkflow = (): MarketplaceWorkflow => {
  if (!marketplaceWorkflow && process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
    marketplaceWorkflow = new MarketplaceWorkflow({
      supabaseUrl: process.env.SUPABASE_URL,
      supabaseKey: process.env.SUPABASE_SERVICE_KEY,
      enableInventorySync: true,
      enableOrderSync: true,
      inventorySyncIntervalMs: 5 * 60 * 1000, // 5 minutes
      orderSyncIntervalMs: 2 * 60 * 1000, // 2 minutes
      lowStockThreshold: 5,
    });
  }
  return marketplaceWorkflow!;
};

// Get all available connectors
app.get('/api/connectors', (req: Request, res: Response) => {
  try {
    const connectors = getAvailableConnectors().map(name => ({
      name,
      ...getConnectorMetadata(name),
    }));
    res.json(connectors);
  } catch (error) {
    console.error('Connectors error:', error);
    res.status(500).json({ error: 'Failed to get connectors' });
  }
});

// Get connector metadata
app.get('/api/connectors/:platform', (req: Request, res: Response) => {
  try {
    const platform = req.params.platform as ConnectorName;
    const metadata = getConnectorMetadata(platform);

    if (!metadata) {
      return res.status(404).json({ error: `Unknown connector: ${platform}` });
    }

    res.json({ name: platform, ...metadata });
  } catch (error) {
    console.error('Connector metadata error:', error);
    res.status(500).json({ error: 'Failed to get connector metadata' });
  }
});

// Test connector connection
app.post('/api/connectors/:platform/test', async (req: Request, res: Response) => {
  try {
    const platform = req.params.platform as ConnectorName;

    // Check if connector type is valid
    const metadata = getConnectorMetadata(platform);
    if (!metadata) {
      return res.status(404).json({ error: `Unknown connector: ${platform}` });
    }

    if (metadata.status !== 'available') {
      return res.status(400).json({ error: `Connector ${platform} is not yet available` });
    }

    // Create temporary connector for testing
    const config: ConnectorFactoryConfig = {
      supabaseUrl: process.env.SUPABASE_URL!,
      supabaseKey: process.env.SUPABASE_SERVICE_KEY!,
      shopDomain: req.body.shopDomain,
      siteUrl: req.body.siteUrl,
    };

    const connector = createConnector(platform, config);
    const result = await connector.validateCredentials();

    res.json({
      success: result,
      platform,
      message: result ? 'Connection successful' : 'Connection failed'
    });
  } catch (error) {
    console.error('Connection test error:', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Connection test failed'
    });
  }
});

// Connect a platform (store credentials)
app.post('/api/connectors/:platform/connect', async (req: Request, res: Response) => {
  try {
    const platform = req.params.platform as ConnectorName;
    const { credentials, settings } = req.body;

    if (!credentials) {
      return res.status(400).json({ error: 'Credentials required' });
    }

    // This would store credentials securely in the database
    // For now, just validate they can connect
    const config: ConnectorFactoryConfig = {
      supabaseUrl: process.env.SUPABASE_URL!,
      supabaseKey: process.env.SUPABASE_SERVICE_KEY!,
      shopDomain: settings?.shopDomain,
      siteUrl: settings?.siteUrl,
    };

    const connector = createConnector(platform, config);
    const valid = await connector.validateCredentials();

    if (!valid) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Cache the connector
    connectorInstances.set(platform, connector);

    res.json({
      success: true,
      platform,
      message: `Connected to ${platform}`
    });
  } catch (error) {
    console.error('Connect error:', error);
    res.status(500).json({ error: 'Failed to connect platform' });
  }
});

// Disconnect a platform
app.post('/api/connectors/:platform/disconnect', async (req: Request, res: Response) => {
  try {
    const platform = req.params.platform as ConnectorName;

    // Remove from cache
    connectorInstances.delete(platform);

    res.json({
      success: true,
      platform,
      message: `Disconnected from ${platform}`
    });
  } catch (error) {
    console.error('Disconnect error:', error);
    res.status(500).json({ error: 'Failed to disconnect platform' });
  }
});

// List products from a platform
app.get('/api/connectors/:platform/products', async (req: Request, res: Response) => {
  try {
    const platform = req.params.platform as ConnectorName;
    const connector = connectorInstances.get(platform);

    if (!connector) {
      return res.status(400).json({ error: `Platform ${platform} is not connected` });
    }

    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    const result = await connector.listProducts({ page, limit });

    if (!result.success) {
      return res.status(500).json({ error: result.error?.message || 'Failed to list products' });
    }

    res.json(result.data);
  } catch (error) {
    console.error('List products error:', error);
    res.status(500).json({ error: 'Failed to list products' });
  }
});

// Publish product to multiple platforms (POD workflow)
app.post('/api/products/:id/publish/pod', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { product, targets } = req.body;

    if (!product || !targets || !Array.isArray(targets)) {
      return res.status(400).json({ error: 'Product and targets array required' });
    }

    const workflow = getPODWorkflow();
    if (!workflow) {
      return res.status(503).json({ error: 'POD workflow not configured' });
    }

    const result = await workflow.processProduct(
      { ...product, id },
      targets
    );

    res.json(result);
  } catch (error) {
    console.error('POD publish error:', error);
    res.status(500).json({ error: 'Failed to publish product' });
  }
});

// Publish product to marketplace platforms
app.post('/api/products/:id/publish/marketplace', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { product, listings } = req.body;

    if (!product || !listings || !Array.isArray(listings)) {
      return res.status(400).json({ error: 'Product and listings array required' });
    }

    const workflow = getMarketplaceWorkflow();
    if (!workflow) {
      return res.status(503).json({ error: 'Marketplace workflow not configured' });
    }

    const result = await workflow.listProduct(
      { ...product, id },
      listings
    );

    res.json(result);
  } catch (error) {
    console.error('Marketplace publish error:', error);
    res.status(500).json({ error: 'Failed to publish product' });
  }
});

// Sync inventory across platforms
app.post('/api/inventory/sync', async (req: Request, res: Response) => {
  try {
    const workflow = getMarketplaceWorkflow();
    if (!workflow) {
      return res.status(503).json({ error: 'Marketplace workflow not configured' });
    }

    const result = await workflow.syncAllInventory();
    res.json(result);
  } catch (error) {
    console.error('Inventory sync error:', error);
    res.status(500).json({ error: 'Failed to sync inventory' });
  }
});

// Get cross-platform analytics
app.get('/api/analytics/platforms', async (req: Request, res: Response) => {
  try {
    const startDate = req.query.start ? new Date(req.query.start as string) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const endDate = req.query.end ? new Date(req.query.end as string) : new Date();

    const dateRange = { start: startDate, end: endDate };

    // Get analytics from both workflow types
    const podWorkflow = getPODWorkflow();
    const mktWorkflow = getMarketplaceWorkflow();

    const results: { pod?: any; marketplace?: any } = {};

    if (podWorkflow) {
      try {
        results.pod = await podWorkflow.getCrossplatformAnalytics(dateRange);
      } catch (e) {
        console.error('POD analytics error:', e);
      }
    }

    if (mktWorkflow) {
      try {
        results.marketplace = await mktWorkflow.getMarketplaceAnalytics(dateRange);
      } catch (e) {
        console.error('Marketplace analytics error:', e);
      }
    }

    res.json(results);
  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({ error: 'Failed to get analytics' });
  }
});

// =============================================================================
// ANALYTICS API ROUTES
// =============================================================================

// Mount the comprehensive analytics router
// Provides: /api/analytics/revenue, /api/analytics/products, /api/analytics/trends, etc.
app.use('/api/analytics', analyticsRouter);

// =============================================================================
// PRICING OPTIMIZER API ROUTES
// =============================================================================

// Get pricing optimizer status
app.get('/api/pricing/status', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const status = await optimizer.getStatus();
  res.json(status);
}));

// Get price recommendation for a product
app.get('/api/pricing/recommendations/:productId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const forceRecalculate = req.query.force === 'true';

  const recommendation = await optimizer.getRecommendation(productId, { forceRecalculate });
  res.json(recommendation);
}));

// Get price recommendation explanation
app.get('/api/pricing/recommendations/:productId/explain', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const explanation = await optimizer.explainRecommendation(productId);
  res.json(explanation);
}));

// Get bulk price recommendations
app.post('/api/pricing/recommendations/bulk', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productIds, concurrency } = req.body;
  if (!Array.isArray(productIds)) {
    return res.status(400).json({ error: 'productIds array required' });
  }

  const recommendations = await optimizer.getBulkRecommendations(productIds, { concurrency });
  res.json(Object.fromEntries(recommendations));
}));

// Get competitor products for a product
app.get('/api/pricing/competitors/:productId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const competitors = await optimizer.getCompetitorProducts(productId);
  res.json(competitors);
}));

// Add a competitor
app.post('/api/pricing/competitors', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { name, platform, url, scrapeFrequency } = req.body;
  if (!name || !platform || !url) {
    return res.status(400).json({ error: 'name, platform, and url required' });
  }

  const competitor = await optimizer.addCompetitor({
    name,
    platform,
    url,
    isActive: true,
    scrapeFrequency: scrapeFrequency ?? 'daily',
  });
  res.status(201).json(competitor);
}));

// Get price alerts
app.get('/api/pricing/alerts', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const productId = req.query.productId as string | undefined;
  const severity = req.query.severity as 'low' | 'medium' | 'high' | 'critical' | undefined;
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : undefined;

  const alerts = await optimizer.getAlerts({ productId, severity, limit });
  res.json(alerts);
}));

// Acknowledge a price alert
app.post('/api/pricing/alerts/:alertId/acknowledge', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { alertId } = req.params;
  await optimizer.acknowledgeAlert(alertId);
  res.json({ success: true, message: 'Alert acknowledged' });
}));

// Create a pricing rule
app.post('/api/pricing/rules', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { name, description, condition, action, priority, appliesTo, schedule } = req.body;
  if (!name || !condition || !action) {
    return res.status(400).json({ error: 'name, condition, and action required' });
  }

  const rule = await optimizer.createRule({
    name,
    description: description ?? '',
    condition,
    action,
    priority: priority ?? 0,
    isEnabled: true,
    appliesTo: appliesTo ?? {},
    schedule,
  });
  res.status(201).json(rule);
}));

// Get all pricing rules
app.get('/api/pricing/rules', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const enabledOnly = req.query.enabledOnly === 'true';
  const rules = await optimizer.getRules({ enabledOnly });
  res.json(rules);
}));

// Update a pricing rule
app.put('/api/pricing/rules/:ruleId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { ruleId } = req.params;
  const updates = req.body;
  const rule = await optimizer.updateRule(ruleId, updates);
  res.json(rule);
}));

// Delete a pricing rule
app.delete('/api/pricing/rules/:ruleId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { ruleId } = req.params;
  await optimizer.deleteRule(ruleId);
  res.json({ success: true, message: 'Rule deleted' });
}));

// Get demand analysis (elasticity)
app.get('/api/pricing/analysis/elasticity/:productId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const elasticity = await optimizer.getElasticity(productId);
  res.json(elasticity);
}));

// Get seasonal patterns
app.get('/api/pricing/analysis/seasonality/:productId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const patterns = await optimizer.getSeasonalPatterns(productId);
  res.json(patterns);
}));

// Get conversion analysis
app.get('/api/pricing/analysis/conversion/:productId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const analysis = await optimizer.analyzeConversion(productId);
  res.json(analysis);
}));

// Create A/B test experiment
app.post('/api/pricing/ab-test', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { name, description, productId, variants, trafficAllocation, primaryMetric, secondaryMetrics, minimumSampleSize, confidenceLevel } = req.body;

  if (!name || !productId || !variants || variants.length < 2) {
    return res.status(400).json({ error: 'name, productId, and at least 2 variants required' });
  }

  const experiment = await optimizer.createExperiment({
    name,
    description: description ?? '',
    productId,
    variants,
    trafficAllocation: trafficAllocation ?? { method: 'random' },
    primaryMetric: primaryMetric ?? 'revenue',
    secondaryMetrics: secondaryMetrics ?? [],
    minimumSampleSize: minimumSampleSize ?? 100,
    confidenceLevel: confidenceLevel ?? 0.95,
  });
  res.status(201).json(experiment);
}));

// Get experiment by ID
app.get('/api/pricing/ab-test/:experimentId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { experimentId } = req.params;
  const experiment = await optimizer.getExperiment(experimentId);
  if (!experiment) {
    return res.status(404).json({ error: 'Experiment not found' });
  }
  res.json(experiment);
}));

// Get experiments for a product
app.get('/api/pricing/ab-test/product/:productId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const experiments = await optimizer.getExperiments(productId);
  res.json(experiments);
}));

// Start an experiment
app.post('/api/pricing/ab-test/:experimentId/start', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { experimentId } = req.params;
  const experiment = await optimizer.startExperiment(experimentId);
  res.json(experiment);
}));

// Stop an experiment
app.post('/api/pricing/ab-test/:experimentId/stop', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { experimentId } = req.params;
  const experiment = await optimizer.stopExperiment(experimentId);
  res.json(experiment);
}));

// Get experiment results
app.get('/api/pricing/ab-test/:experimentId/results', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { experimentId } = req.params;
  const results = await optimizer.analyzeExperiment(experimentId);
  res.json(results);
}));

// Get experiment summary with recommendations
app.get('/api/pricing/ab-test/:experimentId/summary', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { experimentId } = req.params;
  const summary = await optimizer.getExperimentSummary(experimentId);
  res.json(summary);
}));

// Get price for a visitor (for storefront integration)
app.get('/api/pricing/visitor-price/:productId', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { productId } = req.params;
  const visitorId = req.query.visitorId as string;
  const defaultPrice = parseFloat(req.query.defaultPrice as string) || 0;

  if (!visitorId) {
    return res.status(400).json({ error: 'visitorId query param required' });
  }

  const result = await optimizer.getPriceForVisitor(productId, visitorId, defaultPrice);
  res.json(result);
}));

// Track purchase event for experiment
app.post('/api/pricing/ab-test/:experimentId/track-purchase', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const { experimentId } = req.params;
  const { variantId, visitorId, revenue } = req.body;

  if (!variantId || !visitorId || revenue === undefined) {
    return res.status(400).json({ error: 'variantId, visitorId, and revenue required' });
  }

  await optimizer.trackPurchase(experimentId, variantId, visitorId, revenue);
  res.json({ success: true, message: 'Purchase tracked' });
}));

// Get margin statistics
app.get('/api/pricing/margins/stats', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const category = req.query.category as string | undefined;
  const platform = req.query.platform as string | undefined;

  const stats = await optimizer.getMarginStats({ category, platform });
  res.json(stats);
}));

// Find low margin products
app.get('/api/pricing/margins/low', asyncHandler(async (req: Request, res: Response) => {
  const optimizer = getPricingOptimizer();
  if (!optimizer) {
    return res.status(503).json({ error: 'Pricing optimizer not configured' });
  }

  const category = req.query.category as string | undefined;
  const platform = req.query.platform as string | undefined;
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : undefined;

  const products = await optimizer.findLowMarginProducts({ category, platform, limit });
  res.json(products);
}));

// Get workflow status
app.get('/api/workflows/status', async (req: Request, res: Response) => {
  try {
    const podWorkflow = getPODWorkflow();

    const activeWorkflows = podWorkflow ? podWorkflow.getActiveWorkflows() : [];

    res.json({
      activeWorkflows: activeWorkflows.length,
      workflows: activeWorkflows,
    });
  } catch (error) {
    console.error('Workflow status error:', error);
    res.status(500).json({ error: 'Failed to get workflow status' });
  }
});

// =============================================================================
// STATIC FILE SERVING (PWA)
// =============================================================================

// Serve static files from the built frontend
const clientDistPath = path.join(__dirname, '../../dist/client');

if (isProduction) {
  app.use(express.static(clientDistPath, {
    maxAge: '1d',
    etag: true
  }));
  
  // Service worker should not be cached
  app.get('/sw.js', (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(path.join(clientDistPath, 'sw.js'));
  });
  
  // SPA fallback - serve index.html for all non-API routes
  app.get('*', (req: Request, res: Response) => {
    if (!req.path.startsWith('/api/')) {
      res.sendFile(path.join(clientDistPath, 'index.html'));
    }
  });
}

// =============================================================================
// ERROR HANDLING (must be last in middleware chain)
// =============================================================================

// 404 handler for unmatched routes
app.use(notFoundHandler);

// Global error handler with structured logging
app.use(errorHandler);

// =============================================================================
// SERVER STARTUP
// =============================================================================

app.listen(PORT, '0.0.0.0', () => {
  logger.info('Server started', {
    port: PORT,
    environment: NODE_ENV,
    version: API_VERSION,
    secretsConfigured: requiredSecrets.length - missingSecrets.length,
    totalSecrets: requiredSecrets.length,
  });

  console.log(`
+================================================================+
|         PASSIVE INCOME SAFEGUARDS - MOBILE DASHBOARD           |
+================================================================+
|  Server running on port ${String(PORT).padEnd(36)}|
|  PWA ready for mobile installation                             |
|  ${requiredSecrets.length - missingSecrets.length}/${requiredSecrets.length} Secrets configured                                  |
|  Environment: ${NODE_ENV.padEnd(46)}|
|  API Version: ${API_VERSION.padEnd(46)}|
+================================================================+

Health Endpoints:
  GET  /health         - Full health check with components
  GET  /ready          - Readiness check for load balancers
  GET  /metrics        - Performance metrics

API Endpoints:
  GET  /api/status     - System status (cached)
  POST /api/products/process - Process product through safeguards
  GET  /api/budget     - Budget status
  GET  /api/approvals  - Approval queue
  GET  /api/providers  - Provider health
  GET  /api/queue      - API queue stats

Connector Endpoints:
  GET  /api/connectors              - List available connectors
  GET  /api/connectors/:platform    - Get connector metadata
  POST /api/connectors/:platform/test       - Test connection
  POST /api/connectors/:platform/connect    - Connect platform
  POST /api/connectors/:platform/disconnect - Disconnect platform
  GET  /api/connectors/:platform/products   - List platform products

Workflow Endpoints:
  POST /api/products/:id/publish/pod         - Publish to POD platforms
  POST /api/products/:id/publish/marketplace - Publish to marketplaces
  POST /api/inventory/sync                   - Sync inventory
  GET  /api/analytics/platforms              - Cross-platform analytics
  GET  /api/workflows/status                 - Active workflow status
  `);
});

export default app;
