/**
 * ============================================================================
 * CACHING SERVICE
 * In-memory cache with TTL, invalidation, and performance metrics
 * ============================================================================
 *
 * Features:
 * - In-memory caching with configurable TTL
 * - Cache invalidation (single key, pattern, all)
 * - Cached query wrapper for Supabase
 * - LRU eviction when max size exceeded
 * - Cache statistics and metrics
 * - Namespace support for organization
 *
 * Usage:
 * ```typescript
 * import { cache, cachedQuery, createNamespacedCache } from './services/cache';
 *
 * // Basic caching
 * cache.set('user:123', userData, 300000); // 5 minute TTL
 * const user = cache.get('user:123');
 *
 * // Cached database query
 * const users = await cachedQuery('all-users', async () => {
 *   return await supabase.from('users').select();
 * }, 60000);
 *
 * // Namespaced cache
 * const userCache = createNamespacedCache('users');
 * userCache.set('123', userData);
 * userCache.invalidateAll(); // Only invalidates users namespace
 * ```
 */

import { cacheLogger as logger } from './logger.js';

// =============================================================================
// TYPES
// =============================================================================

export interface CacheEntry<T> {
  value: T;
  expiresAt: number;
  createdAt: number;
  accessedAt: number;
  accessCount: number;
  size: number;
}

export interface CacheStats {
  hits: number;
  misses: number;
  sets: number;
  deletes: number;
  evictions: number;
  size: number;
  maxSize: number;
  hitRate: number;
  entries: number;
}

export interface CacheOptions {
  maxSize?: number; // Maximum cache size in bytes (approximate)
  maxEntries?: number; // Maximum number of entries
  defaultTTL?: number; // Default TTL in milliseconds
  cleanupInterval?: number; // Cleanup interval in milliseconds
}

// =============================================================================
// CACHE IMPLEMENTATION
// =============================================================================

const DEFAULT_OPTIONS: Required<CacheOptions> = {
  maxSize: 50 * 1024 * 1024, // 50MB
  maxEntries: 10000,
  defaultTTL: 5 * 60 * 1000, // 5 minutes
  cleanupInterval: 60 * 1000, // 1 minute
};

class MemoryCache {
  private readonly store: Map<string, CacheEntry<unknown>> = new Map();
  private readonly options: Required<CacheOptions>;
  private stats: CacheStats = {
    hits: 0,
    misses: 0,
    sets: 0,
    deletes: 0,
    evictions: 0,
    size: 0,
    maxSize: 0,
    hitRate: 0,
    entries: 0,
  };
  private cleanupTimer: ReturnType<typeof setInterval> | null = null;

  constructor(options: CacheOptions = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.stats.maxSize = this.options.maxSize;
    this.startCleanupTimer();
  }

  /**
   * Get a value from the cache
   */
  get<T>(key: string): T | undefined {
    const entry = this.store.get(key);

    if (!entry) {
      this.stats.misses++;
      this.updateHitRate();
      return undefined;
    }

    // Check if expired
    if (Date.now() > entry.expiresAt) {
      this.delete(key);
      this.stats.misses++;
      this.updateHitRate();
      return undefined;
    }

    // Update access stats
    entry.accessedAt = Date.now();
    entry.accessCount++;
    this.stats.hits++;
    this.updateHitRate();

    logger.debug('Cache hit', { key });
    return entry.value as T;
  }

  /**
   * Set a value in the cache
   */
  set<T>(key: string, value: T, ttl?: number): void {
    const actualTTL = ttl ?? this.options.defaultTTL;
    const size = this.estimateSize(value);
    const now = Date.now();

    // Check if we need to evict entries
    this.ensureCapacity(size);

    const entry: CacheEntry<T> = {
      value,
      expiresAt: now + actualTTL,
      createdAt: now,
      accessedAt: now,
      accessCount: 0,
      size,
    };

    // Update size if replacing existing entry
    const existing = this.store.get(key);
    if (existing) {
      this.stats.size -= existing.size;
    }

    this.store.set(key, entry as CacheEntry<unknown>);
    this.stats.size += size;
    this.stats.sets++;
    this.stats.entries = this.store.size;

    logger.debug('Cache set', { key, ttl: actualTTL, size });
  }

  /**
   * Delete a value from the cache
   */
  delete(key: string): boolean {
    const entry = this.store.get(key);
    if (entry) {
      this.stats.size -= entry.size;
      this.store.delete(key);
      this.stats.deletes++;
      this.stats.entries = this.store.size;
      logger.debug('Cache delete', { key });
      return true;
    }
    return false;
  }

  /**
   * Check if a key exists and is not expired
   */
  has(key: string): boolean {
    const entry = this.store.get(key);
    if (!entry) return false;
    if (Date.now() > entry.expiresAt) {
      this.delete(key);
      return false;
    }
    return true;
  }

  /**
   * Invalidate entries matching a pattern
   * Pattern supports * as wildcard
   */
  invalidatePattern(pattern: string): number {
    const regex = new RegExp(
      '^' + pattern.replace(/\*/g, '.*').replace(/\?/g, '.') + '$'
    );
    let count = 0;

    for (const key of this.store.keys()) {
      if (regex.test(key)) {
        this.delete(key);
        count++;
      }
    }

    logger.info('Cache invalidated by pattern', { pattern, count });
    return count;
  }

  /**
   * Clear all cache entries
   */
  clear(): void {
    const count = this.store.size;
    this.store.clear();
    this.stats.size = 0;
    this.stats.entries = 0;
    logger.info('Cache cleared', { entriesCleared: count });
  }

  /**
   * Get cache statistics
   */
  getStats(): CacheStats {
    return { ...this.stats };
  }

  /**
   * Get all keys (for debugging)
   */
  keys(): string[] {
    return Array.from(this.store.keys());
  }

  /**
   * Get entry metadata (for debugging)
   */
  getEntryMeta(key: string): Omit<CacheEntry<unknown>, 'value'> | undefined {
    const entry = this.store.get(key);
    if (!entry) return undefined;

    return {
      expiresAt: entry.expiresAt,
      createdAt: entry.createdAt,
      accessedAt: entry.accessedAt,
      accessCount: entry.accessCount,
      size: entry.size,
    };
  }

  /**
   * Stop cleanup timer (for graceful shutdown)
   */
  shutdown(): void {
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = null;
    }
  }

  // ==========================================================================
  // PRIVATE METHODS
  // ==========================================================================

  private startCleanupTimer(): void {
    this.cleanupTimer = setInterval(() => {
      this.cleanup();
    }, this.options.cleanupInterval);

    // Don't prevent process from exiting (Node.js only)
    if (typeof this.cleanupTimer === 'object' && 'unref' in this.cleanupTimer) {
      (this.cleanupTimer as NodeJS.Timeout).unref();
    }
  }

  private cleanup(): void {
    const now = Date.now();
    let expiredCount = 0;

    for (const [key, entry] of this.store.entries()) {
      if (now > entry.expiresAt) {
        this.delete(key);
        expiredCount++;
      }
    }

    if (expiredCount > 0) {
      logger.debug('Cache cleanup completed', { expiredCount });
    }
  }

  private ensureCapacity(newEntrySize: number): void {
    // Check entry count limit
    while (this.store.size >= this.options.maxEntries) {
      this.evictLRU();
    }

    // Check size limit
    while (this.stats.size + newEntrySize > this.options.maxSize && this.store.size > 0) {
      this.evictLRU();
    }
  }

  private evictLRU(): void {
    let lruKey: string | null = null;
    let lruAccessedAt = Infinity;

    for (const [key, entry] of this.store.entries()) {
      if (entry.accessedAt < lruAccessedAt) {
        lruAccessedAt = entry.accessedAt;
        lruKey = key;
      }
    }

    if (lruKey) {
      this.delete(lruKey);
      this.stats.evictions++;
      logger.debug('Cache LRU eviction', { key: lruKey });
    }
  }

  private estimateSize(value: unknown): number {
    // Rough estimation of object size in bytes
    const str = JSON.stringify(value);
    return str ? str.length * 2 : 0; // UTF-16 encoding
  }

  private updateHitRate(): void {
    const total = this.stats.hits + this.stats.misses;
    this.stats.hitRate = total > 0 ? this.stats.hits / total : 0;
  }
}

// =============================================================================
// SINGLETON INSTANCE
// =============================================================================

export const cache = new MemoryCache();

// =============================================================================
// CACHED QUERY WRAPPER
// =============================================================================

/**
 * Execute a query with caching
 * Useful for database queries that are expensive and don't change frequently
 *
 * @param key - Cache key
 * @param queryFn - Async function that fetches the data
 * @param ttl - Time to live in milliseconds (default: 5 minutes)
 * @param options - Additional options
 */
export async function cachedQuery<T>(
  key: string,
  queryFn: () => Promise<T>,
  ttl?: number,
  options?: {
    forceRefresh?: boolean;
    onCacheHit?: (value: T) => void;
    onCacheMiss?: () => void;
  }
): Promise<T> {
  // Check cache first (unless force refresh)
  if (!options?.forceRefresh) {
    const cached = cache.get<T>(key);
    if (cached !== undefined) {
      options?.onCacheHit?.(cached);
      return cached;
    }
  }

  options?.onCacheMiss?.();

  // Execute query
  const startTime = performance.now();
  const result = await queryFn();
  const duration = Math.round(performance.now() - startTime);

  // Store in cache
  cache.set(key, result, ttl);

  logger.debug('Cached query executed', { key, duration });

  return result;
}

/**
 * Invalidate cached query result
 */
export function invalidateCachedQuery(key: string): boolean {
  return cache.delete(key);
}

/**
 * Invalidate multiple cached query results by pattern
 */
export function invalidateCachedQueries(pattern: string): number {
  return cache.invalidatePattern(pattern);
}

// =============================================================================
// NAMESPACED CACHE
// =============================================================================

/**
 * Create a namespaced cache for organizing related cache entries
 *
 * @param namespace - Namespace prefix for all keys
 */
export function createNamespacedCache(namespace: string) {
  const prefix = `${namespace}:`;

  return {
    /**
     * Get a value from the cache
     */
    get<T>(key: string): T | undefined {
      return cache.get<T>(`${prefix}${key}`);
    },

    /**
     * Set a value in the cache
     */
    set<T>(key: string, value: T, ttl?: number): void {
      cache.set(`${prefix}${key}`, value, ttl);
    },

    /**
     * Delete a value from the cache
     */
    delete(key: string): boolean {
      return cache.delete(`${prefix}${key}`);
    },

    /**
     * Check if a key exists
     */
    has(key: string): boolean {
      return cache.has(`${prefix}${key}`);
    },

    /**
     * Invalidate all entries in this namespace
     */
    invalidateAll(): number {
      return cache.invalidatePattern(`${prefix}*`);
    },

    /**
     * Execute a cached query
     */
    async query<T>(
      key: string,
      queryFn: () => Promise<T>,
      ttl?: number
    ): Promise<T> {
      return cachedQuery(`${prefix}${key}`, queryFn, ttl);
    },

    /**
     * Get all keys in this namespace
     */
    keys(): string[] {
      return cache
        .keys()
        .filter((k) => k.startsWith(prefix))
        .map((k) => k.slice(prefix.length));
    },
  };
}

// =============================================================================
// CACHE DECORATORS (for class methods)
// =============================================================================

/**
 * Decorator factory for caching method results
 *
 * Usage:
 * ```typescript
 * class UserService {
 *   @Cached('user', 60000)
 *   async getUser(id: string): Promise<User> {
 *     return await db.query('SELECT * FROM users WHERE id = ?', [id]);
 *   }
 * }
 * ```
 */
export function Cached(keyPrefix: string, ttl?: number) {
  return function (
    _target: unknown,
    propertyKey: string,
    descriptor: PropertyDescriptor
  ) {
    const originalMethod = descriptor.value;

    descriptor.value = async function (...args: unknown[]) {
      const key = `${keyPrefix}:${propertyKey}:${JSON.stringify(args)}`;
      return cachedQuery(key, () => originalMethod.apply(this, args), ttl);
    };

    return descriptor;
  };
}

// =============================================================================
// MEMOIZATION HELPER
// =============================================================================

/**
 * Create a memoized version of an async function
 *
 * @param fn - Function to memoize
 * @param keyFn - Function to generate cache key from arguments
 * @param ttl - Time to live in milliseconds
 */
export function memoize<TArgs extends unknown[], TResult>(
  fn: (...args: TArgs) => Promise<TResult>,
  keyFn: (...args: TArgs) => string,
  ttl?: number
): (...args: TArgs) => Promise<TResult> {
  return async (...args: TArgs): Promise<TResult> => {
    const key = `memoize:${keyFn(...args)}`;
    return cachedQuery(key, () => fn(...args), ttl);
  };
}

// =============================================================================
// CACHE WARMING
// =============================================================================

interface CacheWarmupTask<T> {
  key: string;
  queryFn: () => Promise<T>;
  ttl?: number;
}

/**
 * Warm up cache with multiple queries in parallel
 *
 * Usage:
 * ```typescript
 * await warmupCache([
 *   { key: 'config', queryFn: () => getConfig() },
 *   { key: 'categories', queryFn: () => getCategories() },
 * ]);
 * ```
 */
export async function warmupCache<T>(
  tasks: CacheWarmupTask<T>[]
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  const results = await Promise.allSettled(
    tasks.map(async (task) => {
      try {
        const result = await task.queryFn();
        cache.set(task.key, result, task.ttl);
        return true;
      } catch (error) {
        logger.error('Cache warmup failed', {
          key: task.key,
          error: error instanceof Error ? error.message : String(error),
        });
        throw error;
      }
    })
  );

  for (const result of results) {
    if (result.status === 'fulfilled') {
      success++;
    } else {
      failed++;
    }
  }

  logger.info('Cache warmup completed', { success, failed });
  return { success, failed };
}

// =============================================================================
// EXPORTS
// =============================================================================

export default cache;
