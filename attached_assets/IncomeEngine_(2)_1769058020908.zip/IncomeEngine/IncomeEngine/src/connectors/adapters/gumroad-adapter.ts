/**
 * Gumroad Adapter
 * Digital products marketplace connector
 *
 * API Docs: https://app.gumroad.com/api
 * Auth: API Key (access_token query param)
 * Rate Limit: 100 requests/minute
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  ProductType,
  DateRange,
  PlatformAnalytics,
  RevenueData,
} from '../core/types';
import { mapPlatformError } from '../utils/error-mapper';

// Gumroad-specific types
interface GumroadProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  short_url: string;
  formatted_price: string;
  published: boolean;
  url: string;
  custom_permalink: string;
  custom_receipt: string;
  custom_summary: string;
  preview_url: string;
  thumbnail_url: string;
  tags: string[];
  sales_count: number;
  sales_usd_cents: number;
  is_tiered_membership: boolean;
  recurrence: string | null;
  variants: GumroadVariant[];
  custom_fields: GumroadCustomField[];
  file_info: GumroadFileInfo;
}

interface GumroadVariant {
  id: string;
  name: string;
  price_difference_cents: number;
  max_purchase_count: number | null;
  purchasing_power_parity_prices: Record<string, number>;
}

interface GumroadCustomField {
  id: string;
  name: string;
  required: boolean;
}

interface GumroadFileInfo {
  file_count: number;
  file_size_bytes: number;
}

interface GumroadSale {
  id: string;
  email: string;
  seller_id: string;
  timestamp: string;
  order_number: number;
  product_id: string;
  product_name: string;
  price_cents: number;
  currency: string;
  quantity: number;
  discover_fee_charged: boolean;
  can_contact: boolean;
  referrer: string;
  card: { visual: string; type: string };
  purchase_email: string;
  variants: string;
  license_key: string;
}

interface LicenseKey {
  id: string;
  product_id: string;
  license_key: string;
  uses: number;
  max_uses: number;
}

/**
 * Gumroad platform adapter
 */
export class GumroadAdapter extends BaseConnector {
  readonly name = 'gumroad';
  readonly displayName = 'Gumroad';
  readonly workflowGroup = 'pod_digital' as const;
  readonly connectorType = 'api_key' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: true, // Also supports OAuth
    supportsBulkOperations: false,
    supportsWebhooks: true,
    supportsInventorySync: false,
    supportsOrderFulfillment: false, // Digital products, no fulfillment
    supportsAnalytics: true,
    maxProductsPerRequest: 1,
    rateLimits: {
      requestsPerMinute: 100,
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 255,
    maxDescriptionLength: 65535,
    maxImages: 1, // Cover image only
    maxTags: 20,
    maxVariants: 50,
    allowedImageFormats: ['jpg', 'jpeg', 'png', 'gif'],
    maxImageSizeMB: 25,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['name', 'price'],
    requiredCategories: false,
    requiredShippingProfile: false,
  };

  private baseUrl = 'https://api.gumroad.com/v2';

  constructor(config: ConnectorConfig) {
    super({
      ...config,
      baseUrl: 'https://api.gumroad.com/v2',
    });
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    const apiKey = this.config.credentials?.apiKey;
    if (!apiKey) {
      return {
        success: false,
        error: this.createError('AUTH_MISSING', 'Gumroad API key is required'),
      };
    }

    this.authToken = {
      accessToken: apiKey,
      tokenType: 'Bearer',
    };

    // Validate by fetching user info
    const userResult = await this.request<{ success: boolean; user: { id: string } }>({
      method: 'GET',
      path: '/user',
      query: { access_token: apiKey },
    });

    if (!userResult.success || !userResult.data?.success) {
      this.authToken = null;
      return {
        success: false,
        error: userResult.error || this.createError('AUTH_INVALID', 'Invalid API key'),
      };
    }

    return { success: true, data: this.authToken };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    // API keys don't need refreshing
    if (this.authToken) {
      return { success: true, data: this.authToken };
    }
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    const result = await this.request<{ success: boolean }>({
      method: 'GET',
      path: '/user',
      query: { access_token: this.authToken?.accessToken },
    });
    return result.success && result.data?.success === true;
  }

  // Override to add access_token to all requests
  protected override buildUrl(
    path: string,
    query?: Record<string, string | number | boolean>
  ): string {
    const fullQuery = {
      ...query,
      access_token: this.authToken?.accessToken || '',
    };
    return super.buildUrl(path, fullQuery);
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    const result = await this.request<{ success: boolean; products: GumroadProduct[] }>({
      method: 'GET',
      path: '/products',
    });

    if (!result.success || !result.data?.success) {
      return result as ConnectorResult<PaginatedProducts>;
    }

    const products = result.data.products;
    const page = options?.page || 1;
    const limit = options?.limit || 20;
    const start = (page - 1) * limit;
    const end = start + limit;

    return {
      success: true,
      data: {
        items: products.slice(start, end).map((p) => this.normalizeProduct(p)),
        total: products.length,
        page,
        limit,
        hasMore: end < products.length,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    const result = await this.request<{ success: boolean; product: GumroadProduct }>({
      method: 'GET',
      path: `/products/${id}`,
    });

    if (!result.success || !result.data?.success) {
      return result as ConnectorResult<NormalizedProduct>;
    }

    return {
      success: true,
      data: this.normalizeProduct(result.data.product),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    // Validate product
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_ERROR',
          validation.issues.map((i) => i.message).join('; ')
        ),
      };
    }

    const gumroadData = {
      name: product.title,
      description: product.description,
      price: Math.round(product.pricing.price * 100), // Cents
      tags: product.tags?.join(','),
      preview_url: product.images[0]?.url,
      custom_permalink: product.metadata?.permalink,
      published: false, // Start as draft
    };

    const result = await this.request<{ success: boolean; product: GumroadProduct }>({
      method: 'POST',
      path: '/products',
      body: gumroadData,
    });

    if (!result.success || !result.data?.success) {
      return result as ConnectorResult<CreateResult>;
    }

    return {
      success: true,
      data: {
        id: result.data.product.id,
        externalId: result.data.product.id,
        externalUrl: result.data.product.short_url,
        status: result.data.product.published ? 'active' : 'draft',
      },
    };
  }

  async updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>> {
    const updatePayload: Record<string, unknown> = {};
    const updatedFields: string[] = [];

    if (updates.title) {
      updatePayload.name = updates.title;
      updatedFields.push('name');
    }
    if (updates.description) {
      updatePayload.description = updates.description;
      updatedFields.push('description');
    }
    if (updates.tags) {
      updatePayload.tags = updates.tags.join(',');
      updatedFields.push('tags');
    }
    if (updates.pricing?.price) {
      updatePayload.price = Math.round(updates.pricing.price * 100);
      updatedFields.push('price');
    }

    const result = await this.request<{ success: boolean; product: GumroadProduct }>({
      method: 'PUT',
      path: `/products/${id}`,
      body: updatePayload,
    });

    if (!result.success || !result.data?.success) {
      return result as ConnectorResult<UpdateResult>;
    }

    return {
      success: true,
      data: {
        id,
        externalId: id,
        updatedFields,
      },
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    const result = await this.request<{ success: boolean }>({
      method: 'DELETE',
      path: `/products/${id}`,
    });

    return {
      success: result.success && result.data?.success === true,
      data: { id, deleted: result.success && result.data?.success === true },
      error: result.error,
    };
  }

  // ============================================================================
  // Publishing
  // ============================================================================

  async publishProduct(id: string): Promise<ConnectorResult<void>> {
    const result = await this.request<{ success: boolean }>({
      method: 'PUT',
      path: `/products/${id}`,
      body: { published: true },
    });

    return {
      success: result.success && result.data?.success === true,
      error: result.error,
    };
  }

  async unpublishProduct(id: string): Promise<ConnectorResult<void>> {
    const result = await this.request<{ success: boolean }>({
      method: 'PUT',
      path: `/products/${id}`,
      body: { published: false },
    });

    return {
      success: result.success && result.data?.success === true,
      error: result.error,
    };
  }

  // ============================================================================
  // Sales & Analytics
  // ============================================================================

  async getProductSales(productId: string): Promise<ConnectorResult<GumroadSale[]>> {
    const result = await this.request<{ success: boolean; sales: GumroadSale[] }>({
      method: 'GET',
      path: `/products/${productId}/sales`,
    });

    if (!result.success || !result.data?.success) {
      return result as ConnectorResult<GumroadSale[]>;
    }

    return { success: true, data: result.data.sales };
  }

  async getAllSales(): Promise<ConnectorResult<GumroadSale[]>> {
    const result = await this.request<{ success: boolean; sales: GumroadSale[] }>({
      method: 'GET',
      path: '/sales',
    });

    if (!result.success || !result.data?.success) {
      return result as ConnectorResult<GumroadSale[]>;
    }

    return { success: true, data: result.data.sales };
  }

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    const salesResult = await this.getAllSales();
    if (!salesResult.success) {
      return salesResult as ConnectorResult<PlatformAnalytics>;
    }

    // Filter sales by date range
    const sales = salesResult.data!.filter((s) => {
      const saleDate = new Date(s.timestamp);
      return saleDate >= dateRange.start && saleDate <= dateRange.end;
    });

    const totalRevenue = sales.reduce((sum, s) => sum + s.price_cents / 100, 0);

    // Group by day
    const byDay = new Map<string, number>();
    sales.forEach((s) => {
      const date = new Date(s.timestamp).toISOString().split('T')[0];
      byDay.set(date, (byDay.get(date) || 0) + s.price_cents / 100);
    });

    // Group by product
    const byProduct = new Map<string, { title: string; sales: number; revenue: number }>();
    sales.forEach((s) => {
      const existing = byProduct.get(s.product_id) || {
        title: s.product_name,
        sales: 0,
        revenue: 0,
      };
      existing.sales += s.quantity;
      existing.revenue += s.price_cents / 100;
      byProduct.set(s.product_id, existing);
    });

    return {
      success: true,
      data: {
        platform: 'gumroad',
        dateRange,
        revenue: {
          total: totalRevenue,
          currency: 'USD',
          byDay: Array.from(byDay.entries()).map(([date, amount]) => ({ date, amount })),
          byProduct: Array.from(byProduct.entries()).map(([productId, data]) => ({
            productId,
            title: data.title,
            amount: data.revenue,
          })),
        },
        orderCount: sales.length,
        productCount: byProduct.size,
        topProducts: Array.from(byProduct.entries())
          .map(([id, data]) => ({ id, ...data }))
          .sort((a, b) => b.revenue - a.revenue)
          .slice(0, 10),
      },
    };
  }

  // ============================================================================
  // License Keys
  // ============================================================================

  async generateLicenseKey(productId: string): Promise<ConnectorResult<LicenseKey>> {
    // Gumroad doesn't have a direct API for generating license keys
    // They are generated automatically on purchase
    return {
      success: false,
      error: this.createError(
        'NOT_SUPPORTED',
        'License keys are generated automatically on purchase'
      ),
    };
  }

  async verifyLicenseKey(
    productId: string,
    licenseKey: string
  ): Promise<ConnectorResult<{ valid: boolean; uses: number }>> {
    const result = await this.request<{
      success: boolean;
      uses: number;
      purchase: { product_id: string };
    }>({
      method: 'POST',
      path: '/licenses/verify',
      body: {
        product_id: productId,
        license_key: licenseKey,
      },
    });

    if (!result.success) {
      return { success: true, data: { valid: false, uses: 0 } };
    }

    return {
      success: true,
      data: {
        valid: result.data?.success === true,
        uses: result.data?.uses || 0,
      },
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const p = platformProduct as GumroadProduct;

    return {
      id: p.id,
      externalId: p.id,
      title: p.name,
      description: p.description || '',
      productType: 'digital-download' as ProductType,
      images: p.thumbnail_url
        ? [
            {
              id: `${p.id}-thumb`,
              url: p.thumbnail_url,
              position: 0,
              isPrimary: true,
            },
          ]
        : [],
      variants: p.variants.map((v) => ({
        id: v.id,
        title: v.name,
        price: p.price / 100 + v.price_difference_cents / 100,
        options: {},
      })),
      pricing: {
        price: p.price / 100,
        currency: p.currency,
        taxable: true,
      },
      tags: p.tags,
      metadata: {
        custom_permalink: p.custom_permalink,
        recurrence: p.recurrence,
        is_tiered_membership: p.is_tiered_membership,
      },
      platformData: {
        short_url: p.short_url,
        url: p.url,
        preview_url: p.preview_url,
        sales_count: p.sales_count,
        sales_usd_cents: p.sales_usd_cents,
        file_info: p.file_info,
      },
      status: p.published ? 'active' : 'draft',
      createdAt: new Date(), // Gumroad doesn't provide creation date
      updatedAt: new Date(),
    };
  }

  denormalizeProduct(product: NormalizedProduct): unknown {
    return {
      name: product.title,
      description: product.description,
      price: Math.round(product.pricing.price * 100),
      tags: product.tags?.join(','),
      custom_permalink: product.metadata?.custom_permalink,
      preview_url: product.images[0]?.url,
      published: product.status === 'active',
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    if (!product.title) {
      issues.push(this.createValidationIssue('title', 'Name is required', 'error'));
    } else if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Name exceeds ${this.platformLimits.maxTitleLength} characters`,
          'error'
        )
      );
    }

    if (!product.pricing?.price || product.pricing.price < 0) {
      issues.push(
        this.createValidationIssue('pricing.price', 'Price must be 0 or greater', 'error')
      );
    }

    if (product.pricing?.price && product.pricing.price > 0 && product.pricing.price < 0.99) {
      issues.push(
        this.createValidationIssue(
          'pricing.price',
          'Paid products must be at least $0.99',
          'error'
        )
      );
    }

    if (product.tags && product.tags.length > this.platformLimits.maxTags) {
      issues.push(
        this.createValidationIssue(
          'tags',
          `Too many tags (max ${this.platformLimits.maxTags})`,
          'warning'
        )
      );
    }

    return {
      valid: issues.filter((i) => i.severity === 'error').length === 0,
      issues,
    };
  }

  protected override mapPlatformError(status: number, data: unknown) {
    return mapPlatformError('gumroad', status, data);
  }
}

export default GumroadAdapter;
