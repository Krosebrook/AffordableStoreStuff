/**
 * TikTok Shop Adapter
 * E-commerce marketplace connector for TikTok Shop
 *
 * API Docs: https://partner.tiktokshop.com/doc
 * Auth: OAuth 2.0
 * Rate Limit: 100 requests per 10 seconds
 *
 * Features: Products, Orders, Fulfillment, Live Shopping, Analytics
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PaginatedOrders,
  Order,
  OrderItem,
  TrackingInfo,
  Fulfillment,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  ProductType,
  ProductStatus,
  OrderStatus,
  DateRange,
  PlatformAnalytics,
  RevenueData,
  TikTokCategory,
  TikTokAttribute,
  ImageUploadResult,
} from '../core/types';

// TikTok Shop product status
type TikTokProductStatus = 'DRAFT' | 'PENDING' | 'LIVE' | 'SUSPENDED' | 'DELETED';

// TikTok Shop order status
type TikTokOrderStatus =
  | 'UNPAID'
  | 'ON_HOLD'
  | 'AWAITING_SHIPMENT'
  | 'AWAITING_COLLECTION'
  | 'IN_TRANSIT'
  | 'DELIVERED'
  | 'COMPLETED'
  | 'CANCELLED';

export interface TikTokShopCredentials {
  appKey: string;
  appSecret: string;
  accessToken?: string;
  refreshToken?: string;
  shopId?: string;
}

interface TikTokProduct {
  product_id: string;
  product_name: string;
  description: string;
  category_list: { id: string; name: string }[];
  brand: { id: string; name: string };
  main_images: { url: string }[];
  skus: TikTokSku[];
  product_status: TikTokProductStatus;
  create_time: number;
  update_time: number;
}

interface TikTokSku {
  id: string;
  seller_sku: string;
  original_price: { amount: string; currency: string };
  price: { amount: string; currency: string };
  inventory: { quantity: number };
  sales_attributes: { attribute_id: string; value_id: string; name: string }[];
}

interface TikTokOrder {
  order_id: string;
  order_status: TikTokOrderStatus;
  order_line_list: TikTokOrderLine[];
  payment: { total_amount: { amount: string; currency: string } };
  recipient_address: {
    name: string;
    phone: string;
    address_line: string[];
    city: string;
    state: string;
    postal_code: string;
    country: string;
  };
  create_time: number;
  update_time: number;
}

interface TikTokOrderLine {
  product_id: string;
  sku_id: string;
  product_name: string;
  sku_name: string;
  quantity: number;
  original_price: { amount: string; currency: string };
  sale_price: { amount: string; currency: string };
}

interface TikTokApiResponse<T> {
  code: number;
  message: string;
  data: T;
  request_id: string;
}

/**
 * TikTok Shop platform adapter
 * E-commerce marketplace with live shopping integration
 */
export class TikTokShopAdapter extends BaseConnector {
  readonly name = 'tiktok-shop';
  readonly displayName = 'TikTok Shop';
  readonly workflowGroup = 'marketplace' as const;
  readonly connectorType = 'oauth2' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: true,
    supportsBulkOperations: true,
    supportsWebhooks: true,
    supportsInventorySync: true,
    supportsOrderFulfillment: true,
    supportsAnalytics: true,
    maxProductsPerRequest: 20,
    rateLimits: {
      requestsPer10Seconds: 100,
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 255,
    maxDescriptionLength: 10000,
    maxImages: 9,
    maxTags: 20,
    maxVariants: 50,
    allowedImageFormats: ['jpg', 'jpeg', 'png'],
    maxImageSizeMB: 5,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['title', 'description', 'category', 'images', 'price', 'inventory'],
    requiredCategories: true,
    requiredShippingProfile: true,
  };

  private baseUrl = 'https://open-api.tiktokglobalshop.com';
  private shopId: string | null = null;
  private credentials: TikTokShopCredentials | null = null;

  constructor(config: ConnectorConfig) {
    super({
      ...config,
      baseUrl: 'https://open-api.tiktokglobalshop.com',
    });

    if (config.credentials) {
      this.credentials = {
        appKey: config.credentials.appKey,
        appSecret: config.credentials.appSecret,
        accessToken: config.credentials.accessToken,
        refreshToken: config.credentials.refreshToken,
        shopId: config.credentials.shopId,
      };
      this.shopId = config.credentials.shopId || null;
    }
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    if (!this.credentials?.appKey || !this.credentials?.appSecret) {
      return {
        success: false,
        error: this.createError('AUTH_MISSING', 'TikTok Shop app key and secret are required'),
      };
    }

    // If we already have an access token, validate it
    if (this.credentials.accessToken) {
      this.authToken = {
        accessToken: this.credentials.accessToken,
        refreshToken: this.credentials.refreshToken,
        tokenType: 'Bearer',
      };

      const shopsResult = await this.getShops();
      if (shopsResult.success) {
        return { success: true, data: this.authToken };
      }

      // Token might be expired, try to refresh
      if (this.credentials.refreshToken) {
        return this.refreshAuth();
      }
    }

    // Need to initiate OAuth flow
    return {
      success: false,
      error: this.createError(
        'AUTH_REQUIRED',
        'TikTok Shop requires OAuth authorization. Please complete the OAuth flow.',
        false,
        {
          authUrl: this.getAuthorizationUrl(),
        }
      ),
    };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    if (!this.credentials?.refreshToken) {
      return {
        success: false,
        error: this.createError('AUTH_EXPIRED', 'No refresh token available'),
      };
    }

    const result = await this.request<{
      access_token: string;
      refresh_token: string;
      expires_in: number;
    }>({
      method: 'POST',
      path: '/api/v2/token/refresh',
      body: {
        app_key: this.credentials.appKey,
        app_secret: this.credentials.appSecret,
        refresh_token: this.credentials.refreshToken,
        grant_type: 'refresh_token',
      },
    });

    if (!result.success) {
      return result as ConnectorResult<AuthToken>;
    }

    this.authToken = {
      accessToken: result.data!.access_token,
      refreshToken: result.data!.refresh_token,
      expiresAt: new Date(Date.now() + result.data!.expires_in * 1000),
      tokenType: 'Bearer',
    };

    // Update stored credentials
    if (this.credentials) {
      this.credentials.accessToken = result.data!.access_token;
      this.credentials.refreshToken = result.data!.refresh_token;
    }

    return { success: true, data: this.authToken };
  }

  async validateCredentials(): Promise<boolean> {
    if (!this.authToken) {
      return false;
    }
    const shopsResult = await this.getShops();
    return shopsResult.success;
  }

  /**
   * Get OAuth authorization URL
   */
  getAuthorizationUrl(): string {
    const params = new URLSearchParams({
      app_key: this.credentials?.appKey || '',
      state: crypto.randomUUID(),
    });
    return `https://auth.tiktok-shops.com/oauth/authorize?${params.toString()}`;
  }

  /**
   * Exchange authorization code for access token
   */
  async exchangeCode(code: string): Promise<ConnectorResult<AuthToken>> {
    const result = await this.request<{
      access_token: string;
      refresh_token: string;
      expires_in: number;
    }>({
      method: 'POST',
      path: '/api/v2/token/get',
      body: {
        app_key: this.credentials?.appKey,
        app_secret: this.credentials?.appSecret,
        auth_code: code,
        grant_type: 'authorized_code',
      },
    });

    if (!result.success) {
      return result as ConnectorResult<AuthToken>;
    }

    this.authToken = {
      accessToken: result.data!.access_token,
      refreshToken: result.data!.refresh_token,
      expiresAt: new Date(Date.now() + result.data!.expires_in * 1000),
      tokenType: 'Bearer',
    };

    return { success: true, data: this.authToken };
  }

  // ============================================================================
  // Shop Operations
  // ============================================================================

  async getShops(): Promise<ConnectorResult<{ id: string; name: string; region: string }[]>> {
    const result = await this.request<TikTokApiResponse<{ shops: { shop_id: string; shop_name: string; region: string }[] }>>({
      method: 'GET',
      path: '/authorization/202309/shops',
    });

    if (!result.success) {
      return result as ConnectorResult<{ id: string; name: string; region: string }[]>;
    }

    const shops = result.data!.data.shops.map((s) => ({
      id: s.shop_id,
      name: s.shop_name,
      region: s.region,
    }));

    // Set first shop as default
    if (shops.length > 0 && !this.shopId) {
      this.shopId = shops[0].id;
    }

    return { success: true, data: shops };
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    const page = options?.page ?? 1;
    const limit = options?.limit ?? 20;

    const result = await this.request<TikTokApiResponse<{ products: TikTokProduct[]; total: number }>>({
      method: 'POST',
      path: `/product/202309/products/search`,
      query: { shop_cipher: this.shopId || '' },
      body: {
        page_size: limit,
        page_number: page,
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedProducts>;
    }

    const items = result.data!.data.products.map((p) => this.normalizeProduct(p));

    return {
      success: true,
      data: {
        items,
        total: result.data!.data.total,
        page,
        limit,
        hasMore: page * limit < result.data!.data.total,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    const result = await this.request<TikTokApiResponse<TikTokProduct>>({
      method: 'GET',
      path: `/product/202309/products/${id}`,
      query: { shop_cipher: this.shopId || '' },
    });

    if (!result.success) {
      return result as ConnectorResult<NormalizedProduct>;
    }

    return {
      success: true,
      data: this.normalizeProduct(result.data!.data),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_FAILED',
          `Product validation failed: ${validation.issues.map((i) => i.message).join(', ')}`,
          false
        ),
      };
    }

    // First upload images
    const imageIds: string[] = [];
    for (const image of product.images) {
      const uploadResult = await this.uploadImage(image.url);
      if (uploadResult.success && uploadResult.data) {
        imageIds.push(uploadResult.data.imageId);
      }
    }

    const ttProduct = this.denormalizeTikTokProduct(product, imageIds);

    const result = await this.request<TikTokApiResponse<{ product_id: string }>>({
      method: 'POST',
      path: '/product/202309/products',
      query: { shop_cipher: this.shopId || '' },
      body: ttProduct,
    });

    if (!result.success) {
      return result as ConnectorResult<CreateResult>;
    }

    return {
      success: true,
      data: {
        id: result.data!.data.product_id,
        externalId: result.data!.data.product_id,
        status: 'pending' as ProductStatus,
      },
    };
  }

  async updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>> {
    const result = await this.request<TikTokApiResponse<{ product_id: string }>>({
      method: 'PUT',
      path: `/product/202309/products/${id}`,
      query: { shop_cipher: this.shopId || '' },
      body: updates,
    });

    if (!result.success) {
      return result as ConnectorResult<UpdateResult>;
    }

    return {
      success: true,
      data: {
        id,
        externalId: id,
        updatedFields: Object.keys(updates),
      },
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    const result = await this.request<TikTokApiResponse<{ success: boolean }>>({
      method: 'DELETE',
      path: `/product/202309/products`,
      query: { shop_cipher: this.shopId || '' },
      body: { product_ids: [id] },
    });

    if (!result.success) {
      return result as ConnectorResult<DeleteResult>;
    }

    return {
      success: true,
      data: {
        id,
        deleted: true,
      },
    };
  }

  // ============================================================================
  // Order Operations
  // ============================================================================

  async listOrders(options?: ListOptions): Promise<ConnectorResult<PaginatedOrders>> {
    const page = options?.page ?? 1;
    const limit = options?.limit ?? 20;

    const result = await this.request<TikTokApiResponse<{ orders: TikTokOrder[]; total: number }>>({
      method: 'POST',
      path: '/order/202309/orders/search',
      query: { shop_cipher: this.shopId || '' },
      body: {
        page_size: limit,
        page_number: page,
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedOrders>;
    }

    const items = result.data!.data.orders.map((o) => this.normalizeOrder(o));

    return {
      success: true,
      data: {
        items,
        total: result.data!.data.total,
        page,
        limit,
        hasMore: page * limit < result.data!.data.total,
      },
    };
  }

  async getOrder(orderId: string): Promise<ConnectorResult<Order>> {
    const result = await this.request<TikTokApiResponse<TikTokOrder>>({
      method: 'GET',
      path: `/order/202309/orders/${orderId}`,
      query: { shop_cipher: this.shopId || '' },
    });

    if (!result.success) {
      return result as ConnectorResult<Order>;
    }

    return {
      success: true,
      data: this.normalizeOrder(result.data!.data),
    };
  }

  async fulfillOrder(orderId: string, tracking: TrackingInfo): Promise<ConnectorResult<Fulfillment>> {
    const result = await this.request<TikTokApiResponse<{ package_id: string }>>({
      method: 'POST',
      path: `/fulfillment/202309/packages`,
      query: { shop_cipher: this.shopId || '' },
      body: {
        order_id: orderId,
        tracking_number: tracking.trackingNumber,
        shipping_provider_id: tracking.carrier,
      },
    });

    if (!result.success) {
      return result as ConnectorResult<Fulfillment>;
    }

    return {
      success: true,
      data: {
        id: result.data!.data.package_id,
        orderId,
        tracking,
        items: [],
        fulfilledAt: new Date(),
      },
    };
  }

  // ============================================================================
  // Image Operations
  // ============================================================================

  async uploadImage(imageUrl: string): Promise<ConnectorResult<ImageUploadResult>> {
    const result = await this.request<TikTokApiResponse<{ image_info: { image_id: string; image_url: string } }>>({
      method: 'POST',
      path: '/product/202309/images/upload',
      query: { shop_cipher: this.shopId || '' },
      body: { image_url: imageUrl },
    });

    if (!result.success) {
      return result as ConnectorResult<ImageUploadResult>;
    }

    return {
      success: true,
      data: {
        imageId: result.data!.data.image_info.image_id,
        imageUrl: result.data!.data.image_info.image_url,
      },
    };
  }

  // ============================================================================
  // Category Operations
  // ============================================================================

  async getCategories(): Promise<ConnectorResult<TikTokCategory[]>> {
    const result = await this.request<TikTokApiResponse<{ categories: { id: string; parent_id: string; name: string; is_leaf: boolean }[] }>>({
      method: 'GET',
      path: '/product/202309/categories',
      query: { shop_cipher: this.shopId || '' },
    });

    if (!result.success) {
      return result as ConnectorResult<TikTokCategory[]>;
    }

    return {
      success: true,
      data: result.data!.data.categories.map((c) => ({
        id: c.id,
        name: c.name,
        parentId: c.parent_id || undefined,
        isLeaf: c.is_leaf,
      })),
    };
  }

  async getCategoryAttributes(categoryId: string): Promise<ConnectorResult<TikTokAttribute[]>> {
    const result = await this.request<TikTokApiResponse<{ attributes: { id: string; name: string; is_required: boolean; input_type: { type: string }; values: { id: string; name: string }[] }[] }>>({
      method: 'GET',
      path: `/product/202309/categories/${categoryId}/attributes`,
      query: { shop_cipher: this.shopId || '' },
    });

    if (!result.success) {
      return result as ConnectorResult<TikTokAttribute[]>;
    }

    return {
      success: true,
      data: result.data!.data.attributes.map((a) => ({
        id: a.id,
        name: a.name,
        required: a.is_required,
        type: a.input_type.type as 'text' | 'number' | 'enum',
        values: a.values?.map((v) => v.name),
      })),
    };
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    // TikTok Shop provides analytics through their seller center API
    const result = await this.request<TikTokApiResponse<{
      total_sales: { amount: string; currency: string };
      order_count: number;
      product_count: number;
    }>>({
      method: 'GET',
      path: '/data/202309/analytics/overview',
      query: {
        shop_cipher: this.shopId || '',
        start_date: Math.floor(dateRange.start.getTime() / 1000),
        end_date: Math.floor(dateRange.end.getTime() / 1000),
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PlatformAnalytics>;
    }

    return {
      success: true,
      data: {
        platform: this.name,
        dateRange,
        revenue: {
          total: parseFloat(result.data!.data.total_sales.amount),
          currency: result.data!.data.total_sales.currency,
          byDay: [],
          byProduct: [],
        },
        orderCount: result.data!.data.order_count,
        productCount: result.data!.data.product_count,
        topProducts: [],
      },
    };
  }

  async getRevenue(dateRange: DateRange): Promise<ConnectorResult<RevenueData>> {
    const analytics = await this.getAnalytics(dateRange);
    if (!analytics.success) {
      return analytics as ConnectorResult<RevenueData>;
    }

    return {
      success: true,
      data: analytics.data!.revenue,
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const ttProduct = platformProduct as TikTokProduct;

    return {
      id: ttProduct.product_id,
      externalId: ttProduct.product_id,
      title: ttProduct.product_name,
      description: ttProduct.description,
      productType: 'other' as ProductType,
      images: ttProduct.main_images.map((img, idx) => ({
        id: String(idx),
        url: img.url,
        position: idx,
        isPrimary: idx === 0,
      })),
      variants: ttProduct.skus.map((sku) => ({
        id: sku.id,
        sku: sku.seller_sku,
        title: sku.sales_attributes.map((a) => a.name).join(' / '),
        price: parseFloat(sku.price.amount),
        compareAtPrice: parseFloat(sku.original_price.amount),
        inventoryQuantity: sku.inventory.quantity,
        options: Object.fromEntries(
          sku.sales_attributes.map((a) => [a.attribute_id, a.value_id])
        ),
      })),
      pricing: {
        price: parseFloat(ttProduct.skus[0]?.price.amount || '0'),
        currency: ttProduct.skus[0]?.price.currency || 'USD',
        taxable: true,
      },
      tags: [],
      metadata: {
        brand: ttProduct.brand,
        categories: ttProduct.category_list,
      },
      platformData: ttProduct,
      status: this.mapProductStatus(ttProduct.product_status),
      createdAt: new Date(ttProduct.create_time * 1000),
      updatedAt: new Date(ttProduct.update_time * 1000),
    };
  }

  denormalizeProduct(product: NormalizedProduct): unknown {
    return this.denormalizeTikTokProduct(
      {
        title: product.title,
        description: product.description,
        productType: product.productType,
        images: product.images,
        variants: product.variants,
        pricing: product.pricing,
        tags: product.tags,
        metadata: product.metadata,
      },
      product.images.map((i) => i.id)
    );
  }

  private denormalizeTikTokProduct(
    product: ProductInput,
    imageIds: string[]
  ): Record<string, unknown> {
    return {
      product_name: product.title,
      description: product.description,
      category_id: product.metadata?.categoryId,
      main_images: imageIds.map((id) => ({ image_id: id })),
      skus: product.variants?.map((v) => ({
        seller_sku: v.sku,
        original_price: { amount: String(v.compareAtPrice || v.price), currency: 'USD' },
        price: { amount: String(v.price), currency: 'USD' },
        inventory: [{ quantity: v.inventoryQuantity || 0 }],
      })) || [
        {
          seller_sku: `SKU-${Date.now()}`,
          original_price: { amount: String(product.pricing.price), currency: 'USD' },
          price: { amount: String(product.pricing.price), currency: 'USD' },
          inventory: [{ quantity: 100 }],
        },
      ],
    };
  }

  private normalizeOrder(ttOrder: TikTokOrder): Order {
    return {
      id: ttOrder.order_id,
      externalId: ttOrder.order_id,
      status: this.mapOrderStatus(ttOrder.order_status),
      items: ttOrder.order_line_list.map((line) => ({
        id: line.sku_id,
        productId: line.product_id,
        variantId: line.sku_id,
        title: line.product_name,
        quantity: line.quantity,
        price: parseFloat(line.sale_price.amount),
        sku: line.sku_name,
      })),
      shippingAddress: {
        name: ttOrder.recipient_address.name,
        address1: ttOrder.recipient_address.address_line[0] || '',
        address2: ttOrder.recipient_address.address_line[1],
        city: ttOrder.recipient_address.city,
        state: ttOrder.recipient_address.state,
        postalCode: ttOrder.recipient_address.postal_code,
        country: ttOrder.recipient_address.country,
        phone: ttOrder.recipient_address.phone,
      },
      subtotal: parseFloat(ttOrder.payment.total_amount.amount),
      shippingCost: 0,
      tax: 0,
      total: parseFloat(ttOrder.payment.total_amount.amount),
      currency: ttOrder.payment.total_amount.currency,
      createdAt: new Date(ttOrder.create_time * 1000),
      updatedAt: new Date(ttOrder.update_time * 1000),
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    // Title validation
    if (product.title.length < 10) {
      issues.push(
        this.createValidationIssue('title', 'Title must be at least 10 characters', 'error')
      );
    }
    if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title must be ${this.platformLimits.maxTitleLength} characters or less`,
          'error'
        )
      );
    }

    // Images validation
    if (!product.images || product.images.length === 0) {
      issues.push(
        this.createValidationIssue('images', 'At least one image is required', 'error')
      );
    }
    if (product.images && product.images.length > this.platformLimits.maxImages) {
      issues.push(
        this.createValidationIssue(
          'images',
          `Maximum ${this.platformLimits.maxImages} images allowed`,
          'error'
        )
      );
    }

    // Category validation
    if (!product.metadata?.categoryId) {
      issues.push(
        this.createValidationIssue('category', 'Category is required', 'error')
      );
    }

    // Price validation
    if (product.pricing.price <= 0) {
      issues.push(
        this.createValidationIssue('price', 'Price must be greater than 0', 'error')
      );
    }

    return {
      valid: !issues.some((i) => i.severity === 'error'),
      issues,
    };
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private mapProductStatus(status: TikTokProductStatus): ProductStatus {
    const statusMap: Record<TikTokProductStatus, ProductStatus> = {
      DRAFT: 'draft',
      PENDING: 'pending',
      LIVE: 'active',
      SUSPENDED: 'archived',
      DELETED: 'archived',
    };
    return statusMap[status] || 'draft';
  }

  private mapOrderStatus(status: TikTokOrderStatus): OrderStatus {
    const statusMap: Record<TikTokOrderStatus, OrderStatus> = {
      UNPAID: 'pending',
      ON_HOLD: 'pending',
      AWAITING_SHIPMENT: 'processing',
      AWAITING_COLLECTION: 'processing',
      IN_TRANSIT: 'shipped',
      DELIVERED: 'delivered',
      COMPLETED: 'delivered',
      CANCELLED: 'cancelled',
    };
    return statusMap[status] || 'pending';
  }

  // ============================================================================
  // TikTok Shop-Specific Methods
  // ============================================================================

  /**
   * Get shipping providers
   */
  async getShippingProviders(): Promise<ConnectorResult<{ id: string; name: string }[]>> {
    const result = await this.request<TikTokApiResponse<{ delivery_options: { id: string; name: string }[] }>>({
      method: 'GET',
      path: '/logistics/202309/delivery_options',
      query: { shop_cipher: this.shopId || '' },
    });

    if (!result.success) {
      return result as ConnectorResult<{ id: string; name: string }[]>;
    }

    return {
      success: true,
      data: result.data!.data.delivery_options,
    };
  }

  /**
   * Update inventory for a SKU
   */
  async updateInventory(
    productId: string,
    skuId: string,
    quantity: number
  ): Promise<ConnectorResult<{ success: boolean }>> {
    const result = await this.request<TikTokApiResponse<{ success: boolean }>>({
      method: 'PUT',
      path: `/product/202309/products/${productId}/inventory`,
      query: { shop_cipher: this.shopId || '' },
      body: {
        skus: [{ id: skuId, inventory: [{ quantity }] }],
      },
    });

    return result as ConnectorResult<{ success: boolean }>;
  }

  /**
   * Activate/deactivate products
   */
  async setProductStatus(
    productIds: string[],
    active: boolean
  ): Promise<ConnectorResult<{ success: boolean }>> {
    const result = await this.request<TikTokApiResponse<{ success: boolean }>>({
      method: 'POST',
      path: active ? '/product/202309/products/activate' : '/product/202309/products/deactivate',
      query: { shop_cipher: this.shopId || '' },
      body: { product_ids: productIds },
    });

    return result as ConnectorResult<{ success: boolean }>;
  }
}

export default TikTokShopAdapter;
