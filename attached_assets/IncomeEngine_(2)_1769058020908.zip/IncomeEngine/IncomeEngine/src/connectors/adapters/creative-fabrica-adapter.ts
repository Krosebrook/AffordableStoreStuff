/**
 * Creative Fabrica Adapter
 * Digital assets marketplace connector for Creative Fabrica
 *
 * Platform for fonts, graphics, crafts, and digital assets.
 * API: Partner/Seller API with API key authentication
 * Rate Limit: 30 requests/minute
 *
 * Product Categories: Fonts, Graphics, Crafts, SVG, Sublimation, etc.
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  ProductType,
  ProductStatus,
  DateRange,
  PlatformAnalytics,
  RevenueData,
  AssetInput,
  Asset,
  LicenseType,
} from '../core/types';

// Creative Fabrica product categories
export type CreativeFabricaCategory =
  | 'fonts'
  | 'graphics'
  | 'crafts'
  | 'svg'
  | 'sublimation'
  | 'embroidery'
  | 'illustrations'
  | 'patterns'
  | 'mockups'
  | 'templates'
  | 'add-ons'
  | '3d';

// Creative Fabrica license types
export type CreativeFabricaLicense = 'personal' | 'commercial' | 'extended';

// Creative Fabrica font styles
export type FontStyle =
  | 'serif'
  | 'sans-serif'
  | 'script'
  | 'display'
  | 'handwritten'
  | 'decorative'
  | 'monospace';

// Royalty structure by category (approximate percentages)
const CATEGORY_ROYALTIES: Record<CreativeFabricaCategory, { minPrice: number; royaltyPercent: number }> = {
  fonts: { minPrice: 10, royaltyPercent: 50 },
  graphics: { minPrice: 5, royaltyPercent: 50 },
  crafts: { minPrice: 3, royaltyPercent: 50 },
  svg: { minPrice: 2, royaltyPercent: 50 },
  sublimation: { minPrice: 3, royaltyPercent: 50 },
  embroidery: { minPrice: 5, royaltyPercent: 50 },
  illustrations: { minPrice: 5, royaltyPercent: 50 },
  patterns: { minPrice: 5, royaltyPercent: 50 },
  mockups: { minPrice: 8, royaltyPercent: 50 },
  templates: { minPrice: 10, royaltyPercent: 50 },
  'add-ons': { minPrice: 5, royaltyPercent: 50 },
  '3d': { minPrice: 10, royaltyPercent: 50 },
};

export interface CreativeFabricaCredentials {
  apiKey: string;
  sellerId?: string;
}

export interface CreativeFabricaAsset {
  title: string;
  description: string;
  category: CreativeFabricaCategory;
  tags: string[];
  files: Array<{
    name: string;
    url: string;
    format: string;
    size?: number;
  }>;
  previewImages: string[];
  price: number;
  license: CreativeFabricaLicense;
  fontStyles?: FontStyle[];
  compatible?: string[]; // Software compatibility
}

interface CreativeFabricaProduct {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  price: number;
  status: 'pending' | 'approved' | 'rejected' | 'published';
  downloads: number;
  earnings: number;
  created_at: string;
  updated_at: string;
}

interface CreativeFabricaUploadResponse {
  id: string;
  status: string;
  preview_url: string;
  product_url: string;
}

/**
 * Creative Fabrica platform adapter
 * Digital assets marketplace for fonts, graphics, and crafts
 */
export class CreativeFabricaAdapter extends BaseConnector {
  readonly name = 'creative-fabrica';
  readonly displayName = 'Creative Fabrica';
  readonly workflowGroup = 'pod_digital' as const;
  readonly connectorType = 'api_key' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: false,
    supportsBulkOperations: false,
    supportsWebhooks: true,
    supportsInventorySync: false,
    supportsOrderFulfillment: false,
    supportsAnalytics: true,
    maxProductsPerRequest: 1,
    rateLimits: {
      requestsPerMinute: 30,
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 100,
    maxDescriptionLength: 5000,
    maxImages: 10, // Preview images
    maxTags: 30,
    maxVariants: 1, // Single product per upload
    allowedImageFormats: ['jpg', 'jpeg', 'png', 'webp'],
    maxImageSizeMB: 50,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['title', 'description', 'category', 'tags', 'files', 'price'],
    requiredCategories: true,
    requiredShippingProfile: false,
  };

  private baseUrl = 'https://api.creativefabrica.com/v1';

  constructor(config: ConnectorConfig) {
    super({
      ...config,
      baseUrl: 'https://api.creativefabrica.com/v1',
    });
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    const apiKey = this.config.credentials?.apiKey;
    if (!apiKey) {
      return {
        success: false,
        error: this.createError('AUTH_MISSING', 'Creative Fabrica API key is required'),
      };
    }

    // Validate API key by fetching seller profile
    this.authToken = {
      accessToken: apiKey,
      tokenType: 'Bearer',
    };

    // Test authentication
    const result = await this.request<{ success: boolean; seller_id: string }>({
      method: 'GET',
      path: '/seller/profile',
    });

    if (!result.success) {
      this.authToken = null;
      return {
        success: false,
        error: result.error,
      };
    }

    return {
      success: true,
      data: this.authToken,
    };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    if (this.authToken) {
      return { success: true, data: this.authToken };
    }
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    if (!this.config.credentials?.apiKey) {
      return false;
    }
    const result = await this.authenticate();
    return result.success;
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    const page = options?.page ?? 1;
    const limit = options?.limit ?? 20;

    const result = await this.request<{
      products: CreativeFabricaProduct[];
      total: number;
      page: number;
      per_page: number;
    }>({
      method: 'GET',
      path: '/seller/products',
      query: {
        page,
        per_page: limit,
        ...(options?.filters as Record<string, string> | undefined),
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedProducts>;
    }

    const items = result.data!.products.map((p) => this.normalizeProduct(p));

    return {
      success: true,
      data: {
        items,
        total: result.data!.total,
        page: result.data!.page,
        limit: result.data!.per_page,
        hasMore: page * limit < result.data!.total,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    const result = await this.request<CreativeFabricaProduct>({
      method: 'GET',
      path: `/seller/products/${id}`,
    });

    if (!result.success) {
      return result as ConnectorResult<NormalizedProduct>;
    }

    return {
      success: true,
      data: this.normalizeProduct(result.data!),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_FAILED',
          `Product validation failed: ${validation.issues.map((i) => i.message).join(', ')}`,
          false
        ),
      };
    }

    const cfProduct = this.denormalizeProduct({
      ...product,
      id: '',
      externalId: undefined,
      variants: [],
      pricing: { ...product.pricing, currency: 'USD', taxable: true },
      status: 'draft',
      createdAt: new Date(),
      updatedAt: new Date(),
      platformData: {},
      metadata: product.metadata || {},
    } as NormalizedProduct);

    const result = await this.request<CreativeFabricaUploadResponse>({
      method: 'POST',
      path: '/seller/products',
      body: cfProduct,
    });

    if (!result.success) {
      return result as ConnectorResult<CreateResult>;
    }

    return {
      success: true,
      data: {
        id: result.data!.id,
        externalId: result.data!.id,
        externalUrl: result.data!.product_url,
        status: 'pending' as ProductStatus,
      },
    };
  }

  async updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>> {
    const result = await this.request<{ success: boolean }>({
      method: 'PATCH',
      path: `/seller/products/${id}`,
      body: updates,
    });

    if (!result.success) {
      return result as ConnectorResult<UpdateResult>;
    }

    return {
      success: true,
      data: {
        id,
        externalId: id,
        updatedFields: Object.keys(updates),
      },
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    const result = await this.request<{ success: boolean }>({
      method: 'DELETE',
      path: `/seller/products/${id}`,
    });

    if (!result.success) {
      return result as ConnectorResult<DeleteResult>;
    }

    return {
      success: true,
      data: {
        id,
        deleted: true,
      },
    };
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    const result = await this.request<{
      total_revenue: number;
      total_downloads: number;
      products_count: number;
      top_products: Array<{
        id: string;
        title: string;
        downloads: number;
        revenue: number;
      }>;
    }>({
      method: 'GET',
      path: '/seller/analytics',
      query: {
        start_date: dateRange.start.toISOString().split('T')[0],
        end_date: dateRange.end.toISOString().split('T')[0],
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PlatformAnalytics>;
    }

    return {
      success: true,
      data: {
        platform: this.name,
        dateRange,
        revenue: {
          total: result.data!.total_revenue,
          currency: 'USD',
          byDay: [],
          byProduct: result.data!.top_products.map((p) => ({
            productId: p.id,
            title: p.title,
            amount: p.revenue,
          })),
        },
        orderCount: result.data!.total_downloads,
        productCount: result.data!.products_count,
        topProducts: result.data!.top_products.map((p) => ({
          id: p.id,
          title: p.title,
          sales: p.downloads,
          revenue: p.revenue,
        })),
      },
    };
  }

  async getRevenue(dateRange: DateRange): Promise<ConnectorResult<RevenueData>> {
    const analytics = await this.getAnalytics(dateRange);
    if (!analytics.success) {
      return analytics as ConnectorResult<RevenueData>;
    }

    return {
      success: true,
      data: analytics.data!.revenue,
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const cfProduct = platformProduct as CreativeFabricaProduct;

    return {
      id: cfProduct.id,
      externalId: cfProduct.id,
      title: cfProduct.title,
      description: cfProduct.description,
      productType: this.mapCategoryToProductType(cfProduct.category),
      images: [],
      variants: [],
      pricing: {
        price: cfProduct.price,
        currency: 'USD',
        taxable: false,
      },
      tags: cfProduct.tags,
      metadata: {
        category: cfProduct.category,
        downloads: cfProduct.downloads,
        earnings: cfProduct.earnings,
      },
      platformData: cfProduct,
      status: this.mapStatus(cfProduct.status),
      createdAt: new Date(cfProduct.created_at),
      updatedAt: new Date(cfProduct.updated_at),
    };
  }

  denormalizeProduct(product: NormalizedProduct): CreativeFabricaAsset {
    return {
      title: product.title,
      description: product.description,
      category: (product.metadata?.category as CreativeFabricaCategory) || 'graphics',
      tags: product.tags,
      files: [],
      previewImages: product.images.map((i) => i.url),
      price: product.pricing.price,
      license: 'commercial',
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    // Title validation
    if (product.title.length < 5) {
      issues.push(
        this.createValidationIssue('title', 'Title must be at least 5 characters', 'error')
      );
    }
    if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title must be ${this.platformLimits.maxTitleLength} characters or less`,
          'error'
        )
      );
    }

    // Description validation
    if (product.description.length < 50) {
      issues.push(
        this.createValidationIssue(
          'description',
          'Description should be at least 50 characters for better discoverability',
          'warning'
        )
      );
    }

    // Tags validation
    if (!product.tags || product.tags.length < 5) {
      issues.push(
        this.createValidationIssue('tags', 'At least 5 tags are required', 'error')
      );
    }

    // Price validation
    if (product.pricing.price < 1) {
      issues.push(
        this.createValidationIssue('price', 'Price must be at least $1', 'error')
      );
    }

    return {
      valid: !issues.some((i) => i.severity === 'error'),
      issues,
    };
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private mapCategoryToProductType(category: string): ProductType {
    const categoryMap: Record<string, ProductType> = {
      fonts: 'font',
      graphics: 'graphic',
      svg: 'graphic',
      templates: 'template',
      patterns: 'graphic',
    };
    return categoryMap[category] || 'digital-download';
  }

  private mapStatus(status: string): ProductStatus {
    const statusMap: Record<string, ProductStatus> = {
      pending: 'pending',
      approved: 'active',
      published: 'active',
      rejected: 'archived',
    };
    return statusMap[status] || 'draft';
  }

  // ============================================================================
  // Creative Fabrica-Specific Methods
  // ============================================================================

  /**
   * Get all available categories
   */
  getAllCategories(): CreativeFabricaCategory[] {
    return Object.keys(CATEGORY_ROYALTIES) as CreativeFabricaCategory[];
  }

  /**
   * Get royalty info for a category
   */
  getCategoryRoyalties(
    category: CreativeFabricaCategory
  ): { minPrice: number; royaltyPercent: number } {
    return CATEGORY_ROYALTIES[category];
  }

  /**
   * Calculate potential earnings
   */
  calculateEarnings(
    price: number,
    category: CreativeFabricaCategory
  ): { grossRevenue: number; royalty: number; netEarnings: number } {
    const { royaltyPercent } = CATEGORY_ROYALTIES[category];
    const royalty = price * (royaltyPercent / 100);

    return {
      grossRevenue: price,
      royalty,
      netEarnings: royalty,
    };
  }

  /**
   * Get required file formats by category
   */
  getRequiredFormats(category: CreativeFabricaCategory): string[] {
    const formatRequirements: Record<CreativeFabricaCategory, string[]> = {
      fonts: ['ttf', 'otf', 'woff', 'woff2'],
      graphics: ['png', 'jpg', 'eps', 'ai', 'svg'],
      crafts: ['svg', 'png', 'dxf'],
      svg: ['svg'],
      sublimation: ['png', 'jpg'],
      embroidery: ['pes', 'dst', 'jef', 'exp'],
      illustrations: ['png', 'jpg', 'eps', 'ai'],
      patterns: ['png', 'jpg', 'eps', 'ai'],
      mockups: ['psd', 'ai'],
      templates: ['psd', 'ai', 'indd'],
      'add-ons': ['abr', 'asl', 'grd', 'pat'],
      '3d': ['obj', 'fbx', 'stl', 'blend'],
    };

    return formatRequirements[category] || ['png', 'jpg'];
  }

  /**
   * Validate asset before upload
   */
  validateAsset(asset: CreativeFabricaAsset): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (asset.title.length < 5) {
      errors.push('Title must be at least 5 characters');
    }
    if (asset.description.length < 50) {
      errors.push('Description should be at least 50 characters');
    }
    if (asset.tags.length < 5) {
      errors.push('At least 5 tags required');
    }
    if (!asset.files || asset.files.length === 0) {
      errors.push('At least one file is required');
    }
    if (!asset.previewImages || asset.previewImages.length === 0) {
      errors.push('At least one preview image is required');
    }

    const { minPrice } = CATEGORY_ROYALTIES[asset.category];
    if (asset.price < minPrice) {
      errors.push(`Minimum price for ${asset.category} is $${minPrice}`);
    }

    return { valid: errors.length === 0, errors };
  }

  /**
   * Get trending categories
   */
  static getTrendingCategories(): CreativeFabricaCategory[] {
    return ['svg', 'sublimation', 'crafts', 'fonts', 'graphics'];
  }
}

export default CreativeFabricaAdapter;
