/**
 * Printify Adapter
 * POD platform connector for Printify API
 *
 * API Docs: https://developers.printify.com/
 * Auth: API Key (Bearer token)
 * Rate Limit: 100 requests/minute, 5000 requests/hour
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  PrintifyShop,
  PrintProvider,
  ProductType,
  ProductStatus,
  DateRange,
  PlatformAnalytics,
} from '../core/types';
import { mapPlatformError } from '../utils/error-mapper';

// Printify-specific types
interface PrintifyProduct {
  id: string;
  title: string;
  description: string;
  tags: string[];
  options: PrintifyOption[];
  variants: PrintifyVariant[];
  images: PrintifyImage[];
  created_at: string;
  updated_at: string;
  visible: boolean;
  is_locked: boolean;
  blueprint_id: number;
  user_id: number;
  shop_id: number;
  print_provider_id: number;
  print_areas: unknown[];
  print_details: unknown[];
  sales_channel_properties: unknown[];
}

interface PrintifyOption {
  name: string;
  type: string;
  values: { id: number; title: string }[];
}

interface PrintifyVariant {
  id: number;
  sku: string;
  cost: number;
  price: number;
  title: string;
  grams: number;
  is_enabled: boolean;
  is_default: boolean;
  is_available: boolean;
  is_printify_express_eligible: boolean;
  options: number[];
}

interface PrintifyImage {
  src: string;
  variant_ids: number[];
  position: string;
  is_default: boolean;
  is_selected_for_publishing: boolean;
}

interface PrintifyBlueprint {
  id: number;
  title: string;
  description: string;
  brand: string;
  model: string;
  images: string[];
}

interface MockupResult {
  task_id: string;
  status: string;
  result?: { url: string }[];
}

interface PublishResult {
  id: string;
  status: 'published' | 'pending' | 'failed';
  external_id?: string;
  external_url?: string;
}

/**
 * Printify platform adapter
 */
export class PrintifyAdapter extends BaseConnector {
  readonly name = 'printify';
  readonly displayName = 'Printify';
  readonly workflowGroup = 'pod_digital' as const;
  readonly connectorType = 'api_key' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: false,
    supportsBulkOperations: false,
    supportsWebhooks: true,
    supportsInventorySync: false,
    supportsOrderFulfillment: true,
    supportsAnalytics: false, // Printify analytics are limited
    maxProductsPerRequest: 1,
    rateLimits: {
      requestsPerMinute: 100,
      requestsPerHour: 5000,
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 140,
    maxDescriptionLength: 5000,
    maxImages: 10,
    maxTags: 13,
    maxVariants: 100,
    allowedImageFormats: ['jpg', 'jpeg', 'png'],
    maxImageSizeMB: 50,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['title', 'description', 'blueprint_id', 'print_provider_id'],
    requiredImageDimensions: { width: 300, height: 300 }, // Minimum for mockups
    requiredCategories: false,
    requiredShippingProfile: false,
  };

  private baseUrl = 'https://api.printify.com/v1';
  private shopId: string | null = null;

  constructor(config: ConnectorConfig) {
    super({
      ...config,
      baseUrl: 'https://api.printify.com/v1',
    });
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    const apiKey = this.config.credentials?.apiKey;
    if (!apiKey) {
      return {
        success: false,
        error: this.createError('AUTH_MISSING', 'Printify API key is required'),
      };
    }

    // Validate API key by fetching shops
    this.authToken = {
      accessToken: apiKey,
      tokenType: 'Bearer',
    };

    const shopsResult = await this.getShops();
    if (!shopsResult.success) {
      this.authToken = null;
      return {
        success: false,
        error: shopsResult.error,
      };
    }

    // Store first shop ID as default
    if (shopsResult.data && shopsResult.data.length > 0) {
      this.shopId = String(shopsResult.data[0].id);
    }

    return {
      success: true,
      data: this.authToken,
    };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    // API keys don't need refreshing
    if (this.authToken) {
      return { success: true, data: this.authToken };
    }
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    const result = await this.getShops();
    return result.success;
  }

  // ============================================================================
  // Shop Management
  // ============================================================================

  async getShops(): Promise<ConnectorResult<PrintifyShop[]>> {
    return this.request<PrintifyShop[]>({
      method: 'GET',
      path: '/shops.json',
    });
  }

  async setActiveShop(shopId: string): void {
    this.shopId = shopId;
  }

  getActiveShopId(): string | null {
    return this.shopId;
  }

  // ============================================================================
  // Print Providers & Blueprints
  // ============================================================================

  async getPrintProviders(): Promise<ConnectorResult<PrintProvider[]>> {
    return this.request<PrintProvider[]>({
      method: 'GET',
      path: '/catalog/print_providers.json',
    });
  }

  async getBlueprints(): Promise<ConnectorResult<PrintifyBlueprint[]>> {
    return this.request<PrintifyBlueprint[]>({
      method: 'GET',
      path: '/catalog/blueprints.json',
    });
  }

  async getBlueprintProviders(
    blueprintId: number
  ): Promise<ConnectorResult<PrintProvider[]>> {
    return this.request<PrintProvider[]>({
      method: 'GET',
      path: `/catalog/blueprints/${blueprintId}/print_providers.json`,
    });
  }

  async getBlueprintVariants(
    blueprintId: number,
    printProviderId: number
  ): Promise<ConnectorResult<{ variants: PrintifyVariant[] }>> {
    return this.request<{ variants: PrintifyVariant[] }>({
      method: 'GET',
      path: `/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/variants.json`,
    });
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected. Call setActiveShop first.'),
      };
    }

    const page = options?.page || 1;
    const limit = options?.limit || 20;

    const result = await this.request<{ data: PrintifyProduct[]; last_page: number; current_page: number }>({
      method: 'GET',
      path: `/shops/${this.shopId}/products.json`,
      query: { page, limit },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedProducts>;
    }

    return {
      success: true,
      data: {
        items: result.data!.data.map((p) => this.normalizeProduct(p)),
        total: result.data!.last_page * limit, // Approximate
        page: result.data!.current_page,
        limit,
        hasMore: result.data!.current_page < result.data!.last_page,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected'),
      };
    }

    const result = await this.request<PrintifyProduct>({
      method: 'GET',
      path: `/shops/${this.shopId}/products/${id}.json`,
    });

    if (!result.success) {
      return result as ConnectorResult<NormalizedProduct>;
    }

    return {
      success: true,
      data: this.normalizeProduct(result.data!),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected'),
      };
    }

    // Validate product
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_ERROR',
          validation.issues.map((i) => i.message).join('; ')
        ),
      };
    }

    const printifyProduct = this.denormalizeProduct({
      ...product,
      id: '',
      status: 'draft',
      createdAt: new Date(),
      updatedAt: new Date(),
      platformData: {},
      metadata: product.metadata || {},
      tags: product.tags || [],
      images: product.images.map((img, idx) => ({
        ...img,
        id: `img-${idx}`,
      })),
      variants: product.variants?.map((v, idx) => ({
        ...v,
        id: `var-${idx}`,
      })) || [],
      pricing: {
        ...product.pricing,
        currency: product.pricing.currency || 'USD',
      },
    } as NormalizedProduct);

    const result = await this.request<PrintifyProduct>({
      method: 'POST',
      path: `/shops/${this.shopId}/products.json`,
      body: printifyProduct,
    });

    if (!result.success) {
      return result as ConnectorResult<CreateResult>;
    }

    return {
      success: true,
      data: {
        id: result.data!.id,
        externalId: result.data!.id,
        status: result.data!.visible ? 'active' : 'draft',
      },
    };
  }

  async updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected'),
      };
    }

    const updatePayload: Record<string, unknown> = {};
    const updatedFields: string[] = [];

    if (updates.title) {
      updatePayload.title = updates.title;
      updatedFields.push('title');
    }
    if (updates.description) {
      updatePayload.description = updates.description;
      updatedFields.push('description');
    }
    if (updates.tags) {
      updatePayload.tags = updates.tags;
      updatedFields.push('tags');
    }

    const result = await this.request<PrintifyProduct>({
      method: 'PUT',
      path: `/shops/${this.shopId}/products/${id}.json`,
      body: updatePayload,
    });

    if (!result.success) {
      return result as ConnectorResult<UpdateResult>;
    }

    return {
      success: true,
      data: {
        id,
        externalId: id,
        updatedFields,
      },
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<{ id: string; deleted: boolean }>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected'),
      };
    }

    const result = await this.request<void>({
      method: 'DELETE',
      path: `/shops/${this.shopId}/products/${id}.json`,
    });

    return {
      success: result.success,
      data: { id, deleted: result.success },
      error: result.error,
    };
  }

  // ============================================================================
  // Mockups
  // ============================================================================

  async generateMockup(productId: string): Promise<ConnectorResult<MockupResult>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected'),
      };
    }

    // Start mockup generation
    const result = await this.request<{ task_id: string }>({
      method: 'POST',
      path: `/shops/${this.shopId}/products/${productId}/mockup-generation.json`,
    });

    if (!result.success) {
      return result as ConnectorResult<MockupResult>;
    }

    // Poll for completion
    const taskId = result.data!.task_id;
    let attempts = 0;
    const maxAttempts = 30;

    while (attempts < maxAttempts) {
      await this.sleep(2000); // Wait 2 seconds between polls

      const statusResult = await this.request<MockupResult>({
        method: 'GET',
        path: `/shops/${this.shopId}/products/${productId}/mockup-generation/${taskId}.json`,
      });

      if (!statusResult.success) {
        return statusResult;
      }

      if (statusResult.data!.status === 'completed') {
        return {
          success: true,
          data: statusResult.data!,
        };
      }

      if (statusResult.data!.status === 'failed') {
        return {
          success: false,
          error: this.createError('MOCKUP_FAILED', 'Mockup generation failed'),
        };
      }

      attempts++;
    }

    return {
      success: false,
      error: this.createError('TIMEOUT', 'Mockup generation timed out'),
    };
  }

  // ============================================================================
  // Publishing
  // ============================================================================

  async publishToShop(productId: string): Promise<ConnectorResult<PublishResult>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected'),
      };
    }

    const result = await this.request<{ id: string }>({
      method: 'POST',
      path: `/shops/${this.shopId}/products/${productId}/publish.json`,
      body: {
        title: true,
        description: true,
        images: true,
        variants: true,
        tags: true,
        keyFeatures: true,
        shipping_template: true,
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PublishResult>;
    }

    return {
      success: true,
      data: {
        id: productId,
        status: 'published',
        external_id: result.data!.id,
      },
    };
  }

  async unpublishFromShop(productId: string): Promise<ConnectorResult<void>> {
    if (!this.shopId) {
      return {
        success: false,
        error: this.createError('NO_SHOP', 'No shop selected'),
      };
    }

    return this.request<void>({
      method: 'POST',
      path: `/shops/${this.shopId}/products/${productId}/unpublish.json`,
    });
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const p = platformProduct as PrintifyProduct;

    return {
      id: p.id,
      externalId: p.id,
      title: p.title,
      description: p.description,
      productType: this.mapBlueprintToProductType(p.blueprint_id),
      images: p.images.map((img, idx) => ({
        id: `${p.id}-img-${idx}`,
        url: img.src,
        position: idx,
        isPrimary: img.is_default,
      })),
      variants: p.variants.map((v) => ({
        id: String(v.id),
        sku: v.sku,
        title: v.title,
        price: v.price / 100, // Convert cents to dollars
        inventoryQuantity: v.is_available ? 999 : 0, // Printify doesn't track inventory
        options: { option: v.options.map(String).join(', ') },
        weight: v.grams,
        weightUnit: 'g',
      })),
      pricing: {
        price: p.variants[0]?.price ? p.variants[0].price / 100 : 0,
        currency: 'USD',
        costPerItem: p.variants[0]?.cost ? p.variants[0].cost / 100 : undefined,
        taxable: true,
      },
      tags: p.tags,
      metadata: {
        blueprint_id: p.blueprint_id,
        print_provider_id: p.print_provider_id,
        shop_id: p.shop_id,
      },
      platformData: {
        visible: p.visible,
        is_locked: p.is_locked,
        print_areas: p.print_areas,
      },
      status: p.visible ? 'active' : 'draft',
      createdAt: new Date(p.created_at),
      updatedAt: new Date(p.updated_at),
    };
  }

  denormalizeProduct(product: NormalizedProduct): unknown {
    return {
      title: product.title,
      description: product.description,
      tags: product.tags || [],
      blueprint_id: product.metadata?.blueprint_id,
      print_provider_id: product.metadata?.print_provider_id,
      variants: product.variants.map((v) => ({
        id: parseInt(v.id, 10) || undefined,
        price: Math.round(v.price * 100), // Convert to cents
        is_enabled: true,
      })),
      print_areas: product.platformData?.print_areas || [],
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    // Check required fields
    if (!product.title) {
      issues.push(this.createValidationIssue('title', 'Title is required', 'error'));
    } else if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title exceeds ${this.platformLimits.maxTitleLength} characters`,
          'error'
        )
      );
    }

    if (!product.description) {
      issues.push(this.createValidationIssue('description', 'Description is required', 'error'));
    } else if (product.description.length > this.platformLimits.maxDescriptionLength) {
      issues.push(
        this.createValidationIssue(
          'description',
          `Description exceeds ${this.platformLimits.maxDescriptionLength} characters`,
          'warning',
          'Description will be truncated'
        )
      );
    }

    // Check tags
    if (product.tags && product.tags.length > this.platformLimits.maxTags) {
      issues.push(
        this.createValidationIssue(
          'tags',
          `Too many tags (max ${this.platformLimits.maxTags})`,
          'warning',
          'Extra tags will be ignored'
        )
      );
    }

    // Check metadata for required Printify fields
    if (!product.metadata?.blueprint_id) {
      issues.push(
        this.createValidationIssue(
          'metadata.blueprint_id',
          'Blueprint ID is required for Printify',
          'error',
          'Select a product template (blueprint) first'
        )
      );
    }

    if (!product.metadata?.print_provider_id) {
      issues.push(
        this.createValidationIssue(
          'metadata.print_provider_id',
          'Print provider ID is required for Printify',
          'error',
          'Select a print provider for this blueprint'
        )
      );
    }

    // Check images
    if (!product.images || product.images.length === 0) {
      issues.push(
        this.createValidationIssue(
          'images',
          'At least one image is required',
          'error'
        )
      );
    }

    return {
      valid: issues.filter((i) => i.severity === 'error').length === 0,
      issues,
    };
  }

  // ============================================================================
  // Helpers
  // ============================================================================

  private mapBlueprintToProductType(blueprintId: number): ProductType {
    // Map common Printify blueprint IDs to product types
    const mapping: Record<number, ProductType> = {
      6: 't-shirt', // Unisex Jersey Short Sleeve Tee
      9: 'hoodie', // Unisex Heavy Blend Hooded Sweatshirt
      88: 'mug', // White Glossy Mug
      12: 'poster', // Enhanced Matte Paper Poster
      23: 'sticker', // Sticker
      37: 'phone-case', // iPhone Case
      66: 'tote-bag', // Tote Bag
    };

    return mapping[blueprintId] || 'other';
  }

  protected override mapPlatformError(status: number, data: unknown) {
    return mapPlatformError('printify', status, data);
  }
}

export default PrintifyAdapter;
