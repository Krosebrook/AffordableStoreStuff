/**
 * Abstract base class for all platform connectors
 * Provides common functionality and enforces consistent interface
 */

import {
  ConnectorCapabilities,
  ConnectorResult,
  ConnectorError,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  BulkResult,
  ListOptions,
  PaginatedProducts,
  PaginatedOrders,
  Order,
  TrackingInfo,
  Fulfillment,
  DateRange,
  PlatformAnalytics,
  RevenueData,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  WorkflowGroup,
  ConnectorType,
  RateLimitInfo,
} from './types';

export interface ConnectorConfig {
  platform: string;
  credentials?: Record<string, string>;
  baseUrl?: string;
  timeout?: number;
  maxRetries?: number;
  debug?: boolean;
}

export interface RequestOptions {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  body?: unknown;
  query?: Record<string, string | number | boolean>;
  headers?: Record<string, string>;
  timeout?: number;
}

/**
 * Abstract base class for platform connectors
 * All adapters must extend this class
 */
export abstract class BaseConnector {
  // Identity - must be implemented by each adapter
  abstract readonly name: string;
  abstract readonly displayName: string;
  abstract readonly workflowGroup: WorkflowGroup;
  abstract readonly connectorType: ConnectorType;
  abstract readonly capabilities: ConnectorCapabilities;
  abstract readonly platformLimits: PlatformLimits;
  abstract readonly platformRequirements: PlatformRequirements;

  // Configuration
  protected config: ConnectorConfig;
  protected authToken: AuthToken | null = null;
  protected rateLimitInfo: RateLimitInfo | null = null;
  protected lastRequestTime: number = 0;

  constructor(config: ConnectorConfig) {
    this.config = {
      timeout: 30000,
      maxRetries: 3,
      debug: false,
      ...config,
    };
  }

  // ============================================================================
  // Authentication (abstract - must be implemented)
  // ============================================================================

  /**
   * Authenticate with the platform
   * Returns auth token on success
   */
  abstract authenticate(): Promise<ConnectorResult<AuthToken>>;

  /**
   * Refresh authentication token
   * Only applicable for OAuth connectors
   */
  abstract refreshAuth(): Promise<ConnectorResult<AuthToken>>;

  /**
   * Validate current credentials
   * Returns true if credentials are valid and not expired
   */
  abstract validateCredentials(): Promise<boolean>;

  // ============================================================================
  // Product Operations (abstract - must be implemented)
  // ============================================================================

  /**
   * List products from the platform
   */
  abstract listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>>;

  /**
   * Get a single product by ID
   */
  abstract getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>>;

  /**
   * Create a new product on the platform
   */
  abstract createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>>;

  /**
   * Update an existing product
   */
  abstract updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>>;

  /**
   * Delete a product from the platform
   */
  abstract deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>>;

  // ============================================================================
  // Normalization (abstract - must be implemented)
  // ============================================================================

  /**
   * Convert platform-specific product to normalized format
   */
  abstract normalizeProduct(platformProduct: unknown): NormalizedProduct;

  /**
   * Convert normalized product to platform-specific format
   */
  abstract denormalizeProduct(product: NormalizedProduct): unknown;

  /**
   * Validate product for platform-specific requirements
   */
  abstract validateProductForPlatform(product: ProductInput): ValidationResult;

  // ============================================================================
  // Optional Operations (default implementations, can be overridden)
  // ============================================================================

  /**
   * Bulk create products
   * Default implementation calls createProduct in sequence
   */
  async bulkCreateProducts(products: ProductInput[]): Promise<ConnectorResult<BulkResult>> {
    if (!this.capabilities.supportsBulkOperations) {
      // Fallback to sequential creation
      const results: BulkResult['results'] = [];
      let successful = 0;
      let failed = 0;

      for (const product of products) {
        const result = await this.createProduct(product);
        if (result.success && result.data) {
          results.push({ id: result.data.id, success: true });
          successful++;
        } else {
          results.push({
            id: '',
            success: false,
            error: result.error,
          });
          failed++;
        }
      }

      return {
        success: failed === 0,
        data: {
          total: products.length,
          successful,
          failed,
          results,
        },
      };
    }

    // Subclasses with native bulk support should override this
    return this.bulkCreateProducts(products);
  }

  /**
   * List orders from the platform
   * Only implemented by marketplace connectors
   */
  async listOrders(_options?: ListOptions): Promise<ConnectorResult<PaginatedOrders>> {
    if (!this.capabilities.supportsOrderFulfillment) {
      return {
        success: false,
        error: this.createError(
          'NOT_SUPPORTED',
          `${this.displayName} does not support order management`
        ),
      };
    }
    // Subclasses should override
    throw new Error('listOrders must be implemented by marketplace connectors');
  }

  /**
   * Get order by ID
   */
  async getOrder(_orderId: string): Promise<ConnectorResult<Order>> {
    if (!this.capabilities.supportsOrderFulfillment) {
      return {
        success: false,
        error: this.createError(
          'NOT_SUPPORTED',
          `${this.displayName} does not support order management`
        ),
      };
    }
    throw new Error('getOrder must be implemented by marketplace connectors');
  }

  /**
   * Fulfill an order with tracking information
   */
  async fulfillOrder(
    _orderId: string,
    _tracking: TrackingInfo
  ): Promise<ConnectorResult<Fulfillment>> {
    if (!this.capabilities.supportsOrderFulfillment) {
      return {
        success: false,
        error: this.createError(
          'NOT_SUPPORTED',
          `${this.displayName} does not support order fulfillment`
        ),
      };
    }
    throw new Error('fulfillOrder must be implemented by marketplace connectors');
  }

  /**
   * Get analytics for the platform
   */
  async getAnalytics(_dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    if (!this.capabilities.supportsAnalytics) {
      return {
        success: false,
        error: this.createError(
          'NOT_SUPPORTED',
          `${this.displayName} does not support analytics`
        ),
      };
    }
    throw new Error('getAnalytics must be implemented by connectors with analytics support');
  }

  /**
   * Get revenue data for the platform
   */
  async getRevenue(_dateRange: DateRange): Promise<ConnectorResult<RevenueData>> {
    if (!this.capabilities.supportsAnalytics) {
      return {
        success: false,
        error: this.createError(
          'NOT_SUPPORTED',
          `${this.displayName} does not support revenue tracking`
        ),
      };
    }
    throw new Error('getRevenue must be implemented by connectors with analytics support');
  }

  // ============================================================================
  // Helper Methods (protected - available to subclasses)
  // ============================================================================

  /**
   * Make an HTTP request with retry and rate limiting
   */
  protected async request<T>(options: RequestOptions): Promise<ConnectorResult<T>> {
    // Apply rate limiting
    await this.applyRateLimit();

    let lastError: ConnectorError | undefined;
    const maxRetries = this.config.maxRetries ?? 3;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const response = await this.executeRequest<T>(options);

        // Update rate limit info from response headers
        this.updateRateLimitInfo(response);

        if (response.success) {
          return response;
        }

        lastError = response.error;

        // Check if error is retryable
        if (!response.error?.retryable) {
          return response;
        }

        // Wait before retry with exponential backoff
        if (attempt < maxRetries) {
          const delay = this.calculateRetryDelay(attempt, response.retryAfter);
          await this.sleep(delay);
        }
      } catch (error) {
        lastError = this.mapError(error);
        if (!lastError.retryable || attempt >= maxRetries) {
          return { success: false, error: lastError };
        }
        await this.sleep(this.calculateRetryDelay(attempt));
      }
    }

    return {
      success: false,
      error: lastError ?? this.createError('MAX_RETRIES', 'Maximum retries exceeded'),
    };
  }

  /**
   * Execute the actual HTTP request
   * Should be overridden by subclasses for platform-specific implementations
   */
  protected async executeRequest<T>(options: RequestOptions): Promise<ConnectorResult<T>> {
    const url = this.buildUrl(options.path, options.query);
    const headers = this.buildHeaders(options.headers);

    const fetchOptions: RequestInit = {
      method: options.method,
      headers,
    };

    if (options.body) {
      fetchOptions.body = JSON.stringify(options.body);
    }

    try {
      const response = await fetch(url, fetchOptions);
      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: this.mapPlatformError(response.status, data),
          rateLimitInfo: this.extractRateLimitInfo(response),
        };
      }

      return {
        success: true,
        data: data as T,
        rateLimitInfo: this.extractRateLimitInfo(response),
      };
    } catch (error) {
      return {
        success: false,
        error: this.mapError(error),
      };
    }
  }

  /**
   * Build full URL with base URL and query parameters
   */
  protected buildUrl(path: string, query?: Record<string, string | number | boolean>): string {
    const baseUrl = this.config.baseUrl ?? '';
    const url = new URL(path, baseUrl);

    if (query) {
      Object.entries(query).forEach(([key, value]) => {
        url.searchParams.set(key, String(value));
      });
    }

    return url.toString();
  }

  /**
   * Build request headers with authentication
   */
  protected buildHeaders(customHeaders?: Record<string, string>): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...customHeaders,
    };

    // Add auth header if we have a token
    if (this.authToken) {
      headers['Authorization'] = `${this.authToken.tokenType} ${this.authToken.accessToken}`;
    }

    return headers;
  }

  /**
   * Apply rate limiting before making a request
   */
  protected async applyRateLimit(): Promise<void> {
    const limits = this.capabilities.rateLimits;
    if (!limits) return;

    const now = Date.now();
    let minDelay = 0;

    if (limits.requestsPerSecond) {
      minDelay = Math.max(minDelay, 1000 / limits.requestsPerSecond);
    }
    if (limits.requestsPerMinute) {
      minDelay = Math.max(minDelay, 60000 / limits.requestsPerMinute);
    }

    const elapsed = now - this.lastRequestTime;
    if (elapsed < minDelay) {
      await this.sleep(minDelay - elapsed);
    }

    this.lastRequestTime = Date.now();
  }

  /**
   * Calculate retry delay with exponential backoff
   */
  protected calculateRetryDelay(attempt: number, retryAfter?: number): number {
    if (retryAfter) {
      return retryAfter * 1000;
    }
    // Exponential backoff: 1s, 2s, 4s, 8s...
    return Math.min(1000 * Math.pow(2, attempt), 30000);
  }

  /**
   * Extract rate limit info from response headers
   */
  protected extractRateLimitInfo(response: Response): RateLimitInfo | undefined {
    const limit = response.headers.get('X-RateLimit-Limit');
    const remaining = response.headers.get('X-RateLimit-Remaining');
    const reset = response.headers.get('X-RateLimit-Reset');

    if (limit && remaining) {
      return {
        limit: parseInt(limit, 10),
        remaining: parseInt(remaining, 10),
        resetAt: reset ? new Date(parseInt(reset, 10) * 1000) : new Date(),
      };
    }

    return undefined;
  }

  /**
   * Update stored rate limit info
   */
  protected updateRateLimitInfo(response: ConnectorResult<unknown>): void {
    if (response.rateLimitInfo) {
      this.rateLimitInfo = response.rateLimitInfo;
    }
  }

  /**
   * Map platform-specific error to ConnectorError
   * Should be overridden for platform-specific error codes
   */
  protected mapPlatformError(status: number, data: unknown): ConnectorError {
    const message = typeof data === 'object' && data !== null
      ? (data as Record<string, unknown>).message || (data as Record<string, unknown>).error || 'Unknown error'
      : String(data);

    return {
      code: `HTTP_${status}`,
      message: String(message),
      platformCode: String(status),
      retryable: status >= 500 || status === 429,
      details: { status, data },
    };
  }

  /**
   * Map JavaScript error to ConnectorError
   */
  protected mapError(error: unknown): ConnectorError {
    if (error instanceof Error) {
      return {
        code: 'NETWORK_ERROR',
        message: error.message,
        retryable: true,
        details: { name: error.name, stack: error.stack },
      };
    }
    return {
      code: 'UNKNOWN_ERROR',
      message: String(error),
      retryable: false,
    };
  }

  /**
   * Create a ConnectorError
   */
  protected createError(
    code: string,
    message: string,
    retryable = false,
    details?: Record<string, unknown>
  ): ConnectorError {
    return { code, message, retryable, details };
  }

  /**
   * Create a validation issue
   */
  protected createValidationIssue(
    field: string,
    message: string,
    severity: 'error' | 'warning' = 'error',
    suggestion?: string
  ): ValidationIssue {
    return { field, message, severity, suggestion };
  }

  /**
   * Sleep for specified milliseconds
   */
  protected sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Log operation for debugging
   */
  protected log(level: 'debug' | 'info' | 'warn' | 'error', message: string, data?: unknown): void {
    if (!this.config.debug && level === 'debug') return;

    const prefix = `[${this.name}]`;
    const logData = data ? JSON.stringify(data, null, 2) : '';

    switch (level) {
      case 'debug':
        console.debug(`${prefix} ${message}`, logData);
        break;
      case 'info':
        console.info(`${prefix} ${message}`, logData);
        break;
      case 'warn':
        console.warn(`${prefix} ${message}`, logData);
        break;
      case 'error':
        console.error(`${prefix} ${message}`, logData);
        break;
    }
  }

  // ============================================================================
  // Utility Methods
  // ============================================================================

  /**
   * Check if connector is authenticated
   */
  isAuthenticated(): boolean {
    if (!this.authToken) return false;
    if (this.authToken.expiresAt && this.authToken.expiresAt < new Date()) {
      return false;
    }
    return true;
  }

  /**
   * Get current rate limit status
   */
  getRateLimitStatus(): RateLimitInfo | null {
    return this.rateLimitInfo;
  }

  /**
   * Get platform limits
   */
  getPlatformLimits(): PlatformLimits {
    return this.platformLimits;
  }

  /**
   * Get platform requirements
   */
  getPlatformRequirements(): PlatformRequirements {
    return this.platformRequirements;
  }

  /**
   * Validate product against platform limits
   */
  validateAgainstLimits(product: ProductInput): ValidationIssue[] {
    const issues: ValidationIssue[] = [];
    const limits = this.platformLimits;

    if (product.title.length > limits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title exceeds maximum length of ${limits.maxTitleLength} characters`,
          'error',
          `Shorten title to ${limits.maxTitleLength} characters or less`
        )
      );
    }

    if (product.description.length > limits.maxDescriptionLength) {
      issues.push(
        this.createValidationIssue(
          'description',
          `Description exceeds maximum length of ${limits.maxDescriptionLength} characters`,
          'error',
          `Shorten description to ${limits.maxDescriptionLength} characters or less`
        )
      );
    }

    if (product.images.length > limits.maxImages) {
      issues.push(
        this.createValidationIssue(
          'images',
          `Too many images. Maximum allowed: ${limits.maxImages}`,
          'error'
        )
      );
    }

    if (product.tags && product.tags.length > limits.maxTags) {
      issues.push(
        this.createValidationIssue(
          'tags',
          `Too many tags. Maximum allowed: ${limits.maxTags}`,
          'warning',
          `Remove ${product.tags.length - limits.maxTags} tags`
        )
      );
    }

    if (product.variants && product.variants.length > limits.maxVariants) {
      issues.push(
        this.createValidationIssue(
          'variants',
          `Too many variants. Maximum allowed: ${limits.maxVariants}`,
          'error'
        )
      );
    }

    return issues;
  }
}

export default BaseConnector;
