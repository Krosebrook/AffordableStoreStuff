/**
 * Bulk Processor
 * Handles batch operations for products across platforms
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  BaseConnector,
  ConnectorConfig,
} from './base-connector';
import {
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ConnectorResult,
  ConnectorError,
} from './types';
import { createConnector, ConnectorName } from '../index';

// ============================================================================
// Types
// ============================================================================

export interface BulkOperation {
  id: string;
  type: 'create' | 'update' | 'delete';
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'partial' | 'cancelled';
  platforms: ConnectorName[];
  items: BulkOperationItem[];
  options: BulkOperationOptions;
  progress: BulkProgress;
  result?: BulkOperationResult;
  createdAt: Date;
  updatedAt: Date;
  completedAt?: Date;
}

export interface BulkOperationItem {
  id: string;
  productId?: string;
  data: ProductInput | Partial<ProductInput>;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'skipped';
  platformResults: Map<ConnectorName, ItemPlatformResult>;
  error?: ConnectorError;
}

export interface ItemPlatformResult {
  platform: ConnectorName;
  success: boolean;
  externalId?: string;
  externalUrl?: string;
  error?: ConnectorError;
  duration: number;
}

export interface BulkOperationOptions {
  batchSize: number;
  concurrency: number;
  continueOnError: boolean;
  rollbackOnFailure: boolean;
  dryRun: boolean;
  validateBeforeProcess: boolean;
  notifyOnProgress: boolean;
  notifyOnCompletion: boolean;
  retryFailedItems: boolean;
  maxRetries: number;
}

export interface BulkProgress {
  total: number;
  processed: number;
  successful: number;
  failed: number;
  skipped: number;
  currentBatch: number;
  totalBatches: number;
  percent: number;
  estimatedTimeRemaining?: number;
  startedAt?: Date;
  currentItem?: string;
}

export interface BulkOperationResult {
  success: boolean;
  total: number;
  successful: number;
  failed: number;
  skipped: number;
  duration: number;
  rollbackPerformed: boolean;
  items: BulkItemResult[];
  errors: BulkError[];
}

export interface BulkItemResult {
  itemId: string;
  productId?: string;
  success: boolean;
  platforms: ItemPlatformResult[];
}

export interface BulkError {
  itemId: string;
  platform?: ConnectorName;
  code: string;
  message: string;
  recoverable: boolean;
}

// ============================================================================
// Default Options
// ============================================================================

const DEFAULT_OPTIONS: BulkOperationOptions = {
  batchSize: 10,
  concurrency: 3,
  continueOnError: true,
  rollbackOnFailure: false,
  dryRun: false,
  validateBeforeProcess: true,
  notifyOnProgress: true,
  notifyOnCompletion: true,
  retryFailedItems: true,
  maxRetries: 2,
};

// ============================================================================
// Bulk Processor Class
// ============================================================================

export class BulkProcessor extends EventEmitter {
  private supabase: SupabaseClient;
  private connectors: Map<ConnectorName, BaseConnector>;
  private activeOperations: Map<string, BulkOperation>;
  private rollbackStack: Map<string, RollbackAction[]>;

  constructor(supabaseUrl: string, supabaseKey: string) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.connectors = new Map();
    this.activeOperations = new Map();
    this.rollbackStack = new Map();
  }

  // ============================================================================
  // Bulk Create
  // ============================================================================

  /**
   * Create multiple products across platforms
   */
  async bulkCreate(
    products: ProductInput[],
    platforms: ConnectorName[],
    options: Partial<BulkOperationOptions> = {}
  ): Promise<BulkOperation> {
    const opts = { ...DEFAULT_OPTIONS, ...options };
    const operation = this.createOperation('create', platforms, products, opts);

    this.activeOperations.set(operation.id, operation);
    await this.saveOperation(operation);

    // Start processing
    this.processOperation(operation).catch((error) => {
      console.error(`Bulk create operation ${operation.id} failed:`, error);
    });

    return operation;
  }

  // ============================================================================
  // Bulk Update
  // ============================================================================

  /**
   * Update multiple products across platforms
   */
  async bulkUpdate(
    updates: Array<{ productId: string; data: Partial<ProductInput> }>,
    platforms: ConnectorName[],
    options: Partial<BulkOperationOptions> = {}
  ): Promise<BulkOperation> {
    const opts = { ...DEFAULT_OPTIONS, ...options };

    const items: BulkOperationItem[] = updates.map((u) => ({
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      productId: u.productId,
      data: u.data,
      status: 'pending' as const,
      platformResults: new Map(),
    }));

    const operation: BulkOperation = {
      id: `bulk-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'update',
      status: 'pending',
      platforms,
      items,
      options: opts,
      progress: this.initializeProgress(items.length, opts.batchSize),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.activeOperations.set(operation.id, operation);
    await this.saveOperation(operation);

    this.processOperation(operation).catch((error) => {
      console.error(`Bulk update operation ${operation.id} failed:`, error);
    });

    return operation;
  }

  // ============================================================================
  // Bulk Delete
  // ============================================================================

  /**
   * Delete multiple products across platforms
   */
  async bulkDelete(
    productIds: string[],
    platforms: ConnectorName[],
    options: Partial<BulkOperationOptions> = {}
  ): Promise<BulkOperation> {
    const opts = { ...DEFAULT_OPTIONS, ...options };

    const items: BulkOperationItem[] = productIds.map((id) => ({
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      productId: id,
      data: {} as ProductInput,
      status: 'pending' as const,
      platformResults: new Map(),
    }));

    const operation: BulkOperation = {
      id: `bulk-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: 'delete',
      status: 'pending',
      platforms,
      items,
      options: opts,
      progress: this.initializeProgress(items.length, opts.batchSize),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.activeOperations.set(operation.id, operation);
    await this.saveOperation(operation);

    this.processOperation(operation).catch((error) => {
      console.error(`Bulk delete operation ${operation.id} failed:`, error);
    });

    return operation;
  }

  // ============================================================================
  // Operation Management
  // ============================================================================

  /**
   * Get operation status
   */
  getOperation(operationId: string): BulkOperation | undefined {
    return this.activeOperations.get(operationId);
  }

  /**
   * Cancel an operation
   */
  async cancelOperation(operationId: string): Promise<boolean> {
    const operation = this.activeOperations.get(operationId);
    if (!operation || operation.status === 'completed') {
      return false;
    }

    operation.status = 'cancelled';
    operation.updatedAt = new Date();
    await this.saveOperation(operation);

    // Perform rollback if needed
    if (operation.options.rollbackOnFailure) {
      await this.performRollback(operation);
    }

    this.emit('operation:cancelled', { operation });

    return true;
  }

  /**
   * Retry failed items in an operation
   */
  async retryFailed(operationId: string): Promise<BulkOperation | null> {
    const operation = this.activeOperations.get(operationId);
    if (!operation) {
      return null;
    }

    // Get failed items
    const failedItems = operation.items.filter((i) => i.status === 'failed');
    if (failedItems.length === 0) {
      return operation;
    }

    // Reset failed items
    failedItems.forEach((item) => {
      item.status = 'pending';
      item.error = undefined;
      item.platformResults.clear();
    });

    operation.status = 'processing';
    operation.progress.processed -= failedItems.length;
    operation.progress.failed = 0;
    operation.updatedAt = new Date();

    await this.saveOperation(operation);

    // Reprocess
    this.processOperation(operation).catch((error) => {
      console.error(`Retry operation ${operation.id} failed:`, error);
    });

    return operation;
  }

  // ============================================================================
  // Private Processing Methods
  // ============================================================================

  private createOperation(
    type: BulkOperation['type'],
    platforms: ConnectorName[],
    products: ProductInput[],
    options: BulkOperationOptions
  ): BulkOperation {
    const items: BulkOperationItem[] = products.map((product) => ({
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      data: product,
      status: 'pending' as const,
      platformResults: new Map(),
    }));

    return {
      id: `bulk-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      status: 'pending',
      platforms,
      items,
      options,
      progress: this.initializeProgress(items.length, options.batchSize),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }

  private initializeProgress(total: number, batchSize: number): BulkProgress {
    return {
      total,
      processed: 0,
      successful: 0,
      failed: 0,
      skipped: 0,
      currentBatch: 0,
      totalBatches: Math.ceil(total / batchSize),
      percent: 0,
    };
  }

  private async processOperation(operation: BulkOperation): Promise<void> {
    const startTime = Date.now();
    operation.status = 'processing';
    operation.progress.startedAt = new Date();
    await this.saveOperation(operation);

    this.emit('operation:started', { operation });

    const errors: BulkError[] = [];
    const results: BulkItemResult[] = [];

    // Validate if needed
    if (operation.options.validateBeforeProcess && operation.type !== 'delete') {
      const validationErrors = await this.validateItems(operation);
      if (validationErrors.length > 0 && !operation.options.continueOnError) {
        operation.status = 'failed';
        operation.result = {
          success: false,
          total: operation.items.length,
          successful: 0,
          failed: validationErrors.length,
          skipped: operation.items.length - validationErrors.length,
          duration: Date.now() - startTime,
          rollbackPerformed: false,
          items: [],
          errors: validationErrors,
        };
        await this.saveOperation(operation);
        this.emit('operation:completed', { operation });
        return;
      }
    }

    // Initialize connectors
    await this.initializeConnectors(operation.platforms);

    // Process in batches
    const batches = this.createBatches(operation.items, operation.options.batchSize);

    for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
      if (operation.status === 'cancelled') {
        break;
      }

      operation.progress.currentBatch = batchIndex + 1;
      await this.processBatch(operation, batches[batchIndex], results, errors);

      // Update progress
      this.updateProgress(operation);
      await this.saveOperation(operation);

      if (operation.options.notifyOnProgress) {
        this.emit('operation:progress', { operation });
      }
    }

    // Finalize
    operation.completedAt = new Date();
    operation.status =
      operation.progress.failed > 0
        ? operation.progress.successful === 0
          ? 'failed'
          : 'partial'
        : 'completed';

    operation.result = {
      success: operation.progress.failed === 0,
      total: operation.items.length,
      successful: operation.progress.successful,
      failed: operation.progress.failed,
      skipped: operation.progress.skipped,
      duration: Date.now() - startTime,
      rollbackPerformed: false,
      items: results,
      errors,
    };

    // Rollback if needed
    if (operation.options.rollbackOnFailure && operation.progress.failed > 0) {
      await this.performRollback(operation);
      operation.result.rollbackPerformed = true;
    }

    await this.saveOperation(operation);

    if (operation.options.notifyOnCompletion) {
      this.emit('operation:completed', { operation });
    }

    this.activeOperations.delete(operation.id);
  }

  private async processBatch(
    operation: BulkOperation,
    batch: BulkOperationItem[],
    results: BulkItemResult[],
    errors: BulkError[]
  ): Promise<void> {
    const concurrency = operation.options.concurrency;

    // Process items with concurrency limit
    const chunks = this.createBatches(batch, concurrency);

    for (const chunk of chunks) {
      if (operation.status === 'cancelled') break;

      await Promise.all(
        chunk.map((item) => this.processItem(operation, item, results, errors))
      );
    }
  }

  private async processItem(
    operation: BulkOperation,
    item: BulkOperationItem,
    results: BulkItemResult[],
    errors: BulkError[]
  ): Promise<void> {
    item.status = 'processing';
    operation.progress.currentItem = item.id;

    const itemResult: BulkItemResult = {
      itemId: item.id,
      productId: item.productId,
      success: true,
      platforms: [],
    };

    for (const platform of operation.platforms) {
      if (operation.status === 'cancelled') break;

      const startTime = Date.now();
      let result: ConnectorResult<CreateResult | UpdateResult | DeleteResult>;

      try {
        const connector = this.connectors.get(platform);
        if (!connector) {
          throw new Error(`Connector not found: ${platform}`);
        }

        if (operation.options.dryRun) {
          // Dry run - just validate
          result = { success: true, data: { id: 'dry-run' } as CreateResult };
        } else {
          // Execute actual operation
          result = await this.executeOperation(
            operation.type,
            connector,
            item.data as ProductInput,
            item.productId
          );
        }

        const platformResult: ItemPlatformResult = {
          platform,
          success: result.success,
          externalId: result.success ? (result.data as CreateResult)?.externalId : undefined,
          externalUrl: result.success ? (result.data as CreateResult)?.externalUrl : undefined,
          error: result.error,
          duration: Date.now() - startTime,
        };

        item.platformResults.set(platform, platformResult);
        itemResult.platforms.push(platformResult);

        // Track for rollback
        if (
          result.success &&
          operation.options.rollbackOnFailure &&
          operation.type === 'create'
        ) {
          this.addRollbackAction(operation.id, {
            type: 'delete',
            platform,
            externalId: (result.data as CreateResult).externalId,
          });
        }

        if (!result.success) {
          itemResult.success = false;
          errors.push({
            itemId: item.id,
            platform,
            code: result.error?.code || 'UNKNOWN',
            message: result.error?.message || 'Unknown error',
            recoverable: result.error?.retryable || false,
          });
        }
      } catch (error) {
        const platformResult: ItemPlatformResult = {
          platform,
          success: false,
          error: {
            code: 'PROCESSING_ERROR',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
          duration: Date.now() - startTime,
        };

        item.platformResults.set(platform, platformResult);
        itemResult.platforms.push(platformResult);
        itemResult.success = false;

        errors.push({
          itemId: item.id,
          platform,
          code: 'PROCESSING_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
          recoverable: true,
        });
      }
    }

    // Update item status
    item.status = itemResult.success ? 'completed' : 'failed';

    // Update progress
    operation.progress.processed++;
    if (itemResult.success) {
      operation.progress.successful++;
    } else {
      operation.progress.failed++;

      if (!operation.options.continueOnError) {
        operation.status = 'failed';
      }
    }

    results.push(itemResult);
  }

  private async executeOperation(
    type: BulkOperation['type'],
    connector: BaseConnector,
    data: ProductInput,
    productId?: string
  ): Promise<ConnectorResult<CreateResult | UpdateResult | DeleteResult>> {
    switch (type) {
      case 'create':
        return connector.createProduct(data);
      case 'update':
        if (!productId) {
          return {
            success: false,
            error: {
              code: 'MISSING_ID',
              message: 'Product ID required for update',
              retryable: false,
            },
          };
        }
        return connector.updateProduct(productId, data);
      case 'delete':
        if (!productId) {
          return {
            success: false,
            error: {
              code: 'MISSING_ID',
              message: 'Product ID required for delete',
              retryable: false,
            },
          };
        }
        return connector.deleteProduct(productId);
      default:
        return {
          success: false,
          error: {
            code: 'INVALID_OPERATION',
            message: `Unknown operation type: ${type}`,
            retryable: false,
          },
        };
    }
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private createBatches<T>(items: T[], size: number): T[][] {
    const batches: T[][] = [];
    for (let i = 0; i < items.length; i += size) {
      batches.push(items.slice(i, i + size));
    }
    return batches;
  }

  private updateProgress(operation: BulkOperation): void {
    operation.progress.percent = Math.round(
      (operation.progress.processed / operation.progress.total) * 100
    );

    // Estimate remaining time
    if (operation.progress.startedAt && operation.progress.processed > 0) {
      const elapsed = Date.now() - operation.progress.startedAt.getTime();
      const avgTimePerItem = elapsed / operation.progress.processed;
      const remaining = operation.progress.total - operation.progress.processed;
      operation.progress.estimatedTimeRemaining = avgTimePerItem * remaining;
    }
  }

  private async validateItems(operation: BulkOperation): Promise<BulkError[]> {
    const errors: BulkError[] = [];

    for (const item of operation.items) {
      for (const platform of operation.platforms) {
        const connector = await this.getConnector(platform);
        const validation = connector.validateProductForPlatform(item.data as ProductInput);

        if (!validation.valid) {
          item.status = 'skipped';
          operation.progress.skipped++;

          validation.issues
            .filter((issue) => issue.severity === 'error')
            .forEach((issue) => {
              errors.push({
                itemId: item.id,
                platform,
                code: 'VALIDATION_ERROR',
                message: `${issue.field}: ${issue.message}`,
                recoverable: false,
              });
            });
        }
      }
    }

    return errors;
  }

  private async initializeConnectors(platforms: ConnectorName[]): Promise<void> {
    for (const platform of platforms) {
      if (!this.connectors.has(platform)) {
        await this.getConnector(platform);
      }
    }
  }

  private async getConnector(platform: ConnectorName): Promise<BaseConnector> {
    if (this.connectors.has(platform)) {
      return this.connectors.get(platform)!;
    }

    const { data: credentials } = await this.supabase
      .from('platform_credentials')
      .select('*')
      .eq('platform', platform)
      .single();

    if (!credentials) {
      throw new Error(`No credentials found for platform: ${platform}`);
    }

    const connector = createConnector(platform, {
      platform,
      credentials: credentials.credentials,
    } as ConnectorConfig);

    this.connectors.set(platform, connector);
    return connector;
  }

  // ============================================================================
  // Rollback Methods
  // ============================================================================

  private addRollbackAction(operationId: string, action: RollbackAction): void {
    if (!this.rollbackStack.has(operationId)) {
      this.rollbackStack.set(operationId, []);
    }
    this.rollbackStack.get(operationId)!.push(action);
  }

  private async performRollback(operation: BulkOperation): Promise<void> {
    const actions = this.rollbackStack.get(operation.id) || [];

    console.log(`Performing rollback for operation ${operation.id}: ${actions.length} actions`);

    for (const action of actions.reverse()) {
      try {
        const connector = this.connectors.get(action.platform);
        if (!connector) continue;

        if (action.type === 'delete') {
          await connector.deleteProduct(action.externalId);
        }
      } catch (error) {
        console.error(`Rollback action failed:`, error);
      }
    }

    this.rollbackStack.delete(operation.id);
  }

  // ============================================================================
  // Persistence
  // ============================================================================

  private async saveOperation(operation: BulkOperation): Promise<void> {
    const row = {
      id: operation.id,
      type: operation.type,
      status: operation.status,
      platforms: operation.platforms,
      item_count: operation.items.length,
      options: operation.options,
      progress: {
        ...operation.progress,
        startedAt: operation.progress.startedAt?.toISOString(),
      },
      result: operation.result,
      created_at: operation.createdAt.toISOString(),
      updated_at: new Date().toISOString(),
      completed_at: operation.completedAt?.toISOString(),
    };

    await this.supabase.from('bulk_operations').upsert(row);
  }
}

// ============================================================================
// Rollback Action Type
// ============================================================================

interface RollbackAction {
  type: 'delete' | 'restore';
  platform: ConnectorName;
  externalId: string;
  previousData?: unknown;
}

export default BulkProcessor;
