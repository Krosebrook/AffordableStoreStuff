/**
 * TOTP (Time-based One-Time Password) Utility
 *
 * Implements RFC 6238 TOTP algorithm for 2FA authentication.
 * Used by browser automation adapters that require 2FA (e.g., Amazon KDP).
 *
 * This implementation uses native Node.js crypto module for HMAC-SHA1,
 * avoiding external dependencies while maintaining security standards.
 */

import { createHmac } from 'crypto';

// ============================================================================
// Types
// ============================================================================

export interface TOTPConfig {
  /** Base32-encoded secret key */
  secret: string;
  /** Time step in seconds (default: 30) */
  period?: number;
  /** Number of digits in OTP (default: 6) */
  digits?: number;
  /** Hash algorithm (default: 'sha1') */
  algorithm?: 'sha1' | 'sha256' | 'sha512';
  /** Time offset for clock drift tolerance */
  window?: number;
}

export interface TOTPResult {
  /** Generated OTP code */
  code: string;
  /** Seconds until code expires */
  remainingSeconds: number;
  /** Current time step counter */
  counter: number;
}

// ============================================================================
// Base32 Decoding
// ============================================================================

const BASE32_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const BASE32_LOOKUP: Record<string, number> = {};

// Initialize lookup table
for (let i = 0; i < BASE32_CHARS.length; i++) {
  BASE32_LOOKUP[BASE32_CHARS[i]] = i;
}

/**
 * Decode a Base32 string to a Buffer
 * Handles common variations (lowercase, padding, spaces)
 */
export function base32Decode(encoded: string): Buffer {
  // Normalize: uppercase, remove spaces and padding
  const normalized = encoded
    .toUpperCase()
    .replace(/\s+/g, '')
    .replace(/=+$/, '');

  if (normalized.length === 0) {
    throw new Error('Empty Base32 string');
  }

  // Validate characters
  for (const char of normalized) {
    if (!(char in BASE32_LOOKUP)) {
      throw new Error(`Invalid Base32 character: ${char}`);
    }
  }

  // Calculate output length
  const outputLength = Math.floor((normalized.length * 5) / 8);
  const output = Buffer.alloc(outputLength);

  let bits = 0;
  let value = 0;
  let index = 0;

  for (const char of normalized) {
    value = (value << 5) | BASE32_LOOKUP[char];
    bits += 5;

    if (bits >= 8) {
      bits -= 8;
      output[index++] = (value >>> bits) & 0xff;
    }
  }

  return output;
}

/**
 * Encode a Buffer to Base32 string
 */
export function base32Encode(buffer: Buffer): string {
  let result = '';
  let bits = 0;
  let value = 0;

  for (const byte of buffer) {
    value = (value << 8) | byte;
    bits += 8;

    while (bits >= 5) {
      bits -= 5;
      result += BASE32_CHARS[(value >>> bits) & 0x1f];
    }
  }

  // Handle remaining bits
  if (bits > 0) {
    result += BASE32_CHARS[(value << (5 - bits)) & 0x1f];
  }

  // Add padding
  const padding = (8 - (result.length % 8)) % 8;
  return result + '='.repeat(padding);
}

// ============================================================================
// TOTP Implementation
// ============================================================================

/**
 * Generate a TOTP code
 *
 * @param config - TOTP configuration
 * @returns TOTPResult with code and metadata
 *
 * @example
 * ```typescript
 * const result = generateTOTP({
 *   secret: 'JBSWY3DPEHPK3PXP',
 *   period: 30,
 *   digits: 6,
 * });
 * console.log(result.code); // "123456"
 * console.log(result.remainingSeconds); // 15
 * ```
 */
export function generateTOTP(config: TOTPConfig): TOTPResult {
  const {
    secret,
    period = 30,
    digits = 6,
    algorithm = 'sha1',
  } = config;

  // Decode secret
  const key = base32Decode(secret);

  // Calculate time counter
  const now = Math.floor(Date.now() / 1000);
  const counter = Math.floor(now / period);
  const remainingSeconds = period - (now % period);

  // Generate HOTP
  const code = generateHOTP(key, counter, digits, algorithm);

  return {
    code,
    remainingSeconds,
    counter,
  };
}

/**
 * Verify a TOTP code with optional time window
 *
 * @param code - The code to verify
 * @param config - TOTP configuration
 * @returns true if code is valid within the time window
 */
export function verifyTOTP(code: string, config: TOTPConfig): boolean {
  const {
    secret,
    period = 30,
    digits = 6,
    algorithm = 'sha1',
    window = 1, // Allow 1 step before/after
  } = config;

  const key = base32Decode(secret);
  const now = Math.floor(Date.now() / 1000);
  const counter = Math.floor(now / period);

  // Check current and adjacent time steps
  for (let i = -window; i <= window; i++) {
    const expectedCode = generateHOTP(key, counter + i, digits, algorithm);
    if (timingSafeEqual(code, expectedCode)) {
      return true;
    }
  }

  return false;
}

/**
 * Generate HOTP (HMAC-based One-Time Password)
 * Core algorithm used by TOTP (RFC 4226)
 */
function generateHOTP(
  key: Buffer,
  counter: number,
  digits: number,
  algorithm: 'sha1' | 'sha256' | 'sha512'
): string {
  // Convert counter to 8-byte buffer (big-endian)
  const counterBuffer = Buffer.alloc(8);
  for (let i = 7; i >= 0; i--) {
    counterBuffer[i] = counter & 0xff;
    counter = Math.floor(counter / 256);
  }

  // Calculate HMAC
  const hmac = createHmac(algorithm, key);
  hmac.update(counterBuffer);
  const hash = hmac.digest();

  // Dynamic truncation
  const offset = hash[hash.length - 1] & 0x0f;
  const binary =
    ((hash[offset] & 0x7f) << 24) |
    ((hash[offset + 1] & 0xff) << 16) |
    ((hash[offset + 2] & 0xff) << 8) |
    (hash[offset + 3] & 0xff);

  // Generate OTP
  const otp = binary % Math.pow(10, digits);
  return otp.toString().padStart(digits, '0');
}

/**
 * Timing-safe string comparison to prevent timing attacks
 */
function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) {
    return false;
  }

  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }

  return result === 0;
}

// ============================================================================
// Secret Generation
// ============================================================================

/**
 * Generate a new random TOTP secret
 *
 * @param length - Number of bytes (default: 20 for 160-bit key)
 * @returns Base32-encoded secret
 */
export function generateSecret(length: number = 20): string {
  const { randomBytes } = require('crypto');
  const buffer = randomBytes(length);
  return base32Encode(buffer);
}

/**
 * Generate a TOTP provisioning URI for QR codes
 *
 * @param options - Provisioning options
 * @returns otpauth:// URI
 */
export function generateProvisioningURI(options: {
  secret: string;
  accountName: string;
  issuer: string;
  period?: number;
  digits?: number;
  algorithm?: 'sha1' | 'sha256' | 'sha512';
}): string {
  const {
    secret,
    accountName,
    issuer,
    period = 30,
    digits = 6,
    algorithm = 'sha1',
  } = options;

  const params = new URLSearchParams({
    secret: secret.replace(/\s/g, ''),
    issuer: issuer,
    algorithm: algorithm.toUpperCase(),
    digits: digits.toString(),
    period: period.toString(),
  });

  const label = encodeURIComponent(`${issuer}:${accountName}`);
  return `otpauth://totp/${label}?${params.toString()}`;
}

// ============================================================================
// Convenience Functions
// ============================================================================

/**
 * Get the current TOTP code for a secret
 * Simplified interface for common use case
 */
export function getCode(secret: string): string {
  return generateTOTP({ secret }).code;
}

/**
 * Get time remaining until next code
 */
export function getTimeRemaining(period: number = 30): number {
  const now = Math.floor(Date.now() / 1000);
  return period - (now % period);
}

/**
 * Wait for the next TOTP period
 * Useful when a code was just used and you need a fresh one
 */
export async function waitForNextCode(period: number = 30): Promise<void> {
  const remaining = getTimeRemaining(period);
  await new Promise(resolve => setTimeout(resolve, (remaining + 1) * 1000));
}

export default {
  generateTOTP,
  verifyTOTP,
  generateSecret,
  generateProvisioningURI,
  getCode,
  getTimeRemaining,
  waitForNextCode,
  base32Decode,
  base32Encode,
};
