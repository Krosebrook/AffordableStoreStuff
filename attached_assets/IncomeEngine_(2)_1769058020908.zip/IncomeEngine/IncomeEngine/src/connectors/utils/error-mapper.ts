/**
 * Error Mapper
 * Platform-specific error normalization
 */

import { ConnectorError } from '../core/types';

/**
 * Standard error codes used across all connectors
 */
export enum ErrorCode {
  // Authentication errors
  AUTH_INVALID = 'AUTH_INVALID',
  AUTH_EXPIRED = 'AUTH_EXPIRED',
  AUTH_INSUFFICIENT_SCOPE = 'AUTH_INSUFFICIENT_SCOPE',
  AUTH_REVOKED = 'AUTH_REVOKED',

  // Rate limiting
  RATE_LIMITED = 'RATE_LIMITED',
  QUOTA_EXCEEDED = 'QUOTA_EXCEEDED',

  // Resource errors
  NOT_FOUND = 'NOT_FOUND',
  ALREADY_EXISTS = 'ALREADY_EXISTS',
  CONFLICT = 'CONFLICT',

  // Validation errors
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  INVALID_INPUT = 'INVALID_INPUT',
  MISSING_FIELD = 'MISSING_FIELD',

  // Server errors
  SERVER_ERROR = 'SERVER_ERROR',
  SERVICE_UNAVAILABLE = 'SERVICE_UNAVAILABLE',
  MAINTENANCE = 'MAINTENANCE',

  // Network errors
  NETWORK_ERROR = 'NETWORK_ERROR',
  TIMEOUT = 'TIMEOUT',
  CONNECTION_REFUSED = 'CONNECTION_REFUSED',

  // Business logic errors
  INSUFFICIENT_INVENTORY = 'INSUFFICIENT_INVENTORY',
  PRICE_VIOLATION = 'PRICE_VIOLATION',
  POLICY_VIOLATION = 'POLICY_VIOLATION',
  TRADEMARK_VIOLATION = 'TRADEMARK_VIOLATION',

  // Platform-specific
  PLATFORM_ERROR = 'PLATFORM_ERROR',
  UNSUPPORTED_OPERATION = 'UNSUPPORTED_OPERATION',

  // Generic
  UNKNOWN_ERROR = 'UNKNOWN_ERROR',
}

/**
 * Platform-specific error mappings
 */
interface PlatformErrorMapping {
  statusCode?: number;
  errorCode?: string | RegExp;
  errorMessage?: string | RegExp;
  targetCode: ErrorCode;
  retryable: boolean;
  suggestion?: string;
}

/**
 * Error mappings for each platform
 */
const PLATFORM_MAPPINGS: Record<string, PlatformErrorMapping[]> = {
  printify: [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 403, targetCode: ErrorCode.AUTH_INSUFFICIENT_SCOPE, retryable: false },
    { statusCode: 404, targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { statusCode: 429, targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { errorCode: 'shop_not_found', targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { errorCode: 'invalid_blueprint', targetCode: ErrorCode.VALIDATION_ERROR, retryable: false },
    { errorMessage: /print provider.*not available/i, targetCode: ErrorCode.SERVICE_UNAVAILABLE, retryable: true },
  ],

  etsy: [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 403, errorCode: 'INSUFFICIENT_SCOPE', targetCode: ErrorCode.AUTH_INSUFFICIENT_SCOPE, retryable: false },
    { statusCode: 404, targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { statusCode: 429, targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { statusCode: 503, targetCode: ErrorCode.MAINTENANCE, retryable: true },
    { errorCode: 'LISTING_NOT_FOUND', targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { errorCode: 'INVALID_LISTING_ID', targetCode: ErrorCode.INVALID_INPUT, retryable: false },
    { errorMessage: /shipping profile.*required/i, targetCode: ErrorCode.MISSING_FIELD, retryable: false, suggestion: 'Add a shipping profile to your Etsy shop' },
    { errorMessage: /trademark/i, targetCode: ErrorCode.TRADEMARK_VIOLATION, retryable: false },
  ],

  gumroad: [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 404, targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { statusCode: 429, targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { errorCode: 'product_not_found', targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { errorMessage: /price must be/i, targetCode: ErrorCode.PRICE_VIOLATION, retryable: false },
  ],

  shopify: [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 402, targetCode: ErrorCode.QUOTA_EXCEEDED, retryable: false, suggestion: 'Check your Shopify plan limits' },
    { statusCode: 403, targetCode: ErrorCode.AUTH_INSUFFICIENT_SCOPE, retryable: false },
    { statusCode: 404, targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { statusCode: 422, targetCode: ErrorCode.VALIDATION_ERROR, retryable: false },
    { statusCode: 429, targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { statusCode: 503, targetCode: ErrorCode.SERVICE_UNAVAILABLE, retryable: true },
    { errorCode: 'THROTTLED', targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { errorMessage: /variant.*already exists/i, targetCode: ErrorCode.ALREADY_EXISTS, retryable: false },
    { errorMessage: /inventory.*not available/i, targetCode: ErrorCode.INSUFFICIENT_INVENTORY, retryable: false },
  ],

  woocommerce: [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 403, targetCode: ErrorCode.AUTH_INSUFFICIENT_SCOPE, retryable: false },
    { statusCode: 404, targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { statusCode: 400, errorCode: 'rest_invalid_param', targetCode: ErrorCode.INVALID_INPUT, retryable: false },
    { statusCode: 400, errorCode: 'woocommerce_rest_product_invalid_id', targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { errorMessage: /consumer key.*invalid/i, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
  ],

  'amazon-kdp': [
    { errorMessage: /session.*expired/i, targetCode: ErrorCode.AUTH_EXPIRED, retryable: false },
    { errorMessage: /captcha/i, targetCode: ErrorCode.PLATFORM_ERROR, retryable: false, suggestion: 'Manual captcha resolution required' },
    { errorMessage: /content.*guidelines/i, targetCode: ErrorCode.POLICY_VIOLATION, retryable: false },
    { errorMessage: /ISBN.*invalid/i, targetCode: ErrorCode.VALIDATION_ERROR, retryable: false },
    { errorMessage: /cover.*dimensions/i, targetCode: ErrorCode.VALIDATION_ERROR, retryable: false, suggestion: 'Check cover image dimensions' },
  ],

  redbubble: [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 429, targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { errorMessage: /design.*rejected/i, targetCode: ErrorCode.POLICY_VIOLATION, retryable: false },
    { errorMessage: /file.*too large/i, targetCode: ErrorCode.VALIDATION_ERROR, retryable: false, suggestion: 'Reduce image file size' },
  ],

  teepublic: [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 429, targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { errorMessage: /design.*flagged/i, targetCode: ErrorCode.POLICY_VIOLATION, retryable: false },
  ],

  'creative-fabrica': [
    { statusCode: 401, targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { statusCode: 429, targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { errorMessage: /license.*type/i, targetCode: ErrorCode.VALIDATION_ERROR, retryable: false },
    { errorMessage: /category.*required/i, targetCode: ErrorCode.MISSING_FIELD, retryable: false },
  ],

  'tiktok-shop': [
    { errorCode: '100001', targetCode: ErrorCode.AUTH_INVALID, retryable: false },
    { errorCode: '100002', targetCode: ErrorCode.AUTH_EXPIRED, retryable: false },
    { errorCode: '50002', targetCode: ErrorCode.RATE_LIMITED, retryable: true },
    { errorCode: '70001', targetCode: ErrorCode.NOT_FOUND, retryable: false },
    { errorCode: '70002', targetCode: ErrorCode.VALIDATION_ERROR, retryable: false },
    { errorMessage: /product.*audit/i, targetCode: ErrorCode.POLICY_VIOLATION, retryable: false },
    { errorMessage: /category.*attribute/i, targetCode: ErrorCode.MISSING_FIELD, retryable: false, suggestion: 'Check required category attributes' },
  ],
};

/**
 * HTTP status code to error code mapping
 */
const HTTP_STATUS_MAPPING: Record<number, { code: ErrorCode; retryable: boolean }> = {
  400: { code: ErrorCode.INVALID_INPUT, retryable: false },
  401: { code: ErrorCode.AUTH_INVALID, retryable: false },
  403: { code: ErrorCode.AUTH_INSUFFICIENT_SCOPE, retryable: false },
  404: { code: ErrorCode.NOT_FOUND, retryable: false },
  409: { code: ErrorCode.CONFLICT, retryable: false },
  422: { code: ErrorCode.VALIDATION_ERROR, retryable: false },
  429: { code: ErrorCode.RATE_LIMITED, retryable: true },
  500: { code: ErrorCode.SERVER_ERROR, retryable: true },
  502: { code: ErrorCode.SERVER_ERROR, retryable: true },
  503: { code: ErrorCode.SERVICE_UNAVAILABLE, retryable: true },
  504: { code: ErrorCode.TIMEOUT, retryable: true },
};

/**
 * Map platform-specific error to normalized ConnectorError
 */
export function mapPlatformError(
  platform: string,
  statusCode: number | undefined,
  errorData: unknown
): ConnectorError {
  const mappings = PLATFORM_MAPPINGS[platform] || [];

  // Extract error code and message from response
  const { errorCode, errorMessage } = extractErrorInfo(errorData);

  // Try platform-specific mappings first
  for (const mapping of mappings) {
    if (matchesMapping(mapping, statusCode, errorCode, errorMessage)) {
      return {
        code: mapping.targetCode,
        message: buildErrorMessage(mapping.targetCode, errorMessage, mapping.suggestion),
        platformCode: errorCode || String(statusCode),
        platformMessage: errorMessage,
        retryable: mapping.retryable,
        details: { statusCode, platform, originalError: errorData },
      };
    }
  }

  // Fall back to HTTP status code mapping
  if (statusCode && HTTP_STATUS_MAPPING[statusCode]) {
    const httpMapping = HTTP_STATUS_MAPPING[statusCode];
    return {
      code: httpMapping.code,
      message: errorMessage || getDefaultMessage(httpMapping.code),
      platformCode: String(statusCode),
      platformMessage: errorMessage,
      retryable: httpMapping.retryable,
      details: { statusCode, platform, originalError: errorData },
    };
  }

  // Generic error
  return {
    code: ErrorCode.UNKNOWN_ERROR,
    message: errorMessage || 'An unknown error occurred',
    platformCode: errorCode || String(statusCode),
    platformMessage: errorMessage,
    retryable: false,
    details: { statusCode, platform, originalError: errorData },
  };
}

/**
 * Map network/JavaScript error to ConnectorError
 */
export function mapNetworkError(error: unknown): ConnectorError {
  if (error instanceof Error) {
    // Check for specific network errors
    if (error.name === 'AbortError' || error.message.includes('timeout')) {
      return {
        code: ErrorCode.TIMEOUT,
        message: 'Request timed out',
        retryable: true,
        details: { name: error.name, message: error.message },
      };
    }

    if (error.message.includes('ECONNREFUSED')) {
      return {
        code: ErrorCode.CONNECTION_REFUSED,
        message: 'Connection refused',
        retryable: true,
        details: { name: error.name, message: error.message },
      };
    }

    if (error.message.includes('ENOTFOUND') || error.message.includes('getaddrinfo')) {
      return {
        code: ErrorCode.NETWORK_ERROR,
        message: 'DNS lookup failed',
        retryable: true,
        details: { name: error.name, message: error.message },
      };
    }

    if (error.message.includes('ECONNRESET') || error.message.includes('socket hang up')) {
      return {
        code: ErrorCode.NETWORK_ERROR,
        message: 'Connection reset',
        retryable: true,
        details: { name: error.name, message: error.message },
      };
    }

    return {
      code: ErrorCode.NETWORK_ERROR,
      message: error.message,
      retryable: true,
      details: { name: error.name, stack: error.stack },
    };
  }

  return {
    code: ErrorCode.UNKNOWN_ERROR,
    message: String(error),
    retryable: false,
  };
}

/**
 * Extract error code and message from various error formats
 */
function extractErrorInfo(errorData: unknown): { errorCode?: string; errorMessage?: string } {
  if (!errorData) {
    return {};
  }

  if (typeof errorData === 'string') {
    return { errorMessage: errorData };
  }

  if (typeof errorData !== 'object') {
    return { errorMessage: String(errorData) };
  }

  const data = errorData as Record<string, unknown>;

  // Common error structures
  const errorCode =
    data.error_code ||
    data.errorCode ||
    data.code ||
    (data.error as Record<string, unknown>)?.code;

  const errorMessage =
    data.error_description ||
    data.errorMessage ||
    data.message ||
    data.error_message ||
    (data.error as Record<string, unknown>)?.message ||
    (typeof data.error === 'string' ? data.error : undefined) ||
    (Array.isArray(data.errors) ? (data.errors[0] as Record<string, unknown>)?.message : undefined);

  return {
    errorCode: errorCode ? String(errorCode) : undefined,
    errorMessage: errorMessage ? String(errorMessage) : undefined,
  };
}

/**
 * Check if error matches a mapping
 */
function matchesMapping(
  mapping: PlatformErrorMapping,
  statusCode: number | undefined,
  errorCode: string | undefined,
  errorMessage: string | undefined
): boolean {
  // Check status code
  if (mapping.statusCode !== undefined) {
    if (statusCode !== mapping.statusCode) {
      return false;
    }
  }

  // Check error code
  if (mapping.errorCode !== undefined) {
    if (!errorCode) return false;

    if (mapping.errorCode instanceof RegExp) {
      if (!mapping.errorCode.test(errorCode)) return false;
    } else {
      if (errorCode !== mapping.errorCode) return false;
    }
  }

  // Check error message
  if (mapping.errorMessage !== undefined) {
    if (!errorMessage) return false;

    if (mapping.errorMessage instanceof RegExp) {
      if (!mapping.errorMessage.test(errorMessage)) return false;
    } else {
      if (!errorMessage.includes(mapping.errorMessage)) return false;
    }
  }

  return true;
}

/**
 * Build user-friendly error message
 */
function buildErrorMessage(
  code: ErrorCode,
  platformMessage?: string,
  suggestion?: string
): string {
  const baseMessage = getDefaultMessage(code);

  let message = platformMessage || baseMessage;

  if (suggestion) {
    message += `. ${suggestion}`;
  }

  return message;
}

/**
 * Get default message for error code
 */
function getDefaultMessage(code: ErrorCode): string {
  const messages: Record<ErrorCode, string> = {
    [ErrorCode.AUTH_INVALID]: 'Authentication failed. Please check your credentials.',
    [ErrorCode.AUTH_EXPIRED]: 'Your session has expired. Please re-authenticate.',
    [ErrorCode.AUTH_INSUFFICIENT_SCOPE]: 'Insufficient permissions. Please grant the required access.',
    [ErrorCode.AUTH_REVOKED]: 'Access has been revoked. Please re-authorize.',
    [ErrorCode.RATE_LIMITED]: 'Too many requests. Please wait before trying again.',
    [ErrorCode.QUOTA_EXCEEDED]: 'API quota exceeded. Please try again later.',
    [ErrorCode.NOT_FOUND]: 'The requested resource was not found.',
    [ErrorCode.ALREADY_EXISTS]: 'This resource already exists.',
    [ErrorCode.CONFLICT]: 'A conflict occurred with the current state.',
    [ErrorCode.VALIDATION_ERROR]: 'The request data is invalid.',
    [ErrorCode.INVALID_INPUT]: 'Invalid input provided.',
    [ErrorCode.MISSING_FIELD]: 'A required field is missing.',
    [ErrorCode.SERVER_ERROR]: 'The server encountered an error. Please try again.',
    [ErrorCode.SERVICE_UNAVAILABLE]: 'The service is temporarily unavailable.',
    [ErrorCode.MAINTENANCE]: 'The service is undergoing maintenance.',
    [ErrorCode.NETWORK_ERROR]: 'A network error occurred. Please check your connection.',
    [ErrorCode.TIMEOUT]: 'The request timed out. Please try again.',
    [ErrorCode.CONNECTION_REFUSED]: 'Connection was refused by the server.',
    [ErrorCode.INSUFFICIENT_INVENTORY]: 'Insufficient inventory available.',
    [ErrorCode.PRICE_VIOLATION]: 'The price violates platform policies.',
    [ErrorCode.POLICY_VIOLATION]: 'The content violates platform policies.',
    [ErrorCode.TRADEMARK_VIOLATION]: 'Potential trademark violation detected.',
    [ErrorCode.PLATFORM_ERROR]: 'A platform-specific error occurred.',
    [ErrorCode.UNSUPPORTED_OPERATION]: 'This operation is not supported.',
    [ErrorCode.UNKNOWN_ERROR]: 'An unknown error occurred.',
  };

  return messages[code] || 'An error occurred.';
}

/**
 * Check if error is retryable based on code
 */
export function isRetryableError(error: ConnectorError): boolean {
  if (error.retryable !== undefined) {
    return error.retryable;
  }

  const retryableCodes = new Set([
    ErrorCode.RATE_LIMITED,
    ErrorCode.SERVER_ERROR,
    ErrorCode.SERVICE_UNAVAILABLE,
    ErrorCode.MAINTENANCE,
    ErrorCode.NETWORK_ERROR,
    ErrorCode.TIMEOUT,
    ErrorCode.CONNECTION_REFUSED,
  ]);

  return retryableCodes.has(error.code as ErrorCode);
}

/**
 * Get suggested action for error
 */
export function getSuggestedAction(error: ConnectorError): string | undefined {
  const actions: Partial<Record<ErrorCode, string>> = {
    [ErrorCode.AUTH_INVALID]: 'Re-enter your API credentials in Settings',
    [ErrorCode.AUTH_EXPIRED]: 'Click "Reconnect" to refresh your session',
    [ErrorCode.AUTH_INSUFFICIENT_SCOPE]: 'Re-authorize with additional permissions',
    [ErrorCode.RATE_LIMITED]: 'Wait a few minutes before retrying',
    [ErrorCode.QUOTA_EXCEEDED]: 'Upgrade your plan or wait for quota reset',
    [ErrorCode.NOT_FOUND]: 'Verify the resource ID is correct',
    [ErrorCode.VALIDATION_ERROR]: 'Review and correct the input data',
    [ErrorCode.MISSING_FIELD]: 'Add the required field and try again',
    [ErrorCode.TRADEMARK_VIOLATION]: 'Modify the content to avoid trademark issues',
  };

  return actions[error.code as ErrorCode];
}

export default {
  mapPlatformError,
  mapNetworkError,
  isRetryableError,
  getSuggestedAction,
  ErrorCode,
};
