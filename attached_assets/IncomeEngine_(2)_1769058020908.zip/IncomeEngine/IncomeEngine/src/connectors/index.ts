/**
 * Connectors Module
 * Unified platform connector system for ecommerce integrations
 *
 * This module provides a consistent interface for connecting to multiple
 * ecommerce platforms (POD and marketplace) with:
 * - Unified product normalization
 * - Rate limiting and retry handling
 * - OAuth and API key credential management
 * - Platform-specific error mapping
 */

// Core types
export * from './core/types';

// Base connector
export { BaseConnector, type ConnectorConfig, type RequestOptions } from './core/base-connector';

// Core utilities
export { CredentialManager } from './core/credential-manager';
export {
  RateLimitManager,
  getRateLimitManager,
  createRateLimitManager,
} from './core/rate-limit-manager';

// Utils
export {
  RetryHandler,
  retry,
  retryWithTimeout,
  withRetry,
  CircuitBreaker,
  type CircuitState,
} from './utils/retry-handler';

export {
  mapPlatformError,
  mapNetworkError,
  isRetryableError,
  getSuggestedAction,
  ErrorCode,
} from './utils/error-mapper';

// TOTP Utility (for 2FA)
export {
  generateTOTP,
  verifyTOTP,
  generateSecret,
  generateProvisioningURI,
  getCode,
  getTimeRemaining,
  waitForNextCode,
  base32Decode,
  base32Encode,
  type TOTPConfig,
  type TOTPResult,
} from './utils/totp';

// Webhook Notification Service
export {
  sendWebhook,
  WebhookQueueManager,
  NotificationService,
  type WebhookConfig,
  type WebhookPayload,
  type WebhookEventType,
  type WebhookResult,
  type WebhookQueueItem,
} from './utils/webhook';

// Platform Adapters - POD + Digital
export { PrintifyAdapter } from './adapters/printify-adapter';
export { EtsyAdapter } from './adapters/etsy-adapter';
export { GumroadAdapter } from './adapters/gumroad-adapter';
export { TeePublicAdapter } from './adapters/teepublic-adapter';
export { Society6Adapter } from './adapters/society6-adapter';
export { CreativeFabricaAdapter } from './adapters/creative-fabrica-adapter';

// Platform Adapters - Marketplace
export { ShopifyAdapter } from './adapters/shopify-adapter';
export { WooCommerceAdapter } from './adapters/woocommerce-adapter';
export { AmazonKDPAdapter } from './adapters/amazon-kdp-adapter';
export { TikTokShopAdapter } from './adapters/tiktok-shop-adapter';

// Workflow Engines
export { PODDigitalWorkflow, type PODPlatform, type WorkflowConfig, type PublishTarget } from './workflows/pod-digital-workflow';
export { MarketplaceWorkflow, type MarketplacePlatform, type MarketplaceConfig, type MarketplaceListing } from './workflows/marketplace-workflow';

// Connector Registry
import { BaseConnector, ConnectorConfig } from './core/base-connector';
import { PrintifyAdapter } from './adapters/printify-adapter';
import { EtsyAdapter } from './adapters/etsy-adapter';
import { GumroadAdapter } from './adapters/gumroad-adapter';
import { ShopifyAdapter } from './adapters/shopify-adapter';
import { WooCommerceAdapter } from './adapters/woocommerce-adapter';
import { AmazonKDPAdapter } from './adapters/amazon-kdp-adapter';
import { TeePublicAdapter } from './adapters/teepublic-adapter';
import { Society6Adapter } from './adapters/society6-adapter';
import { CreativeFabricaAdapter } from './adapters/creative-fabrica-adapter';
import { TikTokShopAdapter } from './adapters/tiktok-shop-adapter';

/**
 * Available connector types
 */
export type ConnectorName =
  | 'printify'
  | 'etsy'
  | 'gumroad'
  | 'shopify'
  | 'woocommerce'
  | 'amazon-kdp'
  | 'redbubble'
  | 'teepublic'
  | 'society6'
  | 'creative-fabrica'
  | 'tiktok-shop';

/**
 * Connector factory configuration
 */
export interface ConnectorFactoryConfig extends ConnectorConfig {
  shopDomain?: string; // For Shopify
  siteUrl?: string; // For WooCommerce
}

/**
 * Create a connector instance by name
 */
export function createConnector(
  name: ConnectorName,
  config: ConnectorFactoryConfig
): BaseConnector {
  switch (name) {
    case 'printify':
      return new PrintifyAdapter(config);
    case 'etsy':
      return new EtsyAdapter(config);
    case 'gumroad':
      return new GumroadAdapter(config);
    case 'shopify':
      return new ShopifyAdapter({ ...config, shopDomain: config.shopDomain });
    case 'woocommerce':
      return new WooCommerceAdapter({ ...config, siteUrl: config.siteUrl });
    case 'amazon-kdp':
      return new AmazonKDPAdapter(config);
    case 'teepublic':
      return new TeePublicAdapter(config);
    case 'society6':
      return new Society6Adapter(config);
    case 'creative-fabrica':
      return new CreativeFabricaAdapter(config);
    case 'tiktok-shop':
      return new TikTokShopAdapter(config);
    case 'redbubble':
      // Redbubble adapter exists at adapters/redbubble-adapter.ts
      // Import and return it when fully integrated
      throw new Error(`Connector ${name} requires additional setup`);
    default:
      throw new Error(`Unknown connector: ${name}`);
  }
}

/**
 * Get all available connector names
 */
export function getAvailableConnectors(): ConnectorName[] {
  return [
    'printify',
    'etsy',
    'gumroad',
    'shopify',
    'woocommerce',
    'amazon-kdp',
    'redbubble',
    'teepublic',
    'society6',
    'creative-fabrica',
    'tiktok-shop',
  ];
}

/**
 * Get connector metadata
 */
export function getConnectorMetadata(name: ConnectorName): {
  displayName: string;
  workflowGroup: 'pod_digital' | 'marketplace';
  connectorType: 'api_key' | 'oauth2' | 'playwright';
  status: 'available' | 'coming_soon';
} {
  const metadata: Record<ConnectorName, ReturnType<typeof getConnectorMetadata>> = {
    printify: {
      displayName: 'Printify',
      workflowGroup: 'pod_digital',
      connectorType: 'api_key',
      status: 'available',
    },
    etsy: {
      displayName: 'Etsy',
      workflowGroup: 'pod_digital',
      connectorType: 'oauth2',
      status: 'available',
    },
    gumroad: {
      displayName: 'Gumroad',
      workflowGroup: 'pod_digital',
      connectorType: 'oauth2',
      status: 'available',
    },
    shopify: {
      displayName: 'Shopify',
      workflowGroup: 'marketplace',
      connectorType: 'oauth2',
      status: 'available',
    },
    woocommerce: {
      displayName: 'WooCommerce',
      workflowGroup: 'marketplace',
      connectorType: 'api_key',
      status: 'available',
    },
    'amazon-kdp': {
      displayName: 'Amazon KDP',
      workflowGroup: 'marketplace',
      connectorType: 'playwright',
      status: 'available',
    },
    redbubble: {
      displayName: 'Redbubble',
      workflowGroup: 'pod_digital',
      connectorType: 'playwright',
      status: 'available',
    },
    teepublic: {
      displayName: 'TeePublic',
      workflowGroup: 'pod_digital',
      connectorType: 'playwright',
      status: 'available',
    },
    society6: {
      displayName: 'Society6',
      workflowGroup: 'pod_digital',
      connectorType: 'playwright',
      status: 'available',
    },
    'creative-fabrica': {
      displayName: 'Creative Fabrica',
      workflowGroup: 'pod_digital',
      connectorType: 'api_key',
      status: 'available',
    },
    'tiktok-shop': {
      displayName: 'TikTok Shop',
      workflowGroup: 'marketplace',
      connectorType: 'oauth2',
      status: 'available',
    },
  };

  return metadata[name];
}

export default {
  createConnector,
  getAvailableConnectors,
  getConnectorMetadata,
};
