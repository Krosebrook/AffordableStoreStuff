/**
 * POD + Digital Products Workflow Engine
 *
 * Unified workflow orchestration for Print-on-Demand and Digital product platforms:
 * - Printify (POD)
 * - Etsy (POD + Digital)
 * - Gumroad (Digital)
 * - Redbubble (POD) [planned]
 * - TeePublic (POD) [planned]
 * - Creative Fabrica (Digital) [planned]
 *
 * This workflow handles:
 * - Product generation and normalization
 * - Multi-platform validation
 * - Safeguard checks (trademark, copyright, quality)
 * - Staged publishing with retry
 * - Cross-platform analytics aggregation
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  NormalizedProduct,
  ProductInput,
  ConnectorResult,
  CreateResult,
  ValidationResult,
  ProductStatus,
  DateRange,
} from '../core/types';
import { BaseConnector } from '../core/base-connector';
import { PrintifyAdapter } from '../adapters/printify-adapter';
import { EtsyAdapter } from '../adapters/etsy-adapter';
import { GumroadAdapter } from '../adapters/gumroad-adapter';
import { ErrorCode } from '../utils/error-mapper';

// ============================================================================
// Workflow Types
// ============================================================================

export type PODPlatform = 'printify' | 'etsy' | 'gumroad' | 'redbubble' | 'teepublic' | 'creative-fabrica';

export interface WorkflowConfig {
  supabaseUrl: string;
  supabaseKey: string;
  enableSafeguards: boolean;
  maxRetries: number;
  retryDelayMs: number;
  parallelPublishing: boolean;
  dryRun: boolean;
}

export interface PublishTarget {
  platform: PODPlatform;
  enabled: boolean;
  priority: number;
  customSettings?: Record<string, unknown>;
}

export interface WorkflowResult {
  success: boolean;
  productId: string;
  platforms: PlatformPublishResult[];
  safeguardResults?: SafeguardCheckResult[];
  totalTime: number;
  errors: WorkflowError[];
}

export interface PlatformPublishResult {
  platform: PODPlatform;
  success: boolean;
  externalId?: string;
  externalUrl?: string;
  status: 'published' | 'pending' | 'failed' | 'skipped';
  error?: string;
  retryCount: number;
  duration: number;
}

export interface SafeguardCheckResult {
  name: string;
  passed: boolean;
  score?: number;
  reason?: string;
  metadata?: Record<string, unknown>;
}

export interface WorkflowError {
  platform?: PODPlatform;
  code: string;
  message: string;
  recoverable: boolean;
  timestamp: Date;
}

export interface WorkflowState {
  id: string;
  productId: string;
  status: 'pending' | 'validating' | 'safeguards' | 'publishing' | 'completed' | 'failed';
  currentPlatform?: PODPlatform;
  progress: number;
  startedAt: Date;
  updatedAt: Date;
  completedAt?: Date;
  results: Partial<WorkflowResult>;
}

export interface CrossPlatformAnalytics {
  dateRange: DateRange;
  totalRevenue: number;
  totalOrders: number;
  totalProducts: number;
  byPlatform: Record<PODPlatform, PlatformMetrics>;
  topProducts: TopProduct[];
  trends: TrendData[];
}

interface PlatformMetrics {
  revenue: number;
  orders: number;
  products: number;
  conversionRate: number;
  avgOrderValue: number;
}

interface TopProduct {
  id: string;
  title: string;
  platform: PODPlatform;
  revenue: number;
  orders: number;
}

interface TrendData {
  date: string;
  revenue: number;
  orders: number;
}

// ============================================================================
// Safeguard Integration Types
// ============================================================================

interface SafeguardsOrchestrator {
  checkProduct(product: ProductInput): Promise<SafeguardCheckResult[]>;
  isProductApproved(results: SafeguardCheckResult[]): boolean;
}

// ============================================================================
// POD Digital Workflow Engine
// ============================================================================

export class PODDigitalWorkflow {
  private connectors: Map<PODPlatform, BaseConnector> = new Map();
  private supabase: SupabaseClient;
  private config: WorkflowConfig;
  private safeguards: SafeguardsOrchestrator | null = null;
  private activeWorkflows: Map<string, WorkflowState> = new Map();

  constructor(config: WorkflowConfig) {
    this.config = config;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
  }

  // ============================================================================
  // Initialization
  // ============================================================================

  /**
   * Initialize connectors for specified platforms
   */
  async initialize(platforms: PODPlatform[]): Promise<void> {
    for (const platform of platforms) {
      try {
        const connector = await this.createConnector(platform);
        if (connector) {
          this.connectors.set(platform, connector);
        }
      } catch (error) {
        console.error(`Failed to initialize ${platform} connector:`, error);
      }
    }
  }

  /**
   * Set safeguards orchestrator for quality checks
   */
  setSafeguardsOrchestrator(orchestrator: SafeguardsOrchestrator): void {
    this.safeguards = orchestrator;
  }

  /**
   * Create a connector instance with credentials from database
   */
  private async createConnector(platform: PODPlatform): Promise<BaseConnector | null> {
    // Get credentials from database
    const { data: credentials, error } = await this.supabase
      .from('platform_credentials')
      .select('*')
      .eq('platform', platform)
      .single();

    if (error || !credentials) {
      console.warn(`No credentials found for ${platform}`);
      return null;
    }

    const baseConfig = {
      supabaseUrl: this.config.supabaseUrl,
      supabaseKey: this.config.supabaseKey,
    };

    switch (platform) {
      case 'printify':
        return new PrintifyAdapter(baseConfig);
      case 'etsy':
        return new EtsyAdapter(baseConfig);
      case 'gumroad':
        return new GumroadAdapter(baseConfig);
      default:
        console.warn(`Connector for ${platform} not yet implemented`);
        return null;
    }
  }

  // ============================================================================
  // Product Publishing Workflow
  // ============================================================================

  /**
   * Process and publish a product to multiple platforms
   */
  async processProduct(
    product: ProductInput,
    targets: PublishTarget[]
  ): Promise<WorkflowResult> {
    const workflowId = crypto.randomUUID();
    const startTime = Date.now();
    const errors: WorkflowError[] = [];
    const platformResults: PlatformPublishResult[] = [];
    let safeguardResults: SafeguardCheckResult[] = [];

    // Initialize workflow state
    const state: WorkflowState = {
      id: workflowId,
      productId: product.id || crypto.randomUUID(),
      status: 'pending',
      progress: 0,
      startedAt: new Date(),
      updatedAt: new Date(),
      results: {},
    };
    this.activeWorkflows.set(workflowId, state);

    try {
      // Step 1: Validate product structure
      state.status = 'validating';
      this.updateWorkflowState(workflowId, state);

      const validationResults = await this.validateForAllPlatforms(product, targets);
      const invalidPlatforms = validationResults.filter(r => !r.result.valid);

      if (invalidPlatforms.length > 0) {
        for (const invalid of invalidPlatforms) {
          platformResults.push({
            platform: invalid.platform,
            success: false,
            status: 'failed',
            error: invalid.result.errors.join(', '),
            retryCount: 0,
            duration: 0,
          });
        }
      }

      // Step 2: Run safeguard checks if enabled
      if (this.config.enableSafeguards && this.safeguards) {
        state.status = 'safeguards';
        state.progress = 20;
        this.updateWorkflowState(workflowId, state);

        safeguardResults = await this.safeguards.checkProduct(product);
        const approved = this.safeguards.isProductApproved(safeguardResults);

        if (!approved) {
          // Log to approval queue
          await this.logToApprovalQueue(product, safeguardResults);

          return {
            success: false,
            productId: state.productId,
            platforms: platformResults,
            safeguardResults,
            totalTime: Date.now() - startTime,
            errors: [{
              code: 'SAFEGUARD_BLOCKED',
              message: 'Product blocked by safeguard checks',
              recoverable: true,
              timestamp: new Date(),
            }],
          };
        }
      }

      // Step 3: Publish to platforms
      state.status = 'publishing';
      state.progress = 40;
      this.updateWorkflowState(workflowId, state);

      // Sort targets by priority
      const validTargets = targets
        .filter(t => t.enabled && !invalidPlatforms.find(p => p.platform === t.platform))
        .sort((a, b) => a.priority - b.priority);

      if (this.config.parallelPublishing) {
        // Publish to all platforms in parallel
        const publishPromises = validTargets.map(target =>
          this.publishToPlatform(product, target)
        );
        const results = await Promise.allSettled(publishPromises);

        results.forEach((result, index) => {
          if (result.status === 'fulfilled') {
            platformResults.push(result.value);
          } else {
            platformResults.push({
              platform: validTargets[index].platform,
              success: false,
              status: 'failed',
              error: result.reason?.message || 'Unknown error',
              retryCount: 0,
              duration: 0,
            });
          }
        });
      } else {
        // Publish sequentially
        for (const target of validTargets) {
          state.currentPlatform = target.platform;
          this.updateWorkflowState(workflowId, state);

          const result = await this.publishToPlatform(product, target);
          platformResults.push(result);

          // Update progress
          const completedCount = platformResults.length;
          state.progress = 40 + (completedCount / validTargets.length) * 50;
          this.updateWorkflowState(workflowId, state);
        }
      }

      // Step 4: Store mappings in database
      await this.storeProductMappings(state.productId, platformResults);

      // Step 5: Complete workflow
      state.status = 'completed';
      state.progress = 100;
      state.completedAt = new Date();
      this.updateWorkflowState(workflowId, state);

      const allSucceeded = platformResults.every(r => r.success);
      const someSucceeded = platformResults.some(r => r.success);

      return {
        success: allSucceeded || (someSucceeded && !this.config.dryRun),
        productId: state.productId,
        platforms: platformResults,
        safeguardResults,
        totalTime: Date.now() - startTime,
        errors,
      };

    } catch (error) {
      state.status = 'failed';
      this.updateWorkflowState(workflowId, state);

      errors.push({
        code: ErrorCode.UNKNOWN,
        message: error instanceof Error ? error.message : 'Unknown error',
        recoverable: false,
        timestamp: new Date(),
      });

      return {
        success: false,
        productId: state.productId,
        platforms: platformResults,
        safeguardResults,
        totalTime: Date.now() - startTime,
        errors,
      };
    } finally {
      // Cleanup workflow state after a delay
      setTimeout(() => {
        this.activeWorkflows.delete(workflowId);
      }, 60000);
    }
  }

  /**
   * Publish product to a single platform with retry logic
   */
  private async publishToPlatform(
    product: ProductInput,
    target: PublishTarget
  ): Promise<PlatformPublishResult> {
    const startTime = Date.now();
    const connector = this.connectors.get(target.platform);

    if (!connector) {
      return {
        platform: target.platform,
        success: false,
        status: 'skipped',
        error: 'Connector not initialized',
        retryCount: 0,
        duration: 0,
      };
    }

    if (this.config.dryRun) {
      return {
        platform: target.platform,
        success: true,
        status: 'skipped',
        error: 'Dry run mode - not published',
        retryCount: 0,
        duration: Date.now() - startTime,
      };
    }

    let lastError: string | undefined;
    let retryCount = 0;

    // Retry loop
    for (let attempt = 0; attempt <= this.config.maxRetries; attempt++) {
      try {
        const result = await connector.createProduct(product);

        if (result.success && result.data) {
          return {
            platform: target.platform,
            success: true,
            externalId: result.data.externalId,
            externalUrl: result.data.url,
            status: 'published',
            retryCount,
            duration: Date.now() - startTime,
          };
        }

        lastError = result.error?.message || 'Unknown error';

        // Check if error is retryable
        if (result.error && !result.error.retryable) {
          break;
        }

        retryCount++;

      } catch (error) {
        lastError = error instanceof Error ? error.message : 'Unknown error';
        retryCount++;
      }

      // Wait before retry
      if (attempt < this.config.maxRetries) {
        const delay = this.config.retryDelayMs * Math.pow(2, attempt);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    return {
      platform: target.platform,
      success: false,
      status: 'failed',
      error: lastError,
      retryCount,
      duration: Date.now() - startTime,
    };
  }

  // ============================================================================
  // Validation
  // ============================================================================

  /**
   * Validate product for all target platforms
   */
  private async validateForAllPlatforms(
    product: ProductInput,
    targets: PublishTarget[]
  ): Promise<Array<{ platform: PODPlatform; result: ValidationResult }>> {
    const results: Array<{ platform: PODPlatform; result: ValidationResult }> = [];

    for (const target of targets) {
      if (!target.enabled) continue;

      const connector = this.connectors.get(target.platform);
      if (!connector) {
        results.push({
          platform: target.platform,
          result: {
            valid: false,
            errors: ['Connector not available'],
            warnings: [],
          },
        });
        continue;
      }

      const result = connector.validateProductForPlatform(product);
      results.push({ platform: target.platform, result });
    }

    return results;
  }

  // ============================================================================
  // Database Operations
  // ============================================================================

  /**
   * Store product-platform mappings
   */
  private async storeProductMappings(
    productId: string,
    results: PlatformPublishResult[]
  ): Promise<void> {
    const mappings = results
      .filter(r => r.success && r.externalId)
      .map(r => ({
        product_id: productId,
        platform: r.platform,
        external_id: r.externalId,
        external_url: r.externalUrl,
        publish_status: r.status,
        last_sync_at: new Date().toISOString(),
      }));

    if (mappings.length > 0) {
      const { error } = await this.supabase
        .from('product_platform_mappings')
        .upsert(mappings, { onConflict: 'product_id,platform' });

      if (error) {
        console.error('Failed to store product mappings:', error);
      }
    }
  }

  /**
   * Log product to approval queue
   */
  private async logToApprovalQueue(
    product: ProductInput,
    safeguardResults: SafeguardCheckResult[]
  ): Promise<void> {
    const failedChecks = safeguardResults.filter(r => !r.passed);

    const { error } = await this.supabase
      .from('approval_queue')
      .insert({
        product_id: product.id,
        product_data: product,
        status: 'pending',
        safeguard_results: safeguardResults,
        auto_decision: 'blocked',
        blocking_safeguards: failedChecks.map(c => c.name),
        requested_at: new Date().toISOString(),
      });

    if (error) {
      console.error('Failed to log to approval queue:', error);
    }
  }

  // ============================================================================
  // Workflow State Management
  // ============================================================================

  private updateWorkflowState(id: string, state: WorkflowState): void {
    state.updatedAt = new Date();
    this.activeWorkflows.set(id, { ...state });
  }

  /**
   * Get current workflow state
   */
  getWorkflowState(id: string): WorkflowState | undefined {
    return this.activeWorkflows.get(id);
  }

  /**
   * Get all active workflows
   */
  getActiveWorkflows(): WorkflowState[] {
    return Array.from(this.activeWorkflows.values());
  }

  // ============================================================================
  // Bulk Operations
  // ============================================================================

  /**
   * Process multiple products in batch
   */
  async processBatch(
    products: ProductInput[],
    targets: PublishTarget[],
    options?: {
      concurrency?: number;
      stopOnError?: boolean;
    }
  ): Promise<WorkflowResult[]> {
    const concurrency = options?.concurrency || 3;
    const results: WorkflowResult[] = [];
    const queue = [...products];

    const processNext = async (): Promise<void> => {
      while (queue.length > 0) {
        const product = queue.shift();
        if (!product) break;

        try {
          const result = await this.processProduct(product, targets);
          results.push(result);

          if (!result.success && options?.stopOnError) {
            // Clear remaining queue
            queue.length = 0;
          }
        } catch (error) {
          if (options?.stopOnError) {
            queue.length = 0;
          }
        }
      }
    };

    // Run with concurrency limit
    const workers = Array(Math.min(concurrency, products.length))
      .fill(null)
      .map(() => processNext());

    await Promise.all(workers);
    return results;
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  /**
   * Get aggregated analytics across all POD/Digital platforms
   */
  async getCrossplatformAnalytics(dateRange: DateRange): Promise<CrossPlatformAnalytics> {
    const platformMetrics: Record<PODPlatform, PlatformMetrics> = {} as any;
    const topProducts: TopProduct[] = [];
    let totalRevenue = 0;
    let totalOrders = 0;
    let totalProducts = 0;

    // Gather analytics from each platform
    for (const [platform, connector] of this.connectors.entries()) {
      try {
        const result = await connector.getAnalytics(dateRange);

        if (result.success && result.data) {
          const data = result.data;
          totalRevenue += data.revenue;
          totalOrders += data.orders;

          platformMetrics[platform] = {
            revenue: data.revenue,
            orders: data.orders,
            products: data.topProducts.length,
            conversionRate: data.conversion,
            avgOrderValue: data.orders > 0 ? data.revenue / data.orders : 0,
          };

          totalProducts += data.topProducts.length;

          // Collect top products
          data.topProducts.forEach(p => {
            topProducts.push({
              id: p.id,
              title: p.title,
              platform,
              revenue: p.revenue,
              orders: p.sales,
            });
          });
        }
      } catch (error) {
        console.error(`Failed to get analytics for ${platform}:`, error);
      }
    }

    // Sort top products by revenue
    topProducts.sort((a, b) => b.revenue - a.revenue);

    return {
      dateRange,
      totalRevenue,
      totalOrders,
      totalProducts,
      byPlatform: platformMetrics,
      topProducts: topProducts.slice(0, 20),
      trends: [], // TODO: Implement trend calculation
    };
  }

  /**
   * Get sync status for all products
   */
  async getSyncStatus(): Promise<Record<PODPlatform, { synced: number; failed: number; pending: number }>> {
    const status: Record<string, { synced: number; failed: number; pending: number }> = {};

    const { data, error } = await this.supabase
      .from('product_platform_mappings')
      .select('platform, publish_status');

    if (error || !data) {
      return status as any;
    }

    for (const mapping of data) {
      if (!status[mapping.platform]) {
        status[mapping.platform] = { synced: 0, failed: 0, pending: 0 };
      }

      switch (mapping.publish_status) {
        case 'published':
          status[mapping.platform].synced++;
          break;
        case 'failed':
          status[mapping.platform].failed++;
          break;
        case 'pending':
        case 'draft':
          status[mapping.platform].pending++;
          break;
      }
    }

    return status as any;
  }

  // ============================================================================
  // Cleanup
  // ============================================================================

  /**
   * Disconnect all connectors
   */
  async shutdown(): Promise<void> {
    for (const [platform, connector] of this.connectors.entries()) {
      try {
        if ('disconnect' in connector && typeof connector.disconnect === 'function') {
          await connector.disconnect();
        }
      } catch (error) {
        console.error(`Error disconnecting ${platform}:`, error);
      }
    }
    this.connectors.clear();
    this.activeWorkflows.clear();
  }
}

export default PODDigitalWorkflow;
