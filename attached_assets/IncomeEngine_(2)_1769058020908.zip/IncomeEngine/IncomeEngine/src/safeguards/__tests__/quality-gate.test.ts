/**
 * ============================================================================
 * QUALITY GATE TEST SUITE
 * ============================================================================
 *
 * Tests for Safeguard #2: AI Quality Gates
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { QualityGate } from '../quality-gate';
import {
  createMockSupabaseClient,
  createMockOpenAIClient,
  createMockProduct,
  createMockQualityConfig,
  MockSupabaseClient,
  MockOpenAIClient
} from './test-utils';

// Mock modules
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn()
}));

vi.mock('openai', () => ({
  default: vi.fn()
}));

describe('Safeguard #2: Quality Gate', () => {
  let qualityGate: QualityGate;
  let mockSupabase: MockSupabaseClient;
  let mockOpenAI: MockOpenAIClient;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();
    mockOpenAI = createMockOpenAIClient();

    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    const openaiModule = require('openai');
    openaiModule.default.mockImplementation(() => mockOpenAI);

    qualityGate = new QualityGate(
      'https://test.supabase.co',
      'test-key',
      'test-openai-key'
    );
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // assessProduct Tests
  // ===========================================================================

  describe('assessProduct', () => {
    it('should pass high quality product', async () => {
      const product = createMockProduct({
        title: 'Beautiful Mandala Coloring Book for Adults',
        description: 'A stunning collection of 50 intricate mandala designs perfect for relaxation and stress relief. Each pattern is carefully crafted to provide hours of mindful coloring.'
      });

      const config = createMockQualityConfig({
        min_quality_score: 0.70,
        min_resolution_width: 2000,
        min_resolution_height: 2000
      });

      mockSupabase._setResponse(config);

      // Mock OpenAI image analysis response
      mockOpenAI._setCompletionResponse({
        choices: [{
          message: {
            content: JSON.stringify({
              hasWatermark: false,
              isBlurry: false,
              dominantColors: ['#333333', '#666666', '#999999'],
              styleKeywords: ['mandala', 'intricate', 'detailed', 'symmetrical'],
              detectedObjects: ['mandala pattern', 'circular design'],
              aestheticScore: 0.85
            })
          }
        }]
      });

      // Mock embeddings for style consistency
      mockOpenAI._setEmbeddingResponse({
        data: [{ embedding: new Array(1536).fill(0.5) }]
      });

      // Mock niche relevance
      mockOpenAI._setCompletionResponse({
        choices: [{
          message: {
            content: JSON.stringify({ score: 0.9, reason: 'Highly relevant to coloring niche' })
          }
        }]
      });

      const result = await qualityGate.assessProduct(product);

      expect(result.passed).toBe(true);
      expect(result.qualityScore).toBeGreaterThanOrEqual(0.70);
      expect(result.assessor).toBe('ai');
    });

    it('should fail product with watermark', async () => {
      const product = createMockProduct();
      const config = createMockQualityConfig();

      mockSupabase._setResponse(config);

      // Mock image analysis with watermark detected
      mockOpenAI._setCompletionResponse({
        choices: [{
          message: {
            content: JSON.stringify({
              hasWatermark: true,
              isBlurry: false,
              dominantColors: ['#333333'],
              styleKeywords: ['mandala'],
              detectedObjects: ['pattern'],
              aestheticScore: 0.7
            })
          }
        }]
      });

      const result = await qualityGate.assessProduct(product);

      expect(result.passed).toBe(false);
      expect(result.issuesDetected.some(i => i.type === 'composition' && i.message.includes('Watermark'))).toBe(true);
    });

    it('should fail blurry images', async () => {
      const product = createMockProduct();
      const config = createMockQualityConfig();

      mockSupabase._setResponse(config);

      mockOpenAI._setCompletionResponse({
        choices: [{
          message: {
            content: JSON.stringify({
              hasWatermark: false,
              isBlurry: true,
              dominantColors: ['#333333'],
              styleKeywords: ['blurry'],
              detectedObjects: ['unclear'],
              aestheticScore: 0.3
            })
          }
        }]
      });

      const result = await qualityGate.assessProduct(product);

      expect(result.issuesDetected.some(i => i.message.includes('blurry'))).toBe(true);
    });

    it('should detect banned style keywords', async () => {
      const product = createMockProduct();
      const config = createMockQualityConfig({
        banned_style_keywords: ['blurry', 'watermark', 'trademark', 'copyrighted']
      });

      mockSupabase._setResponse(config);

      mockOpenAI._setCompletionResponse({
        choices: [{
          message: {
            content: JSON.stringify({
              hasWatermark: false,
              isBlurry: false,
              dominantColors: ['#333333'],
              styleKeywords: ['copyrighted', 'disney-like', 'trademarked'],
              detectedObjects: ['character'],
              aestheticScore: 0.7
            })
          }
        }]
      });

      const result = await qualityGate.assessProduct(product);

      expect(result.issuesDetected.some(i => i.type === 'banned_content')).toBe(true);
    });

    it('should use default config when not found in database', async () => {
      const product = createMockProduct();

      // No config found - return null
      mockSupabase._setResponse(null, { message: 'Not found' });

      mockOpenAI._setCompletionResponse({
        choices: [{
          message: {
            content: JSON.stringify({
              hasWatermark: false,
              isBlurry: false,
              dominantColors: ['#333333'],
              styleKeywords: ['mandala'],
              detectedObjects: ['pattern'],
              aestheticScore: 0.8
            })
          }
        }]
      });

      const result = await qualityGate.assessProduct(product);

      // Should use default min_quality_score of 0.70
      expect(result).toBeDefined();
    });
  });

  // ===========================================================================
  // AI Pattern Detection Tests
  // ===========================================================================

  describe('AI Language Pattern Detection', () => {
    const aiPatterns = [
      /as an ai/i,
      /i cannot/i,
      /i'm sorry/i,
      /certainly!/i,
      /absolutely!/i,
      /delve into/i,
      /it's important to note/i,
      /in conclusion/i
    ];

    it('should detect "as an AI" pattern', () => {
      const text = 'As an AI, I think this is a beautiful design.';
      const hasPattern = aiPatterns.some(p => p.test(text));
      expect(hasPattern).toBe(true);
    });

    it('should detect "certainly!" pattern', () => {
      const text = 'Certainly! This mandala features intricate patterns.';
      const hasPattern = aiPatterns.some(p => p.test(text));
      expect(hasPattern).toBe(true);
    });

    it('should detect "delve into" pattern', () => {
      const text = "Let's delve into the artistic elements of this design.";
      const hasPattern = aiPatterns.some(p => p.test(text));
      expect(hasPattern).toBe(true);
    });

    it('should not flag natural product copy', () => {
      const text = 'Beautiful mandala patterns for relaxation and mindfulness. Perfect for adults who love coloring.';
      const hasPattern = aiPatterns.some(p => p.test(text));
      expect(hasPattern).toBe(false);
    });

    it('should detect multiple AI patterns', () => {
      const text = "Certainly! As an AI, I delve into the artistic elements. It's important to note that in conclusion...";
      const matchedPatterns = aiPatterns.filter(p => p.test(text));
      expect(matchedPatterns.length).toBeGreaterThan(3);
    });
  });

  // ===========================================================================
  // Resolution Validation Tests
  // ===========================================================================

  describe('Resolution Validation', () => {
    it('should pass images meeting minimum resolution', () => {
      const config = {
        min_resolution_width: 2400,
        min_resolution_height: 3000
      };

      const image = { width: 2400, height: 3000 };
      const passes = image.width >= config.min_resolution_width &&
                     image.height >= config.min_resolution_height;

      expect(passes).toBe(true);
    });

    it('should fail images below minimum width', () => {
      const config = {
        min_resolution_width: 2400,
        min_resolution_height: 3000
      };

      const image = { width: 2000, height: 3000 };
      const passes = image.width >= config.min_resolution_width &&
                     image.height >= config.min_resolution_height;

      expect(passes).toBe(false);
    });

    it('should fail images below minimum height', () => {
      const config = {
        min_resolution_width: 2400,
        min_resolution_height: 3000
      };

      const image = { width: 2400, height: 2500 };
      const passes = image.width >= config.min_resolution_width &&
                     image.height >= config.min_resolution_height;

      expect(passes).toBe(false);
    });

    it('should fail square images when rectangular required', () => {
      const config = {
        min_resolution_width: 2400,
        min_resolution_height: 3000
      };

      const image = { width: 2400, height: 2400 };
      const passes = image.width >= config.min_resolution_width &&
                     image.height >= config.min_resolution_height;

      expect(passes).toBe(false);
    });
  });

  // ===========================================================================
  // Copy Quality Tests
  // ===========================================================================

  describe('Copy Quality Assessment', () => {
    it('should flag too short title', () => {
      const title = 'Mandala';
      const issues = [];

      if (title.length < 10) {
        issues.push({
          type: 'composition',
          severity: 'warning',
          message: 'Title is too short (minimum 10 characters)',
          field: 'title'
        });
      }

      expect(issues.length).toBe(1);
      expect(issues[0].field).toBe('title');
    });

    it('should flag too long title', () => {
      const title = 'A'.repeat(250);
      const issues = [];

      if (title.length > 200) {
        issues.push({
          type: 'composition',
          severity: 'warning',
          message: 'Title is too long (maximum 200 characters)',
          field: 'title'
        });
      }

      expect(issues.length).toBe(1);
    });

    it('should flag too short description', () => {
      const description = 'Nice patterns.';
      const issues = [];

      if (description.length < 50) {
        issues.push({
          type: 'composition',
          severity: 'warning',
          message: 'Description is too short (minimum 50 characters)',
          field: 'description'
        });
      }

      expect(issues.length).toBe(1);
    });

    it('should detect keyword stuffing', () => {
      const description = 'mandala mandala mandala mandala mandala coloring book with mandala patterns';
      const words = description.toLowerCase().split(/\s+/);
      const wordCounts = new Map<string, number>();

      for (const word of words) {
        if (word.length > 3) {
          wordCounts.set(word, (wordCounts.get(word) || 0) + 1);
        }
      }

      const totalWords = words.length;
      let hasKeywordStuffing = false;

      for (const [word, count] of wordCounts) {
        if (count / totalWords > 0.05) {
          hasKeywordStuffing = true;
          break;
        }
      }

      expect(hasKeywordStuffing).toBe(true);
    });

    it('should pass natural description', () => {
      const description = 'Beautiful mandala patterns for relaxation and mindfulness. This coloring book features 50 unique designs for adults.';
      const words = description.toLowerCase().split(/\s+/);
      const wordCounts = new Map<string, number>();

      for (const word of words) {
        if (word.length > 3) {
          wordCounts.set(word, (wordCounts.get(word) || 0) + 1);
        }
      }

      const totalWords = words.length;
      let hasKeywordStuffing = false;

      for (const [word, count] of wordCounts) {
        if (count / totalWords > 0.05) {
          hasKeywordStuffing = true;
          break;
        }
      }

      expect(hasKeywordStuffing).toBe(false);
    });
  });

  // ===========================================================================
  // Overall Score Calculation Tests
  // ===========================================================================

  describe('Overall Score Calculation', () => {
    it('should calculate weighted score correctly', () => {
      const factors = {
        composition: 0.85,
        style: 0.80,
        niche: 0.90,
        originality: 0.75,
        issueCount: 1,
        criticalIssues: 0
      };

      // Weighted average
      let score = (
        factors.composition * 0.25 +
        factors.style * 0.20 +
        factors.niche * 0.20 +
        factors.originality * 0.35
      );

      // Penalize for issues
      score -= factors.issueCount * 0.02;
      score -= factors.criticalIssues * 0.15;

      score = Math.max(0, Math.min(1, score));

      expect(score).toBeCloseTo(0.8025, 2);
    });

    it('should heavily penalize critical issues', () => {
      const factors = {
        composition: 0.85,
        style: 0.80,
        niche: 0.90,
        originality: 0.75,
        issueCount: 2,
        criticalIssues: 1
      };

      let score = (
        factors.composition * 0.25 +
        factors.style * 0.20 +
        factors.niche * 0.20 +
        factors.originality * 0.35
      );

      score -= factors.issueCount * 0.02;
      score -= factors.criticalIssues * 0.15;

      score = Math.max(0, Math.min(1, score));

      // Score should be significantly reduced
      expect(score).toBeLessThan(0.70);
    });

    it('should clamp score between 0 and 1', () => {
      const factors = {
        composition: 1.0,
        style: 1.0,
        niche: 1.0,
        originality: 1.0,
        issueCount: 0,
        criticalIssues: 0
      };

      let score = (
        factors.composition * 0.25 +
        factors.style * 0.20 +
        factors.niche * 0.20 +
        factors.originality * 0.35
      );

      score = Math.max(0, Math.min(1, score));

      expect(score).toBeLessThanOrEqual(1);
      expect(score).toBeGreaterThanOrEqual(0);
    });

    it('should not go below 0 with many issues', () => {
      const factors = {
        composition: 0.5,
        style: 0.5,
        niche: 0.5,
        originality: 0.5,
        issueCount: 20,
        criticalIssues: 5
      };

      let score = (
        factors.composition * 0.25 +
        factors.style * 0.20 +
        factors.niche * 0.20 +
        factors.originality * 0.35
      );

      score -= factors.issueCount * 0.02;
      score -= factors.criticalIssues * 0.15;

      score = Math.max(0, Math.min(1, score));

      expect(score).toBe(0);
    });
  });

  // ===========================================================================
  // Cosine Similarity Tests
  // ===========================================================================

  describe('Cosine Similarity', () => {
    const cosineSimilarity = (a: number[], b: number[]): number => {
      if (a.length !== b.length) return 0;

      let dotProduct = 0;
      let normA = 0;
      let normB = 0;

      for (let i = 0; i < a.length; i++) {
        dotProduct += a[i] * b[i];
        normA += a[i] * a[i];
        normB += b[i] * b[i];
      }

      return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    };

    it('should return 1 for identical vectors', () => {
      const a = [1, 2, 3];
      const b = [1, 2, 3];

      expect(cosineSimilarity(a, b)).toBeCloseTo(1, 5);
    });

    it('should return 0 for orthogonal vectors', () => {
      const a = [1, 0, 0];
      const b = [0, 1, 0];

      expect(cosineSimilarity(a, b)).toBe(0);
    });

    it('should return -1 for opposite vectors', () => {
      const a = [1, 2, 3];
      const b = [-1, -2, -3];

      expect(cosineSimilarity(a, b)).toBeCloseTo(-1, 5);
    });

    it('should handle different length vectors', () => {
      const a = [1, 2, 3];
      const b = [1, 2];

      expect(cosineSimilarity(a, b)).toBe(0);
    });

    it('should calculate similarity for normalized vectors', () => {
      const a = [0.5, 0.5, 0.5, 0.5];
      const b = [0.6, 0.4, 0.5, 0.5];

      const similarity = cosineSimilarity(a, b);
      expect(similarity).toBeGreaterThan(0.9);
      expect(similarity).toBeLessThan(1);
    });
  });

  // ===========================================================================
  // storeStyleBaseline Tests
  // ===========================================================================

  describe('storeStyleBaseline', () => {
    it('should store style embedding for niche', async () => {
      mockOpenAI._setEmbeddingResponse({
        data: [{ embedding: new Array(1536).fill(0.5) }]
      });

      mockSupabase._setResponse({ id: 'style-123' });

      await qualityGate.storeStyleBaseline(
        'adult_coloring',
        'mandala',
        'Intricate geometric patterns with symmetrical designs'
      );

      expect(mockOpenAI.embeddings.create).toHaveBeenCalled();
      expect(mockSupabase.from).toHaveBeenCalledWith('style_embeddings');
    });
  });
});
