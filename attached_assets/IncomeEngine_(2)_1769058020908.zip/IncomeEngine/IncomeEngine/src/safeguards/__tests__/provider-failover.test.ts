/**
 * ============================================================================
 * PROVIDER FAILOVER TEST SUITE
 * ============================================================================
 *
 * Tests for Safeguard #5: Provider Failover
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { ProviderFailover, healthCheckers } from '../provider-failover';
import {
  createMockSupabaseClient,
  createMockProvider,
  createMockFetchResponse,
  mockFetch,
  MockSupabaseClient
} from './test-utils';

// Mock modules
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn()
}));

describe('Safeguard #5: Provider Failover', () => {
  let failover: ProviderFailover;
  let mockSupabase: MockSupabaseClient;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();

    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    failover = new ProviderFailover('https://test.supabase.co', 'test-key');
  });

  afterEach(() => {
    failover.stopHealthChecks();
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // getProvider Tests
  // ===========================================================================

  describe('getProvider', () => {
    it('should return primary provider when available', async () => {
      const providers = [
        createMockProvider({
          provider_name: 'openai',
          is_primary: true,
          is_available: true,
          health_score: 0.95
        }),
        createMockProvider({
          provider_name: 'replicate',
          is_primary: false,
          is_available: true,
          health_score: 0.90
        })
      ];

      mockSupabase._setResponse(providers);

      const result = await failover.getProvider('ai_generation');

      expect(result?.providerName).toBe('openai');
    });

    it('should return backup provider when primary unavailable', async () => {
      const providers = [
        createMockProvider({
          provider_name: 'openai',
          is_primary: true,
          is_available: false,
          health_score: 0
        }),
        createMockProvider({
          provider_name: 'replicate',
          is_primary: false,
          is_available: true,
          health_score: 0.90
        })
      ];

      // The query filters by is_available=true
      mockSupabase._setResponse([providers[1]]);

      const result = await failover.getProvider('ai_generation');

      expect(result?.providerName).toBe('replicate');
    });

    it('should return null when no providers available', async () => {
      mockSupabase._setResponse([]);

      const result = await failover.getProvider('ai_generation');

      expect(result).toBeNull();
    });

    it('should filter by required capabilities', async () => {
      const providers = [
        createMockProvider({
          provider_name: 'openai',
          is_primary: true,
          is_available: true,
          capabilities: { models: ['gpt-4o', 'dall-e-3'] }
        }),
        createMockProvider({
          provider_name: 'replicate',
          is_primary: false,
          is_available: true,
          capabilities: { models: ['flux-schnell', 'sdxl'] }
        })
      ];

      mockSupabase._setResponse(providers);

      // Require a model only available in replicate
      const result = await failover.getProvider('ai_generation', ['flux-schnell']);

      expect(result?.providerName).toBe('replicate');
    });

    it('should return null when no provider has required capabilities', async () => {
      const providers = [
        createMockProvider({
          provider_name: 'openai',
          capabilities: { models: ['gpt-4o'] }
        })
      ];

      mockSupabase._setResponse(providers);

      const result = await failover.getProvider('ai_generation', ['nonexistent-model']);

      expect(result).toBeNull();
    });
  });

  // ===========================================================================
  // reportFailure Tests
  // ===========================================================================

  describe('reportFailure', () => {
    it('should decrease health score on failure', async () => {
      mockSupabase._setResponse({
        failure_count_24h: 0,
        health_score: 1.0
      });

      mockSupabase._setResponse({ id: 'updated' });

      // Mock getProvider for failover
      mockSupabase._setResponse([createMockProvider({ provider_name: 'backup' })]);

      const nextProvider = await failover.reportFailure(
        'ai_generation',
        'openai',
        'API timeout'
      );

      expect(mockSupabase.from).toHaveBeenCalledWith('provider_health');
    });

    it('should mark provider unavailable after threshold failures', async () => {
      mockSupabase._setResponse({
        failure_count_24h: 10,
        health_score: 0.25
      });

      mockSupabase._setResponse({ id: 'updated' });
      mockSupabase._setResponse([createMockProvider({ provider_name: 'backup' })]);

      await failover.reportFailure('ai_generation', 'openai', 'Repeated failures');

      expect(mockSupabase.from).toHaveBeenCalledWith('provider_health');
    });

    it('should log failover event when switching providers', async () => {
      mockSupabase._setResponse({
        failure_count_24h: 5,
        health_score: 0.5
      });

      mockSupabase._setResponse({ id: 'updated' });

      // Return different provider
      mockSupabase._setResponse([
        createMockProvider({ provider_name: 'replicate' })
      ]);

      mockSupabase._setResponse({ id: 'failover-log' });

      const nextProvider = await failover.reportFailure(
        'ai_generation',
        'openai',
        'API error'
      );

      expect(nextProvider?.providerName).toBe('replicate');
    });
  });

  // ===========================================================================
  // reportSuccess Tests
  // ===========================================================================

  describe('reportSuccess', () => {
    it('should increase health score on success', async () => {
      mockSupabase._setResponse({
        avg_response_time_ms: 500,
        health_score: 0.9
      });

      mockSupabase._setResponse({ id: 'updated' });

      await failover.reportSuccess('ai_generation', 'openai', 450);

      expect(mockSupabase.from).toHaveBeenCalledWith('provider_health');
    });

    it('should update average response time', async () => {
      mockSupabase._setResponse({
        avg_response_time_ms: 500,
        health_score: 0.9
      });

      // Calculate new average: 0.9 * 500 + 0.1 * 300 = 480
      const currentAvg = 500;
      const newResponseTime = 300;
      const expectedNewAvg = Math.round((currentAvg * 0.9) + (newResponseTime * 0.1));

      expect(expectedNewAvg).toBe(480);
    });

    it('should cap health score at 1.0', async () => {
      const currentScore = 0.99;
      const increase = 0.01;
      const newScore = Math.min(1.0, currentScore + increase);

      expect(newScore).toBe(1.0);
    });
  });

  // ===========================================================================
  // markUnavailable / markAvailable Tests
  // ===========================================================================

  describe('markUnavailable', () => {
    it('should mark provider as unavailable', async () => {
      mockSupabase._setResponse({ id: 'updated' });

      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

      await failover.markUnavailable('ai_generation', 'openai');

      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('marked as unavailable')
      );

      consoleSpy.mockRestore();
    });
  });

  describe('markAvailable', () => {
    it('should mark provider as available with moderate health', async () => {
      mockSupabase._setResponse({ id: 'updated' });

      // Mock failover resolution check
      mockSupabase._setResponse({ provider_name: 'openai' });
      mockSupabase._setResponse({ id: 'resolved' });

      const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

      await failover.markAvailable('ai_generation', 'openai');

      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('marked as available')
      );

      consoleSpy.mockRestore();
    });
  });

  // ===========================================================================
  // Health Check Tests
  // ===========================================================================

  describe('Health Checks', () => {
    it('should register health checker function', () => {
      const checker = vi.fn().mockResolvedValue({ healthy: true, responseTimeMs: 100 });

      failover.registerHealthChecker('ai_generation', 'openai', checker);

      // Should not throw
      expect(true).toBe(true);
    });

    it('should run health checks on all providers', async () => {
      mockSupabase._setResponse([
        {
          provider_type: 'ai_generation',
          provider_name: 'openai',
          is_available: true
        }
      ]);

      // Mock success update
      mockSupabase._setResponse({ avg_response_time_ms: 500, health_score: 0.9 });
      mockSupabase._setResponse({ id: 'updated' });

      const checker = vi.fn().mockResolvedValue({ healthy: true, responseTimeMs: 100 });
      failover.registerHealthChecker('ai_generation', 'openai', checker);

      await failover.runHealthChecks();

      expect(checker).toHaveBeenCalled();
    });

    it('should report failure for unhealthy check', async () => {
      mockSupabase._setResponse([
        {
          provider_type: 'ai_generation',
          provider_name: 'openai',
          is_available: true
        }
      ]);

      // Mock failure path
      mockSupabase._setResponse({ failure_count_24h: 0, health_score: 1.0 });
      mockSupabase._setResponse({ id: 'updated' });
      mockSupabase._setResponse([]);

      const checker = vi.fn().mockResolvedValue({
        healthy: false,
        responseTimeMs: 0,
        error: 'Connection refused'
      });

      failover.registerHealthChecker('ai_generation', 'openai', checker);

      await failover.runHealthChecks();

      expect(checker).toHaveBeenCalled();
    });

    it('should start and stop health check interval', () => {
      failover.startHealthChecks(60000);

      // Should not throw when called twice
      failover.startHealthChecks(60000);

      failover.stopHealthChecks();

      // Should not throw when stopped twice
      failover.stopHealthChecks();
    });
  });

  // ===========================================================================
  // getStatus Tests
  // ===========================================================================

  describe('getStatus', () => {
    it('should return status grouped by provider type', async () => {
      mockSupabase._setResponse([
        createMockProvider({ provider_type: 'ai_generation', provider_name: 'openai' }),
        createMockProvider({ provider_type: 'ai_generation', provider_name: 'replicate' }),
        createMockProvider({ provider_type: 'pod_fulfillment', provider_name: 'printify' })
      ]);

      const status = await failover.getStatus();

      expect(status.ai_generation).toBeDefined();
      expect(status.pod_fulfillment).toBeDefined();
    });
  });

  // ===========================================================================
  // getRecentFailovers Tests
  // ===========================================================================

  describe('getRecentFailovers', () => {
    it('should return recent failover events', async () => {
      mockSupabase._setResponse([
        {
          id: 'failover-1',
          provider_type: 'ai_generation',
          from_provider: 'openai',
          to_provider: 'replicate',
          reason: 'API timeout',
          triggered_at: new Date().toISOString()
        }
      ]);

      const failovers = await failover.getRecentFailovers(10);

      expect(failovers.length).toBe(1);
      expect(failovers[0].from_provider).toBe('openai');
    });
  });

  // ===========================================================================
  // Pre-built Health Checkers Tests
  // ===========================================================================

  describe('Pre-built Health Checkers', () => {
    describe('printify', () => {
      it('should create printify health checker', () => {
        const checker = healthCheckers.printify('test-api-key');
        expect(typeof checker).toBe('function');
      });

      it('should return healthy for successful response', async () => {
        const fetchMock = mockFetch(() =>
          Promise.resolve(createMockFetchResponse({ shops: [] }))
        );

        const checker = healthCheckers.printify('test-api-key');
        const result = await checker();

        expect(result.healthy).toBe(true);
        expect(result.responseTimeMs).toBeGreaterThanOrEqual(0);

        vi.restoreAllMocks();
      });

      it('should return unhealthy for failed response', async () => {
        const fetchMock = mockFetch(() =>
          Promise.resolve(createMockFetchResponse({}, { ok: false, status: 500 }))
        );

        const checker = healthCheckers.printify('test-api-key');
        const result = await checker();

        expect(result.healthy).toBe(false);
        expect(result.error).toBe('HTTP 500');

        vi.restoreAllMocks();
      });
    });

    describe('openai', () => {
      it('should create openai health checker', () => {
        const checker = healthCheckers.openai('test-api-key');
        expect(typeof checker).toBe('function');
      });
    });

    describe('replicate', () => {
      it('should create replicate health checker', () => {
        const checker = healthCheckers.replicate('test-api-token');
        expect(typeof checker).toBe('function');
      });
    });

    describe('http (generic)', () => {
      it('should create generic http health checker', () => {
        const checker = healthCheckers.http('https://api.example.com/health');
        expect(typeof checker).toBe('function');
      });

      it('should support custom headers', async () => {
        const fetchMock = mockFetch(() =>
          Promise.resolve(createMockFetchResponse({ status: 'ok' }))
        );

        const checker = healthCheckers.http('https://api.example.com/health', {
          'X-Custom-Header': 'value'
        });

        const result = await checker();

        expect(result.healthy).toBe(true);

        vi.restoreAllMocks();
      });
    });
  });

  // ===========================================================================
  // Health Score Calculation Tests
  // ===========================================================================

  describe('Health Score Calculation', () => {
    it('should decrease by 0.1 on failure', () => {
      const currentScore = 1.0;
      const newScore = Math.max(0, currentScore - 0.1);

      expect(newScore).toBe(0.9);
    });

    it('should increase by 0.01 on success', () => {
      const currentScore = 0.9;
      const newScore = Math.min(1.0, currentScore + 0.01);

      expect(newScore).toBe(0.91);
    });

    it('should not go below 0', () => {
      const currentScore = 0.05;
      const newScore = Math.max(0, currentScore - 0.1);

      expect(newScore).toBe(0);
    });

    it('should trigger unavailable at 0.3 threshold', () => {
      const healthScore = 0.25;
      const failureCount = 5;

      const shouldMarkUnavailable = healthScore < 0.3 || failureCount > 10;

      expect(shouldMarkUnavailable).toBe(true);
    });

    it('should trigger unavailable at 10+ failures', () => {
      const healthScore = 0.5;
      const failureCount = 11;

      const shouldMarkUnavailable = healthScore < 0.3 || failureCount > 10;

      expect(shouldMarkUnavailable).toBe(true);
    });
  });

  // ===========================================================================
  // Average Response Time Calculation Tests
  // ===========================================================================

  describe('Average Response Time Calculation', () => {
    it('should calculate weighted average', () => {
      const currentAvg = 500;
      const newResponseTime = 300;
      const newAvg = Math.round((currentAvg * 0.9) + (newResponseTime * 0.1));

      expect(newAvg).toBe(480);
    });

    it('should use new time if no current average', () => {
      const currentAvg = undefined;
      const newResponseTime = 450;
      const newAvg = currentAvg !== undefined
        ? Math.round((currentAvg * 0.9) + (newResponseTime * 0.1))
        : newResponseTime;

      expect(newAvg).toBe(450);
    });
  });

  // ===========================================================================
  // Daily Failure Count Reset Tests
  // ===========================================================================

  describe('Daily Failure Count Reset', () => {
    it('should reset at midnight', () => {
      const testDate = new Date();
      testDate.setHours(0, 2, 0, 0); // 00:02 AM

      const shouldReset = testDate.getHours() === 0 && testDate.getMinutes() < 5;

      expect(shouldReset).toBe(true);
    });

    it('should not reset during the day', () => {
      const testDate = new Date();
      testDate.setHours(14, 30, 0, 0); // 2:30 PM

      const shouldReset = testDate.getHours() === 0 && testDate.getMinutes() < 5;

      expect(shouldReset).toBe(false);
    });
  });

  // ===========================================================================
  // Capability Matching Tests
  // ===========================================================================

  describe('Capability Matching', () => {
    it('should match capability from array', () => {
      const capabilities = { models: ['gpt-4o', 'dall-e-3'] };
      const required = 'gpt-4o';

      const hasCapability = Object.values(capabilities).some(v =>
        Array.isArray(v) ? v.includes(required) : v === required
      );

      expect(hasCapability).toBe(true);
    });

    it('should match capability from string value', () => {
      const capabilities = { version: 'v2' };
      const required = 'v2';

      const hasCapability = Object.values(capabilities).some(v =>
        Array.isArray(v) ? v.includes(required) : v === required
      );

      expect(hasCapability).toBe(true);
    });

    it('should not match missing capability', () => {
      const capabilities = { models: ['gpt-4o'] };
      const required = 'dall-e-3';

      const hasCapability = Object.values(capabilities).some(v =>
        Array.isArray(v) ? v.includes(required) : v === required
      );

      expect(hasCapability).toBe(false);
    });
  });
});
