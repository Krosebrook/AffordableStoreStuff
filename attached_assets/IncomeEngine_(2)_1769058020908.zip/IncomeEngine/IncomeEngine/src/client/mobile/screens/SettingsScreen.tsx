import React, { useState, useCallback } from 'react';

import { usePushNotifications } from '../../hooks/usePushNotifications';
import { useNetworkStatus } from '../../hooks/useNetworkStatus';
import { useOfflineSync } from '../../hooks/useOfflineSync';
import { DeviceDetection } from '../../lib/responsive';

/**
 * Toggle switch component
 */
function Toggle({
  enabled,
  onChange,
  disabled = false,
}: {
  enabled: boolean;
  onChange: (enabled: boolean) => void;
  disabled?: boolean;
}): React.ReactElement {
  return (
    <button
      onClick={() => !disabled && onChange(!enabled)}
      disabled={disabled}
      className={`relative w-12 h-7 rounded-full transition-colors ${
        disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
      } ${enabled ? 'bg-indigo-600' : 'bg-slate-600'}`}
    >
      <span
        className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full shadow-md transition-transform ${
          enabled ? 'translate-x-5' : 'translate-x-0'
        }`}
      />
    </button>
  );
}

/**
 * Settings section component
 */
function SettingsSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <div className="mb-6">
      <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
        {title}
      </h3>
      <div className="bg-slate-800/50 rounded-xl divide-y divide-slate-700">
        {children}
      </div>
    </div>
  );
}

/**
 * Settings row component
 */
function SettingsRow({
  icon,
  title,
  subtitle,
  action,
  onClick,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  onClick?: () => void;
}): React.ReactElement {
  const Component = onClick ? 'button' : 'div';

  return (
    <Component
      onClick={onClick}
      className={`w-full flex items-center gap-4 p-4 ${
        onClick ? 'hover:bg-slate-700/50 active:bg-slate-700 transition-colors text-left' : ''
      }`}
    >
      <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center flex-shrink-0">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium">{title}</p>
        {subtitle && <p className="text-sm text-gray-400 truncate">{subtitle}</p>}
      </div>
      {action}
    </Component>
  );
}

/**
 * Mobile settings screen
 */
export function SettingsScreen(): React.ReactElement {
  const pushNotifications = usePushNotifications();
  const { isOnline, effectiveType, saveData } = useNetworkStatus();
  const { hasPendingActions, pendingCount, syncNow, isSyncing, clearQueue } = useOfflineSync();

  const [notificationsEnabled, setNotificationsEnabled] = useState(
    pushNotifications.permission === 'granted'
  );

  const handleNotificationToggle = useCallback(
    async (enabled: boolean) => {
      if (enabled) {
        const granted = await pushNotifications.requestPermission();
        if (granted) {
          await pushNotifications.subscribeToPush();
          setNotificationsEnabled(true);
        }
      } else {
        await pushNotifications.unsubscribeFromPush();
        setNotificationsEnabled(false);
      }
    },
    [pushNotifications]
  );

  const handleSyncNow = useCallback(async () => {
    await syncNow();
  }, [syncNow]);

  const platform = DeviceDetection.getPlatform();
  const isNative = DeviceDetection.isCapacitor();

  return (
    <div className="p-4">
      {/* Notifications */}
      <SettingsSection title="Notifications">
        <SettingsRow
          icon={
            <svg className="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          }
          title="Push Notifications"
          subtitle={
            !pushNotifications.isSupported
              ? 'Not supported on this device'
              : notificationsEnabled
              ? 'Enabled'
              : 'Disabled'
          }
          action={
            <Toggle
              enabled={notificationsEnabled}
              onChange={handleNotificationToggle}
              disabled={!pushNotifications.isSupported || pushNotifications.isLoading}
            />
          }
        />

        <SettingsRow
          icon={
            <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          }
          title="Alert Notifications"
          subtitle="Get notified about budget limits and errors"
          action={<Toggle enabled={true} onChange={() => {}} />}
        />

        <SettingsRow
          icon={
            <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          }
          title="Approval Notifications"
          subtitle="Get notified when products need approval"
          action={<Toggle enabled={true} onChange={() => {}} />}
        />
      </SettingsSection>

      {/* Sync & Data */}
      <SettingsSection title="Sync & Data">
        <SettingsRow
          icon={
            <svg
              className={`w-5 h-5 ${isOnline ? 'text-green-400' : 'text-red-400'}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.14 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0" />
            </svg>
          }
          title="Connection Status"
          subtitle={
            isOnline
              ? `Online${effectiveType ? ` (${effectiveType.toUpperCase()})` : ''}`
              : 'Offline'
          }
        />

        {hasPendingActions && (
          <SettingsRow
            icon={
              <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            }
            title="Pending Actions"
            subtitle={`${pendingCount} action${pendingCount !== 1 ? 's' : ''} waiting to sync`}
            action={
              <button
                onClick={handleSyncNow}
                disabled={isSyncing || !isOnline}
                className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-sm font-medium disabled:opacity-50"
              >
                {isSyncing ? 'Syncing...' : 'Sync Now'}
              </button>
            }
          />
        )}

        <SettingsRow
          icon={
            <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
            </svg>
          }
          title="Data Saver"
          subtitle={saveData ? 'Active - reducing data usage' : 'Inactive'}
        />
      </SettingsSection>

      {/* App Info */}
      <SettingsSection title="App Info">
        <SettingsRow
          icon={
            <svg className="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
          }
          title="Income Engine"
          subtitle="Version 1.0.0"
        />

        <SettingsRow
          icon={
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          }
          title="Platform"
          subtitle={`${platform.charAt(0).toUpperCase() + platform.slice(1)}${isNative ? ' (Native)' : ' (PWA)'}`}
        />

        <SettingsRow
          icon={
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
          }
          title="Build"
          subtitle={import.meta.env.MODE === 'production' ? 'Production' : 'Development'}
        />
      </SettingsSection>

      {/* Danger Zone */}
      {hasPendingActions && (
        <SettingsSection title="Danger Zone">
          <SettingsRow
            icon={
              <svg className="w-5 h-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            }
            title="Clear Pending Actions"
            subtitle="Delete all queued offline actions"
            onClick={() => {
              if (window.confirm('Are you sure? This cannot be undone.')) {
                clearQueue();
              }
            }}
          />
        </SettingsSection>
      )}

      {/* Footer */}
      <div className="text-center text-xs text-gray-500 mt-8">
        <p>Income Engine Safeguards Dashboard</p>
        <p className="mt-1">Made with care for passive income automation</p>
      </div>
    </div>
  );
}

export default SettingsScreen;
