/**
 * ============================================================================
 * MOBILE ANALYTICS SCREEN
 * Responsive analytics dashboard for mobile devices
 * ============================================================================
 */

import React, { useState, useMemo, useCallback } from 'react';

import { useAnalyticsSummary, type DateRange } from '../../hooks/useAnalytics';
import { useNetworkStatus } from '../../hooks/useNetworkStatus';
import { PullToRefresh } from '../../components/mobile/PullToRefresh';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { RevenueChart } from '../../components/analytics/RevenueChart';
import { PlatformComparison } from '../../components/analytics/PlatformComparison';
import { ProductPerformance } from '../../components/analytics/ProductPerformance';
import { TrendIndicators } from '../../components/analytics/TrendIndicators';
import { formatChartValue } from '../../hooks/useChartData';
import {
  generateCSV,
  CSV_COLUMNS,
  downloadCSV,
} from '../../../services/reporting/export-csv';

type TimePeriod = '7d' | '30d' | '90d';
type ActiveTab = 'overview' | 'products' | 'platforms';

/**
 * KPI Card component for mobile
 */
function KPICard({
  label,
  value,
  gradient,
}: {
  label: string;
  value: string;
  gradient: string;
}): React.ReactElement {
  return (
    <div className={`${gradient} rounded-xl p-3`}>
      <p className="text-xs text-white/80">{label}</p>
      <p className="text-lg font-bold text-white truncate">{value}</p>
    </div>
  );
}

/**
 * Mobile Analytics Screen
 * Optimized for touch interactions and smaller screens
 */
export function AnalyticsScreen(): React.ReactElement {
  const { isOnline } = useNetworkStatus();

  // State
  const [timePeriod, setTimePeriod] = useState<TimePeriod>('30d');
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [showExportMenu, setShowExportMenu] = useState(false);

  // Calculate date range based on time period
  const dateRange = useMemo<DateRange>(() => {
    const now = new Date();
    let start: Date;

    switch (timePeriod) {
      case '7d':
        start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        start = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
      default:
        start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
    }

    return { start, end: now };
  }, [timePeriod]);

  // Fetch analytics data
  const { data: summary, isLoading, isError, error, refetch, isFetching } = useAnalyticsSummary({ dateRange });

  // Handle pull-to-refresh
  const handleRefresh = useCallback(async () => {
    await refetch();
  }, [refetch]);

  // Export handlers
  const handleExportCSV = useCallback(() => {
    if (!summary) return;

    const csvContent = [
      '=== REVENUE DATA ===',
      generateCSV(summary.revenueTimeSeries as Record<string, unknown>[], CSV_COLUMNS.revenue as never),
      '',
      '=== PLATFORM DATA ===',
      generateCSV(summary.platformBreakdown as Record<string, unknown>[], CSV_COLUMNS.platforms as never),
      '',
      '=== PRODUCT DATA ===',
      generateCSV(summary.topProducts as Record<string, unknown>[], CSV_COLUMNS.products as never),
    ].join('\n');

    downloadCSV(csvContent, `analytics-${timePeriod}-${Date.now()}.csv`);
    setShowExportMenu(false);
  }, [summary, timePeriod]);

  const handleExportJSON = useCallback(() => {
    if (!summary) return;

    const jsonData = JSON.stringify(summary, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `analytics-${timePeriod}-${Date.now()}.json`;
    link.click();

    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  }, [summary, timePeriod]);

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  // Error state
  if (isError) {
    return (
      <div className="p-4">
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <h3 className="font-semibold text-red-400">Failed to load analytics</h3>
          <p className="text-sm text-gray-400 mt-1">
            {error instanceof Error ? error.message : 'Unknown error occurred'}
          </p>
          <button
            onClick={() => refetch()}
            className="mt-3 px-4 py-2 bg-red-500 rounded-lg text-sm font-medium text-white"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!summary) return <div />;

  return (
    <PullToRefresh onRefresh={handleRefresh} isRefreshing={isFetching} className="h-full">
      <div className="pb-4">
        {/* Time Period Selector */}
        <div className="sticky top-0 z-10 bg-slate-900/95 backdrop-blur-sm px-4 py-3 border-b border-slate-700">
          <div className="flex items-center justify-between mb-3">
            <div className="flex gap-2">
              {(['7d', '30d', '90d'] as TimePeriod[]).map((period) => (
                <button
                  key={period}
                  onClick={() => setTimePeriod(period)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    timePeriod === period
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-gray-400'
                  }`}
                >
                  {period === '7d' ? '7D' : period === '30d' ? '30D' : '90D'}
                </button>
              ))}
            </div>

            {/* Export Button */}
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="p-2 bg-slate-800 rounded-lg"
                aria-label="Export data"
              >
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
              </button>

              {showExportMenu && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setShowExportMenu(false)}
                  />
                  <div className="absolute right-0 mt-2 w-40 bg-slate-800 border border-slate-700 rounded-xl shadow-xl py-2 z-20">
                    <button
                      onClick={handleExportCSV}
                      className="w-full px-4 py-2 text-left text-sm text-gray-300 hover:bg-slate-700 transition-colors"
                    >
                      Export CSV
                    </button>
                    <button
                      onClick={handleExportJSON}
                      className="w-full px-4 py-2 text-left text-sm text-gray-300 hover:bg-slate-700 transition-colors"
                    >
                      Export JSON
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex gap-1 bg-slate-800/50 p-1 rounded-lg">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'products', label: 'Products' },
              { id: 'platforms', label: 'Platforms' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as ActiveTab)}
                className={`flex-1 py-2 text-xs font-medium rounded-md transition-colors ${
                  activeTab === tab.id
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-400'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Offline Warning */}
        {!isOnline && (
          <div className="mx-4 mt-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
            <p className="text-sm text-amber-400">
              You are offline. Showing cached data.
            </p>
          </div>
        )}

        {/* Main Content */}
        <div className="p-4 space-y-4">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <>
              {/* KPI Cards */}
              <div className="grid grid-cols-2 gap-3">
                <KPICard
                  label="Total Revenue"
                  value={formatChartValue(summary.overview.totalRevenue, 'currency')}
                  gradient="bg-gradient-to-br from-indigo-600 to-purple-600"
                />
                <KPICard
                  label="Total Profit"
                  value={formatChartValue(summary.overview.totalProfit, 'currency')}
                  gradient="bg-gradient-to-br from-emerald-600 to-teal-600"
                />
                <KPICard
                  label="Total Orders"
                  value={summary.overview.totalOrders.toString()}
                  gradient="bg-gradient-to-br from-orange-600 to-amber-600"
                />
                <KPICard
                  label="Avg Order Value"
                  value={formatChartValue(summary.overview.avgOrderValue, 'currency')}
                  gradient="bg-gradient-to-br from-pink-600 to-rose-600"
                />
              </div>

              {/* Profit Margin */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Profit Margin</span>
                  <span className="text-xl font-bold text-green-400">
                    {(summary.overview.profitMargin * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="mt-2 h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-green-500 to-emerald-400 rounded-full transition-all"
                    style={{ width: `${Math.min(summary.overview.profitMargin * 100, 100)}%` }}
                  />
                </div>
              </div>

              {/* Revenue Chart */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <h3 className="text-sm font-semibold text-white mb-3">Revenue Trend</h3>
                <RevenueChart
                  data={summary.revenueTimeSeries}
                  showProfit
                  height={200}
                />
              </div>

              {/* Trend Indicators (Compact) */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <TrendIndicators
                  trends={summary.trends}
                  layout="compact"
                  showComparison={false}
                />
              </div>

              {/* Quick Platform View */}
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-white">Top Platforms</h3>
                  <button
                    onClick={() => setActiveTab('platforms')}
                    className="text-xs text-indigo-400"
                  >
                    View All
                  </button>
                </div>
                <PlatformComparison
                  platforms={summary.platformBreakdown}
                  chartType="horizontal"
                  metric="revenue"
                  showGrowth={false}
                  limit={3}
                  height={150}
                />
              </div>
            </>
          )}

          {/* Products Tab */}
          {activeTab === 'products' && (
            <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <ProductPerformance
                products={summary.topProducts}
                title="Top Products"
                maxItems={15}
                showRank
              />
            </div>
          )}

          {/* Platforms Tab */}
          {activeTab === 'platforms' && (
            <>
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <h3 className="text-sm font-semibold text-white mb-3">Revenue by Platform</h3>
                <PlatformComparison
                  platforms={summary.platformBreakdown}
                  chartType="horizontal"
                  metric="revenue"
                  showGrowth
                  height={300}
                />
              </div>

              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <h3 className="text-sm font-semibold text-white mb-3">Orders by Platform</h3>
                <PlatformComparison
                  platforms={summary.platformBreakdown}
                  chartType="horizontal"
                  metric="orders"
                  showGrowth={false}
                  height={250}
                />
              </div>

              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <h3 className="text-sm font-semibold text-white mb-3">Products by Platform</h3>
                <PlatformComparison
                  platforms={summary.platformBreakdown}
                  chartType="horizontal"
                  metric="products"
                  showGrowth={false}
                  height={250}
                />
              </div>
            </>
          )}
        </div>

        {/* Last Updated Footer */}
        <div className="px-4 py-3 text-center">
          <p className="text-xs text-gray-500">
            Last updated: {new Date().toLocaleTimeString()}
          </p>
        </div>
      </div>
    </PullToRefresh>
  );
}

export default AnalyticsScreen;
