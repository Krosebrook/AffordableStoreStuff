import React, { useCallback, useMemo } from 'react';

import { useSystemStatusQuery } from '../../hooks/useQueries';
import { PullToRefresh } from '../../components/mobile/PullToRefresh';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import type { CircuitBreakerState, BudgetStatus } from '../../types';

/**
 * Alert severity type
 */
type AlertSeverity = 'critical' | 'warning' | 'info';

/**
 * Unified alert interface
 */
interface Alert {
  id: string;
  type: 'circuit_breaker' | 'budget' | 'queue' | 'system';
  severity: AlertSeverity;
  title: string;
  message: string;
  timestamp?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

/**
 * Alert item component
 */
function AlertItem({ alert }: { alert: Alert }): React.ReactElement {
  const severityStyles = {
    critical: {
      bg: 'bg-red-500/20',
      border: 'border-red-500/50',
      icon: 'text-red-400',
      iconBg: 'bg-red-500/30',
    },
    warning: {
      bg: 'bg-amber-500/20',
      border: 'border-amber-500/50',
      icon: 'text-amber-400',
      iconBg: 'bg-amber-500/30',
    },
    info: {
      bg: 'bg-blue-500/20',
      border: 'border-blue-500/50',
      icon: 'text-blue-400',
      iconBg: 'bg-blue-500/30',
    },
  };

  const styles = severityStyles[alert.severity];

  const getIcon = () => {
    switch (alert.type) {
      case 'circuit_breaker':
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M13 10V3L4 14h7v7l9-11h-7z"
          />
        );
      case 'budget':
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        );
      case 'queue':
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
          />
        );
      default:
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
          />
        );
    }
  };

  return (
    <div className={`${styles.bg} border ${styles.border} rounded-xl p-4 mb-3`}>
      <div className="flex gap-3">
        <div className={`w-10 h-10 ${styles.iconBg} rounded-lg flex items-center justify-center flex-shrink-0`}>
          <svg className={`w-5 h-5 ${styles.icon}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {getIcon()}
          </svg>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-medium">{alert.title}</h3>
            {alert.timestamp && (
              <span className="text-xs text-gray-500 whitespace-nowrap">
                {formatTimeAgo(alert.timestamp)}
              </span>
            )}
          </div>
          <p className="text-sm text-gray-400 mt-1">{alert.message}</p>

          {alert.action && (
            <button
              onClick={alert.action.onClick}
              className="mt-2 text-sm text-indigo-400 font-medium hover:text-indigo-300"
            >
              {alert.action.label}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * Format time ago string
 */
function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();

  const minutes = Math.floor(diffMs / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'just now';
}

/**
 * Mobile alerts screen
 * Shows notifications and system alerts
 */
export function AlertsScreen(): React.ReactElement {
  const { data: status, isLoading, error, refetch, isFetching } = useSystemStatusQuery();

  const handleRefresh = useCallback(async () => {
    await refetch();
  }, [refetch]);

  // Build alerts from system status
  const alerts = useMemo(() => {
    if (!status) return [];

    const alertList: Alert[] = [];

    // Circuit breaker alerts
    if (status.circuitBreakers) {
      Object.entries(status.circuitBreakers).forEach(([name, breaker]) => {
        if (breaker.isOpen) {
          alertList.push({
            id: `cb-${name}`,
            type: 'circuit_breaker',
            severity: 'critical',
            title: `Circuit Breaker: ${formatBreakerName(name)}`,
            message: breaker.openedReason || 'System limit exceeded',
            timestamp: breaker.openedAt,
            action: breaker.willRetryAt
              ? { label: `Retry at ${new Date(breaker.willRetryAt).toLocaleTimeString()}`, onClick: () => {} }
              : undefined,
          });
        }
      });
    }

    // Budget alerts
    status.budget?.forEach((budget) => {
      if (budget.isExceeded) {
        alertList.push({
          id: `budget-exceeded-${budget.period}`,
          type: 'budget',
          severity: 'critical',
          title: `${capitalize(budget.period)} Budget Exceeded`,
          message: `Spent $${budget.currentSpend.toFixed(2)} of $${budget.limit.toFixed(2)} limit`,
        });
      } else if (budget.isWarning) {
        alertList.push({
          id: `budget-warning-${budget.period}`,
          type: 'budget',
          severity: 'warning',
          title: `${capitalize(budget.period)} Budget Warning`,
          message: `${budget.percentUsed.toFixed(0)}% of budget used ($${budget.remainingBudget.toFixed(2)} remaining)`,
        });
      }
    });

    // Dead letter queue alerts
    if (status.queues?.deadLetter > 0) {
      alertList.push({
        id: 'dead-letter',
        type: 'queue',
        severity: 'warning',
        title: 'Failed Tasks',
        message: `${status.queues.deadLetter} task${status.queues.deadLetter === 1 ? '' : 's'} in dead letter queue`,
      });
    }

    // Rate limited alerts
    if (status.queues?.rateLimited > 0) {
      alertList.push({
        id: 'rate-limited',
        type: 'queue',
        severity: 'info',
        title: 'Rate Limited',
        message: `${status.queues.rateLimited} API call${status.queues.rateLimited === 1 ? '' : 's'} waiting due to rate limits`,
      });
    }

    // Sort by severity
    const severityOrder: Record<AlertSeverity, number> = { critical: 0, warning: 1, info: 2 };
    return alertList.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);
  }, [status]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4">
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <h3 className="font-semibold text-red-400">Error Loading Alerts</h3>
          <button
            onClick={() => refetch()}
            className="mt-3 px-4 py-2 bg-red-500 rounded-lg text-sm font-medium"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh} isRefreshing={isFetching} className="h-full">
      <div className="p-4">
        {/* Alert Count */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-gray-400">
            {alerts.length} active alert{alerts.length !== 1 ? 's' : ''}
          </p>
        </div>

        {/* Empty State */}
        {alerts.length === 0 && (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                className="w-10 h-10 text-green-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <h3 className="font-semibold text-lg mb-1">All Systems Normal</h3>
            <p className="text-gray-400 text-sm">No alerts or warnings at this time</p>
          </div>
        )}

        {/* Alert List */}
        {alerts.length > 0 && (
          <div>
            {alerts.map((alert) => (
              <AlertItem key={alert.id} alert={alert} />
            ))}
          </div>
        )}

        {/* System Status Summary */}
        {status && (
          <div className="mt-6 bg-slate-800/50 rounded-xl p-4">
            <h3 className="font-semibold mb-3">System Status</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-400">Queued Tasks</p>
                <p className="text-xl font-semibold">{status.queues?.queued ?? 0}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Processing</p>
                <p className="text-xl font-semibold text-blue-400">
                  {status.queues?.processing ?? 0}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Completed Today</p>
                <p className="text-xl font-semibold text-green-400">
                  {status.queues?.completedToday ?? 0}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Approval Rate</p>
                <p className="text-xl font-semibold">
                  {((status.approvalStats?.approvalRate ?? 0) * 100).toFixed(0)}%
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </PullToRefresh>
  );
}

/**
 * Format breaker name for display
 */
function formatBreakerName(name: string): string {
  return name
    .replace(/_/g, ' ')
    .replace(/([A-Z])/g, ' $1')
    .trim()
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Capitalize first letter
 */
function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export default AlertsScreen;
