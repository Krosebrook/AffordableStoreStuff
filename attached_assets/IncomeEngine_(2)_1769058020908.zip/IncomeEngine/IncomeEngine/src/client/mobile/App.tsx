import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import { MainNavigator } from './navigation/MainNavigator';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { usePushNotifications } from '../hooks/usePushNotifications';
import { useOfflineSync } from '../hooks/useOfflineSync';
import { DeviceDetection } from '../lib/responsive';
import { initializeSafeArea } from '../lib/safe-area';
import { pushNotificationService } from '../services/push-notifications';
import { notificationHandler, type NotificationAction } from '../services/notification-handler';

/**
 * Initialize Capacitor plugins
 */
async function initializeCapacitor(): Promise<void> {
  if (!DeviceDetection.isCapacitor()) return;

  try {
    // Dynamic import for Capacitor plugins
    const [{ StatusBar }, { SplashScreen }, { App }] = await Promise.all([
      import('@capacitor/status-bar'),
      import('@capacitor/splash-screen'),
      import('@capacitor/app'),
    ]);

    // Configure status bar
    await StatusBar.setBackgroundColor({ color: '#1e293b' }); // slate-800
    await StatusBar.setStyle({ style: 'DARK' as any });

    // Hide splash screen after app is ready
    await SplashScreen.hide();

    // Handle app state changes
    App.addListener('appStateChange', ({ isActive }) => {
      if (isActive) {
        // App came to foreground - sync data
        console.log('App resumed');
      }
    });

    // Handle back button on Android
    App.addListener('backButton', ({ canGoBack }) => {
      if (!canGoBack) {
        App.exitApp();
      } else {
        window.history.back();
      }
    });
  } catch (error) {
    console.warn('Failed to initialize Capacitor plugins:', error);
  }
}

/**
 * Mobile app wrapper component
 * Handles mobile-specific initialization and navigation
 */
export function MobileApp(): React.ReactElement {
  const navigate = useNavigate();
  const { isOnline } = useNetworkStatus();
  const pushNotifications = usePushNotifications();
  const { hasPendingActions, syncNow } = useOfflineSync();

  // Initialize mobile-specific features
  useEffect(() => {
    // Initialize safe area handling
    initializeSafeArea();

    // Initialize Capacitor
    initializeCapacitor();

    // Initialize push notifications
    pushNotificationService.initialize();

    // Set up notification click handler
    notificationHandler.initialize();
    notificationHandler.setClickHandler((action: NotificationAction) => {
      switch (action.type) {
        case 'open_approvals':
          navigate('/approvals');
          break;
        case 'open_budget':
          navigate('/budget');
          break;
        case 'open_alerts':
          navigate('/alerts');
          break;
        case 'navigate':
          navigate(action.path);
          break;
        default:
          break;
      }
    });

    // Request notification permission after a delay
    const permissionTimeout = setTimeout(async () => {
      if (pushNotifications.permission === 'default' && pushNotifications.isSupported) {
        await pushNotifications.requestPermission();
      }
    }, 3000);

    return () => {
      clearTimeout(permissionTimeout);
    };
  }, [navigate, pushNotifications]);

  // Sync pending actions when coming online
  useEffect(() => {
    if (isOnline && hasPendingActions) {
      syncNow();
    }
  }, [isOnline, hasPendingActions, syncNow]);

  // Add mobile-specific body class
  useEffect(() => {
    document.body.classList.add('mobile-app');

    // Prevent bounce scrolling on iOS
    document.body.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.width = '100%';
    document.body.style.height = '100%';

    return () => {
      document.body.classList.remove('mobile-app');
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.width = '';
      document.body.style.height = '';
    };
  }, []);

  return <MainNavigator />;
}

export default MobileApp;
