import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';

import { MobileHeader } from '../../components/mobile/MobileHeader';
import { TabBar } from '../../components/mobile/TabBar';
import { OfflineIndicator } from '../../components/mobile/OfflineIndicator';
import { LoadingSpinner } from '../../components/LoadingSpinner';

// Lazy load mobile screens for code splitting
const DashboardScreen = lazy(() => import('../screens/DashboardScreen'));
const ApprovalsScreen = lazy(() => import('../screens/ApprovalsScreen'));
const AlertsScreen = lazy(() => import('../screens/AlertsScreen'));
const SettingsScreen = lazy(() => import('../screens/SettingsScreen'));
const AnalyticsScreen = lazy(() => import('../screens/AnalyticsScreen'));

// Import existing pages for non-mobile routes
const BudgetPage = lazy(() => import('../../pages/BudgetPage'));

/**
 * Main mobile navigator component
 * Provides tab navigation structure with header and footer
 */
export function MainNavigator(): React.ReactElement {
  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col">
      {/* Mobile Header */}
      <MobileHeader />

      {/* Offline Indicator */}
      <OfflineIndicator />

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-20">
        <Suspense
          fallback={
            <div className="flex items-center justify-center h-64">
              <LoadingSpinner />
            </div>
          }
        >
          <Routes>
            <Route path="/" element={<DashboardScreen />} />
            <Route path="/analytics" element={<AnalyticsScreen />} />
            <Route path="/approvals" element={<ApprovalsScreen />} />
            <Route path="/alerts" element={<AlertsScreen />} />
            <Route path="/settings" element={<SettingsScreen />} />
            <Route path="/budget" element={<BudgetPage />} />
          </Routes>
        </Suspense>
      </main>

      {/* Bottom Tab Navigation */}
      <TabBar />
    </div>
  );
}

export default MainNavigator;
