/**
 * Mobile route definitions
 * Centralized route configuration for mobile navigation
 */

export interface RouteConfig {
  path: string;
  label: string;
  icon: string;
  /** Show in bottom tab bar */
  showInTabs: boolean;
  /** Badge count key (for notifications) */
  badgeKey?: 'pendingApprovals' | 'alerts' | 'notifications';
}

/**
 * Main application routes
 */
export const ROUTES: Record<string, RouteConfig> = {
  dashboard: {
    path: '/',
    label: 'Dashboard',
    icon: 'dashboard',
    showInTabs: true,
  },
  analytics: {
    path: '/analytics',
    label: 'Analytics',
    icon: 'chart',
    showInTabs: true,
  },
  approvals: {
    path: '/approvals',
    label: 'Approvals',
    icon: 'clipboard',
    showInTabs: true,
    badgeKey: 'pendingApprovals',
  },
  alerts: {
    path: '/alerts',
    label: 'Alerts',
    icon: 'bell',
    showInTabs: true,
    badgeKey: 'alerts',
  },
  settings: {
    path: '/settings',
    label: 'Settings',
    icon: 'cog',
    showInTabs: true,
  },
  budget: {
    path: '/budget',
    label: 'Budget',
    icon: 'wallet',
    showInTabs: false,
  },
};

/**
 * Get routes for tab navigation
 */
export function getTabRoutes(): RouteConfig[] {
  return Object.values(ROUTES).filter((route) => route.showInTabs);
}

/**
 * Get route by path
 */
export function getRouteByPath(path: string): RouteConfig | undefined {
  return Object.values(ROUTES).find((route) => route.path === path);
}

/**
 * Icon component mapping
 * Maps icon names to SVG path data or emoji
 */
export const ICONS: Record<string, string> = {
  dashboard: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6',
  chart: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
  clipboard: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4',
  bell: 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9',
  cog: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
  wallet: 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z',
  check: 'M5 13l4 4L19 7',
  x: 'M6 18L18 6M6 6l12 12',
  refresh: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
  wifi: 'M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.14 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0',
  wifiOff: 'M1 1l22 22M16.72 11.06A10.94 10.94 0 0119 12.55M5 12.55a10.94 10.94 0 015.17-2.39M10.71 5.05A16 16 0 0122.58 9M1.42 9a15.91 15.91 0 014.7-2.88M8.53 16.11a6 6 0 016.95 0M12 20h.01',
};
