import { useState, useEffect, useCallback } from 'react';

import { DeviceDetection } from '../lib/responsive';

/**
 * Push notification permission state
 */
type PermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

/**
 * Notification payload structure
 */
interface NotificationPayload {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  data?: Record<string, unknown>;
  requireInteraction?: boolean;
  actions?: Array<{
    action: string;
    title: string;
    icon?: string;
  }>;
}

/**
 * Push notification hook state
 */
interface PushNotificationState {
  /** Current permission state */
  permission: PermissionState;
  /** Whether push is supported */
  isSupported: boolean;
  /** Whether user has enabled notifications */
  isEnabled: boolean;
  /** Whether currently registering */
  isLoading: boolean;
  /** Last error message */
  error: string | null;
  /** Request notification permission */
  requestPermission: () => Promise<boolean>;
  /** Send a local notification */
  sendNotification: (payload: NotificationPayload) => Promise<void>;
  /** Subscribe to push notifications */
  subscribeToPush: () => Promise<void>;
  /** Unsubscribe from push notifications */
  unsubscribeFromPush: () => Promise<void>;
}

const VAPID_PUBLIC_KEY = import.meta.env.VITE_VAPID_PUBLIC_KEY || '';

/**
 * Convert base64 VAPID key to Uint8Array
 */
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

/**
 * Hook for push notification management
 * Handles permission requests, subscription, and local notifications
 */
export function usePushNotifications(): PushNotificationState {
  const [permission, setPermission] = useState<PermissionState>(() => {
    if (typeof Notification === 'undefined') return 'unsupported';
    return Notification.permission as PermissionState;
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [subscription, setSubscription] = useState<PushSubscription | null>(null);

  const isSupported =
    typeof Notification !== 'undefined' &&
    'serviceWorker' in navigator &&
    'PushManager' in window;

  const isEnabled = permission === 'granted' && subscription !== null;

  // Check for existing subscription on mount
  useEffect(() => {
    if (!isSupported) return;

    const checkSubscription = async () => {
      try {
        const registration = await navigator.serviceWorker.ready;
        const existingSubscription = await registration.pushManager.getSubscription();
        setSubscription(existingSubscription);
      } catch (e) {
        console.error('Error checking push subscription:', e);
      }
    };

    checkSubscription();
  }, [isSupported]);

  /**
   * Request notification permission from user
   */
  const requestPermission = useCallback(async (): Promise<boolean> => {
    if (!isSupported) {
      setError('Push notifications are not supported');
      return false;
    }

    try {
      setIsLoading(true);
      setError(null);

      const result = await Notification.requestPermission();
      setPermission(result as PermissionState);

      return result === 'granted';
    } catch (e) {
      setError('Failed to request permission');
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [isSupported]);

  /**
   * Send a local notification
   */
  const sendNotification = useCallback(
    async (payload: NotificationPayload): Promise<void> => {
      if (permission !== 'granted') {
        throw new Error('Notification permission not granted');
      }

      try {
        // Use service worker for notifications on mobile
        if (DeviceDetection.isCapacitor() || 'serviceWorker' in navigator) {
          const registration = await navigator.serviceWorker.ready;
          await registration.showNotification(payload.title, {
            body: payload.body,
            icon: payload.icon || '/icons/icon-192.png',
            badge: payload.badge || '/icons/badge-72.png',
            tag: payload.tag,
            data: payload.data,
            requireInteraction: payload.requireInteraction,
            actions: payload.actions,
          });
        } else {
          // Fallback to basic notification
          new Notification(payload.title, {
            body: payload.body,
            icon: payload.icon,
            tag: payload.tag,
            data: payload.data,
          });
        }
      } catch (e) {
        console.error('Failed to show notification:', e);
        throw e;
      }
    },
    [permission]
  );

  /**
   * Subscribe to push notifications
   */
  const subscribeToPush = useCallback(async (): Promise<void> => {
    if (!isSupported) {
      throw new Error('Push notifications not supported');
    }

    if (!VAPID_PUBLIC_KEY) {
      console.warn('VAPID public key not configured');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      // Ensure permission is granted
      if (permission !== 'granted') {
        const granted = await requestPermission();
        if (!granted) {
          throw new Error('Permission denied');
        }
      }

      // Get service worker registration
      const registration = await navigator.serviceWorker.ready;

      // Subscribe to push
      const pushSubscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });

      setSubscription(pushSubscription);

      // Send subscription to server
      await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pushSubscription.toJSON()),
      });
    } catch (e) {
      const message = e instanceof Error ? e.message : 'Failed to subscribe';
      setError(message);
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [isSupported, permission, requestPermission]);

  /**
   * Unsubscribe from push notifications
   */
  const unsubscribeFromPush = useCallback(async (): Promise<void> => {
    if (!subscription) return;

    try {
      setIsLoading(true);
      setError(null);

      // Unsubscribe from push
      await subscription.unsubscribe();

      // Notify server
      await fetch('/api/push/unsubscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint: subscription.endpoint }),
      });

      setSubscription(null);
    } catch (e) {
      setError('Failed to unsubscribe');
      throw e;
    } finally {
      setIsLoading(false);
    }
  }, [subscription]);

  return {
    permission,
    isSupported,
    isEnabled,
    isLoading,
    error,
    requestPermission,
    sendNotification,
    subscribeToPush,
    unsubscribeFromPush,
  };
}

export default usePushNotifications;
