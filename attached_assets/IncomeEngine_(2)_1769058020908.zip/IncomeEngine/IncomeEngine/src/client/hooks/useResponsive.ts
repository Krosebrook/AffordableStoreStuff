import { useState, useEffect, useCallback } from 'react';

import {
  BREAKPOINTS,
  type Breakpoint,
  getCurrentBreakpoint,
  createBreakpointListener,
  DeviceDetection,
} from '../lib/responsive';

/**
 * Responsive state
 */
interface ResponsiveState {
  /** Current breakpoint name */
  breakpoint: Breakpoint | 'xs';
  /** Whether viewport is mobile size (under md) */
  isMobile: boolean;
  /** Whether viewport is tablet size (md to lg) */
  isTablet: boolean;
  /** Whether viewport is desktop size (lg and above) */
  isDesktop: boolean;
  /** Whether device is touch-enabled */
  isTouch: boolean;
  /** Current platform */
  platform: 'ios' | 'android' | 'web';
  /** Whether running in Capacitor */
  isCapacitor: boolean;
  /** Whether running as PWA */
  isPWA: boolean;
  /** Current window width */
  width: number;
  /** Current window height */
  height: number;
}

/**
 * Hook for responsive design utilities
 * Provides breakpoint detection and device info
 */
export function useResponsive(): ResponsiveState {
  const [state, setState] = useState<ResponsiveState>(() => ({
    breakpoint: getCurrentBreakpoint(),
    isMobile: typeof window !== 'undefined' ? window.innerWidth < BREAKPOINTS.md : false,
    isTablet: typeof window !== 'undefined'
      ? window.innerWidth >= BREAKPOINTS.md && window.innerWidth < BREAKPOINTS.lg
      : false,
    isDesktop: typeof window !== 'undefined' ? window.innerWidth >= BREAKPOINTS.lg : true,
    isTouch: DeviceDetection.isTouchDevice(),
    platform: DeviceDetection.getPlatform(),
    isCapacitor: DeviceDetection.isCapacitor(),
    isPWA: DeviceDetection.isPWA(),
    width: typeof window !== 'undefined' ? window.innerWidth : 1024,
    height: typeof window !== 'undefined' ? window.innerHeight : 768,
  }));

  const updateState = useCallback(() => {
    setState({
      breakpoint: getCurrentBreakpoint(),
      isMobile: window.innerWidth < BREAKPOINTS.md,
      isTablet: window.innerWidth >= BREAKPOINTS.md && window.innerWidth < BREAKPOINTS.lg,
      isDesktop: window.innerWidth >= BREAKPOINTS.lg,
      isTouch: DeviceDetection.isTouchDevice(),
      platform: DeviceDetection.getPlatform(),
      isCapacitor: DeviceDetection.isCapacitor(),
      isPWA: DeviceDetection.isPWA(),
      width: window.innerWidth,
      height: window.innerHeight,
    });
  }, []);

  useEffect(() => {
    // Listen for resize events
    window.addEventListener('resize', updateState);

    // Listen for orientation changes
    window.addEventListener('orientationchange', () => {
      // Delay to allow layout to settle
      setTimeout(updateState, 100);
    });

    return () => {
      window.removeEventListener('resize', updateState);
      window.removeEventListener('orientationchange', updateState);
    };
  }, [updateState]);

  return state;
}

/**
 * Hook for detecting if above a specific breakpoint
 */
export function useBreakpoint(breakpoint: Breakpoint): boolean {
  const [matches, setMatches] = useState(() => {
    if (typeof window === 'undefined') return false;
    return window.innerWidth >= BREAKPOINTS[breakpoint];
  });

  useEffect(() => {
    return createBreakpointListener(breakpoint, setMatches);
  }, [breakpoint]);

  return matches;
}

/**
 * Hook for detecting orientation
 */
export function useOrientation(): 'portrait' | 'landscape' {
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>(() => {
    if (typeof window === 'undefined') return 'portrait';
    return window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
  });

  useEffect(() => {
    const handleResize = () => {
      setOrientation(window.innerHeight > window.innerWidth ? 'portrait' : 'landscape');
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', () => {
      setTimeout(handleResize, 100);
    });

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  return orientation;
}

/**
 * Hook for reduced motion preference
 */
export function useReducedMotion(): boolean {
  const [reducedMotion, setReducedMotion] = useState(() => {
    if (typeof window === 'undefined') return false;
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });

  useEffect(() => {
    const mql = window.matchMedia('(prefers-reduced-motion: reduce)');

    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);

    mql.addEventListener('change', handler);
    return () => mql.removeEventListener('change', handler);
  }, []);

  return reducedMotion;
}

export default useResponsive;
