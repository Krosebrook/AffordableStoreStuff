/**
 * Responsive utilities for mobile-first development
 * Provides breakpoint detection and responsive helpers
 */

/**
 * Tailwind-aligned breakpoints
 */
export const BREAKPOINTS = {
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
  '2xl': 1536,
} as const;

export type Breakpoint = keyof typeof BREAKPOINTS;

/**
 * Check if current viewport matches or exceeds a breakpoint
 */
export function isBreakpoint(breakpoint: Breakpoint): boolean {
  if (typeof window === 'undefined') return false;
  return window.innerWidth >= BREAKPOINTS[breakpoint];
}

/**
 * Get current breakpoint name
 */
export function getCurrentBreakpoint(): Breakpoint | 'xs' {
  if (typeof window === 'undefined') return 'xs';

  const width = window.innerWidth;

  if (width >= BREAKPOINTS['2xl']) return '2xl';
  if (width >= BREAKPOINTS.xl) return 'xl';
  if (width >= BREAKPOINTS.lg) return 'lg';
  if (width >= BREAKPOINTS.md) return 'md';
  if (width >= BREAKPOINTS.sm) return 'sm';
  return 'xs';
}

/**
 * Check if device is mobile (under md breakpoint)
 */
export function isMobileViewport(): boolean {
  return !isBreakpoint('md');
}

/**
 * Check if device is tablet (md to lg)
 */
export function isTabletViewport(): boolean {
  return isBreakpoint('md') && !isBreakpoint('lg');
}

/**
 * Check if device is desktop (lg and above)
 */
export function isDesktopViewport(): boolean {
  return isBreakpoint('lg');
}

/**
 * Device detection utilities
 */
export const DeviceDetection = {
  /**
   * Check if running on iOS
   */
  isIOS(): boolean {
    if (typeof navigator === 'undefined') return false;
    return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  },

  /**
   * Check if running on Android
   */
  isAndroid(): boolean {
    if (typeof navigator === 'undefined') return false;
    return /Android/.test(navigator.userAgent);
  },

  /**
   * Check if running in Capacitor native container
   */
  isCapacitor(): boolean {
    return typeof (window as any).Capacitor !== 'undefined';
  },

  /**
   * Check if running as PWA (installed to home screen)
   */
  isPWA(): boolean {
    if (typeof window === 'undefined') return false;
    return window.matchMedia('(display-mode: standalone)').matches ||
           (window.navigator as any).standalone === true;
  },

  /**
   * Check if touch device
   */
  isTouchDevice(): boolean {
    if (typeof window === 'undefined') return false;
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  },

  /**
   * Get platform type
   */
  getPlatform(): 'ios' | 'android' | 'web' {
    if (this.isIOS()) return 'ios';
    if (this.isAndroid()) return 'android';
    return 'web';
  },
};

/**
 * Create media query listener
 */
export function createMediaQueryListener(
  query: string,
  callback: (matches: boolean) => void
): () => void {
  if (typeof window === 'undefined') return () => {};

  const mql = window.matchMedia(query);

  const handler = (e: MediaQueryListEvent) => callback(e.matches);

  // Initial call
  callback(mql.matches);

  // Listen for changes
  mql.addEventListener('change', handler);

  // Return cleanup function
  return () => mql.removeEventListener('change', handler);
}

/**
 * Create breakpoint listener
 */
export function createBreakpointListener(
  breakpoint: Breakpoint,
  callback: (matches: boolean) => void
): () => void {
  return createMediaQueryListener(
    `(min-width: ${BREAKPOINTS[breakpoint]}px)`,
    callback
  );
}
