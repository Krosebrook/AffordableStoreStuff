/**
 * Safe area handling utilities for mobile devices
 * Handles notches, home indicators, and other device-specific insets
 */

/**
 * Safe area inset values
 */
export interface SafeAreaInsets {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

/**
 * Default safe area insets
 */
const DEFAULT_INSETS: SafeAreaInsets = {
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
};

/**
 * Get computed safe area insets from CSS environment variables
 */
export function getSafeAreaInsets(): SafeAreaInsets {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return DEFAULT_INSETS;
  }

  const computedStyle = getComputedStyle(document.documentElement);

  const parseInset = (property: string): number => {
    const value = computedStyle.getPropertyValue(property);
    return parseInt(value, 10) || 0;
  };

  return {
    top: parseInset('--sat') || parseEnvInset('safe-area-inset-top'),
    right: parseInset('--sar') || parseEnvInset('safe-area-inset-right'),
    bottom: parseInset('--sab') || parseEnvInset('safe-area-inset-bottom'),
    left: parseInset('--sal') || parseEnvInset('safe-area-inset-left'),
  };
}

/**
 * Parse CSS environment inset value
 */
function parseEnvInset(name: string): number {
  if (typeof document === 'undefined') return 0;

  // Create a temporary element to measure the env() value
  const temp = document.createElement('div');
  temp.style.position = 'absolute';
  temp.style.visibility = 'hidden';
  temp.style.height = `env(${name}, 0px)`;
  document.body.appendChild(temp);

  const height = temp.offsetHeight;
  document.body.removeChild(temp);

  return height;
}

/**
 * Apply safe area CSS custom properties to document
 */
export function applySafeAreaProperties(): void {
  if (typeof document === 'undefined') return;

  const style = document.documentElement.style;

  // Set CSS custom properties that mirror env() values
  style.setProperty('--sat', 'env(safe-area-inset-top, 0px)');
  style.setProperty('--sar', 'env(safe-area-inset-right, 0px)');
  style.setProperty('--sab', 'env(safe-area-inset-bottom, 0px)');
  style.setProperty('--sal', 'env(safe-area-inset-left, 0px)');
}

/**
 * Get status bar height (approximation for different devices)
 */
export function getStatusBarHeight(): number {
  const insets = getSafeAreaInsets();

  // On devices with notch, top inset includes status bar
  if (insets.top > 0) {
    return insets.top;
  }

  // Default status bar heights
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  return isIOS ? 20 : 24;
}

/**
 * Get home indicator height (for devices with gesture navigation)
 */
export function getHomeIndicatorHeight(): number {
  const insets = getSafeAreaInsets();
  return insets.bottom;
}

/**
 * CSS helper classes for safe area handling
 */
export const SafeAreaClasses = {
  /** Padding for top safe area */
  paddingTop: 'pt-[env(safe-area-inset-top)]',

  /** Padding for bottom safe area */
  paddingBottom: 'pb-[env(safe-area-inset-bottom)]',

  /** Padding for left safe area */
  paddingLeft: 'pl-[env(safe-area-inset-left)]',

  /** Padding for right safe area */
  paddingRight: 'pr-[env(safe-area-inset-right)]',

  /** Full safe area padding */
  paddingAll: 'pt-[env(safe-area-inset-top)] pr-[env(safe-area-inset-right)] pb-[env(safe-area-inset-bottom)] pl-[env(safe-area-inset-left)]',

  /** Margin for top safe area */
  marginTop: 'mt-[env(safe-area-inset-top)]',

  /** Margin for bottom safe area */
  marginBottom: 'mb-[env(safe-area-inset-bottom)]',
};

/**
 * Initialize safe area handling
 * Call this once at app startup
 */
export function initializeSafeArea(): void {
  if (typeof document === 'undefined') return;

  // Apply CSS custom properties
  applySafeAreaProperties();

  // Add viewport-fit=cover meta tag if not present
  let viewport = document.querySelector('meta[name="viewport"]');
  if (viewport) {
    const content = viewport.getAttribute('content') || '';
    if (!content.includes('viewport-fit=cover')) {
      viewport.setAttribute('content', `${content}, viewport-fit=cover`);
    }
  }
}
