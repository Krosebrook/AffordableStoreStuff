import React, { useState, useRef, useCallback, memo } from 'react';

interface SwipeableCardProps {
  /** Card content */
  children: React.ReactNode;
  /** Called when swiped right (approve) */
  onSwipeRight?: () => void;
  /** Called when swiped left (reject) */
  onSwipeLeft?: () => void;
  /** Label for right swipe action */
  rightLabel?: string;
  /** Label for left swipe action */
  leftLabel?: string;
  /** Minimum swipe distance to trigger action (px) */
  threshold?: number;
  /** Additional className */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
}

/**
 * Swipeable card component for quick actions
 * Supports left/right swipe gestures for approve/reject actions
 */
export const SwipeableCard = memo(function SwipeableCard({
  children,
  onSwipeRight,
  onSwipeLeft,
  rightLabel = 'Approve',
  leftLabel = 'Reject',
  threshold = 100,
  className = '',
  disabled = false,
}: SwipeableCardProps): React.ReactElement {
  const [translateX, setTranslateX] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef<number>(0);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      if (disabled) return;
      startXRef.current = e.touches[0].clientX;
      setIsDragging(true);
    },
    [disabled]
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (!isDragging || disabled) return;

      const currentX = e.touches[0].clientX;
      const diff = currentX - startXRef.current;

      // Limit swipe range and add resistance at edges
      const maxSwipe = 150;
      const resistedDiff = Math.sign(diff) * Math.min(Math.abs(diff), maxSwipe);

      // Only allow swipe in directions with handlers
      if (diff > 0 && !onSwipeRight) return;
      if (diff < 0 && !onSwipeLeft) return;

      setTranslateX(resistedDiff);
    },
    [isDragging, disabled, onSwipeRight, onSwipeLeft]
  );

  const handleTouchEnd = useCallback(() => {
    if (!isDragging || disabled) return;

    setIsDragging(false);

    if (translateX > threshold && onSwipeRight) {
      // Trigger right swipe action
      setTranslateX(300);
      setTimeout(() => {
        onSwipeRight();
        setTranslateX(0);
      }, 200);
    } else if (translateX < -threshold && onSwipeLeft) {
      // Trigger left swipe action
      setTranslateX(-300);
      setTimeout(() => {
        onSwipeLeft();
        setTranslateX(0);
      }, 200);
    } else {
      // Reset position
      setTranslateX(0);
    }
  }, [isDragging, disabled, translateX, threshold, onSwipeRight, onSwipeLeft]);

  // Calculate background color based on swipe direction
  const getBackgroundStyle = () => {
    if (translateX > 0) {
      const opacity = Math.min(translateX / threshold, 1);
      return {
        backgroundColor: `rgba(34, 197, 94, ${opacity * 0.3})`,
      };
    }
    if (translateX < 0) {
      const opacity = Math.min(Math.abs(translateX) / threshold, 1);
      return {
        backgroundColor: `rgba(239, 68, 68, ${opacity * 0.3})`,
      };
    }
    return {};
  };

  // Calculate action label visibility
  const showRightAction = translateX > 20 && onSwipeRight;
  const showLeftAction = translateX < -20 && onSwipeLeft;

  return (
    <div
      className={`relative overflow-hidden rounded-xl ${className}`}
      style={getBackgroundStyle()}
    >
      {/* Left action indicator (Reject) */}
      {onSwipeLeft && (
        <div
          className={`absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2 text-red-400 transition-opacity ${
            showLeftAction ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <span className="text-sm font-medium">{leftLabel}</span>
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </div>
      )}

      {/* Right action indicator (Approve) */}
      {onSwipeRight && (
        <div
          className={`absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 text-green-400 transition-opacity ${
            showRightAction ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M5 13l4 4L19 7"
            />
          </svg>
          <span className="text-sm font-medium">{rightLabel}</span>
        </div>
      )}

      {/* Card content */}
      <div
        ref={cardRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="bg-slate-800/50 transition-transform"
        style={{
          transform: `translateX(${translateX}px)`,
          transitionDuration: isDragging ? '0ms' : '200ms',
        }}
      >
        {children}
      </div>
    </div>
  );
});

export default SwipeableCard;
