import React, { useState, useRef, useCallback, memo, useEffect } from 'react';

interface PullToRefreshProps {
  /** Content to wrap */
  children: React.ReactNode;
  /** Called when pull-to-refresh is triggered */
  onRefresh: () => Promise<void>;
  /** Pull distance to trigger refresh (px) */
  threshold?: number;
  /** Maximum pull distance (px) */
  maxPull?: number;
  /** Loading state override */
  isRefreshing?: boolean;
  /** Disable pull-to-refresh */
  disabled?: boolean;
  /** Additional className for container */
  className?: string;
}

/**
 * Pull-to-refresh wrapper component
 * Provides native-like pull-to-refresh functionality
 */
export const PullToRefresh = memo(function PullToRefresh({
  children,
  onRefresh,
  threshold = 80,
  maxPull = 120,
  isRefreshing: externalRefreshing,
  disabled = false,
  className = '',
}: PullToRefreshProps): React.ReactElement {
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const startYRef = useRef<number>(0);
  const isPullingRef = useRef(false);

  // Use external refreshing state if provided
  const refreshing = externalRefreshing ?? isRefreshing;

  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      if (disabled || refreshing) return;

      const container = containerRef.current;
      if (!container) return;

      // Only start if scrolled to top
      if (container.scrollTop === 0) {
        startYRef.current = e.touches[0].clientY;
        isPullingRef.current = true;
      }
    },
    [disabled, refreshing]
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (!isPullingRef.current || disabled || refreshing) return;

      const currentY = e.touches[0].clientY;
      const diff = currentY - startYRef.current;

      if (diff > 0) {
        // Apply resistance as we pull further
        const resistance = Math.min(diff / 2.5, maxPull);
        setPullDistance(resistance);

        // Prevent default scrolling when pulling
        e.preventDefault();
      }
    },
    [disabled, refreshing, maxPull]
  );

  const handleTouchEnd = useCallback(async () => {
    if (!isPullingRef.current || disabled) return;

    isPullingRef.current = false;

    if (pullDistance >= threshold && !refreshing) {
      // Trigger refresh
      setIsRefreshing(true);
      setPullDistance(60); // Keep indicator visible during refresh

      try {
        await onRefresh();
      } finally {
        setIsRefreshing(false);
        setPullDistance(0);
      }
    } else {
      // Reset pull distance
      setPullDistance(0);
    }
  }, [pullDistance, threshold, refreshing, onRefresh, disabled]);

  // Reset pull distance when external refresh completes
  useEffect(() => {
    if (!externalRefreshing && pullDistance > 0) {
      setPullDistance(0);
    }
  }, [externalRefreshing, pullDistance]);

  // Calculate progress for visual feedback
  const progress = Math.min(pullDistance / threshold, 1);
  const isReadyToRefresh = pullDistance >= threshold;

  return (
    <div
      ref={containerRef}
      className={`overflow-y-auto ${className}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{
        touchAction: pullDistance > 0 ? 'none' : 'auto',
      }}
    >
      {/* Pull indicator */}
      <div
        className="flex justify-center items-center overflow-hidden transition-all"
        style={{
          height: pullDistance,
          opacity: pullDistance > 10 ? 1 : 0,
        }}
      >
        <div
          className={`flex items-center gap-2 ${
            isReadyToRefresh ? 'text-indigo-400' : 'text-gray-400'
          }`}
        >
          {refreshing ? (
            <>
              <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
              <span className="text-sm font-medium">Refreshing...</span>
            </>
          ) : (
            <>
              <svg
                className="w-5 h-5 transition-transform"
                style={{
                  transform: `rotate(${isReadyToRefresh ? 180 : progress * 180}deg)`,
                }}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 14l-7 7m0 0l-7-7m7 7V3"
                />
              </svg>
              <span className="text-sm font-medium">
                {isReadyToRefresh ? 'Release to refresh' : 'Pull to refresh'}
              </span>
            </>
          )}
        </div>
      </div>

      {/* Content */}
      <div
        style={{
          transform: pullDistance > 0 ? `translateY(${pullDistance / 3}px)` : undefined,
          transition: pullDistance === 0 ? 'transform 200ms ease-out' : undefined,
        }}
      >
        {children}
      </div>
    </div>
  );
});

export default PullToRefresh;
