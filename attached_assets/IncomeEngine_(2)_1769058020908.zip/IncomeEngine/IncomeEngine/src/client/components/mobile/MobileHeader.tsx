import React, { memo } from 'react';
import { useLocation } from 'react-router-dom';

import { StatusBadge } from '../StatusBadge';
import { useSystemStatusQuery } from '../../hooks/useQueries';
import { getRouteByPath } from '../../mobile/navigation/routes';

interface MobileHeaderProps {
  /** Custom title override */
  title?: string;
  /** Show back button instead of logo */
  showBack?: boolean;
  /** Custom right-side content */
  rightContent?: React.ReactNode;
}

/**
 * Mobile app header component
 * Displays title, status badge, and optional actions
 */
export const MobileHeader = memo(function MobileHeader({
  title,
  showBack = false,
  rightContent,
}: MobileHeaderProps): React.ReactElement {
  const location = useLocation();
  const { data: status } = useSystemStatusQuery();

  // Get page title from route config
  const route = getRouteByPath(location.pathname);
  const pageTitle = title || route?.label || 'Income Engine';

  // Determine overall system status
  const hasOpenBreakers = status?.circuitBreakers
    ? Object.values(status.circuitBreakers).some((cb) => cb.isOpen)
    : false;

  const hasDeadLetter = (status?.queues?.deadLetter ?? 0) > 0;
  const systemStatus = hasOpenBreakers || hasDeadLetter ? 'error' : 'ok';

  const handleBack = () => {
    window.history.back();
  };

  return (
    <header className="bg-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-20 safe-area-pt border-b border-slate-700">
      {/* Left Side */}
      <div className="flex items-center gap-3 min-w-0 flex-1">
        {showBack ? (
          <button
            onClick={handleBack}
            className="p-1 -ml-1 rounded-lg hover:bg-slate-700 active:bg-slate-600 transition-colors"
            aria-label="Go back"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 19l-7-7 7-7"
              />
            </svg>
          </button>
        ) : (
          <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <svg
              className="w-5 h-5 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
              />
            </svg>
          </div>
        )}

        <h1 className="font-semibold text-lg truncate">{pageTitle}</h1>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-2 flex-shrink-0">
        {rightContent || <StatusBadge status={systemStatus} />}
      </div>
    </header>
  );
});

export default MobileHeader;
