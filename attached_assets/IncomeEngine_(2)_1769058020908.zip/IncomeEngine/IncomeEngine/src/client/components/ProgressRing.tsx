import React, { memo, useMemo } from 'react';

interface ProgressRingProps {
  percent: number;
  size?: number;
  strokeWidth?: number;
  showLabel?: boolean;
}

/**
 * Circular progress indicator with dynamic coloring
 */
export const ProgressRing = memo(function ProgressRing({
  percent,
  size = 80,
  strokeWidth = 8,
  showLabel = false
}: ProgressRingProps) {
  const { radius, circumference, offset, color } = useMemo(() => {
    const r = (size - strokeWidth) / 2;
    const c = r * 2 * Math.PI;
    const o = c - (percent / 100) * c;

    // Color based on percentage
    let col: string;
    if (percent >= 100) {
      col = '#ef4444'; // red-500
    } else if (percent >= 80) {
      col = '#eab308'; // yellow-500
    } else {
      col = '#22c55e'; // green-500
    }

    return { radius: r, circumference: c, offset: o, color: col };
  }, [percent, size, strokeWidth]);

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg
        width={size}
        height={size}
        className="transform -rotate-90"
        role="progressbar"
        aria-valuenow={percent}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth={strokeWidth}
        />
        {/* Progress circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-500"
        />
      </svg>
      {showLabel && (
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xs font-bold">{Math.round(percent)}%</span>
        </div>
      )}
    </div>
  );
});

export default ProgressRing;
