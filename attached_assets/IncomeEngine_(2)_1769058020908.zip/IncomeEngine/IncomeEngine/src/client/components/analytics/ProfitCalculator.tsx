/**
 * ============================================================================
 * PROFIT CALCULATOR COMPONENT
 * Interactive calculator for estimating profits
 * ============================================================================
 */

import React, { memo, useState, useMemo } from 'react';
import { formatChartValue } from '../../hooks/useChartData';

interface ProfitCalculatorProps {
  defaultValues?: {
    sellingPrice?: number;
    productionCost?: number;
    platformFee?: number;
    marketingCost?: number;
    unitsPerMonth?: number;
  };
  onCalculate?: (result: CalculationResult) => void;
  className?: string;
}

interface CalculationResult {
  profitPerUnit: number;
  profitMargin: number;
  monthlyRevenue: number;
  monthlyProfit: number;
  monthlyROI: number;
  breakEvenUnits: number;
}

/**
 * Interactive profit calculator with real-time calculations
 */
export const ProfitCalculator = memo(function ProfitCalculator({
  defaultValues = {},
  onCalculate,
  className = '',
}: ProfitCalculatorProps) {
  const [values, setValues] = useState({
    sellingPrice: defaultValues.sellingPrice ?? 29.99,
    productionCost: defaultValues.productionCost ?? 8.00,
    platformFee: defaultValues.platformFee ?? 15,
    marketingCost: defaultValues.marketingCost ?? 2.00,
    unitsPerMonth: defaultValues.unitsPerMonth ?? 100,
  });

  const result = useMemo<CalculationResult>(() => {
    const { sellingPrice, productionCost, platformFee, marketingCost, unitsPerMonth } = values;

    // Calculate fees and costs per unit
    const platformFeeAmount = (sellingPrice * platformFee) / 100;
    const totalCostPerUnit = productionCost + platformFeeAmount + marketingCost;

    // Profit calculations
    const profitPerUnit = sellingPrice - totalCostPerUnit;
    const profitMargin = (profitPerUnit / sellingPrice) * 100;

    // Monthly projections
    const monthlyRevenue = sellingPrice * unitsPerMonth;
    const monthlyProfit = profitPerUnit * unitsPerMonth;
    const monthlyInvestment = totalCostPerUnit * unitsPerMonth;
    const monthlyROI = monthlyInvestment > 0 ? (monthlyProfit / monthlyInvestment) * 100 : 0;

    // Break-even analysis (how many units to cover fixed costs)
    const fixedCosts = marketingCost * unitsPerMonth; // Simplified
    const breakEvenUnits = profitPerUnit > 0 ? Math.ceil(fixedCosts / profitPerUnit) : 0;

    const calculationResult: CalculationResult = {
      profitPerUnit,
      profitMargin,
      monthlyRevenue,
      monthlyProfit,
      monthlyROI,
      breakEvenUnits,
    };

    if (onCalculate) {
      onCalculate(calculationResult);
    }

    return calculationResult;
  }, [values, onCalculate]);

  const handleInputChange = (field: keyof typeof values, value: string) => {
    const numValue = parseFloat(value) || 0;
    setValues(prev => ({
      ...prev,
      [field]: numValue,
    }));
  };

  const isProfit = result.profitPerUnit > 0;

  return (
    <div className={`bg-slate-800/50 rounded-xl border border-slate-700/50 ${className}`}>
      <div className="p-4 border-b border-slate-700">
        <h3 className="text-lg font-semibold text-white">Profit Calculator</h3>
        <p className="text-sm text-gray-400">Estimate your product profitability</p>
      </div>

      <div className="p-4 space-y-4">
        {/* Input Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Selling Price */}
          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Selling Price
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
              <input
                type="number"
                value={values.sellingPrice}
                onChange={(e) => handleInputChange('sellingPrice', e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg pl-8 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
                step="0.01"
              />
            </div>
          </div>

          {/* Production Cost */}
          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Production Cost
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
              <input
                type="number"
                value={values.productionCost}
                onChange={(e) => handleInputChange('productionCost', e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg pl-8 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
                step="0.01"
              />
            </div>
          </div>

          {/* Platform Fee */}
          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Platform Fee
            </label>
            <div className="relative">
              <input
                type="number"
                value={values.platformFee}
                onChange={(e) => handleInputChange('platformFee', e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg pl-4 pr-8 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
                max="100"
                step="0.1"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">%</span>
            </div>
          </div>

          {/* Marketing Cost */}
          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Marketing Cost (per unit)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
              <input
                type="number"
                value={values.marketingCost}
                onChange={(e) => handleInputChange('marketingCost', e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg pl-8 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
                step="0.01"
              />
            </div>
          </div>

          {/* Units Per Month */}
          <div className="md:col-span-2">
            <label className="block text-sm text-gray-400 mb-1">
              Expected Units Per Month
            </label>
            <input
              type="range"
              value={values.unitsPerMonth}
              onChange={(e) => handleInputChange('unitsPerMonth', e.target.value)}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              min="1"
              max="1000"
              step="1"
            />
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>1</span>
              <span className="text-lg font-bold text-white">{values.unitsPerMonth} units</span>
              <span>1000</span>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mt-6 pt-4 border-t border-slate-700">
          <h4 className="text-sm font-medium text-gray-400 mb-4">Results</h4>

          {/* Per Unit Results */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
            <div
              className={`p-4 rounded-lg ${
                isProfit ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'
              }`}
            >
              <p className="text-xs text-gray-400 mb-1">Profit Per Unit</p>
              <p
                className={`text-xl font-bold ${
                  isProfit ? 'text-green-400' : 'text-red-400'
                }`}
              >
                {formatChartValue(result.profitPerUnit, 'currency')}
              </p>
            </div>

            <div
              className={`p-4 rounded-lg ${
                isProfit ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'
              }`}
            >
              <p className="text-xs text-gray-400 mb-1">Profit Margin</p>
              <p
                className={`text-xl font-bold ${
                  isProfit ? 'text-green-400' : 'text-red-400'
                }`}
              >
                {result.profitMargin.toFixed(1)}%
              </p>
            </div>

            <div className="p-4 rounded-lg bg-indigo-500/10 border border-indigo-500/30">
              <p className="text-xs text-gray-400 mb-1">Break-Even</p>
              <p className="text-xl font-bold text-indigo-400">
                {result.breakEvenUnits} units
              </p>
            </div>
          </div>

          {/* Monthly Projections */}
          <div className="bg-slate-700/30 rounded-lg p-4">
            <h5 className="text-sm font-medium text-white mb-3">Monthly Projections</h5>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-gray-400">Revenue</p>
                <p className="text-lg font-semibold text-white">
                  {formatChartValue(result.monthlyRevenue, 'currency')}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Profit</p>
                <p
                  className={`text-lg font-semibold ${
                    isProfit ? 'text-green-400' : 'text-red-400'
                  }`}
                >
                  {formatChartValue(result.monthlyProfit, 'currency')}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-400">ROI</p>
                <p
                  className={`text-lg font-semibold ${
                    result.monthlyROI > 0 ? 'text-green-400' : 'text-red-400'
                  }`}
                >
                  {result.monthlyROI.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>

          {/* Cost Breakdown */}
          <div className="mt-4">
            <h5 className="text-sm font-medium text-gray-400 mb-2">Cost Breakdown (per unit)</h5>
            <div className="space-y-2">
              {[
                { label: 'Production', value: values.productionCost, color: '#ef4444' },
                { label: 'Platform Fee', value: (values.sellingPrice * values.platformFee) / 100, color: '#f59e0b' },
                { label: 'Marketing', value: values.marketingCost, color: '#8b5cf6' },
              ].map((item) => {
                const percentage = (item.value / values.sellingPrice) * 100;
                return (
                  <div key={item.label} className="flex items-center gap-3">
                    <span className="text-xs text-gray-400 w-24">{item.label}</span>
                    <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${percentage}%`,
                          backgroundColor: item.color,
                        }}
                      />
                    </div>
                    <span className="text-xs text-gray-400 w-16 text-right">
                      {formatChartValue(item.value, 'currency')}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

export default ProfitCalculator;
