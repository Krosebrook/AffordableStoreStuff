/**
 * ============================================================================
 * TREND INDICATORS COMPONENT
 * KPI cards with trend arrows and comparison data
 * ============================================================================
 */

import React, { memo } from 'react';
import type { TrendItem } from '../../hooks/useAnalytics';
import { CHART_COLORS, formatChartValue, formatCompactNumber } from '../../hooks/useChartData';

interface TrendIndicatorsProps {
  trends: TrendItem[];
  layout?: 'grid' | 'row' | 'compact';
  showComparison?: boolean;
  className?: string;
}

interface TrendCardProps {
  trend: TrendItem;
  showComparison?: boolean;
  compact?: boolean;
}

/**
 * Individual trend card component
 */
const TrendCard = memo(function TrendCard({
  trend,
  showComparison = true,
  compact = false,
}: TrendCardProps) {
  const getTrendColor = (trendDirection: 'up' | 'down' | 'stable') => {
    switch (trendDirection) {
      case 'up':
        return CHART_COLORS.success;
      case 'down':
        return CHART_COLORS.danger;
      default:
        return CHART_COLORS.gray;
    }
  };

  const getTrendIcon = (trendDirection: 'up' | 'down' | 'stable') => {
    switch (trendDirection) {
      case 'up':
        return '↑';
      case 'down':
        return '↓';
      default:
        return '→';
    }
  };

  const formatValue = (value: number, metric: string) => {
    const lowerMetric = metric.toLowerCase();
    if (lowerMetric.includes('revenue') || lowerMetric.includes('value')) {
      return formatChartValue(value, 'currency');
    }
    if (lowerMetric.includes('rate') || lowerMetric.includes('margin')) {
      return `${value.toFixed(1)}%`;
    }
    return formatCompactNumber(value);
  };

  const trendColor = getTrendColor(trend.trend);
  const isPositive = trend.changePercent >= 0;

  if (compact) {
    return (
      <div className="flex items-center justify-between py-2">
        <span className="text-sm text-gray-400">{trend.metric}</span>
        <div className="flex items-center gap-2">
          <span className="font-medium text-white">
            {formatValue(trend.current, trend.metric)}
          </span>
          <span
            className="text-xs px-2 py-0.5 rounded-full"
            style={{
              backgroundColor: `${trendColor}20`,
              color: trendColor,
            }}
          >
            {getTrendIcon(trend.trend)} {Math.abs(trend.changePercent).toFixed(1)}%
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50 hover:border-slate-600/50 transition-colors">
      <div className="flex items-start justify-between mb-3">
        <span className="text-sm text-gray-400">{trend.metric}</span>
        <span
          className="flex items-center gap-1 text-xs px-2 py-1 rounded-full"
          style={{
            backgroundColor: `${trendColor}20`,
            color: trendColor,
          }}
        >
          {getTrendIcon(trend.trend)}
          {isPositive ? '+' : ''}
          {trend.changePercent.toFixed(1)}%
        </span>
      </div>

      <div className="mb-2">
        <span className="text-2xl font-bold text-white">
          {formatValue(trend.current, trend.metric)}
        </span>
      </div>

      {showComparison && (
        <div className="flex items-center gap-2 text-sm">
          <span className="text-gray-400">vs</span>
          <span className="text-gray-300">
            {formatValue(trend.previous, trend.metric)}
          </span>
          <span
            className="font-medium"
            style={{ color: trendColor }}
          >
            ({isPositive ? '+' : ''}
            {trend.metric.toLowerCase().includes('revenue') ||
            trend.metric.toLowerCase().includes('value')
              ? formatChartValue(trend.change, 'currency')
              : trend.change.toLocaleString()})
          </span>
        </div>
      )}

      {/* Mini trend visualization */}
      <div className="mt-3 h-2 bg-slate-700 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${Math.min(Math.max((trend.current / (trend.previous || 1)) * 50, 10), 100)}%`,
            backgroundColor: trendColor,
          }}
        />
      </div>
    </div>
  );
});

/**
 * Trend indicators grid/list component
 */
export const TrendIndicators = memo(function TrendIndicators({
  trends,
  layout = 'grid',
  showComparison = true,
  className = '',
}: TrendIndicatorsProps) {
  if (!trends || trends.length === 0) {
    return (
      <div className={`flex items-center justify-center py-8 ${className}`}>
        <p className="text-gray-400">No trend data available</p>
      </div>
    );
  }

  // Summary stats
  const positiveCount = trends.filter(t => t.trend === 'up').length;
  const negativeCount = trends.filter(t => t.trend === 'down').length;
  const stableCount = trends.filter(t => t.trend === 'stable').length;

  if (layout === 'compact') {
    return (
      <div className={className}>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-medium text-gray-400">Key Metrics</h4>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-green-400">{positiveCount} up</span>
            <span className="text-gray-400">|</span>
            <span className="text-red-400">{negativeCount} down</span>
          </div>
        </div>
        <div className="divide-y divide-slate-700">
          {trends.map((trend) => (
            <TrendCard
              key={trend.metric}
              trend={trend}
              showComparison={false}
              compact
            />
          ))}
        </div>
      </div>
    );
  }

  if (layout === 'row') {
    return (
      <div className={className}>
        <div className="flex gap-4 overflow-x-auto pb-2">
          {trends.map((trend) => (
            <div key={trend.metric} className="min-w-[200px] flex-shrink-0">
              <TrendCard trend={trend} showComparison={showComparison} />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Grid layout (default)
  return (
    <div className={className}>
      {/* Summary header */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Key Metrics</h3>
        <div className="flex items-center gap-3 text-sm">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-gray-400">{positiveCount} improving</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            <span className="text-gray-400">{negativeCount} declining</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-gray-500" />
            <span className="text-gray-400">{stableCount} stable</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {trends.map((trend) => (
          <TrendCard
            key={trend.metric}
            trend={trend}
            showComparison={showComparison}
          />
        ))}
      </div>
    </div>
  );
});

export default TrendIndicators;
