import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';

import App from './App';
import { queryClient } from './lib/queryClient';
import { ErrorBoundary } from './components/ErrorBoundary';
import { reportWebVitals, preloadRoutesWhenIdle } from './lib';
import './index.css';

// Register service worker for PWA
import { registerSW } from 'virtual:pwa-register';

// Auto-update service worker
const updateSW = registerSW({
  onNeedRefresh() {
    if (confirm('New content available. Reload?')) {
      updateSW(true);
    }
  },
  onOfflineReady() {
    console.log('App ready to work offline');
  },
});

// Global error handler for unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
});

// Report Web Vitals for performance monitoring
if (import.meta.env.PROD) {
  reportWebVitals((metric) => {
    // In production, send to analytics endpoint
    console.log('[WebVitals]', metric.name, metric.value, metric.rating);
    // Could send to /api/metrics or analytics service
  });
}

// Preload other routes when browser is idle
preloadRoutesWhenIdle();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary
      onError={(error, errorInfo) => {
        // Log to console in development
        console.error('React Error Boundary:', error);
        console.error('Component Stack:', errorInfo.componentStack);
        // In production, send to error tracking service
      }}
    >
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <App />
        </BrowserRouter>
        {/* Show React Query DevTools only in development */}
        {import.meta.env.DEV && (
          <ReactQueryDevtools initialIsOpen={false} position="bottom" />
        )}
      </QueryClientProvider>
    </ErrorBoundary>
  </React.StrictMode>
);
