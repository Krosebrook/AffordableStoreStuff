/**
 * ============================================================================
 * ANALYTICS PAGE
 * Comprehensive analytics dashboard with charts, metrics, and exports
 * ============================================================================
 */

import React, { useState, useMemo, useCallback } from 'react';
import { useAnalyticsSummary, useExportAnalytics, type DateRange } from '../hooks/useAnalytics';
import { LoadingSpinner } from '../components/LoadingSpinner';
import {
  RevenueChart,
  PlatformComparison,
  ProductPerformance,
  TrendIndicators,
  ProfitCalculator,
} from '../components/analytics';
import { formatChartValue } from '../hooks/useChartData';
import {
  generateCSV,
  CSV_COLUMNS,
  downloadCSV,
} from '../../services/reporting/export-csv';
import {
  generatePDFReport,
  printPDFReport,
} from '../../services/reporting/export-pdf';

type TimePeriod = '7d' | '30d' | '90d' | 'custom';
type ActiveTab = 'overview' | 'products' | 'platforms' | 'calculator';

/**
 * Analytics Dashboard Page
 */
export function AnalyticsPage() {
  // State
  const [timePeriod, setTimePeriod] = useState<TimePeriod>('30d');
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [showExportMenu, setShowExportMenu] = useState(false);

  // Calculate date range based on time period
  const dateRange = useMemo<DateRange>(() => {
    const now = new Date();
    let start: Date;

    switch (timePeriod) {
      case '7d':
        start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        start = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
      default:
        start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
    }

    return { start, end: now };
  }, [timePeriod]);

  // Fetch analytics data
  const { data: summary, isLoading, isError, error, refetch } = useAnalyticsSummary({ dateRange });
  const exportMutation = useExportAnalytics();

  // Export handlers
  const handleExportCSV = useCallback(() => {
    if (!summary) return;

    const csvContent = [
      '=== REVENUE DATA ===',
      generateCSV(summary.revenueTimeSeries as Record<string, unknown>[], CSV_COLUMNS.revenue as any),
      '',
      '=== PLATFORM DATA ===',
      generateCSV(summary.platformBreakdown as Record<string, unknown>[], CSV_COLUMNS.platforms as any),
      '',
      '=== PRODUCT DATA ===',
      generateCSV(summary.topProducts as Record<string, unknown>[], CSV_COLUMNS.products as any),
    ].join('\n');

    downloadCSV(csvContent, `analytics-${timePeriod}-${Date.now()}.csv`);
    setShowExportMenu(false);
  }, [summary, timePeriod]);

  const handleExportPDF = useCallback(() => {
    if (!summary) return;

    const pdfHtml = generatePDFReport(
      {
        overview: summary.overview,
        revenueTimeSeries: summary.revenueTimeSeries,
        platformBreakdown: summary.platformBreakdown,
        topProducts: summary.topProducts,
        trends: summary.trends,
      },
      {
        title: 'Income Engine Analytics Report',
        subtitle: `${timePeriod === '7d' ? 'Weekly' : timePeriod === '30d' ? 'Monthly' : 'Quarterly'} Performance Summary`,
        dateRange: {
          start: dateRange.start.toISOString(),
          end: dateRange.end.toISOString(),
        },
      }
    );

    printPDFReport(pdfHtml);
    setShowExportMenu(false);
  }, [summary, timePeriod, dateRange]);

  const handleExportJSON = useCallback(() => {
    if (!summary) return;

    const jsonData = JSON.stringify(summary, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `analytics-${timePeriod}-${Date.now()}.json`;
    link.click();

    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  }, [summary, timePeriod]);

  // Loading state
  if (isLoading) {
    return <LoadingSpinner centered />;
  }

  // Error state
  if (isError) {
    return (
      <div className="p-4">
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <h3 className="font-semibold text-red-400">Failed to load analytics</h3>
          <p className="text-sm text-gray-400 mt-1">
            {error instanceof Error ? error.message : 'Unknown error occurred'}
          </p>
          <button
            onClick={() => refetch()}
            className="mt-3 px-4 py-2 bg-red-500 rounded-lg text-sm font-medium text-white"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!summary) return null;

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-slate-900/95 backdrop-blur-sm border-b border-slate-700 px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold text-white">Analytics</h1>
            <p className="text-sm text-gray-400">
              {dateRange.start.toLocaleDateString()} - {dateRange.end.toLocaleDateString()}
            </p>
          </div>

          {/* Export Menu */}
          <div className="relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-sm font-medium text-white transition-colors flex items-center gap-2"
            >
              <span>Export</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {showExportMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-xl shadow-xl py-2">
                <button
                  onClick={handleExportCSV}
                  className="w-full px-4 py-2 text-left text-sm text-gray-300 hover:bg-slate-700 transition-colors flex items-center gap-2"
                >
                  <span>CSV</span>
                  <span className="text-xs text-gray-500">Spreadsheet</span>
                </button>
                <button
                  onClick={handleExportPDF}
                  className="w-full px-4 py-2 text-left text-sm text-gray-300 hover:bg-slate-700 transition-colors flex items-center gap-2"
                >
                  <span>PDF</span>
                  <span className="text-xs text-gray-500">Print Report</span>
                </button>
                <button
                  onClick={handleExportJSON}
                  className="w-full px-4 py-2 text-left text-sm text-gray-300 hover:bg-slate-700 transition-colors flex items-center gap-2"
                >
                  <span>JSON</span>
                  <span className="text-xs text-gray-500">Raw Data</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Time Period Selector */}
        <div className="flex gap-2">
          {(['7d', '30d', '90d'] as TimePeriod[]).map((period) => (
            <button
              key={period}
              onClick={() => setTimePeriod(period)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                timePeriod === period
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-gray-400 hover:text-white'
              }`}
            >
              {period === '7d' ? '7 Days' : period === '30d' ? '30 Days' : '90 Days'}
            </button>
          ))}
        </div>
      </header>

      {/* Tab Navigation */}
      <nav className="flex border-b border-slate-700 px-4">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'products', label: 'Products' },
          { id: 'platforms', label: 'Platforms' },
          { id: 'calculator', label: 'Calculator' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as ActiveTab)}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Main Content */}
      <main className="p-4 space-y-6">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <>
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl p-4">
                <p className="text-sm text-white/80">Total Revenue</p>
                <p className="text-2xl font-bold text-white">
                  {formatChartValue(summary.overview.totalRevenue, 'currency')}
                </p>
              </div>
              <div className="bg-gradient-to-br from-emerald-600 to-teal-600 rounded-xl p-4">
                <p className="text-sm text-white/80">Total Profit</p>
                <p className="text-2xl font-bold text-white">
                  {formatChartValue(summary.overview.totalProfit, 'currency')}
                </p>
              </div>
              <div className="bg-gradient-to-br from-orange-600 to-amber-600 rounded-xl p-4">
                <p className="text-sm text-white/80">Total Orders</p>
                <p className="text-2xl font-bold text-white">
                  {summary.overview.totalOrders}
                </p>
              </div>
              <div className="bg-gradient-to-br from-pink-600 to-rose-600 rounded-xl p-4">
                <p className="text-sm text-white/80">Avg Order Value</p>
                <p className="text-2xl font-bold text-white">
                  {formatChartValue(summary.overview.avgOrderValue, 'currency')}
                </p>
              </div>
            </div>

            {/* Revenue Chart */}
            <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <h3 className="text-lg font-semibold text-white mb-4">Revenue Over Time</h3>
              <RevenueChart data={summary.revenueTimeSeries} showProfit height={300} />
            </div>

            {/* Trend Indicators */}
            <TrendIndicators trends={summary.trends} layout="grid" />

            {/* Platform Summary */}
            <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <h3 className="text-lg font-semibold text-white mb-4">Platform Performance</h3>
              <PlatformComparison
                platforms={summary.platformBreakdown}
                chartType="horizontal"
                metric="revenue"
                showGrowth
                limit={5}
                height={300}
              />
            </div>

            {/* Top Products Preview */}
            <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Top Products</h3>
                <button
                  onClick={() => setActiveTab('products')}
                  className="text-sm text-indigo-400 hover:text-indigo-300"
                >
                  View All
                </button>
              </div>
              <ProductPerformance products={summary.topProducts} maxItems={5} />
            </div>
          </>
        )}

        {/* Products Tab */}
        {activeTab === 'products' && (
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
            <ProductPerformance
              products={summary.topProducts}
              title="Product Performance"
              maxItems={20}
              showRank
            />
          </div>
        )}

        {/* Platforms Tab */}
        {activeTab === 'platforms' && (
          <div className="space-y-6">
            <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <h3 className="text-lg font-semibold text-white mb-4">Revenue by Platform</h3>
              <PlatformComparison
                platforms={summary.platformBreakdown}
                chartType="horizontal"
                metric="revenue"
                showGrowth
                height={400}
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <h3 className="text-lg font-semibold text-white mb-4">Orders by Platform</h3>
                <PlatformComparison
                  platforms={summary.platformBreakdown}
                  chartType="bar"
                  metric="orders"
                  showGrowth={false}
                  height={300}
                />
              </div>

              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
                <h3 className="text-lg font-semibold text-white mb-4">Products by Platform</h3>
                <PlatformComparison
                  platforms={summary.platformBreakdown}
                  chartType="bar"
                  metric="products"
                  showGrowth={false}
                  height={300}
                />
              </div>
            </div>
          </div>
        )}

        {/* Calculator Tab */}
        {activeTab === 'calculator' && (
          <div className="max-w-2xl mx-auto">
            <ProfitCalculator
              defaultValues={{
                sellingPrice: summary.overview.avgOrderValue,
                productionCost: summary.overview.avgOrderValue * 0.3,
                platformFee: 15,
                marketingCost: 2,
                unitsPerMonth: Math.round(summary.overview.totalOrders / (timePeriod === '7d' ? 1 : timePeriod === '30d' ? 4 : 12)),
              }}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="p-4 border-t border-slate-700 mt-6">
        <div className="flex items-center justify-between text-sm text-gray-400">
          <span>Last updated: {new Date().toLocaleString()}</span>
          <button
            onClick={() => refetch()}
            className="text-indigo-400 hover:text-indigo-300"
          >
            Refresh Data
          </button>
        </div>
      </footer>

      {/* Click outside to close export menu */}
      {showExportMenu && (
        <div
          className="fixed inset-0 z-0"
          onClick={() => setShowExportMenu(false)}
        />
      )}
    </div>
  );
}

export default AnalyticsPage;
