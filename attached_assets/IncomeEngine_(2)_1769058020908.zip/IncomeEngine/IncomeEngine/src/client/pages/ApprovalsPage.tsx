import React, { useState, useEffect, useCallback } from 'react';
import { LoadingSpinner } from '../components/LoadingSpinner';
import type { PendingApproval } from '../types';

/**
 * Approvals page for reviewing pending products
 */
export function ApprovalsPage() {
  const [approvals, setApprovals] = useState<PendingApproval[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchApprovals = useCallback(async () => {
    try {
      const res = await fetch('/api/approvals');
      const data = await res.json();
      setApprovals(data.pending || []);
    } catch (err) {
      console.error('Failed to fetch approvals:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchApprovals();
  }, [fetchApprovals]);

  const handleApprove = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/approvals/${id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });

      if (res.ok) {
        setApprovals((prev) => prev.filter((a) => a.id !== id));
      }
    } catch (err) {
      console.error('Failed to approve:', err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/approvals/${id}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: 'Rejected via dashboard' })
      });

      if (res.ok) {
        setApprovals((prev) => prev.filter((a) => a.id !== id));
      }
    } catch (err) {
      console.error('Failed to reject:', err);
    } finally {
      setActionLoading(null);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Pending Approvals</h2>

      {approvals.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          <span className="text-4xl mb-4 block">✨</span>
          <p>No pending approvals</p>
          <p className="text-sm mt-1">All products have been reviewed</p>
        </div>
      ) : (
        <div className="space-y-3">
          {approvals.map((item) => (
            <div key={item.id} className="bg-slate-800/50 rounded-xl p-4">
              <div className="flex gap-3">
                <div className="w-16 h-16 bg-slate-700 rounded-lg flex-shrink-0 flex items-center justify-center">
                  <span className="text-2xl">📦</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium truncate">{item.title || 'Product'}</h3>
                  <p className="text-sm text-gray-400">{item.type}</p>
                  <p className="text-xs text-gray-500 mt-1">{item.reason}</p>
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => handleApprove(item.id)}
                      disabled={actionLoading === item.id}
                      className="px-3 py-1 bg-green-600 hover:bg-green-700 rounded text-sm disabled:opacity-50 transition-colors"
                    >
                      {actionLoading === item.id ? '...' : 'Approve'}
                    </button>
                    <button
                      onClick={() => handleReject(item.id)}
                      disabled={actionLoading === item.id}
                      className="px-3 py-1 bg-red-600 hover:bg-red-700 rounded text-sm disabled:opacity-50 transition-colors"
                    >
                      {actionLoading === item.id ? '...' : 'Reject'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default ApprovalsPage;
