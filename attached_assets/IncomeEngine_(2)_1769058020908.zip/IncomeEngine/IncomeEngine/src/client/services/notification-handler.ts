/**
 * Notification handler service
 * Processes incoming notifications and routes them appropriately
 */

import type { SystemStatus } from '../types';

/**
 * Notification action types
 */
export type NotificationAction =
  | { type: 'open_approvals' }
  | { type: 'open_budget' }
  | { type: 'open_alerts' }
  | { type: 'dismiss' }
  | { type: 'navigate'; path: string };

/**
 * Notification data from push payload
 */
interface NotificationData {
  type: string;
  action?: string;
  productId?: string;
  approvalId?: string;
  period?: string;
  breakerName?: string;
  path?: string;
  [key: string]: unknown;
}

/**
 * Notification click handler callback
 */
type NotificationClickHandler = (action: NotificationAction) => void;

/**
 * Notification handler class
 */
class NotificationHandler {
  private clickHandler: NotificationClickHandler | null = null;
  private previousStatus: SystemStatus | null = null;

  /**
   * Initialize notification handler
   */
  initialize(): void {
    // Listen for notification clicks from service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data?.type === 'NOTIFICATION_CLICK') {
          this.handleNotificationClick(event.data.notification);
        }
      });
    }

    // Handle focus from notification click
    window.addEventListener('focus', () => {
      this.clearNotifications();
    });
  }

  /**
   * Set the click handler callback
   */
  setClickHandler(handler: NotificationClickHandler): void {
    this.clickHandler = handler;
  }

  /**
   * Handle notification click
   */
  handleNotificationClick(data: NotificationData): void {
    if (!this.clickHandler) return;

    const action = this.mapDataToAction(data);
    this.clickHandler(action);
  }

  /**
   * Map notification data to action
   */
  private mapDataToAction(data: NotificationData): NotificationAction {
    switch (data.type) {
      case 'approval_needed':
        return { type: 'open_approvals' };

      case 'budget_warning':
      case 'budget_exceeded':
        return { type: 'open_budget' };

      case 'circuit_breaker_open':
      case 'error':
        return { type: 'open_alerts' };

      default:
        if (data.path) {
          return { type: 'navigate', path: data.path };
        }
        return { type: 'dismiss' };
    }
  }

  /**
   * Clear all notifications for this app
   */
  async clearNotifications(): Promise<void> {
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.ready;
      const notifications = await registration.getNotifications();
      notifications.forEach((notification) => notification.close());
    }
  }

  /**
   * Check system status and trigger notifications for changes
   */
  async checkStatusChanges(
    newStatus: SystemStatus,
    sendNotification: (type: string, config: { title: string; body: string }) => Promise<void>
  ): Promise<void> {
    if (!this.previousStatus) {
      this.previousStatus = newStatus;
      return;
    }

    const prev = this.previousStatus;

    // Check for new pending approvals
    const prevPending = prev.approvalStats?.pendingCount ?? 0;
    const newPending = newStatus.approvalStats?.pendingCount ?? 0;

    if (newPending > prevPending) {
      const diff = newPending - prevPending;
      await sendNotification('approval_needed', {
        title: 'New Approvals',
        body: `${diff} new product${diff === 1 ? '' : 's'} need${diff === 1 ? 's' : ''} approval`,
      });
    }

    // Check for budget warnings
    for (const budget of newStatus.budget || []) {
      const prevBudget = prev.budget?.find((b) => b.period === budget.period);

      // Check for new warning state
      if (budget.isWarning && !prevBudget?.isWarning) {
        await sendNotification('budget_warning', {
          title: 'Budget Warning',
          body: `${budget.period} budget at ${budget.percentUsed.toFixed(0)}%`,
        });
      }

      // Check for exceeded state
      if (budget.isExceeded && !prevBudget?.isExceeded) {
        await sendNotification('budget_exceeded', {
          title: 'Budget Exceeded',
          body: `${budget.period} budget limit reached`,
        });
      }
    }

    // Check for circuit breaker changes
    for (const [name, breaker] of Object.entries(newStatus.circuitBreakers || {})) {
      const prevBreaker = prev.circuitBreakers?.[name];

      if (breaker.isOpen && !prevBreaker?.isOpen) {
        await sendNotification('circuit_breaker_open', {
          title: 'Circuit Breaker Open',
          body: breaker.openedReason || `${name} triggered`,
        });
      }
    }

    // Check for dead letter queue items
    const prevDead = prev.queues?.deadLetter ?? 0;
    const newDead = newStatus.queues?.deadLetter ?? 0;

    if (newDead > prevDead) {
      await sendNotification('error', {
        title: 'Failed Tasks',
        body: `${newDead - prevDead} task${newDead - prevDead === 1 ? '' : 's'} moved to dead letter queue`,
      });
    }

    this.previousStatus = newStatus;
  }

  /**
   * Format time ago string
   */
  formatTimeAgo(date: Date | string): string {
    const now = new Date();
    const then = new Date(date);
    const diffMs = now.getTime() - then.getTime();

    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'just now';
  }

  /**
   * Get notification badge count
   */
  getBadgeCount(status: SystemStatus): number {
    let count = 0;

    // Pending approvals
    count += status.approvalStats?.pendingCount ?? 0;

    // Open circuit breakers
    count += Object.values(status.circuitBreakers || {}).filter(
      (cb) => cb.isOpen
    ).length;

    // Dead letter items
    count += status.queues?.deadLetter ?? 0;

    return count;
  }

  /**
   * Update app badge (if supported)
   */
  async updateBadge(count: number): Promise<void> {
    if ('setAppBadge' in navigator) {
      try {
        if (count > 0) {
          await (navigator as any).setAppBadge(count);
        } else {
          await (navigator as any).clearAppBadge();
        }
      } catch (e) {
        console.warn('Badge API not supported:', e);
      }
    }
  }
}

// Export singleton instance
export const notificationHandler = new NotificationHandler();
export default notificationHandler;
