/**
 * ============================================================================
 * RESULTS ANALYZER
 * Statistical analysis for pricing A/B tests
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  PricingExperiment,
  ExperimentResults,
  VariantResults,
  PowerAnalysis,
} from '../types.js';
import { createExperimentManager, ExperimentManager } from './experiment-manager.js';

// =============================================================================
// STATISTICAL UTILITIES
// =============================================================================

/**
 * Calculate z-score for a given confidence level
 */
function getZScore(confidenceLevel: number): number {
  // Common z-scores
  const zScores: Record<number, number> = {
    0.9: 1.645,
    0.95: 1.96,
    0.99: 2.576,
  };
  return zScores[confidenceLevel] ?? 1.96;
}

/**
 * Calculate standard error for a proportion
 */
function standardError(proportion: number, sampleSize: number): number {
  return Math.sqrt((proportion * (1 - proportion)) / sampleSize);
}

/**
 * Calculate z-test for two proportions
 */
function zTestForProportions(
  p1: number,
  n1: number,
  p2: number,
  n2: number
): { zScore: number; pValue: number } {
  const pooledP = (p1 * n1 + p2 * n2) / (n1 + n2);
  const se = Math.sqrt(pooledP * (1 - pooledP) * (1 / n1 + 1 / n2));

  if (se === 0) {
    return { zScore: 0, pValue: 1 };
  }

  const zScore = (p1 - p2) / se;
  const pValue = 2 * (1 - normalCDF(Math.abs(zScore)));

  return { zScore, pValue };
}

/**
 * Calculate t-test for two means
 */
function tTestForMeans(
  mean1: number,
  std1: number,
  n1: number,
  mean2: number,
  std2: number,
  n2: number
): { tScore: number; pValue: number } {
  const se = Math.sqrt((std1 * std1) / n1 + (std2 * std2) / n2);

  if (se === 0) {
    return { tScore: 0, pValue: 1 };
  }

  const tScore = (mean1 - mean2) / se;
  const df = n1 + n2 - 2;
  const pValue = 2 * (1 - tCDF(Math.abs(tScore), df));

  return { tScore, pValue };
}

/**
 * Standard normal CDF approximation
 */
function normalCDF(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x) / Math.sqrt(2);

  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);

  return 0.5 * (1.0 + sign * y);
}

/**
 * Student's t CDF approximation
 */
function tCDF(t: number, df: number): number {
  // Use normal approximation for large df
  if (df > 30) {
    return normalCDF(t);
  }

  // Simple approximation for smaller df
  const x = df / (df + t * t);
  return 1 - 0.5 * incompleteBeta(df / 2, 0.5, x);
}

/**
 * Incomplete beta function approximation
 */
function incompleteBeta(a: number, b: number, x: number): number {
  // Simple approximation using series expansion
  if (x === 0) return 0;
  if (x === 1) return 1;

  let result = 0;
  let term = 1;
  for (let i = 0; i < 100; i++) {
    result += term * Math.pow(x, i) / (a + i);
    term *= (i - b + 1) * x / (i + 1);
    if (Math.abs(term) < 1e-10) break;
  }

  return Math.pow(x, a) * Math.pow(1 - x, b) * result / beta(a, b);
}

/**
 * Beta function
 */
function beta(a: number, b: number): number {
  return (gamma(a) * gamma(b)) / gamma(a + b);
}

/**
 * Gamma function approximation (Lanczos)
 */
function gamma(z: number): number {
  const g = 7;
  const c = [
    0.99999999999980993,
    676.5203681218851,
    -1259.1392167224028,
    771.32342877765313,
    -176.61502916214059,
    12.507343278686905,
    -0.13857109526572012,
    9.9843695780195716e-6,
    1.5056327351493116e-7,
  ];

  if (z < 0.5) {
    return Math.PI / (Math.sin(Math.PI * z) * gamma(1 - z));
  }

  z -= 1;
  let x = c[0];
  for (let i = 1; i < g + 2; i++) {
    x += c[i] / (z + i);
  }

  const t = z + g + 0.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(t, z + 0.5) * Math.exp(-t) * x;
}

// =============================================================================
// RESULTS ANALYZER CLASS
// =============================================================================

export class ResultsAnalyzer {
  private readonly supabase: SupabaseClient;
  private readonly experimentManager: ExperimentManager;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.experimentManager = createExperimentManager(supabaseUrl, supabaseKey);
  }

  /**
   * Analyze experiment results
   */
  async analyzeResults(experimentId: string): Promise<ExperimentResults> {
    const experiment = await this.experimentManager.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    // Get event counts for each variant
    const eventCounts = await this.experimentManager.getEventCounts(experimentId);

    // Get unique visitors per variant
    const visitorCounts = await this.getUniqueVisitors(experimentId);

    // Build variant results
    const variantResults: VariantResults[] = [];
    let controlResult: VariantResults | null = null;

    for (const variant of experiment.variants) {
      const events = eventCounts[variant.id] ?? { views: 0, addToCarts: 0, purchases: 0, revenue: 0 };
      const visitors = visitorCounts[variant.id] ?? 0;

      const result: VariantResults = {
        variantId: variant.id,
        variantName: variant.name,
        price: variant.price,
        sampleSize: visitors,
        metrics: {
          conversions: events.purchases,
          revenue: events.revenue,
          averageOrderValue: events.purchases > 0 ? events.revenue / events.purchases : 0,
          conversionRate: visitors > 0 ? events.purchases / visitors : 0,
          revenuePerVisitor: visitors > 0 ? events.revenue / visitors : 0,
        },
        uplift: null,
        pValue: null,
      };

      if (variant.isControl) {
        controlResult = result;
      }

      variantResults.push(result);
    }

    // Calculate uplift and p-values relative to control
    if (controlResult && controlResult.sampleSize > 0) {
      for (const result of variantResults) {
        if (result.variantId === controlResult.variantId) continue;

        // Calculate uplift
        const metricKey = this.getMetricKey(experiment.primaryMetric);
        const controlValue = (controlResult.metrics as Record<string, number>)[metricKey];
        const variantValue = (result.metrics as Record<string, number>)[metricKey];

        if (controlValue > 0) {
          const absoluteUplift = variantValue - controlValue;
          const relativeUplift = absoluteUplift / controlValue;

          // Calculate confidence interval
          const ci = this.calculateConfidenceInterval(
            result,
            controlResult,
            experiment.primaryMetric,
            experiment.confidenceLevel
          );

          result.uplift = {
            absolute: Math.round(absoluteUplift * 10000) / 10000,
            relative: Math.round(relativeUplift * 10000) / 100,
            confidenceInterval: ci,
          };
        }

        // Calculate p-value
        result.pValue = this.calculatePValue(result, controlResult, experiment.primaryMetric);
      }
    }

    // Determine statistical significance
    const { significance, winner } = this.determineSignificance(
      variantResults,
      controlResult,
      experiment.confidenceLevel
    );

    // Calculate power analysis
    const powerAnalysis = this.calculatePowerAnalysis(
      variantResults,
      experiment.minimumSampleSize,
      experiment.confidenceLevel
    );

    // Determine status
    let status: ExperimentResults['status'] = 'insufficient_data';
    if (variantResults.every((v) => v.sampleSize >= experiment.minimumSampleSize)) {
      if (winner) {
        status = 'winner_found';
      } else if (significance > 0.5) {
        status = 'inconclusive';
      } else {
        status = 'no_winner';
      }
    }

    return {
      experimentId,
      status,
      winner,
      variants: variantResults,
      statisticalSignificance: Math.round(significance * 10000) / 100,
      sampleSize: variantResults.reduce((sum, v) => sum + v.sampleSize, 0),
      powerAnalysis,
      calculatedAt: new Date(),
    };
  }

  /**
   * Get experiment summary with key metrics
   */
  async getExperimentSummary(
    experimentId: string
  ): Promise<{
    experiment: PricingExperiment;
    results: ExperimentResults;
    recommendation: string;
    nextSteps: string[];
  }> {
    const experiment = await this.experimentManager.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    const results = await this.analyzeResults(experimentId);

    const { recommendation, nextSteps } = this.generateRecommendation(experiment, results);

    return {
      experiment,
      results,
      recommendation,
      nextSteps,
    };
  }

  /**
   * Calculate if experiment has reached significance
   */
  async checkSignificance(experimentId: string): Promise<{
    isSignificant: boolean;
    pValue: number;
    sampleSizeReached: boolean;
    estimatedTimeRemaining: number;
  }> {
    const experiment = await this.experimentManager.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    const results = await this.analyzeResults(experimentId);

    const treatmentResults = results.variants.filter((v) =>
      !experiment.variants.find((ev) => ev.id === v.variantId && ev.isControl)
    );

    const lowestPValue = Math.min(
      ...treatmentResults.map((v) => v.pValue ?? 1)
    );

    const isSignificant = lowestPValue < (1 - experiment.confidenceLevel);
    const sampleSizeReached = results.sampleSize >= experiment.minimumSampleSize;

    return {
      isSignificant,
      pValue: Math.round(lowestPValue * 10000) / 10000,
      sampleSizeReached,
      estimatedTimeRemaining: results.powerAnalysis.estimatedDaysRemaining,
    };
  }

  /**
   * Get daily metrics for an experiment
   */
  async getDailyMetrics(
    experimentId: string
  ): Promise<Array<{
    date: string;
    variantId: string;
    visitors: number;
    conversions: number;
    revenue: number;
    conversionRate: number;
  }>> {
    const { data, error } = await this.supabase.rpc('get_experiment_daily_metrics', {
      p_experiment_id: experimentId,
    });

    if (error) {
      // Fallback: calculate from events
      return this.calculateDailyMetrics(experimentId);
    }

    return data ?? [];
  }

  // ===========================================================================
  // HELPER METHODS
  // ===========================================================================

  private async getUniqueVisitors(experimentId: string): Promise<Record<string, number>> {
    const { data, error } = await this.supabase
      .from('pricing_experiment_assignments')
      .select('variant_id')
      .eq('experiment_id', experimentId);

    if (error) {
      throw new Error(`Failed to get visitor counts: ${error.message}`);
    }

    const counts: Record<string, number> = {};
    for (const row of data ?? []) {
      counts[row.variant_id] = (counts[row.variant_id] ?? 0) + 1;
    }

    return counts;
  }

  private getMetricKey(metric: string): string {
    switch (metric) {
      case 'revenue':
        return 'revenue';
      case 'conversion_rate':
        return 'conversionRate';
      case 'profit':
        return 'revenue'; // Would need cost data for true profit
      case 'units_sold':
        return 'conversions';
      default:
        return 'conversionRate';
    }
  }

  private calculateConfidenceInterval(
    variant: VariantResults,
    control: VariantResults,
    metric: string,
    confidenceLevel: number
  ): [number, number] {
    const z = getZScore(confidenceLevel);

    if (metric === 'conversion_rate' || metric === 'revenue') {
      const p1 = variant.metrics.conversionRate;
      const p2 = control.metrics.conversionRate;
      const n1 = variant.sampleSize;
      const n2 = control.sampleSize;

      if (n1 === 0 || n2 === 0) {
        return [0, 0];
      }

      const diff = p1 - p2;
      const se = Math.sqrt((p1 * (1 - p1)) / n1 + (p2 * (1 - p2)) / n2);
      const margin = z * se;

      return [
        Math.round((diff - margin) * 10000) / 100,
        Math.round((diff + margin) * 10000) / 100,
      ];
    }

    return [0, 0];
  }

  private calculatePValue(
    variant: VariantResults,
    control: VariantResults,
    metric: string
  ): number {
    if (variant.sampleSize < 10 || control.sampleSize < 10) {
      return 1;
    }

    if (metric === 'conversion_rate') {
      const { pValue } = zTestForProportions(
        variant.metrics.conversionRate,
        variant.sampleSize,
        control.metrics.conversionRate,
        control.sampleSize
      );
      return Math.round(pValue * 10000) / 10000;
    }

    if (metric === 'revenue') {
      // Use revenue per visitor as the metric
      // Would need actual revenue data variance for proper t-test
      const { pValue } = zTestForProportions(
        variant.metrics.conversionRate,
        variant.sampleSize,
        control.metrics.conversionRate,
        control.sampleSize
      );
      return Math.round(pValue * 10000) / 10000;
    }

    return 1;
  }

  private determineSignificance(
    variants: VariantResults[],
    control: VariantResults | null,
    confidenceLevel: number
  ): { significance: number; winner: string | null } {
    if (!control) {
      return { significance: 0, winner: null };
    }

    const alpha = 1 - confidenceLevel;
    let winner: string | null = null;
    let bestUplift = 0;
    let lowestPValue = 1;

    for (const variant of variants) {
      if (variant.variantId === control.variantId) continue;

      if (variant.pValue !== null && variant.pValue < lowestPValue) {
        lowestPValue = variant.pValue;
      }

      if (
        variant.pValue !== null &&
        variant.pValue < alpha &&
        variant.uplift &&
        variant.uplift.relative > bestUplift
      ) {
        winner = variant.variantId;
        bestUplift = variant.uplift.relative;
      }
    }

    return {
      significance: 1 - lowestPValue,
      winner,
    };
  }

  private calculatePowerAnalysis(
    variants: VariantResults[],
    minimumSampleSize: number,
    confidenceLevel: number
  ): PowerAnalysis {
    const totalSampleSize = variants.reduce((sum, v) => sum + v.sampleSize, 0);
    const avgDailyVisitors = totalSampleSize / 7; // Assume 7 days of data

    const requiredPerVariant = minimumSampleSize;
    const requiredTotal = requiredPerVariant * variants.length;

    const remaining = Math.max(0, requiredTotal - totalSampleSize);
    const daysRemaining = avgDailyVisitors > 0 ? Math.ceil(remaining / avgDailyVisitors) : 999;

    // Calculate current power (simplified)
    const effectSize = 0.05; // 5% minimum detectable effect
    const currentPower = Math.min(
      1,
      totalSampleSize / requiredTotal
    );

    return {
      currentPower: Math.round(currentPower * 100) / 100,
      requiredSampleSize: requiredTotal,
      estimatedDaysRemaining: daysRemaining,
      minimumDetectableEffect: effectSize * 100,
    };
  }

  private generateRecommendation(
    experiment: PricingExperiment,
    results: ExperimentResults
  ): { recommendation: string; nextSteps: string[] } {
    const nextSteps: string[] = [];

    if (results.status === 'insufficient_data') {
      return {
        recommendation: 'Continue running the experiment to gather more data.',
        nextSteps: [
          `Need ${results.powerAnalysis.requiredSampleSize - results.sampleSize} more visitors`,
          `Estimated ${results.powerAnalysis.estimatedDaysRemaining} days remaining`,
          'Ensure traffic is being directed to the experiment',
        ],
      };
    }

    if (results.status === 'winner_found' && results.winner) {
      const winner = results.variants.find((v) => v.variantId === results.winner);
      if (winner) {
        return {
          recommendation: `Implement the winning variant "${winner.variantName}" at $${winner.price.toFixed(2)}.`,
          nextSteps: [
            `Update product price to $${winner.price.toFixed(2)}`,
            'Stop the experiment',
            'Monitor conversion rates for 2 weeks post-implementation',
            'Consider running follow-up experiments to further optimize',
          ],
        };
      }
    }

    if (results.status === 'no_winner') {
      return {
        recommendation: 'No statistically significant winner found. Consider keeping current pricing.',
        nextSteps: [
          'Review if price differences were large enough to detect',
          'Consider testing with larger price variations',
          'Analyze if there are segment-specific patterns',
        ],
      };
    }

    return {
      recommendation: 'Results are inconclusive. Consider extending the experiment.',
      nextSteps: [
        'Continue running for at least 2 more weeks',
        'Increase traffic to the experiment if possible',
        'Review for any external factors affecting results',
      ],
    };
  }

  private async calculateDailyMetrics(
    experimentId: string
  ): Promise<Array<{
    date: string;
    variantId: string;
    visitors: number;
    conversions: number;
    revenue: number;
    conversionRate: number;
  }>> {
    const { data, error } = await this.supabase
      .from('pricing_experiment_events')
      .select('variant_id, event_type, revenue, created_at')
      .eq('experiment_id', experimentId)
      .order('created_at', { ascending: true });

    if (error || !data) {
      return [];
    }

    const dailyData: Map<string, {
      variantId: string;
      visitors: Set<string>;
      conversions: number;
      revenue: number;
    }> = new Map();

    for (const event of data) {
      const date = new Date(event.created_at).toISOString().split('T')[0];
      const key = `${date}:${event.variant_id}`;

      if (!dailyData.has(key)) {
        dailyData.set(key, {
          variantId: event.variant_id,
          visitors: new Set(),
          conversions: 0,
          revenue: 0,
        });
      }

      const day = dailyData.get(key)!;

      if (event.event_type === 'view') {
        // Would need visitor_id to properly count unique visitors
        day.visitors.add(event.created_at); // Using timestamp as proxy
      } else if (event.event_type === 'purchase') {
        day.conversions++;
        day.revenue += event.revenue ?? 0;
      }
    }

    return Array.from(dailyData.entries()).map(([key, value]) => ({
      date: key.split(':')[0],
      variantId: value.variantId,
      visitors: value.visitors.size,
      conversions: value.conversions,
      revenue: Math.round(value.revenue * 100) / 100,
      conversionRate: value.visitors.size > 0
        ? Math.round((value.conversions / value.visitors.size) * 10000) / 100
        : 0,
    }));
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createResultsAnalyzer(
  supabaseUrl: string,
  supabaseKey: string
): ResultsAnalyzer {
  return new ResultsAnalyzer(supabaseUrl, supabaseKey);
}
