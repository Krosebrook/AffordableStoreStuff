/**
 * ============================================================================
 * EXPERIMENT MANAGER
 * A/B test management for pricing experiments
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  PricingExperiment,
  ExperimentVariant,
  TrafficAllocation,
  DBPricingExperiment,
  DBExperimentEvent,
} from '../types.js';

// =============================================================================
// EXPERIMENT MANAGER CLASS
// =============================================================================

export class ExperimentManager {
  private readonly supabase: SupabaseClient;
  private readonly defaultConfidenceLevel: number;
  private readonly defaultMinSampleSize: number;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options?: {
      defaultConfidenceLevel?: number;
      defaultMinSampleSize?: number;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.defaultConfidenceLevel = options?.defaultConfidenceLevel ?? 0.95;
    this.defaultMinSampleSize = options?.defaultMinSampleSize ?? 100;
  }

  // ===========================================================================
  // EXPERIMENT CRUD
  // ===========================================================================

  /**
   * Create a new pricing experiment
   */
  async createExperiment(
    experiment: Omit<PricingExperiment, 'id' | 'status' | 'startDate' | 'endDate' | 'createdAt' | 'updatedAt'>
  ): Promise<PricingExperiment> {
    // Validate variants
    if (experiment.variants.length < 2) {
      throw new Error('Experiment must have at least 2 variants');
    }

    const hasControl = experiment.variants.some((v) => v.isControl);
    if (!hasControl) {
      throw new Error('Experiment must have exactly one control variant');
    }

    const totalTraffic = experiment.variants.reduce((sum, v) => sum + v.trafficPercent, 0);
    if (Math.abs(totalTraffic - 100) > 0.01) {
      throw new Error('Variant traffic percentages must sum to 100');
    }

    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .insert({
        name: experiment.name,
        description: experiment.description,
        product_id: experiment.productId,
        status: 'draft',
        variants: experiment.variants,
        traffic_allocation: experiment.trafficAllocation,
        primary_metric: experiment.primaryMetric,
        secondary_metrics: experiment.secondaryMetrics,
        minimum_sample_size: experiment.minimumSampleSize ?? this.defaultMinSampleSize,
        confidence_level: experiment.confidenceLevel ?? this.defaultConfidenceLevel,
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create experiment: ${error.message}`);
    }

    return this.mapDBExperiment(data);
  }

  /**
   * Get an experiment by ID
   */
  async getExperiment(experimentId: string): Promise<PricingExperiment | null> {
    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .select('*')
      .eq('id', experimentId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw new Error(`Failed to get experiment: ${error.message}`);
    }

    return this.mapDBExperiment(data);
  }

  /**
   * Get experiments for a product
   */
  async getExperimentsForProduct(productId: string): Promise<PricingExperiment[]> {
    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .select('*')
      .eq('product_id', productId)
      .order('created_at', { ascending: false });

    if (error) {
      throw new Error(`Failed to get experiments: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBExperiment(row));
  }

  /**
   * Get all active experiments
   */
  async getActiveExperiments(): Promise<PricingExperiment[]> {
    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .select('*')
      .eq('status', 'running')
      .order('start_date', { ascending: false });

    if (error) {
      throw new Error(`Failed to get active experiments: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBExperiment(row));
  }

  /**
   * Update an experiment
   */
  async updateExperiment(
    experimentId: string,
    updates: Partial<Pick<PricingExperiment, 'name' | 'description' | 'minimumSampleSize' | 'confidenceLevel'>>
  ): Promise<PricingExperiment> {
    const experiment = await this.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    if (experiment.status !== 'draft') {
      throw new Error('Can only update experiments in draft status');
    }

    const dbUpdates: Partial<DBPricingExperiment> = {};
    if (updates.name !== undefined) dbUpdates.name = updates.name;
    if (updates.description !== undefined) dbUpdates.description = updates.description;
    if (updates.minimumSampleSize !== undefined) dbUpdates.minimum_sample_size = updates.minimumSampleSize;
    if (updates.confidenceLevel !== undefined) dbUpdates.confidence_level = updates.confidenceLevel;

    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .update(dbUpdates)
      .eq('id', experimentId)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update experiment: ${error.message}`);
    }

    return this.mapDBExperiment(data);
  }

  /**
   * Delete an experiment
   */
  async deleteExperiment(experimentId: string): Promise<void> {
    const experiment = await this.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    if (experiment.status === 'running') {
      throw new Error('Cannot delete a running experiment. Stop it first.');
    }

    const { error } = await this.supabase
      .from('pricing_experiments')
      .delete()
      .eq('id', experimentId);

    if (error) {
      throw new Error(`Failed to delete experiment: ${error.message}`);
    }
  }

  // ===========================================================================
  // EXPERIMENT LIFECYCLE
  // ===========================================================================

  /**
   * Start an experiment
   */
  async startExperiment(experimentId: string): Promise<PricingExperiment> {
    const experiment = await this.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    if (experiment.status !== 'draft' && experiment.status !== 'paused') {
      throw new Error(`Cannot start experiment in ${experiment.status} status`);
    }

    // Check for conflicting experiments
    const activeExperiments = await this.getActiveExperiments();
    const conflict = activeExperiments.find(
      (e) => e.productId === experiment.productId && e.id !== experimentId
    );
    if (conflict) {
      throw new Error(`Another experiment (${conflict.name}) is already running for this product`);
    }

    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .update({
        status: 'running',
        start_date: experiment.startDate ?? new Date().toISOString(),
      })
      .eq('id', experimentId)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to start experiment: ${error.message}`);
    }

    return this.mapDBExperiment(data);
  }

  /**
   * Pause an experiment
   */
  async pauseExperiment(experimentId: string): Promise<PricingExperiment> {
    const experiment = await this.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    if (experiment.status !== 'running') {
      throw new Error('Can only pause running experiments');
    }

    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .update({ status: 'paused' })
      .eq('id', experimentId)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to pause experiment: ${error.message}`);
    }

    return this.mapDBExperiment(data);
  }

  /**
   * Stop an experiment
   */
  async stopExperiment(experimentId: string): Promise<PricingExperiment> {
    const experiment = await this.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    if (experiment.status !== 'running' && experiment.status !== 'paused') {
      throw new Error('Experiment is not running or paused');
    }

    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .update({
        status: 'completed',
        end_date: new Date().toISOString(),
      })
      .eq('id', experimentId)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to stop experiment: ${error.message}`);
    }

    return this.mapDBExperiment(data);
  }

  /**
   * Cancel an experiment
   */
  async cancelExperiment(experimentId: string): Promise<PricingExperiment> {
    const experiment = await this.getExperiment(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    if (experiment.status === 'completed' || experiment.status === 'cancelled') {
      throw new Error('Experiment is already finished');
    }

    const { data, error } = await this.supabase
      .from('pricing_experiments')
      .update({
        status: 'cancelled',
        end_date: new Date().toISOString(),
      })
      .eq('id', experimentId)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to cancel experiment: ${error.message}`);
    }

    return this.mapDBExperiment(data);
  }

  // ===========================================================================
  // VARIANT ASSIGNMENT
  // ===========================================================================

  /**
   * Assign a visitor to an experiment variant
   */
  async assignVariant(
    experimentId: string,
    visitorId: string
  ): Promise<ExperimentVariant | null> {
    const experiment = await this.getExperiment(experimentId);
    if (!experiment || experiment.status !== 'running') {
      return null;
    }

    // Check for existing assignment
    const existing = await this.getVisitorAssignment(experimentId, visitorId);
    if (existing) {
      return experiment.variants.find((v) => v.id === existing) ?? null;
    }

    // Assign new variant based on traffic allocation
    const variant = this.selectVariant(experiment, visitorId);
    if (!variant) {
      return null;
    }

    // Store assignment
    await this.storeAssignment(experimentId, visitorId, variant.id);

    return variant;
  }

  /**
   * Get the assigned variant for a visitor
   */
  async getVisitorAssignment(
    experimentId: string,
    visitorId: string
  ): Promise<string | null> {
    const { data, error } = await this.supabase
      .from('pricing_experiment_assignments')
      .select('variant_id')
      .eq('experiment_id', experimentId)
      .eq('visitor_id', visitorId)
      .single();

    if (error || !data) {
      return null;
    }

    return data.variant_id;
  }

  /**
   * Get price for a visitor
   */
  async getPriceForVisitor(
    productId: string,
    visitorId: string,
    defaultPrice: number
  ): Promise<{ price: number; experimentId?: string; variantId?: string }> {
    // Find active experiment for this product
    const experiments = await this.getActiveExperiments();
    const experiment = experiments.find((e) => e.productId === productId);

    if (!experiment) {
      return { price: defaultPrice };
    }

    const variant = await this.assignVariant(experiment.id, visitorId);
    if (!variant) {
      return { price: defaultPrice };
    }

    return {
      price: variant.price,
      experimentId: experiment.id,
      variantId: variant.id,
    };
  }

  // ===========================================================================
  // EVENT TRACKING
  // ===========================================================================

  /**
   * Track an experiment event
   */
  async trackEvent(
    experimentId: string,
    variantId: string,
    visitorId: string,
    eventType: 'view' | 'add_to_cart' | 'purchase',
    revenue?: number,
    metadata?: Record<string, unknown>
  ): Promise<void> {
    const { error } = await this.supabase.from('pricing_experiment_events').insert({
      experiment_id: experimentId,
      variant_id: variantId,
      visitor_id: visitorId,
      event_type: eventType,
      revenue: revenue ?? null,
      metadata: metadata ?? {},
    });

    if (error) {
      throw new Error(`Failed to track event: ${error.message}`);
    }
  }

  /**
   * Track a view event
   */
  async trackView(
    experimentId: string,
    variantId: string,
    visitorId: string
  ): Promise<void> {
    await this.trackEvent(experimentId, variantId, visitorId, 'view');
  }

  /**
   * Track an add to cart event
   */
  async trackAddToCart(
    experimentId: string,
    variantId: string,
    visitorId: string
  ): Promise<void> {
    await this.trackEvent(experimentId, variantId, visitorId, 'add_to_cart');
  }

  /**
   * Track a purchase event
   */
  async trackPurchase(
    experimentId: string,
    variantId: string,
    visitorId: string,
    revenue: number
  ): Promise<void> {
    await this.trackEvent(experimentId, variantId, visitorId, 'purchase', revenue);
  }

  /**
   * Get event counts for an experiment
   */
  async getEventCounts(
    experimentId: string
  ): Promise<Record<string, { views: number; addToCarts: number; purchases: number; revenue: number }>> {
    const { data, error } = await this.supabase
      .from('pricing_experiment_events')
      .select('variant_id, event_type, revenue')
      .eq('experiment_id', experimentId);

    if (error) {
      throw new Error(`Failed to get event counts: ${error.message}`);
    }

    const counts: Record<string, { views: number; addToCarts: number; purchases: number; revenue: number }> = {};

    for (const event of data ?? []) {
      if (!counts[event.variant_id]) {
        counts[event.variant_id] = { views: 0, addToCarts: 0, purchases: 0, revenue: 0 };
      }

      switch (event.event_type) {
        case 'view':
          counts[event.variant_id].views++;
          break;
        case 'add_to_cart':
          counts[event.variant_id].addToCarts++;
          break;
        case 'purchase':
          counts[event.variant_id].purchases++;
          counts[event.variant_id].revenue += event.revenue ?? 0;
          break;
      }
    }

    return counts;
  }

  // ===========================================================================
  // HELPER METHODS
  // ===========================================================================

  private selectVariant(experiment: PricingExperiment, visitorId: string): ExperimentVariant | null {
    const allocation = experiment.trafficAllocation;

    // Generate deterministic random number based on visitor ID
    let hash = 0;
    const seed = allocation.seed ?? 0;
    const str = `${experiment.id}:${visitorId}:${seed}`;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    const random = Math.abs(hash) / 2147483647 * 100; // Convert to 0-100

    // Select variant based on traffic allocation
    let cumulative = 0;
    for (const variant of experiment.variants) {
      cumulative += variant.trafficPercent;
      if (random <= cumulative) {
        return variant;
      }
    }

    // Fallback to control
    return experiment.variants.find((v) => v.isControl) ?? experiment.variants[0];
  }

  private async storeAssignment(
    experimentId: string,
    visitorId: string,
    variantId: string
  ): Promise<void> {
    const { error } = await this.supabase
      .from('pricing_experiment_assignments')
      .upsert(
        {
          experiment_id: experimentId,
          visitor_id: visitorId,
          variant_id: variantId,
        },
        { onConflict: 'experiment_id,visitor_id' }
      );

    if (error) {
      console.error('Failed to store assignment:', error);
    }
  }

  private mapDBExperiment(row: DBPricingExperiment): PricingExperiment {
    return {
      id: row.id,
      name: row.name,
      description: row.description,
      productId: row.product_id,
      status: row.status as PricingExperiment['status'],
      variants: row.variants,
      trafficAllocation: row.traffic_allocation,
      primaryMetric: row.primary_metric as PricingExperiment['primaryMetric'],
      secondaryMetrics: row.secondary_metrics,
      minimumSampleSize: row.minimum_sample_size,
      confidenceLevel: row.confidence_level,
      startDate: row.start_date ? new Date(row.start_date) : null,
      endDate: row.end_date ? new Date(row.end_date) : null,
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at),
    };
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createExperimentManager(
  supabaseUrl: string,
  supabaseKey: string,
  options?: {
    defaultConfidenceLevel?: number;
    defaultMinSampleSize?: number;
  }
): ExperimentManager {
  return new ExperimentManager(supabaseUrl, supabaseKey, options);
}
