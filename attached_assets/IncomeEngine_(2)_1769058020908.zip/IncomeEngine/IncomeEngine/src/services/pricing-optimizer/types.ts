/**
 * ============================================================================
 * PRICING OPTIMIZER - TYPE DEFINITIONS
 * Intelligent Pricing Optimizer for Income Engine
 * ============================================================================
 */

// =============================================================================
// CORE TYPES
// =============================================================================

export interface PricePoint {
  readonly price: number;
  readonly currency: string;
  readonly timestamp: Date;
}

export interface ProductPricing {
  readonly productId: string;
  readonly sku: string;
  readonly currentPrice: number;
  readonly costPrice: number;
  readonly currency: string;
  readonly platform: string;
  readonly category: string;
  readonly tags: readonly string[];
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

// =============================================================================
// COMPETITOR MONITORING TYPES
// =============================================================================

export interface Competitor {
  readonly id: string;
  readonly name: string;
  readonly platform: string;
  readonly url: string;
  readonly isActive: boolean;
  readonly lastScraped: Date | null;
  readonly scrapeFrequency: 'hourly' | 'daily' | 'weekly';
}

export interface CompetitorProduct {
  readonly id: string;
  readonly competitorId: string;
  readonly externalId: string;
  readonly title: string;
  readonly url: string;
  readonly imageUrl: string | null;
  readonly currentPrice: number;
  readonly currency: string;
  readonly availability: 'in_stock' | 'out_of_stock' | 'limited' | 'unknown';
  readonly rating: number | null;
  readonly reviewCount: number | null;
  readonly lastUpdated: Date;
}

export interface CompetitorPriceHistory {
  readonly id: string;
  readonly competitorProductId: string;
  readonly price: number;
  readonly currency: string;
  readonly availability: string;
  readonly scrapedAt: Date;
}

export interface PriceAlert {
  readonly id: string;
  readonly productId: string;
  readonly competitorProductId: string;
  readonly alertType: 'price_drop' | 'price_increase' | 'out_of_stock' | 'back_in_stock' | 'new_competitor';
  readonly previousValue: number | string;
  readonly currentValue: number | string;
  readonly percentChange: number | null;
  readonly severity: 'low' | 'medium' | 'high' | 'critical';
  readonly isAcknowledged: boolean;
  readonly createdAt: Date;
}

export interface ScraperConfig {
  readonly url: string;
  readonly platform: string;
  readonly selectors: {
    readonly price: string;
    readonly title: string;
    readonly availability: string;
    readonly rating?: string;
    readonly reviewCount?: string;
    readonly imageUrl?: string;
  };
  readonly waitForSelector?: string;
  readonly timeout: number;
  readonly retryAttempts: number;
}

export interface ScraperResult {
  readonly success: boolean;
  readonly data?: CompetitorProduct;
  readonly error?: string;
  readonly scrapedAt: Date;
  readonly responseTimeMs: number;
}

// =============================================================================
// DEMAND ANALYSIS TYPES
// =============================================================================

export interface SalesData {
  readonly productId: string;
  readonly date: Date;
  readonly quantity: number;
  readonly revenue: number;
  readonly price: number;
  readonly platform: string;
}

export interface ElasticityResult {
  readonly productId: string;
  readonly elasticity: number;
  readonly interpretation: 'elastic' | 'inelastic' | 'unit_elastic';
  readonly confidence: number;
  readonly sampleSize: number;
  readonly priceRange: {
    readonly min: number;
    readonly max: number;
  };
  readonly calculatedAt: Date;
}

export interface SeasonalPattern {
  readonly productId: string;
  readonly patternType: 'weekly' | 'monthly' | 'quarterly' | 'annual';
  readonly factors: SeasonalFactor[];
  readonly peakPeriods: string[];
  readonly lowPeriods: string[];
  readonly confidence: number;
  readonly calculatedAt: Date;
}

export interface SeasonalFactor {
  readonly period: string;
  readonly factor: number;
  readonly label: string;
}

export interface ConversionData {
  readonly productId: string;
  readonly price: number;
  readonly views: number;
  readonly addToCart: number;
  readonly purchases: number;
  readonly conversionRate: number;
  readonly date: Date;
}

export interface ConversionAnalysis {
  readonly productId: string;
  readonly optimalPriceRange: {
    readonly min: number;
    readonly max: number;
  };
  readonly currentConversionRate: number;
  readonly projectedConversionRates: PriceConversionProjection[];
  readonly insights: string[];
  readonly calculatedAt: Date;
}

export interface PriceConversionProjection {
  readonly price: number;
  readonly projectedConversionRate: number;
  readonly projectedRevenue: number;
  readonly confidence: number;
}

// =============================================================================
// PRICE OPTIMIZATION TYPES
// =============================================================================

export interface PricingRule {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly condition: PricingCondition;
  readonly action: PricingAction;
  readonly priority: number;
  readonly isEnabled: boolean;
  readonly appliesTo: {
    readonly platforms?: string[];
    readonly categories?: string[];
    readonly tags?: string[];
    readonly productIds?: string[];
  };
  readonly schedule?: RuleSchedule;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface PricingCondition {
  readonly type: 'competitor_price' | 'demand' | 'inventory' | 'time' | 'margin' | 'composite';
  readonly operator: 'gt' | 'gte' | 'lt' | 'lte' | 'eq' | 'between' | 'in';
  readonly value: number | string | readonly (number | string)[];
  readonly field?: string;
  readonly children?: PricingCondition[];
  readonly logicalOperator?: 'and' | 'or';
}

export interface PricingAction {
  readonly type: 'set_price' | 'adjust_percent' | 'adjust_amount' | 'match_competitor' | 'beat_competitor';
  readonly value: number;
  readonly constraints?: {
    readonly minPrice?: number;
    readonly maxPrice?: number;
    readonly minMargin?: number;
    readonly maxChange?: number;
  };
}

export interface RuleSchedule {
  readonly startDate?: Date;
  readonly endDate?: Date;
  readonly daysOfWeek?: number[];
  readonly hoursOfDay?: number[];
  readonly timezone: string;
}

export interface PriceRecommendation {
  readonly productId: string;
  readonly currentPrice: number;
  readonly recommendedPrice: number;
  readonly confidence: number;
  readonly reasoning: readonly string[];
  readonly factors: PricingFactor[];
  readonly projectedImpact: ProjectedImpact;
  readonly appliedRules: string[];
  readonly createdAt: Date;
  readonly expiresAt: Date;
}

export interface PricingFactor {
  readonly name: string;
  readonly weight: number;
  readonly value: number;
  readonly contribution: number;
  readonly description: string;
}

export interface ProjectedImpact {
  readonly revenueChange: number;
  readonly revenueChangePercent: number;
  readonly marginChange: number;
  readonly marginChangePercent: number;
  readonly volumeChange: number;
  readonly volumeChangePercent: number;
}

export interface MarginProtection {
  readonly productId: string;
  readonly costPrice: number;
  readonly minimumMargin: number;
  readonly minimumPrice: number;
  readonly currentMargin: number;
  readonly isProtected: boolean;
}

// =============================================================================
// A/B TESTING TYPES
// =============================================================================

export interface PricingExperiment {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly productId: string;
  readonly status: 'draft' | 'running' | 'paused' | 'completed' | 'cancelled';
  readonly variants: ExperimentVariant[];
  readonly trafficAllocation: TrafficAllocation;
  readonly primaryMetric: 'revenue' | 'conversion_rate' | 'profit' | 'units_sold';
  readonly secondaryMetrics: string[];
  readonly minimumSampleSize: number;
  readonly confidenceLevel: number;
  readonly startDate: Date | null;
  readonly endDate: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface ExperimentVariant {
  readonly id: string;
  readonly name: string;
  readonly price: number;
  readonly isControl: boolean;
  readonly trafficPercent: number;
}

export interface TrafficAllocation {
  readonly method: 'random' | 'user_based' | 'session_based';
  readonly seed?: number;
}

export interface ExperimentResults {
  readonly experimentId: string;
  readonly status: 'insufficient_data' | 'no_winner' | 'winner_found' | 'inconclusive';
  readonly winner: string | null;
  readonly variants: VariantResults[];
  readonly statisticalSignificance: number;
  readonly sampleSize: number;
  readonly powerAnalysis: PowerAnalysis;
  readonly calculatedAt: Date;
}

export interface VariantResults {
  readonly variantId: string;
  readonly variantName: string;
  readonly price: number;
  readonly sampleSize: number;
  readonly metrics: {
    readonly conversions: number;
    readonly revenue: number;
    readonly averageOrderValue: number;
    readonly conversionRate: number;
    readonly revenuePerVisitor: number;
  };
  readonly uplift: {
    readonly absolute: number;
    readonly relative: number;
    readonly confidenceInterval: [number, number];
  } | null;
  readonly pValue: number | null;
}

export interface PowerAnalysis {
  readonly currentPower: number;
  readonly requiredSampleSize: number;
  readonly estimatedDaysRemaining: number;
  readonly minimumDetectableEffect: number;
}

// =============================================================================
// ORCHESTRATOR TYPES
// =============================================================================

export interface PricingOptimizerConfig {
  readonly supabaseUrl: string;
  readonly supabaseKey: string;
  readonly enableCompetitorMonitoring: boolean;
  readonly enableDemandAnalysis: boolean;
  readonly enableABTesting: boolean;
  readonly defaultCurrency: string;
  readonly defaultMinMargin: number;
  readonly recommendationTTLHours: number;
  readonly scraperConfig?: Partial<ScraperConfig>;
}

export interface PricingOptimizerStatus {
  readonly isHealthy: boolean;
  readonly lastUpdated: Date;
  readonly activeExperiments: number;
  readonly pendingRecommendations: number;
  readonly activeAlerts: number;
  readonly competitorsTracked: number;
  readonly errors: string[];
}

// =============================================================================
// DATABASE ENTITY TYPES
// =============================================================================

export interface DBCompetitor {
  id: string;
  name: string;
  platform: string;
  url: string;
  is_active: boolean;
  last_scraped: string | null;
  scrape_frequency: string;
  created_at: string;
  updated_at: string;
}

export interface DBCompetitorProduct {
  id: string;
  competitor_id: string;
  external_id: string;
  our_product_id: string | null;
  title: string;
  url: string;
  image_url: string | null;
  current_price: number;
  currency: string;
  availability: string;
  rating: number | null;
  review_count: number | null;
  last_updated: string;
  created_at: string;
}

export interface DBPriceHistory {
  id: string;
  competitor_product_id: string;
  price: number;
  currency: string;
  availability: string;
  scraped_at: string;
}

export interface DBPriceAlert {
  id: string;
  product_id: string;
  competitor_product_id: string;
  alert_type: string;
  previous_value: string;
  current_value: string;
  percent_change: number | null;
  severity: string;
  is_acknowledged: boolean;
  created_at: string;
}

export interface DBPricingRule {
  id: string;
  name: string;
  description: string;
  condition: PricingCondition;
  action: PricingAction;
  priority: number;
  is_enabled: boolean;
  applies_to: {
    platforms?: string[];
    categories?: string[];
    tags?: string[];
    product_ids?: string[];
  };
  schedule: RuleSchedule | null;
  created_at: string;
  updated_at: string;
}

export interface DBPricingExperiment {
  id: string;
  name: string;
  description: string;
  product_id: string;
  status: string;
  variants: ExperimentVariant[];
  traffic_allocation: TrafficAllocation;
  primary_metric: string;
  secondary_metrics: string[];
  minimum_sample_size: number;
  confidence_level: number;
  start_date: string | null;
  end_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface DBExperimentEvent {
  id: string;
  experiment_id: string;
  variant_id: string;
  visitor_id: string;
  event_type: 'view' | 'add_to_cart' | 'purchase';
  revenue: number | null;
  metadata: Record<string, unknown>;
  created_at: string;
}
