/**
 * ============================================================================
 * PRICING OPTIMIZER - MAIN ORCHESTRATOR
 * Intelligent Pricing Optimizer for Income Engine
 * ============================================================================
 *
 * This module provides a unified interface for:
 * - Competitor price monitoring and alerts
 * - Demand analysis (elasticity, seasonality, conversion)
 * - Price optimization with rule engine and margin protection
 * - A/B testing for pricing experiments
 */

import type {
  PricingOptimizerConfig,
  PricingOptimizerStatus,
  PriceRecommendation,
  PricingRule,
  PricingExperiment,
  ExperimentResults,
  Competitor,
  CompetitorProduct,
  PriceAlert,
  ElasticityResult,
  SeasonalPattern,
  ConversionAnalysis,
} from './types.js';

// Import sub-modules
import { createPriceTracker, PriceTracker } from './competitor-monitor/price-tracker.js';
import { createPriceAlertService, PriceAlertService } from './competitor-monitor/alert-service.js';
import { createCompetitorScraper, CompetitorScraper } from './competitor-monitor/scraper.js';
import { createElasticityCalculator, ElasticityCalculator } from './demand-analysis/elasticity-calculator.js';
import { createSeasonalityDetector, SeasonalityDetector } from './demand-analysis/seasonality-detector.js';
import { createConversionAnalyzer, ConversionAnalyzer } from './demand-analysis/conversion-analyzer.js';
import { createPriceCalculator, PriceCalculator } from './optimization/price-calculator.js';
import { createMarginProtector, MarginProtector } from './optimization/margin-protector.js';
import { createPricingRuleEngine, PricingRuleEngine } from './optimization/rule-engine.js';
import { createExperimentManager, ExperimentManager } from './ab-testing/experiment-manager.js';
import { createResultsAnalyzer, ResultsAnalyzer } from './ab-testing/results-analyzer.js';

// =============================================================================
// DEFAULT CONFIGURATION
// =============================================================================

const DEFAULT_CONFIG: PricingOptimizerConfig = {
  supabaseUrl: '',
  supabaseKey: '',
  enableCompetitorMonitoring: true,
  enableDemandAnalysis: true,
  enableABTesting: true,
  defaultCurrency: 'USD',
  defaultMinMargin: 0.3,
  recommendationTTLHours: 24,
};

// =============================================================================
// PRICING OPTIMIZER CLASS
// =============================================================================

export class PricingOptimizer {
  private readonly config: PricingOptimizerConfig;

  // Sub-services
  private readonly priceTracker: PriceTracker;
  private readonly alertService: PriceAlertService;
  private readonly scraper: CompetitorScraper;
  private readonly elasticityCalculator: ElasticityCalculator;
  private readonly seasonalityDetector: SeasonalityDetector;
  private readonly conversionAnalyzer: ConversionAnalyzer;
  private readonly priceCalculator: PriceCalculator;
  private readonly marginProtector: MarginProtector;
  private readonly ruleEngine: PricingRuleEngine;
  private readonly experimentManager: ExperimentManager;
  private readonly resultsAnalyzer: ResultsAnalyzer;

  constructor(config: Partial<PricingOptimizerConfig> & { supabaseUrl: string; supabaseKey: string }) {
    this.config = { ...DEFAULT_CONFIG, ...config };

    // Initialize sub-services
    this.priceTracker = createPriceTracker(
      this.config.supabaseUrl,
      this.config.supabaseKey,
      this.config.scraperConfig
    );
    this.alertService = createPriceAlertService(this.config.supabaseUrl, this.config.supabaseKey);
    this.scraper = createCompetitorScraper(this.config.scraperConfig);
    this.elasticityCalculator = createElasticityCalculator(
      this.config.supabaseUrl,
      this.config.supabaseKey
    );
    this.seasonalityDetector = createSeasonalityDetector(
      this.config.supabaseUrl,
      this.config.supabaseKey
    );
    this.conversionAnalyzer = createConversionAnalyzer(
      this.config.supabaseUrl,
      this.config.supabaseKey
    );
    this.priceCalculator = createPriceCalculator(this.config.supabaseUrl, this.config.supabaseKey, {
      recommendationTTLHours: this.config.recommendationTTLHours,
    });
    this.marginProtector = createMarginProtector(this.config.supabaseUrl, this.config.supabaseKey, {
      defaultMinMargin: this.config.defaultMinMargin,
    });
    this.ruleEngine = createPricingRuleEngine(this.config.supabaseUrl, this.config.supabaseKey);
    this.experimentManager = createExperimentManager(
      this.config.supabaseUrl,
      this.config.supabaseKey
    );
    this.resultsAnalyzer = createResultsAnalyzer(this.config.supabaseUrl, this.config.supabaseKey);
  }

  // ===========================================================================
  // STATUS & HEALTH
  // ===========================================================================

  /**
   * Get the current status of the pricing optimizer
   */
  async getStatus(): Promise<PricingOptimizerStatus> {
    try {
      const [alerts, experiments, competitors] = await Promise.all([
        this.alertService.getUnacknowledgedAlerts({ limit: 100 }),
        this.experimentManager.getActiveExperiments(),
        this.priceTracker.getActiveCompetitors(),
      ]);

      return {
        isHealthy: true,
        lastUpdated: new Date(),
        activeExperiments: experiments.length,
        pendingRecommendations: 0, // Would need to query recommendations table
        activeAlerts: alerts.length,
        competitorsTracked: competitors.length,
        errors: [],
      };
    } catch (error) {
      return {
        isHealthy: false,
        lastUpdated: new Date(),
        activeExperiments: 0,
        pendingRecommendations: 0,
        activeAlerts: 0,
        competitorsTracked: 0,
        errors: [error instanceof Error ? error.message : 'Unknown error'],
      };
    }
  }

  // ===========================================================================
  // PRICE RECOMMENDATIONS
  // ===========================================================================

  /**
   * Get price recommendation for a product
   */
  async getRecommendation(
    productId: string,
    options?: { competitorPrices?: number[]; forceRecalculate?: boolean }
  ): Promise<PriceRecommendation> {
    return this.priceCalculator.calculateOptimalPrice(productId, options);
  }

  /**
   * Get recommendations for multiple products
   */
  async getBulkRecommendations(
    productIds: string[],
    options?: { concurrency?: number }
  ): Promise<Map<string, PriceRecommendation>> {
    return this.priceCalculator.calculateBulkRecommendations(productIds, options);
  }

  /**
   * Explain a price recommendation
   */
  async explainRecommendation(productId: string): Promise<{
    recommendation: PriceRecommendation | null;
    explanation: string;
    factorBreakdown: Array<{ factor: string; impact: string; weight: string }>;
  }> {
    return this.priceCalculator.explainRecommendation(productId);
  }

  // ===========================================================================
  // COMPETITOR MONITORING
  // ===========================================================================

  /**
   * Add a competitor to track
   */
  async addCompetitor(competitor: Omit<Competitor, 'id' | 'lastScraped'>): Promise<Competitor> {
    return this.priceTracker.addCompetitor(competitor);
  }

  /**
   * Get all active competitors
   */
  async getCompetitors(): Promise<Competitor[]> {
    return this.priceTracker.getActiveCompetitors();
  }

  /**
   * Add a competitor product to track
   */
  async addCompetitorProduct(
    competitorId: string,
    product: {
      externalId: string;
      title: string;
      url: string;
      imageUrl?: string;
      currentPrice: number;
      currency: string;
      ourProductId?: string;
    }
  ): Promise<CompetitorProduct> {
    return this.priceTracker.addCompetitorProduct(competitorId, product);
  }

  /**
   * Get competitor products for one of our products
   */
  async getCompetitorProducts(ourProductId: string): Promise<CompetitorProduct[]> {
    return this.priceTracker.getCompetitorProductsForOurProduct(ourProductId);
  }

  /**
   * Scrape all due competitors
   */
  async scrapeCompetitors(): Promise<{
    competitorsScraped: number;
    productsScraped: number;
    successRate: number;
  }> {
    return this.priceTracker.scrapeDueCompetitors();
  }

  /**
   * Get price statistics for a competitor product
   */
  async getCompetitorPriceStats(
    competitorProductId: string,
    days?: number
  ): Promise<{
    currentPrice: number;
    minPrice: number;
    maxPrice: number;
    avgPrice: number;
    priceChange: number;
    priceChangePercent: number;
    volatility: number;
    dataPoints: number;
  }> {
    return this.priceTracker.getPriceStatistics(competitorProductId, days);
  }

  // ===========================================================================
  // PRICE ALERTS
  // ===========================================================================

  /**
   * Get unacknowledged price alerts
   */
  async getAlerts(options?: {
    productId?: string;
    severity?: PriceAlert['severity'];
    limit?: number;
  }): Promise<PriceAlert[]> {
    return this.alertService.getUnacknowledgedAlerts(options);
  }

  /**
   * Acknowledge a price alert
   */
  async acknowledgeAlert(alertId: string): Promise<void> {
    return this.alertService.acknowledgeAlert(alertId);
  }

  /**
   * Get alert statistics
   */
  async getAlertStats(days?: number): Promise<{
    total: number;
    byType: Record<string, number>;
    bySeverity: Record<string, number>;
    acknowledged: number;
    unacknowledged: number;
    averagePerDay: number;
  }> {
    return this.alertService.getAlertStatistics(days);
  }

  // ===========================================================================
  // DEMAND ANALYSIS
  // ===========================================================================

  /**
   * Calculate price elasticity for a product
   */
  async getElasticity(
    productId: string,
    options?: { startDate?: Date; endDate?: Date }
  ): Promise<ElasticityResult> {
    return this.elasticityCalculator.calculateElasticity(productId, options);
  }

  /**
   * Detect seasonal patterns for a product
   */
  async getSeasonalPatterns(
    productId: string,
    options?: { startDate?: Date; endDate?: Date }
  ): Promise<SeasonalPattern[]> {
    return this.seasonalityDetector.detectPatterns(productId, options);
  }

  /**
   * Get seasonal demand forecast
   */
  async forecastDemand(
    productId: string,
    targetDate: Date,
    baselineQuantity?: number
  ): Promise<{
    forecastedQuantity: number;
    baselineQuantity: number;
    adjustmentFactor: number;
    confidence: number;
  }> {
    return this.seasonalityDetector.forecastDemand(productId, targetDate, {
      baselineQuantity,
    });
  }

  /**
   * Analyze conversion rates at different price points
   */
  async analyzeConversion(
    productId: string,
    options?: { startDate?: Date; endDate?: Date }
  ): Promise<ConversionAnalysis> {
    return this.conversionAnalyzer.analyzeConversion(productId, options);
  }

  /**
   * Analyze revenue per visitor
   */
  async analyzeRevenuePerVisitor(
    productId: string,
    options?: { startDate?: Date; endDate?: Date }
  ): Promise<{
    pricePoints: Array<{
      price: number;
      revenuePerVisitor: number;
      conversionRate: number;
      views: number;
    }>;
    optimalPrice: number;
    currentRevPerVisitor: number;
    potentialUplift: number;
  }> {
    return this.conversionAnalyzer.analyzeRevenuePerVisitor(productId, options);
  }

  // ===========================================================================
  // PRICING RULES
  // ===========================================================================

  /**
   * Create a pricing rule
   */
  async createRule(
    rule: Omit<PricingRule, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<PricingRule> {
    return this.ruleEngine.createRule(rule);
  }

  /**
   * Get all pricing rules
   */
  async getRules(options?: { enabledOnly?: boolean }): Promise<PricingRule[]> {
    return this.ruleEngine.getRules(options);
  }

  /**
   * Update a pricing rule
   */
  async updateRule(
    ruleId: string,
    updates: Partial<Omit<PricingRule, 'id' | 'createdAt' | 'updatedAt'>>
  ): Promise<PricingRule> {
    return this.ruleEngine.updateRule(ruleId, updates);
  }

  /**
   * Delete a pricing rule
   */
  async deleteRule(ruleId: string): Promise<void> {
    return this.ruleEngine.deleteRule(ruleId);
  }

  /**
   * Enable/disable a rule
   */
  async setRuleEnabled(ruleId: string, enabled: boolean): Promise<void> {
    return this.ruleEngine.setRuleEnabled(ruleId, enabled);
  }

  // ===========================================================================
  // MARGIN PROTECTION
  // ===========================================================================

  /**
   * Check if a price maintains minimum margin
   */
  checkMargin(
    proposedPrice: number,
    costPrice: number,
    options?: { category?: string; platform?: string }
  ): { isValid: boolean; minimumPrice: number; currentMargin: number } {
    const result = this.marginProtector.checkMargin(proposedPrice, costPrice, options);
    return {
      isValid: result.isValid,
      minimumPrice: result.minimumPrice,
      currentMargin: result.currentMargin,
    };
  }

  /**
   * Get margin statistics
   */
  async getMarginStats(options?: {
    category?: string;
    platform?: string;
  }): Promise<{
    averageMargin: number;
    medianMargin: number;
    minMargin: number;
    maxMargin: number;
    productsBelow: number;
    productsAbove: number;
    totalProducts: number;
  }> {
    return this.marginProtector.getMarginStatistics(options);
  }

  /**
   * Find products with low margins
   */
  async findLowMarginProducts(options?: {
    category?: string;
    platform?: string;
    limit?: number;
  }): Promise<Array<{ productId: string; margin: number; minimumMargin: number; gap: number }>> {
    const products = await this.marginProtector.findLowMarginProducts(options);
    return products.map((p) => ({
      productId: p.productId,
      margin: p.margin,
      minimumMargin: p.minimumMargin,
      gap: p.gap,
    }));
  }

  // ===========================================================================
  // A/B TESTING
  // ===========================================================================

  /**
   * Create a pricing experiment
   */
  async createExperiment(
    experiment: Omit<
      PricingExperiment,
      'id' | 'status' | 'startDate' | 'endDate' | 'createdAt' | 'updatedAt'
    >
  ): Promise<PricingExperiment> {
    return this.experimentManager.createExperiment(experiment);
  }

  /**
   * Get an experiment by ID
   */
  async getExperiment(experimentId: string): Promise<PricingExperiment | null> {
    return this.experimentManager.getExperiment(experimentId);
  }

  /**
   * Get experiments for a product
   */
  async getExperiments(productId: string): Promise<PricingExperiment[]> {
    return this.experimentManager.getExperimentsForProduct(productId);
  }

  /**
   * Get all active experiments
   */
  async getActiveExperiments(): Promise<PricingExperiment[]> {
    return this.experimentManager.getActiveExperiments();
  }

  /**
   * Start an experiment
   */
  async startExperiment(experimentId: string): Promise<PricingExperiment> {
    return this.experimentManager.startExperiment(experimentId);
  }

  /**
   * Stop an experiment
   */
  async stopExperiment(experimentId: string): Promise<PricingExperiment> {
    return this.experimentManager.stopExperiment(experimentId);
  }

  /**
   * Get price for a visitor in an active experiment
   */
  async getPriceForVisitor(
    productId: string,
    visitorId: string,
    defaultPrice: number
  ): Promise<{ price: number; experimentId?: string; variantId?: string }> {
    return this.experimentManager.getPriceForVisitor(productId, visitorId, defaultPrice);
  }

  /**
   * Track a purchase event in an experiment
   */
  async trackPurchase(
    experimentId: string,
    variantId: string,
    visitorId: string,
    revenue: number
  ): Promise<void> {
    return this.experimentManager.trackPurchase(experimentId, variantId, visitorId, revenue);
  }

  /**
   * Analyze experiment results
   */
  async analyzeExperiment(experimentId: string): Promise<ExperimentResults> {
    return this.resultsAnalyzer.analyzeResults(experimentId);
  }

  /**
   * Get experiment summary with recommendation
   */
  async getExperimentSummary(experimentId: string): Promise<{
    experiment: PricingExperiment;
    results: ExperimentResults;
    recommendation: string;
    nextSteps: string[];
  }> {
    return this.resultsAnalyzer.getExperimentSummary(experimentId);
  }

  /**
   * Check if experiment has reached statistical significance
   */
  async checkExperimentSignificance(experimentId: string): Promise<{
    isSignificant: boolean;
    pValue: number;
    sampleSizeReached: boolean;
    estimatedTimeRemaining: number;
  }> {
    return this.resultsAnalyzer.checkSignificance(experimentId);
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createPricingOptimizer(
  config: Partial<PricingOptimizerConfig> & { supabaseUrl: string; supabaseKey: string }
): PricingOptimizer {
  return new PricingOptimizer(config);
}

// =============================================================================
// EXPORTS
// =============================================================================

// Re-export types
export * from './types.js';

// Re-export sub-modules
export { createPriceTracker, PriceTracker } from './competitor-monitor/price-tracker.js';
export { createPriceAlertService, PriceAlertService } from './competitor-monitor/alert-service.js';
export { createCompetitorScraper, CompetitorScraper } from './competitor-monitor/scraper.js';
export { createElasticityCalculator, ElasticityCalculator } from './demand-analysis/elasticity-calculator.js';
export { createSeasonalityDetector, SeasonalityDetector } from './demand-analysis/seasonality-detector.js';
export { createConversionAnalyzer, ConversionAnalyzer } from './demand-analysis/conversion-analyzer.js';
export { createPriceCalculator, PriceCalculator } from './optimization/price-calculator.js';
export { createMarginProtector, MarginProtector } from './optimization/margin-protector.js';
export { createPricingRuleEngine, PricingRuleEngine } from './optimization/rule-engine.js';
export { createExperimentManager, ExperimentManager } from './ab-testing/experiment-manager.js';
export { createResultsAnalyzer, ResultsAnalyzer } from './ab-testing/results-analyzer.js';
