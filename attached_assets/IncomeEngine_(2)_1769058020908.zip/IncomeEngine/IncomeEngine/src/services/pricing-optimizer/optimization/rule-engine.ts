/**
 * ============================================================================
 * PRICING RULE ENGINE
 * Define and execute custom pricing rules
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  PricingRule,
  PricingCondition,
  PricingAction,
  DBPricingRule,
  ProductPricing,
} from '../types.js';

// =============================================================================
// RULE CONTEXT
// =============================================================================

export interface RuleContext {
  product: ProductPricing;
  currentPrice: number;
  costPrice: number;
  competitorPrices?: number[];
  averageCompetitorPrice?: number;
  lowestCompetitorPrice?: number;
  elasticity?: number;
  demandFactor?: number;
  seasonalFactor?: number;
  inventoryLevel?: number;
  daysInStock?: number;
  currentMargin?: number;
  conversionRate?: number;
  timestamp: Date;
}

export interface RuleResult {
  ruleId: string;
  ruleName: string;
  matched: boolean;
  action?: PricingAction;
  newPrice?: number;
  reason?: string;
}

// =============================================================================
// RULE ENGINE CLASS
// =============================================================================

export class PricingRuleEngine {
  private readonly supabase: SupabaseClient;
  private rulesCache: PricingRule[] = [];
  private lastCacheUpdate: Date | null = null;
  private readonly cacheValidityMs: number;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options?: {
      cacheValidityMs?: number;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.cacheValidityMs = options?.cacheValidityMs ?? 5 * 60 * 1000; // 5 minutes
  }

  // ===========================================================================
  // RULE MANAGEMENT
  // ===========================================================================

  /**
   * Create a new pricing rule
   */
  async createRule(rule: Omit<PricingRule, 'id' | 'createdAt' | 'updatedAt'>): Promise<PricingRule> {
    const { data, error } = await this.supabase
      .from('pricing_rules')
      .insert({
        name: rule.name,
        description: rule.description,
        condition: rule.condition,
        action: rule.action,
        priority: rule.priority,
        is_enabled: rule.isEnabled,
        applies_to: rule.appliesTo,
        schedule: rule.schedule ?? null,
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create rule: ${error.message}`);
    }

    // Invalidate cache
    this.lastCacheUpdate = null;

    return this.mapDBRule(data);
  }

  /**
   * Update an existing rule
   */
  async updateRule(
    ruleId: string,
    updates: Partial<Omit<PricingRule, 'id' | 'createdAt' | 'updatedAt'>>
  ): Promise<PricingRule> {
    const dbUpdates: Partial<DBPricingRule> = {};

    if (updates.name !== undefined) dbUpdates.name = updates.name;
    if (updates.description !== undefined) dbUpdates.description = updates.description;
    if (updates.condition !== undefined) dbUpdates.condition = updates.condition;
    if (updates.action !== undefined) dbUpdates.action = updates.action;
    if (updates.priority !== undefined) dbUpdates.priority = updates.priority;
    if (updates.isEnabled !== undefined) dbUpdates.is_enabled = updates.isEnabled;
    if (updates.appliesTo !== undefined) dbUpdates.applies_to = updates.appliesTo;
    if (updates.schedule !== undefined) dbUpdates.schedule = updates.schedule;

    const { data, error } = await this.supabase
      .from('pricing_rules')
      .update(dbUpdates)
      .eq('id', ruleId)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update rule: ${error.message}`);
    }

    // Invalidate cache
    this.lastCacheUpdate = null;

    return this.mapDBRule(data);
  }

  /**
   * Delete a rule
   */
  async deleteRule(ruleId: string): Promise<void> {
    const { error } = await this.supabase
      .from('pricing_rules')
      .delete()
      .eq('id', ruleId);

    if (error) {
      throw new Error(`Failed to delete rule: ${error.message}`);
    }

    // Invalidate cache
    this.lastCacheUpdate = null;
  }

  /**
   * Get all rules
   */
  async getRules(options?: { enabledOnly?: boolean }): Promise<PricingRule[]> {
    let query = this.supabase
      .from('pricing_rules')
      .select('*')
      .order('priority', { ascending: false });

    if (options?.enabledOnly) {
      query = query.eq('is_enabled', true);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get rules: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBRule(row));
  }

  /**
   * Get a single rule by ID
   */
  async getRule(ruleId: string): Promise<PricingRule | null> {
    const { data, error } = await this.supabase
      .from('pricing_rules')
      .select('*')
      .eq('id', ruleId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw new Error(`Failed to get rule: ${error.message}`);
    }

    return this.mapDBRule(data);
  }

  /**
   * Enable/disable a rule
   */
  async setRuleEnabled(ruleId: string, enabled: boolean): Promise<void> {
    const { error } = await this.supabase
      .from('pricing_rules')
      .update({ is_enabled: enabled })
      .eq('id', ruleId);

    if (error) {
      throw new Error(`Failed to update rule: ${error.message}`);
    }

    // Invalidate cache
    this.lastCacheUpdate = null;
  }

  // ===========================================================================
  // RULE EXECUTION
  // ===========================================================================

  /**
   * Evaluate all applicable rules for a product
   */
  async evaluateRules(context: RuleContext): Promise<{
    appliedRules: RuleResult[];
    finalPrice: number;
    priceChanged: boolean;
  }> {
    const rules = await this.getActiveRules();
    const applicableRules = this.filterApplicableRules(rules, context);
    const now = context.timestamp;

    const appliedRules: RuleResult[] = [];
    let currentPrice = context.currentPrice;

    // Sort by priority (highest first)
    applicableRules.sort((a, b) => b.priority - a.priority);

    for (const rule of applicableRules) {
      // Check schedule
      if (!this.isRuleScheduleActive(rule, now)) {
        continue;
      }

      // Evaluate condition
      const matched = this.evaluateCondition(rule.condition, context, currentPrice);

      if (matched) {
        // Apply action
        const newPrice = this.applyAction(rule.action, context, currentPrice);

        appliedRules.push({
          ruleId: rule.id,
          ruleName: rule.name,
          matched: true,
          action: rule.action,
          newPrice,
          reason: `Rule "${rule.name}" matched and applied`,
        });

        currentPrice = newPrice;
      } else {
        appliedRules.push({
          ruleId: rule.id,
          ruleName: rule.name,
          matched: false,
          reason: `Rule "${rule.name}" condition not met`,
        });
      }
    }

    return {
      appliedRules,
      finalPrice: Math.round(currentPrice * 100) / 100,
      priceChanged: currentPrice !== context.currentPrice,
    };
  }

  /**
   * Evaluate a single rule
   */
  evaluateRule(rule: PricingRule, context: RuleContext): RuleResult {
    const matched = this.evaluateCondition(rule.condition, context, context.currentPrice);

    if (matched) {
      const newPrice = this.applyAction(rule.action, context, context.currentPrice);
      return {
        ruleId: rule.id,
        ruleName: rule.name,
        matched: true,
        action: rule.action,
        newPrice,
        reason: `Condition met: ${this.describeCondition(rule.condition)}`,
      };
    }

    return {
      ruleId: rule.id,
      ruleName: rule.name,
      matched: false,
      reason: `Condition not met: ${this.describeCondition(rule.condition)}`,
    };
  }

  /**
   * Preview rule effect without applying
   */
  previewRule(
    rule: Omit<PricingRule, 'id' | 'createdAt' | 'updatedAt'>,
    context: RuleContext
  ): RuleResult {
    const matched = this.evaluateCondition(rule.condition, context, context.currentPrice);

    if (matched) {
      const newPrice = this.applyAction(rule.action, context, context.currentPrice);
      return {
        ruleId: 'preview',
        ruleName: rule.name,
        matched: true,
        action: rule.action,
        newPrice,
        reason: 'Preview: rule would apply',
      };
    }

    return {
      ruleId: 'preview',
      ruleName: rule.name,
      matched: false,
      reason: 'Preview: condition not met',
    };
  }

  // ===========================================================================
  // CONDITION EVALUATION
  // ===========================================================================

  private evaluateCondition(
    condition: PricingCondition,
    context: RuleContext,
    currentPrice: number
  ): boolean {
    if (condition.type === 'composite' && condition.children) {
      const results = condition.children.map((child) =>
        this.evaluateCondition(child, context, currentPrice)
      );

      if (condition.logicalOperator === 'or') {
        return results.some(Boolean);
      }
      return results.every(Boolean);
    }

    const value = this.getConditionValue(condition, context, currentPrice);

    return this.compareValues(value, condition.operator, condition.value);
  }

  private getConditionValue(
    condition: PricingCondition,
    context: RuleContext,
    currentPrice: number
  ): number | string {
    switch (condition.type) {
      case 'competitor_price':
        switch (condition.field) {
          case 'lowest':
            return context.lowestCompetitorPrice ?? 0;
          case 'average':
            return context.averageCompetitorPrice ?? 0;
          case 'diff_percent':
            if (!context.lowestCompetitorPrice) return 0;
            return ((currentPrice - context.lowestCompetitorPrice) / context.lowestCompetitorPrice) * 100;
          default:
            return context.lowestCompetitorPrice ?? 0;
        }

      case 'demand':
        switch (condition.field) {
          case 'elasticity':
            return context.elasticity ?? 0;
          case 'factor':
            return context.demandFactor ?? 1;
          case 'seasonal':
            return context.seasonalFactor ?? 1;
          default:
            return context.demandFactor ?? 1;
        }

      case 'inventory':
        switch (condition.field) {
          case 'level':
            return context.inventoryLevel ?? 0;
          case 'days_in_stock':
            return context.daysInStock ?? 0;
          default:
            return context.inventoryLevel ?? 0;
        }

      case 'time':
        const now = context.timestamp;
        switch (condition.field) {
          case 'hour':
            return now.getHours();
          case 'day_of_week':
            return now.getDay();
          case 'day_of_month':
            return now.getDate();
          case 'month':
            return now.getMonth() + 1;
          default:
            return now.getHours();
        }

      case 'margin':
        return context.currentMargin ?? 0;

      default:
        return 0;
    }
  }

  private compareValues(
    actual: number | string,
    operator: PricingCondition['operator'],
    expected: number | string | readonly (number | string)[]
  ): boolean {
    const numActual = typeof actual === 'string' ? parseFloat(actual) : actual;

    switch (operator) {
      case 'gt':
        return numActual > (expected as number);
      case 'gte':
        return numActual >= (expected as number);
      case 'lt':
        return numActual < (expected as number);
      case 'lte':
        return numActual <= (expected as number);
      case 'eq':
        return actual === expected;
      case 'between':
        const [min, max] = expected as number[];
        return numActual >= min && numActual <= max;
      case 'in':
        return (expected as readonly (number | string)[]).includes(actual);
      default:
        return false;
    }
  }

  // ===========================================================================
  // ACTION APPLICATION
  // ===========================================================================

  private applyAction(
    action: PricingAction,
    context: RuleContext,
    currentPrice: number
  ): number {
    let newPrice: number;

    switch (action.type) {
      case 'set_price':
        newPrice = action.value;
        break;

      case 'adjust_percent':
        newPrice = currentPrice * (1 + action.value / 100);
        break;

      case 'adjust_amount':
        newPrice = currentPrice + action.value;
        break;

      case 'match_competitor':
        newPrice = context.lowestCompetitorPrice ?? currentPrice;
        break;

      case 'beat_competitor':
        const competitorPrice = context.lowestCompetitorPrice ?? currentPrice;
        newPrice = competitorPrice * (1 - action.value / 100);
        break;

      default:
        newPrice = currentPrice;
    }

    // Apply constraints
    if (action.constraints) {
      if (action.constraints.minPrice !== undefined) {
        newPrice = Math.max(newPrice, action.constraints.minPrice);
      }
      if (action.constraints.maxPrice !== undefined) {
        newPrice = Math.min(newPrice, action.constraints.maxPrice);
      }
      if (action.constraints.maxChange !== undefined) {
        const maxChange = currentPrice * (action.constraints.maxChange / 100);
        const change = newPrice - currentPrice;
        if (Math.abs(change) > maxChange) {
          newPrice = currentPrice + (change > 0 ? maxChange : -maxChange);
        }
      }
      if (action.constraints.minMargin !== undefined && context.costPrice > 0) {
        const minPrice = context.costPrice / (1 - action.constraints.minMargin / 100);
        newPrice = Math.max(newPrice, minPrice);
      }
    }

    return Math.round(newPrice * 100) / 100;
  }

  // ===========================================================================
  // HELPER METHODS
  // ===========================================================================

  private async getActiveRules(): Promise<PricingRule[]> {
    // Check cache validity
    if (
      this.lastCacheUpdate &&
      Date.now() - this.lastCacheUpdate.getTime() < this.cacheValidityMs
    ) {
      return this.rulesCache;
    }

    // Refresh cache
    const rules = await this.getRules({ enabledOnly: true });
    this.rulesCache = rules;
    this.lastCacheUpdate = new Date();

    return rules;
  }

  private filterApplicableRules(rules: PricingRule[], context: RuleContext): PricingRule[] {
    return rules.filter((rule) => {
      const appliesTo = rule.appliesTo;

      // Check platform filter
      if (appliesTo.platforms && appliesTo.platforms.length > 0) {
        if (!appliesTo.platforms.includes(context.product.platform)) {
          return false;
        }
      }

      // Check category filter
      if (appliesTo.categories && appliesTo.categories.length > 0) {
        if (!appliesTo.categories.includes(context.product.category)) {
          return false;
        }
      }

      // Check product ID filter
      if (appliesTo.productIds && appliesTo.productIds.length > 0) {
        if (!appliesTo.productIds.includes(context.product.productId)) {
          return false;
        }
      }

      // Check tags filter
      if (appliesTo.tags && appliesTo.tags.length > 0) {
        const productTags = context.product.tags;
        if (!appliesTo.tags.some((tag) => productTags.includes(tag))) {
          return false;
        }
      }

      return true;
    });
  }

  private isRuleScheduleActive(rule: PricingRule, now: Date): boolean {
    if (!rule.schedule) return true;

    const schedule = rule.schedule;

    // Check date range
    if (schedule.startDate && now < new Date(schedule.startDate)) {
      return false;
    }
    if (schedule.endDate && now > new Date(schedule.endDate)) {
      return false;
    }

    // Check day of week
    if (schedule.daysOfWeek && schedule.daysOfWeek.length > 0) {
      if (!schedule.daysOfWeek.includes(now.getDay())) {
        return false;
      }
    }

    // Check hour of day
    if (schedule.hoursOfDay && schedule.hoursOfDay.length > 0) {
      if (!schedule.hoursOfDay.includes(now.getHours())) {
        return false;
      }
    }

    return true;
  }

  private describeCondition(condition: PricingCondition): string {
    if (condition.type === 'composite' && condition.children) {
      const descriptions = condition.children.map((c) => this.describeCondition(c));
      return `(${descriptions.join(` ${condition.logicalOperator ?? 'and'} `)})`;
    }

    const operatorMap: Record<string, string> = {
      gt: '>',
      gte: '>=',
      lt: '<',
      lte: '<=',
      eq: '=',
      between: 'between',
      in: 'in',
    };

    return `${condition.type}.${condition.field ?? 'value'} ${operatorMap[condition.operator]} ${JSON.stringify(condition.value)}`;
  }

  private mapDBRule(row: DBPricingRule): PricingRule {
    return {
      id: row.id,
      name: row.name,
      description: row.description,
      condition: row.condition,
      action: row.action,
      priority: row.priority,
      isEnabled: row.is_enabled,
      appliesTo: row.applies_to,
      schedule: row.schedule ?? undefined,
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at),
    };
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createPricingRuleEngine(
  supabaseUrl: string,
  supabaseKey: string,
  options?: {
    cacheValidityMs?: number;
  }
): PricingRuleEngine {
  return new PricingRuleEngine(supabaseUrl, supabaseKey, options);
}
