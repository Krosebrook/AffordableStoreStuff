/**
 * ============================================================================
 * MARGIN PROTECTOR
 * Ensure pricing maintains minimum profit margins
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { MarginProtection, ProductPricing } from '../types.js';

// =============================================================================
// MARGIN CONFIGURATION
// =============================================================================

export interface MarginConfig {
  /** Default minimum margin percentage (0-1) */
  defaultMinMargin: number;
  /** Category-specific minimum margins */
  categoryMargins?: Record<string, number>;
  /** Platform-specific minimum margins */
  platformMargins?: Record<string, number>;
  /** Minimum absolute profit per unit in currency */
  minAbsoluteProfit?: number;
  /** Enable alerts when margin drops below threshold */
  alertsEnabled?: boolean;
  /** Threshold for low margin alerts (as ratio of minMargin) */
  alertThreshold?: number;
}

const DEFAULT_CONFIG: Required<MarginConfig> = {
  defaultMinMargin: 0.3, // 30%
  categoryMargins: {},
  platformMargins: {},
  minAbsoluteProfit: 1.0,
  alertsEnabled: true,
  alertThreshold: 1.2, // Alert when margin is within 20% of minimum
};

// =============================================================================
// MARGIN PROTECTOR CLASS
// =============================================================================

export class MarginProtector {
  private readonly supabase: SupabaseClient;
  private readonly config: Required<MarginConfig>;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    config?: MarginConfig
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Check if a price maintains minimum margin
   */
  checkMargin(
    proposedPrice: number,
    costPrice: number,
    options?: {
      category?: string;
      platform?: string;
    }
  ): MarginProtection & { isValid: boolean; adjustedPrice?: number } {
    const minMargin = this.getMinimumMargin(options?.category, options?.platform);
    const margin = this.calculateMargin(proposedPrice, costPrice);
    const minimumPrice = this.calculateMinimumPrice(costPrice, minMargin);

    const isValid = proposedPrice >= minimumPrice;

    return {
      productId: '',
      costPrice,
      minimumMargin: Math.round(minMargin * 10000) / 100,
      minimumPrice: Math.round(minimumPrice * 100) / 100,
      currentMargin: Math.round(margin * 10000) / 100,
      isProtected: isValid,
      isValid,
      adjustedPrice: isValid ? undefined : Math.round(minimumPrice * 100) / 100,
    };
  }

  /**
   * Calculate margin protection for a product
   */
  async getMarginProtection(productId: string): Promise<MarginProtection> {
    const product = await this.getProductPricing(productId);

    if (!product) {
      throw new Error(`Product not found: ${productId}`);
    }

    const minMargin = this.getMinimumMargin(product.category, product.platform);
    const margin = this.calculateMargin(product.currentPrice, product.costPrice);
    const minimumPrice = this.calculateMinimumPrice(product.costPrice, minMargin);

    return {
      productId,
      costPrice: product.costPrice,
      minimumMargin: Math.round(minMargin * 10000) / 100,
      minimumPrice: Math.round(minimumPrice * 100) / 100,
      currentMargin: Math.round(margin * 10000) / 100,
      isProtected: product.currentPrice >= minimumPrice,
    };
  }

  /**
   * Enforce margin protection on a proposed price
   */
  enforceMargin(
    proposedPrice: number,
    costPrice: number,
    options?: {
      category?: string;
      platform?: string;
      allowOverride?: boolean;
    }
  ): {
    finalPrice: number;
    wasAdjusted: boolean;
    originalPrice: number;
    margin: number;
    minimumMargin: number;
  } {
    const minMargin = this.getMinimumMargin(options?.category, options?.platform);
    const minimumPrice = this.calculateMinimumPrice(costPrice, minMargin);

    let finalPrice = proposedPrice;
    let wasAdjusted = false;

    if (proposedPrice < minimumPrice && !options?.allowOverride) {
      finalPrice = minimumPrice;
      wasAdjusted = true;
    }

    const margin = this.calculateMargin(finalPrice, costPrice);

    return {
      finalPrice: Math.round(finalPrice * 100) / 100,
      wasAdjusted,
      originalPrice: Math.round(proposedPrice * 100) / 100,
      margin: Math.round(margin * 10000) / 100,
      minimumMargin: Math.round(minMargin * 10000) / 100,
    };
  }

  /**
   * Find products with margin below threshold
   */
  async findLowMarginProducts(options?: {
    category?: string;
    platform?: string;
    limit?: number;
  }): Promise<Array<ProductPricing & { margin: number; minimumMargin: number; gap: number }>> {
    let query = this.supabase
      .from('products')
      .select('id, sku, current_price, cost_price, category, platform, created_at, updated_at')
      .gt('current_price', 0)
      .gt('cost_price', 0);

    if (options?.category) {
      query = query.eq('category', options.category);
    }
    if (options?.platform) {
      query = query.eq('platform', options.platform);
    }
    if (options?.limit) {
      query = query.limit(options.limit);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get products: ${error.message}`);
    }

    const lowMarginProducts: Array<ProductPricing & { margin: number; minimumMargin: number; gap: number }> = [];

    for (const row of data ?? []) {
      const minMargin = this.getMinimumMargin(row.category, row.platform);
      const margin = this.calculateMargin(row.current_price, row.cost_price);

      if (margin < minMargin * this.config.alertThreshold) {
        lowMarginProducts.push({
          productId: row.id,
          sku: row.sku,
          currentPrice: row.current_price,
          costPrice: row.cost_price,
          currency: 'USD',
          platform: row.platform,
          category: row.category,
          tags: [],
          createdAt: new Date(row.created_at),
          updatedAt: new Date(row.updated_at),
          margin: Math.round(margin * 10000) / 100,
          minimumMargin: Math.round(minMargin * 10000) / 100,
          gap: Math.round((minMargin - margin) * 10000) / 100,
        });
      }
    }

    // Sort by gap (most urgent first)
    lowMarginProducts.sort((a, b) => b.gap - a.gap);

    return lowMarginProducts;
  }

  /**
   * Bulk validate prices against margin requirements
   */
  async bulkValidate(
    items: Array<{
      productId: string;
      proposedPrice: number;
      costPrice: number;
      category?: string;
      platform?: string;
    }>
  ): Promise<Array<{
    productId: string;
    isValid: boolean;
    proposedPrice: number;
    minimumPrice: number;
    margin: number;
    minimumMargin: number;
  }>> {
    return items.map((item) => {
      const minMargin = this.getMinimumMargin(item.category, item.platform);
      const margin = this.calculateMargin(item.proposedPrice, item.costPrice);
      const minimumPrice = this.calculateMinimumPrice(item.costPrice, minMargin);

      return {
        productId: item.productId,
        isValid: item.proposedPrice >= minimumPrice,
        proposedPrice: Math.round(item.proposedPrice * 100) / 100,
        minimumPrice: Math.round(minimumPrice * 100) / 100,
        margin: Math.round(margin * 10000) / 100,
        minimumMargin: Math.round(minMargin * 10000) / 100,
      };
    });
  }

  /**
   * Calculate price for target margin
   */
  calculatePriceForMargin(costPrice: number, targetMargin: number): number {
    // Margin = (Price - Cost) / Price
    // Price * Margin = Price - Cost
    // Price * Margin - Price = -Cost
    // Price * (Margin - 1) = -Cost
    // Price = Cost / (1 - Margin)
    return Math.round((costPrice / (1 - targetMargin)) * 100) / 100;
  }

  /**
   * Calculate breakeven price
   */
  calculateBreakevenPrice(costPrice: number): number {
    return Math.round(costPrice * 100) / 100;
  }

  /**
   * Get margin statistics for products
   */
  async getMarginStatistics(options?: {
    category?: string;
    platform?: string;
  }): Promise<{
    averageMargin: number;
    medianMargin: number;
    minMargin: number;
    maxMargin: number;
    productsBelow: number;
    productsAbove: number;
    totalProducts: number;
  }> {
    let query = this.supabase
      .from('products')
      .select('id, current_price, cost_price, category, platform')
      .gt('current_price', 0)
      .gt('cost_price', 0);

    if (options?.category) {
      query = query.eq('category', options.category);
    }
    if (options?.platform) {
      query = query.eq('platform', options.platform);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get products: ${error.message}`);
    }

    if (!data || data.length === 0) {
      return {
        averageMargin: 0,
        medianMargin: 0,
        minMargin: 0,
        maxMargin: 0,
        productsBelow: 0,
        productsAbove: 0,
        totalProducts: 0,
      };
    }

    const margins = data.map((row) => ({
      margin: this.calculateMargin(row.current_price, row.cost_price),
      minMargin: this.getMinimumMargin(row.category, row.platform),
    }));

    const marginValues = margins.map((m) => m.margin);
    marginValues.sort((a, b) => a - b);

    const productsBelow = margins.filter((m) => m.margin < m.minMargin).length;
    const productsAbove = margins.filter((m) => m.margin >= m.minMargin).length;

    return {
      averageMargin: Math.round((marginValues.reduce((a, b) => a + b, 0) / marginValues.length) * 10000) / 100,
      medianMargin: Math.round(marginValues[Math.floor(marginValues.length / 2)] * 10000) / 100,
      minMargin: Math.round(Math.min(...marginValues) * 10000) / 100,
      maxMargin: Math.round(Math.max(...marginValues) * 10000) / 100,
      productsBelow,
      productsAbove,
      totalProducts: data.length,
    };
  }

  // ===========================================================================
  // CONFIGURATION METHODS
  // ===========================================================================

  /**
   * Update margin configuration
   */
  updateConfig(updates: Partial<MarginConfig>): void {
    Object.assign(this.config, updates);
  }

  /**
   * Set category-specific margin
   */
  setCategoryMargin(category: string, minMargin: number): void {
    this.config.categoryMargins[category] = minMargin;
  }

  /**
   * Set platform-specific margin
   */
  setPlatformMargin(platform: string, minMargin: number): void {
    this.config.platformMargins[platform] = minMargin;
  }

  /**
   * Get current configuration
   */
  getConfig(): Required<MarginConfig> {
    return { ...this.config };
  }

  // ===========================================================================
  // HELPER METHODS
  // ===========================================================================

  private getMinimumMargin(category?: string, platform?: string): number {
    // Check category-specific margin first
    if (category && this.config.categoryMargins[category] !== undefined) {
      return this.config.categoryMargins[category];
    }

    // Then check platform-specific margin
    if (platform && this.config.platformMargins[platform] !== undefined) {
      return this.config.platformMargins[platform];
    }

    // Fall back to default
    return this.config.defaultMinMargin;
  }

  private calculateMargin(price: number, cost: number): number {
    if (price <= 0) return 0;
    return (price - cost) / price;
  }

  private calculateMinimumPrice(costPrice: number, minMargin: number): number {
    const marginBasedPrice = costPrice / (1 - minMargin);
    const absoluteProfitPrice = costPrice + this.config.minAbsoluteProfit;
    return Math.max(marginBasedPrice, absoluteProfitPrice);
  }

  private async getProductPricing(productId: string): Promise<ProductPricing | null> {
    const { data, error } = await this.supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw new Error(`Failed to get product: ${error.message}`);
    }

    return {
      productId: data.id,
      sku: data.sku,
      currentPrice: data.current_price,
      costPrice: data.cost_price,
      currency: data.currency ?? 'USD',
      platform: data.platform,
      category: data.category,
      tags: data.tags ?? [],
      createdAt: new Date(data.created_at),
      updatedAt: new Date(data.updated_at),
    };
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createMarginProtector(
  supabaseUrl: string,
  supabaseKey: string,
  config?: MarginConfig
): MarginProtector {
  return new MarginProtector(supabaseUrl, supabaseKey, config);
}
