/**
 * ============================================================================
 * PRICE CALCULATOR
 * Calculate optimal prices using multiple factors
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  PriceRecommendation,
  PricingFactor,
  ProjectedImpact,
  ProductPricing,
  ElasticityResult,
  SeasonalPattern,
  ConversionAnalysis,
} from '../types.js';
import { createMarginProtector, MarginProtector } from './margin-protector.js';
import { createPricingRuleEngine, PricingRuleEngine, RuleContext } from './rule-engine.js';
import { createElasticityCalculator, ElasticityCalculator } from '../demand-analysis/elasticity-calculator.js';
import { createSeasonalityDetector, SeasonalityDetector } from '../demand-analysis/seasonality-detector.js';
import { createConversionAnalyzer, ConversionAnalyzer } from '../demand-analysis/conversion-analyzer.js';

// =============================================================================
// CALCULATOR CONFIGURATION
// =============================================================================

export interface PriceCalculatorConfig {
  /** Weight for competitor pricing factor (0-1) */
  competitorWeight: number;
  /** Weight for demand/elasticity factor (0-1) */
  demandWeight: number;
  /** Weight for seasonality factor (0-1) */
  seasonalityWeight: number;
  /** Weight for conversion optimization factor (0-1) */
  conversionWeight: number;
  /** Weight for margin protection factor (0-1) */
  marginWeight: number;
  /** Hours until recommendation expires */
  recommendationTTLHours: number;
  /** Minimum confidence threshold for recommendations */
  minConfidenceThreshold: number;
}

const DEFAULT_CONFIG: PriceCalculatorConfig = {
  competitorWeight: 0.25,
  demandWeight: 0.2,
  seasonalityWeight: 0.15,
  conversionWeight: 0.25,
  marginWeight: 0.15,
  recommendationTTLHours: 24,
  minConfidenceThreshold: 0.5,
};

// =============================================================================
// PRICE CALCULATOR CLASS
// =============================================================================

export class PriceCalculator {
  private readonly supabase: SupabaseClient;
  private readonly config: PriceCalculatorConfig;
  private readonly marginProtector: MarginProtector;
  private readonly ruleEngine: PricingRuleEngine;
  private readonly elasticityCalculator: ElasticityCalculator;
  private readonly seasonalityDetector: SeasonalityDetector;
  private readonly conversionAnalyzer: ConversionAnalyzer;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    config?: Partial<PriceCalculatorConfig>
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.config = { ...DEFAULT_CONFIG, ...config };

    this.marginProtector = createMarginProtector(supabaseUrl, supabaseKey);
    this.ruleEngine = createPricingRuleEngine(supabaseUrl, supabaseKey);
    this.elasticityCalculator = createElasticityCalculator(supabaseUrl, supabaseKey);
    this.seasonalityDetector = createSeasonalityDetector(supabaseUrl, supabaseKey);
    this.conversionAnalyzer = createConversionAnalyzer(supabaseUrl, supabaseKey);
  }

  /**
   * Calculate optimal price recommendation for a product
   */
  async calculateOptimalPrice(
    productId: string,
    options?: {
      competitorPrices?: number[];
      forceRecalculate?: boolean;
    }
  ): Promise<PriceRecommendation> {
    // Get product data
    const product = await this.getProductPricing(productId);
    if (!product) {
      throw new Error(`Product not found: ${productId}`);
    }

    // Check for cached recommendation
    if (!options?.forceRecalculate) {
      const cached = await this.getCachedRecommendation(productId);
      if (cached) {
        return cached;
      }
    }

    // Gather analysis data
    const [elasticity, seasonalPatterns, conversionAnalysis, competitorData] =
      await Promise.all([
        this.getElasticity(productId),
        this.getSeasonality(productId),
        this.getConversionAnalysis(productId),
        this.getCompetitorData(productId, options?.competitorPrices),
      ]);

    // Calculate pricing factors
    const factors: PricingFactor[] = [];
    let basePrice = product.currentPrice;
    const now = new Date();

    // 1. Competitor factor
    if (competitorData.hasData) {
      const competitorFactor = this.calculateCompetitorFactor(
        product.currentPrice,
        competitorData.lowestPrice,
        competitorData.averagePrice
      );
      factors.push(competitorFactor);
      basePrice = this.applyFactor(basePrice, competitorFactor, this.config.competitorWeight);
    }

    // 2. Demand/Elasticity factor
    if (elasticity && elasticity.confidence > 0.3) {
      const demandFactor = this.calculateDemandFactor(elasticity);
      factors.push(demandFactor);
      basePrice = this.applyFactor(basePrice, demandFactor, this.config.demandWeight);
    }

    // 3. Seasonality factor
    if (seasonalPatterns && seasonalPatterns.length > 0) {
      const seasonalFactor = await this.calculateSeasonalFactor(productId, now, seasonalPatterns);
      factors.push(seasonalFactor);
      basePrice = this.applyFactor(basePrice, seasonalFactor, this.config.seasonalityWeight);
    }

    // 4. Conversion factor
    if (conversionAnalysis && conversionAnalysis.projectedConversionRates.length > 0) {
      const conversionFactor = this.calculateConversionFactor(
        product.currentPrice,
        conversionAnalysis
      );
      factors.push(conversionFactor);
      basePrice = this.applyFactor(basePrice, conversionFactor, this.config.conversionWeight);
    }

    // 5. Apply pricing rules
    const ruleContext: RuleContext = {
      product,
      currentPrice: product.currentPrice,
      costPrice: product.costPrice,
      competitorPrices: competitorData.prices,
      averageCompetitorPrice: competitorData.averagePrice,
      lowestCompetitorPrice: competitorData.lowestPrice,
      elasticity: elasticity?.elasticity,
      seasonalFactor: factors.find((f) => f.name === 'Seasonality')?.value,
      currentMargin: ((product.currentPrice - product.costPrice) / product.currentPrice) * 100,
      timestamp: now,
    };

    const ruleResult = await this.ruleEngine.evaluateRules(ruleContext);
    const appliedRules = ruleResult.appliedRules
      .filter((r) => r.matched)
      .map((r) => r.ruleName);

    if (ruleResult.priceChanged) {
      basePrice = ruleResult.finalPrice;
    }

    // 6. Enforce margin protection
    const marginResult = this.marginProtector.enforceMargin(
      basePrice,
      product.costPrice,
      { category: product.category, platform: product.platform }
    );

    const recommendedPrice = marginResult.finalPrice;

    // Generate reasoning
    const reasoning = this.generateReasoning(factors, marginResult, appliedRules);

    // Calculate projected impact
    const projectedImpact = this.calculateProjectedImpact(
      product.currentPrice,
      recommendedPrice,
      product.costPrice,
      elasticity
    );

    // Calculate confidence
    const confidence = this.calculateConfidence(factors, elasticity, competitorData);

    const recommendation: PriceRecommendation = {
      productId,
      currentPrice: product.currentPrice,
      recommendedPrice,
      confidence,
      reasoning,
      factors,
      projectedImpact,
      appliedRules,
      createdAt: now,
      expiresAt: new Date(now.getTime() + this.config.recommendationTTLHours * 60 * 60 * 1000),
    };

    // Cache recommendation
    await this.cacheRecommendation(recommendation);

    return recommendation;
  }

  /**
   * Calculate recommendations for multiple products
   */
  async calculateBulkRecommendations(
    productIds: string[],
    options?: { concurrency?: number }
  ): Promise<Map<string, PriceRecommendation>> {
    const concurrency = options?.concurrency ?? 5;
    const results = new Map<string, PriceRecommendation>();

    for (let i = 0; i < productIds.length; i += concurrency) {
      const batch = productIds.slice(i, i + concurrency);
      const batchResults = await Promise.all(
        batch.map(async (productId) => {
          try {
            const recommendation = await this.calculateOptimalPrice(productId);
            return { productId, recommendation };
          } catch (error) {
            console.error(`Failed to calculate price for ${productId}:`, error);
            return { productId, recommendation: null };
          }
        })
      );

      for (const result of batchResults) {
        if (result.recommendation) {
          results.set(result.productId, result.recommendation);
        }
      }
    }

    return results;
  }

  /**
   * Get explanation for a price recommendation
   */
  async explainRecommendation(productId: string): Promise<{
    recommendation: PriceRecommendation | null;
    explanation: string;
    factorBreakdown: Array<{ factor: string; impact: string; weight: string }>;
  }> {
    const recommendation = await this.getCachedRecommendation(productId);

    if (!recommendation) {
      return {
        recommendation: null,
        explanation: 'No recommendation available. Run calculateOptimalPrice first.',
        factorBreakdown: [],
      };
    }

    const priceChange = recommendation.recommendedPrice - recommendation.currentPrice;
    const changePercent = ((priceChange / recommendation.currentPrice) * 100).toFixed(1);
    const direction = priceChange >= 0 ? 'increase' : 'decrease';

    const explanation = `Based on analysis, we recommend a ${direction} from $${recommendation.currentPrice.toFixed(2)} ` +
      `to $${recommendation.recommendedPrice.toFixed(2)} (${changePercent}%). ` +
      `This recommendation has ${(recommendation.confidence * 100).toFixed(0)}% confidence.`;

    const factorBreakdown = recommendation.factors.map((f) => ({
      factor: f.name,
      impact: f.contribution > 0
        ? `+${(f.contribution * 100).toFixed(1)}% price increase`
        : `${(f.contribution * 100).toFixed(1)}% price decrease`,
      weight: `${(f.weight * 100).toFixed(0)}%`,
    }));

    return {
      recommendation,
      explanation,
      factorBreakdown,
    };
  }

  // ===========================================================================
  // FACTOR CALCULATIONS
  // ===========================================================================

  private calculateCompetitorFactor(
    currentPrice: number,
    lowestCompetitorPrice: number,
    averageCompetitorPrice: number
  ): PricingFactor {
    // Target price between lowest and average competitor
    const targetPrice = (lowestCompetitorPrice + averageCompetitorPrice) / 2;
    const priceDiff = targetPrice - currentPrice;
    const contribution = priceDiff / currentPrice;

    return {
      name: 'Competitor Pricing',
      weight: this.config.competitorWeight,
      value: targetPrice,
      contribution: Math.max(-0.2, Math.min(0.2, contribution)),
      description: `Competitors range from $${lowestCompetitorPrice.toFixed(2)} to $${averageCompetitorPrice.toFixed(2)}`,
    };
  }

  private calculateDemandFactor(elasticity: ElasticityResult): PricingFactor {
    // If elastic (|e| > 1): suggest lower price
    // If inelastic (|e| < 1): suggest higher price
    const absElasticity = Math.abs(elasticity.elasticity);
    let contribution = 0;

    if (elasticity.interpretation === 'elastic') {
      // Lower price to increase volume
      contribution = -0.05 * (absElasticity - 1);
    } else if (elasticity.interpretation === 'inelastic') {
      // Raise price since demand is less sensitive
      contribution = 0.05 * (1 - absElasticity);
    }

    return {
      name: 'Demand Elasticity',
      weight: this.config.demandWeight,
      value: elasticity.elasticity,
      contribution: Math.max(-0.15, Math.min(0.15, contribution)),
      description: `Demand is ${elasticity.interpretation} (elasticity: ${elasticity.elasticity.toFixed(2)})`,
    };
  }

  private async calculateSeasonalFactor(
    productId: string,
    date: Date,
    patterns: SeasonalPattern[]
  ): Promise<PricingFactor> {
    const adjustment = await this.seasonalityDetector.getSeasonalAdjustment(productId, date);
    const contribution = (adjustment.combinedFactor - 1) * 0.5; // Dampen seasonal effect

    return {
      name: 'Seasonality',
      weight: this.config.seasonalityWeight,
      value: adjustment.combinedFactor,
      contribution: Math.max(-0.1, Math.min(0.1, contribution)),
      description: `Seasonal adjustment factor: ${adjustment.combinedFactor.toFixed(2)}`,
    };
  }

  private calculateConversionFactor(
    currentPrice: number,
    analysis: ConversionAnalysis
  ): PricingFactor {
    const optimalMid = (analysis.optimalPriceRange.min + analysis.optimalPriceRange.max) / 2;
    const priceDiff = optimalMid - currentPrice;
    const contribution = (priceDiff / currentPrice) * 0.5;

    return {
      name: 'Conversion Optimization',
      weight: this.config.conversionWeight,
      value: optimalMid,
      contribution: Math.max(-0.15, Math.min(0.15, contribution)),
      description: `Optimal conversion price range: $${analysis.optimalPriceRange.min.toFixed(2)} - $${analysis.optimalPriceRange.max.toFixed(2)}`,
    };
  }

  private applyFactor(basePrice: number, factor: PricingFactor, weight: number): number {
    return basePrice * (1 + factor.contribution * weight);
  }

  // ===========================================================================
  // PROJECTED IMPACT
  // ===========================================================================

  private calculateProjectedImpact(
    currentPrice: number,
    recommendedPrice: number,
    costPrice: number,
    elasticity: ElasticityResult | null
  ): ProjectedImpact {
    const priceChangePercent = (recommendedPrice - currentPrice) / currentPrice;

    // Estimate volume change based on elasticity
    let volumeChangePercent = 0;
    if (elasticity && elasticity.confidence > 0.3) {
      volumeChangePercent = -elasticity.elasticity * priceChangePercent;
    } else {
      // Default assumption: -1 elasticity
      volumeChangePercent = -priceChangePercent;
    }

    // Calculate revenue change
    const revenueChangePercent = (1 + priceChangePercent) * (1 + volumeChangePercent) - 1;

    // Calculate margin changes
    const currentMargin = (currentPrice - costPrice) / currentPrice;
    const newMargin = (recommendedPrice - costPrice) / recommendedPrice;
    const marginChangePercent = (newMargin - currentMargin) / currentMargin;

    return {
      revenueChange: 0, // Would need actual volume data
      revenueChangePercent: Math.round(revenueChangePercent * 10000) / 100,
      marginChange: Math.round((newMargin - currentMargin) * 10000) / 100,
      marginChangePercent: Math.round(marginChangePercent * 10000) / 100,
      volumeChange: 0, // Would need actual volume data
      volumeChangePercent: Math.round(volumeChangePercent * 10000) / 100,
    };
  }

  // ===========================================================================
  // CONFIDENCE CALCULATION
  // ===========================================================================

  private calculateConfidence(
    factors: PricingFactor[],
    elasticity: ElasticityResult | null,
    competitorData: { hasData: boolean; count: number }
  ): number {
    let confidence = 0.5; // Base confidence

    // Factor coverage bonus
    if (factors.length >= 3) confidence += 0.1;
    if (factors.length >= 4) confidence += 0.1;

    // Elasticity confidence bonus
    if (elasticity && elasticity.confidence > 0.5) {
      confidence += 0.1;
    }

    // Competitor data bonus
    if (competitorData.hasData) {
      confidence += Math.min(competitorData.count / 10, 0.1);
    }

    return Math.min(1, Math.round(confidence * 100) / 100);
  }

  // ===========================================================================
  // REASONING GENERATION
  // ===========================================================================

  private generateReasoning(
    factors: PricingFactor[],
    marginResult: { wasAdjusted: boolean; margin: number },
    appliedRules: string[]
  ): readonly string[] {
    const reasoning: string[] = [];

    // Add factor-based reasoning
    for (const factor of factors) {
      if (Math.abs(factor.contribution) > 0.01) {
        reasoning.push(factor.description);
      }
    }

    // Add margin adjustment reasoning
    if (marginResult.wasAdjusted) {
      reasoning.push(`Price adjusted to maintain minimum margin of ${marginResult.margin.toFixed(1)}%`);
    }

    // Add rule-based reasoning
    if (appliedRules.length > 0) {
      reasoning.push(`Applied pricing rules: ${appliedRules.join(', ')}`);
    }

    return reasoning;
  }

  // ===========================================================================
  // DATA FETCHING
  // ===========================================================================

  private async getProductPricing(productId: string): Promise<ProductPricing | null> {
    const { data, error } = await this.supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw new Error(`Failed to get product: ${error.message}`);
    }

    return {
      productId: data.id,
      sku: data.sku,
      currentPrice: data.current_price,
      costPrice: data.cost_price,
      currency: data.currency ?? 'USD',
      platform: data.platform,
      category: data.category,
      tags: data.tags ?? [],
      createdAt: new Date(data.created_at),
      updatedAt: new Date(data.updated_at),
    };
  }

  private async getElasticity(productId: string): Promise<ElasticityResult | null> {
    try {
      return await this.elasticityCalculator.calculateElasticity(productId);
    } catch {
      return null;
    }
  }

  private async getSeasonality(productId: string): Promise<SeasonalPattern[] | null> {
    try {
      return await this.seasonalityDetector.detectPatterns(productId);
    } catch {
      return null;
    }
  }

  private async getConversionAnalysis(productId: string): Promise<ConversionAnalysis | null> {
    try {
      return await this.conversionAnalyzer.analyzeConversion(productId);
    } catch {
      return null;
    }
  }

  private async getCompetitorData(
    productId: string,
    providedPrices?: number[]
  ): Promise<{
    hasData: boolean;
    prices: number[];
    lowestPrice: number;
    averagePrice: number;
    count: number;
  }> {
    if (providedPrices && providedPrices.length > 0) {
      return {
        hasData: true,
        prices: providedPrices,
        lowestPrice: Math.min(...providedPrices),
        averagePrice: providedPrices.reduce((a, b) => a + b, 0) / providedPrices.length,
        count: providedPrices.length,
      };
    }

    // Try to get from database
    const { data, error } = await this.supabase
      .from('pricing_competitor_products')
      .select('current_price')
      .eq('our_product_id', productId)
      .gt('current_price', 0);

    if (error || !data || data.length === 0) {
      return {
        hasData: false,
        prices: [],
        lowestPrice: 0,
        averagePrice: 0,
        count: 0,
      };
    }

    const prices = data.map((d) => d.current_price);
    return {
      hasData: true,
      prices,
      lowestPrice: Math.min(...prices),
      averagePrice: prices.reduce((a, b) => a + b, 0) / prices.length,
      count: prices.length,
    };
  }

  // ===========================================================================
  // CACHING
  // ===========================================================================

  private async getCachedRecommendation(
    productId: string
  ): Promise<PriceRecommendation | null> {
    const { data, error } = await this.supabase
      .from('pricing_recommendations')
      .select('*')
      .eq('product_id', productId)
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error || !data) {
      return null;
    }

    return {
      productId: data.product_id,
      currentPrice: data.current_price,
      recommendedPrice: data.recommended_price,
      confidence: data.confidence,
      reasoning: data.reasoning,
      factors: data.factors,
      projectedImpact: data.projected_impact,
      appliedRules: data.applied_rules,
      createdAt: new Date(data.created_at),
      expiresAt: new Date(data.expires_at),
    };
  }

  private async cacheRecommendation(recommendation: PriceRecommendation): Promise<void> {
    const { error } = await this.supabase.from('pricing_recommendations').upsert(
      {
        product_id: recommendation.productId,
        current_price: recommendation.currentPrice,
        recommended_price: recommendation.recommendedPrice,
        confidence: recommendation.confidence,
        reasoning: recommendation.reasoning,
        factors: recommendation.factors,
        projected_impact: recommendation.projectedImpact,
        applied_rules: recommendation.appliedRules,
        created_at: recommendation.createdAt.toISOString(),
        expires_at: recommendation.expiresAt.toISOString(),
      },
      { onConflict: 'product_id' }
    );

    if (error) {
      console.error('Failed to cache recommendation:', error);
    }
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createPriceCalculator(
  supabaseUrl: string,
  supabaseKey: string,
  config?: Partial<PriceCalculatorConfig>
): PriceCalculator {
  return new PriceCalculator(supabaseUrl, supabaseKey, config);
}
