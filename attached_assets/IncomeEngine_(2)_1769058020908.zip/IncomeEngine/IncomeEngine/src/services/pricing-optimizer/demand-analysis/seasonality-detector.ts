/**
 * ============================================================================
 * SEASONALITY DETECTOR
 * Detect and analyze seasonal patterns in sales data
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { SalesData, SeasonalPattern, SeasonalFactor } from '../types.js';

// =============================================================================
// CONSTANTS
// =============================================================================

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];
const QUARTER_NAMES = ['Q1 (Jan-Mar)', 'Q2 (Apr-Jun)', 'Q3 (Jul-Sep)', 'Q4 (Oct-Dec)'];

// =============================================================================
// SEASONALITY DETECTOR CLASS
// =============================================================================

export class SeasonalityDetector {
  private readonly supabase: SupabaseClient;
  private readonly minimumDataDays: number;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options?: {
      minimumDataDays?: number;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.minimumDataDays = options?.minimumDataDays ?? 30;
  }

  /**
   * Detect seasonal patterns for a product
   */
  async detectPatterns(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
      platform?: string;
    }
  ): Promise<SeasonalPattern[]> {
    const salesData = await this.getSalesData(productId, options);

    if (salesData.length < this.minimumDataDays) {
      return [];
    }

    const patterns: SeasonalPattern[] = [];

    // Detect weekly patterns (day-of-week)
    const weeklyPattern = this.detectWeeklyPattern(productId, salesData);
    if (weeklyPattern) {
      patterns.push(weeklyPattern);
    }

    // Detect monthly patterns (week-of-month)
    const monthlyPattern = this.detectMonthlyPattern(productId, salesData);
    if (monthlyPattern) {
      patterns.push(monthlyPattern);
    }

    // Detect quarterly patterns (month-of-quarter)
    if (salesData.length >= 90) {
      const quarterlyPattern = this.detectQuarterlyPattern(productId, salesData);
      if (quarterlyPattern) {
        patterns.push(quarterlyPattern);
      }
    }

    // Detect annual patterns (month-of-year)
    if (salesData.length >= 365) {
      const annualPattern = this.detectAnnualPattern(productId, salesData);
      if (annualPattern) {
        patterns.push(annualPattern);
      }
    }

    return patterns;
  }

  /**
   * Detect weekly (day-of-week) pattern
   */
  private detectWeeklyPattern(productId: string, salesData: SalesData[]): SeasonalPattern | null {
    const dayTotals = new Array(7).fill(0);
    const dayCounts = new Array(7).fill(0);

    for (const sale of salesData) {
      const dayOfWeek = sale.date.getDay();
      dayTotals[dayOfWeek] += sale.quantity;
      dayCounts[dayOfWeek]++;
    }

    // Calculate averages
    const dayAverages = dayTotals.map((total, i) =>
      dayCounts[i] > 0 ? total / dayCounts[i] : 0
    );

    // Calculate overall average
    const overallAverage = dayAverages.reduce((a, b) => a + b, 0) / 7;

    if (overallAverage === 0) return null;

    // Calculate seasonal factors
    const factors: SeasonalFactor[] = dayAverages.map((avg, i) => ({
      period: String(i),
      factor: avg / overallAverage,
      label: DAY_NAMES[i],
    }));

    // Identify peak and low periods
    const sortedFactors = [...factors].sort((a, b) => b.factor - a.factor);
    const peakPeriods = sortedFactors.slice(0, 2).map((f) => f.label);
    const lowPeriods = sortedFactors.slice(-2).map((f) => f.label);

    // Calculate confidence based on variation
    const variance = factors.reduce((sum, f) => sum + Math.pow(f.factor - 1, 2), 0) / factors.length;
    const confidence = Math.min(Math.sqrt(variance) * 2, 1);

    // Only return pattern if there's meaningful variation
    if (confidence < 0.1) return null;

    return {
      productId,
      patternType: 'weekly',
      factors,
      peakPeriods,
      lowPeriods,
      confidence: Math.round(confidence * 100) / 100,
      calculatedAt: new Date(),
    };
  }

  /**
   * Detect monthly (week-of-month) pattern
   */
  private detectMonthlyPattern(productId: string, salesData: SalesData[]): SeasonalPattern | null {
    const weekTotals = new Array(5).fill(0); // Week 1-5
    const weekCounts = new Array(5).fill(0);

    for (const sale of salesData) {
      const weekOfMonth = Math.min(Math.floor((sale.date.getDate() - 1) / 7), 4);
      weekTotals[weekOfMonth] += sale.quantity;
      weekCounts[weekOfMonth]++;
    }

    const weekAverages = weekTotals.map((total, i) =>
      weekCounts[i] > 0 ? total / weekCounts[i] : 0
    );

    const overallAverage = weekAverages.reduce((a, b) => a + b, 0) / 5;

    if (overallAverage === 0) return null;

    const factors: SeasonalFactor[] = weekAverages.map((avg, i) => ({
      period: String(i + 1),
      factor: avg / overallAverage,
      label: `Week ${i + 1}`,
    }));

    const sortedFactors = [...factors].sort((a, b) => b.factor - a.factor);
    const peakPeriods = sortedFactors.slice(0, 2).map((f) => f.label);
    const lowPeriods = sortedFactors.slice(-2).map((f) => f.label);

    const variance = factors.reduce((sum, f) => sum + Math.pow(f.factor - 1, 2), 0) / factors.length;
    const confidence = Math.min(Math.sqrt(variance) * 2, 1);

    if (confidence < 0.1) return null;

    return {
      productId,
      patternType: 'monthly',
      factors,
      peakPeriods,
      lowPeriods,
      confidence: Math.round(confidence * 100) / 100,
      calculatedAt: new Date(),
    };
  }

  /**
   * Detect quarterly (month-of-quarter) pattern
   */
  private detectQuarterlyPattern(productId: string, salesData: SalesData[]): SeasonalPattern | null {
    const quarterTotals = new Array(4).fill(0);
    const quarterCounts = new Array(4).fill(0);

    for (const sale of salesData) {
      const quarter = Math.floor(sale.date.getMonth() / 3);
      quarterTotals[quarter] += sale.quantity;
      quarterCounts[quarter]++;
    }

    const quarterAverages = quarterTotals.map((total, i) =>
      quarterCounts[i] > 0 ? total / quarterCounts[i] : 0
    );

    const overallAverage = quarterAverages.reduce((a, b) => a + b, 0) / 4;

    if (overallAverage === 0) return null;

    const factors: SeasonalFactor[] = quarterAverages.map((avg, i) => ({
      period: String(i + 1),
      factor: avg / overallAverage,
      label: QUARTER_NAMES[i],
    }));

    const sortedFactors = [...factors].sort((a, b) => b.factor - a.factor);
    const peakPeriods = sortedFactors.slice(0, 1).map((f) => f.label);
    const lowPeriods = sortedFactors.slice(-1).map((f) => f.label);

    const variance = factors.reduce((sum, f) => sum + Math.pow(f.factor - 1, 2), 0) / factors.length;
    const confidence = Math.min(Math.sqrt(variance) * 2, 1);

    if (confidence < 0.1) return null;

    return {
      productId,
      patternType: 'quarterly',
      factors,
      peakPeriods,
      lowPeriods,
      confidence: Math.round(confidence * 100) / 100,
      calculatedAt: new Date(),
    };
  }

  /**
   * Detect annual (month-of-year) pattern
   */
  private detectAnnualPattern(productId: string, salesData: SalesData[]): SeasonalPattern | null {
    const monthTotals = new Array(12).fill(0);
    const monthCounts = new Array(12).fill(0);

    for (const sale of salesData) {
      const month = sale.date.getMonth();
      monthTotals[month] += sale.quantity;
      monthCounts[month]++;
    }

    const monthAverages = monthTotals.map((total, i) =>
      monthCounts[i] > 0 ? total / monthCounts[i] : 0
    );

    const overallAverage = monthAverages.reduce((a, b) => a + b, 0) / 12;

    if (overallAverage === 0) return null;

    const factors: SeasonalFactor[] = monthAverages.map((avg, i) => ({
      period: String(i + 1),
      factor: avg / overallAverage,
      label: MONTH_NAMES[i],
    }));

    const sortedFactors = [...factors].sort((a, b) => b.factor - a.factor);
    const peakPeriods = sortedFactors.slice(0, 3).map((f) => f.label);
    const lowPeriods = sortedFactors.slice(-3).map((f) => f.label);

    const variance = factors.reduce((sum, f) => sum + Math.pow(f.factor - 1, 2), 0) / factors.length;
    const confidence = Math.min(Math.sqrt(variance) * 2, 1);

    if (confidence < 0.1) return null;

    return {
      productId,
      patternType: 'annual',
      factors,
      peakPeriods,
      lowPeriods,
      confidence: Math.round(confidence * 100) / 100,
      calculatedAt: new Date(),
    };
  }

  /**
   * Get seasonal adjustment factor for a specific date
   */
  async getSeasonalAdjustment(
    productId: string,
    date: Date
  ): Promise<{
    combinedFactor: number;
    factors: { type: string; factor: number }[];
  }> {
    const patterns = await this.detectPatterns(productId);

    const factors: { type: string; factor: number }[] = [];
    let combinedFactor = 1;

    for (const pattern of patterns) {
      let periodIndex: number;

      switch (pattern.patternType) {
        case 'weekly':
          periodIndex = date.getDay();
          break;
        case 'monthly':
          periodIndex = Math.min(Math.floor((date.getDate() - 1) / 7), 4);
          break;
        case 'quarterly':
          periodIndex = Math.floor(date.getMonth() / 3);
          break;
        case 'annual':
          periodIndex = date.getMonth();
          break;
        default:
          continue;
      }

      const factor = pattern.factors[periodIndex]?.factor ?? 1;
      const weightedFactor = 1 + (factor - 1) * pattern.confidence;

      factors.push({ type: pattern.patternType, factor: weightedFactor });
      combinedFactor *= weightedFactor;
    }

    return {
      combinedFactor: Math.round(combinedFactor * 1000) / 1000,
      factors,
    };
  }

  /**
   * Forecast demand for a future date
   */
  async forecastDemand(
    productId: string,
    targetDate: Date,
    options?: {
      baselineQuantity?: number;
    }
  ): Promise<{
    forecastedQuantity: number;
    baselineQuantity: number;
    adjustmentFactor: number;
    confidence: number;
  }> {
    // Get baseline if not provided
    let baselineQuantity = options?.baselineQuantity;

    if (baselineQuantity === undefined) {
      const salesData = await this.getSalesData(productId, {
        startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      });

      if (salesData.length > 0) {
        baselineQuantity = salesData.reduce((sum, s) => sum + s.quantity, 0) / salesData.length;
      } else {
        baselineQuantity = 0;
      }
    }

    const { combinedFactor, factors } = await this.getSeasonalAdjustment(productId, targetDate);

    // Calculate confidence based on pattern confidences
    const patterns = await this.detectPatterns(productId);
    const confidence = patterns.length > 0
      ? patterns.reduce((sum, p) => sum + p.confidence, 0) / patterns.length
      : 0;

    return {
      forecastedQuantity: Math.round(baselineQuantity * combinedFactor * 100) / 100,
      baselineQuantity: Math.round(baselineQuantity * 100) / 100,
      adjustmentFactor: combinedFactor,
      confidence: Math.round(confidence * 100) / 100,
    };
  }

  /**
   * Get demand forecast for a date range
   */
  async forecastDateRange(
    productId: string,
    startDate: Date,
    endDate: Date,
    options?: {
      baselineQuantity?: number;
    }
  ): Promise<Array<{ date: Date; forecastedQuantity: number; adjustmentFactor: number }>> {
    const forecasts: Array<{ date: Date; forecastedQuantity: number; adjustmentFactor: number }> = [];

    // Get baseline once
    let baselineQuantity = options?.baselineQuantity;

    if (baselineQuantity === undefined) {
      const salesData = await this.getSalesData(productId, {
        startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      });

      if (salesData.length > 0) {
        baselineQuantity = salesData.reduce((sum, s) => sum + s.quantity, 0) / salesData.length;
      } else {
        baselineQuantity = 0;
      }
    }

    // Detect patterns once
    const patterns = await this.detectPatterns(productId);

    // Generate forecasts for each day
    const currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      let combinedFactor = 1;

      for (const pattern of patterns) {
        let periodIndex: number;

        switch (pattern.patternType) {
          case 'weekly':
            periodIndex = currentDate.getDay();
            break;
          case 'monthly':
            periodIndex = Math.min(Math.floor((currentDate.getDate() - 1) / 7), 4);
            break;
          case 'quarterly':
            periodIndex = Math.floor(currentDate.getMonth() / 3);
            break;
          case 'annual':
            periodIndex = currentDate.getMonth();
            break;
          default:
            continue;
        }

        const factor = pattern.factors[periodIndex]?.factor ?? 1;
        const weightedFactor = 1 + (factor - 1) * pattern.confidence;
        combinedFactor *= weightedFactor;
      }

      forecasts.push({
        date: new Date(currentDate),
        forecastedQuantity: Math.round(baselineQuantity * combinedFactor * 100) / 100,
        adjustmentFactor: Math.round(combinedFactor * 1000) / 1000,
      });

      currentDate.setDate(currentDate.getDate() + 1);
    }

    return forecasts;
  }

  /**
   * Get sales data from database
   */
  private async getSalesData(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
      platform?: string;
    }
  ): Promise<SalesData[]> {
    const startDate = options?.startDate ?? new Date(Date.now() - 365 * 24 * 60 * 60 * 1000);
    const endDate = options?.endDate ?? new Date();

    let query = this.supabase
      .from('pricing_sales_data')
      .select('*')
      .eq('product_id', productId)
      .gte('date', startDate.toISOString())
      .lte('date', endDate.toISOString())
      .order('date', { ascending: true });

    if (options?.platform) {
      query = query.eq('platform', options.platform);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get sales data: ${error.message}`);
    }

    return (data ?? []).map((row) => ({
      productId: row.product_id,
      date: new Date(row.date),
      quantity: row.quantity,
      revenue: row.revenue,
      price: row.price,
      platform: row.platform,
    }));
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createSeasonalityDetector(
  supabaseUrl: string,
  supabaseKey: string,
  options?: {
    minimumDataDays?: number;
  }
): SeasonalityDetector {
  return new SeasonalityDetector(supabaseUrl, supabaseKey, options);
}
