/**
 * ============================================================================
 * PRICE ELASTICITY CALCULATOR
 * Calculate price elasticity of demand for products
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { SalesData, ElasticityResult } from '../types.js';

// =============================================================================
// ELASTICITY CALCULATOR CLASS
// =============================================================================

export class ElasticityCalculator {
  private readonly supabase: SupabaseClient;
  private readonly minimumDataPoints: number;
  private readonly minimumPriceVariation: number;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options?: {
      minimumDataPoints?: number;
      minimumPriceVariation?: number;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.minimumDataPoints = options?.minimumDataPoints ?? 10;
    this.minimumPriceVariation = options?.minimumPriceVariation ?? 0.05; // 5% minimum price variation
  }

  /**
   * Calculate price elasticity for a product
   */
  async calculateElasticity(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
      platform?: string;
    }
  ): Promise<ElasticityResult> {
    const salesData = await this.getSalesData(productId, options);

    if (salesData.length < this.minimumDataPoints) {
      return {
        productId,
        elasticity: 0,
        interpretation: 'inelastic',
        confidence: 0,
        sampleSize: salesData.length,
        priceRange: { min: 0, max: 0 },
        calculatedAt: new Date(),
      };
    }

    // Extract prices and quantities
    const prices = salesData.map((d) => d.price);
    const quantities = salesData.map((d) => d.quantity);

    // Calculate price range
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const priceVariation = (maxPrice - minPrice) / minPrice;

    if (priceVariation < this.minimumPriceVariation) {
      return {
        productId,
        elasticity: 0,
        interpretation: 'inelastic',
        confidence: 0,
        sampleSize: salesData.length,
        priceRange: { min: minPrice, max: maxPrice },
        calculatedAt: new Date(),
      };
    }

    // Calculate elasticity using midpoint method
    const elasticity = this.calculateMidpointElasticity(prices, quantities);

    // Calculate confidence based on data quality
    const confidence = this.calculateConfidence(salesData, priceVariation);

    // Interpret elasticity
    const interpretation = this.interpretElasticity(elasticity);

    return {
      productId,
      elasticity: Math.round(elasticity * 1000) / 1000,
      interpretation,
      confidence: Math.round(confidence * 100) / 100,
      sampleSize: salesData.length,
      priceRange: {
        min: Math.round(minPrice * 100) / 100,
        max: Math.round(maxPrice * 100) / 100,
      },
      calculatedAt: new Date(),
    };
  }

  /**
   * Calculate elasticity using the midpoint method
   */
  private calculateMidpointElasticity(prices: number[], quantities: number[]): number {
    // Group data by price buckets
    const priceBuckets = this.groupByPriceBuckets(prices, quantities, 5);

    if (priceBuckets.length < 2) {
      return 0;
    }

    // Calculate elasticity between consecutive buckets
    const elasticities: number[] = [];

    for (let i = 0; i < priceBuckets.length - 1; i++) {
      const p1 = priceBuckets[i].avgPrice;
      const p2 = priceBuckets[i + 1].avgPrice;
      const q1 = priceBuckets[i].avgQuantity;
      const q2 = priceBuckets[i + 1].avgQuantity;

      if (p1 === p2 || q1 === 0 || q2 === 0) continue;

      // Midpoint formula: (Q2-Q1)/((Q2+Q1)/2) / (P2-P1)/((P2+P1)/2)
      const percentQuantityChange = (q2 - q1) / ((q2 + q1) / 2);
      const percentPriceChange = (p2 - p1) / ((p2 + p1) / 2);

      if (percentPriceChange !== 0) {
        elasticities.push(percentQuantityChange / percentPriceChange);
      }
    }

    if (elasticities.length === 0) return 0;

    // Return weighted average elasticity
    return elasticities.reduce((a, b) => a + b, 0) / elasticities.length;
  }

  /**
   * Calculate regression-based elasticity (log-log model)
   */
  private calculateRegressionElasticity(prices: number[], quantities: number[]): number {
    // Filter out zero values for log calculation
    const validPairs = prices
      .map((p, i) => ({ price: p, quantity: quantities[i] }))
      .filter((d) => d.price > 0 && d.quantity > 0);

    if (validPairs.length < 3) return 0;

    const logPrices = validPairs.map((d) => Math.log(d.price));
    const logQuantities = validPairs.map((d) => Math.log(d.quantity));

    // Simple linear regression on log values
    const n = logPrices.length;
    const sumX = logPrices.reduce((a, b) => a + b, 0);
    const sumY = logQuantities.reduce((a, b) => a + b, 0);
    const sumXY = logPrices.reduce((sum, x, i) => sum + x * logQuantities[i], 0);
    const sumXX = logPrices.reduce((sum, x) => sum + x * x, 0);

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);

    return isNaN(slope) ? 0 : slope;
  }

  /**
   * Group data by price buckets
   */
  private groupByPriceBuckets(
    prices: number[],
    quantities: number[],
    numBuckets: number
  ): Array<{ avgPrice: number; avgQuantity: number; count: number }> {
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const bucketSize = (maxPrice - minPrice) / numBuckets;

    if (bucketSize === 0) return [];

    const buckets: Map<number, { prices: number[]; quantities: number[] }> = new Map();

    prices.forEach((price, i) => {
      const bucketIndex = Math.min(
        Math.floor((price - minPrice) / bucketSize),
        numBuckets - 1
      );
      if (!buckets.has(bucketIndex)) {
        buckets.set(bucketIndex, { prices: [], quantities: [] });
      }
      const bucket = buckets.get(bucketIndex)!;
      bucket.prices.push(price);
      bucket.quantities.push(quantities[i]);
    });

    return Array.from(buckets.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([_, bucket]) => ({
        avgPrice: bucket.prices.reduce((a, b) => a + b, 0) / bucket.prices.length,
        avgQuantity: bucket.quantities.reduce((a, b) => a + b, 0) / bucket.quantities.length,
        count: bucket.prices.length,
      }));
  }

  /**
   * Calculate confidence score
   */
  private calculateConfidence(salesData: SalesData[], priceVariation: number): number {
    let confidence = 0;

    // Data points factor (max 0.3)
    const dataPointsFactor = Math.min(salesData.length / 100, 1) * 0.3;
    confidence += dataPointsFactor;

    // Price variation factor (max 0.3)
    const variationFactor = Math.min(priceVariation / 0.5, 1) * 0.3;
    confidence += variationFactor;

    // Time coverage factor (max 0.2)
    const dates = salesData.map((d) => d.date.getTime());
    const timeRange = Math.max(...dates) - Math.min(...dates);
    const daysCovered = timeRange / (1000 * 60 * 60 * 24);
    const timeFactor = Math.min(daysCovered / 90, 1) * 0.2;
    confidence += timeFactor;

    // Data distribution factor (max 0.2)
    const prices = salesData.map((d) => d.price);
    const uniquePrices = new Set(prices).size;
    const distributionFactor = Math.min(uniquePrices / 10, 1) * 0.2;
    confidence += distributionFactor;

    return confidence;
  }

  /**
   * Interpret elasticity value
   */
  private interpretElasticity(elasticity: number): 'elastic' | 'inelastic' | 'unit_elastic' {
    const absElasticity = Math.abs(elasticity);
    if (absElasticity > 1.1) return 'elastic';
    if (absElasticity < 0.9) return 'inelastic';
    return 'unit_elastic';
  }

  /**
   * Get sales data from database
   */
  private async getSalesData(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
      platform?: string;
    }
  ): Promise<SalesData[]> {
    const startDate = options?.startDate ?? new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const endDate = options?.endDate ?? new Date();

    let query = this.supabase
      .from('pricing_sales_data')
      .select('*')
      .eq('product_id', productId)
      .gte('date', startDate.toISOString())
      .lte('date', endDate.toISOString())
      .order('date', { ascending: true });

    if (options?.platform) {
      query = query.eq('platform', options.platform);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get sales data: ${error.message}`);
    }

    return (data ?? []).map((row) => ({
      productId: row.product_id,
      date: new Date(row.date),
      quantity: row.quantity,
      revenue: row.revenue,
      price: row.price,
      platform: row.platform,
    }));
  }

  /**
   * Calculate elasticity for multiple products
   */
  async calculateBulkElasticity(
    productIds: string[],
    options?: {
      startDate?: Date;
      endDate?: Date;
    }
  ): Promise<Map<string, ElasticityResult>> {
    const results = new Map<string, ElasticityResult>();

    for (const productId of productIds) {
      try {
        const result = await this.calculateElasticity(productId, options);
        results.set(productId, result);
      } catch (error) {
        // Log error but continue with other products
        console.error(`Failed to calculate elasticity for ${productId}:`, error);
      }
    }

    return results;
  }

  /**
   * Get optimal price point based on elasticity
   */
  calculateOptimalPriceChange(
    currentPrice: number,
    elasticity: number,
    targetRevenueChange: number
  ): {
    recommendedPrice: number;
    projectedQuantityChange: number;
    projectedRevenueChange: number;
  } {
    // For revenue maximization with elastic demand (|e| > 1): lower price
    // For revenue maximization with inelastic demand (|e| < 1): raise price

    const absElasticity = Math.abs(elasticity);

    if (absElasticity < 0.1) {
      // Near zero elasticity - price changes have minimal effect
      return {
        recommendedPrice: currentPrice,
        projectedQuantityChange: 0,
        projectedRevenueChange: 0,
      };
    }

    // Calculate price change needed for target revenue change
    // Revenue = P * Q
    // dR/R = dP/P + dQ/Q
    // dQ/Q = e * dP/P
    // dR/R = dP/P + e * dP/P = dP/P * (1 + e)
    // dP/P = (dR/R) / (1 + e)

    const priceChangePercent = targetRevenueChange / (1 + elasticity);
    const recommendedPrice = currentPrice * (1 + priceChangePercent);
    const quantityChangePercent = elasticity * priceChangePercent;

    return {
      recommendedPrice: Math.round(recommendedPrice * 100) / 100,
      projectedQuantityChange: Math.round(quantityChangePercent * 10000) / 100,
      projectedRevenueChange: Math.round(targetRevenueChange * 10000) / 100,
    };
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createElasticityCalculator(
  supabaseUrl: string,
  supabaseKey: string,
  options?: {
    minimumDataPoints?: number;
    minimumPriceVariation?: number;
  }
): ElasticityCalculator {
  return new ElasticityCalculator(supabaseUrl, supabaseKey, options);
}
