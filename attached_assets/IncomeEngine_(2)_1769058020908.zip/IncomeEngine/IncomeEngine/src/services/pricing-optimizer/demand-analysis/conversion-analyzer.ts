/**
 * ============================================================================
 * CONVERSION ANALYZER
 * Analyze price vs conversion rate relationships
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  ConversionData,
  ConversionAnalysis,
  PriceConversionProjection,
} from '../types.js';

// =============================================================================
// CONVERSION ANALYZER CLASS
// =============================================================================

export class ConversionAnalyzer {
  private readonly supabase: SupabaseClient;
  private readonly minimumDataPoints: number;
  private readonly minimumViews: number;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options?: {
      minimumDataPoints?: number;
      minimumViews?: number;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.minimumDataPoints = options?.minimumDataPoints ?? 7;
    this.minimumViews = options?.minimumViews ?? 100;
  }

  /**
   * Analyze conversion rates at different price points
   */
  async analyzeConversion(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
      platform?: string;
    }
  ): Promise<ConversionAnalysis> {
    const conversionData = await this.getConversionData(productId, options);

    if (conversionData.length < this.minimumDataPoints) {
      return {
        productId,
        optimalPriceRange: { min: 0, max: 0 },
        currentConversionRate: 0,
        projectedConversionRates: [],
        insights: ['Insufficient data for conversion analysis'],
        calculatedAt: new Date(),
      };
    }

    // Filter out data points with insufficient views
    const validData = conversionData.filter((d) => d.views >= this.minimumViews);

    if (validData.length < 3) {
      return {
        productId,
        optimalPriceRange: { min: 0, max: 0 },
        currentConversionRate: this.calculateAverageConversionRate(conversionData),
        projectedConversionRates: [],
        insights: ['Insufficient traffic for reliable conversion analysis'],
        calculatedAt: new Date(),
      };
    }

    // Group data by price buckets
    const priceBuckets = this.groupByPriceBuckets(validData);

    // Find optimal price range
    const optimalRange = this.findOptimalPriceRange(priceBuckets);

    // Generate projections
    const projections = this.generateProjections(priceBuckets, validData);

    // Generate insights
    const insights = this.generateInsights(priceBuckets, optimalRange, validData);

    // Calculate current conversion rate
    const mostRecent = conversionData.sort(
      (a, b) => b.date.getTime() - a.date.getTime()
    )[0];
    const currentConversionRate = mostRecent?.conversionRate ?? 0;

    return {
      productId,
      optimalPriceRange: optimalRange,
      currentConversionRate: Math.round(currentConversionRate * 10000) / 100,
      projectedConversionRates: projections,
      insights,
      calculatedAt: new Date(),
    };
  }

  /**
   * Calculate revenue per visitor at different price points
   */
  async analyzeRevenuePerVisitor(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
    }
  ): Promise<{
    pricePoints: Array<{
      price: number;
      revenuePerVisitor: number;
      conversionRate: number;
      views: number;
    }>;
    optimalPrice: number;
    currentRevPerVisitor: number;
    potentialUplift: number;
  }> {
    const conversionData = await this.getConversionData(productId, options);
    const validData = conversionData.filter((d) => d.views >= this.minimumViews);

    if (validData.length < 3) {
      return {
        pricePoints: [],
        optimalPrice: 0,
        currentRevPerVisitor: 0,
        potentialUplift: 0,
      };
    }

    // Group by price buckets and calculate RPV
    const priceBuckets = this.groupByPriceBuckets(validData);

    const pricePoints = priceBuckets.map((bucket) => ({
      price: bucket.avgPrice,
      revenuePerVisitor: bucket.avgPrice * bucket.avgConversionRate,
      conversionRate: bucket.avgConversionRate,
      views: bucket.totalViews,
    }));

    // Find optimal price (highest RPV)
    const optimalPoint = pricePoints.reduce(
      (best, current) =>
        current.revenuePerVisitor > best.revenuePerVisitor ? current : best,
      pricePoints[0]
    );

    // Calculate current RPV
    const mostRecent = conversionData.sort(
      (a, b) => b.date.getTime() - a.date.getTime()
    )[0];
    const currentRevPerVisitor = mostRecent
      ? mostRecent.price * mostRecent.conversionRate
      : 0;

    // Calculate potential uplift
    const potentialUplift =
      currentRevPerVisitor > 0
        ? ((optimalPoint.revenuePerVisitor - currentRevPerVisitor) / currentRevPerVisitor) * 100
        : 0;

    return {
      pricePoints: pricePoints.map((p) => ({
        ...p,
        revenuePerVisitor: Math.round(p.revenuePerVisitor * 10000) / 10000,
        conversionRate: Math.round(p.conversionRate * 10000) / 100,
      })),
      optimalPrice: Math.round(optimalPoint.price * 100) / 100,
      currentRevPerVisitor: Math.round(currentRevPerVisitor * 10000) / 10000,
      potentialUplift: Math.round(potentialUplift * 100) / 100,
    };
  }

  /**
   * Calculate funnel metrics
   */
  async analyzeFunnel(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
    }
  ): Promise<{
    viewToCartRate: number;
    cartToPurchaseRate: number;
    overallConversionRate: number;
    dropoffPoints: Array<{ stage: string; dropoffRate: number }>;
  }> {
    const conversionData = await this.getConversionData(productId, options);

    if (conversionData.length === 0) {
      return {
        viewToCartRate: 0,
        cartToPurchaseRate: 0,
        overallConversionRate: 0,
        dropoffPoints: [],
      };
    }

    const totals = conversionData.reduce(
      (acc, d) => ({
        views: acc.views + d.views,
        addToCart: acc.addToCart + d.addToCart,
        purchases: acc.purchases + d.purchases,
      }),
      { views: 0, addToCart: 0, purchases: 0 }
    );

    const viewToCartRate = totals.views > 0 ? totals.addToCart / totals.views : 0;
    const cartToPurchaseRate = totals.addToCart > 0 ? totals.purchases / totals.addToCart : 0;
    const overallConversionRate = totals.views > 0 ? totals.purchases / totals.views : 0;

    const dropoffPoints = [
      {
        stage: 'View to Cart',
        dropoffRate: 1 - viewToCartRate,
      },
      {
        stage: 'Cart to Purchase',
        dropoffRate: 1 - cartToPurchaseRate,
      },
    ];

    return {
      viewToCartRate: Math.round(viewToCartRate * 10000) / 100,
      cartToPurchaseRate: Math.round(cartToPurchaseRate * 10000) / 100,
      overallConversionRate: Math.round(overallConversionRate * 10000) / 100,
      dropoffPoints: dropoffPoints.map((d) => ({
        ...d,
        dropoffRate: Math.round(d.dropoffRate * 10000) / 100,
      })),
    };
  }

  /**
   * Predict conversion rate for a given price
   */
  predictConversionRate(
    historicalData: ConversionData[],
    targetPrice: number
  ): { predictedRate: number; confidence: number } {
    const validData = historicalData.filter((d) => d.views >= this.minimumViews);

    if (validData.length < 3) {
      return { predictedRate: 0, confidence: 0 };
    }

    // Use linear regression on log(price) vs conversion rate
    const prices = validData.map((d) => d.price);
    const rates = validData.map((d) => d.conversionRate);

    const logPrices = prices.map((p) => Math.log(p));
    const { slope, intercept, rSquared } = this.linearRegression(logPrices, rates);

    const predictedRate = slope * Math.log(targetPrice) + intercept;

    // Clamp between 0 and 1
    const clampedRate = Math.max(0, Math.min(1, predictedRate));

    return {
      predictedRate: Math.round(clampedRate * 10000) / 100,
      confidence: Math.round(Math.max(0, rSquared) * 100) / 100,
    };
  }

  // ===========================================================================
  // HELPER METHODS
  // ===========================================================================

  private groupByPriceBuckets(
    data: ConversionData[],
    numBuckets: number = 5
  ): Array<{
    avgPrice: number;
    avgConversionRate: number;
    totalViews: number;
    dataPoints: number;
  }> {
    const prices = data.map((d) => d.price);
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const bucketSize = (maxPrice - minPrice) / numBuckets;

    if (bucketSize === 0) {
      return [{
        avgPrice: minPrice,
        avgConversionRate: data.reduce((s, d) => s + d.conversionRate, 0) / data.length,
        totalViews: data.reduce((s, d) => s + d.views, 0),
        dataPoints: data.length,
      }];
    }

    const buckets: Map<number, ConversionData[]> = new Map();

    for (const d of data) {
      const bucketIndex = Math.min(
        Math.floor((d.price - minPrice) / bucketSize),
        numBuckets - 1
      );
      if (!buckets.has(bucketIndex)) {
        buckets.set(bucketIndex, []);
      }
      buckets.get(bucketIndex)!.push(d);
    }

    return Array.from(buckets.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([_, items]) => {
        const totalViews = items.reduce((s, d) => s + d.views, 0);
        const weightedConversion = items.reduce(
          (s, d) => s + d.conversionRate * d.views,
          0
        );
        return {
          avgPrice: items.reduce((s, d) => s + d.price, 0) / items.length,
          avgConversionRate: totalViews > 0 ? weightedConversion / totalViews : 0,
          totalViews,
          dataPoints: items.length,
        };
      });
  }

  private findOptimalPriceRange(
    buckets: Array<{
      avgPrice: number;
      avgConversionRate: number;
      totalViews: number;
    }>
  ): { min: number; max: number } {
    if (buckets.length === 0) {
      return { min: 0, max: 0 };
    }

    // Calculate revenue per visitor for each bucket
    const rpvBuckets = buckets.map((b) => ({
      ...b,
      rpv: b.avgPrice * b.avgConversionRate,
    }));

    // Find buckets with RPV above median
    const sortedRpv = [...rpvBuckets].sort((a, b) => b.rpv - a.rpv);
    const medianRpv = sortedRpv[Math.floor(sortedRpv.length / 2)].rpv;

    const aboveMedian = rpvBuckets.filter((b) => b.rpv >= medianRpv);

    if (aboveMedian.length === 0) {
      return {
        min: buckets[0].avgPrice,
        max: buckets[buckets.length - 1].avgPrice,
      };
    }

    return {
      min: Math.round(Math.min(...aboveMedian.map((b) => b.avgPrice)) * 100) / 100,
      max: Math.round(Math.max(...aboveMedian.map((b) => b.avgPrice)) * 100) / 100,
    };
  }

  private generateProjections(
    buckets: Array<{
      avgPrice: number;
      avgConversionRate: number;
      totalViews: number;
    }>,
    rawData: ConversionData[]
  ): PriceConversionProjection[] {
    if (buckets.length < 2) {
      return [];
    }

    const minPrice = Math.min(...buckets.map((b) => b.avgPrice));
    const maxPrice = Math.max(...buckets.map((b) => b.avgPrice));
    const priceStep = (maxPrice - minPrice) / 10;

    const projections: PriceConversionProjection[] = [];

    for (let price = minPrice; price <= maxPrice; price += priceStep) {
      const { predictedRate, confidence } = this.predictConversionRate(rawData, price);

      // Estimate baseline views per day
      const avgViews = rawData.reduce((s, d) => s + d.views, 0) / rawData.length;

      projections.push({
        price: Math.round(price * 100) / 100,
        projectedConversionRate: predictedRate,
        projectedRevenue: Math.round(price * (predictedRate / 100) * avgViews * 100) / 100,
        confidence,
      });
    }

    return projections;
  }

  private generateInsights(
    buckets: Array<{
      avgPrice: number;
      avgConversionRate: number;
      totalViews: number;
    }>,
    optimalRange: { min: number; max: number },
    rawData: ConversionData[]
  ): string[] {
    const insights: string[] = [];

    if (buckets.length < 2) {
      insights.push('Not enough price variation to generate insights');
      return insights;
    }

    // Price sensitivity insight
    const firstBucket = buckets[0];
    const lastBucket = buckets[buckets.length - 1];
    const priceIncrease = (lastBucket.avgPrice - firstBucket.avgPrice) / firstBucket.avgPrice;
    const conversionDecrease = (firstBucket.avgConversionRate - lastBucket.avgConversionRate) / firstBucket.avgConversionRate;

    if (conversionDecrease > priceIncrease * 1.5) {
      insights.push('Customers are highly price-sensitive. Consider pricing at the lower end of optimal range.');
    } else if (conversionDecrease < priceIncrease * 0.5) {
      insights.push('Customers are relatively price-insensitive. There may be room to increase prices.');
    }

    // Optimal range insight
    insights.push(
      `Optimal price range for revenue per visitor: $${optimalRange.min.toFixed(2)} - $${optimalRange.max.toFixed(2)}`
    );

    // Current price vs optimal insight
    const currentPrice = rawData.sort((a, b) => b.date.getTime() - a.date.getTime())[0]?.price;
    if (currentPrice) {
      if (currentPrice < optimalRange.min) {
        insights.push(
          `Current price ($${currentPrice.toFixed(2)}) is below optimal range. Consider increasing.`
        );
      } else if (currentPrice > optimalRange.max) {
        insights.push(
          `Current price ($${currentPrice.toFixed(2)}) is above optimal range. Consider decreasing.`
        );
      } else {
        insights.push(`Current price is within the optimal range.`);
      }
    }

    // Volume insight
    const highVolumeBuckets = buckets.filter((b) => b.totalViews > buckets.reduce((s, b2) => s + b2.totalViews, 0) / buckets.length);
    if (highVolumeBuckets.length > 0) {
      const avgHighVolumePrice = highVolumeBuckets.reduce((s, b) => s + b.avgPrice, 0) / highVolumeBuckets.length;
      insights.push(
        `Highest traffic volume occurs around $${avgHighVolumePrice.toFixed(2)}`
      );
    }

    return insights;
  }

  private calculateAverageConversionRate(data: ConversionData[]): number {
    if (data.length === 0) return 0;
    return data.reduce((s, d) => s + d.conversionRate, 0) / data.length;
  }

  private linearRegression(
    x: number[],
    y: number[]
  ): { slope: number; intercept: number; rSquared: number } {
    const n = x.length;
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
    const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);
    const sumYY = y.reduce((sum, yi) => sum + yi * yi, 0);

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    // Calculate R-squared
    const yMean = sumY / n;
    const ssTotal = y.reduce((sum, yi) => sum + Math.pow(yi - yMean, 2), 0);
    const ssResidual = y.reduce((sum, yi, i) => {
      const predicted = slope * x[i] + intercept;
      return sum + Math.pow(yi - predicted, 2);
    }, 0);
    const rSquared = ssTotal > 0 ? 1 - ssResidual / ssTotal : 0;

    return { slope, intercept, rSquared };
  }

  private async getConversionData(
    productId: string,
    options?: {
      startDate?: Date;
      endDate?: Date;
      platform?: string;
    }
  ): Promise<ConversionData[]> {
    const startDate = options?.startDate ?? new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const endDate = options?.endDate ?? new Date();

    let query = this.supabase
      .from('pricing_conversion_data')
      .select('*')
      .eq('product_id', productId)
      .gte('date', startDate.toISOString())
      .lte('date', endDate.toISOString())
      .order('date', { ascending: true });

    if (options?.platform) {
      query = query.eq('platform', options.platform);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get conversion data: ${error.message}`);
    }

    return (data ?? []).map((row) => ({
      productId: row.product_id,
      price: row.price,
      views: row.views,
      addToCart: row.add_to_cart,
      purchases: row.purchases,
      conversionRate: row.views > 0 ? row.purchases / row.views : 0,
      date: new Date(row.date),
    }));
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createConversionAnalyzer(
  supabaseUrl: string,
  supabaseKey: string,
  options?: {
    minimumDataPoints?: number;
    minimumViews?: number;
  }
): ConversionAnalyzer {
  return new ConversionAnalyzer(supabaseUrl, supabaseKey, options);
}
