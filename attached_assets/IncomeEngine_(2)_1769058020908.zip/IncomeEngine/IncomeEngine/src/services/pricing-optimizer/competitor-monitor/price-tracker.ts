/**
 * ============================================================================
 * COMPETITOR PRICE TRACKER
 * Historical price tracking and analysis
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  Competitor,
  CompetitorProduct,
  CompetitorPriceHistory,
  DBCompetitor,
  DBCompetitorProduct,
  DBPriceHistory,
  ScraperConfig,
  ScraperResult,
} from '../types.js';
import { CompetitorScraper, createCompetitorScraper } from './scraper.js';

// =============================================================================
// PRICE TRACKER CLASS
// =============================================================================

export class PriceTracker {
  private readonly supabase: SupabaseClient;
  private readonly scraper: CompetitorScraper;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    scraperConfig?: Partial<{ timeout: number; retryAttempts: number }>
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.scraper = createCompetitorScraper(scraperConfig);
  }

  // ===========================================================================
  // COMPETITOR MANAGEMENT
  // ===========================================================================

  /**
   * Add a new competitor to track
   */
  async addCompetitor(competitor: Omit<Competitor, 'id' | 'lastScraped'>): Promise<Competitor> {
    const { data, error } = await this.supabase
      .from('pricing_competitors')
      .insert({
        name: competitor.name,
        platform: competitor.platform,
        url: competitor.url,
        is_active: competitor.isActive,
        scrape_frequency: competitor.scrapeFrequency,
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to add competitor: ${error.message}`);
    }

    return this.mapDBCompetitor(data);
  }

  /**
   * Get all active competitors
   */
  async getActiveCompetitors(): Promise<Competitor[]> {
    const { data, error } = await this.supabase
      .from('pricing_competitors')
      .select('*')
      .eq('is_active', true)
      .order('name');

    if (error) {
      throw new Error(`Failed to get competitors: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBCompetitor(row));
  }

  /**
   * Get competitor by ID
   */
  async getCompetitor(id: string): Promise<Competitor | null> {
    const { data, error } = await this.supabase
      .from('pricing_competitors')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      throw new Error(`Failed to get competitor: ${error.message}`);
    }

    return this.mapDBCompetitor(data);
  }

  /**
   * Update competitor
   */
  async updateCompetitor(
    id: string,
    updates: Partial<Omit<Competitor, 'id'>>
  ): Promise<Competitor> {
    const dbUpdates: Partial<DBCompetitor> = {};
    if (updates.name !== undefined) dbUpdates.name = updates.name;
    if (updates.platform !== undefined) dbUpdates.platform = updates.platform;
    if (updates.url !== undefined) dbUpdates.url = updates.url;
    if (updates.isActive !== undefined) dbUpdates.is_active = updates.isActive;
    if (updates.scrapeFrequency !== undefined) dbUpdates.scrape_frequency = updates.scrapeFrequency;

    const { data, error } = await this.supabase
      .from('pricing_competitors')
      .update(dbUpdates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to update competitor: ${error.message}`);
    }

    return this.mapDBCompetitor(data);
  }

  /**
   * Deactivate a competitor
   */
  async deactivateCompetitor(id: string): Promise<void> {
    const { error } = await this.supabase
      .from('pricing_competitors')
      .update({ is_active: false })
      .eq('id', id);

    if (error) {
      throw new Error(`Failed to deactivate competitor: ${error.message}`);
    }
  }

  // ===========================================================================
  // COMPETITOR PRODUCT MANAGEMENT
  // ===========================================================================

  /**
   * Add a competitor product to track
   */
  async addCompetitorProduct(
    competitorId: string,
    product: {
      externalId: string;
      title: string;
      url: string;
      imageUrl?: string;
      currentPrice: number;
      currency: string;
      ourProductId?: string;
    }
  ): Promise<CompetitorProduct> {
    const { data, error } = await this.supabase
      .from('pricing_competitor_products')
      .insert({
        competitor_id: competitorId,
        external_id: product.externalId,
        our_product_id: product.ourProductId,
        title: product.title,
        url: product.url,
        image_url: product.imageUrl,
        current_price: product.currentPrice,
        currency: product.currency,
        availability: 'unknown',
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to add competitor product: ${error.message}`);
    }

    // Record initial price in history
    await this.recordPriceHistory(data.id, product.currentPrice, product.currency, 'unknown');

    return this.mapDBCompetitorProduct(data);
  }

  /**
   * Get competitor products for a competitor
   */
  async getCompetitorProducts(competitorId: string): Promise<CompetitorProduct[]> {
    const { data, error } = await this.supabase
      .from('pricing_competitor_products')
      .select('*')
      .eq('competitor_id', competitorId)
      .order('title');

    if (error) {
      throw new Error(`Failed to get competitor products: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBCompetitorProduct(row));
  }

  /**
   * Get competitor products mapped to one of our products
   */
  async getCompetitorProductsForOurProduct(ourProductId: string): Promise<CompetitorProduct[]> {
    const { data, error } = await this.supabase
      .from('pricing_competitor_products')
      .select('*, pricing_competitors!inner(*)')
      .eq('our_product_id', ourProductId);

    if (error) {
      throw new Error(`Failed to get competitor products: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBCompetitorProduct(row));
  }

  /**
   * Link a competitor product to one of our products
   */
  async linkToOurProduct(competitorProductId: string, ourProductId: string): Promise<void> {
    const { error } = await this.supabase
      .from('pricing_competitor_products')
      .update({ our_product_id: ourProductId })
      .eq('id', competitorProductId);

    if (error) {
      throw new Error(`Failed to link competitor product: ${error.message}`);
    }
  }

  // ===========================================================================
  // PRICE HISTORY
  // ===========================================================================

  /**
   * Record a price in history
   */
  async recordPriceHistory(
    competitorProductId: string,
    price: number,
    currency: string,
    availability: string
  ): Promise<void> {
    const { error } = await this.supabase.from('pricing_price_history').insert({
      competitor_product_id: competitorProductId,
      price,
      currency,
      availability,
    });

    if (error) {
      throw new Error(`Failed to record price history: ${error.message}`);
    }
  }

  /**
   * Get price history for a competitor product
   */
  async getPriceHistory(
    competitorProductId: string,
    options?: { startDate?: Date; endDate?: Date; limit?: number }
  ): Promise<CompetitorPriceHistory[]> {
    let query = this.supabase
      .from('pricing_price_history')
      .select('*')
      .eq('competitor_product_id', competitorProductId)
      .order('scraped_at', { ascending: false });

    if (options?.startDate) {
      query = query.gte('scraped_at', options.startDate.toISOString());
    }
    if (options?.endDate) {
      query = query.lte('scraped_at', options.endDate.toISOString());
    }
    if (options?.limit) {
      query = query.limit(options.limit);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get price history: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBPriceHistory(row));
  }

  /**
   * Get price statistics for a competitor product
   */
  async getPriceStatistics(
    competitorProductId: string,
    days: number = 30
  ): Promise<{
    currentPrice: number;
    minPrice: number;
    maxPrice: number;
    avgPrice: number;
    priceChange: number;
    priceChangePercent: number;
    volatility: number;
    dataPoints: number;
  }> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const history = await this.getPriceHistory(competitorProductId, { startDate });

    if (history.length === 0) {
      return {
        currentPrice: 0,
        minPrice: 0,
        maxPrice: 0,
        avgPrice: 0,
        priceChange: 0,
        priceChangePercent: 0,
        volatility: 0,
        dataPoints: 0,
      };
    }

    const prices = history.map((h) => h.price);
    const currentPrice = prices[0];
    const oldestPrice = prices[prices.length - 1];

    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length;
    const priceChange = currentPrice - oldestPrice;
    const priceChangePercent = oldestPrice > 0 ? (priceChange / oldestPrice) * 100 : 0;

    // Calculate volatility (standard deviation)
    const squaredDiffs = prices.map((p) => Math.pow(p - avgPrice, 2));
    const avgSquaredDiff = squaredDiffs.reduce((a, b) => a + b, 0) / prices.length;
    const volatility = Math.sqrt(avgSquaredDiff);

    return {
      currentPrice,
      minPrice,
      maxPrice,
      avgPrice: Math.round(avgPrice * 100) / 100,
      priceChange: Math.round(priceChange * 100) / 100,
      priceChangePercent: Math.round(priceChangePercent * 100) / 100,
      volatility: Math.round(volatility * 100) / 100,
      dataPoints: prices.length,
    };
  }

  // ===========================================================================
  // SCRAPING OPERATIONS
  // ===========================================================================

  /**
   * Scrape and update a single competitor product
   */
  async scrapeAndUpdate(competitorProduct: CompetitorProduct): Promise<ScraperResult> {
    const config: ScraperConfig = {
      url: competitorProduct.url,
      platform: 'generic', // Will be determined from competitor
      selectors: this.scraper.getSelectorsForPlatform('generic'),
      timeout: 30000,
      retryAttempts: 3,
    };

    const result = await this.scraper.scrapeWithRetry(config);

    if (result.success && result.data) {
      // Update the product with new data
      await this.supabase
        .from('pricing_competitor_products')
        .update({
          current_price: result.data.currentPrice,
          availability: result.data.availability,
          rating: result.data.rating,
          review_count: result.data.reviewCount,
          image_url: result.data.imageUrl,
          last_updated: new Date().toISOString(),
        })
        .eq('id', competitorProduct.id);

      // Record price in history
      await this.recordPriceHistory(
        competitorProduct.id,
        result.data.currentPrice,
        result.data.currency,
        result.data.availability
      );
    }

    return result;
  }

  /**
   * Scrape all products for a competitor
   */
  async scrapeCompetitor(
    competitorId: string,
    options?: { concurrency?: number }
  ): Promise<Map<string, ScraperResult>> {
    const products = await this.getCompetitorProducts(competitorId);
    const results = new Map<string, ScraperResult>();

    const concurrency = options?.concurrency ?? 3;

    // Process in batches
    for (let i = 0; i < products.length; i += concurrency) {
      const batch = products.slice(i, i + concurrency);
      const batchResults = await Promise.all(
        batch.map((product) => this.scrapeAndUpdate(product))
      );

      batch.forEach((product, index) => {
        results.set(product.id, batchResults[index]);
      });

      // Delay between batches to avoid rate limiting
      if (i + concurrency < products.length) {
        await this.sleep(2000);
      }
    }

    // Update competitor last scraped timestamp
    await this.supabase
      .from('pricing_competitors')
      .update({ last_scraped: new Date().toISOString() })
      .eq('id', competitorId);

    return results;
  }

  /**
   * Scrape all due competitors based on their frequency
   */
  async scrapeDueCompetitors(): Promise<{
    competitorsScraped: number;
    productsScraped: number;
    successRate: number;
  }> {
    const competitors = await this.getActiveCompetitors();
    const now = new Date();

    let competitorsScraped = 0;
    let productsScraped = 0;
    let successCount = 0;

    for (const competitor of competitors) {
      if (this.isDue(competitor, now)) {
        const results = await this.scrapeCompetitor(competitor.id);
        competitorsScraped++;
        productsScraped += results.size;
        successCount += Array.from(results.values()).filter((r) => r.success).length;
      }
    }

    return {
      competitorsScraped,
      productsScraped,
      successRate: productsScraped > 0 ? (successCount / productsScraped) * 100 : 100,
    };
  }

  // ===========================================================================
  // HELPER METHODS
  // ===========================================================================

  private isDue(competitor: Competitor, now: Date): boolean {
    if (!competitor.lastScraped) return true;

    const lastScraped = new Date(competitor.lastScraped);
    const hoursSince = (now.getTime() - lastScraped.getTime()) / (1000 * 60 * 60);

    switch (competitor.scrapeFrequency) {
      case 'hourly':
        return hoursSince >= 1;
      case 'daily':
        return hoursSince >= 24;
      case 'weekly':
        return hoursSince >= 168;
      default:
        return hoursSince >= 24;
    }
  }

  private mapDBCompetitor(row: DBCompetitor): Competitor {
    return {
      id: row.id,
      name: row.name,
      platform: row.platform,
      url: row.url,
      isActive: row.is_active,
      lastScraped: row.last_scraped ? new Date(row.last_scraped) : null,
      scrapeFrequency: row.scrape_frequency as 'hourly' | 'daily' | 'weekly',
    };
  }

  private mapDBCompetitorProduct(row: DBCompetitorProduct): CompetitorProduct {
    return {
      id: row.id,
      competitorId: row.competitor_id,
      externalId: row.external_id,
      title: row.title,
      url: row.url,
      imageUrl: row.image_url,
      currentPrice: row.current_price,
      currency: row.currency,
      availability: row.availability as 'in_stock' | 'out_of_stock' | 'limited' | 'unknown',
      rating: row.rating,
      reviewCount: row.review_count,
      lastUpdated: new Date(row.last_updated),
    };
  }

  private mapDBPriceHistory(row: DBPriceHistory): CompetitorPriceHistory {
    return {
      id: row.id,
      competitorProductId: row.competitor_product_id,
      price: row.price,
      currency: row.currency,
      availability: row.availability,
      scrapedAt: new Date(row.scraped_at),
    };
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createPriceTracker(
  supabaseUrl: string,
  supabaseKey: string,
  scraperConfig?: Partial<{ timeout: number; retryAttempts: number }>
): PriceTracker {
  return new PriceTracker(supabaseUrl, supabaseKey, scraperConfig);
}
