/**
 * ============================================================================
 * PRICE ALERT SERVICE
 * Monitor price changes and generate alerts
 * ============================================================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  PriceAlert,
  DBPriceAlert,
  CompetitorProduct,
  CompetitorPriceHistory,
} from '../types.js';

// =============================================================================
// ALERT THRESHOLDS
// =============================================================================

export interface AlertThresholds {
  /** Minimum percent change to trigger price drop alert */
  priceDropPercent: number;
  /** Minimum percent change to trigger price increase alert */
  priceIncreasePercent: number;
  /** Minimum absolute price change to trigger alert (in currency units) */
  minAbsoluteChange: number;
  /** Time window in hours to look for price changes */
  lookbackHours: number;
}

const DEFAULT_THRESHOLDS: AlertThresholds = {
  priceDropPercent: 5,
  priceIncreasePercent: 10,
  minAbsoluteChange: 1,
  lookbackHours: 24,
};

// =============================================================================
// ALERT SERVICE CLASS
// =============================================================================

export class PriceAlertService {
  private readonly supabase: SupabaseClient;
  private readonly thresholds: AlertThresholds;
  private readonly webhookUrl?: string;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options?: {
      thresholds?: Partial<AlertThresholds>;
      webhookUrl?: string;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.thresholds = { ...DEFAULT_THRESHOLDS, ...options?.thresholds };
    this.webhookUrl = options?.webhookUrl;
  }

  // ===========================================================================
  // ALERT GENERATION
  // ===========================================================================

  /**
   * Check for price changes and generate alerts
   */
  async checkAndGenerateAlerts(
    competitorProductId: string,
    newPrice: number,
    newAvailability: string
  ): Promise<PriceAlert[]> {
    // Get the product and recent price history
    const { data: product, error: productError } = await this.supabase
      .from('pricing_competitor_products')
      .select('*, pricing_competitors!inner(*)')
      .eq('id', competitorProductId)
      .single();

    if (productError || !product) {
      throw new Error(`Failed to get competitor product: ${productError?.message}`);
    }

    const lookbackDate = new Date();
    lookbackDate.setHours(lookbackDate.getHours() - this.thresholds.lookbackHours);

    const { data: history, error: historyError } = await this.supabase
      .from('pricing_price_history')
      .select('*')
      .eq('competitor_product_id', competitorProductId)
      .gte('scraped_at', lookbackDate.toISOString())
      .order('scraped_at', { ascending: false })
      .limit(10);

    if (historyError) {
      throw new Error(`Failed to get price history: ${historyError.message}`);
    }

    const alerts: PriceAlert[] = [];
    const previousHistory = history && history.length > 1 ? history[1] : null;
    const previousPrice = previousHistory?.price ?? product.current_price;
    const previousAvailability = previousHistory?.availability ?? product.availability;

    // Check for price change alerts
    if (previousPrice > 0 && newPrice > 0) {
      const priceChange = newPrice - previousPrice;
      const percentChange = (priceChange / previousPrice) * 100;

      // Price drop alert
      if (
        priceChange < 0 &&
        Math.abs(percentChange) >= this.thresholds.priceDropPercent &&
        Math.abs(priceChange) >= this.thresholds.minAbsoluteChange
      ) {
        const alert = await this.createAlert({
          productId: product.our_product_id,
          competitorProductId,
          alertType: 'price_drop',
          previousValue: previousPrice,
          currentValue: newPrice,
          percentChange,
          severity: this.calculateSeverity(Math.abs(percentChange), 'price_drop'),
        });
        alerts.push(alert);
      }

      // Price increase alert
      if (
        priceChange > 0 &&
        percentChange >= this.thresholds.priceIncreasePercent &&
        priceChange >= this.thresholds.minAbsoluteChange
      ) {
        const alert = await this.createAlert({
          productId: product.our_product_id,
          competitorProductId,
          alertType: 'price_increase',
          previousValue: previousPrice,
          currentValue: newPrice,
          percentChange,
          severity: this.calculateSeverity(percentChange, 'price_increase'),
        });
        alerts.push(alert);
      }
    }

    // Check for availability change alerts
    if (previousAvailability !== newAvailability) {
      // Out of stock alert
      if (previousAvailability !== 'out_of_stock' && newAvailability === 'out_of_stock') {
        const alert = await this.createAlert({
          productId: product.our_product_id,
          competitorProductId,
          alertType: 'out_of_stock',
          previousValue: previousAvailability,
          currentValue: newAvailability,
          percentChange: null,
          severity: 'medium',
        });
        alerts.push(alert);
      }

      // Back in stock alert
      if (previousAvailability === 'out_of_stock' && newAvailability !== 'out_of_stock') {
        const alert = await this.createAlert({
          productId: product.our_product_id,
          competitorProductId,
          alertType: 'back_in_stock',
          previousValue: previousAvailability,
          currentValue: newAvailability,
          percentChange: null,
          severity: 'high',
        });
        alerts.push(alert);
      }
    }

    // Send webhook notifications for critical alerts
    if (this.webhookUrl) {
      const criticalAlerts = alerts.filter((a) => a.severity === 'critical' || a.severity === 'high');
      if (criticalAlerts.length > 0) {
        await this.sendWebhookNotification(criticalAlerts);
      }
    }

    return alerts;
  }

  /**
   * Create a price alert
   */
  private async createAlert(params: {
    productId: string | null;
    competitorProductId: string;
    alertType: PriceAlert['alertType'];
    previousValue: number | string;
    currentValue: number | string;
    percentChange: number | null;
    severity: PriceAlert['severity'];
  }): Promise<PriceAlert> {
    const { data, error } = await this.supabase
      .from('pricing_alerts')
      .insert({
        product_id: params.productId,
        competitor_product_id: params.competitorProductId,
        alert_type: params.alertType,
        previous_value: String(params.previousValue),
        current_value: String(params.currentValue),
        percent_change: params.percentChange,
        severity: params.severity,
        is_acknowledged: false,
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create alert: ${error.message}`);
    }

    return this.mapDBAlert(data);
  }

  /**
   * Calculate alert severity based on percent change
   */
  private calculateSeverity(
    percentChange: number,
    alertType: 'price_drop' | 'price_increase'
  ): PriceAlert['severity'] {
    if (alertType === 'price_drop') {
      if (percentChange >= 30) return 'critical';
      if (percentChange >= 20) return 'high';
      if (percentChange >= 10) return 'medium';
      return 'low';
    } else {
      if (percentChange >= 50) return 'critical';
      if (percentChange >= 30) return 'high';
      if (percentChange >= 20) return 'medium';
      return 'low';
    }
  }

  // ===========================================================================
  // ALERT MANAGEMENT
  // ===========================================================================

  /**
   * Get unacknowledged alerts
   */
  async getUnacknowledgedAlerts(options?: {
    productId?: string;
    severity?: PriceAlert['severity'];
    limit?: number;
  }): Promise<PriceAlert[]> {
    let query = this.supabase
      .from('pricing_alerts')
      .select('*')
      .eq('is_acknowledged', false)
      .order('created_at', { ascending: false });

    if (options?.productId) {
      query = query.eq('product_id', options.productId);
    }
    if (options?.severity) {
      query = query.eq('severity', options.severity);
    }
    if (options?.limit) {
      query = query.limit(options.limit);
    }

    const { data, error } = await query;

    if (error) {
      throw new Error(`Failed to get alerts: ${error.message}`);
    }

    return (data ?? []).map((row) => this.mapDBAlert(row));
  }

  /**
   * Get all alerts with filters
   */
  async getAlerts(options?: {
    productId?: string;
    alertType?: PriceAlert['alertType'];
    severity?: PriceAlert['severity'];
    acknowledged?: boolean;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<{ alerts: PriceAlert[]; total: number }> {
    let query = this.supabase
      .from('pricing_alerts')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false });

    if (options?.productId) {
      query = query.eq('product_id', options.productId);
    }
    if (options?.alertType) {
      query = query.eq('alert_type', options.alertType);
    }
    if (options?.severity) {
      query = query.eq('severity', options.severity);
    }
    if (options?.acknowledged !== undefined) {
      query = query.eq('is_acknowledged', options.acknowledged);
    }
    if (options?.startDate) {
      query = query.gte('created_at', options.startDate.toISOString());
    }
    if (options?.endDate) {
      query = query.lte('created_at', options.endDate.toISOString());
    }
    if (options?.limit) {
      query = query.limit(options.limit);
    }
    if (options?.offset) {
      query = query.range(options.offset, options.offset + (options.limit ?? 50) - 1);
    }

    const { data, count, error } = await query;

    if (error) {
      throw new Error(`Failed to get alerts: ${error.message}`);
    }

    return {
      alerts: (data ?? []).map((row) => this.mapDBAlert(row)),
      total: count ?? 0,
    };
  }

  /**
   * Acknowledge an alert
   */
  async acknowledgeAlert(alertId: string): Promise<void> {
    const { error } = await this.supabase
      .from('pricing_alerts')
      .update({ is_acknowledged: true })
      .eq('id', alertId);

    if (error) {
      throw new Error(`Failed to acknowledge alert: ${error.message}`);
    }
  }

  /**
   * Acknowledge multiple alerts
   */
  async acknowledgeAlerts(alertIds: string[]): Promise<void> {
    const { error } = await this.supabase
      .from('pricing_alerts')
      .update({ is_acknowledged: true })
      .in('id', alertIds);

    if (error) {
      throw new Error(`Failed to acknowledge alerts: ${error.message}`);
    }
  }

  /**
   * Delete old acknowledged alerts
   */
  async cleanupOldAlerts(daysToKeep: number = 30): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    const { data, error } = await this.supabase
      .from('pricing_alerts')
      .delete()
      .eq('is_acknowledged', true)
      .lt('created_at', cutoffDate.toISOString())
      .select();

    if (error) {
      throw new Error(`Failed to cleanup alerts: ${error.message}`);
    }

    return data?.length ?? 0;
  }

  // ===========================================================================
  // ALERT STATISTICS
  // ===========================================================================

  /**
   * Get alert statistics
   */
  async getAlertStatistics(days: number = 30): Promise<{
    total: number;
    byType: Record<string, number>;
    bySeverity: Record<string, number>;
    acknowledged: number;
    unacknowledged: number;
    averagePerDay: number;
  }> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const { data, error } = await this.supabase
      .from('pricing_alerts')
      .select('alert_type, severity, is_acknowledged')
      .gte('created_at', startDate.toISOString());

    if (error) {
      throw new Error(`Failed to get alert statistics: ${error.message}`);
    }

    const alerts = data ?? [];
    const byType: Record<string, number> = {};
    const bySeverity: Record<string, number> = {};
    let acknowledged = 0;
    let unacknowledged = 0;

    for (const alert of alerts) {
      byType[alert.alert_type] = (byType[alert.alert_type] ?? 0) + 1;
      bySeverity[alert.severity] = (bySeverity[alert.severity] ?? 0) + 1;
      if (alert.is_acknowledged) {
        acknowledged++;
      } else {
        unacknowledged++;
      }
    }

    return {
      total: alerts.length,
      byType,
      bySeverity,
      acknowledged,
      unacknowledged,
      averagePerDay: Math.round((alerts.length / days) * 100) / 100,
    };
  }

  // ===========================================================================
  // NOTIFICATIONS
  // ===========================================================================

  /**
   * Send webhook notification for alerts
   */
  private async sendWebhookNotification(alerts: PriceAlert[]): Promise<void> {
    if (!this.webhookUrl) return;

    try {
      const payload = {
        event: 'price_alerts',
        timestamp: new Date().toISOString(),
        alerts: alerts.map((a) => ({
          id: a.id,
          type: a.alertType,
          severity: a.severity,
          previousValue: a.previousValue,
          currentValue: a.currentValue,
          percentChange: a.percentChange,
          createdAt: a.createdAt.toISOString(),
        })),
      };

      await fetch(this.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
    } catch (error) {
      // Log error but don't throw - webhook failure shouldn't break alert flow
      console.error('Failed to send webhook notification:', error);
    }
  }

  // ===========================================================================
  // HELPER METHODS
  // ===========================================================================

  private mapDBAlert(row: DBPriceAlert): PriceAlert {
    return {
      id: row.id,
      productId: row.product_id,
      competitorProductId: row.competitor_product_id,
      alertType: row.alert_type as PriceAlert['alertType'],
      previousValue: isNaN(Number(row.previous_value))
        ? row.previous_value
        : Number(row.previous_value),
      currentValue: isNaN(Number(row.current_value))
        ? row.current_value
        : Number(row.current_value),
      percentChange: row.percent_change,
      severity: row.severity as PriceAlert['severity'],
      isAcknowledged: row.is_acknowledged,
      createdAt: new Date(row.created_at),
    };
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createPriceAlertService(
  supabaseUrl: string,
  supabaseKey: string,
  options?: {
    thresholds?: Partial<AlertThresholds>;
    webhookUrl?: string;
  }
): PriceAlertService {
  return new PriceAlertService(supabaseUrl, supabaseKey, options);
}
