/**
 * ============================================================================
 * COMPETITOR PRICE SCRAPER
 * Playwright-based price scraping for competitor monitoring
 * ============================================================================
 */

import type {
  ScraperConfig,
  ScraperResult,
  CompetitorProduct,
} from '../types.js';

// =============================================================================
// PLATFORM SELECTORS
// =============================================================================

const PLATFORM_SELECTORS: Record<string, ScraperConfig['selectors']> = {
  amazon: {
    price: '#priceblock_ourprice, #priceblock_dealprice, .a-price .a-offscreen',
    title: '#productTitle',
    availability: '#availability span',
    rating: '.a-icon-star .a-icon-alt',
    reviewCount: '#acrCustomerReviewText',
    imageUrl: '#landingImage',
  },
  etsy: {
    price: '[data-buy-box-listing-id] .wt-text-title-03',
    title: '[data-buy-box-listing-id] h1',
    availability: '[data-appears-component-name="add_to_cart_button"]',
    rating: '[data-rating]',
    reviewCount: '[data-reviews-count]',
    imageUrl: '[data-carousel-image]',
  },
  ebay: {
    price: '.x-price-primary span.ux-textspans',
    title: '.x-item-title__mainTitle',
    availability: '.d-quantity__availability span',
    rating: '.x-star-rating .clipped',
    reviewCount: '.x-star-rating .ux-summary__count',
    imageUrl: '.ux-image-carousel-item img',
  },
  shopify: {
    price: '.product-price, [data-product-price], .price__regular .price-item',
    title: '.product-title, h1.product__title, [data-product-title]',
    availability: '.product-form__submit, [data-add-to-cart]',
    rating: '.spr-badge-caption',
    reviewCount: '.spr-badge-caption',
    imageUrl: '.product-featured-image img, .product__media img',
  },
  generic: {
    price: '[class*="price"], [data-price], .price, #price',
    title: 'h1, [class*="title"], .product-title',
    availability: '[class*="stock"], [class*="availability"], .availability',
    imageUrl: '[class*="product"] img, .product-image img',
  },
};

// =============================================================================
// SCRAPER CLASS
// =============================================================================

export class CompetitorScraper {
  private readonly defaultTimeout: number;
  private readonly defaultRetryAttempts: number;
  private readonly userAgents: readonly string[];

  constructor(config?: Partial<{ timeout: number; retryAttempts: number }>) {
    this.defaultTimeout = config?.timeout ?? 30000;
    this.defaultRetryAttempts = config?.retryAttempts ?? 3;
    this.userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    ];
  }

  /**
   * Get selectors for a platform
   */
  getSelectorsForPlatform(platform: string): ScraperConfig['selectors'] {
    return PLATFORM_SELECTORS[platform.toLowerCase()] ?? PLATFORM_SELECTORS.generic;
  }

  /**
   * Scrape a single competitor product page
   */
  async scrape(config: ScraperConfig): Promise<ScraperResult> {
    const startTime = Date.now();

    try {
      // Dynamic import to avoid loading Playwright when not needed
      const { chromium } = await import('playwright');

      const browser = await chromium.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
      });

      try {
        const context = await browser.newContext({
          userAgent: this.getRandomUserAgent(),
          viewport: { width: 1920, height: 1080 },
          locale: 'en-US',
        });

        const page = await context.newPage();

        // Block unnecessary resources for faster loading
        await page.route('**/*.{png,jpg,jpeg,gif,webp,svg,ico,woff,woff2,ttf,eot}', (route) =>
          route.abort()
        );

        // Navigate to the page
        await page.goto(config.url, {
          waitUntil: 'domcontentloaded',
          timeout: config.timeout,
        });

        // Wait for price selector if specified
        if (config.waitForSelector) {
          await page.waitForSelector(config.waitForSelector, {
            timeout: config.timeout / 2,
          }).catch(() => {
            // Continue even if selector not found
          });
        }

        // Extract data
        const data = await this.extractProductData(page, config);

        return {
          success: true,
          data,
          scrapedAt: new Date(),
          responseTimeMs: Date.now() - startTime,
        };
      } finally {
        await browser.close();
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown scraping error',
        scrapedAt: new Date(),
        responseTimeMs: Date.now() - startTime,
      };
    }
  }

  /**
   * Scrape with retry logic
   */
  async scrapeWithRetry(
    config: ScraperConfig,
    maxAttempts?: number
  ): Promise<ScraperResult> {
    const attempts = maxAttempts ?? config.retryAttempts ?? this.defaultRetryAttempts;

    let lastError: string = 'Unknown error';

    for (let attempt = 1; attempt <= attempts; attempt++) {
      const result = await this.scrape(config);

      if (result.success) {
        return result;
      }

      lastError = result.error ?? 'Unknown error';

      // Exponential backoff
      if (attempt < attempts) {
        const delay = Math.min(1000 * Math.pow(2, attempt - 1), 10000);
        await this.sleep(delay);
      }
    }

    return {
      success: false,
      error: `Failed after ${attempts} attempts: ${lastError}`,
      scrapedAt: new Date(),
      responseTimeMs: 0,
    };
  }

  /**
   * Scrape multiple URLs in parallel with rate limiting
   */
  async scrapeMultiple(
    configs: ScraperConfig[],
    options?: { concurrency?: number; delayBetweenMs?: number }
  ): Promise<Map<string, ScraperResult>> {
    const concurrency = options?.concurrency ?? 3;
    const delayBetweenMs = options?.delayBetweenMs ?? 1000;
    const results = new Map<string, ScraperResult>();

    // Process in batches
    for (let i = 0; i < configs.length; i += concurrency) {
      const batch = configs.slice(i, i + concurrency);
      const batchResults = await Promise.all(
        batch.map((config) => this.scrapeWithRetry(config))
      );

      batch.forEach((config, index) => {
        results.set(config.url, batchResults[index]);
      });

      // Delay between batches
      if (i + concurrency < configs.length) {
        await this.sleep(delayBetweenMs);
      }
    }

    return results;
  }

  /**
   * Extract product data from the page
   */
  private async extractProductData(
    page: import('playwright').Page,
    config: ScraperConfig
  ): Promise<CompetitorProduct> {
    const selectors = config.selectors;

    const [title, priceText, availability, rating, reviewCount, imageUrl] =
      await Promise.all([
        this.extractText(page, selectors.title),
        this.extractText(page, selectors.price),
        this.extractText(page, selectors.availability),
        selectors.rating ? this.extractText(page, selectors.rating) : null,
        selectors.reviewCount ? this.extractText(page, selectors.reviewCount) : null,
        selectors.imageUrl ? this.extractAttribute(page, selectors.imageUrl, 'src') : null,
      ]);

    const price = this.parsePrice(priceText);

    return {
      id: '', // Will be set by caller
      competitorId: '', // Will be set by caller
      externalId: this.extractExternalId(config.url),
      title: title?.trim() ?? 'Unknown Product',
      url: config.url,
      imageUrl,
      currentPrice: price,
      currency: this.detectCurrency(priceText),
      availability: this.parseAvailability(availability),
      rating: rating ? this.parseRating(rating) : null,
      reviewCount: reviewCount ? this.parseReviewCount(reviewCount) : null,
      lastUpdated: new Date(),
    };
  }

  /**
   * Extract text content from a selector
   */
  private async extractText(
    page: import('playwright').Page,
    selector: string
  ): Promise<string | null> {
    try {
      const element = await page.$(selector);
      if (!element) return null;
      return await element.textContent();
    } catch {
      return null;
    }
  }

  /**
   * Extract an attribute from a selector
   */
  private async extractAttribute(
    page: import('playwright').Page,
    selector: string,
    attribute: string
  ): Promise<string | null> {
    try {
      const element = await page.$(selector);
      if (!element) return null;
      return await element.getAttribute(attribute);
    } catch {
      return null;
    }
  }

  /**
   * Parse price from text
   */
  private parsePrice(priceText: string | null): number {
    if (!priceText) return 0;

    // Remove currency symbols and extra whitespace
    const cleaned = priceText
      .replace(/[^0-9.,]/g, '')
      .replace(/,(\d{3})/g, '$1') // Handle thousands separator
      .replace(/,/g, '.'); // Convert comma decimal to period

    const price = parseFloat(cleaned);
    return isNaN(price) ? 0 : price;
  }

  /**
   * Detect currency from price text
   */
  private detectCurrency(priceText: string | null): string {
    if (!priceText) return 'USD';

    if (priceText.includes('$')) return 'USD';
    if (priceText.includes('EUR') || priceText.includes('\u20AC')) return 'EUR';
    if (priceText.includes('GBP') || priceText.includes('\u00A3')) return 'GBP';
    if (priceText.includes('CAD') || priceText.includes('C$')) return 'CAD';
    if (priceText.includes('AUD') || priceText.includes('A$')) return 'AUD';

    return 'USD';
  }

  /**
   * Parse availability status
   */
  private parseAvailability(
    availabilityText: string | null
  ): 'in_stock' | 'out_of_stock' | 'limited' | 'unknown' {
    if (!availabilityText) return 'unknown';

    const text = availabilityText.toLowerCase();

    if (text.includes('out of stock') || text.includes('unavailable') || text.includes('sold out')) {
      return 'out_of_stock';
    }

    if (text.includes('limited') || text.includes('only') || text.includes('few left')) {
      return 'limited';
    }

    if (text.includes('in stock') || text.includes('available') || text.includes('add to cart')) {
      return 'in_stock';
    }

    return 'unknown';
  }

  /**
   * Parse rating from text
   */
  private parseRating(ratingText: string): number | null {
    const match = ratingText.match(/(\d+(?:\.\d+)?)/);
    if (!match) return null;

    const rating = parseFloat(match[1]);
    return isNaN(rating) ? null : Math.min(rating, 5);
  }

  /**
   * Parse review count from text
   */
  private parseReviewCount(reviewText: string): number | null {
    const cleaned = reviewText.replace(/[^0-9]/g, '');
    const count = parseInt(cleaned, 10);
    return isNaN(count) ? null : count;
  }

  /**
   * Extract external product ID from URL
   */
  private extractExternalId(url: string): string {
    try {
      const urlObj = new URL(url);
      const pathname = urlObj.pathname;

      // Amazon ASIN
      const asinMatch = pathname.match(/\/dp\/([A-Z0-9]{10})/i);
      if (asinMatch) return asinMatch[1];

      // Etsy listing ID
      const etsyMatch = pathname.match(/\/listing\/(\d+)/);
      if (etsyMatch) return etsyMatch[1];

      // eBay item ID
      const ebayMatch = pathname.match(/\/itm\/(\d+)/);
      if (ebayMatch) return ebayMatch[1];

      // Generic: use last path segment
      const segments = pathname.split('/').filter(Boolean);
      return segments[segments.length - 1] ?? url;
    } catch {
      return url;
    }
  }

  /**
   * Get a random user agent
   */
  private getRandomUserAgent(): string {
    const index = Math.floor(Math.random() * this.userAgents.length);
    return this.userAgents[index];
  }

  /**
   * Sleep helper
   */
  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createCompetitorScraper(
  config?: Partial<{ timeout: number; retryAttempts: number }>
): CompetitorScraper {
  return new CompetitorScraper(config);
}
