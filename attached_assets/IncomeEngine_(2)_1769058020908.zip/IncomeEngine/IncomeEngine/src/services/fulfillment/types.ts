/**
 * Order Fulfillment Pipeline Types
 * Defines all types for unified order fulfillment across platforms
 */

import { ConnectorName } from '../../connectors/index';
import {
  Order,
  OrderItem,
  OrderStatus,
  ShippingAddress,
  TrackingInfo,
  ProductType,
} from '../../connectors/core/types';

// ============================================================================
// Fulfillment Status Types
// ============================================================================

export type FulfillmentStatus =
  | 'pending'
  | 'processing'
  | 'routed'
  | 'in_production'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'on_hold'
  | 'failed';

export type ReturnStatus =
  | 'requested'
  | 'approved'
  | 'rejected'
  | 'in_transit'
  | 'received'
  | 'refunded'
  | 'closed';

export type RefundStatus =
  | 'pending'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'partial';

export type FulfillmentPriority = 'low' | 'normal' | 'high' | 'urgent';

// ============================================================================
// Unified Order Types
// ============================================================================

export interface UnifiedOrder {
  id: string;
  externalId: string;
  platform: ConnectorName;
  status: OrderStatus;
  fulfillmentStatus: FulfillmentStatus;
  priority: FulfillmentPriority;
  items: UnifiedOrderItem[];
  shippingAddress: ShippingAddress;
  billingAddress?: ShippingAddress;
  customer: CustomerInfo;
  pricing: OrderPricing;
  fulfillment?: FulfillmentDetails;
  metadata: Record<string, unknown>;
  platformData: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
  fulfilledAt?: Date;
  shippedAt?: Date;
  deliveredAt?: Date;
}

export interface UnifiedOrderItem {
  id: string;
  externalId: string;
  productId: string;
  variantId?: string;
  sku?: string;
  title: string;
  quantity: number;
  price: number;
  productType: ProductType;
  fulfillmentProvider?: string;
  fulfillmentStatus: FulfillmentStatus;
  trackingInfo?: TrackingInfo;
  metadata?: Record<string, unknown>;
}

export interface CustomerInfo {
  id?: string;
  email: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  locale?: string;
  acceptsMarketing?: boolean;
}

export interface OrderPricing {
  subtotal: number;
  shippingCost: number;
  tax: number;
  discount: number;
  total: number;
  currency: string;
}

export interface FulfillmentDetails {
  provider: string;
  providerId?: string;
  trackingInfo?: TrackingInfo;
  shippedAt?: Date;
  estimatedDelivery?: Date;
  notes?: string;
}

// ============================================================================
// Order Aggregation Types
// ============================================================================

export interface OrderAggregationConfig {
  platforms: ConnectorName[];
  pollIntervalMs: number;
  batchSize: number;
  enableWebhooks: boolean;
  filterStatuses?: OrderStatus[];
  lookbackHours?: number;
}

export interface OrderAggregationResult {
  success: boolean;
  orders: UnifiedOrder[];
  byPlatform: Record<ConnectorName, PlatformOrderResult>;
  errors: OrderAggregationError[];
  timestamp: Date;
  duration: number;
}

export interface PlatformOrderResult {
  platform: ConnectorName;
  success: boolean;
  orderCount: number;
  newOrderCount: number;
  updatedOrderCount: number;
  error?: string;
  lastSyncAt: Date;
}

export interface OrderAggregationError {
  platform: ConnectorName;
  code: string;
  message: string;
  retryable: boolean;
  timestamp: Date;
}

// ============================================================================
// Fulfillment Routing Types
// ============================================================================

export interface FulfillmentProvider {
  id: string;
  name: string;
  type: 'pod' | 'dropship' | 'warehouse' | 'digital';
  platforms: ConnectorName[];
  productTypes: ProductType[];
  regions: string[];
  priority: number;
  enabled: boolean;
  apiConfig?: ProviderApiConfig;
  costConfig: ProviderCostConfig;
  capabilities: ProviderCapabilities;
}

export interface ProviderApiConfig {
  baseUrl: string;
  apiKey?: string;
  webhookUrl?: string;
  timeout?: number;
}

export interface ProviderCostConfig {
  baseCost: number;
  perItemCost: number;
  shippingZones: ShippingZoneCost[];
}

export interface ShippingZoneCost {
  zone: string;
  countries: string[];
  baseCost: number;
  perItemCost: number;
  estimatedDays: number;
}

export interface ProviderCapabilities {
  supportsBulkOrders: boolean;
  supportsRush: boolean;
  supportsGiftWrapping: boolean;
  supportsCustomPackaging: boolean;
  maxItemsPerOrder: number;
  cutoffTime?: string; // UTC time for same-day processing
}

export interface RoutingDecision {
  orderId: string;
  itemId: string;
  providerId: string;
  providerName: string;
  reason: string;
  alternativeProviders: string[];
  estimatedCost: number;
  estimatedDays: number;
  confidence: number;
}

export interface RoutingResult {
  success: boolean;
  orderId: string;
  decisions: RoutingDecision[];
  totalEstimatedCost: number;
  totalEstimatedDays: number;
  warnings?: string[];
  errors?: RoutingError[];
}

export interface RoutingError {
  itemId: string;
  code: string;
  message: string;
  suggestion?: string;
}

export interface RoutingRules {
  rules: RoutingRule[];
  defaultProviderId: string;
  fallbackProviderId?: string;
}

export interface RoutingRule {
  id: string;
  name: string;
  priority: number;
  conditions: RoutingCondition[];
  action: RoutingAction;
  enabled: boolean;
}

export interface RoutingCondition {
  field: 'productType' | 'country' | 'region' | 'orderValue' | 'platform' | 'sku' | 'quantity';
  operator: 'equals' | 'notEquals' | 'contains' | 'in' | 'greaterThan' | 'lessThan';
  value: string | number | string[];
}

export interface RoutingAction {
  providerId: string;
  shippingMethod?: string;
  priority?: FulfillmentPriority;
  notes?: string;
}

// ============================================================================
// Tracking Types
// ============================================================================

export interface TrackingUpdate {
  orderId: string;
  itemIds: string[];
  platform: ConnectorName;
  trackingInfo: TrackingInfo;
  notifyCustomer: boolean;
  timestamp: Date;
}

export interface TrackingUpdateResult {
  success: boolean;
  orderId: string;
  platform: ConnectorName;
  externalFulfillmentId?: string;
  error?: string;
  customerNotified: boolean;
  timestamp: Date;
}

export interface TrackingEvent {
  id: string;
  orderId: string;
  trackingNumber: string;
  carrier: string;
  status: TrackingEventStatus;
  location?: string;
  description: string;
  timestamp: Date;
  rawData?: Record<string, unknown>;
}

export type TrackingEventStatus =
  | 'label_created'
  | 'picked_up'
  | 'in_transit'
  | 'out_for_delivery'
  | 'delivered'
  | 'exception'
  | 'returned_to_sender';

export interface CarrierConfig {
  carrier: string;
  displayName: string;
  trackingUrlPattern: string;
  apiEnabled: boolean;
  apiConfig?: {
    baseUrl: string;
    apiKey?: string;
  };
}

// ============================================================================
// Return and Refund Types
// ============================================================================

export interface ReturnRequest {
  id: string;
  orderId: string;
  platform: ConnectorName;
  externalId?: string;
  items: ReturnItem[];
  reason: ReturnReason;
  reasonDetails?: string;
  customerEmail: string;
  status: ReturnStatus;
  refundStatus: RefundStatus;
  returnShippingLabel?: ShippingLabel;
  createdAt: Date;
  updatedAt: Date;
  processedAt?: Date;
  receivedAt?: Date;
  refundedAt?: Date;
}

export interface ReturnItem {
  orderItemId: string;
  productId: string;
  sku?: string;
  title: string;
  quantity: number;
  returnQuantity: number;
  refundAmount: number;
  condition?: ItemCondition;
  inspectionNotes?: string;
}

export type ReturnReason =
  | 'damaged'
  | 'defective'
  | 'wrong_item'
  | 'not_as_described'
  | 'no_longer_needed'
  | 'arrived_late'
  | 'better_price_found'
  | 'accidental_order'
  | 'other';

export type ItemCondition =
  | 'new'
  | 'like_new'
  | 'good'
  | 'fair'
  | 'poor'
  | 'damaged';

export interface ShippingLabel {
  carrier: string;
  trackingNumber: string;
  labelUrl: string;
  expiresAt?: Date;
}

export interface RefundRequest {
  id: string;
  orderId: string;
  returnRequestId?: string;
  platform: ConnectorName;
  items: RefundItem[];
  totalRefund: number;
  refundMethod: RefundMethod;
  reason: string;
  status: RefundStatus;
  transactionId?: string;
  processedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface RefundItem {
  orderItemId: string;
  quantity: number;
  amount: number;
  reason?: string;
}

export type RefundMethod =
  | 'original_payment'
  | 'store_credit'
  | 'gift_card'
  | 'bank_transfer';

export interface ReturnPolicy {
  id: string;
  name: string;
  returnWindowDays: number;
  restockingFee: number;
  freeReturnShipping: boolean;
  excludedProductTypes: ProductType[];
  excludedReasons: ReturnReason[];
  autoApprove: boolean;
  autoApproveMaxValue: number;
}

// ============================================================================
// Notification Types
// ============================================================================

export type NotificationTrigger =
  | 'order_received'
  | 'order_confirmed'
  | 'in_production'
  | 'shipped'
  | 'out_for_delivery'
  | 'delivered'
  | 'return_approved'
  | 'return_received'
  | 'refund_processed'
  | 'order_cancelled';

export interface CustomerNotification {
  id: string;
  orderId: string;
  trigger: NotificationTrigger;
  channel: 'email' | 'sms' | 'push';
  recipient: string;
  subject?: string;
  body: string;
  templateId?: string;
  sentAt?: Date;
  status: 'pending' | 'sent' | 'failed' | 'bounced';
  error?: string;
  metadata?: Record<string, unknown>;
  createdAt: Date;
}

export interface NotificationTemplate {
  id: string;
  trigger: NotificationTrigger;
  channel: 'email' | 'sms' | 'push';
  subject?: string;
  body: string;
  variables: string[];
  enabled: boolean;
}

// ============================================================================
// Audit Trail Types
// ============================================================================

export type AuditAction =
  | 'order_created'
  | 'order_updated'
  | 'order_routed'
  | 'order_sent_to_provider'
  | 'tracking_received'
  | 'tracking_pushed'
  | 'status_updated'
  | 'return_requested'
  | 'return_approved'
  | 'return_rejected'
  | 'return_received'
  | 'refund_initiated'
  | 'refund_completed'
  | 'notification_sent'
  | 'error_occurred';

export interface FulfillmentAuditEntry {
  id: string;
  orderId: string;
  action: AuditAction;
  actor: 'system' | 'user' | 'webhook' | 'provider';
  actorId?: string;
  platform?: ConnectorName;
  providerId?: string;
  previousState?: Record<string, unknown>;
  newState?: Record<string, unknown>;
  details?: Record<string, unknown>;
  timestamp: Date;
}

// ============================================================================
// Fulfillment Pipeline Config
// ============================================================================

export interface FulfillmentPipelineConfig {
  supabaseUrl: string;
  supabaseKey: string;
  aggregation: OrderAggregationConfig;
  routing: RoutingRules;
  providers: FulfillmentProvider[];
  carriers: CarrierConfig[];
  returnPolicy: ReturnPolicy;
  notifications: NotificationConfig;
  enableAuditTrail: boolean;
  webhookSecret?: string;
}

export interface NotificationConfig {
  enabled: boolean;
  emailProvider?: 'sendgrid' | 'ses' | 'smtp';
  smsProvider?: 'twilio' | 'sns';
  templates: NotificationTemplate[];
  defaultFromEmail?: string;
  defaultFromPhone?: string;
}

// ============================================================================
// Event Types
// ============================================================================

export type FulfillmentEventType =
  | 'order:received'
  | 'order:aggregated'
  | 'order:routed'
  | 'order:sent_to_provider'
  | 'order:in_production'
  | 'tracking:received'
  | 'tracking:pushed'
  | 'order:shipped'
  | 'order:delivered'
  | 'order:cancelled'
  | 'return:requested'
  | 'return:approved'
  | 'return:rejected'
  | 'return:received'
  | 'refund:initiated'
  | 'refund:completed'
  | 'notification:sent'
  | 'error:occurred';

export interface FulfillmentEvent {
  type: FulfillmentEventType;
  orderId?: string;
  platform?: ConnectorName;
  payload: Record<string, unknown>;
  timestamp: Date;
}

export type FulfillmentEventHandler = (event: FulfillmentEvent) => void | Promise<void>;

// ============================================================================
// Statistics Types
// ============================================================================

export interface FulfillmentStats {
  period: 'day' | 'week' | 'month';
  startDate: Date;
  endDate: Date;
  totalOrders: number;
  fulfilledOrders: number;
  pendingOrders: number;
  cancelledOrders: number;
  returnedOrders: number;
  averageFulfillmentTime: number;
  averageShippingTime: number;
  fulfillmentRate: number;
  returnRate: number;
  byPlatform: Record<ConnectorName, PlatformStats>;
  byProvider: Record<string, ProviderStats>;
}

export interface PlatformStats {
  platform: ConnectorName;
  totalOrders: number;
  fulfilledOrders: number;
  averageOrderValue: number;
  returnRate: number;
}

export interface ProviderStats {
  providerId: string;
  providerName: string;
  totalOrders: number;
  onTimeRate: number;
  averageProcessingTime: number;
  averageCost: number;
}
