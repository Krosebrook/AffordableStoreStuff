/**
 * Tracking Updater
 * Pushes tracking numbers to platforms and monitors shipment status
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  createConnector,
  ConnectorName,
  BaseConnector,
  TrackingInfo,
} from '../../connectors/index';
import { sendWebhook, NotificationService, WebhookPayload } from '../../connectors/utils/webhook';
import {
  UnifiedOrder,
  TrackingUpdate,
  TrackingUpdateResult,
  TrackingEvent,
  TrackingEventStatus,
  CarrierConfig,
  FulfillmentEvent,
  FulfillmentAuditEntry,
  CustomerNotification,
  NotificationTrigger,
} from './types';

// ============================================================================
// Tracking Updater Class
// ============================================================================

export class TrackingUpdater extends EventEmitter {
  private supabase: SupabaseClient;
  private notificationService: NotificationService;
  private connectors: Map<ConnectorName, BaseConnector>;
  private carriers: Map<string, CarrierConfig>;
  private pollingInterval: NodeJS.Timeout | null = null;
  private pollingIntervalMs: number = 30 * 60 * 1000; // 30 minutes

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    carriers: CarrierConfig[] = []
  ) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.notificationService = new NotificationService(supabaseUrl, supabaseKey);
    this.connectors = new Map();
    this.carriers = new Map(carriers.map((c) => [c.carrier, c]));
  }

  // ============================================================================
  // Lifecycle Methods
  // ============================================================================

  /**
   * Initialize platform connectors
   */
  async initialize(platforms: ConnectorName[]): Promise<void> {
    for (const platform of platforms) {
      try {
        const credentials = await this.getCredentials(platform);
        if (credentials) {
          const connector = createConnector(platform, {
            platform,
            credentials,
          });
          await connector.authenticate();
          this.connectors.set(platform, connector);
          console.log(`[TrackingUpdater] Initialized connector for ${platform}`);
        }
      } catch (error) {
        console.error(`[TrackingUpdater] Failed to initialize ${platform}:`, error);
      }
    }
  }

  /**
   * Start tracking status polling
   */
  startPolling(intervalMs?: number): void {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
    }

    if (intervalMs) {
      this.pollingIntervalMs = intervalMs;
    }

    this.pollingInterval = setInterval(() => {
      this.pollTrackingStatuses();
    }, this.pollingIntervalMs);

    // Initial poll
    this.pollTrackingStatuses();

    console.log(`[TrackingUpdater] Started polling with interval: ${this.pollingIntervalMs}ms`);
  }

  /**
   * Stop tracking status polling
   */
  stopPolling(): void {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    console.log('[TrackingUpdater] Stopped polling');
  }

  // ============================================================================
  // Tracking Updates
  // ============================================================================

  /**
   * Push tracking info to a platform
   */
  async pushTracking(update: TrackingUpdate): Promise<TrackingUpdateResult> {
    const connector = this.connectors.get(update.platform);
    if (!connector) {
      return {
        success: false,
        orderId: update.orderId,
        platform: update.platform,
        error: `No connector available for platform: ${update.platform}`,
        customerNotified: false,
        timestamp: new Date(),
      };
    }

    try {
      // Get the external order ID
      const order = await this.getOrder(update.orderId);
      if (!order) {
        return {
          success: false,
          orderId: update.orderId,
          platform: update.platform,
          error: 'Order not found',
          customerNotified: false,
          timestamp: new Date(),
        };
      }

      // Build tracking URL if not provided
      const trackingInfo = this.enrichTrackingInfo(update.trackingInfo);

      // Push to platform
      const result = await connector.fulfillOrder(order.externalId, trackingInfo);

      if (!result.success) {
        await this.logAudit(update.orderId, 'error_occurred', {
          error: result.error?.message,
          platform: update.platform,
          action: 'push_tracking',
        });

        return {
          success: false,
          orderId: update.orderId,
          platform: update.platform,
          error: result.error?.message || 'Failed to push tracking',
          customerNotified: false,
          timestamp: new Date(),
        };
      }

      // Update order in database
      await this.updateOrderTracking(update.orderId, trackingInfo);

      // Log audit
      await this.logAudit(update.orderId, 'tracking_pushed', {
        platform: update.platform,
        trackingNumber: trackingInfo.trackingNumber,
        carrier: trackingInfo.carrier,
      });

      // Emit event
      this.emitEvent('tracking:pushed', {
        orderId: update.orderId,
        platform: update.platform,
        trackingNumber: trackingInfo.trackingNumber,
      });

      // Send customer notification if requested
      let customerNotified = false;
      if (update.notifyCustomer) {
        customerNotified = await this.sendTrackingNotification(order, trackingInfo);
      }

      return {
        success: true,
        orderId: update.orderId,
        platform: update.platform,
        externalFulfillmentId: result.data?.id,
        customerNotified,
        timestamp: new Date(),
      };
    } catch (error) {
      console.error(`[TrackingUpdater] Failed to push tracking:`, error);
      return {
        success: false,
        orderId: update.orderId,
        platform: update.platform,
        error: error instanceof Error ? error.message : 'Unknown error',
        customerNotified: false,
        timestamp: new Date(),
      };
    }
  }

  /**
   * Push tracking to multiple platforms for the same order
   */
  async pushTrackingToAllPlatforms(
    orderId: string,
    trackingInfo: TrackingInfo,
    notifyCustomer: boolean = true
  ): Promise<TrackingUpdateResult[]> {
    const order = await this.getOrder(orderId);
    if (!order) {
      return [];
    }

    const results: TrackingUpdateResult[] = [];

    // Push to the original platform
    const mainResult = await this.pushTracking({
      orderId,
      itemIds: order.items.map((i) => i.id),
      platform: order.platform,
      trackingInfo,
      notifyCustomer,
      timestamp: new Date(),
    });
    results.push(mainResult);

    // Check for any marketplace cross-listings
    const { data: crossListings } = await this.supabase
      .from('order_cross_listings')
      .select('platform, external_order_id')
      .eq('unified_order_id', orderId);

    if (crossListings) {
      for (const listing of crossListings) {
        const listingResult = await this.pushTracking({
          orderId,
          itemIds: order.items.map((i) => i.id),
          platform: listing.platform as ConnectorName,
          trackingInfo,
          notifyCustomer: false, // Only notify once
          timestamp: new Date(),
        });
        results.push(listingResult);
      }
    }

    return results;
  }

  /**
   * Receive tracking update from provider webhook
   */
  async receiveTracking(
    providerId: string,
    orderId: string,
    trackingInfo: TrackingInfo
  ): Promise<void> {
    // Enrich tracking info
    const enrichedTracking = this.enrichTrackingInfo(trackingInfo);

    // Store tracking info
    await this.updateOrderTracking(orderId, enrichedTracking);

    // Log audit
    await this.logAudit(orderId, 'tracking_received', {
      providerId,
      trackingNumber: trackingInfo.trackingNumber,
      carrier: trackingInfo.carrier,
    });

    // Emit event
    this.emitEvent('tracking:received', {
      orderId,
      providerId,
      trackingNumber: trackingInfo.trackingNumber,
    });

    // Push to all platforms
    const order = await this.getOrder(orderId);
    if (order) {
      await this.pushTrackingToAllPlatforms(orderId, enrichedTracking, true);
    }
  }

  // ============================================================================
  // Tracking Status Polling
  // ============================================================================

  /**
   * Poll for tracking status updates
   */
  async pollTrackingStatuses(): Promise<void> {
    // Get orders with tracking that aren't delivered
    const { data: orders } = await this.supabase
      .from('unified_orders')
      .select('id, fulfillment, status')
      .not('fulfillment', 'is', null)
      .not('fulfillment->trackingInfo', 'is', null)
      .not('fulfillment_status', 'eq', 'delivered')
      .limit(100);

    if (!orders || orders.length === 0) {
      return;
    }

    console.log(`[TrackingUpdater] Polling status for ${orders.length} shipments`);

    for (const order of orders) {
      try {
        const trackingInfo = order.fulfillment?.trackingInfo as TrackingInfo;
        if (!trackingInfo?.trackingNumber) continue;

        const events = await this.fetchTrackingEvents(
          trackingInfo.carrier,
          trackingInfo.trackingNumber
        );

        if (events.length > 0) {
          await this.processTrackingEvents(order.id, events);
        }
      } catch (error) {
        console.error(`[TrackingUpdater] Failed to poll tracking for order ${order.id}:`, error);
      }
    }
  }

  /**
   * Fetch tracking events from carrier API
   */
  private async fetchTrackingEvents(
    carrier: string,
    trackingNumber: string
  ): Promise<TrackingEvent[]> {
    const carrierConfig = this.carriers.get(carrier);
    if (!carrierConfig || !carrierConfig.apiEnabled || !carrierConfig.apiConfig) {
      return [];
    }

    try {
      const response = await fetch(
        `${carrierConfig.apiConfig.baseUrl}/track/${trackingNumber}`,
        {
          headers: {
            'Authorization': `Bearer ${carrierConfig.apiConfig.apiKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      return this.parseCarrierEvents(carrier, trackingNumber, data);
    } catch (error) {
      console.error(`[TrackingUpdater] Failed to fetch events from ${carrier}:`, error);
      return [];
    }
  }

  /**
   * Parse carrier-specific event format
   */
  private parseCarrierEvents(
    carrier: string,
    trackingNumber: string,
    data: unknown
  ): TrackingEvent[] {
    // Generic parsing - would need carrier-specific implementations
    const events: TrackingEvent[] = [];
    const rawEvents = (data as { events?: unknown[] })?.events || [];

    for (const event of rawEvents) {
      const e = event as Record<string, unknown>;
      events.push({
        id: `${trackingNumber}-${e.timestamp}`,
        orderId: '', // Will be set later
        trackingNumber,
        carrier,
        status: this.mapCarrierStatus(String(e.status || '')),
        location: String(e.location || ''),
        description: String(e.description || ''),
        timestamp: new Date(e.timestamp as string),
        rawData: e,
      });
    }

    return events;
  }

  /**
   * Map carrier status to standard status
   */
  private mapCarrierStatus(status: string): TrackingEventStatus {
    const lowerStatus = status.toLowerCase();

    if (lowerStatus.includes('delivered')) return 'delivered';
    if (lowerStatus.includes('out for delivery')) return 'out_for_delivery';
    if (lowerStatus.includes('transit')) return 'in_transit';
    if (lowerStatus.includes('picked up')) return 'picked_up';
    if (lowerStatus.includes('label')) return 'label_created';
    if (lowerStatus.includes('exception') || lowerStatus.includes('delay')) return 'exception';
    if (lowerStatus.includes('return')) return 'returned_to_sender';

    return 'in_transit';
  }

  /**
   * Process tracking events and update order status
   */
  private async processTrackingEvents(
    orderId: string,
    events: TrackingEvent[]
  ): Promise<void> {
    // Sort events by timestamp
    events.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    // Get the latest event
    const latestEvent = events[0];
    if (!latestEvent) return;

    // Store events
    for (const event of events) {
      await this.storeTrackingEvent(orderId, event);
    }

    // Update order status based on latest event
    const order = await this.getOrder(orderId);
    if (!order) return;

    const previousStatus = order.fulfillmentStatus;
    let newStatus = order.fulfillmentStatus;
    let notificationTrigger: NotificationTrigger | null = null;

    switch (latestEvent.status) {
      case 'delivered':
        newStatus = 'delivered';
        notificationTrigger = 'delivered';
        break;
      case 'out_for_delivery':
        notificationTrigger = 'out_for_delivery';
        break;
      case 'exception':
        // Keep current status but notify
        break;
      case 'returned_to_sender':
        newStatus = 'failed';
        break;
    }

    if (newStatus !== previousStatus) {
      await this.supabase
        .from('unified_orders')
        .update({
          fulfillment_status: newStatus,
          delivered_at: newStatus === 'delivered' ? new Date().toISOString() : undefined,
          updated_at: new Date().toISOString(),
        })
        .eq('id', orderId);

      await this.logAudit(orderId, 'status_updated', {
        previousStatus,
        newStatus,
        trackingEvent: latestEvent.status,
      });

      this.emitEvent(`order:${newStatus}` as FulfillmentEvent['type'], {
        orderId,
        trackingStatus: latestEvent.status,
      });
    }

    // Send customer notification if applicable
    if (notificationTrigger) {
      await this.sendStatusNotification(order, notificationTrigger, latestEvent);
    }
  }

  /**
   * Store tracking event in database
   */
  private async storeTrackingEvent(orderId: string, event: TrackingEvent): Promise<void> {
    const { error } = await this.supabase
      .from('tracking_events')
      .upsert({
        id: event.id,
        order_id: orderId,
        tracking_number: event.trackingNumber,
        carrier: event.carrier,
        status: event.status,
        location: event.location,
        description: event.description,
        timestamp: event.timestamp.toISOString(),
        raw_data: event.rawData,
      }, { onConflict: 'id' });

    if (error) {
      console.error('[TrackingUpdater] Failed to store tracking event:', error);
    }
  }

  // ============================================================================
  // Tracking Info Enrichment
  // ============================================================================

  /**
   * Enrich tracking info with tracking URL
   */
  private enrichTrackingInfo(trackingInfo: TrackingInfo): TrackingInfo {
    if (trackingInfo.trackingUrl) {
      return trackingInfo;
    }

    const carrierConfig = this.carriers.get(trackingInfo.carrier);
    if (carrierConfig && carrierConfig.trackingUrlPattern) {
      return {
        ...trackingInfo,
        trackingUrl: carrierConfig.trackingUrlPattern.replace(
          '{tracking_number}',
          trackingInfo.trackingNumber
        ),
      };
    }

    // Default tracking URL patterns
    const defaultPatterns: Record<string, string> = {
      'usps': 'https://tools.usps.com/go/TrackConfirmAction?tLabels={tracking_number}',
      'ups': 'https://www.ups.com/track?tracknum={tracking_number}',
      'fedex': 'https://www.fedex.com/fedextrack/?trknbr={tracking_number}',
      'dhl': 'https://www.dhl.com/en/express/tracking.html?AWB={tracking_number}',
      'usps_first_class': 'https://tools.usps.com/go/TrackConfirmAction?tLabels={tracking_number}',
      'usps_priority': 'https://tools.usps.com/go/TrackConfirmAction?tLabels={tracking_number}',
    };

    const carrier = trackingInfo.carrier.toLowerCase().replace(/[^a-z]/g, '_');
    const pattern = defaultPatterns[carrier];

    if (pattern) {
      return {
        ...trackingInfo,
        trackingUrl: pattern.replace('{tracking_number}', trackingInfo.trackingNumber),
      };
    }

    return trackingInfo;
  }

  // ============================================================================
  // Customer Notifications
  // ============================================================================

  /**
   * Send tracking notification to customer
   */
  private async sendTrackingNotification(
    order: UnifiedOrder,
    trackingInfo: TrackingInfo
  ): Promise<boolean> {
    if (!order.customer.email) {
      return false;
    }

    try {
      await this.notificationService.notify('order_fulfilled', {
        orderId: order.id,
        email: order.customer.email,
        customerName: order.customer.firstName || 'Customer',
        trackingNumber: trackingInfo.trackingNumber,
        carrier: trackingInfo.carrier,
        trackingUrl: trackingInfo.trackingUrl,
      });

      await this.storeNotification(order.id, 'shipped', order.customer.email);
      return true;
    } catch (error) {
      console.error('[TrackingUpdater] Failed to send tracking notification:', error);
      return false;
    }
  }

  /**
   * Send status notification to customer
   */
  private async sendStatusNotification(
    order: UnifiedOrder,
    trigger: NotificationTrigger,
    event: TrackingEvent
  ): Promise<boolean> {
    if (!order.customer.email) {
      return false;
    }

    try {
      await this.notificationService.notify(trigger as any, {
        orderId: order.id,
        email: order.customer.email,
        customerName: order.customer.firstName || 'Customer',
        trackingNumber: event.trackingNumber,
        carrier: event.carrier,
        location: event.location,
        description: event.description,
      });

      await this.storeNotification(order.id, trigger, order.customer.email);
      return true;
    } catch (error) {
      console.error('[TrackingUpdater] Failed to send status notification:', error);
      return false;
    }
  }

  /**
   * Store notification record
   */
  private async storeNotification(
    orderId: string,
    trigger: NotificationTrigger,
    recipient: string
  ): Promise<void> {
    await this.supabase.from('customer_notifications').insert({
      order_id: orderId,
      trigger,
      channel: 'email',
      recipient,
      status: 'sent',
      sent_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
    });
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private async getCredentials(platform: ConnectorName): Promise<Record<string, string> | null> {
    const { data, error } = await this.supabase
      .from('platform_credentials')
      .select('credentials')
      .eq('platform', platform)
      .eq('enabled', true)
      .single();

    if (error || !data) {
      return null;
    }

    return data.credentials;
  }

  private async getOrder(orderId: string): Promise<UnifiedOrder | null> {
    const { data, error } = await this.supabase
      .from('unified_orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (error || !data) {
      return null;
    }

    return this.mapDbRowToOrder(data);
  }

  private async updateOrderTracking(orderId: string, trackingInfo: TrackingInfo): Promise<void> {
    const { error } = await this.supabase
      .from('unified_orders')
      .update({
        fulfillment: {
          trackingInfo,
          shippedAt: new Date().toISOString(),
        },
        fulfillment_status: 'shipped',
        shipped_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('id', orderId);

    if (error) {
      console.error('[TrackingUpdater] Failed to update order tracking:', error);
    }
  }

  private mapDbRowToOrder(row: Record<string, unknown>): UnifiedOrder {
    return {
      id: row.id as string,
      externalId: row.external_id as string,
      platform: row.platform as ConnectorName,
      status: row.status as any,
      fulfillmentStatus: row.fulfillment_status as any,
      priority: row.priority as any,
      items: row.items as any[],
      shippingAddress: row.shipping_address as any,
      billingAddress: row.billing_address as any,
      customer: row.customer as any,
      pricing: row.pricing as any,
      fulfillment: row.fulfillment as any,
      metadata: (row.metadata as Record<string, unknown>) || {},
      platformData: (row.platform_data as Record<string, unknown>) || {},
      createdAt: new Date(row.created_at as string),
      updatedAt: new Date(row.updated_at as string),
      fulfilledAt: row.fulfilled_at ? new Date(row.fulfilled_at as string) : undefined,
      shippedAt: row.shipped_at ? new Date(row.shipped_at as string) : undefined,
      deliveredAt: row.delivered_at ? new Date(row.delivered_at as string) : undefined,
    };
  }

  private async logAudit(
    orderId: string,
    action: FulfillmentAuditEntry['action'],
    details?: Record<string, unknown>
  ): Promise<void> {
    await this.supabase.from('fulfillment_audit_log').insert({
      order_id: orderId,
      action,
      actor: 'system',
      details,
      timestamp: new Date().toISOString(),
    });
  }

  private emitEvent(type: FulfillmentEvent['type'], payload: Record<string, unknown>): void {
    const event: FulfillmentEvent = {
      type,
      payload,
      timestamp: new Date(),
    };
    this.emit(type, event);
    this.emit('fulfillment:event', event);
  }

  /**
   * Subscribe to fulfillment events
   */
  onEvent(handler: (event: FulfillmentEvent) => void): void {
    this.on('fulfillment:event', handler);
  }

  /**
   * Add carrier configuration
   */
  addCarrier(config: CarrierConfig): void {
    this.carriers.set(config.carrier, config);
  }

  /**
   * Get tracking history for an order
   */
  async getTrackingHistory(orderId: string): Promise<TrackingEvent[]> {
    const { data, error } = await this.supabase
      .from('tracking_events')
      .select('*')
      .eq('order_id', orderId)
      .order('timestamp', { ascending: false });

    if (error || !data) {
      return [];
    }

    return data.map((row) => ({
      id: row.id,
      orderId: row.order_id,
      trackingNumber: row.tracking_number,
      carrier: row.carrier,
      status: row.status,
      location: row.location,
      description: row.description,
      timestamp: new Date(row.timestamp),
      rawData: row.raw_data,
    }));
  }
}

export default TrackingUpdater;
