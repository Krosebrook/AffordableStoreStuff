/**
 * Fulfillment Router
 * Routes orders to appropriate POD providers based on product type, location, and rules
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  UnifiedOrder,
  UnifiedOrderItem,
  FulfillmentProvider,
  RoutingDecision,
  RoutingResult,
  RoutingError,
  RoutingRules,
  RoutingRule,
  RoutingCondition,
  FulfillmentPriority,
  FulfillmentEvent,
  FulfillmentAuditEntry,
  ShippingZoneCost,
} from './types';
import { ProductType } from '../../connectors/core/types';
import { ConnectorName } from '../../connectors/index';

// ============================================================================
// Fulfillment Router Class
// ============================================================================

export class FulfillmentRouter extends EventEmitter {
  private supabase: SupabaseClient;
  private providers: Map<string, FulfillmentProvider>;
  private rules: RoutingRules;
  private routingCache: Map<string, RoutingDecision>;
  private cacheTimeout: number = 5 * 60 * 1000; // 5 minutes

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    providers: FulfillmentProvider[],
    rules: RoutingRules
  ) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.providers = new Map(providers.map((p) => [p.id, p]));
    this.rules = rules;
    this.routingCache = new Map();
  }

  // ============================================================================
  // Routing Methods
  // ============================================================================

  /**
   * Route an entire order to appropriate providers
   */
  async routeOrder(order: UnifiedOrder): Promise<RoutingResult> {
    const decisions: RoutingDecision[] = [];
    const errors: RoutingError[] = [];
    let totalEstimatedCost = 0;
    let maxEstimatedDays = 0;

    for (const item of order.items) {
      try {
        const decision = await this.routeItem(order, item);
        decisions.push(decision);
        totalEstimatedCost += decision.estimatedCost * item.quantity;
        maxEstimatedDays = Math.max(maxEstimatedDays, decision.estimatedDays);
      } catch (error) {
        errors.push({
          itemId: item.id,
          code: 'ROUTING_FAILED',
          message: error instanceof Error ? error.message : 'Unknown error',
          suggestion: 'Check if provider supports this product type',
        });
      }
    }

    const result: RoutingResult = {
      success: errors.length === 0,
      orderId: order.id,
      decisions,
      totalEstimatedCost,
      totalEstimatedDays: maxEstimatedDays,
      warnings: this.generateWarnings(order, decisions),
      errors: errors.length > 0 ? errors : undefined,
    };

    // Log audit entry
    await this.logAudit(order.id, 'order_routed', {
      decisions: decisions.map((d) => ({
        itemId: d.itemId,
        providerId: d.providerId,
      })),
      totalCost: totalEstimatedCost,
      estimatedDays: maxEstimatedDays,
    });

    // Emit event
    this.emitEvent('order:routed', {
      orderId: order.id,
      decisions: decisions.length,
      providers: [...new Set(decisions.map((d) => d.providerId))],
    });

    return result;
  }

  /**
   * Route a single order item
   */
  async routeItem(order: UnifiedOrder, item: UnifiedOrderItem): Promise<RoutingDecision> {
    // Check cache first
    const cacheKey = this.getCacheKey(order, item);
    const cached = this.routingCache.get(cacheKey);
    if (cached) {
      return cached;
    }

    // Find matching rule
    const matchingRule = this.findMatchingRule(order, item);

    // Get provider from rule or find best provider
    let providerId: string;
    let reason: string;

    if (matchingRule) {
      providerId = matchingRule.action.providerId;
      reason = `Matched rule: ${matchingRule.name}`;
    } else {
      const bestProvider = this.findBestProvider(order, item);
      if (!bestProvider) {
        throw new Error(`No suitable provider found for item: ${item.title}`);
      }
      providerId = bestProvider.id;
      reason = 'Auto-selected based on product type and location';
    }

    const provider = this.providers.get(providerId);
    if (!provider || !provider.enabled) {
      // Try fallback provider
      const fallbackId = this.rules.fallbackProviderId || this.rules.defaultProviderId;
      const fallback = this.providers.get(fallbackId);
      if (!fallback || !fallback.enabled) {
        throw new Error(`Provider ${providerId} is not available and no fallback configured`);
      }
      providerId = fallbackId;
      reason = `Fallback to ${fallback.name} (primary provider unavailable)`;
    }

    const selectedProvider = this.providers.get(providerId)!;
    const shippingCost = this.calculateShippingCost(selectedProvider, order.shippingAddress.country);
    const estimatedDays = this.getEstimatedDays(selectedProvider, order.shippingAddress.country);

    const decision: RoutingDecision = {
      orderId: order.id,
      itemId: item.id,
      providerId,
      providerName: selectedProvider.name,
      reason,
      alternativeProviders: this.getAlternativeProviders(item, providerId),
      estimatedCost: selectedProvider.costConfig.perItemCost + shippingCost,
      estimatedDays,
      confidence: matchingRule ? 1.0 : 0.8,
    };

    // Cache the decision
    this.routingCache.set(cacheKey, decision);
    setTimeout(() => this.routingCache.delete(cacheKey), this.cacheTimeout);

    return decision;
  }

  /**
   * Find matching routing rule for an item
   */
  private findMatchingRule(order: UnifiedOrder, item: UnifiedOrderItem): RoutingRule | null {
    // Sort rules by priority (highest first)
    const sortedRules = [...this.rules.rules]
      .filter((r) => r.enabled)
      .sort((a, b) => b.priority - a.priority);

    for (const rule of sortedRules) {
      if (this.ruleMatches(rule, order, item)) {
        return rule;
      }
    }

    return null;
  }

  /**
   * Check if a rule matches the order/item
   */
  private ruleMatches(rule: RoutingRule, order: UnifiedOrder, item: UnifiedOrderItem): boolean {
    return rule.conditions.every((condition) =>
      this.conditionMatches(condition, order, item)
    );
  }

  /**
   * Check if a single condition matches
   */
  private conditionMatches(
    condition: RoutingCondition,
    order: UnifiedOrder,
    item: UnifiedOrderItem
  ): boolean {
    let fieldValue: unknown;

    switch (condition.field) {
      case 'productType':
        fieldValue = item.productType;
        break;
      case 'country':
        fieldValue = order.shippingAddress.country;
        break;
      case 'region':
        fieldValue = this.getRegion(order.shippingAddress.country);
        break;
      case 'orderValue':
        fieldValue = order.pricing.total;
        break;
      case 'platform':
        fieldValue = order.platform;
        break;
      case 'sku':
        fieldValue = item.sku;
        break;
      case 'quantity':
        fieldValue = item.quantity;
        break;
      default:
        return false;
    }

    switch (condition.operator) {
      case 'equals':
        return fieldValue === condition.value;
      case 'notEquals':
        return fieldValue !== condition.value;
      case 'contains':
        return String(fieldValue).includes(String(condition.value));
      case 'in':
        return Array.isArray(condition.value) && condition.value.includes(fieldValue);
      case 'greaterThan':
        return typeof fieldValue === 'number' && fieldValue > (condition.value as number);
      case 'lessThan':
        return typeof fieldValue === 'number' && fieldValue < (condition.value as number);
      default:
        return false;
    }
  }

  /**
   * Find the best provider for an item based on various factors
   */
  private findBestProvider(
    order: UnifiedOrder,
    item: UnifiedOrderItem
  ): FulfillmentProvider | null {
    const eligibleProviders = Array.from(this.providers.values())
      .filter((p) => p.enabled)
      .filter((p) => p.productTypes.includes(item.productType))
      .filter((p) => this.providerServesRegion(p, order.shippingAddress.country));

    if (eligibleProviders.length === 0) {
      return null;
    }

    // Score providers based on multiple factors
    const scoredProviders = eligibleProviders.map((provider) => ({
      provider,
      score: this.scoreProvider(provider, order, item),
    }));

    // Sort by score descending
    scoredProviders.sort((a, b) => b.score - a.score);

    return scoredProviders[0].provider;
  }

  /**
   * Score a provider based on various factors
   */
  private scoreProvider(
    provider: FulfillmentProvider,
    order: UnifiedOrder,
    item: UnifiedOrderItem
  ): number {
    let score = 0;

    // Priority weight (0-100)
    score += provider.priority * 10;

    // Cost efficiency (lower cost = higher score)
    const cost = provider.costConfig.perItemCost +
      this.calculateShippingCost(provider, order.shippingAddress.country);
    score += Math.max(0, 50 - cost);

    // Delivery time (faster = higher score)
    const days = this.getEstimatedDays(provider, order.shippingAddress.country);
    score += Math.max(0, 20 - days * 2);

    // Platform affinity (if provider is associated with order platform)
    if (provider.platforms.includes(order.platform)) {
      score += 15;
    }

    // Rush capability for high priority orders
    if (order.priority === 'urgent' && provider.capabilities.supportsRush) {
      score += 25;
    }

    return score;
  }

  /**
   * Check if provider serves a region/country
   */
  private providerServesRegion(provider: FulfillmentProvider, country: string): boolean {
    // Check direct country match in regions
    if (provider.regions.includes(country)) {
      return true;
    }

    // Check shipping zones
    for (const zone of provider.costConfig.shippingZones) {
      if (zone.countries.includes(country)) {
        return true;
      }
    }

    // Check region groups (e.g., 'US', 'EU', 'APAC')
    const region = this.getRegion(country);
    if (provider.regions.includes(region)) {
      return true;
    }

    return false;
  }

  /**
   * Get region for a country
   */
  private getRegion(country: string): string {
    const regionMap: Record<string, string[]> = {
      'NA': ['US', 'CA', 'MX'],
      'EU': ['GB', 'DE', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'PL', 'SE', 'DK', 'NO', 'FI', 'PT', 'IE', 'CZ', 'RO', 'HU', 'GR'],
      'APAC': ['AU', 'NZ', 'JP', 'KR', 'SG', 'HK', 'TW', 'MY', 'TH', 'PH', 'ID', 'VN', 'IN'],
      'LATAM': ['BR', 'AR', 'CL', 'CO', 'PE', 'VE'],
      'MEA': ['AE', 'SA', 'IL', 'ZA', 'EG', 'NG', 'KE'],
    };

    for (const [region, countries] of Object.entries(regionMap)) {
      if (countries.includes(country)) {
        return region;
      }
    }

    return 'OTHER';
  }

  /**
   * Calculate shipping cost for a provider and country
   */
  private calculateShippingCost(provider: FulfillmentProvider, country: string): number {
    const zone = this.findShippingZone(provider, country);
    if (zone) {
      return zone.baseCost;
    }
    // Default to base cost if no zone found
    return provider.costConfig.baseCost;
  }

  /**
   * Get estimated delivery days
   */
  private getEstimatedDays(provider: FulfillmentProvider, country: string): number {
    const zone = this.findShippingZone(provider, country);
    if (zone) {
      return zone.estimatedDays;
    }
    // Default estimate
    return 7;
  }

  /**
   * Find shipping zone for a country
   */
  private findShippingZone(provider: FulfillmentProvider, country: string): ShippingZoneCost | null {
    for (const zone of provider.costConfig.shippingZones) {
      if (zone.countries.includes(country)) {
        return zone;
      }
    }
    return null;
  }

  /**
   * Get alternative providers for an item
   */
  private getAlternativeProviders(item: UnifiedOrderItem, excludeId: string): string[] {
    return Array.from(this.providers.values())
      .filter((p) => p.enabled && p.id !== excludeId)
      .filter((p) => p.productTypes.includes(item.productType))
      .sort((a, b) => b.priority - a.priority)
      .slice(0, 3)
      .map((p) => p.id);
  }

  /**
   * Generate warnings for routing decisions
   */
  private generateWarnings(order: UnifiedOrder, decisions: RoutingDecision[]): string[] {
    const warnings: string[] = [];

    // Check for multiple providers (split shipment)
    const uniqueProviders = new Set(decisions.map((d) => d.providerId));
    if (uniqueProviders.size > 1) {
      warnings.push(
        `Order will be split across ${uniqueProviders.size} providers, which may result in multiple shipments`
      );
    }

    // Check for low confidence decisions
    const lowConfidence = decisions.filter((d) => d.confidence < 0.7);
    if (lowConfidence.length > 0) {
      warnings.push(
        `${lowConfidence.length} item(s) have low routing confidence - manual review recommended`
      );
    }

    // Check for high cost
    const totalCost = decisions.reduce((sum, d) => sum + d.estimatedCost, 0);
    if (totalCost > order.pricing.subtotal * 0.5) {
      warnings.push('Fulfillment cost exceeds 50% of order subtotal');
    }

    // Check for long delivery time
    const maxDays = Math.max(...decisions.map((d) => d.estimatedDays));
    if (maxDays > 14) {
      warnings.push(`Estimated delivery time is ${maxDays} days - consider faster options`);
    }

    return warnings;
  }

  /**
   * Get cache key for routing decision
   */
  private getCacheKey(order: UnifiedOrder, item: UnifiedOrderItem): string {
    return `${item.productType}-${order.shippingAddress.country}-${order.priority}`;
  }

  // ============================================================================
  // Provider Management
  // ============================================================================

  /**
   * Add or update a provider
   */
  addProvider(provider: FulfillmentProvider): void {
    this.providers.set(provider.id, provider);
    this.clearCache();
  }

  /**
   * Remove a provider
   */
  removeProvider(providerId: string): void {
    this.providers.delete(providerId);
    this.clearCache();
  }

  /**
   * Enable/disable a provider
   */
  setProviderEnabled(providerId: string, enabled: boolean): void {
    const provider = this.providers.get(providerId);
    if (provider) {
      provider.enabled = enabled;
      this.clearCache();
    }
  }

  /**
   * Get provider by ID
   */
  getProvider(providerId: string): FulfillmentProvider | undefined {
    return this.providers.get(providerId);
  }

  /**
   * Get all providers
   */
  getAllProviders(): FulfillmentProvider[] {
    return Array.from(this.providers.values());
  }

  /**
   * Get enabled providers
   */
  getEnabledProviders(): FulfillmentProvider[] {
    return Array.from(this.providers.values()).filter((p) => p.enabled);
  }

  // ============================================================================
  // Rule Management
  // ============================================================================

  /**
   * Add a routing rule
   */
  addRule(rule: RoutingRule): void {
    this.rules.rules.push(rule);
    this.clearCache();
  }

  /**
   * Remove a routing rule
   */
  removeRule(ruleId: string): void {
    this.rules.rules = this.rules.rules.filter((r) => r.id !== ruleId);
    this.clearCache();
  }

  /**
   * Update a routing rule
   */
  updateRule(ruleId: string, updates: Partial<RoutingRule>): void {
    const index = this.rules.rules.findIndex((r) => r.id === ruleId);
    if (index !== -1) {
      this.rules.rules[index] = { ...this.rules.rules[index], ...updates };
      this.clearCache();
    }
  }

  /**
   * Get all rules
   */
  getRules(): RoutingRule[] {
    return this.rules.rules;
  }

  // ============================================================================
  // Batch Routing
  // ============================================================================

  /**
   * Route multiple orders
   */
  async routeOrders(orders: UnifiedOrder[]): Promise<Map<string, RoutingResult>> {
    const results = new Map<string, RoutingResult>();

    // Process in parallel with concurrency limit
    const batchSize = 10;
    for (let i = 0; i < orders.length; i += batchSize) {
      const batch = orders.slice(i, i + batchSize);
      const batchResults = await Promise.all(
        batch.map((order) => this.routeOrder(order))
      );

      batch.forEach((order, index) => {
        results.set(order.id, batchResults[index]);
      });
    }

    return results;
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  /**
   * Get routing statistics
   */
  async getRoutingStats(
    startDate: Date,
    endDate: Date
  ): Promise<{
    totalRouted: number;
    byProvider: Record<string, number>;
    byProductType: Record<string, number>;
    averageCost: number;
    averageDays: number;
    ruleHitRate: number;
  }> {
    const { data } = await this.supabase
      .from('routing_decisions')
      .select('*')
      .gte('created_at', startDate.toISOString())
      .lte('created_at', endDate.toISOString());

    if (!data || data.length === 0) {
      return {
        totalRouted: 0,
        byProvider: {},
        byProductType: {},
        averageCost: 0,
        averageDays: 0,
        ruleHitRate: 0,
      };
    }

    const byProvider: Record<string, number> = {};
    const byProductType: Record<string, number> = {};
    let totalCost = 0;
    let totalDays = 0;
    let ruleMatches = 0;

    for (const decision of data) {
      byProvider[decision.provider_id] = (byProvider[decision.provider_id] || 0) + 1;
      byProductType[decision.product_type] = (byProductType[decision.product_type] || 0) + 1;
      totalCost += decision.estimated_cost || 0;
      totalDays += decision.estimated_days || 0;
      if (decision.confidence >= 1.0) {
        ruleMatches++;
      }
    }

    return {
      totalRouted: data.length,
      byProvider,
      byProductType,
      averageCost: totalCost / data.length,
      averageDays: totalDays / data.length,
      ruleHitRate: ruleMatches / data.length,
    };
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private clearCache(): void {
    this.routingCache.clear();
  }

  private async logAudit(
    orderId: string,
    action: FulfillmentAuditEntry['action'],
    details?: Record<string, unknown>
  ): Promise<void> {
    await this.supabase.from('fulfillment_audit_log').insert({
      order_id: orderId,
      action,
      actor: 'system',
      details,
      timestamp: new Date().toISOString(),
    });
  }

  private emitEvent(type: FulfillmentEvent['type'], payload: Record<string, unknown>): void {
    const event: FulfillmentEvent = {
      type,
      payload,
      timestamp: new Date(),
    };
    this.emit(type, event);
    this.emit('fulfillment:event', event);
  }

  /**
   * Subscribe to fulfillment events
   */
  onEvent(handler: (event: FulfillmentEvent) => void): void {
    this.on('fulfillment:event', handler);
  }
}

export default FulfillmentRouter;
