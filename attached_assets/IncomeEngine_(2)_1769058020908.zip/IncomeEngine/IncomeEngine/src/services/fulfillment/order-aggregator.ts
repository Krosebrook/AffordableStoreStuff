/**
 * Order Aggregator
 * Collects orders from all connected platforms into a unified format
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  createConnector,
  ConnectorName,
  BaseConnector,
  Order,
  OrderStatus,
  OrderItem,
} from '../../connectors/index';
import { NotificationService, WebhookPayload } from '../../connectors/utils/webhook';
import {
  UnifiedOrder,
  UnifiedOrderItem,
  OrderAggregationConfig,
  OrderAggregationResult,
  PlatformOrderResult,
  OrderAggregationError,
  FulfillmentStatus,
  FulfillmentPriority,
  FulfillmentEvent,
  FulfillmentEventHandler,
  FulfillmentAuditEntry,
  CustomerInfo,
  OrderPricing,
} from './types';
import { ProductType } from '../../connectors/core/types';

// ============================================================================
// Order Aggregator Class
// ============================================================================

export class OrderAggregator extends EventEmitter {
  private supabase: SupabaseClient;
  private notificationService: NotificationService;
  private connectors: Map<ConnectorName, BaseConnector>;
  private config: OrderAggregationConfig;
  private pollInterval: NodeJS.Timeout | null = null;
  private isRunning: boolean = false;
  private lastSyncTimes: Map<ConnectorName, Date>;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    config: OrderAggregationConfig
  ) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.notificationService = new NotificationService(supabaseUrl, supabaseKey);
    this.connectors = new Map();
    this.config = config;
    this.lastSyncTimes = new Map();
  }

  // ============================================================================
  // Lifecycle Methods
  // ============================================================================

  /**
   * Initialize connectors for all configured platforms
   */
  async initialize(): Promise<void> {
    for (const platform of this.config.platforms) {
      try {
        const credentials = await this.getCredentials(platform);
        if (credentials) {
          const connector = createConnector(platform, {
            platform,
            credentials,
          });
          await connector.authenticate();
          this.connectors.set(platform, connector);
          console.log(`[OrderAggregator] Initialized connector for ${platform}`);
        }
      } catch (error) {
        console.error(`[OrderAggregator] Failed to initialize ${platform}:`, error);
      }
    }
  }

  /**
   * Start polling for orders
   */
  start(): void {
    if (this.isRunning) {
      console.warn('[OrderAggregator] Already running');
      return;
    }

    this.isRunning = true;
    this.notificationService.start();

    // Initial aggregation
    this.aggregateOrders();

    // Set up polling interval
    this.pollInterval = setInterval(() => {
      this.aggregateOrders();
    }, this.config.pollIntervalMs);

    console.log('[OrderAggregator] Started with interval:', this.config.pollIntervalMs);
  }

  /**
   * Stop polling for orders
   */
  stop(): void {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    this.isRunning = false;
    this.notificationService.stop();
    console.log('[OrderAggregator] Stopped');
  }

  // ============================================================================
  // Order Aggregation
  // ============================================================================

  /**
   * Aggregate orders from all platforms
   */
  async aggregateOrders(): Promise<OrderAggregationResult> {
    const startTime = Date.now();
    const allOrders: UnifiedOrder[] = [];
    const byPlatform: Record<string, PlatformOrderResult> = {};
    const errors: OrderAggregationError[] = [];

    const platforms = Array.from(this.connectors.keys());

    // Fetch orders from all platforms in parallel
    const results = await Promise.allSettled(
      platforms.map((platform) => this.fetchPlatformOrders(platform))
    );

    for (let i = 0; i < platforms.length; i++) {
      const platform = platforms[i];
      const result = results[i];

      if (result.status === 'fulfilled') {
        const platformResult = result.value;
        byPlatform[platform] = platformResult;

        if (platformResult.success) {
          // Get the actual orders from database that were just synced
          const { data: orders } = await this.supabase
            .from('unified_orders')
            .select('*')
            .eq('platform', platform)
            .gte('updated_at', new Date(startTime - this.config.pollIntervalMs).toISOString())
            .order('created_at', { ascending: false })
            .limit(this.config.batchSize);

          if (orders) {
            allOrders.push(...orders.map(this.mapDbRowToOrder));
          }
        }
      } else {
        errors.push({
          platform,
          code: 'FETCH_FAILED',
          message: result.reason?.message || 'Unknown error',
          retryable: true,
          timestamp: new Date(),
        });

        byPlatform[platform] = {
          platform,
          success: false,
          orderCount: 0,
          newOrderCount: 0,
          updatedOrderCount: 0,
          error: result.reason?.message,
          lastSyncAt: this.lastSyncTimes.get(platform) || new Date(),
        };
      }
    }

    const aggregationResult: OrderAggregationResult = {
      success: errors.length === 0,
      orders: allOrders,
      byPlatform: byPlatform as Record<ConnectorName, PlatformOrderResult>,
      errors,
      timestamp: new Date(),
      duration: Date.now() - startTime,
    };

    // Emit aggregation event
    this.emitEvent('order:aggregated', {
      orderCount: allOrders.length,
      platforms: platforms.length,
      errors: errors.length,
    });

    return aggregationResult;
  }

  /**
   * Fetch orders from a single platform
   */
  private async fetchPlatformOrders(platform: ConnectorName): Promise<PlatformOrderResult> {
    const connector = this.connectors.get(platform);
    if (!connector) {
      return {
        platform,
        success: false,
        orderCount: 0,
        newOrderCount: 0,
        updatedOrderCount: 0,
        error: 'Connector not initialized',
        lastSyncAt: new Date(),
      };
    }

    try {
      const lastSync = this.lastSyncTimes.get(platform);
      const lookbackMs = (this.config.lookbackHours || 24) * 60 * 60 * 1000;

      // Fetch orders from platform
      const result = await connector.listOrders({
        limit: this.config.batchSize,
        filters: this.config.filterStatuses
          ? { status: this.config.filterStatuses }
          : undefined,
      });

      if (!result.success || !result.data) {
        return {
          platform,
          success: false,
          orderCount: 0,
          newOrderCount: 0,
          updatedOrderCount: 0,
          error: result.error?.message || 'Failed to fetch orders',
          lastSyncAt: lastSync || new Date(),
        };
      }

      // Process and store orders
      let newCount = 0;
      let updatedCount = 0;

      for (const order of result.data.items) {
        const unifiedOrder = this.normalizeOrder(order, platform);
        const { isNew } = await this.upsertOrder(unifiedOrder);
        if (isNew) {
          newCount++;
          // Emit new order event
          this.emitEvent('order:received', { orderId: unifiedOrder.id, platform });
        } else {
          updatedCount++;
        }
      }

      // Update last sync time
      this.lastSyncTimes.set(platform, new Date());

      return {
        platform,
        success: true,
        orderCount: result.data.items.length,
        newOrderCount: newCount,
        updatedOrderCount: updatedCount,
        lastSyncAt: new Date(),
      };
    } catch (error) {
      console.error(`[OrderAggregator] Error fetching orders from ${platform}:`, error);
      return {
        platform,
        success: false,
        orderCount: 0,
        newOrderCount: 0,
        updatedOrderCount: 0,
        error: error instanceof Error ? error.message : 'Unknown error',
        lastSyncAt: this.lastSyncTimes.get(platform) || new Date(),
      };
    }
  }

  /**
   * Normalize platform-specific order to unified format
   */
  private normalizeOrder(order: Order, platform: ConnectorName): UnifiedOrder {
    return {
      id: `${platform}-${order.externalId}`,
      externalId: order.externalId,
      platform,
      status: order.status,
      fulfillmentStatus: this.mapToFulfillmentStatus(order.status),
      priority: this.determinePriority(order),
      items: order.items.map((item) => this.normalizeOrderItem(item, platform)),
      shippingAddress: order.shippingAddress,
      customer: this.extractCustomerInfo(order),
      pricing: {
        subtotal: order.subtotal,
        shippingCost: order.shippingCost,
        tax: order.tax,
        discount: 0, // Not always available in Order type
        total: order.total,
        currency: order.currency,
      },
      metadata: {},
      platformData: {},
      createdAt: order.createdAt,
      updatedAt: order.updatedAt,
    };
  }

  /**
   * Normalize order item
   */
  private normalizeOrderItem(item: OrderItem, platform: ConnectorName): UnifiedOrderItem {
    return {
      id: `${platform}-${item.id}`,
      externalId: item.id,
      productId: item.productId,
      variantId: item.variantId,
      sku: item.sku,
      title: item.title,
      quantity: item.quantity,
      price: item.price,
      productType: this.inferProductType(item),
      fulfillmentStatus: 'pending',
    };
  }

  /**
   * Extract customer info from order
   */
  private extractCustomerInfo(order: Order): CustomerInfo {
    return {
      email: '', // Would need to be extracted from platform-specific data
      firstName: order.shippingAddress.name.split(' ')[0],
      lastName: order.shippingAddress.name.split(' ').slice(1).join(' '),
      phone: order.shippingAddress.phone,
    };
  }

  /**
   * Map order status to fulfillment status
   */
  private mapToFulfillmentStatus(status: OrderStatus): FulfillmentStatus {
    const statusMap: Record<OrderStatus, FulfillmentStatus> = {
      pending: 'pending',
      processing: 'processing',
      shipped: 'shipped',
      delivered: 'delivered',
      cancelled: 'cancelled',
      refunded: 'cancelled',
    };
    return statusMap[status] || 'pending';
  }

  /**
   * Determine order priority based on various factors
   */
  private determinePriority(order: Order): FulfillmentPriority {
    // High value orders get higher priority
    if (order.total > 200) return 'high';
    if (order.total > 100) return 'normal';

    // Could add more rules like:
    // - Repeat customers
    // - Express shipping selected
    // - Promotional orders

    return 'normal';
  }

  /**
   * Infer product type from order item
   */
  private inferProductType(item: OrderItem): ProductType {
    const title = item.title.toLowerCase();
    const sku = (item.sku || '').toLowerCase();

    if (title.includes('shirt') || title.includes('tee') || sku.startsWith('ts-')) return 't-shirt';
    if (title.includes('hoodie') || sku.startsWith('hd-')) return 'hoodie';
    if (title.includes('mug') || sku.startsWith('mg-')) return 'mug';
    if (title.includes('poster') || sku.startsWith('ps-')) return 'poster';
    if (title.includes('sticker') || sku.startsWith('st-')) return 'sticker';
    if (title.includes('phone') || title.includes('case') || sku.startsWith('pc-')) return 'phone-case';
    if (title.includes('tote') || title.includes('bag') || sku.startsWith('tb-')) return 'tote-bag';

    return 'other';
  }

  // ============================================================================
  // Database Operations
  // ============================================================================

  /**
   * Upsert unified order to database
   */
  private async upsertOrder(order: UnifiedOrder): Promise<{ isNew: boolean }> {
    // Check if order exists
    const { data: existing } = await this.supabase
      .from('unified_orders')
      .select('id')
      .eq('id', order.id)
      .single();

    const isNew = !existing;

    const row = this.mapOrderToDbRow(order);

    const { error } = await this.supabase
      .from('unified_orders')
      .upsert(row, { onConflict: 'id' });

    if (error) {
      console.error('[OrderAggregator] Failed to upsert order:', error);
      throw error;
    }

    // Log audit entry
    await this.logAudit(order.id, isNew ? 'order_created' : 'order_updated', {
      platform: order.platform,
      status: order.status,
    });

    return { isNew };
  }

  /**
   * Get unified order by ID
   */
  async getOrder(orderId: string): Promise<UnifiedOrder | null> {
    const { data, error } = await this.supabase
      .from('unified_orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (error || !data) {
      return null;
    }

    return this.mapDbRowToOrder(data);
  }

  /**
   * Get orders by status
   */
  async getOrdersByStatus(
    status: FulfillmentStatus | FulfillmentStatus[],
    options: {
      platform?: ConnectorName;
      limit?: number;
      offset?: number;
    } = {}
  ): Promise<UnifiedOrder[]> {
    const statuses = Array.isArray(status) ? status : [status];

    let query = this.supabase
      .from('unified_orders')
      .select('*')
      .in('fulfillment_status', statuses)
      .order('created_at', { ascending: false });

    if (options.platform) {
      query = query.eq('platform', options.platform);
    }

    if (options.limit) {
      query = query.limit(options.limit);
    }

    if (options.offset) {
      query = query.range(options.offset, options.offset + (options.limit || 10) - 1);
    }

    const { data, error } = await query;

    if (error) {
      console.error('[OrderAggregator] Failed to fetch orders:', error);
      return [];
    }

    return (data || []).map(this.mapDbRowToOrder);
  }

  /**
   * Get pending orders ready for fulfillment
   */
  async getPendingOrders(limit: number = 50): Promise<UnifiedOrder[]> {
    return this.getOrdersByStatus(['pending', 'processing'], { limit });
  }

  /**
   * Update order fulfillment status
   */
  async updateOrderStatus(
    orderId: string,
    status: FulfillmentStatus,
    details?: Record<string, unknown>
  ): Promise<boolean> {
    const { error } = await this.supabase
      .from('unified_orders')
      .update({
        fulfillment_status: status,
        updated_at: new Date().toISOString(),
        ...details,
      })
      .eq('id', orderId);

    if (error) {
      console.error('[OrderAggregator] Failed to update order status:', error);
      return false;
    }

    await this.logAudit(orderId, 'status_updated', { newStatus: status, ...details });

    return true;
  }

  // ============================================================================
  // Webhook Handling
  // ============================================================================

  /**
   * Process incoming webhook from platform
   */
  async processWebhook(
    platform: ConnectorName,
    eventType: string,
    payload: Record<string, unknown>
  ): Promise<void> {
    if (!this.config.enableWebhooks) {
      return;
    }

    console.log(`[OrderAggregator] Processing webhook from ${platform}: ${eventType}`);

    switch (eventType) {
      case 'order.created':
      case 'order.paid':
        await this.handleNewOrderWebhook(platform, payload);
        break;
      case 'order.updated':
        await this.handleOrderUpdateWebhook(platform, payload);
        break;
      case 'order.cancelled':
        await this.handleOrderCancelledWebhook(platform, payload);
        break;
      case 'order.fulfilled':
        await this.handleOrderFulfilledWebhook(platform, payload);
        break;
      default:
        console.log(`[OrderAggregator] Unhandled webhook event: ${eventType}`);
    }
  }

  private async handleNewOrderWebhook(
    platform: ConnectorName,
    payload: Record<string, unknown>
  ): Promise<void> {
    const connector = this.connectors.get(platform);
    if (!connector) return;

    // Fetch the full order from the platform
    const orderId = payload.id as string || payload.order_id as string;
    if (!orderId) return;

    const result = await connector.getOrder(orderId);
    if (result.success && result.data) {
      const unifiedOrder = this.normalizeOrder(result.data, platform);
      await this.upsertOrder(unifiedOrder);
      this.emitEvent('order:received', { orderId: unifiedOrder.id, platform });
    }
  }

  private async handleOrderUpdateWebhook(
    platform: ConnectorName,
    payload: Record<string, unknown>
  ): Promise<void> {
    const externalId = payload.id as string || payload.order_id as string;
    const orderId = `${platform}-${externalId}`;

    const order = await this.getOrder(orderId);
    if (order) {
      // Refresh order from platform
      await this.fetchPlatformOrders(platform);
    }
  }

  private async handleOrderCancelledWebhook(
    platform: ConnectorName,
    payload: Record<string, unknown>
  ): Promise<void> {
    const externalId = payload.id as string || payload.order_id as string;
    const orderId = `${platform}-${externalId}`;

    await this.updateOrderStatus(orderId, 'cancelled', {
      cancelled_reason: payload.cancel_reason,
    });

    this.emitEvent('order:cancelled', { orderId, platform });
  }

  private async handleOrderFulfilledWebhook(
    platform: ConnectorName,
    payload: Record<string, unknown>
  ): Promise<void> {
    const externalId = payload.id as string || payload.order_id as string;
    const orderId = `${platform}-${externalId}`;

    await this.updateOrderStatus(orderId, 'shipped');
    this.emitEvent('order:shipped', { orderId, platform });
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private async getCredentials(platform: ConnectorName): Promise<Record<string, string> | null> {
    const { data, error } = await this.supabase
      .from('platform_credentials')
      .select('credentials')
      .eq('platform', platform)
      .eq('enabled', true)
      .single();

    if (error || !data) {
      return null;
    }

    return data.credentials;
  }

  private mapOrderToDbRow(order: UnifiedOrder): Record<string, unknown> {
    return {
      id: order.id,
      external_id: order.externalId,
      platform: order.platform,
      status: order.status,
      fulfillment_status: order.fulfillmentStatus,
      priority: order.priority,
      items: order.items,
      shipping_address: order.shippingAddress,
      billing_address: order.billingAddress,
      customer: order.customer,
      pricing: order.pricing,
      fulfillment: order.fulfillment,
      metadata: order.metadata,
      platform_data: order.platformData,
      created_at: order.createdAt.toISOString(),
      updated_at: new Date().toISOString(),
      fulfilled_at: order.fulfilledAt?.toISOString(),
      shipped_at: order.shippedAt?.toISOString(),
      delivered_at: order.deliveredAt?.toISOString(),
    };
  }

  private mapDbRowToOrder(row: Record<string, unknown>): UnifiedOrder {
    return {
      id: row.id as string,
      externalId: row.external_id as string,
      platform: row.platform as ConnectorName,
      status: row.status as OrderStatus,
      fulfillmentStatus: row.fulfillment_status as FulfillmentStatus,
      priority: row.priority as FulfillmentPriority,
      items: row.items as UnifiedOrderItem[],
      shippingAddress: row.shipping_address as UnifiedOrder['shippingAddress'],
      billingAddress: row.billing_address as UnifiedOrder['billingAddress'],
      customer: row.customer as CustomerInfo,
      pricing: row.pricing as OrderPricing,
      fulfillment: row.fulfillment as UnifiedOrder['fulfillment'],
      metadata: (row.metadata as Record<string, unknown>) || {},
      platformData: (row.platform_data as Record<string, unknown>) || {},
      createdAt: new Date(row.created_at as string),
      updatedAt: new Date(row.updated_at as string),
      fulfilledAt: row.fulfilled_at ? new Date(row.fulfilled_at as string) : undefined,
      shippedAt: row.shipped_at ? new Date(row.shipped_at as string) : undefined,
      deliveredAt: row.delivered_at ? new Date(row.delivered_at as string) : undefined,
    };
  }

  private async logAudit(
    orderId: string,
    action: FulfillmentAuditEntry['action'],
    details?: Record<string, unknown>
  ): Promise<void> {
    await this.supabase.from('fulfillment_audit_log').insert({
      order_id: orderId,
      action,
      actor: 'system',
      details,
      timestamp: new Date().toISOString(),
    });
  }

  private emitEvent(type: FulfillmentEvent['type'], payload: Record<string, unknown>): void {
    const event: FulfillmentEvent = {
      type,
      payload,
      timestamp: new Date(),
    };
    this.emit(type, event);
    this.emit('fulfillment:event', event);
  }

  /**
   * Subscribe to fulfillment events
   */
  onEvent(handler: FulfillmentEventHandler): void {
    this.on('fulfillment:event', handler);
  }

  /**
   * Get aggregation stats
   */
  async getStats(): Promise<{
    totalOrders: number;
    byPlatform: Record<string, number>;
    byStatus: Record<string, number>;
  }> {
    const { data: orders } = await this.supabase
      .from('unified_orders')
      .select('platform, fulfillment_status');

    if (!orders) {
      return { totalOrders: 0, byPlatform: {}, byStatus: {} };
    }

    const byPlatform: Record<string, number> = {};
    const byStatus: Record<string, number> = {};

    for (const order of orders) {
      byPlatform[order.platform] = (byPlatform[order.platform] || 0) + 1;
      byStatus[order.fulfillment_status] = (byStatus[order.fulfillment_status] || 0) + 1;
    }

    return {
      totalOrders: orders.length,
      byPlatform,
      byStatus,
    };
  }
}

export default OrderAggregator;
