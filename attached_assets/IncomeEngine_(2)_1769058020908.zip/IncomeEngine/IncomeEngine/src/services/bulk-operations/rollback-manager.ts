/**
 * Rollback Manager
 * Handle rollback on partial failure for bulk operations
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  BulkOperation,
  BulkOperationItem,
  RollbackData,
  PlatformRollbackData,
  BulkOperationType,
} from './types';
import { ProgressTracker } from './progress-tracker';
import { ConnectorName, createConnector, ConnectorFactoryConfig } from '../../connectors/index';
import { NormalizedProduct, ConnectorError } from '../../connectors/core/types';

// ============================================================================
// Types
// ============================================================================

export interface RollbackResult {
  success: boolean;
  totalItems: number;
  rolledBack: number;
  failed: number;
  skipped: number;
  errors: RollbackError[];
  duration: number;
}

export interface RollbackError {
  itemId: string;
  platform: ConnectorName;
  error: string;
  retryable: boolean;
}

export interface RollbackManagerConfig {
  supabaseUrl: string;
  supabaseKey: string;
  maxConcurrency: number;
  retryAttempts: number;
  retryDelayMs: number;
  connectorConfigs: Map<ConnectorName, ConnectorFactoryConfig>;
}

// ============================================================================
// Rollback Manager Class
// ============================================================================

export class RollbackManager extends EventEmitter {
  private supabase: SupabaseClient;
  private progressTracker: ProgressTracker;
  private config: RollbackManagerConfig;
  private activeRollbacks: Set<string> = new Set();
  private rollbackData: Map<string, Map<string, RollbackData>> = new Map();

  constructor(
    config: RollbackManagerConfig,
    progressTracker?: ProgressTracker
  ) {
    super();
    this.config = config;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
    this.progressTracker = progressTracker || new ProgressTracker(
      config.supabaseUrl,
      config.supabaseKey
    );
  }

  // ============================================================================
  // Rollback Data Management
  // ============================================================================

  /**
   * Store rollback data for an item before making changes
   */
  async storeRollbackData(
    operationId: string,
    item: BulkOperationItem,
    platformData: PlatformRollbackData[]
  ): Promise<void> {
    let operationRollbackData = this.rollbackData.get(operationId);
    if (!operationRollbackData) {
      operationRollbackData = new Map();
      this.rollbackData.set(operationId, operationRollbackData);
    }

    const rollbackData: RollbackData = {
      operationType: item.operationType,
      productId: item.productId,
      platformData,
      createdAt: new Date(),
    };

    operationRollbackData.set(item.id, rollbackData);
    item.rollbackData = rollbackData;

    // Persist to database
    await this.persistRollbackData(operationId, item.id, rollbackData);
  }

  /**
   * Capture current state for rollback (before update/delete)
   */
  async captureCurrentState(
    operationId: string,
    item: BulkOperationItem,
    platforms: ConnectorName[]
  ): Promise<PlatformRollbackData[]> {
    const platformData: PlatformRollbackData[] = [];

    for (const platform of platforms) {
      if (!item.externalId) continue;

      try {
        const connectorConfig = this.config.connectorConfigs.get(platform);
        if (!connectorConfig) continue;

        const connector = createConnector(platform, connectorConfig);
        const result = await connector.getProduct(item.externalId);

        if (result.success && result.data) {
          platformData.push({
            platform,
            externalId: item.externalId,
            previousState: result.data,
            action: this.determineRollbackAction(item.operationType),
            completed: false,
          });
        }
      } catch (error) {
        console.error(`Failed to capture state for ${platform}:`, error);
        // Continue with other platforms
      }
    }

    await this.storeRollbackData(operationId, item, platformData);
    return platformData;
  }

  /**
   * Determine what action to take for rollback
   */
  private determineRollbackAction(
    operationType: BulkOperationType
  ): 'delete' | 'restore' | 'update' {
    switch (operationType) {
      case 'create':
      case 'publish':
        return 'delete'; // Rollback creation by deleting
      case 'delete':
        return 'restore'; // Rollback deletion by restoring
      case 'update':
      case 'sync':
        return 'update'; // Rollback update by restoring previous state
      default:
        return 'update';
    }
  }

  // ============================================================================
  // Rollback Execution
  // ============================================================================

  /**
   * Execute rollback for an entire operation
   */
  async rollbackOperation(operation: BulkOperation): Promise<RollbackResult> {
    const operationId = operation.id;
    const startTime = Date.now();

    if (this.activeRollbacks.has(operationId)) {
      throw new Error(`Rollback already in progress for operation: ${operationId}`);
    }

    this.activeRollbacks.add(operationId);
    await this.progressTracker.startRollback(operationId);

    const result: RollbackResult = {
      success: true,
      totalItems: 0,
      rolledBack: 0,
      failed: 0,
      skipped: 0,
      errors: [],
      duration: 0,
    };

    try {
      // Get all items that need rollback (completed or failed items that made changes)
      const itemsToRollback = operation.items.filter(
        (item) =>
          (item.status === 'completed' || item.status === 'failed') &&
          item.rollbackData &&
          item.rollbackData.platformData.length > 0
      );

      result.totalItems = itemsToRollback.length;

      // Process rollbacks in batches
      const batchSize = this.config.maxConcurrency;
      for (let i = 0; i < itemsToRollback.length; i += batchSize) {
        const batch = itemsToRollback.slice(i, i + batchSize);
        const batchResults = await Promise.allSettled(
          batch.map((item) => this.rollbackItem(operationId, item))
        );

        for (let j = 0; j < batchResults.length; j++) {
          const batchResult = batchResults[j];
          const item = batch[j];

          if (batchResult.status === 'fulfilled') {
            if (batchResult.value.success) {
              result.rolledBack++;
              item.status = 'rolled_back';
            } else {
              result.failed++;
              result.errors.push(...batchResult.value.errors);
            }
          } else {
            result.failed++;
            result.errors.push({
              itemId: item.id,
              platform: item.targetPlatforms[0] || 'printify',
              error: batchResult.reason?.message || 'Unknown error',
              retryable: false,
            });
          }
        }
      }

      result.success = result.failed === 0;
      result.duration = Date.now() - startTime;

      await this.progressTracker.completeRollback(operationId, result.success);
      this.emit('rollback:completed', { operationId, result });

    } catch (error) {
      result.success = false;
      result.duration = Date.now() - startTime;
      result.errors.push({
        itemId: 'operation',
        platform: 'printify',
        error: error instanceof Error ? error.message : 'Unknown error',
        retryable: false,
      });

      await this.progressTracker.completeRollback(operationId, false);
      this.emit('rollback:failed', { operationId, error });

    } finally {
      this.activeRollbacks.delete(operationId);
      this.cleanupRollbackData(operationId);
    }

    return result;
  }

  /**
   * Rollback a single item
   */
  async rollbackItem(
    operationId: string,
    item: BulkOperationItem
  ): Promise<{ success: boolean; errors: RollbackError[] }> {
    const rollbackData = item.rollbackData;
    if (!rollbackData) {
      return { success: true, errors: [] }; // Nothing to rollback
    }

    const errors: RollbackError[] = [];
    let allSuccess = true;

    for (const platformData of rollbackData.platformData) {
      if (platformData.completed) continue; // Already rolled back

      const success = await this.rollbackPlatformChange(
        operationId,
        item.id,
        platformData
      );

      if (success) {
        platformData.completed = true;
      } else {
        allSuccess = false;
        errors.push({
          itemId: item.id,
          platform: platformData.platform,
          error: platformData.error || 'Rollback failed',
          retryable: true,
        });
      }
    }

    return { success: allSuccess, errors };
  }

  /**
   * Rollback a single platform change
   */
  private async rollbackPlatformChange(
    operationId: string,
    itemId: string,
    platformData: PlatformRollbackData
  ): Promise<boolean> {
    const { platform, externalId, previousState, action } = platformData;

    const connectorConfig = this.config.connectorConfigs.get(platform);
    if (!connectorConfig) {
      platformData.error = `No connector config for ${platform}`;
      return false;
    }

    for (let attempt = 0; attempt < this.config.retryAttempts; attempt++) {
      try {
        const connector = createConnector(platform, connectorConfig);

        switch (action) {
          case 'delete':
            // Delete the created product
            const deleteResult = await connector.deleteProduct(externalId);
            if (deleteResult.success) {
              return true;
            }
            platformData.error = deleteResult.error?.message || 'Delete failed';
            break;

          case 'restore':
            // Recreate the deleted product
            if (previousState) {
              const createResult = await connector.createProduct({
                title: previousState.title,
                description: previousState.description,
                productType: previousState.productType,
                images: previousState.images,
                variants: previousState.variants,
                pricing: previousState.pricing,
                tags: previousState.tags,
                metadata: previousState.metadata,
              });
              if (createResult.success) {
                return true;
              }
              platformData.error = createResult.error?.message || 'Restore failed';
            } else {
              platformData.error = 'No previous state to restore';
              return false;
            }
            break;

          case 'update':
            // Restore previous state
            if (previousState) {
              const updateResult = await connector.updateProduct(externalId, {
                title: previousState.title,
                description: previousState.description,
                productType: previousState.productType,
                images: previousState.images,
                variants: previousState.variants,
                pricing: previousState.pricing,
                tags: previousState.tags,
                metadata: previousState.metadata,
              });
              if (updateResult.success) {
                return true;
              }
              platformData.error = updateResult.error?.message || 'Update failed';
            } else {
              platformData.error = 'No previous state to restore';
              return false;
            }
            break;
        }

        // Wait before retry
        if (attempt < this.config.retryAttempts - 1) {
          await this.sleep(this.config.retryDelayMs * Math.pow(2, attempt));
        }
      } catch (error) {
        platformData.error = error instanceof Error ? error.message : 'Unknown error';
        if (attempt < this.config.retryAttempts - 1) {
          await this.sleep(this.config.retryDelayMs * Math.pow(2, attempt));
        }
      }
    }

    return false;
  }

  // ============================================================================
  // Partial Rollback
  // ============================================================================

  /**
   * Rollback specific items only
   */
  async rollbackItems(
    operationId: string,
    itemIds: string[],
    operation: BulkOperation
  ): Promise<RollbackResult> {
    const startTime = Date.now();

    const result: RollbackResult = {
      success: true,
      totalItems: itemIds.length,
      rolledBack: 0,
      failed: 0,
      skipped: 0,
      errors: [],
      duration: 0,
    };

    const itemsToRollback = operation.items.filter(
      (item) => itemIds.includes(item.id) && item.rollbackData
    );

    result.skipped = itemIds.length - itemsToRollback.length;

    for (const item of itemsToRollback) {
      const itemResult = await this.rollbackItem(operationId, item);
      if (itemResult.success) {
        result.rolledBack++;
        item.status = 'rolled_back';
      } else {
        result.failed++;
        result.errors.push(...itemResult.errors);
      }
    }

    result.success = result.failed === 0;
    result.duration = Date.now() - startTime;

    return result;
  }

  /**
   * Rollback specific platforms for an item
   */
  async rollbackPlatforms(
    operationId: string,
    item: BulkOperationItem,
    platforms: ConnectorName[]
  ): Promise<RollbackResult> {
    const startTime = Date.now();

    const result: RollbackResult = {
      success: true,
      totalItems: platforms.length,
      rolledBack: 0,
      failed: 0,
      skipped: 0,
      errors: [],
      duration: 0,
    };

    if (!item.rollbackData) {
      result.skipped = platforms.length;
      result.duration = Date.now() - startTime;
      return result;
    }

    const platformsToRollback = item.rollbackData.platformData.filter(
      (pd) => platforms.includes(pd.platform) && !pd.completed
    );

    result.skipped = platforms.length - platformsToRollback.length;

    for (const platformData of platformsToRollback) {
      const success = await this.rollbackPlatformChange(
        operationId,
        item.id,
        platformData
      );

      if (success) {
        result.rolledBack++;
      } else {
        result.failed++;
        result.errors.push({
          itemId: item.id,
          platform: platformData.platform,
          error: platformData.error || 'Rollback failed',
          retryable: true,
        });
      }
    }

    result.success = result.failed === 0;
    result.duration = Date.now() - startTime;

    return result;
  }

  // ============================================================================
  // Query Methods
  // ============================================================================

  /**
   * Check if rollback is possible for an operation
   */
  canRollback(operation: BulkOperation): boolean {
    const rollbackableStatuses = ['completed', 'partial', 'failed'];
    if (!rollbackableStatuses.includes(operation.status)) {
      return false;
    }

    // Check if any items have rollback data
    return operation.items.some(
      (item) => item.rollbackData && item.rollbackData.platformData.length > 0
    );
  }

  /**
   * Get items that can be rolled back
   */
  getRollbackableItems(operation: BulkOperation): BulkOperationItem[] {
    return operation.items.filter(
      (item) =>
        item.rollbackData &&
        item.rollbackData.platformData.length > 0 &&
        item.rollbackData.platformData.some((pd) => !pd.completed)
    );
  }

  /**
   * Check if rollback is in progress
   */
  isRollbackInProgress(operationId: string): boolean {
    return this.activeRollbacks.has(operationId);
  }

  /**
   * Get rollback data for an item
   */
  getRollbackData(operationId: string, itemId: string): RollbackData | null {
    const operationData = this.rollbackData.get(operationId);
    return operationData?.get(itemId) || null;
  }

  // ============================================================================
  // Persistence
  // ============================================================================

  private async persistRollbackData(
    operationId: string,
    itemId: string,
    data: RollbackData
  ): Promise<void> {
    try {
      await this.supabase
        .from('bulk_operation_rollback')
        .upsert({
          operation_id: operationId,
          item_id: itemId,
          operation_type: data.operationType,
          product_id: data.productId,
          platform_data: data.platformData,
          created_at: data.createdAt.toISOString(),
        }, { onConflict: 'operation_id,item_id' });
    } catch (error) {
      console.error('Failed to persist rollback data:', error);
    }
  }

  /**
   * Load rollback data from database
   */
  async loadRollbackData(operationId: string): Promise<void> {
    try {
      const { data, error } = await this.supabase
        .from('bulk_operation_rollback')
        .select('*')
        .eq('operation_id', operationId);

      if (error || !data) return;

      const operationData = new Map<string, RollbackData>();
      for (const row of data) {
        operationData.set(row.item_id, {
          operationType: row.operation_type,
          productId: row.product_id,
          platformData: row.platform_data,
          createdAt: new Date(row.created_at),
        });
      }

      this.rollbackData.set(operationId, operationData);
    } catch (error) {
      console.error('Failed to load rollback data:', error);
    }
  }

  private cleanupRollbackData(operationId: string): void {
    this.rollbackData.delete(operationId);
  }

  // ============================================================================
  // Helpers
  // ============================================================================

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

// ============================================================================
// Factory Functions
// ============================================================================

let instance: RollbackManager | null = null;

/**
 * Get the global RollbackManager instance
 */
export function getRollbackManager(
  config: RollbackManagerConfig,
  progressTracker?: ProgressTracker
): RollbackManager {
  if (!instance) {
    instance = new RollbackManager(config, progressTracker);
  }
  return instance;
}

/**
 * Create a new RollbackManager instance
 */
export function createRollbackManager(
  config: RollbackManagerConfig,
  progressTracker?: ProgressTracker
): RollbackManager {
  return new RollbackManager(config, progressTracker);
}

export default RollbackManager;
