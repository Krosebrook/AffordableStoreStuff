/**
 * ============================================================================
 * FORECASTING MODULES - INDEX
 * ============================================================================
 * Export all forecasting modules
 */

// Revenue Predictor
export {
  RevenuePredictor,
  createRevenuePredictor,
  type RevenuePredictorConfig,
  type RevenueData,
} from './revenue-predictor.js';

// Trend Predictor
export {
  TrendPredictor,
  createTrendPredictor,
  type TrendPredictorConfig,
  type TrendDataPoint,
} from './trend-predictor.js';

// Inventory Predictor
export {
  InventoryPredictor,
  createInventoryPredictor,
  type InventoryPredictorConfig,
  type InventoryDataPoint,
  type StockoutPrediction,
  type ReorderRecommendation,
} from './inventory-predictor.js';

// Demand Predictor
export {
  DemandPredictor,
  createDemandPredictor,
  type DemandPredictorConfig,
  type DemandDataPoint,
  type DemandDriverInput,
} from './demand-predictor.js';

// Re-export types
export type {
  Forecast,
  RevenueForecast,
  InventoryForecast,
  DemandForecast,
  TrendAnalysis,
  TrendSignal,
  PredictionPoint,
} from '../types.js';
