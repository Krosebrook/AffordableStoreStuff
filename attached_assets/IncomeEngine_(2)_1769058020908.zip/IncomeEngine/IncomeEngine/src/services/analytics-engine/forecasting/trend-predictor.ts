/**
 * ============================================================================
 * TREND PREDICTOR
 * ============================================================================
 * Niche and keyword trend detection and forecasting
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  TrendSignal,
  TrendAnalysis,
  TrendDirection,
  DataPoint,
  PredictionPoint,
  SeasonalPattern,
  ConfidenceLevel,
} from '../types.js';
import {
  createMovingAverageModel,
  createLinearRegressionModel,
  detectSeasonality,
} from '../ml-models/index.js';

export interface TrendPredictorConfig {
  trendThreshold: number; // Minimum change to consider trending
  velocityWindow: number; // Days for velocity calculation
  momentumWindow: number; // Days for momentum calculation
  significanceThreshold: number; // Minimum score difference for significance
}

export interface TrendDataPoint {
  keyword: string;
  source: 'google_trends' | 'reddit' | 'twitter' | 'internal' | 'combined';
  date: Date;
  score: number;
  metadata?: Record<string, unknown>;
}

export class TrendPredictor {
  private readonly config: TrendPredictorConfig;

  constructor(config?: Partial<TrendPredictorConfig>) {
    this.config = {
      trendThreshold: config?.trendThreshold ?? 0.1, // 10% change
      velocityWindow: config?.velocityWindow ?? 7,
      momentumWindow: config?.momentumWindow ?? 14,
      significanceThreshold: config?.significanceThreshold ?? 5,
    };
  }

  /**
   * Analyze trend for a single keyword
   */
  async analyzeKeyword(
    trendData: TrendDataPoint[],
    keyword: string
  ): Promise<TrendAnalysis> {
    // Filter data for this keyword
    const keywordData = trendData.filter(d => d.keyword === keyword);

    if (keywordData.length < 7) {
      throw new Error(`Insufficient data for keyword "${keyword}": need at least 7 data points`);
    }

    // Sort by date
    const sortedData = [...keywordData].sort(
      (a, b) => a.date.getTime() - b.date.getTime()
    );

    // Group by source
    const sourceGroups = this.groupBySource(sortedData);

    // Generate signals for each source
    const signals: TrendSignal[] = [];
    for (const [source, data] of Object.entries(sourceGroups)) {
      const signal = this.generateSignal(
        keyword,
        source as TrendSignal['source'],
        data
      );
      signals.push(signal);
    }

    // Calculate aggregate metrics
    const aggregateScore = this.calculateAggregateScore(signals);
    const aggregateDirection = this.determineAggregateDirection(signals);
    const confidenceLevel = this.calculateConfidenceLevel(signals);

    // Generate forecast
    const dataPoints: DataPoint[] = sortedData.map(d => ({
      timestamp: d.date,
      value: d.score,
      source: d.source,
    }));
    const forecast = this.forecastTrend(dataPoints, 14);

    // Generate recommendations
    const recommendations = this.generateRecommendations(
      keyword,
      aggregateDirection,
      aggregateScore,
      signals
    );

    return {
      keyword,
      signals,
      aggregateScore,
      aggregateDirection,
      confidenceLevel,
      forecast,
      recommendations,
      analyzedAt: new Date(),
    };
  }

  /**
   * Analyze multiple keywords and rank by potential
   */
  async analyzeMultipleKeywords(
    trendData: TrendDataPoint[],
    keywords: string[]
  ): Promise<TrendAnalysis[]> {
    const analyses: TrendAnalysis[] = [];

    for (const keyword of keywords) {
      try {
        const analysis = await this.analyzeKeyword(trendData, keyword);
        analyses.push(analysis);
      } catch (error) {
        console.warn(`Failed to analyze keyword "${keyword}":`, error);
      }
    }

    // Sort by aggregate score and rising trends first
    return analyses.sort((a, b) => {
      const directionScore = {
        rising: 3,
        stable: 1,
        falling: 0,
        volatile: 2,
      };

      const aScore = directionScore[a.aggregateDirection] * 100 + a.aggregateScore;
      const bScore = directionScore[b.aggregateDirection] * 100 + b.aggregateScore;

      return bScore - aScore;
    });
  }

  /**
   * Group data by source
   */
  private groupBySource(
    data: TrendDataPoint[]
  ): Record<string, TrendDataPoint[]> {
    const groups: Record<string, TrendDataPoint[]> = {};

    for (const item of data) {
      if (!groups[item.source]) {
        groups[item.source] = [];
      }
      groups[item.source].push(item);
    }

    return groups;
  }

  /**
   * Generate trend signal for a source
   */
  private generateSignal(
    keyword: string,
    source: TrendSignal['source'],
    data: TrendDataPoint[]
  ): TrendSignal {
    const sortedData = [...data].sort(
      (a, b) => a.date.getTime() - b.date.getTime()
    );
    const scores = sortedData.map(d => d.score);

    const currentScore = scores[scores.length - 1];
    const previousScore = scores.length > this.config.velocityWindow
      ? scores[scores.length - 1 - this.config.velocityWindow]
      : scores[0];

    const changePercent = previousScore > 0
      ? ((currentScore - previousScore) / previousScore) * 100
      : 0;

    // Calculate velocity (rate of change)
    const velocity = this.calculateVelocity(scores);

    // Calculate momentum (acceleration of change)
    const momentum = this.calculateMomentum(scores);

    // Determine direction
    const direction = this.determineDirection(changePercent, velocity);

    // Detect seasonality
    const dataPoints: DataPoint[] = sortedData.map(d => ({
      timestamp: d.date,
      value: d.score,
      source: d.source,
    }));
    const seasonality = this.detectSeasonalPattern(dataPoints);

    // Find related keywords (from metadata if available)
    const relatedKeywords = this.extractRelatedKeywords(data);

    return {
      id: uuidv4(),
      keyword,
      source,
      currentScore,
      previousScore,
      changePercent,
      direction,
      velocity,
      momentum,
      seasonality,
      relatedKeywords,
      lastUpdated: new Date(),
    };
  }

  /**
   * Calculate velocity (average rate of change)
   */
  private calculateVelocity(scores: number[]): number {
    if (scores.length < 2) return 0;

    const windowSize = Math.min(this.config.velocityWindow, scores.length - 1);
    const recentScores = scores.slice(-windowSize - 1);

    let totalChange = 0;
    for (let i = 1; i < recentScores.length; i++) {
      if (recentScores[i - 1] !== 0) {
        totalChange += (recentScores[i] - recentScores[i - 1]) / recentScores[i - 1];
      }
    }

    return totalChange / (recentScores.length - 1);
  }

  /**
   * Calculate momentum (acceleration of velocity)
   */
  private calculateMomentum(scores: number[]): number {
    if (scores.length < this.config.momentumWindow) return 0;

    const midpoint = Math.floor(scores.length / 2);
    const firstHalfVelocity = this.calculateVelocity(scores.slice(0, midpoint));
    const secondHalfVelocity = this.calculateVelocity(scores.slice(midpoint));

    return secondHalfVelocity - firstHalfVelocity;
  }

  /**
   * Determine trend direction
   */
  private determineDirection(
    changePercent: number,
    velocity: number
  ): TrendDirection {
    const absChange = Math.abs(changePercent);
    const absVelocity = Math.abs(velocity);

    // Check for volatility (high absolute velocity but unclear direction)
    if (absVelocity > 0.5 && absChange < 20) {
      return 'volatile';
    }

    if (absChange < this.config.trendThreshold * 100) {
      return 'stable';
    }

    return changePercent > 0 ? 'rising' : 'falling';
  }

  /**
   * Detect seasonal pattern in trend data
   */
  private detectSeasonalPattern(
    dataPoints: DataPoint[]
  ): SeasonalPattern | undefined {
    if (dataPoints.length < 14) return undefined;

    const seasonality = detectSeasonality(dataPoints, [7]);
    if (!seasonality || seasonality.strength < 0.3) return undefined;

    return {
      type: 'weekly',
      peakPeriods: [],
      troughPeriods: [],
      amplitude: seasonality.strength,
    };
  }

  /**
   * Extract related keywords from metadata
   */
  private extractRelatedKeywords(data: TrendDataPoint[]): string[] {
    const related = new Set<string>();

    for (const item of data) {
      if (item.metadata?.relatedKeywords) {
        const keywords = item.metadata.relatedKeywords as string[];
        keywords.forEach(k => related.add(k));
      }
    }

    return Array.from(related).slice(0, 10);
  }

  /**
   * Calculate aggregate score from multiple signals
   */
  private calculateAggregateScore(signals: TrendSignal[]): number {
    if (signals.length === 0) return 0;

    // Weight different sources
    const sourceWeights: Record<string, number> = {
      google_trends: 0.4,
      internal: 0.3,
      reddit: 0.15,
      twitter: 0.1,
      combined: 0.05,
    };

    let weightedSum = 0;
    let totalWeight = 0;

    for (const signal of signals) {
      const weight = sourceWeights[signal.source] ?? 0.1;
      weightedSum += signal.currentScore * weight;
      totalWeight += weight;
    }

    return totalWeight > 0 ? weightedSum / totalWeight : 0;
  }

  /**
   * Determine aggregate direction from signals
   */
  private determineAggregateDirection(signals: TrendSignal[]): TrendDirection {
    if (signals.length === 0) return 'stable';

    const directionCounts = { rising: 0, falling: 0, stable: 0, volatile: 0 };

    for (const signal of signals) {
      directionCounts[signal.direction]++;
    }

    const maxDirection = Object.entries(directionCounts).reduce((max, [dir, count]) =>
      count > max[1] ? [dir, count] : max,
      ['stable', 0] as [string, number]
    );

    return maxDirection[0] as TrendDirection;
  }

  /**
   * Calculate confidence level
   */
  private calculateConfidenceLevel(signals: TrendSignal[]): ConfidenceLevel {
    if (signals.length === 0) return 'low';

    // Confidence based on number of agreeing sources and data recency
    const agreementScore = this.calculateSourceAgreement(signals);
    const dataFreshness = this.calculateDataFreshness(signals);

    const combinedScore = agreementScore * 0.6 + dataFreshness * 0.4;

    if (combinedScore >= 0.9) return 'very_high';
    if (combinedScore >= 0.7) return 'high';
    if (combinedScore >= 0.4) return 'medium';
    return 'low';
  }

  /**
   * Calculate agreement between sources
   */
  private calculateSourceAgreement(signals: TrendSignal[]): number {
    if (signals.length <= 1) return 0.5;

    const directions = signals.map(s => s.direction);
    const majorityDirection = directions.reduce((acc, dir) => {
      acc[dir] = (acc[dir] ?? 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const maxAgreement = Math.max(...Object.values(majorityDirection));
    return maxAgreement / signals.length;
  }

  /**
   * Calculate data freshness
   */
  private calculateDataFreshness(signals: TrendSignal[]): number {
    if (signals.length === 0) return 0;

    const now = Date.now();
    const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days

    const freshnessScores = signals.map(s => {
      const age = now - s.lastUpdated.getTime();
      return Math.max(0, 1 - age / maxAge);
    });

    return freshnessScores.reduce((a, b) => a + b, 0) / signals.length;
  }

  /**
   * Forecast trend for future periods
   */
  private forecastTrend(
    dataPoints: DataPoint[],
    horizon: number
  ): PredictionPoint[] {
    if (dataPoints.length < 7) {
      // Not enough data, return flat forecast
      const lastValue = dataPoints[dataPoints.length - 1]?.value ?? 50;
      const lastDate = dataPoints[dataPoints.length - 1]?.timestamp ?? new Date();

      return Array.from({ length: horizon }, (_, i) => {
        const date = new Date(lastDate);
        date.setDate(date.getDate() + i + 1);
        return {
          date,
          value: lastValue,
          lowerBound: lastValue * 0.8,
          upperBound: lastValue * 1.2,
        };
      });
    }

    // Use moving average for trend forecasting
    const maModel = createMovingAverageModel({ windowSize: 7 });
    return maModel.forecast(dataPoints, horizon);
  }

  /**
   * Generate actionable recommendations
   */
  private generateRecommendations(
    keyword: string,
    direction: TrendDirection,
    score: number,
    signals: TrendSignal[]
  ): string[] {
    const recommendations: string[] = [];

    switch (direction) {
      case 'rising':
        recommendations.push(`"${keyword}" is trending upward - consider creating products in this niche`);
        if (score > 70) {
          recommendations.push('High demand detected - prioritize quick product launch');
        }
        recommendations.push('Monitor competitors entering this space');
        break;

      case 'falling':
        recommendations.push(`"${keyword}" shows declining interest - consider pivoting or diversifying`);
        recommendations.push('Focus on existing customers rather than new acquisition');
        break;

      case 'volatile':
        recommendations.push(`"${keyword}" shows high volatility - monitor closely before investing`);
        recommendations.push('Consider waiting for trend stabilization');
        break;

      case 'stable':
        recommendations.push(`"${keyword}" shows stable demand - good for consistent revenue`);
        if (score > 50) {
          recommendations.push('Opportunity for steady product line development');
        }
        break;
    }

    // Add source-specific recommendations
    const hasGoogleData = signals.some(s => s.source === 'google_trends');
    const hasSocialData = signals.some(s => s.source === 'reddit' || s.source === 'twitter');

    if (!hasGoogleData) {
      recommendations.push('Consider adding Google Trends data for more accurate predictions');
    }

    if (hasSocialData && signals.find(s => s.source === 'reddit')?.velocity ?? 0 > 0.3) {
      recommendations.push('Strong social momentum detected - potential for viral growth');
    }

    return recommendations;
  }

  /**
   * Find top rising trends
   */
  async findRisingTrends(
    trendData: TrendDataPoint[],
    limit: number = 10
  ): Promise<TrendSignal[]> {
    const keywords = [...new Set(trendData.map(d => d.keyword))];
    const analyses = await this.analyzeMultipleKeywords(trendData, keywords);

    const risingSignals: TrendSignal[] = [];

    for (const analysis of analyses) {
      const risingSignal = analysis.signals.find(s => s.direction === 'rising');
      if (risingSignal) {
        risingSignals.push(risingSignal);
      }
    }

    return risingSignals
      .sort((a, b) => b.velocity - a.velocity)
      .slice(0, limit);
  }

  /**
   * Find top falling trends
   */
  async findFallingTrends(
    trendData: TrendDataPoint[],
    limit: number = 10
  ): Promise<TrendSignal[]> {
    const keywords = [...new Set(trendData.map(d => d.keyword))];
    const analyses = await this.analyzeMultipleKeywords(trendData, keywords);

    const fallingSignals: TrendSignal[] = [];

    for (const analysis of analyses) {
      const fallingSignal = analysis.signals.find(s => s.direction === 'falling');
      if (fallingSignal) {
        fallingSignals.push(fallingSignal);
      }
    }

    return fallingSignals
      .sort((a, b) => a.velocity - b.velocity) // Most negative first
      .slice(0, limit);
  }

  /**
   * Detect emerging niches from trend data
   */
  async detectEmergingNiches(
    trendData: TrendDataPoint[],
    options?: {
      minScore: number;
      minVelocity: number;
      maxResults: number;
    }
  ): Promise<{ keyword: string; score: number; velocity: number; potential: number }[]> {
    const minScore = options?.minScore ?? 20;
    const minVelocity = options?.minVelocity ?? 0.1;
    const maxResults = options?.maxResults ?? 20;

    const keywords = [...new Set(trendData.map(d => d.keyword))];
    const analyses = await this.analyzeMultipleKeywords(trendData, keywords);

    const emerging = analyses
      .filter(a =>
        a.aggregateScore >= minScore &&
        a.signals.some(s => s.velocity >= minVelocity)
      )
      .map(a => {
        const maxVelocitySignal = a.signals.reduce(
          (max, s) => (s.velocity > max.velocity ? s : max),
          a.signals[0]
        );

        // Calculate potential score (combination of current score and growth rate)
        const potential = a.aggregateScore * (1 + maxVelocitySignal.velocity);

        return {
          keyword: a.keyword,
          score: a.aggregateScore,
          velocity: maxVelocitySignal.velocity,
          potential,
        };
      })
      .sort((a, b) => b.potential - a.potential)
      .slice(0, maxResults);

    return emerging;
  }
}

/**
 * Factory function for trend predictor
 */
export function createTrendPredictor(
  config?: Partial<TrendPredictorConfig>
): TrendPredictor {
  return new TrendPredictor(config);
}
