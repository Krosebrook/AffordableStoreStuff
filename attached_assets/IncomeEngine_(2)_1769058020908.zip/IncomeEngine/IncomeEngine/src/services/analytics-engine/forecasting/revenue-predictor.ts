/**
 * ============================================================================
 * REVENUE PREDICTOR
 * ============================================================================
 * Time-series revenue forecasting with multiple model ensemble
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  RevenueForecast,
  PredictionPoint,
  DataPoint,
  ModelResult,
  RevenueBreakdown,
  ConfidenceLevel,
  ModelType,
} from '../types.js';
import {
  createMovingAverageModel,
  createExponentialSmoothingModel,
  createLinearRegressionModel,
  createSeasonalDecompositionModel,
  detectSeasonality,
} from '../ml-models/index.js';

export interface RevenuePredictorConfig {
  defaultHorizon: number;
  confidenceLevel: number;
  minDataPoints: number;
  ensembleWeights: {
    movingAverage: number;
    exponentialSmoothing: number;
    linearRegression: number;
    seasonalDecomposition: number;
  };
}

export interface RevenueData {
  date: Date;
  revenue: number;
  platform?: string;
  productId?: string;
  units?: number;
}

export class RevenuePredictor {
  private readonly config: RevenuePredictorConfig;

  constructor(config?: Partial<RevenuePredictorConfig>) {
    this.config = {
      defaultHorizon: config?.defaultHorizon ?? 30,
      confidenceLevel: config?.confidenceLevel ?? 0.95,
      minDataPoints: config?.minDataPoints ?? 14,
      ensembleWeights: config?.ensembleWeights ?? {
        movingAverage: 0.2,
        exponentialSmoothing: 0.35,
        linearRegression: 0.15,
        seasonalDecomposition: 0.3,
      },
    };
  }

  /**
   * Generate revenue forecast
   */
  async forecast(
    revenueData: RevenueData[],
    horizon: number = this.config.defaultHorizon
  ): Promise<RevenueForecast> {
    if (revenueData.length < this.config.minDataPoints) {
      throw new Error(
        `Insufficient data: need at least ${this.config.minDataPoints} data points, got ${revenueData.length}`
      );
    }

    // Sort by date
    const sortedData = [...revenueData].sort(
      (a, b) => a.date.getTime() - b.date.getTime()
    );

    // Convert to DataPoints
    const dataPoints: DataPoint[] = sortedData.map(d => ({
      timestamp: d.date,
      value: d.revenue,
      source: 'internal',
    }));

    // Run multiple models and ensemble
    const modelResults = await this.runModels(dataPoints, horizon);
    const ensemblePredictions = this.ensemblePredictions(modelResults, horizon);

    // Calculate metrics
    const totalPredictedRevenue = ensemblePredictions.reduce(
      (sum, p) => sum + p.value,
      0
    );

    // Calculate growth rate (comparing predicted to historical)
    const lastMonthRevenue = dataPoints
      .slice(-30)
      .reduce((sum, p) => sum + p.value, 0);
    const growthRate =
      lastMonthRevenue > 0
        ? (totalPredictedRevenue - lastMonthRevenue) / lastMonthRevenue
        : 0;

    // Break down by platform and product if available
    const revenueByPlatform = this.aggregateByField(sortedData, 'platform');
    const revenueByProduct = this.aggregateByField(sortedData, 'productId');

    // Calculate seasonal factors
    const seasonalFactors = this.calculateSeasonalFactors(dataPoints);

    // Determine confidence level
    const avgConfidence = this.calculateAverageConfidence(modelResults);
    const confidenceLevel = this.getConfidenceLevel(avgConfidence);

    // Determine best model used
    const bestModel = this.selectBestModel(modelResults);

    return {
      id: uuidv4(),
      type: 'revenue',
      targetEntity: 'total_revenue',
      predictions: ensemblePredictions,
      confidence: avgConfidence,
      confidenceLevel,
      modelUsed: bestModel.model,
      dataPointsUsed: dataPoints.length,
      generatedAt: new Date(),
      validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000), // Valid for 24 hours
      totalPredictedRevenue,
      revenueByPlatform,
      revenueByProduct,
      growthRate,
      seasonalFactors,
    };
  }

  /**
   * Run all forecasting models
   */
  private async runModels(
    dataPoints: DataPoint[],
    horizon: number
  ): Promise<ModelResult[]> {
    const results: ModelResult[] = [];

    // Moving Average
    try {
      const maModel = createMovingAverageModel({ windowSize: 7 });
      results.push(maModel.fit(dataPoints, horizon));
    } catch (error) {
      console.warn('Moving average model failed:', error);
    }

    // Exponential Smoothing (auto-optimized)
    try {
      const esParams = this.optimizeExponentialSmoothing(dataPoints);
      const esModel = createExponentialSmoothingModel(esParams);
      results.push(esModel.getModelResult(dataPoints, horizon));
    } catch (error) {
      console.warn('Exponential smoothing model failed:', error);
    }

    // Linear Regression
    try {
      const lrModel = createLinearRegressionModel();
      results.push(lrModel.getModelResult(dataPoints, horizon));
    } catch (error) {
      console.warn('Linear regression model failed:', error);
    }

    // Seasonal Decomposition (if enough data)
    if (dataPoints.length >= 14) {
      try {
        const seasonality = detectSeasonality(dataPoints, [7, 30]);
        if (seasonality) {
          const sdModel = createSeasonalDecompositionModel({
            period: seasonality.period,
            method: 'additive',
          });
          results.push(sdModel.getModelResult(dataPoints, horizon));
        }
      } catch (error) {
        console.warn('Seasonal decomposition model failed:', error);
      }
    }

    return results;
  }

  /**
   * Optimize exponential smoothing parameters
   */
  private optimizeExponentialSmoothing(
    dataPoints: DataPoint[]
  ): { alpha: number; beta?: number } {
    // Simple heuristic-based optimization
    const values = dataPoints.map(d => d.value);
    const n = values.length;

    // Calculate volatility
    let sumDiff = 0;
    for (let i = 1; i < n; i++) {
      sumDiff += Math.abs(values[i] - values[i - 1]);
    }
    const avgDiff = sumDiff / (n - 1);
    const avgValue = values.reduce((a, b) => a + b, 0) / n;
    const volatility = avgValue > 0 ? avgDiff / avgValue : 0;

    // Higher volatility = lower alpha (more smoothing)
    const alpha = Math.max(0.1, Math.min(0.5, 0.5 - volatility));

    // Check for trend
    const firstHalfAvg =
      values.slice(0, Math.floor(n / 2)).reduce((a, b) => a + b, 0) /
      Math.floor(n / 2);
    const secondHalfAvg =
      values.slice(Math.floor(n / 2)).reduce((a, b) => a + b, 0) /
      Math.ceil(n / 2);
    const hasTrend = Math.abs(secondHalfAvg - firstHalfAvg) / avgValue > 0.1;

    if (hasTrend) {
      return { alpha, beta: 0.1 };
    }

    return { alpha };
  }

  /**
   * Ensemble predictions from multiple models
   */
  private ensemblePredictions(
    modelResults: ModelResult[],
    horizon: number
  ): PredictionPoint[] {
    if (modelResults.length === 0) {
      throw new Error('No model results to ensemble');
    }

    // Calculate weights based on model accuracy
    const accuracySum = modelResults.reduce((sum, r) => sum + r.accuracy, 0);
    const weights = modelResults.map(r =>
      accuracySum > 0 ? r.accuracy / accuracySum : 1 / modelResults.length
    );

    const predictions: PredictionPoint[] = [];

    for (let h = 0; h < horizon; h++) {
      let weightedValue = 0;
      let weightedLower = 0;
      let weightedUpper = 0;
      let totalWeight = 0;
      let targetDate: Date | null = null;

      for (let i = 0; i < modelResults.length; i++) {
        const prediction = modelResults[i].predictions[h];
        if (prediction) {
          weightedValue += weights[i] * prediction.value;
          weightedLower += weights[i] * prediction.lowerBound;
          weightedUpper += weights[i] * prediction.upperBound;
          totalWeight += weights[i];
          targetDate = prediction.date;
        }
      }

      if (totalWeight > 0 && targetDate) {
        predictions.push({
          date: targetDate,
          value: weightedValue / totalWeight,
          lowerBound: weightedLower / totalWeight,
          upperBound: weightedUpper / totalWeight,
        });
      }
    }

    return predictions;
  }

  /**
   * Aggregate revenue by a specific field
   */
  private aggregateByField(
    data: RevenueData[],
    field: 'platform' | 'productId'
  ): Record<string, number> {
    const result: Record<string, number> = {};

    for (const item of data) {
      const key = item[field] ?? 'unknown';
      result[key] = (result[key] ?? 0) + item.revenue;
    }

    return result;
  }

  /**
   * Calculate seasonal factors
   */
  private calculateSeasonalFactors(dataPoints: DataPoint[]): Record<string, number> {
    const factors: Record<string, number> = {};
    const dayTotals: Record<number, number[]> = {};

    // Group by day of week
    for (const dp of dataPoints) {
      const dayOfWeek = dp.timestamp.getDay();
      if (!dayTotals[dayOfWeek]) {
        dayTotals[dayOfWeek] = [];
      }
      dayTotals[dayOfWeek].push(dp.value);
    }

    // Calculate average for each day
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const overallAvg =
      dataPoints.reduce((sum, dp) => sum + dp.value, 0) / dataPoints.length;

    for (let day = 0; day < 7; day++) {
      const values = dayTotals[day] ?? [];
      if (values.length > 0) {
        const dayAvg = values.reduce((a, b) => a + b, 0) / values.length;
        factors[dayNames[day]] = overallAvg > 0 ? dayAvg / overallAvg : 1;
      } else {
        factors[dayNames[day]] = 1;
      }
    }

    return factors;
  }

  /**
   * Calculate average confidence from model results
   */
  private calculateAverageConfidence(modelResults: ModelResult[]): number {
    if (modelResults.length === 0) return 0;
    return (
      modelResults.reduce((sum, r) => sum + r.accuracy, 0) / modelResults.length
    );
  }

  /**
   * Get confidence level label
   */
  private getConfidenceLevel(confidence: number): ConfidenceLevel {
    if (confidence >= 0.9) return 'very_high';
    if (confidence >= 0.75) return 'high';
    if (confidence >= 0.5) return 'medium';
    return 'low';
  }

  /**
   * Select the best performing model
   */
  private selectBestModel(modelResults: ModelResult[]): ModelResult {
    if (modelResults.length === 0) {
      throw new Error('No model results available');
    }

    return modelResults.reduce((best, current) =>
      current.accuracy > best.accuracy ? current : best
    );
  }

  /**
   * Get revenue breakdown for a date range
   */
  async getRevenueBreakdown(
    revenueData: RevenueData[],
    startDate: Date,
    endDate: Date
  ): Promise<RevenueBreakdown> {
    const filtered = revenueData.filter(
      d => d.date >= startDate && d.date <= endDate
    );

    const totalRevenue = filtered.reduce((sum, d) => sum + d.revenue, 0);
    const totalUnits = filtered.reduce((sum, d) => sum + (d.units ?? 0), 0);

    // By platform
    const platformMap = new Map<string, { revenue: number; units: number }>();
    for (const d of filtered) {
      const key = d.platform ?? 'unknown';
      const existing = platformMap.get(key) ?? { revenue: 0, units: 0 };
      platformMap.set(key, {
        revenue: existing.revenue + d.revenue,
        units: existing.units + (d.units ?? 0),
      });
    }

    // By product
    const productMap = new Map<string, { revenue: number; units: number }>();
    for (const d of filtered) {
      const key = d.productId ?? 'unknown';
      const existing = productMap.get(key) ?? { revenue: 0, units: 0 };
      productMap.set(key, {
        revenue: existing.revenue + d.revenue,
        units: existing.units + (d.units ?? 0),
      });
    }

    // Calculate period string
    const periodDays = Math.ceil(
      (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
    );
    const period = `${periodDays} days`;

    // Calculate comparison to previous period
    const previousStart = new Date(
      startDate.getTime() - (endDate.getTime() - startDate.getTime())
    );
    const previousFiltered = revenueData.filter(
      d => d.date >= previousStart && d.date < startDate
    );
    const previousRevenue = previousFiltered.reduce((sum, d) => sum + d.revenue, 0);

    return {
      period,
      totalRevenue,
      byPlatform: Array.from(platformMap.entries()).map(([platform, data]) => ({
        platform,
        revenue: data.revenue,
        units: data.units,
      })),
      byProduct: Array.from(productMap.entries()).map(([productId, data]) => ({
        productId,
        title: productId, // Would be resolved from product data
        revenue: data.revenue,
        units: data.units,
      })),
      byCategory: [], // Would require category data
      comparedToPrevious: {
        percentChange:
          previousRevenue > 0
            ? ((totalRevenue - previousRevenue) / previousRevenue) * 100
            : 0,
        absoluteChange: totalRevenue - previousRevenue,
      },
    };
  }

  /**
   * Predict revenue for a specific platform
   */
  async forecastByPlatform(
    revenueData: RevenueData[],
    platform: string,
    horizon: number = this.config.defaultHorizon
  ): Promise<RevenueForecast> {
    const platformData = revenueData.filter(d => d.platform === platform);
    const forecast = await this.forecast(platformData, horizon);
    forecast.targetEntity = `platform:${platform}`;
    return forecast;
  }

  /**
   * Predict revenue for a specific product
   */
  async forecastByProduct(
    revenueData: RevenueData[],
    productId: string,
    horizon: number = this.config.defaultHorizon
  ): Promise<RevenueForecast> {
    const productData = revenueData.filter(d => d.productId === productId);
    const forecast = await this.forecast(productData, horizon);
    forecast.targetEntity = `product:${productId}`;
    return forecast;
  }
}

/**
 * Factory function for revenue predictor
 */
export function createRevenuePredictor(
  config?: Partial<RevenuePredictorConfig>
): RevenuePredictor {
  return new RevenuePredictor(config);
}
