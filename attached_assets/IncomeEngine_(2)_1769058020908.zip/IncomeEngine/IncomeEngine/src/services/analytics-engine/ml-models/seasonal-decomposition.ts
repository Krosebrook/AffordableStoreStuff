/**
 * ============================================================================
 * SEASONAL DECOMPOSITION MODEL
 * ============================================================================
 * Time series decomposition into trend, seasonal, and residual components
 * Supports both additive and multiplicative decomposition
 */

import type { DataPoint, PredictionPoint, ModelResult, SeasonalPattern } from '../types.js';
import { MovingAverageModel } from './moving-average.js';

export interface SeasonalDecompositionOptions {
  period: number; // Seasonal period (e.g., 7 for weekly, 12 for monthly)
  method: 'additive' | 'multiplicative';
  trendSmoothingWindow?: number;
  confidenceLevel?: number;
  extrapolateSeasons?: number; // Number of future seasons for forecasting
}

export interface DecompositionResult {
  trend: number[];
  seasonal: number[];
  residual: number[];
  observed: number[];
  seasonalIndices: number[];
  trendStrength: number;
  seasonalStrength: number;
}

export class SeasonalDecompositionModel {
  private readonly period: number;
  private readonly method: 'additive' | 'multiplicative';
  private readonly trendSmoothingWindow: number;
  private readonly confidenceLevel: number;
  private readonly extrapolateSeasons: number;

  // Decomposed components
  private trend: number[] = [];
  private seasonal: number[] = [];
  private residual: number[] = [];
  private seasonalIndices: number[] = [];
  private residualStd: number = 0;
  private fitted: boolean = false;

  constructor(options: SeasonalDecompositionOptions) {
    this.period = options.period;
    this.method = options.method;
    this.trendSmoothingWindow = options.trendSmoothingWindow ?? options.period;
    this.confidenceLevel = options.confidenceLevel ?? 0.95;
    this.extrapolateSeasons = options.extrapolateSeasons ?? 2;
  }

  /**
   * Decompose time series into components
   */
  decompose(dataPoints: DataPoint[]): DecompositionResult {
    const values = dataPoints.map(dp => dp.value);
    const n = values.length;

    if (n < 2 * this.period) {
      throw new Error(`Need at least ${2 * this.period} data points for seasonal decomposition with period ${this.period}`);
    }

    // Step 1: Calculate trend using centered moving average
    this.trend = this.calculateTrend(values);

    // Step 2: Detrend the series
    const detrended = this.detrend(values, this.trend);

    // Step 3: Calculate seasonal indices
    this.seasonalIndices = this.calculateSeasonalIndices(detrended, n);

    // Step 4: Calculate full seasonal component
    this.seasonal = this.expandSeasonalIndices(n);

    // Step 5: Calculate residual
    this.residual = this.calculateResidual(values, this.trend, this.seasonal);

    // Calculate residual standard deviation
    const validResiduals = this.residual.filter(r => !isNaN(r) && isFinite(r));
    if (validResiduals.length > 0) {
      const mean = validResiduals.reduce((a, b) => a + b, 0) / validResiduals.length;
      const variance = validResiduals.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / validResiduals.length;
      this.residualStd = Math.sqrt(variance);
    }

    this.fitted = true;

    return {
      trend: this.trend,
      seasonal: this.seasonal,
      residual: this.residual,
      observed: values,
      seasonalIndices: this.seasonalIndices,
      trendStrength: this.calculateTrendStrength(values),
      seasonalStrength: this.calculateSeasonalStrength(values),
    };
  }

  /**
   * Calculate trend using centered moving average
   */
  private calculateTrend(values: number[]): number[] {
    const maModel = new MovingAverageModel({
      windowSize: this.trendSmoothingWindow,
    });

    // Use centered moving average
    const ma = maModel.calculateSMA(values);
    const n = values.length;
    const offset = Math.floor(this.trendSmoothingWindow / 2);

    const trend: number[] = new Array(n).fill(NaN);
    for (let i = 0; i < ma.length; i++) {
      const idx = i + offset;
      if (idx < n) {
        trend[idx] = ma[i];
      }
    }

    // Interpolate/extrapolate missing values at edges
    return this.fillMissingTrend(trend);
  }

  /**
   * Fill missing trend values at edges using linear extrapolation
   */
  private fillMissingTrend(trend: number[]): number[] {
    const result = [...trend];
    const n = result.length;

    // Find first and last valid indices
    let firstValid = 0;
    let lastValid = n - 1;
    while (firstValid < n && (isNaN(result[firstValid]) || !isFinite(result[firstValid]))) {
      firstValid++;
    }
    while (lastValid >= 0 && (isNaN(result[lastValid]) || !isFinite(result[lastValid]))) {
      lastValid--;
    }

    if (firstValid >= lastValid) {
      // Not enough valid points, fill with mean
      const validValues = result.filter(v => !isNaN(v) && isFinite(v));
      const mean = validValues.length > 0
        ? validValues.reduce((a, b) => a + b, 0) / validValues.length
        : 0;
      return result.map(() => mean);
    }

    // Calculate slope for extrapolation
    const slope = (result[lastValid] - result[firstValid]) / (lastValid - firstValid);

    // Fill beginning
    for (let i = firstValid - 1; i >= 0; i--) {
      result[i] = result[firstValid] - slope * (firstValid - i);
    }

    // Fill end
    for (let i = lastValid + 1; i < n; i++) {
      result[i] = result[lastValid] + slope * (i - lastValid);
    }

    return result;
  }

  /**
   * Detrend the series
   */
  private detrend(values: number[], trend: number[]): number[] {
    if (this.method === 'multiplicative') {
      return values.map((v, i) => (trend[i] !== 0 ? v / trend[i] : 1));
    }
    return values.map((v, i) => v - trend[i]);
  }

  /**
   * Calculate seasonal indices from detrended series
   */
  private calculateSeasonalIndices(detrended: number[], n: number): number[] {
    const seasonalSums: number[] = new Array(this.period).fill(0);
    const seasonalCounts: number[] = new Array(this.period).fill(0);

    for (let i = 0; i < n; i++) {
      const seasonIdx = i % this.period;
      if (!isNaN(detrended[i]) && isFinite(detrended[i])) {
        seasonalSums[seasonIdx] += detrended[i];
        seasonalCounts[seasonIdx]++;
      }
    }

    const indices = seasonalSums.map((sum, i) => {
      if (seasonalCounts[i] === 0) {
        return this.method === 'multiplicative' ? 1 : 0;
      }
      return sum / seasonalCounts[i];
    });

    // Normalize seasonal indices
    if (this.method === 'multiplicative') {
      const mean = indices.reduce((a, b) => a + b, 0) / this.period;
      return indices.map(v => v / mean);
    } else {
      const sum = indices.reduce((a, b) => a + b, 0);
      return indices.map(v => v - sum / this.period);
    }
  }

  /**
   * Expand seasonal indices to full series length
   */
  private expandSeasonalIndices(n: number): number[] {
    const seasonal: number[] = new Array(n);
    for (let i = 0; i < n; i++) {
      seasonal[i] = this.seasonalIndices[i % this.period];
    }
    return seasonal;
  }

  /**
   * Calculate residual component
   */
  private calculateResidual(values: number[], trend: number[], seasonal: number[]): number[] {
    if (this.method === 'multiplicative') {
      return values.map((v, i) => {
        const expected = trend[i] * seasonal[i];
        return expected !== 0 ? v / expected : 1;
      });
    }
    return values.map((v, i) => v - trend[i] - seasonal[i]);
  }

  /**
   * Calculate strength of trend (0 to 1)
   */
  private calculateTrendStrength(values: number[]): number {
    if (this.residual.length === 0 || this.seasonal.length === 0) {
      return 0;
    }

    const validResiduals = this.residual.filter(r => !isNaN(r) && isFinite(r));
    const residualVar = this.calculateVariance(validResiduals);

    const detrendedSeasonalRemoved = values.map((v, i) => {
      if (this.method === 'multiplicative') {
        return this.seasonal[i] !== 0 ? v / this.seasonal[i] : v;
      }
      return v - this.seasonal[i];
    });
    const dsrVar = this.calculateVariance(detrendedSeasonalRemoved);

    return dsrVar > 0 ? Math.max(0, 1 - residualVar / dsrVar) : 0;
  }

  /**
   * Calculate strength of seasonality (0 to 1)
   */
  private calculateSeasonalStrength(values: number[]): number {
    if (this.residual.length === 0 || this.trend.length === 0) {
      return 0;
    }

    const validResiduals = this.residual.filter(r => !isNaN(r) && isFinite(r));
    const residualVar = this.calculateVariance(validResiduals);

    const detrended = values.map((v, i) => {
      if (this.method === 'multiplicative') {
        return this.trend[i] !== 0 ? v / this.trend[i] : v;
      }
      return v - this.trend[i];
    });
    const detrendedVar = this.calculateVariance(detrended);

    return detrendedVar > 0 ? Math.max(0, 1 - residualVar / detrendedVar) : 0;
  }

  /**
   * Calculate variance
   */
  private calculateVariance(values: number[]): number {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  }

  /**
   * Get Z-score for confidence level
   */
  private getZScore(): number {
    const zScores: Record<number, number> = {
      0.90: 1.645,
      0.95: 1.96,
      0.99: 2.576,
    };
    return zScores[this.confidenceLevel] ?? 1.96;
  }

  /**
   * Forecast future values
   */
  forecast(dataPoints: DataPoint[], horizon: number): PredictionPoint[] {
    if (!this.fitted) {
      this.decompose(dataPoints);
    }

    const n = dataPoints.length;
    const lastDate = dataPoints[n - 1].timestamp;
    const zScore = this.getZScore();

    // Extrapolate trend using linear regression on last portion
    const trendForecast = this.extrapolateTrend(horizon);

    const predictions: PredictionPoint[] = [];

    for (let h = 1; h <= horizon; h++) {
      const seasonIdx = (n + h - 1) % this.period;
      const seasonalValue = this.seasonalIndices[seasonIdx];
      const trendValue = trendForecast[h - 1];

      let prediction: number;
      if (this.method === 'multiplicative') {
        prediction = trendValue * seasonalValue;
      } else {
        prediction = trendValue + seasonalValue;
      }

      // Increase uncertainty for further horizons
      const uncertaintyMultiplier = Math.sqrt(h);
      const margin = zScore * this.residualStd * uncertaintyMultiplier;

      const predictionDate = new Date(lastDate);
      predictionDate.setDate(predictionDate.getDate() + h);

      predictions.push({
        date: predictionDate,
        value: prediction,
        lowerBound: prediction - Math.abs(margin),
        upperBound: prediction + Math.abs(margin),
      });
    }

    return predictions;
  }

  /**
   * Extrapolate trend using linear fit on recent data
   */
  private extrapolateTrend(horizon: number): number[] {
    // Use last 2 periods of trend for extrapolation
    const recentTrend = this.trend.slice(-2 * this.period);
    const n = recentTrend.length;

    if (n < 2) {
      const lastTrend = this.trend[this.trend.length - 1] ?? 0;
      return new Array(horizon).fill(lastTrend);
    }

    // Simple linear regression on trend
    const xMean = (n - 1) / 2;
    const yMean = recentTrend.reduce((a, b) => a + b, 0) / n;

    let numerator = 0;
    let denominator = 0;
    for (let i = 0; i < n; i++) {
      numerator += (i - xMean) * (recentTrend[i] - yMean);
      denominator += (i - xMean) * (i - xMean);
    }

    const slope = denominator !== 0 ? numerator / denominator : 0;
    const intercept = yMean - slope * xMean;

    const forecasts: number[] = [];
    for (let h = 1; h <= horizon; h++) {
      forecasts.push(intercept + slope * (n - 1 + h));
    }

    return forecasts;
  }

  /**
   * Get seasonal pattern information
   */
  getSeasonalPattern(): SeasonalPattern {
    const maxIdx = this.seasonalIndices.indexOf(Math.max(...this.seasonalIndices));
    const minIdx = this.seasonalIndices.indexOf(Math.min(...this.seasonalIndices));

    const amplitude = this.method === 'multiplicative'
      ? Math.max(...this.seasonalIndices) - Math.min(...this.seasonalIndices)
      : (Math.max(...this.seasonalIndices) - Math.min(...this.seasonalIndices)) / 2;

    const periodNames: Record<number, 'daily' | 'weekly' | 'monthly' | 'yearly'> = {
      24: 'daily',
      7: 'weekly',
      30: 'monthly',
      12: 'monthly',
      52: 'yearly',
      365: 'yearly',
    };

    return {
      type: periodNames[this.period] ?? 'monthly',
      peakPeriods: [String(maxIdx + 1)],
      troughPeriods: [String(minIdx + 1)],
      amplitude: Math.min(amplitude, 1),
    };
  }

  /**
   * Calculate error metrics
   */
  private calculateErrorMetrics(actual: number[], predicted: number[]): {
    mse: number;
    mae: number;
    mape: number;
  } {
    const validPairs: { a: number; p: number }[] = [];
    for (let i = 0; i < actual.length; i++) {
      if (!isNaN(predicted[i]) && isFinite(predicted[i])) {
        validPairs.push({ a: actual[i], p: predicted[i] });
      }
    }

    if (validPairs.length === 0) {
      return { mse: 0, mae: 0, mape: 0 };
    }

    let sumSquaredError = 0;
    let sumAbsoluteError = 0;
    let sumPercentageError = 0;
    let validPercentageCount = 0;

    for (const { a, p } of validPairs) {
      const error = a - p;
      sumSquaredError += error * error;
      sumAbsoluteError += Math.abs(error);

      if (a !== 0) {
        sumPercentageError += Math.abs(error / a);
        validPercentageCount++;
      }
    }

    const n = validPairs.length;
    return {
      mse: sumSquaredError / n,
      mae: sumAbsoluteError / n,
      mape: validPercentageCount > 0 ? sumPercentageError / validPercentageCount : 0,
    };
  }

  /**
   * Generate full model result
   */
  getModelResult(dataPoints: DataPoint[], horizon: number = 7): ModelResult {
    const decomposition = this.decompose(dataPoints);
    const values = dataPoints.map(dp => dp.value);

    // Reconstruct fitted values
    const fittedValues = values.map((_, i) => {
      if (this.method === 'multiplicative') {
        return decomposition.trend[i] * decomposition.seasonal[i];
      }
      return decomposition.trend[i] + decomposition.seasonal[i];
    });

    const errors = this.calculateErrorMetrics(values, fittedValues);
    const predictions = this.forecast(dataPoints, horizon);

    return {
      model: 'seasonal_decomposition',
      predictions,
      accuracy: Math.max(0, 1 - errors.mape),
      mse: errors.mse,
      mae: errors.mae,
      mape: errors.mape,
      trainingDataPoints: dataPoints.length,
      generatedAt: new Date(),
    };
  }
}

/**
 * Factory function for seasonal decomposition
 */
export function createSeasonalDecompositionModel(
  options?: Partial<SeasonalDecompositionOptions>
): SeasonalDecompositionModel {
  return new SeasonalDecompositionModel({
    period: options?.period ?? 7,
    method: options?.method ?? 'additive',
    trendSmoothingWindow: options?.trendSmoothingWindow,
    confidenceLevel: options?.confidenceLevel ?? 0.95,
    extrapolateSeasons: options?.extrapolateSeasons ?? 2,
  });
}

/**
 * Convenience function for quick seasonal decomposition
 */
export function decomposeTimeSeries(
  dataPoints: DataPoint[],
  period: number,
  method: 'additive' | 'multiplicative' = 'additive'
): DecompositionResult {
  const model = new SeasonalDecompositionModel({ period, method });
  return model.decompose(dataPoints);
}

/**
 * Detect if series has significant seasonality
 */
export function detectSeasonality(
  dataPoints: DataPoint[],
  periods: number[] = [7, 30, 365]
): { period: number; strength: number } | null {
  const values = dataPoints.map(dp => dp.value);
  let bestPeriod = 0;
  let bestStrength = 0;

  for (const period of periods) {
    if (values.length < 2 * period) continue;

    try {
      const model = new SeasonalDecompositionModel({ period, method: 'additive' });
      const result = model.decompose(dataPoints);

      if (result.seasonalStrength > bestStrength) {
        bestStrength = result.seasonalStrength;
        bestPeriod = period;
      }
    } catch {
      // Skip periods that can't be fitted
    }
  }

  if (bestStrength > 0.3) {
    return { period: bestPeriod, strength: bestStrength };
  }

  return null;
}
