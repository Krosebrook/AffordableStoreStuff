/**
 * ============================================================================
 * ML MODELS - INDEX
 * ============================================================================
 * Export all ML models for time series forecasting
 */

// Moving Average
export {
  MovingAverageModel,
  createMovingAverageModel,
  simpleMovingAverage,
  exponentialMovingAverage,
  type MovingAverageOptions,
} from './moving-average.js';

// Exponential Smoothing
export {
  ExponentialSmoothingModel,
  createExponentialSmoothingModel,
  simpleExponentialSmoothing,
  holtsMethod,
  holtWinters,
  type ExponentialSmoothingOptions,
} from './exponential-smoothing.js';

// Linear Regression
export {
  LinearRegressionModel,
  MultipleLinearRegressionModel,
  createLinearRegressionModel,
  linearRegressionForecast,
  type LinearRegressionOptions,
  type RegressionCoefficients,
} from './linear-regression.js';

// Seasonal Decomposition
export {
  SeasonalDecompositionModel,
  createSeasonalDecompositionModel,
  decomposeTimeSeries,
  detectSeasonality,
  type SeasonalDecompositionOptions,
  type DecompositionResult,
} from './seasonal-decomposition.js';

// Re-export types
export type { DataPoint, PredictionPoint, ModelResult, ModelType } from '../types.js';
