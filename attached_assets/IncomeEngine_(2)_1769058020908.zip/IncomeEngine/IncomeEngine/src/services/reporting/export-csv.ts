/**
 * ============================================================================
 * CSV EXPORT SERVICE
 * Generates CSV files from analytics data
 * ============================================================================
 */

export interface CSVExportOptions {
  filename?: string;
  delimiter?: string;
  includeHeaders?: boolean;
  dateFormat?: 'iso' | 'locale' | 'short';
}

export interface CSVColumn<T> {
  key: keyof T | string;
  header: string;
  formatter?: (value: unknown, row: T) => string;
}

/**
 * Convert a value to a CSV-safe string
 */
function escapeCSVValue(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }

  const stringValue = String(value);

  // Escape quotes and wrap in quotes if contains special characters
  if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
    return `"${stringValue.replace(/"/g, '""')}"`;
  }

  return stringValue;
}

/**
 * Format a date value based on the specified format
 */
function formatDate(date: Date | string, format: 'iso' | 'locale' | 'short'): string {
  const d = typeof date === 'string' ? new Date(date) : date;

  switch (format) {
    case 'iso':
      return d.toISOString();
    case 'locale':
      return d.toLocaleString();
    case 'short':
      return d.toLocaleDateString();
    default:
      return d.toISOString();
  }
}

/**
 * Generate CSV content from an array of objects
 */
export function generateCSV<T extends Record<string, unknown>>(
  data: T[],
  columns: CSVColumn<T>[],
  options: CSVExportOptions = {}
): string {
  const {
    delimiter = ',',
    includeHeaders = true,
    dateFormat = 'short',
  } = options;

  const lines: string[] = [];

  // Add header row
  if (includeHeaders) {
    const headerRow = columns.map(col => escapeCSVValue(col.header)).join(delimiter);
    lines.push(headerRow);
  }

  // Add data rows
  for (const row of data) {
    const values = columns.map(col => {
      // Handle nested keys (e.g., 'user.name')
      let value: unknown;
      if (typeof col.key === 'string' && col.key.includes('.')) {
        value = col.key.split('.').reduce((obj: unknown, key) => {
          return obj && typeof obj === 'object' ? (obj as Record<string, unknown>)[key] : undefined;
        }, row);
      } else {
        value = row[col.key as keyof T];
      }

      // Apply formatter if provided
      if (col.formatter) {
        value = col.formatter(value, row);
      }

      // Format dates
      if (value instanceof Date) {
        value = formatDate(value, dateFormat);
      }

      return escapeCSVValue(value);
    });

    lines.push(values.join(delimiter));
  }

  return lines.join('\n');
}

/**
 * Pre-defined column configurations for common data types
 */
export const CSV_COLUMNS = {
  revenue: [
    { key: 'date', header: 'Date' },
    { key: 'revenue', header: 'Revenue ($)', formatter: (v: unknown) => Number(v).toFixed(2) },
    { key: 'orders', header: 'Orders' },
    { key: 'profit', header: 'Profit ($)', formatter: (v: unknown) => Number(v).toFixed(2) },
  ],

  platforms: [
    { key: 'platform', header: 'Platform' },
    { key: 'revenue', header: 'Revenue ($)', formatter: (v: unknown) => Number(v).toFixed(2) },
    { key: 'orders', header: 'Orders' },
    { key: 'products', header: 'Products' },
    { key: 'avgOrderValue', header: 'Avg Order Value ($)', formatter: (v: unknown) => Number(v).toFixed(2) },
    { key: 'growth', header: 'Growth (%)', formatter: (v: unknown) => `${Number(v).toFixed(1)}%` },
  ],

  products: [
    { key: 'id', header: 'Product ID' },
    { key: 'title', header: 'Title' },
    { key: 'platform', header: 'Platform' },
    { key: 'revenue', header: 'Revenue ($)', formatter: (v: unknown) => Number(v).toFixed(2) },
    { key: 'unitsSold', header: 'Units Sold' },
    { key: 'views', header: 'Views' },
    { key: 'conversionRate', header: 'Conversion Rate (%)', formatter: (v: unknown) => `${Number(v).toFixed(2)}%` },
    { key: 'trend', header: 'Trend' },
  ],

  trends: [
    { key: 'metric', header: 'Metric' },
    { key: 'current', header: 'Current Period' },
    { key: 'previous', header: 'Previous Period' },
    { key: 'change', header: 'Change' },
    { key: 'changePercent', header: 'Change (%)', formatter: (v: unknown) => `${Number(v).toFixed(2)}%` },
    { key: 'trend', header: 'Trend' },
  ],
};

/**
 * Generate a complete analytics report as CSV
 */
export function generateAnalyticsReportCSV(
  data: {
    revenue?: unknown[];
    platforms?: unknown[];
    products?: unknown[];
    trends?: unknown[];
  },
  options: CSVExportOptions = {}
): string {
  const sections: string[] = [];
  const separator = '\n\n';

  if (data.revenue && data.revenue.length > 0) {
    sections.push(
      '=== REVENUE DATA ===\n' +
      generateCSV(data.revenue as Record<string, unknown>[], CSV_COLUMNS.revenue as CSVColumn<Record<string, unknown>>[], options)
    );
  }

  if (data.platforms && data.platforms.length > 0) {
    sections.push(
      '=== PLATFORM BREAKDOWN ===\n' +
      generateCSV(data.platforms as Record<string, unknown>[], CSV_COLUMNS.platforms as CSVColumn<Record<string, unknown>>[], options)
    );
  }

  if (data.products && data.products.length > 0) {
    sections.push(
      '=== PRODUCT PERFORMANCE ===\n' +
      generateCSV(data.products as Record<string, unknown>[], CSV_COLUMNS.products as CSVColumn<Record<string, unknown>>[], options)
    );
  }

  if (data.trends && data.trends.length > 0) {
    sections.push(
      '=== TREND DATA ===\n' +
      generateCSV(data.trends as Record<string, unknown>[], CSV_COLUMNS.trends as CSVColumn<Record<string, unknown>>[], options)
    );
  }

  return sections.join(separator);
}

/**
 * Create a downloadable CSV blob
 */
export function createCSVBlob(content: string): Blob {
  return new Blob([content], { type: 'text/csv;charset=utf-8;' });
}

/**
 * Trigger a CSV download in the browser
 */
export function downloadCSV(content: string, filename: string): void {
  const blob = createCSVBlob(content);
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  link.style.display = 'none';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
}

export default {
  generateCSV,
  generateAnalyticsReportCSV,
  createCSVBlob,
  downloadCSV,
  CSV_COLUMNS,
};
