/**
 * ============================================================================
 * EMAIL SENDER SERVICE
 * Sends analytics reports via email
 * ============================================================================
 *
 * Note: This service prepares email payloads. In production, integrate with
 * an email provider like SendGrid, AWS SES, Postmark, or use SMTP.
 */

export interface EmailRecipient {
  email: string;
  name?: string;
}

export interface EmailAttachment {
  filename: string;
  content: string;
  contentType: string;
  encoding?: 'base64' | 'utf8';
}

export interface EmailOptions {
  to: EmailRecipient[];
  cc?: EmailRecipient[];
  bcc?: EmailRecipient[];
  subject: string;
  html?: string;
  text?: string;
  attachments?: EmailAttachment[];
  replyTo?: string;
  scheduledAt?: Date;
}

export interface EmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
  recipientStatus?: Record<string, 'sent' | 'failed' | 'pending'>;
}

export interface ScheduledReport {
  id: string;
  name: string;
  recipients: EmailRecipient[];
  frequency: 'daily' | 'weekly' | 'monthly';
  dayOfWeek?: number; // 0-6 for weekly
  dayOfMonth?: number; // 1-31 for monthly
  hour: number; // 0-23
  timezone: string;
  reportTypes: ('revenue' | 'platforms' | 'products' | 'trends')[];
  lastSentAt?: Date;
  nextScheduledAt: Date;
  isActive: boolean;
}

/**
 * Format currency for email display
 */
function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(value);
}

/**
 * Format percentage with sign
 */
function formatPercent(value: number): string {
  const sign = value >= 0 ? '+' : '';
  return `${sign}${value.toFixed(1)}%`;
}

/**
 * Generate email HTML template for analytics report
 */
export function generateReportEmailHTML(
  data: {
    overview?: {
      totalRevenue: number;
      totalOrders: number;
      totalProfit: number;
      profitMargin: number;
    };
    topPlatforms?: { platform: string; revenue: number; growth: number }[];
    topProducts?: { title: string; revenue: number }[];
  },
  options: {
    title?: string;
    dateRange?: { start: string; end: string };
    recipientName?: string;
  } = {}
): string {
  const {
    title = 'Your Weekly Analytics Report',
    dateRange,
    recipientName,
  } = options;

  const greeting = recipientName ? `Hi ${recipientName},` : 'Hi there,';
  const dateRangeText = dateRange
    ? `${new Date(dateRange.start).toLocaleDateString()} - ${new Date(dateRange.end).toLocaleDateString()}`
    : 'Last 7 days';

  let summaryCards = '';
  if (data.overview) {
    summaryCards = `
      <table width="100%" cellpadding="0" cellspacing="0" style="margin: 20px 0;">
        <tr>
          <td width="25%" style="padding: 10px;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="font-size: 12px; opacity: 0.9;">Total Revenue</div>
              <div style="font-size: 24px; font-weight: 700;">${formatCurrency(data.overview.totalRevenue)}</div>
            </div>
          </td>
          <td width="25%" style="padding: 10px;">
            <div style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="font-size: 12px; opacity: 0.9;">Total Orders</div>
              <div style="font-size: 24px; font-weight: 700;">${data.overview.totalOrders}</div>
            </div>
          </td>
          <td width="25%" style="padding: 10px;">
            <div style="background: linear-gradient(135deg, #ee0979 0%, #ff6a00 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="font-size: 12px; opacity: 0.9;">Total Profit</div>
              <div style="font-size: 24px; font-weight: 700;">${formatCurrency(data.overview.totalProfit)}</div>
            </div>
          </td>
          <td width="25%" style="padding: 10px;">
            <div style="background: linear-gradient(135deg, #4776E6 0%, #8E54E9 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="font-size: 12px; opacity: 0.9;">Profit Margin</div>
              <div style="font-size: 24px; font-weight: 700;">${data.overview.profitMargin.toFixed(1)}%</div>
            </div>
          </td>
        </tr>
      </table>
    `;
  }

  let platformsSection = '';
  if (data.topPlatforms && data.topPlatforms.length > 0) {
    const platformRows = data.topPlatforms
      .slice(0, 5)
      .map(p => `
        <tr>
          <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${p.platform}</td>
          <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; text-align: right;">${formatCurrency(p.revenue)}</td>
          <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; text-align: right; color: ${p.growth >= 0 ? '#22c55e' : '#ef4444'};">${formatPercent(p.growth)}</td>
        </tr>
      `)
      .join('');

    platformsSection = `
      <div style="margin: 30px 0;">
        <h3 style="color: #1e293b; margin-bottom: 15px;">Top Platforms</h3>
        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
          <thead>
            <tr style="background-color: #f1f5f9;">
              <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">Platform</th>
              <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e2e8f0;">Revenue</th>
              <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e2e8f0;">Growth</th>
            </tr>
          </thead>
          <tbody>
            ${platformRows}
          </tbody>
        </table>
      </div>
    `;
  }

  let productsSection = '';
  if (data.topProducts && data.topProducts.length > 0) {
    const productRows = data.topProducts
      .slice(0, 5)
      .map((p, i) => `
        <tr>
          <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${i + 1}</td>
          <td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${p.title}</td>
          <td style="padding: 12px; border-bottom: 1px solid #e2e8f0; text-align: right;">${formatCurrency(p.revenue)}</td>
        </tr>
      `)
      .join('');

    productsSection = `
      <div style="margin: 30px 0;">
        <h3 style="color: #1e293b; margin-bottom: 15px;">Top Products</h3>
        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
          <thead>
            <tr style="background-color: #f1f5f9;">
              <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">#</th>
              <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0;">Product</th>
              <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e2e8f0;">Revenue</th>
            </tr>
          </thead>
          <tbody>
            ${productRows}
          </tbody>
        </table>
      </div>
    `;
  }

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${title}</title>
    </head>
    <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f1f5f9;">
      <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 600px; margin: 0 auto; background-color: #ffffff;">
        <!-- Header -->
        <tr>
          <td style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); padding: 30px; text-align: center;">
            <h1 style="color: white; margin: 0; font-size: 24px;">Income Engine</h1>
            <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0;">${title}</p>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="padding: 30px;">
            <p style="color: #475569; margin: 0 0 20px 0;">${greeting}</p>
            <p style="color: #475569; margin: 0 0 20px 0;">
              Here's your analytics summary for <strong>${dateRangeText}</strong>.
            </p>

            ${summaryCards}
            ${platformsSection}
            ${productsSection}

            <div style="margin: 30px 0; text-align: center;">
              <a href="#" style="display: inline-block; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white; text-decoration: none; padding: 14px 30px; border-radius: 8px; font-weight: 600;">
                View Full Dashboard
              </a>
            </div>

            <p style="color: #475569; margin: 20px 0 0 0;">
              Keep up the great work!
            </p>
            <p style="color: #475569; margin: 10px 0 0 0;">
              - The Income Engine Team
            </p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background-color: #f8fafc; padding: 20px; text-align: center; border-top: 1px solid #e2e8f0;">
            <p style="color: #94a3b8; font-size: 12px; margin: 0;">
              You're receiving this email because you subscribed to analytics reports.
            </p>
            <p style="color: #94a3b8; font-size: 12px; margin: 10px 0 0 0;">
              <a href="#" style="color: #6366f1; text-decoration: none;">Unsubscribe</a> |
              <a href="#" style="color: #6366f1; text-decoration: none;">Manage Preferences</a>
            </p>
          </td>
        </tr>
      </table>
    </body>
    </html>
  `;
}

/**
 * Generate plain text version of the report email
 */
export function generateReportEmailText(
  data: {
    overview?: {
      totalRevenue: number;
      totalOrders: number;
      totalProfit: number;
      profitMargin: number;
    };
  },
  options: {
    title?: string;
    dateRange?: { start: string; end: string };
    recipientName?: string;
  } = {}
): string {
  const { title = 'Your Weekly Analytics Report', dateRange, recipientName } = options;

  const greeting = recipientName ? `Hi ${recipientName},` : 'Hi there,';
  const dateRangeText = dateRange
    ? `${new Date(dateRange.start).toLocaleDateString()} - ${new Date(dateRange.end).toLocaleDateString()}`
    : 'Last 7 days';

  let text = `${title}\n${'='.repeat(title.length)}\n\n`;
  text += `${greeting}\n\n`;
  text += `Here's your analytics summary for ${dateRangeText}.\n\n`;

  if (data.overview) {
    text += `OVERVIEW\n--------\n`;
    text += `Total Revenue: ${formatCurrency(data.overview.totalRevenue)}\n`;
    text += `Total Orders: ${data.overview.totalOrders}\n`;
    text += `Total Profit: ${formatCurrency(data.overview.totalProfit)}\n`;
    text += `Profit Margin: ${data.overview.profitMargin.toFixed(1)}%\n\n`;
  }

  text += `Visit your dashboard for the full report.\n\n`;
  text += `Keep up the great work!\n`;
  text += `- The Income Engine Team\n`;

  return text;
}

/**
 * Send an email (mock implementation)
 * In production, replace with actual email provider integration
 */
export async function sendEmail(options: EmailOptions): Promise<EmailResult> {
  // Validate required fields
  if (!options.to || options.to.length === 0) {
    return {
      success: false,
      error: 'No recipients specified',
    };
  }

  if (!options.subject) {
    return {
      success: false,
      error: 'No subject specified',
    };
  }

  if (!options.html && !options.text) {
    return {
      success: false,
      error: 'No email content specified',
    };
  }

  // In production, integrate with email provider:
  // - SendGrid: await sgMail.send(options)
  // - AWS SES: await ses.sendEmail(params).promise()
  // - Postmark: await client.sendEmail(options)

  console.log('[Email Sender] Would send email:', {
    to: options.to.map(r => r.email),
    subject: options.subject,
    hasHtml: !!options.html,
    hasText: !!options.text,
    attachmentCount: options.attachments?.length || 0,
  });

  // Mock successful response
  return {
    success: true,
    messageId: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    recipientStatus: options.to.reduce((acc, r) => {
      acc[r.email] = 'sent';
      return acc;
    }, {} as Record<string, 'sent' | 'failed' | 'pending'>),
  };
}

/**
 * Schedule a recurring report
 */
export async function scheduleReport(report: Omit<ScheduledReport, 'id' | 'nextScheduledAt'>): Promise<ScheduledReport> {
  // Calculate next scheduled time
  const now = new Date();
  let nextRun = new Date(now);
  nextRun.setHours(report.hour, 0, 0, 0);

  if (nextRun <= now) {
    // If the time has passed today, schedule for next occurrence
    if (report.frequency === 'daily') {
      nextRun.setDate(nextRun.getDate() + 1);
    } else if (report.frequency === 'weekly' && report.dayOfWeek !== undefined) {
      const daysUntil = (report.dayOfWeek - now.getDay() + 7) % 7 || 7;
      nextRun.setDate(nextRun.getDate() + daysUntil);
    } else if (report.frequency === 'monthly' && report.dayOfMonth !== undefined) {
      nextRun.setMonth(nextRun.getMonth() + 1);
      nextRun.setDate(report.dayOfMonth);
    }
  }

  const scheduledReport: ScheduledReport = {
    ...report,
    id: `sched_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    nextScheduledAt: nextRun,
    isActive: true,
  };

  // In production, save to database
  console.log('[Email Sender] Scheduled report:', scheduledReport);

  return scheduledReport;
}

/**
 * Send an analytics report to a list of recipients
 */
export async function sendAnalyticsReport(
  recipients: EmailRecipient[],
  data: Parameters<typeof generateReportEmailHTML>[0],
  options: Parameters<typeof generateReportEmailHTML>[1] & {
    attachCsv?: boolean;
    csvContent?: string;
    attachPdf?: boolean;
    pdfContent?: string;
  } = {}
): Promise<EmailResult> {
  const html = generateReportEmailHTML(data, options);
  const text = generateReportEmailText(data, options);

  const attachments: EmailAttachment[] = [];

  if (options.attachCsv && options.csvContent) {
    attachments.push({
      filename: `analytics-report-${Date.now()}.csv`,
      content: Buffer.from(options.csvContent).toString('base64'),
      contentType: 'text/csv',
      encoding: 'base64',
    });
  }

  if (options.attachPdf && options.pdfContent) {
    attachments.push({
      filename: `analytics-report-${Date.now()}.html`,
      content: Buffer.from(options.pdfContent).toString('base64'),
      contentType: 'text/html',
      encoding: 'base64',
    });
  }

  return sendEmail({
    to: recipients,
    subject: options.title || 'Your Income Engine Analytics Report',
    html,
    text,
    attachments: attachments.length > 0 ? attachments : undefined,
  });
}

export default {
  generateReportEmailHTML,
  generateReportEmailText,
  sendEmail,
  scheduleReport,
  sendAnalyticsReport,
};
