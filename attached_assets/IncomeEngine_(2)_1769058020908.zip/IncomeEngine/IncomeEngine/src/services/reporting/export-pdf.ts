/**
 * ============================================================================
 * PDF EXPORT SERVICE
 * Generates PDF reports from analytics data
 * ============================================================================
 *
 * Note: This service generates HTML that can be printed to PDF via browser's
 * print functionality or converted using a server-side PDF library like
 * puppeteer, pdfkit, or jspdf.
 */

export interface PDFExportOptions {
  title?: string;
  subtitle?: string;
  dateRange?: { start: string; end: string };
  includeCharts?: boolean;
  includeSummary?: boolean;
  brandColor?: string;
  logoUrl?: string;
}

export interface PDFSection {
  title: string;
  type: 'table' | 'summary' | 'chart';
  data: unknown;
}

/**
 * Format currency values
 */
function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(value);
}

/**
 * Format percentage values
 */
function formatPercent(value: number): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`;
}

/**
 * Generate table HTML from data
 */
function generateTableHTML<T extends Record<string, unknown>>(
  data: T[],
  columns: { key: string; header: string; formatter?: (v: unknown) => string }[]
): string {
  const headerRow = columns
    .map(col => `<th style="padding: 12px; text-align: left; border-bottom: 2px solid #e2e8f0; font-weight: 600;">${col.header}</th>`)
    .join('');

  const bodyRows = data
    .map((row, index) => {
      const bgColor = index % 2 === 0 ? '#ffffff' : '#f8fafc';
      const cells = columns
        .map(col => {
          let value = row[col.key];
          if (col.formatter) {
            value = col.formatter(value);
          }
          return `<td style="padding: 12px; border-bottom: 1px solid #e2e8f0;">${value ?? ''}</td>`;
        })
        .join('');
      return `<tr style="background-color: ${bgColor};">${cells}</tr>`;
    })
    .join('');

  return `
    <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
      <thead>
        <tr style="background-color: #f1f5f9;">
          ${headerRow}
        </tr>
      </thead>
      <tbody>
        ${bodyRows}
      </tbody>
    </table>
  `;
}

/**
 * Generate summary cards HTML
 */
function generateSummaryHTML(
  summary: Record<string, { value: number | string; label: string; change?: number }>
): string {
  const cards = Object.entries(summary)
    .map(([key, item]) => {
      const changeColor = item.change && item.change >= 0 ? '#22c55e' : '#ef4444';
      const changeHTML = item.change !== undefined
        ? `<span style="color: ${changeColor}; font-size: 14px;">${formatPercent(item.change)}</span>`
        : '';

      return `
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 24px; border-radius: 12px; flex: 1; min-width: 200px;">
          <div style="font-size: 14px; opacity: 0.9; margin-bottom: 8px;">${item.label}</div>
          <div style="font-size: 28px; font-weight: 700;">${typeof item.value === 'number' ? formatCurrency(item.value) : item.value}</div>
          ${changeHTML}
        </div>
      `;
    })
    .join('');

  return `
    <div style="display: flex; gap: 20px; flex-wrap: wrap; margin: 20px 0;">
      ${cards}
    </div>
  `;
}

/**
 * Generate trend indicator HTML
 */
function generateTrendHTML(trend: 'up' | 'down' | 'stable'): string {
  const icons = {
    up: '<span style="color: #22c55e;">&#9650;</span>',
    down: '<span style="color: #ef4444;">&#9660;</span>',
    stable: '<span style="color: #6b7280;">&#9644;</span>',
  };
  return icons[trend] || icons.stable;
}

/**
 * Generate the full PDF report HTML
 */
export function generatePDFReport(
  data: {
    overview?: {
      totalRevenue: number;
      totalOrders: number;
      totalProfit: number;
      profitMargin: number;
      avgOrderValue: number;
    };
    revenueTimeSeries?: { date: string; revenue: number; orders: number; profit: number }[];
    platformBreakdown?: {
      platform: string;
      revenue: number;
      orders: number;
      products: number;
      growth: number;
    }[];
    topProducts?: {
      title: string;
      platform: string;
      revenue: number;
      unitsSold: number;
      trend: 'up' | 'down' | 'stable';
    }[];
    trends?: {
      metric: string;
      current: number;
      previous: number;
      changePercent: number;
      trend: 'up' | 'down' | 'stable';
    }[];
  },
  options: PDFExportOptions = {}
): string {
  const {
    title = 'Analytics Report',
    subtitle = 'Income Engine Performance Summary',
    dateRange,
    brandColor = '#6366f1',
  } = options;

  const dateRangeText = dateRange
    ? `${new Date(dateRange.start).toLocaleDateString()} - ${new Date(dateRange.end).toLocaleDateString()}`
    : new Date().toLocaleDateString();

  let content = '';

  // Overview Summary
  if (data.overview) {
    content += `
      <section style="margin-bottom: 40px;">
        <h2 style="color: ${brandColor}; border-bottom: 2px solid ${brandColor}; padding-bottom: 10px;">Overview</h2>
        ${generateSummaryHTML({
          revenue: { value: data.overview.totalRevenue, label: 'Total Revenue' },
          orders: { value: data.overview.totalOrders.toString(), label: 'Total Orders' },
          profit: { value: data.overview.totalProfit, label: 'Total Profit' },
          margin: { value: `${data.overview.profitMargin}%`, label: 'Profit Margin' },
          aov: { value: data.overview.avgOrderValue, label: 'Avg Order Value' },
        })}
      </section>
    `;
  }

  // Platform Breakdown
  if (data.platformBreakdown && data.platformBreakdown.length > 0) {
    content += `
      <section style="margin-bottom: 40px;">
        <h2 style="color: ${brandColor}; border-bottom: 2px solid ${brandColor}; padding-bottom: 10px;">Platform Performance</h2>
        ${generateTableHTML(data.platformBreakdown, [
          { key: 'platform', header: 'Platform' },
          { key: 'revenue', header: 'Revenue', formatter: (v) => formatCurrency(v as number) },
          { key: 'orders', header: 'Orders' },
          { key: 'products', header: 'Products' },
          { key: 'growth', header: 'Growth', formatter: (v) => formatPercent(v as number) },
        ])}
      </section>
    `;
  }

  // Top Products
  if (data.topProducts && data.topProducts.length > 0) {
    content += `
      <section style="margin-bottom: 40px;">
        <h2 style="color: ${brandColor}; border-bottom: 2px solid ${brandColor}; padding-bottom: 10px;">Top Products</h2>
        ${generateTableHTML(data.topProducts, [
          { key: 'title', header: 'Product' },
          { key: 'platform', header: 'Platform' },
          { key: 'revenue', header: 'Revenue', formatter: (v) => formatCurrency(v as number) },
          { key: 'unitsSold', header: 'Units Sold' },
          { key: 'trend', header: 'Trend', formatter: (v) => generateTrendHTML(v as 'up' | 'down' | 'stable') },
        ])}
      </section>
    `;
  }

  // Trends
  if (data.trends && data.trends.length > 0) {
    content += `
      <section style="margin-bottom: 40px;">
        <h2 style="color: ${brandColor}; border-bottom: 2px solid ${brandColor}; padding-bottom: 10px;">Key Metrics Trends</h2>
        ${generateTableHTML(data.trends, [
          { key: 'metric', header: 'Metric' },
          { key: 'current', header: 'Current Period' },
          { key: 'previous', header: 'Previous Period' },
          { key: 'changePercent', header: 'Change', formatter: (v) => formatPercent(v as number) },
          { key: 'trend', header: 'Trend', formatter: (v) => generateTrendHTML(v as 'up' | 'down' | 'stable') },
        ])}
      </section>
    `;
  }

  // Revenue Time Series (simplified table for PDF)
  if (data.revenueTimeSeries && data.revenueTimeSeries.length > 0) {
    // Show last 10 days only for brevity
    const recentData = data.revenueTimeSeries.slice(-10);
    content += `
      <section style="margin-bottom: 40px;">
        <h2 style="color: ${brandColor}; border-bottom: 2px solid ${brandColor}; padding-bottom: 10px;">Recent Revenue (Last 10 Days)</h2>
        ${generateTableHTML(recentData, [
          { key: 'date', header: 'Date' },
          { key: 'revenue', header: 'Revenue', formatter: (v) => formatCurrency(v as number) },
          { key: 'orders', header: 'Orders' },
          { key: 'profit', header: 'Profit', formatter: (v) => formatCurrency(v as number) },
        ])}
      </section>
    `;
  }

  // Full HTML document
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${title}</title>
      <style>
        @page {
          size: A4;
          margin: 20mm;
        }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          color: #1e293b;
          line-height: 1.6;
          max-width: 210mm;
          margin: 0 auto;
          padding: 20px;
        }
        @media print {
          body {
            padding: 0;
          }
          section {
            page-break-inside: avoid;
          }
        }
      </style>
    </head>
    <body>
      <header style="text-align: center; margin-bottom: 40px; border-bottom: 3px solid ${brandColor}; padding-bottom: 20px;">
        <h1 style="color: ${brandColor}; margin: 0; font-size: 32px;">${title}</h1>
        <p style="color: #64748b; margin: 10px 0 0 0; font-size: 16px;">${subtitle}</p>
        <p style="color: #94a3b8; margin: 5px 0 0 0; font-size: 14px;">Report Period: ${dateRangeText}</p>
      </header>

      <main>
        ${content}
      </main>

      <footer style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #94a3b8; font-size: 12px;">
        <p>Generated by Income Engine on ${new Date().toLocaleString()}</p>
        <p>This report contains confidential business data. Handle appropriately.</p>
      </footer>
    </body>
    </html>
  `;
}

/**
 * Open print dialog for PDF export
 */
export function printPDFReport(htmlContent: string): void {
  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.onload = () => {
      printWindow.print();
    };
  }
}

/**
 * Create a downloadable HTML file (can be opened and printed as PDF)
 */
export function downloadHTMLReport(htmlContent: string, filename: string): void {
  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.html') ? filename : `${filename}.html`;
  link.style.display = 'none';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
}

export default {
  generatePDFReport,
  printPDFReport,
  downloadHTMLReport,
};
