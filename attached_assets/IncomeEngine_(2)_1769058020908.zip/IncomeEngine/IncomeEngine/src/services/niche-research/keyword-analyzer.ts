/**
 * ============================================================================
 * KEYWORD ANALYZER
 * ============================================================================
 * Analyzes search volume, competition, and keyword metrics for niche research.
 * Supports keyword clustering, suggestions, and intent classification.
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  KeywordMetrics,
  KeywordCluster,
  KeywordSuggestion,
  KeywordAnalysisResult,
  KeywordIntent,
  CompetitionLevel,
  SeasonalPattern,
  KeywordAnalysisRequest,
  KeywordAnalysisResponse,
  RateLimitConfig,
  CacheEntry,
} from './types.js';
import { NicheResearchError, RateLimitError, ValidationError } from './types.js';

// =============================================================================
// CONFIGURATION
// =============================================================================

export interface KeywordAnalyzerConfig {
  readonly cacheEnabled: boolean;
  readonly cacheTtlMinutes: number;
  readonly rateLimiting: RateLimitConfig;
  readonly mockMode: boolean;
  readonly minKeywordLength: number;
  readonly maxKeywordLength: number;
  readonly defaultMaxSuggestions: number;
}

const DEFAULT_CONFIG: KeywordAnalyzerConfig = {
  cacheEnabled: true,
  cacheTtlMinutes: 120,
  rateLimiting: {
    googleTrends: { requestsPerMinute: 10, requestsPerHour: 100, requestsPerDay: 1000 },
    socialApis: { requestsPerMinute: 30, requestsPerHour: 500, requestsPerDay: 5000 },
    scrapers: { requestsPerMinute: 5, requestsPerHour: 50, requestsPerDay: 500 },
  },
  mockMode: process.env.NODE_ENV !== 'production',
  minKeywordLength: 2,
  maxKeywordLength: 100,
  defaultMaxSuggestions: 50,
};

// =============================================================================
// INTENT PATTERNS
// =============================================================================

const INTENT_PATTERNS: Record<KeywordIntent, RegExp[]> = {
  transactional: [
    /\bbuy\b/i,
    /\bpurchase\b/i,
    /\border\b/i,
    /\bshop\b/i,
    /\bdeal\b/i,
    /\bdiscount\b/i,
    /\bcoupon\b/i,
    /\bsale\b/i,
    /\bprice\b/i,
    /\bcheap\b/i,
    /\baffordable\b/i,
  ],
  commercial: [
    /\bbest\b/i,
    /\btop\b/i,
    /\breview\b/i,
    /\bcompare\b/i,
    /\bvs\b/i,
    /\balternative\b/i,
    /\brated\b/i,
    /\brecommend/i,
  ],
  informational: [
    /\bhow\b/i,
    /\bwhat\b/i,
    /\bwhy\b/i,
    /\bwhen\b/i,
    /\bwhere\b/i,
    /\bguide\b/i,
    /\btutorial\b/i,
    /\btips\b/i,
    /\bideas\b/i,
    /\bexamples\b/i,
  ],
  navigational: [
    /\blogin\b/i,
    /\bsign in\b/i,
    /\bwebsite\b/i,
    /\bofficial\b/i,
    /\bcontact\b/i,
    /\blocation\b/i,
  ],
};

// =============================================================================
// RATE LIMITER
// =============================================================================

interface RateLimitState {
  requests: number;
  resetAt: number;
}

class SimpleRateLimiter {
  private readonly state: Map<string, RateLimitState> = new Map();

  checkLimit(source: string, maxRequests: number, windowMs: number = 60000): void {
    const now = Date.now();
    let state = this.state.get(source);

    if (!state || now >= state.resetAt) {
      state = { requests: 0, resetAt: now + windowMs };
      this.state.set(source, state);
    }

    if (state.requests >= maxRequests) {
      throw new RateLimitError(source, state.resetAt - now);
    }

    state.requests++;
  }
}

// =============================================================================
// CACHE
// =============================================================================

class KeywordCache<T> {
  private readonly cache: Map<string, CacheEntry<T>> = new Map();
  private readonly ttlMs: number;

  constructor(ttlMinutes: number) {
    this.ttlMs = ttlMinutes * 60 * 1000;
  }

  get(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() > entry.expiresAt.getTime()) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  set(key: string, data: T, source: string): void {
    const now = new Date();
    this.cache.set(key, {
      data,
      cachedAt: now,
      expiresAt: new Date(now.getTime() + this.ttlMs),
      source,
    });
  }

  clear(): void {
    this.cache.clear();
  }
}

// =============================================================================
// KEYWORD ANALYZER CLASS
// =============================================================================

export class KeywordAnalyzer {
  private readonly config: KeywordAnalyzerConfig;
  private readonly rateLimiter: SimpleRateLimiter;
  private readonly metricsCache: KeywordCache<KeywordMetrics>;
  private readonly analysisCache: KeywordCache<KeywordAnalysisResult>;

  constructor(config?: Partial<KeywordAnalyzerConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.rateLimiter = new SimpleRateLimiter();
    this.metricsCache = new KeywordCache(this.config.cacheTtlMinutes);
    this.analysisCache = new KeywordCache(this.config.cacheTtlMinutes);
  }

  // ===========================================================================
  // PUBLIC METHODS
  // ===========================================================================

  /**
   * Analyze a keyword and get comprehensive metrics
   */
  async analyzeKeyword(request: KeywordAnalysisRequest): Promise<KeywordAnalysisResponse> {
    try {
      this.validateKeyword(request.keyword);

      // Check cache first
      const cacheKey = `analysis:${request.keyword.toLowerCase()}`;
      const cached = this.config.cacheEnabled ? this.analysisCache.get(cacheKey) : null;

      if (cached) {
        return {
          success: true,
          result: cached,
          analyzedAt: cached.analyzedAt,
        };
      }

      // Get metrics
      const metrics = await this.getKeywordMetrics(request.keyword);

      // Get suggestions if requested
      const suggestions = request.includeSuggestions !== false
        ? await this.getSuggestions(request.keyword, request.maxSuggestions)
        : [];

      // Get questions if requested
      const questions = request.includeQuestions !== false
        ? this.generateQuestions(request.keyword)
        : [];

      // Generate long-tail variations
      const longTailVariations = this.generateLongTailVariations(request.keyword);

      // Create clusters from suggestions
      const clusters = this.clusterKeywords(request.keyword, suggestions);

      const result: KeywordAnalysisResult = {
        keyword: request.keyword,
        metrics,
        suggestions,
        clusters,
        longTailVariations,
        questions,
        analyzedAt: new Date(),
      };

      // Cache the result
      if (this.config.cacheEnabled) {
        this.analysisCache.set(cacheKey, result, 'analyzer');
      }

      return {
        success: true,
        result,
        analyzedAt: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        result: null,
        analyzedAt: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      };
    }
  }

  /**
   * Get metrics for a single keyword
   */
  async getKeywordMetrics(keyword: string): Promise<KeywordMetrics> {
    this.validateKeyword(keyword);

    // Check cache
    const cacheKey = `metrics:${keyword.toLowerCase()}`;
    const cached = this.config.cacheEnabled ? this.metricsCache.get(cacheKey) : null;

    if (cached) {
      return cached;
    }

    this.rateLimiter.checkLimit('keywordMetrics', 30);

    let metrics: KeywordMetrics;

    if (this.config.mockMode) {
      metrics = this.generateMockMetrics(keyword);
    } else {
      // In production, integrate with keyword data APIs
      throw new NicheResearchError(
        'Keyword data API integration not configured',
        'NOT_CONFIGURED',
        false
      );
    }

    // Cache the result
    if (this.config.cacheEnabled) {
      this.metricsCache.set(cacheKey, metrics, 'api');
    }

    return metrics;
  }

  /**
   * Get metrics for multiple keywords
   */
  async getBulkKeywordMetrics(keywords: string[]): Promise<Map<string, KeywordMetrics>> {
    const results = new Map<string, KeywordMetrics>();

    for (const keyword of keywords) {
      try {
        const metrics = await this.getKeywordMetrics(keyword);
        results.set(keyword, metrics);
      } catch (error) {
        console.warn(`Failed to get metrics for "${keyword}":`, error);
      }
    }

    return results;
  }

  /**
   * Get keyword suggestions based on a seed keyword
   */
  async getSuggestions(
    keyword: string,
    maxResults?: number
  ): Promise<KeywordSuggestion[]> {
    this.validateKeyword(keyword);
    const limit = maxResults ?? this.config.defaultMaxSuggestions;

    this.rateLimiter.checkLimit('suggestions', 20);

    if (this.config.mockMode) {
      return this.generateMockSuggestions(keyword, limit);
    }

    // In production, integrate with autocomplete APIs
    return this.generateMockSuggestions(keyword, limit);
  }

  /**
   * Classify the intent of a keyword
   */
  classifyIntent(keyword: string): KeywordIntent {
    const lowerKeyword = keyword.toLowerCase();

    // Check each intent pattern
    for (const [intent, patterns] of Object.entries(INTENT_PATTERNS)) {
      for (const pattern of patterns) {
        if (pattern.test(lowerKeyword)) {
          return intent as KeywordIntent;
        }
      }
    }

    // Default to informational for unclassified keywords
    return 'informational';
  }

  /**
   * Calculate keyword difficulty score
   */
  calculateDifficulty(
    searchVolume: number,
    competitionScore: number,
    cpc: number
  ): number {
    // Normalize factors to 0-100 scale
    const volumeScore = Math.min(100, Math.log10(searchVolume + 1) * 20);
    const compScore = competitionScore * 100;
    const cpcScore = Math.min(100, cpc * 20);

    // Weighted combination
    const difficulty = (
      volumeScore * 0.2 +
      compScore * 0.5 +
      cpcScore * 0.3
    );

    return Math.round(Math.min(100, Math.max(0, difficulty)));
  }

  /**
   * Calculate opportunity score
   */
  calculateOpportunity(
    searchVolume: number,
    competitionScore: number,
    difficulty: number
  ): number {
    // High opportunity = high search volume, low competition, low difficulty
    const volumeFactor = Math.min(1, Math.log10(searchVolume + 1) / 5);
    const competitionFactor = 1 - competitionScore;
    const difficultyFactor = 1 - difficulty / 100;

    const opportunity = (
      volumeFactor * 0.4 +
      competitionFactor * 0.35 +
      difficultyFactor * 0.25
    ) * 100;

    return Math.round(Math.min(100, Math.max(0, opportunity)));
  }

  /**
   * Determine competition level from score
   */
  getCompetitionLevel(score: number): CompetitionLevel {
    if (score < 0.25) return 'low';
    if (score < 0.5) return 'medium';
    if (score < 0.75) return 'high';
    return 'very_high';
  }

  /**
   * Generate question variations of a keyword
   */
  generateQuestions(keyword: string): string[] {
    const questionPrefixes = [
      'how to',
      'what is',
      'why do',
      'where to buy',
      'when to',
      'which',
      'can you',
      'should I',
      'is it worth',
      'how much does',
    ];

    const questionSuffixes = [
      'work',
      'cost',
      'last',
      'compare',
      'help',
    ];

    const questions: string[] = [];

    // Prefix questions
    for (const prefix of questionPrefixes) {
      questions.push(`${prefix} ${keyword}`);
    }

    // Suffix questions
    for (const suffix of questionSuffixes) {
      questions.push(`how does ${keyword} ${suffix}`);
    }

    return questions.slice(0, 15);
  }

  /**
   * Generate long-tail keyword variations
   */
  generateLongTailVariations(keyword: string): string[] {
    const modifiers = {
      prefix: ['best', 'top', 'cheap', 'affordable', 'custom', 'unique', 'personalized', 'handmade'],
      suffix: ['for beginners', 'for sale', 'online', 'near me', 'ideas', 'designs', 'templates', 'examples'],
      intent: ['buy', 'shop', 'get', 'find', 'order'],
    };

    const variations: string[] = [];

    // Prefix variations
    for (const prefix of modifiers.prefix) {
      variations.push(`${prefix} ${keyword}`);
    }

    // Suffix variations
    for (const suffix of modifiers.suffix) {
      variations.push(`${keyword} ${suffix}`);
    }

    // Intent variations
    for (const intent of modifiers.intent) {
      variations.push(`${intent} ${keyword}`);
    }

    // Combined variations
    for (const prefix of modifiers.prefix.slice(0, 3)) {
      for (const suffix of modifiers.suffix.slice(0, 3)) {
        variations.push(`${prefix} ${keyword} ${suffix}`);
      }
    }

    return [...new Set(variations)];
  }

  /**
   * Cluster related keywords together
   */
  clusterKeywords(
    primaryKeyword: string,
    suggestions: KeywordSuggestion[]
  ): KeywordCluster[] {
    if (suggestions.length === 0) {
      return [];
    }

    // Simple clustering based on common words
    const clusters: Map<string, KeywordSuggestion[]> = new Map();
    const words = primaryKeyword.toLowerCase().split(/\s+/);

    // Group suggestions by their main modifier
    for (const suggestion of suggestions) {
      const suggestionWords = suggestion.keyword.toLowerCase().split(/\s+/);
      const differingWords = suggestionWords.filter(w => !words.includes(w) && w.length > 2);

      const clusterKey = differingWords[0] || 'general';

      if (!clusters.has(clusterKey)) {
        clusters.set(clusterKey, []);
      }
      clusters.get(clusterKey)!.push(suggestion);
    }

    // Convert to cluster objects
    const result: KeywordCluster[] = [];

    for (const [name, clusterSuggestions] of clusters) {
      if (clusterSuggestions.length < 2) continue;

      const totalVolume = clusterSuggestions.reduce(
        (sum, s) => sum + (s.searchVolume ?? 0),
        0
      );

      const avgRelevance = clusterSuggestions.reduce(
        (sum, s) => sum + s.relevanceScore,
        0
      ) / clusterSuggestions.length;

      result.push({
        id: uuidv4(),
        name: name.charAt(0).toUpperCase() + name.slice(1),
        primaryKeyword,
        relatedKeywords: [], // Would need to fetch full metrics
        totalSearchVolume: totalVolume,
        averageDifficulty: 50, // Placeholder
        averageOpportunity: avgRelevance * 100,
        topicRelevance: avgRelevance,
      });
    }

    return result.sort((a, b) => b.totalSearchVolume - a.totalSearchVolume);
  }

  /**
   * Find keyword gaps compared to competitors
   */
  async findKeywordGaps(
    ourKeywords: string[],
    competitorKeywords: string[]
  ): Promise<string[]> {
    const ourSet = new Set(ourKeywords.map(k => k.toLowerCase()));
    const gaps = competitorKeywords.filter(k => !ourSet.has(k.toLowerCase()));
    return gaps;
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  private validateKeyword(keyword: string): void {
    if (!keyword || typeof keyword !== 'string') {
      throw new ValidationError('keyword', 'Keyword must be a non-empty string');
    }

    const trimmed = keyword.trim();

    if (trimmed.length < this.config.minKeywordLength) {
      throw new ValidationError('keyword', `Keyword must be at least ${this.config.minKeywordLength} characters`);
    }

    if (trimmed.length > this.config.maxKeywordLength) {
      throw new ValidationError('keyword', `Keyword must not exceed ${this.config.maxKeywordLength} characters`);
    }
  }

  // ===========================================================================
  // MOCK DATA GENERATORS
  // ===========================================================================

  private generateMockMetrics(keyword: string): KeywordMetrics {
    const wordCount = keyword.split(/\s+/).length;
    const baseVolume = Math.max(100, Math.floor(50000 / Math.pow(wordCount, 1.5)));

    const searchVolume = Math.floor(baseVolume * (0.5 + Math.random()));
    const searchVolumeChange = (Math.random() - 0.3) * 40;
    const competitionScore = Math.max(0.1, Math.min(0.95, 0.3 + Math.random() * 0.5));
    const cpc = Math.max(0.1, 0.5 + Math.random() * 4);
    const intent = this.classifyIntent(keyword);

    const difficulty = this.calculateDifficulty(searchVolume, competitionScore, cpc);
    const opportunity = this.calculateOpportunity(searchVolume, competitionScore, difficulty);

    // Generate mock seasonality
    const hasSeasonality = Math.random() > 0.6;
    const seasonality: SeasonalPattern | null = hasSeasonality
      ? {
          type: 'annual',
          peakMonths: [10, 11, 0], // Oct, Nov, Dec
          troughMonths: [5, 6, 7], // Jun, Jul, Aug
          amplitude: 0.3 + Math.random() * 0.4,
          confidence: 0.6 + Math.random() * 0.3,
        }
      : null;

    return {
      keyword,
      searchVolume,
      searchVolumeChange,
      competition: this.getCompetitionLevel(competitionScore),
      competitionScore,
      cpc,
      difficulty,
      opportunity,
      intent,
      seasonality,
      updatedAt: new Date(),
    };
  }

  private generateMockSuggestions(keyword: string, limit: number): KeywordSuggestion[] {
    const sources: Array<'autocomplete' | 'related' | 'questions' | 'competitor'> = [
      'autocomplete',
      'related',
      'questions',
      'competitor',
    ];

    const modifiers = [
      'best', 'cheap', 'custom', 'unique', 'personalized', 'handmade', 'vintage',
      'modern', 'minimalist', 'funny', 'cute', 'elegant', 'professional',
    ];

    const suffixes = [
      'ideas', 'designs', 'templates', 'examples', 'for sale', 'shop',
      'online', 'store', 'gift', 'set', 'bundle', 'collection',
    ];

    const suggestions: KeywordSuggestion[] = [];

    // Generate prefix suggestions
    for (const modifier of modifiers.slice(0, Math.ceil(limit / 3))) {
      suggestions.push({
        keyword: `${modifier} ${keyword}`,
        source: sources[Math.floor(Math.random() * sources.length)],
        searchVolume: Math.floor(100 + Math.random() * 5000),
        relevanceScore: 0.7 + Math.random() * 0.3,
      });
    }

    // Generate suffix suggestions
    for (const suffix of suffixes.slice(0, Math.ceil(limit / 3))) {
      suggestions.push({
        keyword: `${keyword} ${suffix}`,
        source: sources[Math.floor(Math.random() * sources.length)],
        searchVolume: Math.floor(100 + Math.random() * 5000),
        relevanceScore: 0.6 + Math.random() * 0.3,
      });
    }

    // Generate combined suggestions
    const remaining = limit - suggestions.length;
    for (let i = 0; i < remaining && i < modifiers.length && i < suffixes.length; i++) {
      suggestions.push({
        keyword: `${modifiers[i]} ${keyword} ${suffixes[i]}`,
        source: 'related',
        searchVolume: Math.floor(50 + Math.random() * 2000),
        relevanceScore: 0.5 + Math.random() * 0.3,
      });
    }

    return suggestions
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, limit);
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createKeywordAnalyzer(config?: Partial<KeywordAnalyzerConfig>): KeywordAnalyzer {
  return new KeywordAnalyzer(config);
}
