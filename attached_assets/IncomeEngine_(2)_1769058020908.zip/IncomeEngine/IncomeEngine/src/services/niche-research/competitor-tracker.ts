/**
 * ============================================================================
 * COMPETITOR TRACKER
 * ============================================================================
 * Monitors competitor listings and pricing across multiple platforms.
 * Supports Etsy, Amazon, and other marketplace tracking with caching.
 */

import { v4 as uuidv4 } from 'uuid';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  CompetitorListing,
  CompetitorPriceHistory,
  CompetitorAnalysis,
  CompetitorAlert,
  PriceRange,
  SellerMetrics,
  TrendDirection,
  CompetitionLevel,
  CompetitorTrackRequest,
  CompetitorTrackResponse,
  RateLimitConfig,
  CacheEntry,
  DBCompetitorListing,
} from './types.js';
import { NicheResearchError, RateLimitError, DataSourceError } from './types.js';

// =============================================================================
// CONFIGURATION
// =============================================================================

export interface CompetitorTrackerConfig {
  readonly supabaseUrl?: string;
  readonly supabaseKey?: string;
  readonly cacheEnabled: boolean;
  readonly cacheTtlMinutes: number;
  readonly rateLimiting: RateLimitConfig;
  readonly mockMode: boolean;
  readonly platforms: readonly string[];
  readonly maxListingsPerScan: number;
  readonly alertThresholds: AlertThresholds;
}

export interface AlertThresholds {
  readonly priceDropPercent: number;
  readonly priceIncreasePercent: number;
  readonly newListingCount: number;
  readonly ratingDropThreshold: number;
}

const DEFAULT_CONFIG: CompetitorTrackerConfig = {
  cacheEnabled: true,
  cacheTtlMinutes: 30,
  rateLimiting: {
    googleTrends: { requestsPerMinute: 10, requestsPerHour: 100, requestsPerDay: 1000 },
    socialApis: { requestsPerMinute: 30, requestsPerHour: 500, requestsPerDay: 5000 },
    scrapers: { requestsPerMinute: 5, requestsPerHour: 50, requestsPerDay: 500 },
  },
  mockMode: process.env.NODE_ENV !== 'production',
  platforms: ['etsy', 'amazon', 'redbubble', 'teepublic'],
  maxListingsPerScan: 100,
  alertThresholds: {
    priceDropPercent: 10,
    priceIncreasePercent: 20,
    newListingCount: 5,
    ratingDropThreshold: 0.5,
  },
};

// =============================================================================
// RATE LIMITER
// =============================================================================

interface RateLimitState {
  requests: number;
  resetAt: number;
}

class PlatformRateLimiter {
  private readonly state: Map<string, RateLimitState> = new Map();

  checkLimit(platform: string, maxRequests: number, windowMs: number = 60000): void {
    const now = Date.now();
    const key = `platform:${platform}`;
    let state = this.state.get(key);

    if (!state || now >= state.resetAt) {
      state = { requests: 0, resetAt: now + windowMs };
      this.state.set(key, state);
    }

    if (state.requests >= maxRequests) {
      throw new RateLimitError(platform, state.resetAt - now);
    }

    state.requests++;
  }
}

// =============================================================================
// CACHE
// =============================================================================

class ListingCache<T> {
  private readonly cache: Map<string, CacheEntry<T>> = new Map();
  private readonly ttlMs: number;

  constructor(ttlMinutes: number) {
    this.ttlMs = ttlMinutes * 60 * 1000;
  }

  get(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() > entry.expiresAt.getTime()) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  set(key: string, data: T, source: string): void {
    const now = new Date();
    this.cache.set(key, {
      data,
      cachedAt: now,
      expiresAt: new Date(now.getTime() + this.ttlMs),
      source,
    });
  }

  clear(): void {
    this.cache.clear();
  }

  getAll(): T[] {
    const now = Date.now();
    const results: T[] = [];

    for (const [key, entry] of this.cache) {
      if (now <= entry.expiresAt.getTime()) {
        results.push(entry.data);
      } else {
        this.cache.delete(key);
      }
    }

    return results;
  }
}

// =============================================================================
// COMPETITOR TRACKER CLASS
// =============================================================================

export class CompetitorTracker {
  private readonly config: CompetitorTrackerConfig;
  private readonly supabase: SupabaseClient | null;
  private readonly rateLimiter: PlatformRateLimiter;
  private readonly listingCache: ListingCache<CompetitorListing[]>;
  private readonly analysisCache: ListingCache<CompetitorAnalysis>;
  private readonly priceHistory: Map<string, CompetitorPriceHistory[]> = new Map();

  constructor(config?: Partial<CompetitorTrackerConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.rateLimiter = new PlatformRateLimiter();
    this.listingCache = new ListingCache(this.config.cacheTtlMinutes);
    this.analysisCache = new ListingCache(this.config.cacheTtlMinutes * 2);

    // Initialize Supabase if credentials provided
    if (this.config.supabaseUrl && this.config.supabaseKey) {
      this.supabase = createClient(this.config.supabaseUrl, this.config.supabaseKey);
    } else {
      this.supabase = null;
    }
  }

  // ===========================================================================
  // PUBLIC METHODS
  // ===========================================================================

  /**
   * Track competitors for a niche
   */
  async trackCompetitors(request: CompetitorTrackRequest): Promise<CompetitorTrackResponse> {
    try {
      const platforms = request.platforms.filter(p => this.config.platforms.includes(p));

      if (platforms.length === 0) {
        throw new NicheResearchError(
          'No valid platforms specified',
          'INVALID_PLATFORMS',
          false
        );
      }

      // Check cache
      const cacheKey = `listings:${request.niche}:${platforms.join(',')}`;
      const cachedListings = this.config.cacheEnabled ? this.listingCache.get(cacheKey) : null;

      let listings: CompetitorListing[];

      if (cachedListings) {
        listings = cachedListings;
      } else {
        listings = [];

        for (const platform of platforms) {
          try {
            const platformListings = await this.fetchPlatformListings(
              request.niche,
              platform,
              request.maxListings ?? this.config.maxListingsPerScan,
              request.priceRange
            );
            listings.push(...platformListings);
          } catch (error) {
            if (error instanceof RateLimitError) {
              console.warn(`Rate limited for ${platform}, skipping...`);
            } else {
              console.error(`Error fetching ${platform} listings:`, error);
            }
          }
        }

        // Sort by relevance/reviews
        listings.sort((a, b) => {
          const scoreA = (a.reviewCount * a.rating) + (a.salesCount ?? 0);
          const scoreB = (b.reviewCount * b.rating) + (b.salesCount ?? 0);
          return scoreB - scoreA;
        });

        // Limit results
        listings = listings.slice(0, request.maxListings ?? this.config.maxListingsPerScan);

        // Cache results
        if (this.config.cacheEnabled && listings.length > 0) {
          this.listingCache.set(cacheKey, listings, 'combined');
        }
      }

      // Analyze competitors
      const analysis = this.analyzeListings(request.niche, listings);

      // Generate alerts
      const alerts = await this.generateAlerts(request.niche, listings);

      // Store in database if available
      if (this.supabase) {
        await this.storeListings(listings);
      }

      return {
        success: true,
        listings,
        analysis,
        alerts,
        scrapedAt: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        listings: [],
        analysis: null,
        alerts: [],
        scrapedAt: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      };
    }
  }

  /**
   * Get listings for a specific platform
   */
  async getListings(
    niche: string,
    platform: string,
    maxListings: number = 50
  ): Promise<CompetitorListing[]> {
    return this.fetchPlatformListings(niche, platform, maxListings);
  }

  /**
   * Get price history for a listing
   */
  async getPriceHistory(listingId: string): Promise<CompetitorPriceHistory[]> {
    // Check in-memory cache first
    const cached = this.priceHistory.get(listingId);
    if (cached && cached.length > 0) {
      return cached;
    }

    // Fetch from database if available
    if (this.supabase) {
      const { data, error } = await this.supabase
        .from('niche_competitor_price_history')
        .select('*')
        .eq('listing_id', listingId)
        .order('recorded_at', { ascending: false })
        .limit(100);

      if (error) {
        throw new DataSourceError('database', error);
      }

      const history: CompetitorPriceHistory[] = (data ?? []).map(row => ({
        listingId: row.listing_id,
        price: row.price,
        currency: row.currency,
        recordedAt: new Date(row.recorded_at),
      }));

      this.priceHistory.set(listingId, history);
      return history;
    }

    return [];
  }

  /**
   * Analyze competitor listings
   */
  analyzeListings(niche: string, listings: CompetitorListing[]): CompetitorAnalysis {
    if (listings.length === 0) {
      return this.createEmptyAnalysis(niche, '');
    }

    const platform = listings[0].platform;
    const prices = listings.map(l => l.price).filter(p => p > 0);
    const ratings = listings.map(l => l.rating).filter(r => r > 0);
    const reviews = listings.map(l => l.reviewCount);

    // Calculate price statistics
    const priceRange = this.calculatePriceRange(prices);
    const averagePrice = prices.length > 0
      ? prices.reduce((a, b) => a + b, 0) / prices.length
      : 0;

    // Calculate rating statistics
    const averageRating = ratings.length > 0
      ? ratings.reduce((a, b) => a + b, 0) / ratings.length
      : 0;
    const averageReviews = reviews.length > 0
      ? reviews.reduce((a, b) => a + b, 0) / reviews.length
      : 0;

    // Identify top sellers
    const topSellers = this.identifyTopSellers(listings);

    // Determine price trend (would need historical data)
    const priceTrend: TrendDirection = 'stable';

    // Calculate saturation and entry barrier
    const saturationLevel = this.calculateSaturation(listings);
    const entryBarrier = this.calculateEntryBarrier(listings, averageReviews);

    return {
      niche,
      platform,
      totalListings: listings.length,
      averagePrice: Math.round(averagePrice * 100) / 100,
      priceRange,
      averageRating: Math.round(averageRating * 100) / 100,
      averageReviews: Math.round(averageReviews),
      topSellers,
      priceTrend,
      saturationLevel,
      entryBarrier,
      analyzedAt: new Date(),
    };
  }

  /**
   * Get top sellers in a niche
   */
  async getTopSellers(
    niche: string,
    platform: string,
    limit: number = 10
  ): Promise<SellerMetrics[]> {
    const listings = await this.getListings(niche, platform, 100);
    const sellers = this.identifyTopSellers(listings);
    return sellers.slice(0, limit);
  }

  /**
   * Compare our pricing with competitors
   */
  comparePricing(
    ourPrice: number,
    competitorListings: CompetitorListing[]
  ): {
    position: 'lowest' | 'below_avg' | 'average' | 'above_avg' | 'highest';
    percentile: number;
    averageCompetitorPrice: number;
    priceGap: number;
    recommendation: string;
  } {
    if (competitorListings.length === 0) {
      return {
        position: 'average',
        percentile: 50,
        averageCompetitorPrice: ourPrice,
        priceGap: 0,
        recommendation: 'No competitor data available for comparison',
      };
    }

    const prices = competitorListings.map(l => l.price).sort((a, b) => a - b);
    const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length;
    const priceGap = ((ourPrice - avgPrice) / avgPrice) * 100;

    // Calculate percentile
    const belowCount = prices.filter(p => p < ourPrice).length;
    const percentile = Math.round((belowCount / prices.length) * 100);

    // Determine position
    let position: 'lowest' | 'below_avg' | 'average' | 'above_avg' | 'highest';
    if (percentile <= 10) position = 'lowest';
    else if (percentile <= 40) position = 'below_avg';
    else if (percentile <= 60) position = 'average';
    else if (percentile <= 90) position = 'above_avg';
    else position = 'highest';

    // Generate recommendation
    let recommendation: string;
    if (position === 'highest') {
      recommendation = 'Your price is among the highest. Consider lowering to be more competitive or emphasize premium quality.';
    } else if (position === 'above_avg') {
      recommendation = 'Your price is above average. Ensure your product offers clear value differentiation.';
    } else if (position === 'average') {
      recommendation = 'Your price is competitive. Focus on other differentiators like quality, shipping, or customer service.';
    } else if (position === 'below_avg') {
      recommendation = 'Your price is below average. You may have room to increase price without losing competitiveness.';
    } else {
      recommendation = 'Your price is among the lowest. Consider if you can increase margin while staying competitive.';
    }

    return {
      position,
      percentile,
      averageCompetitorPrice: Math.round(avgPrice * 100) / 100,
      priceGap: Math.round(priceGap * 100) / 100,
      recommendation,
    };
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  private async fetchPlatformListings(
    niche: string,
    platform: string,
    maxListings: number,
    priceRange?: { min: number; max: number }
  ): Promise<CompetitorListing[]> {
    this.rateLimiter.checkLimit(platform, this.config.rateLimiting.scrapers.requestsPerMinute);

    if (this.config.mockMode) {
      return this.generateMockListings(niche, platform, maxListings, priceRange);
    }

    // In production, implement platform-specific scrapers
    throw new DataSourceError(platform, new Error('Platform scraper not implemented'));
  }

  private async generateAlerts(
    niche: string,
    listings: CompetitorListing[]
  ): Promise<CompetitorAlert[]> {
    const alerts: CompetitorAlert[] = [];

    // Check for new listings (would need historical comparison)
    // For now, just detect listings with very few reviews (likely new)
    const newListings = listings.filter(l => l.reviewCount < 5);
    if (newListings.length >= this.config.alertThresholds.newListingCount) {
      alerts.push({
        id: uuidv4(),
        type: 'new_listing',
        niche,
        platform: listings[0]?.platform ?? 'unknown',
        listing: newListings[0],
        previousValue: null,
        currentValue: newListings.length.toString(),
        changePercent: null,
        severity: 'medium',
        createdAt: new Date(),
      });
    }

    // Check for trending products (high sales/reviews ratio)
    const trendingListings = listings.filter(l => {
      const salesPerDay = (l.salesCount ?? 0) / 30; // Assume monthly data
      return salesPerDay > 10 && l.rating >= 4.5;
    });

    for (const listing of trendingListings.slice(0, 3)) {
      alerts.push({
        id: uuidv4(),
        type: 'trending_product',
        niche,
        platform: listing.platform,
        listing,
        previousValue: null,
        currentValue: `${listing.salesCount} sales`,
        changePercent: null,
        severity: 'high',
        createdAt: new Date(),
      });
    }

    return alerts;
  }

  private async storeListings(listings: CompetitorListing[]): Promise<void> {
    if (!this.supabase || listings.length === 0) return;

    const dbListings: Partial<DBCompetitorListing>[] = listings.map(l => ({
      id: l.id,
      platform: l.platform,
      external_id: l.externalId,
      seller_id: l.sellerId,
      seller_name: l.sellerName,
      niche: '', // Would need to be passed in
      title: l.title,
      description: l.description,
      url: l.url,
      image_url: l.imageUrl,
      price: l.price,
      currency: l.currency,
      original_price: l.originalPrice,
      review_count: l.reviewCount,
      rating: l.rating,
      sales_count: l.salesCount,
      favorites: l.favorites,
      tags: l.tags as string[],
      categories: l.categories as string[],
      scraped_at: l.scrapedAt.toISOString(),
    }));

    const { error } = await this.supabase
      .from('niche_competitor_listings')
      .upsert(dbListings, { onConflict: 'platform,external_id' });

    if (error) {
      console.error('Failed to store listings:', error);
    }
  }

  private calculatePriceRange(prices: number[]): PriceRange {
    if (prices.length === 0) {
      return { min: 0, max: 0, median: 0, percentile25: 0, percentile75: 0 };
    }

    const sorted = [...prices].sort((a, b) => a - b);
    const len = sorted.length;

    return {
      min: sorted[0],
      max: sorted[len - 1],
      median: sorted[Math.floor(len / 2)],
      percentile25: sorted[Math.floor(len * 0.25)],
      percentile75: sorted[Math.floor(len * 0.75)],
    };
  }

  private identifyTopSellers(listings: CompetitorListing[]): SellerMetrics[] {
    // Group by seller
    const sellerMap: Map<string, CompetitorListing[]> = new Map();

    for (const listing of listings) {
      const key = `${listing.platform}:${listing.sellerId}`;
      if (!sellerMap.has(key)) {
        sellerMap.set(key, []);
      }
      sellerMap.get(key)!.push(listing);
    }

    // Calculate metrics for each seller
    const sellers: SellerMetrics[] = [];

    for (const [_, sellerListings] of sellerMap) {
      if (sellerListings.length === 0) continue;

      const first = sellerListings[0];
      const prices = sellerListings.map(l => l.price);
      const totalReviews = sellerListings.reduce((sum, l) => sum + l.reviewCount, 0);
      const avgRating = sellerListings.reduce((sum, l) => sum + l.rating, 0) / sellerListings.length;
      const totalSales = sellerListings.reduce((sum, l) => sum + (l.salesCount ?? 0), 0);

      sellers.push({
        sellerId: first.sellerId,
        sellerName: first.sellerName,
        platform: first.platform,
        listingCount: sellerListings.length,
        totalSales: totalSales > 0 ? totalSales : null,
        averageRating: Math.round(avgRating * 100) / 100,
        totalReviews,
        priceRange: this.calculatePriceRange(prices),
        marketShare: null, // Would need total market data
      });
    }

    // Sort by total sales or reviews
    return sellers
      .sort((a, b) => (b.totalSales ?? b.totalReviews) - (a.totalSales ?? a.totalReviews))
      .slice(0, 10);
  }

  private calculateSaturation(listings: CompetitorListing[]): CompetitionLevel {
    const count = listings.length;
    const avgReviews = listings.reduce((sum, l) => sum + l.reviewCount, 0) / listings.length;

    if (count < 10 && avgReviews < 50) return 'low';
    if (count < 50 && avgReviews < 200) return 'medium';
    if (count < 200 && avgReviews < 1000) return 'high';
    return 'very_high';
  }

  private calculateEntryBarrier(
    listings: CompetitorListing[],
    avgReviews: number
  ): CompetitionLevel {
    // Entry barrier based on competitor strength
    const topListings = listings.slice(0, 10);
    const topAvgReviews = topListings.reduce((sum, l) => sum + l.reviewCount, 0) / topListings.length;
    const topAvgRating = topListings.reduce((sum, l) => sum + l.rating, 0) / topListings.length;

    if (topAvgReviews < 100 && topAvgRating < 4.5) return 'low';
    if (topAvgReviews < 500 && topAvgRating < 4.7) return 'medium';
    if (topAvgReviews < 2000) return 'high';
    return 'very_high';
  }

  private createEmptyAnalysis(niche: string, platform: string): CompetitorAnalysis {
    return {
      niche,
      platform,
      totalListings: 0,
      averagePrice: 0,
      priceRange: { min: 0, max: 0, median: 0, percentile25: 0, percentile75: 0 },
      averageRating: 0,
      averageReviews: 0,
      topSellers: [],
      priceTrend: 'stable',
      saturationLevel: 'low',
      entryBarrier: 'low',
      analyzedAt: new Date(),
    };
  }

  // ===========================================================================
  // MOCK DATA GENERATORS
  // ===========================================================================

  private generateMockListings(
    niche: string,
    platform: string,
    count: number,
    priceRange?: { min: number; max: number }
  ): CompetitorListing[] {
    const minPrice = priceRange?.min ?? 5;
    const maxPrice = priceRange?.max ?? 100;

    const listings: CompetitorListing[] = [];
    const sellers = this.generateMockSellers(platform, Math.ceil(count / 5));

    for (let i = 0; i < count; i++) {
      const seller = sellers[Math.floor(Math.random() * sellers.length)];
      const price = minPrice + Math.random() * (maxPrice - minPrice);
      const hasDiscount = Math.random() > 0.7;
      const originalPrice = hasDiscount ? price * (1.1 + Math.random() * 0.4) : null;

      listings.push({
        id: uuidv4(),
        platform,
        externalId: `${platform}-${i + 1}`,
        sellerId: seller.id,
        sellerName: seller.name,
        title: `${this.capitalize(niche)} Design ${i + 1} - ${seller.name}`,
        description: `High quality ${niche} product with premium materials and unique design.`,
        url: `https://${platform}.com/listing/${i + 1}`,
        imageUrl: `https://placeholder.com/${niche}/${i + 1}.jpg`,
        price: Math.round(price * 100) / 100,
        currency: 'USD',
        originalPrice: originalPrice ? Math.round(originalPrice * 100) / 100 : null,
        reviewCount: Math.floor(Math.random() * 1000),
        rating: 3.5 + Math.random() * 1.5,
        salesCount: Math.floor(Math.random() * 500),
        favorites: Math.floor(Math.random() * 200),
        tags: [niche, 'trending', 'gift', 'unique'].slice(0, 2 + Math.floor(Math.random() * 3)),
        categories: [niche, 'Home & Living', 'Art & Collectibles'].slice(0, 2),
        createdAt: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000),
        scrapedAt: new Date(),
      });
    }

    return listings;
  }

  private generateMockSellers(platform: string, count: number): { id: string; name: string }[] {
    const names = [
      'DesignStudio', 'CreativeShop', 'ArtisanCraft', 'ModernMade', 'UniqueFinds',
      'TrendyDesigns', 'QualityCraft', 'PremiumGoods', 'HandmadeHaven', 'StyleStudio',
    ];

    return Array.from({ length: count }, (_, i) => ({
      id: `seller-${i + 1}`,
      name: `${names[i % names.length]}${platform.charAt(0).toUpperCase()}${i + 1}`,
    }));
  }

  private capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createCompetitorTracker(
  config?: Partial<CompetitorTrackerConfig>
): CompetitorTracker {
  return new CompetitorTracker(config);
}
