/**
 * ============================================================================
 * TREND SCANNER
 * ============================================================================
 * Scans Google Trends and social signals for trending topics and niches.
 * Supports multiple data sources with rate limiting and caching.
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  TrendSignal,
  TrendSource,
  TrendDataPoint,
  TrendDirection,
  GoogleTrendsData,
  SocialSignal,
  SocialPlatform,
  SocialPost,
  RelatedQuery,
  RelatedTopic,
  RegionInterest,
  SeasonalPattern,
  TrendScanRequest,
  TrendScanResponse,
  RateLimitConfig,
  CacheEntry,
  DataSourceWeights,
} from './types.js';
import { NicheResearchError, RateLimitError, DataSourceError } from './types.js';

// =============================================================================
// CONFIGURATION
// =============================================================================

export interface TrendScannerConfig {
  readonly cacheEnabled: boolean;
  readonly cacheTtlMinutes: number;
  readonly rateLimiting: RateLimitConfig;
  readonly dataSourceWeights: DataSourceWeights;
  readonly mockMode: boolean;
}

const DEFAULT_CONFIG: TrendScannerConfig = {
  cacheEnabled: true,
  cacheTtlMinutes: 60,
  rateLimiting: {
    googleTrends: { requestsPerMinute: 10, requestsPerHour: 100, requestsPerDay: 1000 },
    socialApis: { requestsPerMinute: 30, requestsPerHour: 500, requestsPerDay: 5000 },
    scrapers: { requestsPerMinute: 5, requestsPerHour: 50, requestsPerDay: 500 },
  },
  dataSourceWeights: {
    googleTrends: 0.35,
    pinterest: 0.15,
    etsy: 0.15,
    amazon: 0.10,
    reddit: 0.10,
    twitter: 0.08,
    tiktok: 0.07,
  },
  mockMode: process.env.NODE_ENV !== 'production',
};

// =============================================================================
// RATE LIMITER
// =============================================================================

interface RateLimitState {
  minuteRequests: number;
  hourRequests: number;
  dayRequests: number;
  minuteResetAt: number;
  hourResetAt: number;
  dayResetAt: number;
}

class RateLimiter {
  private readonly state: Map<string, RateLimitState> = new Map();

  checkLimit(source: string, config: { requestsPerMinute: number; requestsPerHour: number; requestsPerDay: number }): void {
    const now = Date.now();
    let state = this.state.get(source);

    if (!state) {
      state = {
        minuteRequests: 0,
        hourRequests: 0,
        dayRequests: 0,
        minuteResetAt: now + 60000,
        hourResetAt: now + 3600000,
        dayResetAt: now + 86400000,
      };
      this.state.set(source, state);
    }

    // Reset counters if windows have passed
    if (now >= state.minuteResetAt) {
      state.minuteRequests = 0;
      state.minuteResetAt = now + 60000;
    }
    if (now >= state.hourResetAt) {
      state.hourRequests = 0;
      state.hourResetAt = now + 3600000;
    }
    if (now >= state.dayResetAt) {
      state.dayRequests = 0;
      state.dayResetAt = now + 86400000;
    }

    // Check limits
    if (state.minuteRequests >= config.requestsPerMinute) {
      throw new RateLimitError(source, state.minuteResetAt - now);
    }
    if (state.hourRequests >= config.requestsPerHour) {
      throw new RateLimitError(source, state.hourResetAt - now);
    }
    if (state.dayRequests >= config.requestsPerDay) {
      throw new RateLimitError(source, state.dayResetAt - now);
    }

    // Increment counters
    state.minuteRequests++;
    state.hourRequests++;
    state.dayRequests++;
  }
}

// =============================================================================
// CACHE
// =============================================================================

class TrendCache<T> {
  private readonly cache: Map<string, CacheEntry<T>> = new Map();
  private readonly ttlMs: number;

  constructor(ttlMinutes: number) {
    this.ttlMs = ttlMinutes * 60 * 1000;
  }

  get(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() > entry.expiresAt.getTime()) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  set(key: string, data: T, source: string): void {
    const now = new Date();
    this.cache.set(key, {
      data,
      cachedAt: now,
      expiresAt: new Date(now.getTime() + this.ttlMs),
      source,
    });
  }

  clear(): void {
    this.cache.clear();
  }

  getStats(): { hits: number; size: number } {
    return { hits: 0, size: this.cache.size };
  }
}

// =============================================================================
// TREND SCANNER CLASS
// =============================================================================

export class TrendScanner {
  private readonly config: TrendScannerConfig;
  private readonly rateLimiter: RateLimiter;
  private readonly trendCache: TrendCache<TrendSignal[]>;
  private readonly socialCache: TrendCache<SocialSignal[]>;

  constructor(config?: Partial<TrendScannerConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.rateLimiter = new RateLimiter();
    this.trendCache = new TrendCache(this.config.cacheTtlMinutes);
    this.socialCache = new TrendCache(this.config.cacheTtlMinutes);
  }

  // ===========================================================================
  // PUBLIC METHODS
  // ===========================================================================

  /**
   * Scan trends for given keywords
   */
  async scanTrends(request: TrendScanRequest): Promise<TrendScanResponse> {
    const startTime = Date.now();

    try {
      const sources = request.sources ?? ['google_trends', 'social'];
      const trends: TrendSignal[] = [];
      const socialSignals: SocialSignal[] = [];

      // Scan each keyword
      for (const keyword of request.keywords) {
        // Check cache first
        const cacheKey = `trend:${keyword}:${request.timeRange ?? 'month'}`;
        const cached = this.config.cacheEnabled ? this.trendCache.get(cacheKey) : null;

        if (cached) {
          trends.push(...cached);
        } else {
          // Fetch from sources
          for (const source of sources) {
            try {
              if (source === 'google_trends') {
                const trendSignal = await this.fetchGoogleTrends(keyword, request.timeRange, request.region);
                trends.push(trendSignal);
              } else if (source === 'social' && request.includeSocial !== false) {
                const signals = await this.fetchSocialSignals(keyword);
                socialSignals.push(...signals);
              } else {
                const trendSignal = await this.fetchPlatformTrend(keyword, source);
                trends.push(trendSignal);
              }
            } catch (error) {
              if (error instanceof RateLimitError) {
                console.warn(`Rate limited for ${source}, skipping...`);
              } else {
                console.error(`Error fetching ${source} for ${keyword}:`, error);
              }
            }
          }

          // Cache results
          if (this.config.cacheEnabled && trends.length > 0) {
            const keywordTrends = trends.filter(t => t.keyword === keyword);
            this.trendCache.set(cacheKey, keywordTrends, 'combined');
          }
        }
      }

      // Analyze rising and falling keywords
      const risingKeywords = trends
        .filter(t => t.direction === 'rising' || t.direction === 'emerging')
        .sort((a, b) => b.velocity - a.velocity)
        .map(t => t.keyword);

      const fallingKeywords = trends
        .filter(t => t.direction === 'falling')
        .sort((a, b) => a.velocity - b.velocity)
        .map(t => t.keyword);

      return {
        success: true,
        trends,
        socialSignals,
        risingKeywords: [...new Set(risingKeywords)],
        fallingKeywords: [...new Set(fallingKeywords)],
        scannedAt: new Date(),
      };
    } catch (error) {
      return {
        success: false,
        trends: [],
        socialSignals: [],
        risingKeywords: [],
        fallingKeywords: [],
        scannedAt: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      };
    }
  }

  /**
   * Get Google Trends data for a keyword
   */
  async getGoogleTrendsData(
    keyword: string,
    timeRange?: string,
    region?: string
  ): Promise<GoogleTrendsData> {
    this.rateLimiter.checkLimit('googleTrends', this.config.rateLimiting.googleTrends);

    if (this.config.mockMode) {
      return this.generateMockGoogleTrendsData(keyword);
    }

    // In production, integrate with Google Trends API or pytrends
    throw new NicheResearchError(
      'Google Trends API integration not configured',
      'NOT_CONFIGURED',
      false
    );
  }

  /**
   * Get social signals for a keyword
   */
  async getSocialSignals(
    keyword: string,
    platforms?: SocialPlatform[]
  ): Promise<SocialSignal[]> {
    const targetPlatforms = platforms ?? ['reddit', 'twitter', 'tiktok'];
    const signals: SocialSignal[] = [];

    for (const platform of targetPlatforms) {
      try {
        this.rateLimiter.checkLimit('socialApis', this.config.rateLimiting.socialApis);
        const signal = await this.fetchPlatformSocialSignal(keyword, platform);
        signals.push(signal);
      } catch (error) {
        if (error instanceof RateLimitError) {
          console.warn(`Rate limited for ${platform} social API`);
        } else {
          console.error(`Error fetching ${platform} signals:`, error);
        }
      }
    }

    return signals;
  }

  /**
   * Detect emerging niches from trend data
   */
  async detectEmergingNiches(
    keywords: string[],
    options?: {
      minVelocity?: number;
      minScore?: number;
      maxResults?: number;
    }
  ): Promise<{ keyword: string; score: number; velocity: number; potential: number }[]> {
    const minVelocity = options?.minVelocity ?? 0.1;
    const minScore = options?.minScore ?? 20;
    const maxResults = options?.maxResults ?? 20;

    const scanResult = await this.scanTrends({
      keywords,
      sources: ['google_trends'],
      includeSocial: true,
    });

    if (!scanResult.success) {
      return [];
    }

    const emerging = scanResult.trends
      .filter(t => t.currentScore >= minScore && t.velocity >= minVelocity)
      .map(t => ({
        keyword: t.keyword,
        score: t.currentScore,
        velocity: t.velocity,
        potential: t.currentScore * (1 + t.velocity) * (1 + t.momentum * 0.5),
      }))
      .sort((a, b) => b.potential - a.potential)
      .slice(0, maxResults);

    return emerging;
  }

  /**
   * Find related trending keywords
   */
  async findRelatedTrends(
    keyword: string,
    maxResults: number = 20
  ): Promise<{ keyword: string; score: number; type: 'rising' | 'top' }[]> {
    const trendsData = await this.getGoogleTrendsData(keyword);

    const related: { keyword: string; score: number; type: 'rising' | 'top' }[] = [];

    for (const query of trendsData.relatedQueries) {
      related.push({
        keyword: query.query,
        score: query.score,
        type: query.type,
      });
    }

    return related
      .sort((a, b) => {
        // Prioritize rising over top
        if (a.type === 'rising' && b.type !== 'rising') return -1;
        if (b.type === 'rising' && a.type !== 'rising') return 1;
        return b.score - a.score;
      })
      .slice(0, maxResults);
  }

  /**
   * Analyze seasonality patterns
   */
  analyzeSeasonality(dataPoints: TrendDataPoint[]): SeasonalPattern | null {
    if (dataPoints.length < 52) {
      // Need at least a year of weekly data
      return null;
    }

    // Calculate monthly averages
    const monthlyData: Map<number, number[]> = new Map();

    for (const point of dataPoints) {
      const month = point.date.getMonth();
      if (!monthlyData.has(month)) {
        monthlyData.set(month, []);
      }
      monthlyData.get(month)!.push(point.value);
    }

    const monthlyAverages: { month: number; avg: number }[] = [];
    for (const [month, values] of monthlyData) {
      const avg = values.reduce((a, b) => a + b, 0) / values.length;
      monthlyAverages.push({ month, avg });
    }

    if (monthlyAverages.length < 6) {
      return null;
    }

    // Calculate overall average
    const overallAvg = monthlyAverages.reduce((a, b) => a + b.avg, 0) / monthlyAverages.length;

    // Find peaks and troughs
    const sorted = [...monthlyAverages].sort((a, b) => b.avg - a.avg);
    const peakMonths = sorted.slice(0, 3).map(m => m.month);
    const troughMonths = sorted.slice(-3).map(m => m.month);

    // Calculate amplitude (strength of seasonality)
    const maxAvg = Math.max(...monthlyAverages.map(m => m.avg));
    const minAvg = Math.min(...monthlyAverages.map(m => m.avg));
    const amplitude = overallAvg > 0 ? (maxAvg - minAvg) / overallAvg : 0;

    // Calculate confidence based on consistency
    const variance = monthlyAverages.reduce((sum, m) => sum + Math.pow(m.avg - overallAvg, 2), 0) / monthlyAverages.length;
    const stdDev = Math.sqrt(variance);
    const coefficientOfVariation = overallAvg > 0 ? stdDev / overallAvg : 0;
    const confidence = Math.min(1, coefficientOfVariation * 2);

    if (amplitude < 0.2) {
      return {
        type: 'none',
        peakMonths: [],
        troughMonths: [],
        amplitude: 0,
        confidence: 0,
      };
    }

    return {
      type: 'annual',
      peakMonths,
      troughMonths,
      amplitude,
      confidence,
    };
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  private async fetchGoogleTrends(
    keyword: string,
    timeRange?: string,
    region?: string
  ): Promise<TrendSignal> {
    this.rateLimiter.checkLimit('googleTrends', this.config.rateLimiting.googleTrends);

    if (this.config.mockMode) {
      return this.generateMockTrendSignal(keyword, 'google_trends');
    }

    const trendsData = await this.getGoogleTrendsData(keyword, timeRange, region);
    return this.convertGoogleTrendsToSignal(keyword, trendsData);
  }

  private async fetchSocialSignals(keyword: string): Promise<SocialSignal[]> {
    const platforms: SocialPlatform[] = ['reddit', 'twitter', 'tiktok'];
    return this.getSocialSignals(keyword, platforms);
  }

  private async fetchPlatformTrend(
    keyword: string,
    source: TrendSource
  ): Promise<TrendSignal> {
    this.rateLimiter.checkLimit('scrapers', this.config.rateLimiting.scrapers);

    if (this.config.mockMode) {
      return this.generateMockTrendSignal(keyword, source);
    }

    // In production, implement platform-specific scrapers
    throw new DataSourceError(source, new Error('Platform scraper not implemented'));
  }

  private async fetchPlatformSocialSignal(
    keyword: string,
    platform: SocialPlatform
  ): Promise<SocialSignal> {
    if (this.config.mockMode) {
      return this.generateMockSocialSignal(keyword, platform);
    }

    // In production, integrate with platform APIs
    throw new DataSourceError(platform, new Error('Social API not implemented'));
  }

  private convertGoogleTrendsToSignal(keyword: string, data: GoogleTrendsData): TrendSignal {
    const dataPoints = data.interestOverTime;

    if (dataPoints.length === 0) {
      return this.createEmptyTrendSignal(keyword, 'google_trends');
    }

    const currentScore = dataPoints[dataPoints.length - 1].value;
    const previousIndex = Math.max(0, dataPoints.length - 8);
    const previousScore = dataPoints[previousIndex].value;

    const changePercent = previousScore > 0
      ? ((currentScore - previousScore) / previousScore) * 100
      : 0;

    const velocity = this.calculateVelocity(dataPoints.map(d => d.value));
    const momentum = this.calculateMomentum(dataPoints.map(d => d.value));
    const direction = this.determineDirection(changePercent, velocity);

    return {
      id: uuidv4(),
      keyword,
      source: 'google_trends',
      currentScore,
      previousScore,
      changePercent,
      direction,
      velocity,
      momentum,
      dataPoints,
      lastUpdated: new Date(),
    };
  }

  private calculateVelocity(values: number[]): number {
    if (values.length < 2) return 0;

    const windowSize = Math.min(7, values.length - 1);
    const recent = values.slice(-windowSize - 1);

    let totalChange = 0;
    for (let i = 1; i < recent.length; i++) {
      if (recent[i - 1] !== 0) {
        totalChange += (recent[i] - recent[i - 1]) / recent[i - 1];
      }
    }

    return totalChange / (recent.length - 1);
  }

  private calculateMomentum(values: number[]): number {
    if (values.length < 14) return 0;

    const midpoint = Math.floor(values.length / 2);
    const firstHalfVelocity = this.calculateVelocity(values.slice(0, midpoint));
    const secondHalfVelocity = this.calculateVelocity(values.slice(midpoint));

    return secondHalfVelocity - firstHalfVelocity;
  }

  private determineDirection(changePercent: number, velocity: number): TrendDirection {
    const absChange = Math.abs(changePercent);
    const absVelocity = Math.abs(velocity);

    // Check for volatility
    if (absVelocity > 0.5 && absChange < 20) {
      return 'volatile';
    }

    // Check for emerging (low base but rising fast)
    if (velocity > 0.3 && absChange > 50) {
      return 'emerging';
    }

    if (absChange < 10) {
      return 'stable';
    }

    return changePercent > 0 ? 'rising' : 'falling';
  }

  private createEmptyTrendSignal(keyword: string, source: TrendSource): TrendSignal {
    return {
      id: uuidv4(),
      keyword,
      source,
      currentScore: 0,
      previousScore: 0,
      changePercent: 0,
      direction: 'stable',
      velocity: 0,
      momentum: 0,
      dataPoints: [],
      lastUpdated: new Date(),
    };
  }

  // ===========================================================================
  // MOCK DATA GENERATORS
  // ===========================================================================

  private generateMockTrendSignal(keyword: string, source: TrendSource): TrendSignal {
    const baseScore = 30 + Math.random() * 50;
    const velocity = (Math.random() - 0.3) * 0.5;
    const momentum = (Math.random() - 0.4) * 0.3;
    const changePercent = velocity * 100;

    const direction = this.determineDirection(changePercent, velocity);

    // Generate mock data points
    const dataPoints: TrendDataPoint[] = [];
    const now = new Date();
    for (let i = 52; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i * 7);
      const seasonalFactor = 1 + 0.2 * Math.sin((date.getMonth() / 12) * Math.PI * 2);
      const trendFactor = 1 + velocity * (52 - i) / 52;
      const noise = 0.9 + Math.random() * 0.2;
      dataPoints.push({
        date,
        value: Math.round(baseScore * seasonalFactor * trendFactor * noise),
        source,
      });
    }

    return {
      id: uuidv4(),
      keyword,
      source,
      currentScore: dataPoints[dataPoints.length - 1].value,
      previousScore: dataPoints[dataPoints.length - 8]?.value ?? baseScore,
      changePercent,
      direction,
      velocity,
      momentum,
      dataPoints,
      lastUpdated: new Date(),
    };
  }

  private generateMockSocialSignal(keyword: string, platform: SocialPlatform): SocialSignal {
    const mentionCount = Math.floor(100 + Math.random() * 10000);
    const sentimentScore = -0.2 + Math.random() * 0.6;
    const engagementScore = Math.random() * 100;
    const viralPotential = Math.random();
    const influencerMentions = Math.floor(Math.random() * 20);

    const topPosts: SocialPost[] = Array.from({ length: 5 }, (_, i) => ({
      id: uuidv4(),
      platform,
      content: `Sample ${platform} post about ${keyword} #trending`,
      url: `https://${platform}.com/post/${i + 1}`,
      engagement: Math.floor(100 + Math.random() * 5000),
      author: `user${Math.floor(Math.random() * 1000)}`,
      postedAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
    }));

    return {
      platform,
      keyword,
      mentionCount,
      sentimentScore,
      engagementScore,
      viralPotential,
      influencerMentions,
      topPosts,
      fetchedAt: new Date(),
    };
  }

  private generateMockGoogleTrendsData(keyword: string): GoogleTrendsData {
    const now = new Date();

    // Generate interest over time
    const interestOverTime: TrendDataPoint[] = [];
    const baseValue = 30 + Math.random() * 40;
    for (let i = 52; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i * 7);
      const seasonalFactor = 1 + 0.3 * Math.sin((date.getMonth() / 12) * Math.PI * 2);
      const trendFactor = 1 + (0.3 * (52 - i)) / 52;
      const noise = 0.85 + Math.random() * 0.3;
      interestOverTime.push({
        date,
        value: Math.round(baseValue * seasonalFactor * trendFactor * noise),
        source: 'google_trends',
      });
    }

    // Generate related queries
    const relatedQueries: RelatedQuery[] = [
      { query: `${keyword} ideas`, score: Math.floor(70 + Math.random() * 30), type: 'top' },
      { query: `best ${keyword}`, score: Math.floor(60 + Math.random() * 30), type: 'top' },
      { query: `${keyword} 2024`, score: Math.floor(50 + Math.random() * 30), type: 'rising' },
      { query: `${keyword} trending`, score: Math.floor(40 + Math.random() * 30), type: 'rising' },
      { query: `cheap ${keyword}`, score: Math.floor(30 + Math.random() * 30), type: 'top' },
    ];

    // Generate related topics
    const relatedTopics: RelatedTopic[] = [
      { topic: `${keyword} (Topic)`, score: Math.floor(80 + Math.random() * 20), type: 'top' },
      { topic: 'Shopping', score: Math.floor(60 + Math.random() * 20), type: 'top' },
      { topic: 'Design', score: Math.floor(50 + Math.random() * 20), type: 'rising' },
    ];

    // Generate region interest
    const regions = ['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany'];
    const regionInterest: RegionInterest[] = regions.map((region, i) => ({
      region,
      regionCode: ['US', 'GB', 'CA', 'AU', 'DE'][i],
      score: Math.floor(100 - i * 15 + Math.random() * 10),
    }));

    return {
      keyword,
      interestOverTime,
      relatedQueries,
      relatedTopics,
      regionInterest,
      fetchedAt: new Date(),
    };
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createTrendScanner(config?: Partial<TrendScannerConfig>): TrendScanner {
  return new TrendScanner(config);
}
