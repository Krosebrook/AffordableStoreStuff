/**
 * ============================================================================
 * NICHE RESEARCH SERVICE - TYPE DEFINITIONS
 * ============================================================================
 * TypeScript interfaces for the niche research automation system.
 * Supports trend scanning, keyword analysis, competitor tracking,
 * and opportunity scoring for product niche discovery.
 */

// =============================================================================
// CORE TYPES
// =============================================================================

export type TrendSource = 'google_trends' | 'pinterest' | 'etsy' | 'amazon' | 'social';
export type SocialPlatform = 'reddit' | 'twitter' | 'tiktok' | 'instagram';
export type TrendDirection = 'rising' | 'falling' | 'stable' | 'volatile' | 'emerging';
export type ConfidenceLevel = 'low' | 'medium' | 'high' | 'very_high';
export type CompetitionLevel = 'low' | 'medium' | 'high' | 'very_high';
export type SeasonalityType = 'none' | 'weekly' | 'monthly' | 'quarterly' | 'annual';
export type OpportunityTier = 'excellent' | 'good' | 'moderate' | 'poor';

// =============================================================================
// TREND TYPES
// =============================================================================

export interface TrendDataPoint {
  readonly date: Date;
  readonly value: number;
  readonly source: TrendSource;
}

export interface TrendSignal {
  readonly id: string;
  readonly keyword: string;
  readonly source: TrendSource;
  readonly currentScore: number;
  readonly previousScore: number;
  readonly changePercent: number;
  readonly direction: TrendDirection;
  readonly velocity: number;
  readonly momentum: number;
  readonly dataPoints: readonly TrendDataPoint[];
  readonly lastUpdated: Date;
}

export interface GoogleTrendsData {
  readonly keyword: string;
  readonly interestOverTime: readonly TrendDataPoint[];
  readonly relatedQueries: readonly RelatedQuery[];
  readonly relatedTopics: readonly RelatedTopic[];
  readonly regionInterest: readonly RegionInterest[];
  readonly fetchedAt: Date;
}

export interface RelatedQuery {
  readonly query: string;
  readonly score: number;
  readonly type: 'top' | 'rising';
}

export interface RelatedTopic {
  readonly topic: string;
  readonly score: number;
  readonly type: 'top' | 'rising';
}

export interface RegionInterest {
  readonly region: string;
  readonly regionCode: string;
  readonly score: number;
}

export interface SocialSignal {
  readonly platform: SocialPlatform;
  readonly keyword: string;
  readonly mentionCount: number;
  readonly sentimentScore: number;
  readonly engagementScore: number;
  readonly viralPotential: number;
  readonly influencerMentions: number;
  readonly topPosts: readonly SocialPost[];
  readonly fetchedAt: Date;
}

export interface SocialPost {
  readonly id: string;
  readonly platform: SocialPlatform;
  readonly content: string;
  readonly url: string;
  readonly engagement: number;
  readonly author: string;
  readonly postedAt: Date;
}

export interface SeasonalPattern {
  readonly type: SeasonalityType;
  readonly peakMonths: readonly number[];
  readonly troughMonths: readonly number[];
  readonly amplitude: number;
  readonly confidence: number;
}

// =============================================================================
// KEYWORD TYPES
// =============================================================================

export interface KeywordMetrics {
  readonly keyword: string;
  readonly searchVolume: number;
  readonly searchVolumeChange: number;
  readonly competition: CompetitionLevel;
  readonly competitionScore: number;
  readonly cpc: number;
  readonly difficulty: number;
  readonly opportunity: number;
  readonly intent: KeywordIntent;
  readonly seasonality: SeasonalPattern | null;
  readonly updatedAt: Date;
}

export type KeywordIntent = 'informational' | 'commercial' | 'transactional' | 'navigational';

export interface KeywordCluster {
  readonly id: string;
  readonly name: string;
  readonly primaryKeyword: string;
  readonly relatedKeywords: readonly KeywordMetrics[];
  readonly totalSearchVolume: number;
  readonly averageDifficulty: number;
  readonly averageOpportunity: number;
  readonly topicRelevance: number;
}

export interface KeywordSuggestion {
  readonly keyword: string;
  readonly source: 'autocomplete' | 'related' | 'questions' | 'competitor';
  readonly searchVolume: number | null;
  readonly relevanceScore: number;
}

export interface KeywordAnalysisResult {
  readonly keyword: string;
  readonly metrics: KeywordMetrics;
  readonly suggestions: readonly KeywordSuggestion[];
  readonly clusters: readonly KeywordCluster[];
  readonly longTailVariations: readonly string[];
  readonly questions: readonly string[];
  readonly analyzedAt: Date;
}

// =============================================================================
// COMPETITOR TYPES
// =============================================================================

export interface CompetitorListing {
  readonly id: string;
  readonly platform: string;
  readonly externalId: string;
  readonly sellerId: string;
  readonly sellerName: string;
  readonly title: string;
  readonly description: string;
  readonly url: string;
  readonly imageUrl: string | null;
  readonly price: number;
  readonly currency: string;
  readonly originalPrice: number | null;
  readonly reviewCount: number;
  readonly rating: number;
  readonly salesCount: number | null;
  readonly favorites: number | null;
  readonly tags: readonly string[];
  readonly categories: readonly string[];
  readonly createdAt: Date;
  readonly scrapedAt: Date;
}

export interface CompetitorPriceHistory {
  readonly listingId: string;
  readonly price: number;
  readonly currency: string;
  readonly recordedAt: Date;
}

export interface CompetitorAnalysis {
  readonly niche: string;
  readonly platform: string;
  readonly totalListings: number;
  readonly averagePrice: number;
  readonly priceRange: PriceRange;
  readonly averageRating: number;
  readonly averageReviews: number;
  readonly topSellers: readonly SellerMetrics[];
  readonly priceTrend: TrendDirection;
  readonly saturationLevel: CompetitionLevel;
  readonly entryBarrier: CompetitionLevel;
  readonly analyzedAt: Date;
}

export interface PriceRange {
  readonly min: number;
  readonly max: number;
  readonly median: number;
  readonly percentile25: number;
  readonly percentile75: number;
}

export interface SellerMetrics {
  readonly sellerId: string;
  readonly sellerName: string;
  readonly platform: string;
  readonly listingCount: number;
  readonly totalSales: number | null;
  readonly averageRating: number;
  readonly totalReviews: number;
  readonly priceRange: PriceRange;
  readonly marketShare: number | null;
}

export interface CompetitorAlert {
  readonly id: string;
  readonly type: 'new_listing' | 'price_change' | 'new_seller' | 'trending_product';
  readonly niche: string;
  readonly platform: string;
  readonly listing: CompetitorListing | null;
  readonly previousValue: number | string | null;
  readonly currentValue: number | string;
  readonly changePercent: number | null;
  readonly severity: 'low' | 'medium' | 'high';
  readonly createdAt: Date;
}

// =============================================================================
// OPPORTUNITY TYPES
// =============================================================================

export interface NicheOpportunity {
  readonly id: string;
  readonly niche: string;
  readonly keywords: readonly string[];
  readonly overallScore: number;
  readonly tier: OpportunityTier;
  readonly scores: OpportunityScores;
  readonly metrics: NicheMetrics;
  readonly recommendations: readonly string[];
  readonly risks: readonly NicheRisk[];
  readonly suggestedProducts: readonly ProductIdea[];
  readonly validUntil: Date;
  readonly scoredAt: Date;
}

export interface OpportunityScores {
  readonly demandScore: number;
  readonly competitionScore: number;
  readonly profitabilityScore: number;
  readonly trendScore: number;
  readonly seasonalityScore: number;
  readonly sustainabilityScore: number;
}

export interface NicheMetrics {
  readonly estimatedSearchVolume: number;
  readonly estimatedMarketSize: number;
  readonly competitorCount: number;
  readonly averagePrice: number;
  readonly profitMargin: number;
  readonly growthRate: number;
  readonly seasonalityStrength: number;
}

export interface NicheRisk {
  readonly type: 'competition' | 'saturation' | 'trend' | 'legal' | 'seasonal' | 'platform';
  readonly severity: 'low' | 'medium' | 'high';
  readonly description: string;
  readonly mitigation: string | null;
}

export interface ProductIdea {
  readonly title: string;
  readonly description: string;
  readonly productType: string;
  readonly targetPrice: number;
  readonly estimatedDemand: number;
  readonly competitionLevel: CompetitionLevel;
  readonly keywords: readonly string[];
  readonly platforms: readonly string[];
}

export interface OpportunityScoringConfig {
  readonly weights: OpportunityScoringWeights;
  readonly thresholds: OpportunityScoringThresholds;
  readonly filters: OpportunityScoringFilters;
}

export interface OpportunityScoringWeights {
  readonly demand: number;
  readonly competition: number;
  readonly profitability: number;
  readonly trend: number;
  readonly seasonality: number;
  readonly sustainability: number;
}

export interface OpportunityScoringThresholds {
  readonly minSearchVolume: number;
  readonly maxCompetitorCount: number;
  readonly minProfitMargin: number;
  readonly minGrowthRate: number;
}

export interface OpportunityScoringFilters {
  readonly excludeNiches: readonly string[];
  readonly requireTrending: boolean;
  readonly minOverallScore: number;
  readonly platforms: readonly string[];
}

// =============================================================================
// SERVICE CONFIGURATION TYPES
// =============================================================================

export interface NicheResearchConfig {
  readonly supabaseUrl: string;
  readonly supabaseKey: string;
  readonly cacheEnabled: boolean;
  readonly cacheTtlMinutes: number;
  readonly rateLimiting: RateLimitConfig;
  readonly dataSourceWeights: DataSourceWeights;
  readonly scoringConfig: OpportunityScoringConfig;
  readonly mockMode: boolean;
}

export interface RateLimitConfig {
  readonly googleTrends: RateLimitRule;
  readonly socialApis: RateLimitRule;
  readonly scrapers: RateLimitRule;
}

export interface RateLimitRule {
  readonly requestsPerMinute: number;
  readonly requestsPerHour: number;
  readonly requestsPerDay: number;
}

export interface DataSourceWeights {
  readonly googleTrends: number;
  readonly pinterest: number;
  readonly etsy: number;
  readonly amazon: number;
  readonly reddit: number;
  readonly twitter: number;
  readonly tiktok: number;
}

// =============================================================================
// API REQUEST/RESPONSE TYPES
// =============================================================================

export interface TrendScanRequest {
  readonly keywords: readonly string[];
  readonly sources?: readonly TrendSource[];
  readonly timeRange?: 'day' | 'week' | 'month' | 'quarter' | 'year';
  readonly region?: string;
  readonly includeSocial?: boolean;
}

export interface TrendScanResponse {
  readonly success: boolean;
  readonly trends: readonly TrendSignal[];
  readonly socialSignals: readonly SocialSignal[];
  readonly risingKeywords: readonly string[];
  readonly fallingKeywords: readonly string[];
  readonly scannedAt: Date;
  readonly error?: string;
}

export interface KeywordAnalysisRequest {
  readonly keyword: string;
  readonly includeSuggestions?: boolean;
  readonly includeQuestions?: boolean;
  readonly maxSuggestions?: number;
  readonly platforms?: readonly string[];
}

export interface KeywordAnalysisResponse {
  readonly success: boolean;
  readonly result: KeywordAnalysisResult | null;
  readonly analyzedAt: Date;
  readonly error?: string;
}

export interface CompetitorTrackRequest {
  readonly niche: string;
  readonly platforms: readonly string[];
  readonly maxListings?: number;
  readonly priceRange?: { min: number; max: number };
  readonly sortBy?: 'relevance' | 'price' | 'reviews' | 'date';
}

export interface CompetitorTrackResponse {
  readonly success: boolean;
  readonly listings: readonly CompetitorListing[];
  readonly analysis: CompetitorAnalysis | null;
  readonly alerts: readonly CompetitorAlert[];
  readonly scrapedAt: Date;
  readonly error?: string;
}

export interface OpportunityScanRequest {
  readonly niches: readonly string[];
  readonly scoringConfig?: Partial<OpportunityScoringConfig>;
  readonly limit?: number;
  readonly minScore?: number;
}

export interface OpportunityScanResponse {
  readonly success: boolean;
  readonly opportunities: readonly NicheOpportunity[];
  readonly topRecommendations: readonly string[];
  readonly scanedAt: Date;
  readonly error?: string;
}

// =============================================================================
// CACHE TYPES
// =============================================================================

export interface CacheEntry<T> {
  readonly data: T;
  readonly cachedAt: Date;
  readonly expiresAt: Date;
  readonly source: string;
}

export interface CacheStats {
  readonly hits: number;
  readonly misses: number;
  readonly size: number;
  readonly oldestEntry: Date | null;
}

// =============================================================================
// DATABASE ENTITY TYPES
// =============================================================================

export interface DBNicheResearchJob {
  id: string;
  niche: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  started_at: string | null;
  completed_at: string | null;
  result: NicheOpportunity | null;
  error: string | null;
  created_at: string;
  updated_at: string;
}

export interface DBKeywordMetrics {
  id: string;
  keyword: string;
  search_volume: number;
  competition_score: number;
  cpc: number;
  difficulty: number;
  opportunity: number;
  intent: string;
  seasonality: SeasonalPattern | null;
  source: string;
  created_at: string;
  updated_at: string;
}

export interface DBCompetitorListing {
  id: string;
  platform: string;
  external_id: string;
  seller_id: string;
  seller_name: string;
  niche: string;
  title: string;
  description: string;
  url: string;
  image_url: string | null;
  price: number;
  currency: string;
  original_price: number | null;
  review_count: number;
  rating: number;
  sales_count: number | null;
  favorites: number | null;
  tags: string[];
  categories: string[];
  created_at: string;
  scraped_at: string;
}

export interface DBTrendHistory {
  id: string;
  keyword: string;
  source: string;
  score: number;
  direction: string;
  velocity: number;
  recorded_at: string;
}

export interface DBNicheOpportunity {
  id: string;
  niche: string;
  keywords: string[];
  overall_score: number;
  tier: string;
  scores: OpportunityScores;
  metrics: NicheMetrics;
  recommendations: string[];
  risks: NicheRisk[];
  suggested_products: ProductIdea[];
  valid_until: string;
  scored_at: string;
  created_at: string;
}

// =============================================================================
// ERROR TYPES
// =============================================================================

export class NicheResearchError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly retryable: boolean = false,
    public readonly details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'NicheResearchError';
  }
}

export class RateLimitError extends NicheResearchError {
  constructor(
    source: string,
    retryAfterMs: number
  ) {
    super(
      `Rate limit exceeded for ${source}. Retry after ${retryAfterMs}ms`,
      'RATE_LIMIT_EXCEEDED',
      true,
      { source, retryAfterMs }
    );
    this.name = 'RateLimitError';
  }
}

export class DataSourceError extends NicheResearchError {
  constructor(
    source: string,
    originalError: Error
  ) {
    super(
      `Failed to fetch data from ${source}: ${originalError.message}`,
      'DATA_SOURCE_ERROR',
      true,
      { source, originalError: originalError.message }
    );
    this.name = 'DataSourceError';
  }
}

export class ValidationError extends NicheResearchError {
  constructor(
    field: string,
    message: string
  ) {
    super(
      `Validation error for ${field}: ${message}`,
      'VALIDATION_ERROR',
      false,
      { field }
    );
    this.name = 'ValidationError';
  }
}

// =============================================================================
// SERVICE STATUS TYPES
// =============================================================================

export interface NicheResearchStatus {
  readonly initialized: boolean;
  readonly healthy: boolean;
  readonly lastScanAt: Date | null;
  readonly activeJobs: number;
  readonly cacheStats: CacheStats;
  readonly dataSourceHealth: Record<string, 'healthy' | 'degraded' | 'offline'>;
  readonly errors: readonly { source: string; message: string; timestamp: Date }[];
}
