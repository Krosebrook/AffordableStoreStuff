/**
 * Multi-Platform Sync Engine Types
 * Defines all types for real-time synchronization across platforms
 */

import { ConnectorName } from '../../connectors/index';
import { NormalizedProduct, Order, OrderStatus } from '../../connectors/core/types';

// ============================================================================
// Sync Job Types
// ============================================================================

export type SyncType = 'inventory' | 'price' | 'order' | 'product';
export type SyncDirection = 'push' | 'pull' | 'bidirectional';
export type SyncStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled' | 'retrying';
export type SyncPriority = 'low' | 'normal' | 'high' | 'critical';

export interface SyncJob {
  id: string;
  type: SyncType;
  direction: SyncDirection;
  status: SyncStatus;
  priority: SyncPriority;
  sourcePlatform: ConnectorName;
  targetPlatforms: ConnectorName[];
  productId?: string;
  orderId?: string;
  data: SyncData;
  result?: SyncResult;
  error?: SyncError;
  retryCount: number;
  maxRetries: number;
  scheduledAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface SyncData {
  inventory?: InventorySyncData;
  price?: PriceSyncData;
  order?: OrderSyncData;
  product?: ProductSyncData;
  metadata?: Record<string, unknown>;
}

export interface InventorySyncData {
  productId: string;
  sku?: string;
  variantId?: string;
  quantity: number;
  previousQuantity?: number;
  reservedQuantity?: number;
  availableQuantity?: number;
  lowStockThreshold?: number;
  trackInventory: boolean;
}

export interface PriceSyncData {
  productId: string;
  variantId?: string;
  price: number;
  previousPrice?: number;
  compareAtPrice?: number;
  currency: string;
  costPerItem?: number;
  marginPercent?: number;
}

export interface OrderSyncData {
  orderId: string;
  externalOrderId: string;
  status: OrderStatus;
  previousStatus?: OrderStatus;
  trackingNumber?: string;
  trackingUrl?: string;
  carrier?: string;
  shippedAt?: Date;
  deliveredAt?: Date;
  notes?: string;
}

export interface ProductSyncData {
  productId: string;
  product: Partial<NormalizedProduct>;
  fields: string[];
  createIfMissing: boolean;
}

// ============================================================================
// Sync Result Types
// ============================================================================

export interface SyncResult {
  success: boolean;
  syncedPlatforms: PlatformSyncResult[];
  failedPlatforms: PlatformSyncResult[];
  conflictsResolved: ConflictResolution[];
  duration: number;
  timestamp: Date;
}

export interface PlatformSyncResult {
  platform: ConnectorName;
  success: boolean;
  externalId?: string;
  previousValue?: unknown;
  newValue?: unknown;
  error?: SyncError;
  duration: number;
  retries: number;
}

export interface SyncError {
  code: string;
  message: string;
  platform?: ConnectorName;
  retryable: boolean;
  details?: Record<string, unknown>;
}

// ============================================================================
// Conflict Resolution Types
// ============================================================================

export type ConflictResolutionStrategy =
  | 'source_wins'
  | 'target_wins'
  | 'newest_wins'
  | 'highest_wins'
  | 'lowest_wins'
  | 'manual'
  | 'custom';

export interface ConflictRule {
  id: string;
  syncType: SyncType;
  field: string;
  strategy: ConflictResolutionStrategy;
  sourcePlatformPriority?: ConnectorName[];
  customResolver?: (sourceValue: unknown, targetValue: unknown, context: ConflictContext) => unknown;
  enabled: boolean;
}

export interface Conflict {
  id: string;
  syncJobId: string;
  syncType: SyncType;
  field: string;
  sourcePlatform: ConnectorName;
  targetPlatform: ConnectorName;
  sourceValue: unknown;
  targetValue: unknown;
  sourceUpdatedAt?: Date;
  targetUpdatedAt?: Date;
  status: 'pending' | 'resolved' | 'manual_required';
  resolution?: ConflictResolution;
  createdAt: Date;
}

export interface ConflictContext {
  syncJob: SyncJob;
  sourcePlatform: ConnectorName;
  targetPlatform: ConnectorName;
  field: string;
  sourceUpdatedAt?: Date;
  targetUpdatedAt?: Date;
  metadata?: Record<string, unknown>;
}

export interface ConflictResolution {
  conflictId: string;
  strategy: ConflictResolutionStrategy;
  resolvedValue: unknown;
  resolvedBy: 'auto' | 'manual';
  resolvedAt: Date;
  reason?: string;
}

// ============================================================================
// Webhook Types
// ============================================================================

export type WebhookEventCategory = 'inventory' | 'order' | 'product' | 'price' | 'fulfillment';

export interface PlatformWebhookEvent {
  id: string;
  platform: ConnectorName;
  eventType: string;
  category: WebhookEventCategory;
  payload: Record<string, unknown>;
  signature?: string;
  receivedAt: Date;
  processedAt?: Date;
  status: 'pending' | 'processing' | 'processed' | 'failed' | 'ignored';
  error?: string;
}

export interface WebhookValidationResult {
  valid: boolean;
  platform: ConnectorName;
  eventType: string;
  error?: string;
}

// ============================================================================
// Sync Configuration Types
// ============================================================================

export interface SyncEngineConfig {
  supabaseUrl: string;
  supabaseKey: string;
  defaultSyncInterval: number;
  maxConcurrentJobs: number;
  maxRetries: number;
  retryDelayMs: number;
  conflictResolutionRules: ConflictRule[];
  enableRealTimeSync: boolean;
  enableWebhooks: boolean;
  webhookSecret?: string;
  lowStockThreshold: number;
  alertOnSyncFailure: boolean;
  platformPriority: ConnectorName[];
}

export interface PlatformSyncConfig {
  platform: ConnectorName;
  enabled: boolean;
  syncTypes: SyncType[];
  direction: SyncDirection;
  intervalMs: number;
  priority: SyncPriority;
  webhookEnabled: boolean;
  webhookUrl?: string;
  webhookSecret?: string;
  customSettings?: Record<string, unknown>;
}

// ============================================================================
// Queue Types
// ============================================================================

export interface QueuedSyncJob extends SyncJob {
  queuePosition: number;
  estimatedStartTime?: Date;
}

export interface QueueStats {
  totalJobs: number;
  pendingJobs: number;
  processingJobs: number;
  completedJobs: number;
  failedJobs: number;
  averageProcessingTime: number;
  oldestJobAge: number;
}

// ============================================================================
// Monitoring Types
// ============================================================================

export interface SyncHealthStatus {
  healthy: boolean;
  lastSyncAt?: Date;
  lastSuccessfulSyncAt?: Date;
  consecutiveFailures: number;
  failureRate24h: number;
  averageLatency: number;
  queueDepth: number;
  activeSyncs: number;
  platformStatuses: PlatformSyncHealth[];
}

export interface PlatformSyncHealth {
  platform: ConnectorName;
  healthy: boolean;
  lastSyncAt?: Date;
  lastSuccessfulSyncAt?: Date;
  consecutiveFailures: number;
  failureRate24h: number;
  averageLatency: number;
  webhookStatus: 'active' | 'inactive' | 'error';
}

export interface SyncAlert {
  id: string;
  type: 'sync_failure' | 'conflict' | 'latency' | 'queue_depth' | 'platform_down';
  severity: 'info' | 'warning' | 'error' | 'critical';
  platform?: ConnectorName;
  message: string;
  details?: Record<string, unknown>;
  acknowledged: boolean;
  acknowledgedAt?: Date;
  acknowledgedBy?: string;
  createdAt: Date;
}

// ============================================================================
// Bulk Operation Types
// ============================================================================

export interface BulkSyncRequest {
  id: string;
  type: SyncType;
  direction: SyncDirection;
  sourcePlatform: ConnectorName;
  targetPlatforms: ConnectorName[];
  items: BulkSyncItem[];
  options: BulkSyncOptions;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'partial';
  progress: BulkSyncProgress;
  result?: BulkSyncResult;
  createdAt: Date;
  updatedAt: Date;
}

export interface BulkSyncItem {
  id: string;
  productId?: string;
  orderId?: string;
  data: SyncData;
  status: SyncStatus;
  error?: SyncError;
}

export interface BulkSyncOptions {
  batchSize: number;
  concurrency: number;
  continueOnError: boolean;
  rollbackOnFailure: boolean;
  dryRun: boolean;
  notifyOnCompletion: boolean;
}

export interface BulkSyncProgress {
  total: number;
  processed: number;
  successful: number;
  failed: number;
  skipped: number;
  percent: number;
  currentBatch: number;
  totalBatches: number;
  estimatedTimeRemaining?: number;
}

export interface BulkSyncResult {
  success: boolean;
  total: number;
  successful: number;
  failed: number;
  skipped: number;
  duration: number;
  rollbackPerformed: boolean;
  items: BulkSyncItemResult[];
}

export interface BulkSyncItemResult {
  itemId: string;
  success: boolean;
  platforms: PlatformSyncResult[];
  error?: SyncError;
}

// ============================================================================
// Audit Trail Types
// ============================================================================

export interface SyncAuditEntry {
  id: string;
  syncJobId: string;
  syncType: SyncType;
  action: 'created' | 'started' | 'completed' | 'failed' | 'retried' | 'cancelled' | 'conflict_resolved';
  platform?: ConnectorName;
  previousValue?: unknown;
  newValue?: unknown;
  actor: 'system' | 'webhook' | 'manual' | 'scheduled';
  details?: Record<string, unknown>;
  timestamp: Date;
}

// ============================================================================
// Event Types (for internal pub/sub)
// ============================================================================

export type SyncEventType =
  | 'sync:started'
  | 'sync:completed'
  | 'sync:failed'
  | 'sync:retrying'
  | 'sync:cancelled'
  | 'conflict:detected'
  | 'conflict:resolved'
  | 'webhook:received'
  | 'webhook:processed'
  | 'alert:created'
  | 'bulk:started'
  | 'bulk:progress'
  | 'bulk:completed';

export interface SyncEvent {
  type: SyncEventType;
  payload: Record<string, unknown>;
  timestamp: Date;
}

export type SyncEventHandler = (event: SyncEvent) => void | Promise<void>;
