/**
 * Conflict Resolver
 * Handles conflict detection and resolution for multi-platform sync
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  Conflict,
  ConflictContext,
  ConflictResolution,
  ConflictResolutionStrategy,
  ConflictRule,
  SyncJob,
  SyncType,
} from './types';
import { ConnectorName } from '../../connectors/index';

// ============================================================================
// Default Conflict Rules
// ============================================================================

const DEFAULT_CONFLICT_RULES: ConflictRule[] = [
  // Inventory: always use the lowest value for safety
  {
    id: 'inventory-quantity-lowest',
    syncType: 'inventory',
    field: 'quantity',
    strategy: 'lowest_wins',
    enabled: true,
  },
  // Price: source platform wins
  {
    id: 'price-source-wins',
    syncType: 'price',
    field: 'price',
    strategy: 'source_wins',
    enabled: true,
  },
  // Order status: newest wins
  {
    id: 'order-status-newest',
    syncType: 'order',
    field: 'status',
    strategy: 'newest_wins',
    enabled: true,
  },
  // Product title: source wins
  {
    id: 'product-title-source',
    syncType: 'product',
    field: 'title',
    strategy: 'source_wins',
    enabled: true,
  },
  // Product description: source wins
  {
    id: 'product-description-source',
    syncType: 'product',
    field: 'description',
    strategy: 'source_wins',
    enabled: true,
  },
];

// ============================================================================
// Conflict Resolver Class
// ============================================================================

export class ConflictResolver {
  private supabase: SupabaseClient;
  private rules: Map<string, ConflictRule>;
  private platformPriority: ConnectorName[];

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    customRules: ConflictRule[] = [],
    platformPriority: ConnectorName[] = []
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.rules = new Map();
    this.platformPriority = platformPriority;

    // Load default rules
    DEFAULT_CONFLICT_RULES.forEach((rule) => this.addRule(rule));

    // Load custom rules (override defaults)
    customRules.forEach((rule) => this.addRule(rule));
  }

  /**
   * Add or update a conflict resolution rule
   */
  addRule(rule: ConflictRule): void {
    const key = this.getRuleKey(rule.syncType, rule.field);
    this.rules.set(key, rule);
  }

  /**
   * Remove a conflict resolution rule
   */
  removeRule(syncType: SyncType, field: string): boolean {
    const key = this.getRuleKey(syncType, field);
    return this.rules.delete(key);
  }

  /**
   * Get rule for a specific field
   */
  getRule(syncType: SyncType, field: string): ConflictRule | undefined {
    const key = this.getRuleKey(syncType, field);
    return this.rules.get(key);
  }

  /**
   * Detect conflicts between source and target data
   */
  async detectConflicts(
    syncJob: SyncJob,
    sourceData: Record<string, unknown>,
    targetData: Record<string, unknown>,
    targetPlatform: ConnectorName
  ): Promise<Conflict[]> {
    const conflicts: Conflict[] = [];
    const now = new Date();

    for (const [field, sourceValue] of Object.entries(sourceData)) {
      const targetValue = targetData[field];

      // Skip if values are equal
      if (this.areValuesEqual(sourceValue, targetValue)) {
        continue;
      }

      // Check if field has a conflict (target has different value)
      if (targetValue !== undefined && targetValue !== null) {
        const conflict: Conflict = {
          id: `conflict-${syncJob.id}-${field}-${Date.now()}`,
          syncJobId: syncJob.id,
          syncType: syncJob.type,
          field,
          sourcePlatform: syncJob.sourcePlatform,
          targetPlatform,
          sourceValue,
          targetValue,
          sourceUpdatedAt: syncJob.updatedAt,
          targetUpdatedAt: undefined, // Would need to be fetched from platform
          status: 'pending',
          createdAt: now,
        };

        conflicts.push(conflict);
      }
    }

    // Store detected conflicts
    if (conflicts.length > 0) {
      await this.storeConflicts(conflicts);
    }

    return conflicts;
  }

  /**
   * Resolve a single conflict
   */
  async resolveConflict(conflict: Conflict): Promise<ConflictResolution> {
    const rule = this.getRule(conflict.syncType, conflict.field);
    const context: ConflictContext = {
      syncJob: {} as SyncJob, // Would be loaded from DB in production
      sourcePlatform: conflict.sourcePlatform,
      targetPlatform: conflict.targetPlatform,
      field: conflict.field,
      sourceUpdatedAt: conflict.sourceUpdatedAt,
      targetUpdatedAt: conflict.targetUpdatedAt,
    };

    let resolvedValue: unknown;
    let strategy: ConflictResolutionStrategy;

    if (!rule || !rule.enabled) {
      // Default to source wins if no rule
      resolvedValue = conflict.sourceValue;
      strategy = 'source_wins';
    } else if (rule.strategy === 'custom' && rule.customResolver) {
      // Use custom resolver
      resolvedValue = rule.customResolver(
        conflict.sourceValue,
        conflict.targetValue,
        context
      );
      strategy = 'custom';
    } else if (rule.strategy === 'manual') {
      // Mark for manual resolution
      conflict.status = 'manual_required';
      await this.updateConflict(conflict);

      return {
        conflictId: conflict.id,
        strategy: 'manual',
        resolvedValue: undefined,
        resolvedBy: 'manual',
        resolvedAt: new Date(),
        reason: 'Requires manual review',
      };
    } else {
      // Use automatic strategy
      resolvedValue = this.applyStrategy(
        rule.strategy,
        conflict.sourceValue,
        conflict.targetValue,
        context,
        rule.sourcePlatformPriority
      );
      strategy = rule.strategy;
    }

    const resolution: ConflictResolution = {
      conflictId: conflict.id,
      strategy,
      resolvedValue,
      resolvedBy: 'auto',
      resolvedAt: new Date(),
      reason: `Resolved using ${strategy} strategy`,
    };

    // Update conflict with resolution
    conflict.status = 'resolved';
    conflict.resolution = resolution;
    await this.updateConflict(conflict);

    // Log resolution
    await this.logResolution(conflict, resolution);

    return resolution;
  }

  /**
   * Resolve multiple conflicts for a sync job
   */
  async resolveConflicts(conflicts: Conflict[]): Promise<Map<string, ConflictResolution>> {
    const resolutions = new Map<string, ConflictResolution>();

    for (const conflict of conflicts) {
      const resolution = await this.resolveConflict(conflict);
      resolutions.set(conflict.field, resolution);
    }

    return resolutions;
  }

  /**
   * Get pending conflicts requiring manual resolution
   */
  async getPendingConflicts(
    options: { platform?: ConnectorName; syncType?: SyncType; limit?: number } = {}
  ): Promise<Conflict[]> {
    let query = this.supabase
      .from('sync_conflicts')
      .select('*')
      .eq('status', 'manual_required')
      .order('created_at', { ascending: false });

    if (options.platform) {
      query = query.or(
        `source_platform.eq.${options.platform},target_platform.eq.${options.platform}`
      );
    }

    if (options.syncType) {
      query = query.eq('sync_type', options.syncType);
    }

    if (options.limit) {
      query = query.limit(options.limit);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Failed to fetch pending conflicts:', error);
      return [];
    }

    return this.mapDbRowsToConflicts(data || []);
  }

  /**
   * Manually resolve a conflict
   */
  async manuallyResolve(
    conflictId: string,
    resolvedValue: unknown,
    resolvedBy: string,
    reason?: string
  ): Promise<ConflictResolution> {
    const { data, error } = await this.supabase
      .from('sync_conflicts')
      .select('*')
      .eq('id', conflictId)
      .single();

    if (error || !data) {
      throw new Error(`Conflict not found: ${conflictId}`);
    }

    const conflict = this.mapDbRowToConflict(data);

    const resolution: ConflictResolution = {
      conflictId,
      strategy: 'manual',
      resolvedValue,
      resolvedBy: 'manual',
      resolvedAt: new Date(),
      reason: reason || `Manually resolved by ${resolvedBy}`,
    };

    conflict.status = 'resolved';
    conflict.resolution = resolution;
    await this.updateConflict(conflict);

    await this.logResolution(conflict, resolution, resolvedBy);

    return resolution;
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private getRuleKey(syncType: SyncType, field: string): string {
    return `${syncType}:${field}`;
  }

  private areValuesEqual(a: unknown, b: unknown): boolean {
    if (a === b) return true;
    if (typeof a !== typeof b) return false;
    if (typeof a === 'object' && a !== null && b !== null) {
      return JSON.stringify(a) === JSON.stringify(b);
    }
    return false;
  }

  private applyStrategy(
    strategy: ConflictResolutionStrategy,
    sourceValue: unknown,
    targetValue: unknown,
    context: ConflictContext,
    platformPriority?: ConnectorName[]
  ): unknown {
    switch (strategy) {
      case 'source_wins':
        return sourceValue;

      case 'target_wins':
        return targetValue;

      case 'newest_wins':
        if (!context.sourceUpdatedAt || !context.targetUpdatedAt) {
          return sourceValue; // Default to source if timestamps missing
        }
        return context.sourceUpdatedAt >= context.targetUpdatedAt
          ? sourceValue
          : targetValue;

      case 'highest_wins':
        const sourceNum = Number(sourceValue);
        const targetNum = Number(targetValue);
        if (isNaN(sourceNum) || isNaN(targetNum)) {
          return sourceValue;
        }
        return sourceNum >= targetNum ? sourceValue : targetValue;

      case 'lowest_wins':
        const srcNum = Number(sourceValue);
        const tgtNum = Number(targetValue);
        if (isNaN(srcNum) || isNaN(tgtNum)) {
          return sourceValue;
        }
        return srcNum <= tgtNum ? sourceValue : targetValue;

      default:
        // Check platform priority
        const priority = platformPriority || this.platformPriority;
        if (priority.length > 0) {
          const sourceIdx = priority.indexOf(context.sourcePlatform);
          const targetIdx = priority.indexOf(context.targetPlatform);
          if (sourceIdx !== -1 && targetIdx !== -1) {
            return sourceIdx < targetIdx ? sourceValue : targetValue;
          }
        }
        return sourceValue;
    }
  }

  private async storeConflicts(conflicts: Conflict[]): Promise<void> {
    const rows = conflicts.map((conflict) => ({
      id: conflict.id,
      sync_job_id: conflict.syncJobId,
      sync_type: conflict.syncType,
      field: conflict.field,
      source_platform: conflict.sourcePlatform,
      target_platform: conflict.targetPlatform,
      source_value: conflict.sourceValue,
      target_value: conflict.targetValue,
      source_updated_at: conflict.sourceUpdatedAt?.toISOString(),
      target_updated_at: conflict.targetUpdatedAt?.toISOString(),
      status: conflict.status,
      created_at: conflict.createdAt.toISOString(),
    }));

    const { error } = await this.supabase.from('sync_conflicts').insert(rows);

    if (error) {
      console.error('Failed to store conflicts:', error);
    }
  }

  private async updateConflict(conflict: Conflict): Promise<void> {
    const { error } = await this.supabase
      .from('sync_conflicts')
      .update({
        status: conflict.status,
        resolution: conflict.resolution,
        updated_at: new Date().toISOString(),
      })
      .eq('id', conflict.id);

    if (error) {
      console.error('Failed to update conflict:', error);
    }
  }

  private async logResolution(
    conflict: Conflict,
    resolution: ConflictResolution,
    resolvedBy?: string
  ): Promise<void> {
    await this.supabase.from('sync_audit_log').insert({
      sync_job_id: conflict.syncJobId,
      sync_type: conflict.syncType,
      action: 'conflict_resolved',
      platform: conflict.targetPlatform,
      previous_value: conflict.targetValue,
      new_value: resolution.resolvedValue,
      actor: resolvedBy || 'system',
      details: {
        conflict_id: conflict.id,
        field: conflict.field,
        strategy: resolution.strategy,
        source_platform: conflict.sourcePlatform,
        reason: resolution.reason,
      },
      timestamp: new Date().toISOString(),
    });
  }

  private mapDbRowToConflict(row: Record<string, unknown>): Conflict {
    return {
      id: row.id as string,
      syncJobId: row.sync_job_id as string,
      syncType: row.sync_type as SyncType,
      field: row.field as string,
      sourcePlatform: row.source_platform as ConnectorName,
      targetPlatform: row.target_platform as ConnectorName,
      sourceValue: row.source_value,
      targetValue: row.target_value,
      sourceUpdatedAt: row.source_updated_at
        ? new Date(row.source_updated_at as string)
        : undefined,
      targetUpdatedAt: row.target_updated_at
        ? new Date(row.target_updated_at as string)
        : undefined,
      status: row.status as Conflict['status'],
      resolution: row.resolution as ConflictResolution | undefined,
      createdAt: new Date(row.created_at as string),
    };
  }

  private mapDbRowsToConflicts(rows: Record<string, unknown>[]): Conflict[] {
    return rows.map((row) => this.mapDbRowToConflict(row));
  }
}

export default ConflictResolver;
