/**
 * Sync Manager
 * Manages sync job lifecycle, scheduling, and coordination
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  SyncJob,
  SyncStatus,
  SyncType,
  SyncDirection,
  SyncPriority,
  SyncData,
  SyncResult,
  SyncError,
  SyncEvent,
  SyncEventType,
  SyncEventHandler,
  PlatformSyncResult,
  SyncAuditEntry,
  SyncHealthStatus,
  PlatformSyncHealth,
} from './types';
import { ConnectorName } from '../../connectors/index';

// ============================================================================
// Sync Manager Class
// ============================================================================

export class SyncManager extends EventEmitter {
  private supabase: SupabaseClient;
  private activeSyncs: Map<string, SyncJob>;
  private syncIntervals: Map<string, NodeJS.Timeout>;
  private maxConcurrentJobs: number;
  private maxRetries: number;
  private retryDelayMs: number;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options: {
      maxConcurrentJobs?: number;
      maxRetries?: number;
      retryDelayMs?: number;
    } = {}
  ) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.activeSyncs = new Map();
    this.syncIntervals = new Map();
    this.maxConcurrentJobs = options.maxConcurrentJobs || 5;
    this.maxRetries = options.maxRetries || 3;
    this.retryDelayMs = options.retryDelayMs || 1000;
  }

  // ============================================================================
  // Job Creation
  // ============================================================================

  /**
   * Create a new sync job
   */
  async createJob(
    type: SyncType,
    direction: SyncDirection,
    sourcePlatform: ConnectorName,
    targetPlatforms: ConnectorName[],
    data: SyncData,
    options: {
      priority?: SyncPriority;
      productId?: string;
      orderId?: string;
      scheduledAt?: Date;
    } = {}
  ): Promise<SyncJob> {
    const now = new Date();
    const job: SyncJob = {
      id: `sync-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      direction,
      status: 'pending',
      priority: options.priority || 'normal',
      sourcePlatform,
      targetPlatforms,
      productId: options.productId,
      orderId: options.orderId,
      data,
      retryCount: 0,
      maxRetries: this.maxRetries,
      scheduledAt: options.scheduledAt || now,
      createdAt: now,
      updatedAt: now,
    };

    // Store in database
    await this.saveJob(job);

    // Log creation
    await this.logAudit(job, 'created');

    return job;
  }

  /**
   * Schedule recurring sync
   */
  scheduleRecurringSync(
    key: string,
    intervalMs: number,
    createJobFn: () => Promise<SyncJob>
  ): void {
    // Clear existing interval if any
    this.cancelRecurringSync(key);

    const interval = setInterval(async () => {
      try {
        const job = await createJobFn();
        await this.startJob(job.id);
      } catch (error) {
        console.error(`Recurring sync ${key} failed:`, error);
      }
    }, intervalMs);

    this.syncIntervals.set(key, interval);
  }

  /**
   * Cancel recurring sync
   */
  cancelRecurringSync(key: string): void {
    const interval = this.syncIntervals.get(key);
    if (interval) {
      clearInterval(interval);
      this.syncIntervals.delete(key);
    }
  }

  // ============================================================================
  // Job Lifecycle
  // ============================================================================

  /**
   * Start a sync job
   */
  async startJob(jobId: string): Promise<SyncJob | null> {
    // Check concurrent job limit
    if (this.activeSyncs.size >= this.maxConcurrentJobs) {
      console.warn(`Max concurrent jobs (${this.maxConcurrentJobs}) reached`);
      return null;
    }

    const job = await this.getJob(jobId);
    if (!job) {
      console.error(`Job not found: ${jobId}`);
      return null;
    }

    if (job.status !== 'pending' && job.status !== 'retrying') {
      console.warn(`Job ${jobId} is not in a startable state: ${job.status}`);
      return null;
    }

    job.status = 'processing';
    job.startedAt = new Date();
    job.updatedAt = new Date();

    await this.saveJob(job);
    this.activeSyncs.set(jobId, job);

    await this.logAudit(job, 'started');
    this.emitEvent('sync:started', { job });

    return job;
  }

  /**
   * Complete a sync job successfully
   */
  async completeJob(jobId: string, result: SyncResult): Promise<SyncJob | null> {
    const job = this.activeSyncs.get(jobId) || (await this.getJob(jobId));
    if (!job) {
      console.error(`Job not found: ${jobId}`);
      return null;
    }

    job.status = 'completed';
    job.result = result;
    job.completedAt = new Date();
    job.updatedAt = new Date();

    await this.saveJob(job);
    this.activeSyncs.delete(jobId);

    await this.logAudit(job, 'completed', { result });
    this.emitEvent('sync:completed', { job, result });

    return job;
  }

  /**
   * Fail a sync job
   */
  async failJob(jobId: string, error: SyncError): Promise<SyncJob | null> {
    const job = this.activeSyncs.get(jobId) || (await this.getJob(jobId));
    if (!job) {
      console.error(`Job not found: ${jobId}`);
      return null;
    }

    // Check if we should retry
    if (error.retryable && job.retryCount < job.maxRetries) {
      return this.retryJob(jobId, error);
    }

    job.status = 'failed';
    job.error = error;
    job.completedAt = new Date();
    job.updatedAt = new Date();

    await this.saveJob(job);
    this.activeSyncs.delete(jobId);

    await this.logAudit(job, 'failed', { error });
    this.emitEvent('sync:failed', { job, error });

    return job;
  }

  /**
   * Retry a sync job
   */
  async retryJob(jobId: string, error: SyncError): Promise<SyncJob | null> {
    const job = this.activeSyncs.get(jobId) || (await this.getJob(jobId));
    if (!job) {
      console.error(`Job not found: ${jobId}`);
      return null;
    }

    job.status = 'retrying';
    job.retryCount++;
    job.error = error;
    job.updatedAt = new Date();

    // Calculate retry delay with exponential backoff
    const delay = this.retryDelayMs * Math.pow(2, job.retryCount - 1);
    job.scheduledAt = new Date(Date.now() + delay);

    await this.saveJob(job);
    this.activeSyncs.delete(jobId);

    await this.logAudit(job, 'retried', { error, retryCount: job.retryCount, delay });
    this.emitEvent('sync:retrying', { job, error, retryCount: job.retryCount });

    // Schedule retry
    setTimeout(async () => {
      await this.startJob(jobId);
    }, delay);

    return job;
  }

  /**
   * Cancel a sync job
   */
  async cancelJob(jobId: string, reason?: string): Promise<SyncJob | null> {
    const job = this.activeSyncs.get(jobId) || (await this.getJob(jobId));
    if (!job) {
      console.error(`Job not found: ${jobId}`);
      return null;
    }

    job.status = 'cancelled';
    job.error = {
      code: 'CANCELLED',
      message: reason || 'Job was cancelled',
      retryable: false,
    };
    job.completedAt = new Date();
    job.updatedAt = new Date();

    await this.saveJob(job);
    this.activeSyncs.delete(jobId);

    await this.logAudit(job, 'cancelled', { reason });
    this.emitEvent('sync:cancelled', { job, reason });

    return job;
  }

  // ============================================================================
  // Job Queries
  // ============================================================================

  /**
   * Get a sync job by ID
   */
  async getJob(jobId: string): Promise<SyncJob | null> {
    // Check active syncs first
    const active = this.activeSyncs.get(jobId);
    if (active) return active;

    // Load from database
    const { data, error } = await this.supabase
      .from('sync_jobs')
      .select('*')
      .eq('id', jobId)
      .single();

    if (error || !data) {
      return null;
    }

    return this.mapDbRowToJob(data);
  }

  /**
   * Get jobs by status
   */
  async getJobsByStatus(
    status: SyncStatus | SyncStatus[],
    options: {
      platform?: ConnectorName;
      type?: SyncType;
      limit?: number;
      offset?: number;
    } = {}
  ): Promise<SyncJob[]> {
    const statuses = Array.isArray(status) ? status : [status];

    let query = this.supabase
      .from('sync_jobs')
      .select('*')
      .in('status', statuses)
      .order('created_at', { ascending: false });

    if (options.platform) {
      query = query.or(
        `source_platform.eq.${options.platform},target_platforms.cs.{${options.platform}}`
      );
    }

    if (options.type) {
      query = query.eq('type', options.type);
    }

    if (options.limit) {
      query = query.limit(options.limit);
    }

    if (options.offset) {
      query = query.range(options.offset, options.offset + (options.limit || 10) - 1);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Failed to fetch jobs:', error);
      return [];
    }

    return (data || []).map((row) => this.mapDbRowToJob(row));
  }

  /**
   * Get pending jobs ready for processing
   */
  async getPendingJobs(limit: number = 10): Promise<SyncJob[]> {
    const { data, error } = await this.supabase
      .from('sync_jobs')
      .select('*')
      .in('status', ['pending', 'retrying'])
      .lte('scheduled_at', new Date().toISOString())
      .order('priority', { ascending: false })
      .order('scheduled_at', { ascending: true })
      .limit(limit);

    if (error) {
      console.error('Failed to fetch pending jobs:', error);
      return [];
    }

    return (data || []).map((row) => this.mapDbRowToJob(row));
  }

  /**
   * Get active syncs
   */
  getActiveSyncs(): SyncJob[] {
    return Array.from(this.activeSyncs.values());
  }

  /**
   * Get job history for a product
   */
  async getProductSyncHistory(
    productId: string,
    options: { limit?: number; type?: SyncType } = {}
  ): Promise<SyncJob[]> {
    let query = this.supabase
      .from('sync_jobs')
      .select('*')
      .eq('product_id', productId)
      .order('created_at', { ascending: false });

    if (options.type) {
      query = query.eq('type', options.type);
    }

    if (options.limit) {
      query = query.limit(options.limit);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Failed to fetch product sync history:', error);
      return [];
    }

    return (data || []).map((row) => this.mapDbRowToJob(row));
  }

  // ============================================================================
  // Health & Monitoring
  // ============================================================================

  /**
   * Get sync health status
   */
  async getHealthStatus(): Promise<SyncHealthStatus> {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    // Get recent job stats
    const { data: recentJobs } = await this.supabase
      .from('sync_jobs')
      .select('status, completed_at, started_at, source_platform, target_platforms')
      .gte('created_at', oneDayAgo.toISOString());

    const jobs = recentJobs || [];
    const completedJobs = jobs.filter((j) => j.status === 'completed');
    const failedJobs = jobs.filter((j) => j.status === 'failed');

    // Calculate metrics
    const failureRate = jobs.length > 0 ? failedJobs.length / jobs.length : 0;
    const avgLatency = this.calculateAverageLatency(completedJobs);

    // Get platform-specific health
    const platformStatuses = await this.getPlatformHealthStatuses(jobs);

    // Determine overall health
    const healthy =
      failureRate < 0.1 && // Less than 10% failure rate
      this.activeSyncs.size < this.maxConcurrentJobs && // Not at capacity
      platformStatuses.every((p) => p.healthy);

    // Get last successful sync
    const lastSuccess = completedJobs
      .filter((j) => j.completed_at)
      .sort((a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime())[0];

    return {
      healthy,
      lastSyncAt: jobs[0]?.completed_at ? new Date(jobs[0].completed_at) : undefined,
      lastSuccessfulSyncAt: lastSuccess?.completed_at
        ? new Date(lastSuccess.completed_at)
        : undefined,
      consecutiveFailures: this.countConsecutiveFailures(jobs),
      failureRate24h: failureRate,
      averageLatency: avgLatency,
      queueDepth: await this.getQueueDepth(),
      activeSyncs: this.activeSyncs.size,
      platformStatuses,
    };
  }

  /**
   * Get queue depth
   */
  async getQueueDepth(): Promise<number> {
    const { count, error } = await this.supabase
      .from('sync_jobs')
      .select('*', { count: 'exact', head: true })
      .in('status', ['pending', 'retrying']);

    if (error) {
      console.error('Failed to get queue depth:', error);
      return 0;
    }

    return count || 0;
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private async saveJob(job: SyncJob): Promise<void> {
    const row = this.mapJobToDbRow(job);

    const { error } = await this.supabase
      .from('sync_jobs')
      .upsert(row, { onConflict: 'id' });

    if (error) {
      console.error('Failed to save job:', error);
    }
  }

  private async logAudit(
    job: SyncJob,
    action: SyncAuditEntry['action'],
    details?: Record<string, unknown>
  ): Promise<void> {
    const entry: Omit<SyncAuditEntry, 'id'> = {
      syncJobId: job.id,
      syncType: job.type,
      action,
      platform: job.sourcePlatform,
      actor: 'system',
      details,
      timestamp: new Date(),
    };

    await this.supabase.from('sync_audit_log').insert({
      sync_job_id: entry.syncJobId,
      sync_type: entry.syncType,
      action: entry.action,
      platform: entry.platform,
      actor: entry.actor,
      details: entry.details,
      timestamp: entry.timestamp.toISOString(),
    });
  }

  private emitEvent(type: SyncEventType, payload: Record<string, unknown>): void {
    const event: SyncEvent = {
      type,
      payload,
      timestamp: new Date(),
    };
    this.emit(type, event);
    this.emit('sync:event', event);
  }

  private mapDbRowToJob(row: Record<string, unknown>): SyncJob {
    return {
      id: row.id as string,
      type: row.type as SyncType,
      direction: row.direction as SyncDirection,
      status: row.status as SyncStatus,
      priority: row.priority as SyncPriority,
      sourcePlatform: row.source_platform as ConnectorName,
      targetPlatforms: row.target_platforms as ConnectorName[],
      productId: row.product_id as string | undefined,
      orderId: row.order_id as string | undefined,
      data: row.data as SyncData,
      result: row.result as SyncResult | undefined,
      error: row.error as SyncError | undefined,
      retryCount: row.retry_count as number,
      maxRetries: row.max_retries as number,
      scheduledAt: new Date(row.scheduled_at as string),
      startedAt: row.started_at ? new Date(row.started_at as string) : undefined,
      completedAt: row.completed_at ? new Date(row.completed_at as string) : undefined,
      createdAt: new Date(row.created_at as string),
      updatedAt: new Date(row.updated_at as string),
    };
  }

  private mapJobToDbRow(job: SyncJob): Record<string, unknown> {
    return {
      id: job.id,
      type: job.type,
      direction: job.direction,
      status: job.status,
      priority: job.priority,
      source_platform: job.sourcePlatform,
      target_platforms: job.targetPlatforms,
      product_id: job.productId,
      order_id: job.orderId,
      data: job.data,
      result: job.result,
      error: job.error,
      retry_count: job.retryCount,
      max_retries: job.maxRetries,
      scheduled_at: job.scheduledAt.toISOString(),
      started_at: job.startedAt?.toISOString(),
      completed_at: job.completedAt?.toISOString(),
      created_at: job.createdAt.toISOString(),
      updated_at: job.updatedAt.toISOString(),
    };
  }

  private calculateAverageLatency(
    jobs: Array<{ started_at?: string; completed_at?: string }>
  ): number {
    const validJobs = jobs.filter((j) => j.started_at && j.completed_at);
    if (validJobs.length === 0) return 0;

    const totalLatency = validJobs.reduce((sum, job) => {
      const start = new Date(job.started_at!).getTime();
      const end = new Date(job.completed_at!).getTime();
      return sum + (end - start);
    }, 0);

    return totalLatency / validJobs.length;
  }

  private countConsecutiveFailures(
    jobs: Array<{ status: string; completed_at?: string }>
  ): number {
    const sortedJobs = [...jobs]
      .filter((j) => j.completed_at)
      .sort(
        (a, b) =>
          new Date(b.completed_at!).getTime() - new Date(a.completed_at!).getTime()
      );

    let count = 0;
    for (const job of sortedJobs) {
      if (job.status === 'failed') {
        count++;
      } else if (job.status === 'completed') {
        break;
      }
    }

    return count;
  }

  private async getPlatformHealthStatuses(
    jobs: Array<{
      status: string;
      completed_at?: string;
      source_platform: string;
      target_platforms: string[];
    }>
  ): Promise<PlatformSyncHealth[]> {
    const platforms = new Set<ConnectorName>();

    // Collect all platforms
    jobs.forEach((job) => {
      platforms.add(job.source_platform as ConnectorName);
      (job.target_platforms || []).forEach((p) =>
        platforms.add(p as ConnectorName)
      );
    });

    return Array.from(platforms).map((platform) => {
      const platformJobs = jobs.filter(
        (j) =>
          j.source_platform === platform ||
          (j.target_platforms || []).includes(platform)
      );

      const completed = platformJobs.filter((j) => j.status === 'completed');
      const failed = platformJobs.filter((j) => j.status === 'failed');
      const failureRate = platformJobs.length > 0 ? failed.length / platformJobs.length : 0;

      const lastSuccess = completed
        .filter((j) => j.completed_at)
        .sort(
          (a, b) =>
            new Date(b.completed_at!).getTime() - new Date(a.completed_at!).getTime()
        )[0];

      return {
        platform,
        healthy: failureRate < 0.2,
        lastSyncAt: platformJobs[0]?.completed_at
          ? new Date(platformJobs[0].completed_at)
          : undefined,
        lastSuccessfulSyncAt: lastSuccess?.completed_at
          ? new Date(lastSuccess.completed_at)
          : undefined,
        consecutiveFailures: this.countConsecutiveFailures(platformJobs),
        failureRate24h: failureRate,
        averageLatency: 0, // Would need additional calculation
        webhookStatus: 'active' as const,
      };
    });
  }
}

export default SyncManager;
