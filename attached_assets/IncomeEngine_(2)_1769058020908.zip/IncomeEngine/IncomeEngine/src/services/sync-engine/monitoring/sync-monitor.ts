/**
 * Sync Monitor
 * Real-time monitoring and health tracking for the sync engine
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  SyncHealthStatus,
  PlatformSyncHealth,
  SyncAlert,
  SyncJob,
  SyncStatus,
} from '../types';
import { ConnectorName } from '../../../connectors/index';
import { SyncManager } from '../sync-manager';
import { SyncQueue } from '../queue/sync-queue';

// ============================================================================
// Types
// ============================================================================

export interface MonitorConfig {
  checkIntervalMs: number;
  latencyThresholdMs: number;
  failureRateThreshold: number;
  queueDepthThreshold: number;
  consecutiveFailureThreshold: number;
  enableAlerts: boolean;
  retentionDays: number;
}

export interface HealthCheck {
  id: string;
  timestamp: Date;
  status: SyncHealthStatus;
  alerts: SyncAlert[];
}

export interface PlatformMetrics {
  platform: ConnectorName;
  totalSyncs24h: number;
  successfulSyncs: number;
  failedSyncs: number;
  averageLatency: number;
  p95Latency: number;
  lastSyncAt?: Date;
  webhooksReceived24h: number;
  errorRate: number;
}

export interface SyncMetricsSummary {
  timestamp: Date;
  overall: {
    totalSyncs: number;
    successRate: number;
    averageLatency: number;
    queueDepth: number;
    activeSyncs: number;
  };
  byPlatform: PlatformMetrics[];
  bySyncType: Record<string, { count: number; successRate: number; avgLatency: number }>;
  alerts: SyncAlert[];
}

// ============================================================================
// Default Configuration
// ============================================================================

const DEFAULT_CONFIG: MonitorConfig = {
  checkIntervalMs: 30000, // 30 seconds
  latencyThresholdMs: 5000, // 5 seconds
  failureRateThreshold: 0.1, // 10%
  queueDepthThreshold: 100,
  consecutiveFailureThreshold: 5,
  enableAlerts: true,
  retentionDays: 30,
};

// ============================================================================
// Sync Monitor Class
// ============================================================================

export class SyncMonitor extends EventEmitter {
  private supabase: SupabaseClient;
  private syncManager: SyncManager;
  private queue: SyncQueue;
  private config: MonitorConfig;
  private monitorInterval: NodeJS.Timeout | null;
  private lastHealthCheck: HealthCheck | null;
  private metricsHistory: SyncMetricsSummary[];

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    syncManager: SyncManager,
    queue: SyncQueue,
    config: Partial<MonitorConfig> = {}
  ) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.syncManager = syncManager;
    this.queue = queue;
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.monitorInterval = null;
    this.lastHealthCheck = null;
    this.metricsHistory = [];
  }

  /**
   * Start monitoring
   */
  start(): void {
    if (this.monitorInterval) {
      return;
    }

    this.monitorInterval = setInterval(() => {
      this.performHealthCheck();
    }, this.config.checkIntervalMs);

    // Initial check
    this.performHealthCheck();

    this.emit('monitor:started');
  }

  /**
   * Stop monitoring
   */
  stop(): void {
    if (this.monitorInterval) {
      clearInterval(this.monitorInterval);
      this.monitorInterval = null;
    }

    this.emit('monitor:stopped');
  }

  /**
   * Get current health status
   */
  async getHealthStatus(): Promise<SyncHealthStatus> {
    return this.syncManager.getHealthStatus();
  }

  /**
   * Get latest health check
   */
  getLastHealthCheck(): HealthCheck | null {
    return this.lastHealthCheck;
  }

  /**
   * Get metrics summary
   */
  async getMetricsSummary(): Promise<SyncMetricsSummary> {
    const [platformMetrics, syncTypeMetrics, alerts] = await Promise.all([
      this.getPlatformMetrics(),
      this.getSyncTypeMetrics(),
      this.getActiveAlerts(),
    ]);

    const healthStatus = await this.getHealthStatus();

    return {
      timestamp: new Date(),
      overall: {
        totalSyncs: platformMetrics.reduce((sum, p) => sum + p.totalSyncs24h, 0),
        successRate: 1 - healthStatus.failureRate24h,
        averageLatency: healthStatus.averageLatency,
        queueDepth: healthStatus.queueDepth,
        activeSyncs: healthStatus.activeSyncs,
      },
      byPlatform: platformMetrics,
      bySyncType: syncTypeMetrics,
      alerts,
    };
  }

  /**
   * Get platform-specific metrics
   */
  async getPlatformMetrics(): Promise<PlatformMetrics[]> {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const { data: jobs } = await this.supabase
      .from('sync_jobs')
      .select('source_platform, target_platforms, status, started_at, completed_at')
      .gte('created_at', oneDayAgo.toISOString());

    const { data: webhooks } = await this.supabase
      .from('webhook_events')
      .select('platform')
      .gte('received_at', oneDayAgo.toISOString());

    // Aggregate by platform
    const platformStats = new Map<
      string,
      {
        total: number;
        successful: number;
        failed: number;
        latencies: number[];
        lastSync?: Date;
        webhooks: number;
      }
    >();

    for (const job of jobs || []) {
      const platforms = [
        job.source_platform,
        ...(job.target_platforms || []),
      ];

      for (const platform of platforms) {
        if (!platformStats.has(platform)) {
          platformStats.set(platform, {
            total: 0,
            successful: 0,
            failed: 0,
            latencies: [],
            webhooks: 0,
          });
        }

        const stats = platformStats.get(platform)!;
        stats.total++;

        if (job.status === 'completed') {
          stats.successful++;
          if (job.started_at && job.completed_at) {
            const latency =
              new Date(job.completed_at).getTime() -
              new Date(job.started_at).getTime();
            stats.latencies.push(latency);
          }
        } else if (job.status === 'failed') {
          stats.failed++;
        }

        if (job.completed_at) {
          const completedAt = new Date(job.completed_at);
          if (!stats.lastSync || completedAt > stats.lastSync) {
            stats.lastSync = completedAt;
          }
        }
      }
    }

    // Count webhooks
    for (const webhook of webhooks || []) {
      const stats = platformStats.get(webhook.platform);
      if (stats) {
        stats.webhooks++;
      }
    }

    // Build metrics
    return Array.from(platformStats.entries()).map(([platform, stats]) => {
      const sortedLatencies = [...stats.latencies].sort((a, b) => a - b);
      const p95Index = Math.floor(sortedLatencies.length * 0.95);

      return {
        platform: platform as ConnectorName,
        totalSyncs24h: stats.total,
        successfulSyncs: stats.successful,
        failedSyncs: stats.failed,
        averageLatency:
          stats.latencies.length > 0
            ? stats.latencies.reduce((a, b) => a + b, 0) / stats.latencies.length
            : 0,
        p95Latency:
          sortedLatencies.length > 0 ? sortedLatencies[p95Index] || 0 : 0,
        lastSyncAt: stats.lastSync,
        webhooksReceived24h: stats.webhooks,
        errorRate: stats.total > 0 ? stats.failed / stats.total : 0,
      };
    });
  }

  /**
   * Get sync type metrics
   */
  async getSyncTypeMetrics(): Promise<
    Record<string, { count: number; successRate: number; avgLatency: number }>
  > {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const { data: jobs } = await this.supabase
      .from('sync_jobs')
      .select('type, status, started_at, completed_at')
      .gte('created_at', oneDayAgo.toISOString());

    const typeStats = new Map<
      string,
      { count: number; successful: number; latencies: number[] }
    >();

    for (const job of jobs || []) {
      if (!typeStats.has(job.type)) {
        typeStats.set(job.type, { count: 0, successful: 0, latencies: [] });
      }

      const stats = typeStats.get(job.type)!;
      stats.count++;

      if (job.status === 'completed') {
        stats.successful++;
        if (job.started_at && job.completed_at) {
          const latency =
            new Date(job.completed_at).getTime() -
            new Date(job.started_at).getTime();
          stats.latencies.push(latency);
        }
      }
    }

    const result: Record<
      string,
      { count: number; successRate: number; avgLatency: number }
    > = {};

    for (const [type, stats] of typeStats) {
      result[type] = {
        count: stats.count,
        successRate: stats.count > 0 ? stats.successful / stats.count : 0,
        avgLatency:
          stats.latencies.length > 0
            ? stats.latencies.reduce((a, b) => a + b, 0) / stats.latencies.length
            : 0,
      };
    }

    return result;
  }

  /**
   * Get active alerts
   */
  async getActiveAlerts(): Promise<SyncAlert[]> {
    const { data } = await this.supabase
      .from('sync_alerts')
      .select('*')
      .eq('acknowledged', false)
      .order('created_at', { ascending: false })
      .limit(50);

    return (data || []).map((row) => this.mapDbRowToAlert(row));
  }

  /**
   * Acknowledge an alert
   */
  async acknowledgeAlert(alertId: string, acknowledgedBy: string): Promise<void> {
    await this.supabase
      .from('sync_alerts')
      .update({
        acknowledged: true,
        acknowledged_at: new Date().toISOString(),
        acknowledged_by: acknowledgedBy,
      })
      .eq('id', alertId);

    this.emit('alert:acknowledged', { alertId, acknowledgedBy });
  }

  /**
   * Get historical metrics
   */
  getMetricsHistory(
    hours: number = 24
  ): SyncMetricsSummary[] {
    const cutoff = Date.now() - hours * 60 * 60 * 1000;
    return this.metricsHistory.filter(
      (m) => m.timestamp.getTime() >= cutoff
    );
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private async performHealthCheck(): Promise<void> {
    try {
      const healthStatus = await this.getHealthStatus();
      const alerts: SyncAlert[] = [];

      // Check failure rate
      if (healthStatus.failureRate24h > this.config.failureRateThreshold) {
        const alert = await this.createAlert(
          'sync_failure',
          healthStatus.failureRate24h > 0.5 ? 'critical' : 'warning',
          `High failure rate: ${(healthStatus.failureRate24h * 100).toFixed(1)}%`,
          { failureRate: healthStatus.failureRate24h }
        );
        alerts.push(alert);
      }

      // Check latency
      if (healthStatus.averageLatency > this.config.latencyThresholdMs) {
        const alert = await this.createAlert(
          'latency',
          healthStatus.averageLatency > this.config.latencyThresholdMs * 2
            ? 'error'
            : 'warning',
          `High latency: ${healthStatus.averageLatency.toFixed(0)}ms average`,
          { latency: healthStatus.averageLatency }
        );
        alerts.push(alert);
      }

      // Check queue depth
      if (healthStatus.queueDepth > this.config.queueDepthThreshold) {
        const alert = await this.createAlert(
          'queue_depth',
          healthStatus.queueDepth > this.config.queueDepthThreshold * 2
            ? 'error'
            : 'warning',
          `Queue depth high: ${healthStatus.queueDepth} jobs pending`,
          { queueDepth: healthStatus.queueDepth }
        );
        alerts.push(alert);
      }

      // Check consecutive failures
      if (
        healthStatus.consecutiveFailures > this.config.consecutiveFailureThreshold
      ) {
        const alert = await this.createAlert(
          'sync_failure',
          'critical',
          `${healthStatus.consecutiveFailures} consecutive failures detected`,
          { consecutiveFailures: healthStatus.consecutiveFailures }
        );
        alerts.push(alert);
      }

      // Check platform health
      for (const platformStatus of healthStatus.platformStatuses) {
        if (!platformStatus.healthy) {
          const alert = await this.createAlert(
            'platform_down',
            'error',
            `Platform ${platformStatus.platform} is unhealthy`,
            { platform: platformStatus.platform, status: platformStatus }
          );
          alerts.push(alert);
        }
      }

      // Store health check
      this.lastHealthCheck = {
        id: `hc-${Date.now()}`,
        timestamp: new Date(),
        status: healthStatus,
        alerts,
      };

      // Store metrics
      const metrics = await this.getMetricsSummary();
      this.metricsHistory.push(metrics);

      // Trim old metrics (keep last 24 hours)
      const cutoff = Date.now() - 24 * 60 * 60 * 1000;
      this.metricsHistory = this.metricsHistory.filter(
        (m) => m.timestamp.getTime() >= cutoff
      );

      // Persist health check
      await this.persistHealthCheck(this.lastHealthCheck);

      this.emit('healthCheck:completed', { healthCheck: this.lastHealthCheck });
    } catch (error) {
      console.error('Health check failed:', error);
      this.emit('healthCheck:failed', { error });
    }
  }

  private async createAlert(
    type: SyncAlert['type'],
    severity: SyncAlert['severity'],
    message: string,
    details?: Record<string, unknown>
  ): Promise<SyncAlert> {
    const alert: SyncAlert = {
      id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      severity,
      message,
      details,
      acknowledged: false,
      createdAt: new Date(),
    };

    if (this.config.enableAlerts) {
      await this.supabase.from('sync_alerts').insert({
        id: alert.id,
        type: alert.type,
        severity: alert.severity,
        message: alert.message,
        details: alert.details,
        acknowledged: false,
        created_at: alert.createdAt.toISOString(),
      });

      this.emit('alert:created', { alert });
    }

    return alert;
  }

  private async persistHealthCheck(check: HealthCheck): Promise<void> {
    await this.supabase.from('health_checks').insert({
      id: check.id,
      timestamp: check.timestamp.toISOString(),
      status: check.status,
      alert_count: check.alerts.length,
    });
  }

  private mapDbRowToAlert(row: Record<string, unknown>): SyncAlert {
    return {
      id: row.id as string,
      type: row.type as SyncAlert['type'],
      severity: row.severity as SyncAlert['severity'],
      platform: row.platform as ConnectorName | undefined,
      message: row.message as string,
      details: row.details as Record<string, unknown> | undefined,
      acknowledged: row.acknowledged as boolean,
      acknowledgedAt: row.acknowledged_at
        ? new Date(row.acknowledged_at as string)
        : undefined,
      acknowledgedBy: row.acknowledged_by as string | undefined,
      createdAt: new Date(row.created_at as string),
    };
  }
}

export default SyncMonitor;
