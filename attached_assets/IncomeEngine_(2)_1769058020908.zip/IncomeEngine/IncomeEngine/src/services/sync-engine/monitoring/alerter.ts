/**
 * Alerter
 * Sends alerts through various channels (email, Slack, webhooks)
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { SyncAlert } from '../types';
import { ConnectorName } from '../../../connectors/index';

// ============================================================================
// Types
// ============================================================================

export type AlertChannel = 'email' | 'slack' | 'webhook' | 'sms' | 'push';

export interface AlertChannelConfig {
  channel: AlertChannel;
  enabled: boolean;
  config: Record<string, unknown>;
  severityFilter: SyncAlert['severity'][];
  typeFilter?: SyncAlert['type'][];
  platformFilter?: ConnectorName[];
  rateLimit?: {
    maxPerHour: number;
    burstLimit: number;
  };
}

export interface AlertDeliveryResult {
  channel: AlertChannel;
  success: boolean;
  error?: string;
  deliveredAt: Date;
  messageId?: string;
}

export interface AlerterStats {
  totalSent: number;
  byChannel: Record<AlertChannel, number>;
  bySeverity: Record<string, number>;
  failedDeliveries: number;
  rateLimited: number;
}

// ============================================================================
// Alerter Class
// ============================================================================

export class Alerter {
  private supabase: SupabaseClient;
  private channels: Map<AlertChannel, AlertChannelConfig>;
  private rateLimitCounters: Map<string, { count: number; resetAt: number }>;
  private stats: AlerterStats;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.channels = new Map();
    this.rateLimitCounters = new Map();
    this.stats = {
      totalSent: 0,
      byChannel: {} as Record<AlertChannel, number>,
      bySeverity: {},
      failedDeliveries: 0,
      rateLimited: 0,
    };
  }

  /**
   * Configure an alert channel
   */
  configureChannel(config: AlertChannelConfig): void {
    this.channels.set(config.channel, config);
  }

  /**
   * Remove a channel configuration
   */
  removeChannel(channel: AlertChannel): void {
    this.channels.delete(channel);
  }

  /**
   * Send an alert through configured channels
   */
  async sendAlert(alert: SyncAlert): Promise<AlertDeliveryResult[]> {
    const results: AlertDeliveryResult[] = [];

    for (const [channel, config] of this.channels) {
      if (!config.enabled) continue;

      // Check severity filter
      if (!config.severityFilter.includes(alert.severity)) continue;

      // Check type filter
      if (config.typeFilter && !config.typeFilter.includes(alert.type)) continue;

      // Check platform filter
      if (
        config.platformFilter &&
        alert.platform &&
        !config.platformFilter.includes(alert.platform)
      ) {
        continue;
      }

      // Check rate limit
      if (!this.checkRateLimit(channel, config)) {
        this.stats.rateLimited++;
        results.push({
          channel,
          success: false,
          error: 'Rate limited',
          deliveredAt: new Date(),
        });
        continue;
      }

      try {
        const result = await this.deliverToChannel(channel, alert, config);
        results.push(result);

        if (result.success) {
          this.stats.totalSent++;
          this.stats.byChannel[channel] = (this.stats.byChannel[channel] || 0) + 1;
          this.stats.bySeverity[alert.severity] =
            (this.stats.bySeverity[alert.severity] || 0) + 1;
        } else {
          this.stats.failedDeliveries++;
        }

        // Log delivery
        await this.logDelivery(alert, result);
      } catch (error) {
        const result: AlertDeliveryResult = {
          channel,
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
          deliveredAt: new Date(),
        };
        results.push(result);
        this.stats.failedDeliveries++;
        await this.logDelivery(alert, result);
      }
    }

    return results;
  }

  /**
   * Get alerter statistics
   */
  getStats(): AlerterStats {
    return { ...this.stats };
  }

  /**
   * Reset statistics
   */
  resetStats(): void {
    this.stats = {
      totalSent: 0,
      byChannel: {} as Record<AlertChannel, number>,
      bySeverity: {},
      failedDeliveries: 0,
      rateLimited: 0,
    };
  }

  // ============================================================================
  // Channel Delivery Methods
  // ============================================================================

  private async deliverToChannel(
    channel: AlertChannel,
    alert: SyncAlert,
    config: AlertChannelConfig
  ): Promise<AlertDeliveryResult> {
    switch (channel) {
      case 'slack':
        return this.sendSlack(alert, config);
      case 'webhook':
        return this.sendWebhook(alert, config);
      case 'email':
        return this.sendEmail(alert, config);
      case 'sms':
        return this.sendSms(alert, config);
      case 'push':
        return this.sendPush(alert, config);
      default:
        return {
          channel,
          success: false,
          error: `Unknown channel: ${channel}`,
          deliveredAt: new Date(),
        };
    }
  }

  private async sendSlack(
    alert: SyncAlert,
    config: AlertChannelConfig
  ): Promise<AlertDeliveryResult> {
    const webhookUrl = config.config.webhookUrl as string;
    const channel = config.config.channel as string | undefined;

    if (!webhookUrl) {
      return {
        channel: 'slack',
        success: false,
        error: 'Slack webhook URL not configured',
        deliveredAt: new Date(),
      };
    }

    const color = this.getSeverityColor(alert.severity);
    const emoji = this.getSeverityEmoji(alert.severity);

    const payload = {
      channel,
      attachments: [
        {
          color,
          blocks: [
            {
              type: 'header',
              text: {
                type: 'plain_text',
                text: `${emoji} Sync Alert: ${alert.type.replace('_', ' ').toUpperCase()}`,
              },
            },
            {
              type: 'section',
              text: {
                type: 'mrkdwn',
                text: alert.message,
              },
            },
            {
              type: 'context',
              elements: [
                {
                  type: 'mrkdwn',
                  text: `*Severity:* ${alert.severity} | *Time:* ${alert.createdAt.toISOString()}${alert.platform ? ` | *Platform:* ${alert.platform}` : ''}`,
                },
              ],
            },
          ],
        },
      ],
    };

    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        return {
          channel: 'slack',
          success: false,
          error: `Slack API error: ${response.status} - ${errorText}`,
          deliveredAt: new Date(),
        };
      }

      return {
        channel: 'slack',
        success: true,
        deliveredAt: new Date(),
      };
    } catch (error) {
      return {
        channel: 'slack',
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        deliveredAt: new Date(),
      };
    }
  }

  private async sendWebhook(
    alert: SyncAlert,
    config: AlertChannelConfig
  ): Promise<AlertDeliveryResult> {
    const url = config.config.url as string;
    const secret = config.config.secret as string | undefined;
    const headers = config.config.headers as Record<string, string> | undefined;

    if (!url) {
      return {
        channel: 'webhook',
        success: false,
        error: 'Webhook URL not configured',
        deliveredAt: new Date(),
      };
    }

    const payload = {
      event: 'sync_alert',
      timestamp: new Date().toISOString(),
      alert: {
        id: alert.id,
        type: alert.type,
        severity: alert.severity,
        message: alert.message,
        platform: alert.platform,
        details: alert.details,
        createdAt: alert.createdAt.toISOString(),
      },
    };

    const requestHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      ...headers,
    };

    // Add signature if secret provided
    if (secret) {
      const crypto = await import('crypto');
      const signature = crypto
        .createHmac('sha256', secret)
        .update(JSON.stringify(payload))
        .digest('hex');
      requestHeaders['X-Webhook-Signature'] = `sha256=${signature}`;
    }

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: requestHeaders,
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        return {
          channel: 'webhook',
          success: false,
          error: `Webhook error: ${response.status}`,
          deliveredAt: new Date(),
        };
      }

      return {
        channel: 'webhook',
        success: true,
        deliveredAt: new Date(),
      };
    } catch (error) {
      return {
        channel: 'webhook',
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        deliveredAt: new Date(),
      };
    }
  }

  private async sendEmail(
    alert: SyncAlert,
    config: AlertChannelConfig
  ): Promise<AlertDeliveryResult> {
    // Email would require an email service (SendGrid, SES, etc.)
    // This is a placeholder implementation
    const recipients = config.config.recipients as string[];
    const from = config.config.from as string;

    if (!recipients || recipients.length === 0) {
      return {
        channel: 'email',
        success: false,
        error: 'No email recipients configured',
        deliveredAt: new Date(),
      };
    }

    // Store in database for email service to pick up
    await this.supabase.from('email_queue').insert({
      to: recipients,
      from: from || 'alerts@incomeengine.app',
      subject: `[${alert.severity.toUpperCase()}] Sync Alert: ${alert.type}`,
      body: this.formatEmailBody(alert),
      html: this.formatEmailHtml(alert),
      status: 'pending',
      created_at: new Date().toISOString(),
    });

    return {
      channel: 'email',
      success: true,
      deliveredAt: new Date(),
      messageId: `email-${Date.now()}`,
    };
  }

  private async sendSms(
    alert: SyncAlert,
    config: AlertChannelConfig
  ): Promise<AlertDeliveryResult> {
    // SMS would require a service like Twilio
    // Placeholder implementation
    const phoneNumbers = config.config.phoneNumbers as string[];

    if (!phoneNumbers || phoneNumbers.length === 0) {
      return {
        channel: 'sms',
        success: false,
        error: 'No phone numbers configured',
        deliveredAt: new Date(),
      };
    }

    // Store in database for SMS service to pick up
    for (const phone of phoneNumbers) {
      await this.supabase.from('sms_queue').insert({
        to: phone,
        message: `[${alert.severity.toUpperCase()}] ${alert.message}`,
        status: 'pending',
        created_at: new Date().toISOString(),
      });
    }

    return {
      channel: 'sms',
      success: true,
      deliveredAt: new Date(),
    };
  }

  private async sendPush(
    alert: SyncAlert,
    config: AlertChannelConfig
  ): Promise<AlertDeliveryResult> {
    // Push notifications would require a service like Firebase
    // Placeholder implementation
    const deviceTokens = config.config.deviceTokens as string[];

    if (!deviceTokens || deviceTokens.length === 0) {
      return {
        channel: 'push',
        success: false,
        error: 'No device tokens configured',
        deliveredAt: new Date(),
      };
    }

    // Store in database for push service to pick up
    await this.supabase.from('push_queue').insert({
      tokens: deviceTokens,
      title: `Sync Alert: ${alert.type}`,
      body: alert.message,
      data: {
        alertId: alert.id,
        type: alert.type,
        severity: alert.severity,
      },
      status: 'pending',
      created_at: new Date().toISOString(),
    });

    return {
      channel: 'push',
      success: true,
      deliveredAt: new Date(),
    };
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private checkRateLimit(channel: AlertChannel, config: AlertChannelConfig): boolean {
    if (!config.rateLimit) return true;

    const key = channel;
    const now = Date.now();
    const counter = this.rateLimitCounters.get(key);

    if (!counter || now >= counter.resetAt) {
      this.rateLimitCounters.set(key, {
        count: 1,
        resetAt: now + 60 * 60 * 1000, // 1 hour
      });
      return true;
    }

    if (counter.count >= config.rateLimit.maxPerHour) {
      return false;
    }

    counter.count++;
    return true;
  }

  private getSeverityColor(severity: SyncAlert['severity']): string {
    switch (severity) {
      case 'critical':
        return '#FF0000';
      case 'error':
        return '#FF6B6B';
      case 'warning':
        return '#FFD93D';
      case 'info':
        return '#6BCB77';
      default:
        return '#4D96FF';
    }
  }

  private getSeverityEmoji(severity: SyncAlert['severity']): string {
    switch (severity) {
      case 'critical':
        return '\u{1F6A8}'; // rotating light
      case 'error':
        return '\u{274C}'; // cross mark
      case 'warning':
        return '\u{26A0}'; // warning
      case 'info':
        return '\u{2139}'; // info
      default:
        return '\u{1F514}'; // bell
    }
  }

  private formatEmailBody(alert: SyncAlert): string {
    return `
Sync Alert: ${alert.type}

Severity: ${alert.severity.toUpperCase()}
Time: ${alert.createdAt.toISOString()}
${alert.platform ? `Platform: ${alert.platform}` : ''}

Message:
${alert.message}

${alert.details ? `Details:\n${JSON.stringify(alert.details, null, 2)}` : ''}

---
Income Engine Sync Alert System
    `.trim();
  }

  private formatEmailHtml(alert: SyncAlert): string {
    const color = this.getSeverityColor(alert.severity);
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    .header { background: ${color}; color: white; padding: 15px; border-radius: 5px 5px 0 0; }
    .content { background: #f5f5f5; padding: 20px; border-radius: 0 0 5px 5px; }
    .meta { color: #666; font-size: 12px; margin-top: 10px; }
    .details { background: #fff; padding: 10px; border-radius: 5px; margin-top: 15px; }
    pre { overflow-x: auto; }
  </style>
</head>
<body>
  <div class="header">
    <h2>Sync Alert: ${alert.type.replace('_', ' ').toUpperCase()}</h2>
  </div>
  <div class="content">
    <p><strong>Severity:</strong> ${alert.severity.toUpperCase()}</p>
    <p>${alert.message}</p>
    ${alert.platform ? `<p><strong>Platform:</strong> ${alert.platform}</p>` : ''}
    ${
      alert.details
        ? `<div class="details"><h4>Details:</h4><pre>${JSON.stringify(alert.details, null, 2)}</pre></div>`
        : ''
    }
    <p class="meta">Time: ${alert.createdAt.toISOString()}</p>
  </div>
</body>
</html>
    `.trim();
  }

  private async logDelivery(alert: SyncAlert, result: AlertDeliveryResult): Promise<void> {
    await this.supabase.from('alert_delivery_log').insert({
      alert_id: alert.id,
      channel: result.channel,
      success: result.success,
      error: result.error,
      message_id: result.messageId,
      delivered_at: result.deliveredAt.toISOString(),
    });
  }
}

export default Alerter;
