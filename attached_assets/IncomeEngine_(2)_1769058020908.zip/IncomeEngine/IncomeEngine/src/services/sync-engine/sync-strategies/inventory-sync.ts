/**
 * Inventory Sync Strategy
 * Handles real-time inventory synchronization across platforms
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  SyncJob,
  SyncResult,
  SyncError,
  InventorySyncData,
  PlatformSyncResult,
  Conflict,
} from '../types';
import { ConnectorName, createConnector, BaseConnector } from '../../../connectors/index';
import { ConflictResolver } from '../conflict-resolver';

// ============================================================================
// Types
// ============================================================================

export interface InventoryLevel {
  productId: string;
  platform: ConnectorName;
  externalId: string;
  variantId?: string;
  sku?: string;
  quantity: number;
  reservedQuantity: number;
  availableQuantity: number;
  lowStockThreshold: number;
  trackInventory: boolean;
  updatedAt: Date;
}

export interface InventoryUpdate {
  productId: string;
  variantId?: string;
  sku?: string;
  quantity: number;
  adjustment?: number;
  reason?: string;
}

export interface InventorySyncResult {
  success: boolean;
  platform: ConnectorName;
  previousQuantity: number;
  newQuantity: number;
  conflict?: Conflict;
  error?: SyncError;
}

// ============================================================================
// Inventory Sync Strategy Class
// ============================================================================

export class InventorySyncStrategy {
  private supabase: SupabaseClient;
  private conflictResolver: ConflictResolver;
  private lowStockThreshold: number;
  private connectors: Map<ConnectorName, BaseConnector>;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    conflictResolver: ConflictResolver,
    options: {
      lowStockThreshold?: number;
    } = {}
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.conflictResolver = conflictResolver;
    this.lowStockThreshold = options.lowStockThreshold || 5;
    this.connectors = new Map();
  }

  /**
   * Execute inventory sync for a job
   */
  async execute(job: SyncJob): Promise<SyncResult> {
    const startTime = Date.now();
    const inventoryData = job.data.inventory;

    if (!inventoryData) {
      return {
        success: false,
        syncedPlatforms: [],
        failedPlatforms: [],
        conflictsResolved: [],
        duration: Date.now() - startTime,
        timestamp: new Date(),
      };
    }

    const syncedPlatforms: PlatformSyncResult[] = [];
    const failedPlatforms: PlatformSyncResult[] = [];
    const conflictsResolved: Conflict['resolution'][] = [];

    // Get source inventory level
    const sourceLevel = await this.getInventoryLevel(
      inventoryData.productId,
      job.sourcePlatform,
      inventoryData.variantId
    );

    // Sync to each target platform
    for (const targetPlatform of job.targetPlatforms) {
      const platformStartTime = Date.now();

      try {
        // Get target current inventory
        const targetLevel = await this.getInventoryLevel(
          inventoryData.productId,
          targetPlatform,
          inventoryData.variantId
        );

        // Detect conflicts
        const conflicts = await this.conflictResolver.detectConflicts(
          job,
          { quantity: sourceLevel?.quantity || inventoryData.quantity },
          { quantity: targetLevel?.quantity },
          targetPlatform
        );

        // Resolve conflicts
        let finalQuantity = inventoryData.quantity;
        for (const conflict of conflicts) {
          const resolution = await this.conflictResolver.resolveConflict(conflict);
          if (resolution.resolvedValue !== undefined) {
            finalQuantity = resolution.resolvedValue as number;
            conflictsResolved.push(resolution);
          }
        }

        // Update target platform
        const result = await this.updatePlatformInventory(
          targetPlatform,
          inventoryData.productId,
          inventoryData.variantId,
          finalQuantity
        );

        if (result.success) {
          syncedPlatforms.push({
            platform: targetPlatform,
            success: true,
            externalId: targetLevel?.externalId,
            previousValue: targetLevel?.quantity,
            newValue: finalQuantity,
            duration: Date.now() - platformStartTime,
            retries: 0,
          });

          // Check for low stock alert
          if (finalQuantity <= this.lowStockThreshold) {
            await this.triggerLowStockAlert(
              inventoryData.productId,
              targetPlatform,
              finalQuantity
            );
          }
        } else {
          failedPlatforms.push({
            platform: targetPlatform,
            success: false,
            error: result.error,
            duration: Date.now() - platformStartTime,
            retries: 0,
          });
        }
      } catch (error) {
        failedPlatforms.push({
          platform: targetPlatform,
          success: false,
          error: {
            code: 'SYNC_ERROR',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
          duration: Date.now() - platformStartTime,
          retries: 0,
        });
      }
    }

    // Update local inventory record
    await this.updateLocalInventory(inventoryData);

    return {
      success: failedPlatforms.length === 0,
      syncedPlatforms,
      failedPlatforms,
      conflictsResolved: conflictsResolved.filter(Boolean) as Conflict['resolution'][],
      duration: Date.now() - startTime,
      timestamp: new Date(),
    };
  }

  /**
   * Pull inventory from all connected platforms
   */
  async pullInventory(productId: string, platforms: ConnectorName[]): Promise<InventoryLevel[]> {
    const levels: InventoryLevel[] = [];

    for (const platform of platforms) {
      try {
        const level = await this.getInventoryLevel(productId, platform);
        if (level) {
          levels.push(level);
        }
      } catch (error) {
        console.error(`Failed to pull inventory from ${platform}:`, error);
      }
    }

    return levels;
  }

  /**
   * Adjust inventory across all platforms
   */
  async adjustInventory(
    productId: string,
    adjustment: number,
    platforms: ConnectorName[],
    reason?: string
  ): Promise<Map<ConnectorName, InventorySyncResult>> {
    const results = new Map<ConnectorName, InventorySyncResult>();

    for (const platform of platforms) {
      try {
        const currentLevel = await this.getInventoryLevel(productId, platform);
        const currentQty = currentLevel?.quantity || 0;
        const newQty = Math.max(0, currentQty + adjustment);

        const result = await this.updatePlatformInventory(
          platform,
          productId,
          undefined,
          newQty
        );

        results.set(platform, {
          success: result.success,
          platform,
          previousQuantity: currentQty,
          newQuantity: newQty,
          error: result.error,
        });

        // Log adjustment
        await this.logInventoryChange(
          productId,
          platform,
          currentQty,
          newQty,
          adjustment,
          reason
        );
      } catch (error) {
        results.set(platform, {
          success: false,
          platform,
          previousQuantity: 0,
          newQuantity: 0,
          error: {
            code: 'ADJUSTMENT_FAILED',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
        });
      }
    }

    return results;
  }

  /**
   * Get unified inventory view across platforms
   */
  async getUnifiedInventory(
    productId: string
  ): Promise<{
    productId: string;
    totalQuantity: number;
    platformLevels: InventoryLevel[];
    lastSyncAt: Date;
    discrepancies: Array<{ platforms: ConnectorName[]; difference: number }>;
  }> {
    const { data: levels } = await this.supabase
      .from('inventory_levels')
      .select('*')
      .eq('product_id', productId);

    const platformLevels = (levels || []).map((l) => this.mapDbRowToLevel(l));

    // Find discrepancies
    const quantities = platformLevels.map((l) => l.quantity);
    const minQty = Math.min(...quantities);
    const maxQty = Math.max(...quantities);
    const discrepancies: Array<{ platforms: ConnectorName[]; difference: number }> = [];

    if (maxQty - minQty > 0) {
      discrepancies.push({
        platforms: platformLevels.map((l) => l.platform),
        difference: maxQty - minQty,
      });
    }

    return {
      productId,
      totalQuantity: minQty, // Use lowest for safety
      platformLevels,
      lastSyncAt: new Date(
        Math.max(...platformLevels.map((l) => l.updatedAt.getTime()))
      ),
      discrepancies,
    };
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private async getConnector(platform: ConnectorName): Promise<BaseConnector> {
    if (!this.connectors.has(platform)) {
      // Load credentials from database
      const { data: credentials } = await this.supabase
        .from('platform_credentials')
        .select('*')
        .eq('platform', platform)
        .single();

      if (!credentials) {
        throw new Error(`No credentials found for platform: ${platform}`);
      }

      const connector = createConnector(platform, {
        platform,
        credentials: credentials.credentials,
      });

      this.connectors.set(platform, connector);
    }

    return this.connectors.get(platform)!;
  }

  private async getInventoryLevel(
    productId: string,
    platform: ConnectorName,
    variantId?: string
  ): Promise<InventoryLevel | null> {
    let query = this.supabase
      .from('inventory_levels')
      .select('*')
      .eq('product_id', productId)
      .eq('platform', platform);

    if (variantId) {
      query = query.eq('variant_id', variantId);
    }

    const { data, error } = await query.single();

    if (error || !data) {
      return null;
    }

    return this.mapDbRowToLevel(data);
  }

  private async updatePlatformInventory(
    platform: ConnectorName,
    productId: string,
    variantId: string | undefined,
    quantity: number
  ): Promise<{ success: boolean; error?: SyncError }> {
    try {
      // Get external product ID
      const { data: mapping } = await this.supabase
        .from('product_platform_mappings')
        .select('external_id')
        .eq('product_id', productId)
        .eq('platform', platform)
        .single();

      if (!mapping?.external_id) {
        return {
          success: false,
          error: {
            code: 'PRODUCT_NOT_FOUND',
            message: `Product ${productId} not found on ${platform}`,
            platform,
            retryable: false,
          },
        };
      }

      const connector = await this.getConnector(platform);

      // Update product inventory via connector
      const result = await connector.updateProduct(mapping.external_id, {
        variants: variantId
          ? [{ id: variantId, title: '', price: 0, options: {}, inventoryQuantity: quantity }]
          : undefined,
      } as any);

      if (!result.success) {
        return {
          success: false,
          error: {
            code: result.error?.code || 'UPDATE_FAILED',
            message: result.error?.message || 'Failed to update inventory',
            platform,
            retryable: result.error?.retryable || false,
          },
        };
      }

      // Update local record
      await this.supabase
        .from('inventory_levels')
        .upsert({
          product_id: productId,
          platform,
          external_id: mapping.external_id,
          variant_id: variantId,
          quantity,
          available_quantity: quantity,
          updated_at: new Date().toISOString(),
        });

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'PLATFORM_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
          platform,
          retryable: true,
        },
      };
    }
  }

  private async updateLocalInventory(data: InventorySyncData): Promise<void> {
    await this.supabase.from('inventory_levels').upsert({
      product_id: data.productId,
      platform: 'local',
      variant_id: data.variantId,
      sku: data.sku,
      quantity: data.quantity,
      reserved_quantity: data.reservedQuantity || 0,
      available_quantity: data.availableQuantity || data.quantity,
      low_stock_threshold: data.lowStockThreshold || this.lowStockThreshold,
      track_inventory: data.trackInventory,
      updated_at: new Date().toISOString(),
    });
  }

  private async logInventoryChange(
    productId: string,
    platform: ConnectorName,
    previousQty: number,
    newQty: number,
    adjustment: number,
    reason?: string
  ): Promise<void> {
    await this.supabase.from('inventory_change_log').insert({
      product_id: productId,
      platform,
      previous_quantity: previousQty,
      new_quantity: newQty,
      adjustment,
      reason,
      created_at: new Date().toISOString(),
    });
  }

  private async triggerLowStockAlert(
    productId: string,
    platform: ConnectorName,
    quantity: number
  ): Promise<void> {
    // Get product details
    const { data: product } = await this.supabase
      .from('products')
      .select('title')
      .eq('id', productId)
      .single();

    await this.supabase.from('sync_alerts').insert({
      type: 'low_stock',
      severity: quantity === 0 ? 'critical' : 'warning',
      platform,
      message: `Low stock alert: ${product?.title || productId} has ${quantity} units on ${platform}`,
      details: {
        product_id: productId,
        quantity,
        threshold: this.lowStockThreshold,
      },
      acknowledged: false,
      created_at: new Date().toISOString(),
    });
  }

  private mapDbRowToLevel(row: Record<string, unknown>): InventoryLevel {
    return {
      productId: row.product_id as string,
      platform: row.platform as ConnectorName,
      externalId: row.external_id as string,
      variantId: row.variant_id as string | undefined,
      sku: row.sku as string | undefined,
      quantity: row.quantity as number,
      reservedQuantity: row.reserved_quantity as number,
      availableQuantity: row.available_quantity as number,
      lowStockThreshold: row.low_stock_threshold as number,
      trackInventory: row.track_inventory as boolean,
      updatedAt: new Date(row.updated_at as string),
    };
  }
}

export default InventorySyncStrategy;
