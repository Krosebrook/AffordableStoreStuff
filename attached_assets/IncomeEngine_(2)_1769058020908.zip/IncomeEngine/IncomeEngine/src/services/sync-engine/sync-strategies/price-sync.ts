/**
 * Price Sync Strategy
 * Handles real-time price synchronization across platforms
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  SyncJob,
  SyncResult,
  SyncError,
  PriceSyncData,
  PlatformSyncResult,
  Conflict,
} from '../types';
import { ConnectorName, createConnector, BaseConnector } from '../../../connectors/index';
import { ConflictResolver } from '../conflict-resolver';

// ============================================================================
// Types
// ============================================================================

export interface PriceRecord {
  productId: string;
  platform: ConnectorName;
  externalId: string;
  variantId?: string;
  price: number;
  compareAtPrice?: number;
  currency: string;
  costPerItem?: number;
  marginPercent?: number;
  minPrice?: number;
  maxPrice?: number;
  autoAdjust: boolean;
  updatedAt: Date;
}

export interface PriceRule {
  id: string;
  name: string;
  type: 'fixed' | 'markup' | 'margin' | 'competitive' | 'dynamic';
  value: number;
  currency?: string;
  platforms: ConnectorName[];
  productTypes?: string[];
  enabled: boolean;
  priority: number;
}

export interface PriceSyncResult {
  success: boolean;
  platform: ConnectorName;
  previousPrice: number;
  newPrice: number;
  currency: string;
  conflict?: Conflict;
  error?: SyncError;
}

// ============================================================================
// Price Sync Strategy Class
// ============================================================================

export class PriceSyncStrategy {
  private supabase: SupabaseClient;
  private conflictResolver: ConflictResolver;
  private connectors: Map<ConnectorName, BaseConnector>;
  private priceRules: PriceRule[];
  private defaultCurrency: string;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    conflictResolver: ConflictResolver,
    options: {
      defaultCurrency?: string;
      priceRules?: PriceRule[];
    } = {}
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.conflictResolver = conflictResolver;
    this.connectors = new Map();
    this.priceRules = options.priceRules || [];
    this.defaultCurrency = options.defaultCurrency || 'USD';
  }

  /**
   * Execute price sync for a job
   */
  async execute(job: SyncJob): Promise<SyncResult> {
    const startTime = Date.now();
    const priceData = job.data.price;

    if (!priceData) {
      return {
        success: false,
        syncedPlatforms: [],
        failedPlatforms: [],
        conflictsResolved: [],
        duration: Date.now() - startTime,
        timestamp: new Date(),
      };
    }

    const syncedPlatforms: PlatformSyncResult[] = [];
    const failedPlatforms: PlatformSyncResult[] = [];
    const conflictsResolved: Conflict['resolution'][] = [];

    // Sync to each target platform
    for (const targetPlatform of job.targetPlatforms) {
      const platformStartTime = Date.now();

      try {
        // Get target current price
        const targetPrice = await this.getPriceRecord(
          priceData.productId,
          targetPlatform,
          priceData.variantId
        );

        // Apply platform-specific pricing rules
        const adjustedPrice = await this.applyPricingRules(
          priceData.price,
          targetPlatform,
          priceData.productId
        );

        // Detect conflicts
        const conflicts = await this.conflictResolver.detectConflicts(
          job,
          { price: adjustedPrice },
          { price: targetPrice?.price },
          targetPlatform
        );

        // Resolve conflicts
        let finalPrice = adjustedPrice;
        for (const conflict of conflicts) {
          const resolution = await this.conflictResolver.resolveConflict(conflict);
          if (resolution.resolvedValue !== undefined) {
            finalPrice = resolution.resolvedValue as number;
            conflictsResolved.push(resolution);
          }
        }

        // Validate price bounds
        if (targetPrice?.minPrice && finalPrice < targetPrice.minPrice) {
          finalPrice = targetPrice.minPrice;
        }
        if (targetPrice?.maxPrice && finalPrice > targetPrice.maxPrice) {
          finalPrice = targetPrice.maxPrice;
        }

        // Update target platform
        const result = await this.updatePlatformPrice(
          targetPlatform,
          priceData.productId,
          priceData.variantId,
          finalPrice,
          priceData.compareAtPrice,
          priceData.currency
        );

        if (result.success) {
          syncedPlatforms.push({
            platform: targetPlatform,
            success: true,
            externalId: targetPrice?.externalId,
            previousValue: targetPrice?.price,
            newValue: finalPrice,
            duration: Date.now() - platformStartTime,
            retries: 0,
          });

          // Check for significant price change alert
          if (targetPrice) {
            const changePercent = Math.abs(
              ((finalPrice - targetPrice.price) / targetPrice.price) * 100
            );
            if (changePercent > 20) {
              await this.triggerPriceChangeAlert(
                priceData.productId,
                targetPlatform,
                targetPrice.price,
                finalPrice,
                changePercent
              );
            }
          }
        } else {
          failedPlatforms.push({
            platform: targetPlatform,
            success: false,
            error: result.error,
            duration: Date.now() - platformStartTime,
            retries: 0,
          });
        }
      } catch (error) {
        failedPlatforms.push({
          platform: targetPlatform,
          success: false,
          error: {
            code: 'SYNC_ERROR',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
          duration: Date.now() - platformStartTime,
          retries: 0,
        });
      }
    }

    // Update local price record
    await this.updateLocalPrice(priceData);

    return {
      success: failedPlatforms.length === 0,
      syncedPlatforms,
      failedPlatforms,
      conflictsResolved: conflictsResolved.filter(Boolean) as Conflict['resolution'][],
      duration: Date.now() - startTime,
      timestamp: new Date(),
    };
  }

  /**
   * Get unified price view across platforms
   */
  async getUnifiedPricing(
    productId: string
  ): Promise<{
    productId: string;
    basePrice: number;
    currency: string;
    platformPrices: PriceRecord[];
    lastSyncAt: Date;
    discrepancies: Array<{
      platform: ConnectorName;
      price: number;
      difference: number;
    }>;
  }> {
    const { data: prices } = await this.supabase
      .from('price_records')
      .select('*')
      .eq('product_id', productId);

    const platformPrices = (prices || []).map((p) => this.mapDbRowToPrice(p));

    // Find base price (from source/primary platform or average)
    const basePrice = platformPrices.length > 0
      ? platformPrices.reduce((sum, p) => sum + p.price, 0) / platformPrices.length
      : 0;

    // Find discrepancies
    const discrepancies = platformPrices
      .map((p) => ({
        platform: p.platform,
        price: p.price,
        difference: p.price - basePrice,
      }))
      .filter((d) => Math.abs(d.difference) > 0.01);

    return {
      productId,
      basePrice,
      currency: platformPrices[0]?.currency || this.defaultCurrency,
      platformPrices,
      lastSyncAt: new Date(
        Math.max(...platformPrices.map((p) => p.updatedAt.getTime()))
      ),
      discrepancies,
    };
  }

  /**
   * Apply bulk price update across platforms
   */
  async bulkPriceUpdate(
    updates: Array<{
      productId: string;
      variantId?: string;
      price: number;
      compareAtPrice?: number;
    }>,
    platforms: ConnectorName[]
  ): Promise<Map<string, PriceSyncResult[]>> {
    const results = new Map<string, PriceSyncResult[]>();

    for (const update of updates) {
      const productResults: PriceSyncResult[] = [];

      for (const platform of platforms) {
        try {
          const currentPrice = await this.getPriceRecord(
            update.productId,
            platform,
            update.variantId
          );

          const adjustedPrice = await this.applyPricingRules(
            update.price,
            platform,
            update.productId
          );

          const result = await this.updatePlatformPrice(
            platform,
            update.productId,
            update.variantId,
            adjustedPrice,
            update.compareAtPrice,
            this.defaultCurrency
          );

          productResults.push({
            success: result.success,
            platform,
            previousPrice: currentPrice?.price || 0,
            newPrice: adjustedPrice,
            currency: this.defaultCurrency,
            error: result.error,
          });
        } catch (error) {
          productResults.push({
            success: false,
            platform,
            previousPrice: 0,
            newPrice: update.price,
            currency: this.defaultCurrency,
            error: {
              code: 'BULK_UPDATE_FAILED',
              message: error instanceof Error ? error.message : 'Unknown error',
              retryable: true,
            },
          });
        }
      }

      results.set(update.productId, productResults);
    }

    return results;
  }

  /**
   * Calculate profit margin
   */
  calculateMargin(
    price: number,
    costPerItem: number
  ): { margin: number; marginPercent: number } {
    const margin = price - costPerItem;
    const marginPercent = costPerItem > 0 ? (margin / price) * 100 : 0;
    return { margin, marginPercent };
  }

  // ============================================================================
  // Price Rules Management
  // ============================================================================

  /**
   * Add a pricing rule
   */
  addPriceRule(rule: PriceRule): void {
    this.priceRules.push(rule);
    this.priceRules.sort((a, b) => b.priority - a.priority);
  }

  /**
   * Remove a pricing rule
   */
  removePriceRule(ruleId: string): boolean {
    const index = this.priceRules.findIndex((r) => r.id === ruleId);
    if (index !== -1) {
      this.priceRules.splice(index, 1);
      return true;
    }
    return false;
  }

  /**
   * Apply pricing rules to a base price
   */
  private async applyPricingRules(
    basePrice: number,
    platform: ConnectorName,
    productId: string
  ): Promise<number> {
    let price = basePrice;

    // Get product details for rule matching
    const { data: product } = await this.supabase
      .from('products')
      .select('product_type, cost_per_item')
      .eq('id', productId)
      .single();

    for (const rule of this.priceRules) {
      if (!rule.enabled) continue;
      if (!rule.platforms.includes(platform)) continue;
      if (rule.productTypes && product && !rule.productTypes.includes(product.product_type)) {
        continue;
      }

      switch (rule.type) {
        case 'fixed':
          price = rule.value;
          break;
        case 'markup':
          price = basePrice * (1 + rule.value / 100);
          break;
        case 'margin':
          if (product?.cost_per_item) {
            price = product.cost_per_item / (1 - rule.value / 100);
          }
          break;
        case 'competitive':
          // Would fetch competitor prices and adjust
          price = basePrice * (1 + rule.value / 100);
          break;
        case 'dynamic':
          // Would apply dynamic pricing based on demand
          price = basePrice;
          break;
      }
    }

    // Round to 2 decimal places
    return Math.round(price * 100) / 100;
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private async getConnector(platform: ConnectorName): Promise<BaseConnector> {
    if (!this.connectors.has(platform)) {
      const { data: credentials } = await this.supabase
        .from('platform_credentials')
        .select('*')
        .eq('platform', platform)
        .single();

      if (!credentials) {
        throw new Error(`No credentials found for platform: ${platform}`);
      }

      const connector = createConnector(platform, {
        platform,
        credentials: credentials.credentials,
      });

      this.connectors.set(platform, connector);
    }

    return this.connectors.get(platform)!;
  }

  private async getPriceRecord(
    productId: string,
    platform: ConnectorName,
    variantId?: string
  ): Promise<PriceRecord | null> {
    let query = this.supabase
      .from('price_records')
      .select('*')
      .eq('product_id', productId)
      .eq('platform', platform);

    if (variantId) {
      query = query.eq('variant_id', variantId);
    }

    const { data, error } = await query.single();

    if (error || !data) {
      return null;
    }

    return this.mapDbRowToPrice(data);
  }

  private async updatePlatformPrice(
    platform: ConnectorName,
    productId: string,
    variantId: string | undefined,
    price: number,
    compareAtPrice: number | undefined,
    currency: string
  ): Promise<{ success: boolean; error?: SyncError }> {
    try {
      // Get external product ID
      const { data: mapping } = await this.supabase
        .from('product_platform_mappings')
        .select('external_id')
        .eq('product_id', productId)
        .eq('platform', platform)
        .single();

      if (!mapping?.external_id) {
        return {
          success: false,
          error: {
            code: 'PRODUCT_NOT_FOUND',
            message: `Product ${productId} not found on ${platform}`,
            platform,
            retryable: false,
          },
        };
      }

      const connector = await this.getConnector(platform);

      // Update product price via connector
      const result = await connector.updateProduct(mapping.external_id, {
        pricing: {
          price,
          compareAtPrice,
          currency,
          taxable: true,
        },
      } as any);

      if (!result.success) {
        return {
          success: false,
          error: {
            code: result.error?.code || 'UPDATE_FAILED',
            message: result.error?.message || 'Failed to update price',
            platform,
            retryable: result.error?.retryable || false,
          },
        };
      }

      // Update local record
      await this.supabase
        .from('price_records')
        .upsert({
          product_id: productId,
          platform,
          external_id: mapping.external_id,
          variant_id: variantId,
          price,
          compare_at_price: compareAtPrice,
          currency,
          updated_at: new Date().toISOString(),
        });

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'PLATFORM_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
          platform,
          retryable: true,
        },
      };
    }
  }

  private async updateLocalPrice(data: PriceSyncData): Promise<void> {
    await this.supabase.from('price_records').upsert({
      product_id: data.productId,
      platform: 'local',
      variant_id: data.variantId,
      price: data.price,
      previous_price: data.previousPrice,
      compare_at_price: data.compareAtPrice,
      currency: data.currency,
      cost_per_item: data.costPerItem,
      margin_percent: data.marginPercent,
      updated_at: new Date().toISOString(),
    });
  }

  private async triggerPriceChangeAlert(
    productId: string,
    platform: ConnectorName,
    previousPrice: number,
    newPrice: number,
    changePercent: number
  ): Promise<void> {
    const { data: product } = await this.supabase
      .from('products')
      .select('title')
      .eq('id', productId)
      .single();

    await this.supabase.from('sync_alerts').insert({
      type: 'price_change',
      severity: changePercent > 50 ? 'critical' : 'warning',
      platform,
      message: `Significant price change: ${product?.title || productId} changed from $${previousPrice} to $${newPrice} (${changePercent.toFixed(1)}%)`,
      details: {
        product_id: productId,
        previous_price: previousPrice,
        new_price: newPrice,
        change_percent: changePercent,
      },
      acknowledged: false,
      created_at: new Date().toISOString(),
    });
  }

  private mapDbRowToPrice(row: Record<string, unknown>): PriceRecord {
    return {
      productId: row.product_id as string,
      platform: row.platform as ConnectorName,
      externalId: row.external_id as string,
      variantId: row.variant_id as string | undefined,
      price: row.price as number,
      compareAtPrice: row.compare_at_price as number | undefined,
      currency: row.currency as string,
      costPerItem: row.cost_per_item as number | undefined,
      marginPercent: row.margin_percent as number | undefined,
      minPrice: row.min_price as number | undefined,
      maxPrice: row.max_price as number | undefined,
      autoAdjust: row.auto_adjust as boolean,
      updatedAt: new Date(row.updated_at as string),
    };
  }
}

export default PriceSyncStrategy;
