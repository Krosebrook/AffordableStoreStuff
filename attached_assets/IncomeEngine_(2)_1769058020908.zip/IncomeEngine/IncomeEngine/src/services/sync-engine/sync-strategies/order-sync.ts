/**
 * Order Sync Strategy
 * Handles real-time order status synchronization across platforms
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  SyncJob,
  SyncResult,
  SyncError,
  OrderSyncData,
  PlatformSyncResult,
  Conflict,
} from '../types';
import { ConnectorName, createConnector, BaseConnector } from '../../../connectors/index';
import { Order, OrderStatus, TrackingInfo } from '../../../connectors/core/types';
import { ConflictResolver } from '../conflict-resolver';

// ============================================================================
// Types
// ============================================================================

export interface UnifiedOrder extends Order {
  sourceOrders: PlatformOrder[];
  fulfillmentStatus: 'unfulfilled' | 'partially_fulfilled' | 'fulfilled';
  syncStatus: 'synced' | 'pending' | 'conflict' | 'error';
  lastSyncAt: Date;
}

export interface PlatformOrder {
  platform: ConnectorName;
  externalOrderId: string;
  status: OrderStatus;
  trackingInfo?: TrackingInfo;
  updatedAt: Date;
}

export interface OrderSyncResult {
  success: boolean;
  platform: ConnectorName;
  orderId: string;
  previousStatus: OrderStatus;
  newStatus: OrderStatus;
  trackingUpdated: boolean;
  conflict?: Conflict;
  error?: SyncError;
}

// Status transition validation
const VALID_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending: ['processing', 'cancelled'],
  processing: ['shipped', 'cancelled'],
  shipped: ['delivered', 'cancelled'],
  delivered: [],
  cancelled: [],
  refunded: [],
};

// ============================================================================
// Order Sync Strategy Class
// ============================================================================

export class OrderSyncStrategy {
  private supabase: SupabaseClient;
  private conflictResolver: ConflictResolver;
  private connectors: Map<ConnectorName, BaseConnector>;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    conflictResolver: ConflictResolver
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.conflictResolver = conflictResolver;
    this.connectors = new Map();
  }

  /**
   * Execute order sync for a job
   */
  async execute(job: SyncJob): Promise<SyncResult> {
    const startTime = Date.now();
    const orderData = job.data.order;

    if (!orderData) {
      return {
        success: false,
        syncedPlatforms: [],
        failedPlatforms: [],
        conflictsResolved: [],
        duration: Date.now() - startTime,
        timestamp: new Date(),
      };
    }

    const syncedPlatforms: PlatformSyncResult[] = [];
    const failedPlatforms: PlatformSyncResult[] = [];
    const conflictsResolved: Conflict['resolution'][] = [];

    // Sync to each target platform
    for (const targetPlatform of job.targetPlatforms) {
      const platformStartTime = Date.now();

      try {
        // Get target current order status
        const targetOrder = await this.getPlatformOrder(
          orderData.orderId,
          targetPlatform
        );

        // Validate status transition
        if (targetOrder && !this.isValidTransition(targetOrder.status, orderData.status)) {
          failedPlatforms.push({
            platform: targetPlatform,
            success: false,
            error: {
              code: 'INVALID_TRANSITION',
              message: `Cannot transition from ${targetOrder.status} to ${orderData.status}`,
              platform: targetPlatform,
              retryable: false,
            },
            duration: Date.now() - platformStartTime,
            retries: 0,
          });
          continue;
        }

        // Detect conflicts
        const conflicts = await this.conflictResolver.detectConflicts(
          job,
          { status: orderData.status },
          { status: targetOrder?.status },
          targetPlatform
        );

        // Resolve conflicts
        let finalStatus = orderData.status;
        for (const conflict of conflicts) {
          const resolution = await this.conflictResolver.resolveConflict(conflict);
          if (resolution.resolvedValue !== undefined) {
            finalStatus = resolution.resolvedValue as OrderStatus;
            conflictsResolved.push(resolution);
          }
        }

        // Update target platform
        const result = await this.updatePlatformOrderStatus(
          targetPlatform,
          orderData.orderId,
          finalStatus,
          orderData.trackingNumber && orderData.carrier
            ? {
                carrier: orderData.carrier,
                trackingNumber: orderData.trackingNumber,
                trackingUrl: orderData.trackingUrl,
                shippedAt: orderData.shippedAt,
              }
            : undefined
        );

        if (result.success) {
          syncedPlatforms.push({
            platform: targetPlatform,
            success: true,
            externalId: targetOrder?.externalOrderId,
            previousValue: targetOrder?.status,
            newValue: finalStatus,
            duration: Date.now() - platformStartTime,
            retries: 0,
          });
        } else {
          failedPlatforms.push({
            platform: targetPlatform,
            success: false,
            error: result.error,
            duration: Date.now() - platformStartTime,
            retries: 0,
          });
        }
      } catch (error) {
        failedPlatforms.push({
          platform: targetPlatform,
          success: false,
          error: {
            code: 'SYNC_ERROR',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
          duration: Date.now() - platformStartTime,
          retries: 0,
        });
      }
    }

    // Update local order record
    await this.updateLocalOrder(orderData);

    return {
      success: failedPlatforms.length === 0,
      syncedPlatforms,
      failedPlatforms,
      conflictsResolved: conflictsResolved.filter(Boolean) as Conflict['resolution'][],
      duration: Date.now() - startTime,
      timestamp: new Date(),
    };
  }

  /**
   * Pull orders from all connected platforms
   */
  async pullOrders(
    platforms: ConnectorName[],
    options: {
      since?: Date;
      status?: OrderStatus[];
      limit?: number;
    } = {}
  ): Promise<UnifiedOrder[]> {
    const allOrders = new Map<string, UnifiedOrder>();

    for (const platform of platforms) {
      try {
        const connector = await this.getConnector(platform);
        const result = await connector.listOrders({
          limit: options.limit || 100,
          filters: {
            since: options.since?.toISOString(),
            status: options.status,
          },
        });

        if (result.success && result.data) {
          for (const order of result.data.items) {
            // Try to match with existing unified order
            const existingOrder = await this.findMatchingOrder(order, platform);

            if (existingOrder) {
              // Update existing unified order
              const unified = allOrders.get(existingOrder.id) || existingOrder;
              unified.sourceOrders.push({
                platform,
                externalOrderId: order.externalId,
                status: order.status,
                updatedAt: order.updatedAt,
              });
              allOrders.set(existingOrder.id, unified);
            } else {
              // Create new unified order
              const unified = this.createUnifiedOrder(order, platform);
              allOrders.set(unified.id, unified);
            }
          }
        }
      } catch (error) {
        console.error(`Failed to pull orders from ${platform}:`, error);
      }
    }

    return Array.from(allOrders.values());
  }

  /**
   * Get unified order view
   */
  async getUnifiedOrder(orderId: string): Promise<UnifiedOrder | null> {
    const { data: order } = await this.supabase
      .from('unified_orders')
      .select('*, platform_orders(*)')
      .eq('id', orderId)
      .single();

    if (!order) return null;

    return this.mapDbRowToUnifiedOrder(order);
  }

  /**
   * Update order fulfillment with tracking
   */
  async fulfillOrder(
    orderId: string,
    tracking: TrackingInfo,
    platforms?: ConnectorName[]
  ): Promise<Map<ConnectorName, OrderSyncResult>> {
    const results = new Map<ConnectorName, OrderSyncResult>();

    // Get unified order
    const order = await this.getUnifiedOrder(orderId);
    if (!order) {
      throw new Error(`Order not found: ${orderId}`);
    }

    const targetPlatforms = platforms || order.sourceOrders.map((o) => o.platform);

    for (const platform of targetPlatforms) {
      const platformOrder = order.sourceOrders.find((o) => o.platform === platform);
      if (!platformOrder) continue;

      try {
        const result = await this.updatePlatformOrderStatus(
          platform,
          orderId,
          'shipped',
          tracking
        );

        results.set(platform, {
          success: result.success,
          platform,
          orderId,
          previousStatus: platformOrder.status,
          newStatus: 'shipped',
          trackingUpdated: true,
          error: result.error,
        });
      } catch (error) {
        results.set(platform, {
          success: false,
          platform,
          orderId,
          previousStatus: platformOrder.status,
          newStatus: 'shipped',
          trackingUpdated: false,
          error: {
            code: 'FULFILL_FAILED',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
        });
      }
    }

    // Update local order
    await this.supabase
      .from('unified_orders')
      .update({
        status: 'shipped',
        tracking_info: tracking,
        fulfillment_status: 'fulfilled',
        updated_at: new Date().toISOString(),
      })
      .eq('id', orderId);

    return results;
  }

  /**
   * Cancel order across platforms
   */
  async cancelOrder(
    orderId: string,
    reason: string,
    platforms?: ConnectorName[]
  ): Promise<Map<ConnectorName, OrderSyncResult>> {
    const results = new Map<ConnectorName, OrderSyncResult>();

    const order = await this.getUnifiedOrder(orderId);
    if (!order) {
      throw new Error(`Order not found: ${orderId}`);
    }

    const targetPlatforms = platforms || order.sourceOrders.map((o) => o.platform);

    for (const platform of targetPlatforms) {
      const platformOrder = order.sourceOrders.find((o) => o.platform === platform);
      if (!platformOrder) continue;

      // Validate cancellation is possible
      if (!this.isValidTransition(platformOrder.status, 'cancelled')) {
        results.set(platform, {
          success: false,
          platform,
          orderId,
          previousStatus: platformOrder.status,
          newStatus: 'cancelled',
          trackingUpdated: false,
          error: {
            code: 'INVALID_TRANSITION',
            message: `Cannot cancel order in ${platformOrder.status} status`,
            retryable: false,
          },
        });
        continue;
      }

      try {
        const result = await this.updatePlatformOrderStatus(
          platform,
          orderId,
          'cancelled'
        );

        results.set(platform, {
          success: result.success,
          platform,
          orderId,
          previousStatus: platformOrder.status,
          newStatus: 'cancelled',
          trackingUpdated: false,
          error: result.error,
        });
      } catch (error) {
        results.set(platform, {
          success: false,
          platform,
          orderId,
          previousStatus: platformOrder.status,
          newStatus: 'cancelled',
          trackingUpdated: false,
          error: {
            code: 'CANCEL_FAILED',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
        });
      }
    }

    // Update local order
    await this.supabase
      .from('unified_orders')
      .update({
        status: 'cancelled',
        cancellation_reason: reason,
        updated_at: new Date().toISOString(),
      })
      .eq('id', orderId);

    return results;
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private async getConnector(platform: ConnectorName): Promise<BaseConnector> {
    if (!this.connectors.has(platform)) {
      const { data: credentials } = await this.supabase
        .from('platform_credentials')
        .select('*')
        .eq('platform', platform)
        .single();

      if (!credentials) {
        throw new Error(`No credentials found for platform: ${platform}`);
      }

      const connector = createConnector(platform, {
        platform,
        credentials: credentials.credentials,
      });

      this.connectors.set(platform, connector);
    }

    return this.connectors.get(platform)!;
  }

  private async getPlatformOrder(
    orderId: string,
    platform: ConnectorName
  ): Promise<PlatformOrder | null> {
    const { data, error } = await this.supabase
      .from('platform_orders')
      .select('*')
      .eq('unified_order_id', orderId)
      .eq('platform', platform)
      .single();

    if (error || !data) {
      return null;
    }

    return {
      platform: data.platform as ConnectorName,
      externalOrderId: data.external_order_id as string,
      status: data.status as OrderStatus,
      trackingInfo: data.tracking_info as TrackingInfo | undefined,
      updatedAt: new Date(data.updated_at as string),
    };
  }

  private async updatePlatformOrderStatus(
    platform: ConnectorName,
    orderId: string,
    status: OrderStatus,
    tracking?: TrackingInfo
  ): Promise<{ success: boolean; error?: SyncError }> {
    try {
      // Get platform order mapping
      const { data: mapping } = await this.supabase
        .from('platform_orders')
        .select('external_order_id')
        .eq('unified_order_id', orderId)
        .eq('platform', platform)
        .single();

      if (!mapping?.external_order_id) {
        return {
          success: false,
          error: {
            code: 'ORDER_NOT_FOUND',
            message: `Order ${orderId} not found on ${platform}`,
            platform,
            retryable: false,
          },
        };
      }

      const connector = await this.getConnector(platform);

      // Update order status
      if (status === 'shipped' && tracking) {
        const result = await connector.fulfillOrder(mapping.external_order_id, tracking);
        if (!result.success) {
          return {
            success: false,
            error: {
              code: result.error?.code || 'FULFILL_FAILED',
              message: result.error?.message || 'Failed to fulfill order',
              platform,
              retryable: result.error?.retryable || false,
            },
          };
        }
      }

      // Update local record
      await this.supabase
        .from('platform_orders')
        .update({
          status,
          tracking_info: tracking,
          updated_at: new Date().toISOString(),
        })
        .eq('unified_order_id', orderId)
        .eq('platform', platform);

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'PLATFORM_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
          platform,
          retryable: true,
        },
      };
    }
  }

  private async updateLocalOrder(data: OrderSyncData): Promise<void> {
    await this.supabase.from('unified_orders').upsert({
      id: data.orderId,
      status: data.status,
      previous_status: data.previousStatus,
      tracking_number: data.trackingNumber,
      tracking_url: data.trackingUrl,
      carrier: data.carrier,
      shipped_at: data.shippedAt?.toISOString(),
      delivered_at: data.deliveredAt?.toISOString(),
      notes: data.notes,
      updated_at: new Date().toISOString(),
    });
  }

  private async findMatchingOrder(
    order: Order,
    platform: ConnectorName
  ): Promise<UnifiedOrder | null> {
    // Try to find by external ID first
    const { data: existing } = await this.supabase
      .from('platform_orders')
      .select('unified_order_id')
      .eq('external_order_id', order.externalId)
      .eq('platform', platform)
      .single();

    if (existing?.unified_order_id) {
      return this.getUnifiedOrder(existing.unified_order_id);
    }

    // Could also try matching by customer email, items, etc.
    return null;
  }

  private createUnifiedOrder(order: Order, platform: ConnectorName): UnifiedOrder {
    return {
      ...order,
      sourceOrders: [
        {
          platform,
          externalOrderId: order.externalId,
          status: order.status,
          updatedAt: order.updatedAt,
        },
      ],
      fulfillmentStatus: order.status === 'delivered' ? 'fulfilled' : 'unfulfilled',
      syncStatus: 'synced',
      lastSyncAt: new Date(),
    };
  }

  private isValidTransition(currentStatus: OrderStatus, newStatus: OrderStatus): boolean {
    const validNextStatuses = VALID_STATUS_TRANSITIONS[currentStatus] || [];
    return validNextStatuses.includes(newStatus);
  }

  private mapDbRowToUnifiedOrder(row: Record<string, unknown>): UnifiedOrder {
    const platformOrders = (row.platform_orders as Array<Record<string, unknown>> || []).map(
      (po) => ({
        platform: po.platform as ConnectorName,
        externalOrderId: po.external_order_id as string,
        status: po.status as OrderStatus,
        trackingInfo: po.tracking_info as TrackingInfo | undefined,
        updatedAt: new Date(po.updated_at as string),
      })
    );

    return {
      id: row.id as string,
      externalId: row.external_id as string,
      status: row.status as OrderStatus,
      items: row.items as Order['items'],
      shippingAddress: row.shipping_address as Order['shippingAddress'],
      subtotal: row.subtotal as number,
      shippingCost: row.shipping_cost as number,
      tax: row.tax as number,
      total: row.total as number,
      currency: row.currency as string,
      createdAt: new Date(row.created_at as string),
      updatedAt: new Date(row.updated_at as string),
      sourceOrders: platformOrders,
      fulfillmentStatus: row.fulfillment_status as UnifiedOrder['fulfillmentStatus'],
      syncStatus: row.sync_status as UnifiedOrder['syncStatus'],
      lastSyncAt: new Date(row.last_sync_at as string),
    };
  }
}

export default OrderSyncStrategy;
