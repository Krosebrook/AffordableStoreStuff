/**
 * Product Sync Strategy
 * Handles product data synchronization across platforms
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  SyncJob,
  SyncResult,
  SyncError,
  ProductSyncData,
  PlatformSyncResult,
  Conflict,
} from '../types';
import { ConnectorName, createConnector, BaseConnector } from '../../../connectors/index';
import { NormalizedProduct, ProductInput, ProductStatus } from '../../../connectors/core/types';
import { ConflictResolver } from '../conflict-resolver';

// ============================================================================
// Types
// ============================================================================

export interface ProductMapping {
  productId: string;
  platform: ConnectorName;
  externalId: string;
  externalUrl?: string;
  status: ProductStatus;
  syncEnabled: boolean;
  lastSyncAt: Date;
  syncFields: string[];
}

export interface ProductSyncResult {
  success: boolean;
  platform: ConnectorName;
  productId: string;
  externalId?: string;
  action: 'created' | 'updated' | 'skipped';
  updatedFields: string[];
  conflict?: Conflict;
  error?: SyncError;
}

// Fields that can be synced
const SYNCABLE_FIELDS = [
  'title',
  'description',
  'images',
  'variants',
  'pricing',
  'tags',
  'status',
  'metadata',
];

// ============================================================================
// Product Sync Strategy Class
// ============================================================================

export class ProductSyncStrategy {
  private supabase: SupabaseClient;
  private conflictResolver: ConflictResolver;
  private connectors: Map<ConnectorName, BaseConnector>;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    conflictResolver: ConflictResolver
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.conflictResolver = conflictResolver;
    this.connectors = new Map();
  }

  /**
   * Execute product sync for a job
   */
  async execute(job: SyncJob): Promise<SyncResult> {
    const startTime = Date.now();
    const productData = job.data.product;

    if (!productData) {
      return {
        success: false,
        syncedPlatforms: [],
        failedPlatforms: [],
        conflictsResolved: [],
        duration: Date.now() - startTime,
        timestamp: new Date(),
      };
    }

    const syncedPlatforms: PlatformSyncResult[] = [];
    const failedPlatforms: PlatformSyncResult[] = [];
    const conflictsResolved: Conflict['resolution'][] = [];

    // Get source product
    const sourceProduct = await this.getProduct(productData.productId);
    if (!sourceProduct) {
      return {
        success: false,
        syncedPlatforms: [],
        failedPlatforms: [
          {
            platform: job.sourcePlatform,
            success: false,
            error: {
              code: 'PRODUCT_NOT_FOUND',
              message: `Source product ${productData.productId} not found`,
              retryable: false,
            },
            duration: 0,
            retries: 0,
          },
        ],
        conflictsResolved: [],
        duration: Date.now() - startTime,
        timestamp: new Date(),
      };
    }

    // Sync to each target platform
    for (const targetPlatform of job.targetPlatforms) {
      const platformStartTime = Date.now();

      try {
        // Get target platform mapping
        const mapping = await this.getProductMapping(productData.productId, targetPlatform);

        // Determine fields to sync
        const fieldsToSync = productData.fields.filter(
          (f) => SYNCABLE_FIELDS.includes(f)
        );

        if (mapping) {
          // Update existing product
          const result = await this.updatePlatformProduct(
            targetPlatform,
            mapping,
            sourceProduct,
            productData.product,
            fieldsToSync,
            job
          );

          if (result.success) {
            syncedPlatforms.push({
              platform: targetPlatform,
              success: true,
              externalId: mapping.externalId,
              previousValue: result.previousValues,
              newValue: result.newValues,
              duration: Date.now() - platformStartTime,
              retries: 0,
            });

            if (result.conflictsResolved) {
              conflictsResolved.push(...result.conflictsResolved);
            }
          } else {
            failedPlatforms.push({
              platform: targetPlatform,
              success: false,
              error: result.error,
              duration: Date.now() - platformStartTime,
              retries: 0,
            });
          }
        } else if (productData.createIfMissing) {
          // Create new product on platform
          const result = await this.createPlatformProduct(
            targetPlatform,
            sourceProduct,
            productData.product
          );

          if (result.success) {
            syncedPlatforms.push({
              platform: targetPlatform,
              success: true,
              externalId: result.externalId,
              newValue: { action: 'created' },
              duration: Date.now() - platformStartTime,
              retries: 0,
            });
          } else {
            failedPlatforms.push({
              platform: targetPlatform,
              success: false,
              error: result.error,
              duration: Date.now() - platformStartTime,
              retries: 0,
            });
          }
        } else {
          // Skip - product doesn't exist and we're not creating
          syncedPlatforms.push({
            platform: targetPlatform,
            success: true,
            newValue: { action: 'skipped', reason: 'Product not on platform' },
            duration: Date.now() - platformStartTime,
            retries: 0,
          });
        }
      } catch (error) {
        failedPlatforms.push({
          platform: targetPlatform,
          success: false,
          error: {
            code: 'SYNC_ERROR',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
          duration: Date.now() - platformStartTime,
          retries: 0,
        });
      }
    }

    // Update local product sync status
    await this.updateSyncStatus(productData.productId, job.targetPlatforms);

    return {
      success: failedPlatforms.length === 0,
      syncedPlatforms,
      failedPlatforms,
      conflictsResolved: conflictsResolved.filter(Boolean) as Conflict['resolution'][],
      duration: Date.now() - startTime,
      timestamp: new Date(),
    };
  }

  /**
   * Get product mappings across platforms
   */
  async getProductMappings(productId: string): Promise<ProductMapping[]> {
    const { data, error } = await this.supabase
      .from('product_platform_mappings')
      .select('*')
      .eq('product_id', productId);

    if (error || !data) {
      return [];
    }

    return data.map((row) => this.mapDbRowToMapping(row));
  }

  /**
   * Create product on multiple platforms
   */
  async createOnPlatforms(
    productId: string,
    platforms: ConnectorName[],
    productInput?: Partial<ProductInput>
  ): Promise<Map<ConnectorName, ProductSyncResult>> {
    const results = new Map<ConnectorName, ProductSyncResult>();

    const sourceProduct = await this.getProduct(productId);
    if (!sourceProduct) {
      throw new Error(`Product not found: ${productId}`);
    }

    const mergedProduct = {
      ...sourceProduct,
      ...productInput,
    };

    for (const platform of platforms) {
      const result = await this.createPlatformProduct(
        platform,
        sourceProduct,
        mergedProduct
      );

      results.set(platform, {
        success: result.success,
        platform,
        productId,
        externalId: result.externalId,
        action: 'created',
        updatedFields: SYNCABLE_FIELDS,
        error: result.error,
      });
    }

    return results;
  }

  /**
   * Update product on multiple platforms
   */
  async updateOnPlatforms(
    productId: string,
    updates: Partial<ProductInput>,
    platforms?: ConnectorName[],
    fields?: string[]
  ): Promise<Map<ConnectorName, ProductSyncResult>> {
    const results = new Map<ConnectorName, ProductSyncResult>();

    // Get existing mappings
    const mappings = await this.getProductMappings(productId);
    const targetMappings = platforms
      ? mappings.filter((m) => platforms.includes(m.platform))
      : mappings;

    const fieldsToUpdate = fields?.filter((f) => SYNCABLE_FIELDS.includes(f)) || SYNCABLE_FIELDS;

    const sourceProduct = await this.getProduct(productId);
    if (!sourceProduct) {
      throw new Error(`Product not found: ${productId}`);
    }

    for (const mapping of targetMappings) {
      if (!mapping.syncEnabled) {
        results.set(mapping.platform, {
          success: true,
          platform: mapping.platform,
          productId,
          externalId: mapping.externalId,
          action: 'skipped',
          updatedFields: [],
        });
        continue;
      }

      try {
        const connector = await this.getConnector(mapping.platform);
        const platformUpdates = this.preparePlatformUpdates(
          updates,
          fieldsToUpdate,
          mapping.platform
        );

        const result = await connector.updateProduct(mapping.externalId, platformUpdates);

        if (result.success) {
          // Update mapping
          await this.updateProductMapping(mapping, {
            lastSyncAt: new Date(),
          });

          results.set(mapping.platform, {
            success: true,
            platform: mapping.platform,
            productId,
            externalId: mapping.externalId,
            action: 'updated',
            updatedFields: result.data?.updatedFields || fieldsToUpdate,
          });
        } else {
          results.set(mapping.platform, {
            success: false,
            platform: mapping.platform,
            productId,
            externalId: mapping.externalId,
            action: 'updated',
            updatedFields: [],
            error: {
              code: result.error?.code || 'UPDATE_FAILED',
              message: result.error?.message || 'Failed to update product',
              retryable: result.error?.retryable || false,
            },
          });
        }
      } catch (error) {
        results.set(mapping.platform, {
          success: false,
          platform: mapping.platform,
          productId,
          externalId: mapping.externalId,
          action: 'updated',
          updatedFields: [],
          error: {
            code: 'PLATFORM_ERROR',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
        });
      }
    }

    return results;
  }

  /**
   * Delete product from platforms
   */
  async deleteFromPlatforms(
    productId: string,
    platforms?: ConnectorName[]
  ): Promise<Map<ConnectorName, { success: boolean; error?: SyncError }>> {
    const results = new Map<ConnectorName, { success: boolean; error?: SyncError }>();

    const mappings = await this.getProductMappings(productId);
    const targetMappings = platforms
      ? mappings.filter((m) => platforms.includes(m.platform))
      : mappings;

    for (const mapping of targetMappings) {
      try {
        const connector = await this.getConnector(mapping.platform);
        const result = await connector.deleteProduct(mapping.externalId);

        if (result.success) {
          // Remove mapping
          await this.supabase
            .from('product_platform_mappings')
            .delete()
            .eq('product_id', productId)
            .eq('platform', mapping.platform);

          results.set(mapping.platform, { success: true });
        } else {
          results.set(mapping.platform, {
            success: false,
            error: {
              code: result.error?.code || 'DELETE_FAILED',
              message: result.error?.message || 'Failed to delete product',
              retryable: result.error?.retryable || false,
            },
          });
        }
      } catch (error) {
        results.set(mapping.platform, {
          success: false,
          error: {
            code: 'PLATFORM_ERROR',
            message: error instanceof Error ? error.message : 'Unknown error',
            retryable: true,
          },
        });
      }
    }

    return results;
  }

  /**
   * Compare product across platforms
   */
  async compareProduct(
    productId: string
  ): Promise<{
    productId: string;
    platforms: Array<{
      platform: ConnectorName;
      externalId: string;
      product: Partial<NormalizedProduct>;
      differences: string[];
    }>;
    lastCompareAt: Date;
  }> {
    const mappings = await this.getProductMappings(productId);
    const sourceProduct = await this.getProduct(productId);

    const platformData: Array<{
      platform: ConnectorName;
      externalId: string;
      product: Partial<NormalizedProduct>;
      differences: string[];
    }> = [];

    for (const mapping of mappings) {
      try {
        const connector = await this.getConnector(mapping.platform);
        const result = await connector.getProduct(mapping.externalId);

        if (result.success && result.data) {
          const differences = this.findDifferences(sourceProduct, result.data);
          platformData.push({
            platform: mapping.platform,
            externalId: mapping.externalId,
            product: result.data,
            differences,
          });
        }
      } catch (error) {
        console.error(`Failed to compare product on ${mapping.platform}:`, error);
      }
    }

    return {
      productId,
      platforms: platformData,
      lastCompareAt: new Date(),
    };
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private async getConnector(platform: ConnectorName): Promise<BaseConnector> {
    if (!this.connectors.has(platform)) {
      const { data: credentials } = await this.supabase
        .from('platform_credentials')
        .select('*')
        .eq('platform', platform)
        .single();

      if (!credentials) {
        throw new Error(`No credentials found for platform: ${platform}`);
      }

      const connector = createConnector(platform, {
        platform,
        credentials: credentials.credentials,
      });

      this.connectors.set(platform, connector);
    }

    return this.connectors.get(platform)!;
  }

  private async getProduct(productId: string): Promise<NormalizedProduct | null> {
    const { data, error } = await this.supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();

    if (error || !data) {
      return null;
    }

    return this.mapDbRowToProduct(data);
  }

  private async getProductMapping(
    productId: string,
    platform: ConnectorName
  ): Promise<ProductMapping | null> {
    const { data, error } = await this.supabase
      .from('product_platform_mappings')
      .select('*')
      .eq('product_id', productId)
      .eq('platform', platform)
      .single();

    if (error || !data) {
      return null;
    }

    return this.mapDbRowToMapping(data);
  }

  private async createPlatformProduct(
    platform: ConnectorName,
    sourceProduct: NormalizedProduct,
    productInput?: Partial<NormalizedProduct>
  ): Promise<{ success: boolean; externalId?: string; error?: SyncError }> {
    try {
      const connector = await this.getConnector(platform);

      // Prepare product input
      const input: ProductInput = {
        title: productInput?.title || sourceProduct.title,
        description: productInput?.description || sourceProduct.description,
        productType: productInput?.productType || sourceProduct.productType,
        images: (productInput?.images || sourceProduct.images).map((img) => ({
          url: img.url,
          alt: img.alt,
          position: img.position,
          isPrimary: img.isPrimary,
        })),
        variants: (productInput?.variants || sourceProduct.variants).map((v) => ({
          title: v.title,
          price: v.price,
          sku: v.sku,
          options: v.options,
          inventoryQuantity: v.inventoryQuantity,
        })),
        pricing: productInput?.pricing || sourceProduct.pricing,
        tags: productInput?.tags || sourceProduct.tags,
      };

      // Validate for platform
      const validation = connector.validateProductForPlatform(input);
      if (!validation.valid) {
        return {
          success: false,
          error: {
            code: 'VALIDATION_FAILED',
            message: validation.issues.map((i) => i.message).join('; '),
            platform,
            retryable: false,
            details: { issues: validation.issues },
          },
        };
      }

      const result = await connector.createProduct(validation.sanitizedProduct || input);

      if (result.success && result.data) {
        // Create mapping
        await this.supabase.from('product_platform_mappings').insert({
          product_id: sourceProduct.id,
          platform,
          external_id: result.data.externalId,
          external_url: result.data.externalUrl,
          status: result.data.status,
          sync_enabled: true,
          last_sync_at: new Date().toISOString(),
          sync_fields: SYNCABLE_FIELDS,
        });

        return { success: true, externalId: result.data.externalId };
      }

      return {
        success: false,
        error: {
          code: result.error?.code || 'CREATE_FAILED',
          message: result.error?.message || 'Failed to create product',
          platform,
          retryable: result.error?.retryable || false,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'PLATFORM_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
          platform,
          retryable: true,
        },
      };
    }
  }

  private async updatePlatformProduct(
    platform: ConnectorName,
    mapping: ProductMapping,
    sourceProduct: NormalizedProduct,
    productUpdates: Partial<NormalizedProduct>,
    fields: string[],
    job: SyncJob
  ): Promise<{
    success: boolean;
    previousValues?: Record<string, unknown>;
    newValues?: Record<string, unknown>;
    conflictsResolved?: Conflict['resolution'][];
    error?: SyncError;
  }> {
    try {
      const connector = await this.getConnector(platform);

      // Get current product from platform for conflict detection
      const currentResult = await connector.getProduct(mapping.externalId);
      const currentProduct = currentResult.data;

      // Prepare updates for specific fields
      const updates = this.preparePlatformUpdates(productUpdates, fields, platform);

      // Detect and resolve conflicts
      const conflictsResolved: Conflict['resolution'][] = [];
      if (currentProduct) {
        for (const field of fields) {
          const sourceValue = (productUpdates as any)[field] || (sourceProduct as any)[field];
          const targetValue = (currentProduct as any)[field];

          if (sourceValue !== undefined && this.valuesAreDifferent(sourceValue, targetValue)) {
            const conflicts = await this.conflictResolver.detectConflicts(
              job,
              { [field]: sourceValue },
              { [field]: targetValue },
              platform
            );

            for (const conflict of conflicts) {
              const resolution = await this.conflictResolver.resolveConflict(conflict);
              if (resolution.resolvedValue !== undefined) {
                (updates as any)[field] = resolution.resolvedValue;
                conflictsResolved.push(resolution);
              }
            }
          }
        }
      }

      const result = await connector.updateProduct(mapping.externalId, updates);

      if (result.success) {
        await this.updateProductMapping(mapping, {
          lastSyncAt: new Date(),
          status: 'active',
        });

        return {
          success: true,
          previousValues: currentProduct
            ? this.extractFields(currentProduct, fields)
            : undefined,
          newValues: this.extractFields(productUpdates as any, fields),
          conflictsResolved,
        };
      }

      return {
        success: false,
        error: {
          code: result.error?.code || 'UPDATE_FAILED',
          message: result.error?.message || 'Failed to update product',
          platform,
          retryable: result.error?.retryable || false,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: {
          code: 'PLATFORM_ERROR',
          message: error instanceof Error ? error.message : 'Unknown error',
          platform,
          retryable: true,
        },
      };
    }
  }

  private async updateProductMapping(
    mapping: ProductMapping,
    updates: Partial<ProductMapping>
  ): Promise<void> {
    await this.supabase
      .from('product_platform_mappings')
      .update({
        last_sync_at: updates.lastSyncAt?.toISOString(),
        status: updates.status,
        sync_fields: updates.syncFields,
        sync_enabled: updates.syncEnabled,
        updated_at: new Date().toISOString(),
      })
      .eq('product_id', mapping.productId)
      .eq('platform', mapping.platform);
  }

  private async updateSyncStatus(
    productId: string,
    platforms: ConnectorName[]
  ): Promise<void> {
    await this.supabase
      .from('products')
      .update({
        last_sync_at: new Date().toISOString(),
        synced_platforms: platforms,
      })
      .eq('id', productId);
  }

  private preparePlatformUpdates(
    updates: Partial<ProductInput>,
    fields: string[],
    _platform: ConnectorName
  ): Partial<ProductInput> {
    const filteredUpdates: Partial<ProductInput> = {};

    for (const field of fields) {
      if ((updates as any)[field] !== undefined) {
        (filteredUpdates as any)[field] = (updates as any)[field];
      }
    }

    return filteredUpdates;
  }

  private findDifferences(
    source: NormalizedProduct | null,
    target: Partial<NormalizedProduct>
  ): string[] {
    if (!source) return SYNCABLE_FIELDS;

    const differences: string[] = [];

    for (const field of SYNCABLE_FIELDS) {
      const sourceValue = (source as any)[field];
      const targetValue = (target as any)[field];

      if (this.valuesAreDifferent(sourceValue, targetValue)) {
        differences.push(field);
      }
    }

    return differences;
  }

  private valuesAreDifferent(a: unknown, b: unknown): boolean {
    if (a === b) return false;
    if (typeof a !== typeof b) return true;
    if (typeof a === 'object' && a !== null && b !== null) {
      return JSON.stringify(a) !== JSON.stringify(b);
    }
    return true;
  }

  private extractFields(
    obj: Record<string, unknown>,
    fields: string[]
  ): Record<string, unknown> {
    const result: Record<string, unknown> = {};
    for (const field of fields) {
      if (obj[field] !== undefined) {
        result[field] = obj[field];
      }
    }
    return result;
  }

  private mapDbRowToMapping(row: Record<string, unknown>): ProductMapping {
    return {
      productId: row.product_id as string,
      platform: row.platform as ConnectorName,
      externalId: row.external_id as string,
      externalUrl: row.external_url as string | undefined,
      status: row.status as ProductStatus,
      syncEnabled: row.sync_enabled as boolean,
      lastSyncAt: new Date(row.last_sync_at as string),
      syncFields: row.sync_fields as string[],
    };
  }

  private mapDbRowToProduct(row: Record<string, unknown>): NormalizedProduct {
    return {
      id: row.id as string,
      externalId: row.external_id as string | undefined,
      title: row.title as string,
      description: row.description as string,
      productType: row.product_type as NormalizedProduct['productType'],
      images: row.images as NormalizedProduct['images'],
      variants: row.variants as NormalizedProduct['variants'],
      pricing: row.pricing as NormalizedProduct['pricing'],
      tags: row.tags as string[],
      metadata: row.metadata as Record<string, unknown>,
      platformData: row.platform_data as Record<string, unknown>,
      status: row.status as ProductStatus,
      createdAt: new Date(row.created_at as string),
      updatedAt: new Date(row.updated_at as string),
    };
  }
}

export default ProductSyncStrategy;
