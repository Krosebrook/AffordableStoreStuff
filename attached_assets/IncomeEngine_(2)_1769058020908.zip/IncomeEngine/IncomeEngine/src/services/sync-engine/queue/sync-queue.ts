/**
 * Sync Queue
 * In-memory priority queue with persistent backing for sync jobs
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  SyncJob,
  SyncStatus,
  SyncPriority,
  QueuedSyncJob,
  QueueStats,
  SyncEvent,
  SyncEventType,
} from '../types';

// ============================================================================
// Types
// ============================================================================

interface QueueOptions {
  maxSize: number;
  processingConcurrency: number;
  pollingInterval: number;
  priorityWeights: Record<SyncPriority, number>;
}

type QueueEventHandler = (job: SyncJob) => Promise<void>;

// Default priority weights (higher = processed first)
const DEFAULT_PRIORITY_WEIGHTS: Record<SyncPriority, number> = {
  critical: 100,
  high: 75,
  normal: 50,
  low: 25,
};

// ============================================================================
// Sync Queue Class
// ============================================================================

export class SyncQueue extends EventEmitter {
  private supabase: SupabaseClient;
  private queue: QueuedSyncJob[];
  private processing: Set<string>;
  private options: QueueOptions;
  private isRunning: boolean;
  private pollingTimer: NodeJS.Timeout | null;
  private processHandler: QueueEventHandler | null;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    options: Partial<QueueOptions> = {}
  ) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.queue = [];
    this.processing = new Set();
    this.options = {
      maxSize: options.maxSize || 1000,
      processingConcurrency: options.processingConcurrency || 5,
      pollingInterval: options.pollingInterval || 1000,
      priorityWeights: options.priorityWeights || DEFAULT_PRIORITY_WEIGHTS,
    };
    this.isRunning = false;
    this.pollingTimer = null;
    this.processHandler = null;
  }

  /**
   * Add a job to the queue
   */
  async enqueue(job: SyncJob): Promise<QueuedSyncJob> {
    // Check queue size limit
    if (this.queue.length >= this.options.maxSize) {
      throw new Error('Queue is at maximum capacity');
    }

    // Calculate queue position based on priority
    const queuePosition = this.calculateQueuePosition(job);

    const queuedJob: QueuedSyncJob = {
      ...job,
      queuePosition,
      estimatedStartTime: this.estimateStartTime(queuePosition),
    };

    // Insert at correct position based on priority
    this.insertByPriority(queuedJob);

    // Persist to database
    await this.persistJob(queuedJob);

    this.emitEvent('queue:enqueued', { job: queuedJob });

    return queuedJob;
  }

  /**
   * Remove a job from the queue
   */
  async dequeue(jobId: string): Promise<SyncJob | null> {
    const index = this.queue.findIndex((j) => j.id === jobId);
    if (index === -1) {
      return null;
    }

    const [job] = this.queue.splice(index, 1);

    // Update queue positions
    this.recalculatePositions();

    // Update database
    await this.supabase
      .from('sync_queue')
      .delete()
      .eq('job_id', jobId);

    this.emitEvent('queue:dequeued', { job });

    return job;
  }

  /**
   * Get the next job to process
   */
  async getNext(): Promise<SyncJob | null> {
    // Find first job that's ready and not being processed
    const now = new Date();
    const readyJob = this.queue.find(
      (job) =>
        job.scheduledAt <= now &&
        !this.processing.has(job.id) &&
        job.status === 'pending'
    );

    if (!readyJob) {
      return null;
    }

    // Check concurrency limit
    if (this.processing.size >= this.options.processingConcurrency) {
      return null;
    }

    // Mark as processing
    this.processing.add(readyJob.id);
    readyJob.status = 'processing';

    // Update database
    await this.supabase
      .from('sync_queue')
      .update({ status: 'processing', started_at: new Date().toISOString() })
      .eq('job_id', readyJob.id);

    return readyJob;
  }

  /**
   * Mark a job as complete and remove from queue
   */
  async complete(jobId: string): Promise<void> {
    this.processing.delete(jobId);
    await this.dequeue(jobId);
    this.emitEvent('queue:completed', { jobId });
  }

  /**
   * Mark a job as failed
   */
  async fail(jobId: string, error: Error): Promise<void> {
    this.processing.delete(jobId);

    const job = this.queue.find((j) => j.id === jobId);
    if (job) {
      job.status = 'failed';
      job.error = {
        code: 'PROCESSING_ERROR',
        message: error.message,
        retryable: true,
      };
    }

    await this.supabase
      .from('sync_queue')
      .update({
        status: 'failed',
        error: error.message,
        failed_at: new Date().toISOString(),
      })
      .eq('job_id', jobId);

    this.emitEvent('queue:failed', { jobId, error: error.message });
  }

  /**
   * Re-queue a failed job for retry
   */
  async requeue(jobId: string, delay: number = 0): Promise<void> {
    const job = this.queue.find((j) => j.id === jobId);
    if (!job) {
      throw new Error(`Job not found: ${jobId}`);
    }

    job.status = 'pending';
    job.retryCount++;
    job.scheduledAt = new Date(Date.now() + delay);
    job.error = undefined;

    // Recalculate position
    const newPosition = this.calculateQueuePosition(job);
    job.queuePosition = newPosition;
    job.estimatedStartTime = this.estimateStartTime(newPosition);

    // Re-sort queue
    this.sortQueue();

    await this.supabase
      .from('sync_queue')
      .update({
        status: 'pending',
        retry_count: job.retryCount,
        scheduled_at: job.scheduledAt.toISOString(),
        queue_position: newPosition,
      })
      .eq('job_id', jobId);

    this.emitEvent('queue:requeued', { job });
  }

  /**
   * Start queue processing
   */
  start(handler: QueueEventHandler): void {
    if (this.isRunning) {
      return;
    }

    this.processHandler = handler;
    this.isRunning = true;

    // Load persisted jobs
    this.loadPersistedJobs();

    // Start polling
    this.pollingTimer = setInterval(() => {
      this.processQueue();
    }, this.options.pollingInterval);

    this.emitEvent('queue:started', {});
  }

  /**
   * Stop queue processing
   */
  stop(): void {
    if (!this.isRunning) {
      return;
    }

    this.isRunning = false;

    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
      this.pollingTimer = null;
    }

    this.emitEvent('queue:stopped', {});
  }

  /**
   * Get queue statistics
   */
  getStats(): QueueStats {
    const now = Date.now();
    const completedJobs = 0; // Would need historical data
    const failedJobs = this.queue.filter((j) => j.status === 'failed').length;

    // Calculate average processing time from recent jobs
    const avgProcessingTime = 0; // Would need historical data

    // Find oldest job age
    const oldestJob = this.queue
      .filter((j) => j.status === 'pending')
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())[0];

    return {
      totalJobs: this.queue.length + this.processing.size,
      pendingJobs: this.queue.filter((j) => j.status === 'pending').length,
      processingJobs: this.processing.size,
      completedJobs,
      failedJobs,
      averageProcessingTime: avgProcessingTime,
      oldestJobAge: oldestJob ? now - oldestJob.createdAt.getTime() : 0,
    };
  }

  /**
   * Get all queued jobs
   */
  getJobs(filter?: { status?: SyncStatus; priority?: SyncPriority }): QueuedSyncJob[] {
    let jobs = [...this.queue];

    if (filter?.status) {
      jobs = jobs.filter((j) => j.status === filter.status);
    }

    if (filter?.priority) {
      jobs = jobs.filter((j) => j.priority === filter.priority);
    }

    return jobs;
  }

  /**
   * Clear the queue
   */
  async clear(options?: { status?: SyncStatus }): Promise<number> {
    let count = 0;

    if (options?.status) {
      const toRemove = this.queue.filter((j) => j.status === options.status);
      count = toRemove.length;
      this.queue = this.queue.filter((j) => j.status !== options.status);

      await this.supabase.from('sync_queue').delete().eq('status', options.status);
    } else {
      count = this.queue.length;
      this.queue = [];
      this.processing.clear();

      await this.supabase.from('sync_queue').delete();
    }

    this.emitEvent('queue:cleared', { count });

    return count;
  }

  /**
   * Update job priority
   */
  async updatePriority(jobId: string, newPriority: SyncPriority): Promise<void> {
    const job = this.queue.find((j) => j.id === jobId);
    if (!job) {
      throw new Error(`Job not found: ${jobId}`);
    }

    job.priority = newPriority;
    job.queuePosition = this.calculateQueuePosition(job);
    job.estimatedStartTime = this.estimateStartTime(job.queuePosition);

    this.sortQueue();

    await this.supabase
      .from('sync_queue')
      .update({
        priority: newPriority,
        queue_position: job.queuePosition,
      })
      .eq('job_id', jobId);

    this.emitEvent('queue:priorityChanged', { job });
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private async processQueue(): Promise<void> {
    if (!this.processHandler) {
      return;
    }

    // Get next jobs up to concurrency limit
    while (this.processing.size < this.options.processingConcurrency) {
      const job = await this.getNext();
      if (!job) {
        break;
      }

      // Process in background
      this.processJob(job);
    }
  }

  private async processJob(job: SyncJob): Promise<void> {
    try {
      await this.processHandler!(job);
      await this.complete(job.id);
    } catch (error) {
      await this.fail(job.id, error instanceof Error ? error : new Error(String(error)));
    }
  }

  private calculateQueuePosition(job: SyncJob): number {
    const priorityWeight = this.options.priorityWeights[job.priority];
    const scheduledWeight = job.scheduledAt.getTime();

    // Lower is better (processed first)
    // High priority + earlier scheduled = lower position
    return scheduledWeight - priorityWeight * 1000000;
  }

  private insertByPriority(job: QueuedSyncJob): void {
    // Find correct position
    const insertIndex = this.queue.findIndex(
      (existing) => job.queuePosition < existing.queuePosition
    );

    if (insertIndex === -1) {
      this.queue.push(job);
    } else {
      this.queue.splice(insertIndex, 0, job);
    }
  }

  private sortQueue(): void {
    this.queue.sort((a, b) => a.queuePosition - b.queuePosition);
    this.recalculatePositions();
  }

  private recalculatePositions(): void {
    this.queue.forEach((job, index) => {
      job.queuePosition = index;
      job.estimatedStartTime = this.estimateStartTime(index);
    });
  }

  private estimateStartTime(position: number): Date {
    // Estimate based on average processing time and concurrency
    const avgProcessingTime = 5000; // 5 seconds default
    const estimatedMs =
      Math.floor(position / this.options.processingConcurrency) * avgProcessingTime;
    return new Date(Date.now() + estimatedMs);
  }

  private async persistJob(job: QueuedSyncJob): Promise<void> {
    await this.supabase.from('sync_queue').upsert({
      job_id: job.id,
      type: job.type,
      direction: job.direction,
      status: job.status,
      priority: job.priority,
      source_platform: job.sourcePlatform,
      target_platforms: job.targetPlatforms,
      product_id: job.productId,
      order_id: job.orderId,
      data: job.data,
      queue_position: job.queuePosition,
      retry_count: job.retryCount,
      max_retries: job.maxRetries,
      scheduled_at: job.scheduledAt.toISOString(),
      created_at: job.createdAt.toISOString(),
    });
  }

  private async loadPersistedJobs(): Promise<void> {
    const { data, error } = await this.supabase
      .from('sync_queue')
      .select('*')
      .in('status', ['pending', 'retrying'])
      .order('queue_position', { ascending: true });

    if (error) {
      console.error('Failed to load persisted jobs:', error);
      return;
    }

    for (const row of data || []) {
      const job: QueuedSyncJob = {
        id: row.job_id,
        type: row.type,
        direction: row.direction,
        status: row.status,
        priority: row.priority,
        sourcePlatform: row.source_platform,
        targetPlatforms: row.target_platforms,
        productId: row.product_id,
        orderId: row.order_id,
        data: row.data,
        retryCount: row.retry_count,
        maxRetries: row.max_retries,
        scheduledAt: new Date(row.scheduled_at),
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at || row.created_at),
        queuePosition: row.queue_position,
        estimatedStartTime: this.estimateStartTime(row.queue_position),
      };

      this.queue.push(job);
    }

    this.sortQueue();
    this.emitEvent('queue:loaded', { count: this.queue.length });
  }

  private emitEvent(type: SyncEventType | string, payload: Record<string, unknown>): void {
    const event: SyncEvent = {
      type: type as SyncEventType,
      payload,
      timestamp: new Date(),
    };
    this.emit(type, event);
    this.emit('queue:event', event);
  }
}

export default SyncQueue;
