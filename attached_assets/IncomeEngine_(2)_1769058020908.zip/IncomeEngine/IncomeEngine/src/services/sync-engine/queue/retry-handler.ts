/**
 * Sync Retry Handler
 * Handles failed sync job retries with exponential backoff
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { SyncJob, SyncError, SyncStatus } from '../types';
import { SyncQueue } from './sync-queue';

// ============================================================================
// Types
// ============================================================================

export interface RetryConfig {
  maxRetries: number;
  initialDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
  retryableErrors: string[];
  nonRetryableErrors: string[];
  jitterPercent: number;
}

export interface RetryResult {
  shouldRetry: boolean;
  delay: number;
  attempt: number;
  reason?: string;
}

export interface RetryStats {
  totalRetries: number;
  successfulRetries: number;
  failedRetries: number;
  retriesInProgress: number;
  averageRetryDelay: number;
  retriesByError: Record<string, number>;
}

// ============================================================================
// Default Configuration
// ============================================================================

const DEFAULT_CONFIG: RetryConfig = {
  maxRetries: 5,
  initialDelayMs: 1000,
  maxDelayMs: 60000,
  backoffMultiplier: 2,
  retryableErrors: [
    'NETWORK_ERROR',
    'TIMEOUT_ERROR',
    'RATE_LIMIT',
    'SERVICE_UNAVAILABLE',
    'GATEWAY_TIMEOUT',
    'CONNECTION_ERROR',
    'TEMPORARY_ERROR',
    'SYNC_ERROR',
  ],
  nonRetryableErrors: [
    'VALIDATION_FAILED',
    'PRODUCT_NOT_FOUND',
    'INVALID_CREDENTIALS',
    'PERMISSION_DENIED',
    'INVALID_TRANSITION',
    'CANCELLED',
  ],
  jitterPercent: 25,
};

// ============================================================================
// Sync Retry Handler Class
// ============================================================================

export class SyncRetryHandler {
  private supabase: SupabaseClient;
  private queue: SyncQueue;
  private config: RetryConfig;
  private retryTimers: Map<string, NodeJS.Timeout>;
  private stats: RetryStats;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    queue: SyncQueue,
    config: Partial<RetryConfig> = {}
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.queue = queue;
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.retryTimers = new Map();
    this.stats = {
      totalRetries: 0,
      successfulRetries: 0,
      failedRetries: 0,
      retriesInProgress: 0,
      averageRetryDelay: 0,
      retriesByError: {},
    };
  }

  /**
   * Determine if a job should be retried
   */
  shouldRetry(job: SyncJob, error: SyncError): RetryResult {
    // Check max retries
    if (job.retryCount >= job.maxRetries) {
      return {
        shouldRetry: false,
        delay: 0,
        attempt: job.retryCount,
        reason: `Maximum retries (${job.maxRetries}) exceeded`,
      };
    }

    // Check non-retryable errors
    if (this.config.nonRetryableErrors.includes(error.code)) {
      return {
        shouldRetry: false,
        delay: 0,
        attempt: job.retryCount,
        reason: `Error ${error.code} is not retryable`,
      };
    }

    // Check if error is explicitly retryable
    if (!error.retryable && !this.config.retryableErrors.includes(error.code)) {
      return {
        shouldRetry: false,
        delay: 0,
        attempt: job.retryCount,
        reason: `Error ${error.code} is not marked as retryable`,
      };
    }

    // Calculate delay
    const delay = this.calculateDelay(job.retryCount);

    return {
      shouldRetry: true,
      delay,
      attempt: job.retryCount + 1,
    };
  }

  /**
   * Schedule a job for retry
   */
  async scheduleRetry(job: SyncJob, error: SyncError): Promise<boolean> {
    const retryResult = this.shouldRetry(job, error);

    if (!retryResult.shouldRetry) {
      await this.logFailedRetry(job, error, retryResult.reason || 'Not retryable');
      return false;
    }

    // Update stats
    this.stats.totalRetries++;
    this.stats.retriesInProgress++;
    this.stats.retriesByError[error.code] = (this.stats.retriesByError[error.code] || 0) + 1;

    // Update job status
    job.status = 'retrying';
    job.retryCount++;
    job.error = error;
    job.scheduledAt = new Date(Date.now() + retryResult.delay);
    job.updatedAt = new Date();

    // Persist retry state
    await this.persistRetryState(job);

    // Log retry
    await this.logRetry(job, error, retryResult);

    // Schedule retry timer
    const timer = setTimeout(async () => {
      this.retryTimers.delete(job.id);
      this.stats.retriesInProgress--;

      try {
        await this.queue.requeue(job.id, 0); // Already delayed
        this.stats.successfulRetries++;
      } catch (requeueError) {
        console.error(`Failed to requeue job ${job.id}:`, requeueError);
        this.stats.failedRetries++;
      }
    }, retryResult.delay);

    this.retryTimers.set(job.id, timer);

    return true;
  }

  /**
   * Cancel a scheduled retry
   */
  cancelRetry(jobId: string): boolean {
    const timer = this.retryTimers.get(jobId);
    if (timer) {
      clearTimeout(timer);
      this.retryTimers.delete(jobId);
      this.stats.retriesInProgress--;
      return true;
    }
    return false;
  }

  /**
   * Cancel all scheduled retries
   */
  cancelAllRetries(): number {
    let count = 0;
    for (const [jobId, timer] of this.retryTimers) {
      clearTimeout(timer);
      this.retryTimers.delete(jobId);
      count++;
    }
    this.stats.retriesInProgress = 0;
    return count;
  }

  /**
   * Get retry statistics
   */
  getStats(): RetryStats {
    return { ...this.stats };
  }

  /**
   * Get pending retries
   */
  async getPendingRetries(): Promise<
    Array<{
      jobId: string;
      retryCount: number;
      scheduledAt: Date;
      error: SyncError;
    }>
  > {
    const { data, error } = await this.supabase
      .from('sync_jobs')
      .select('id, retry_count, scheduled_at, error')
      .eq('status', 'retrying')
      .order('scheduled_at', { ascending: true });

    if (error) {
      console.error('Failed to get pending retries:', error);
      return [];
    }

    return (data || []).map((row) => ({
      jobId: row.id,
      retryCount: row.retry_count,
      scheduledAt: new Date(row.scheduled_at),
      error: row.error,
    }));
  }

  /**
   * Get retry history for a job
   */
  async getRetryHistory(
    jobId: string
  ): Promise<
    Array<{
      attempt: number;
      error: SyncError;
      delay: number;
      status: 'scheduled' | 'executed' | 'cancelled';
      timestamp: Date;
    }>
  > {
    const { data, error } = await this.supabase
      .from('sync_retry_log')
      .select('*')
      .eq('job_id', jobId)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Failed to get retry history:', error);
      return [];
    }

    return (data || []).map((row) => ({
      attempt: row.attempt,
      error: row.error,
      delay: row.delay_ms,
      status: row.status,
      timestamp: new Date(row.created_at),
    }));
  }

  /**
   * Reset retry count for a job
   */
  async resetRetryCount(jobId: string): Promise<void> {
    this.cancelRetry(jobId);

    await this.supabase
      .from('sync_jobs')
      .update({
        retry_count: 0,
        error: null,
        status: 'pending',
        updated_at: new Date().toISOString(),
      })
      .eq('id', jobId);
  }

  /**
   * Update retry configuration
   */
  updateConfig(updates: Partial<RetryConfig>): void {
    this.config = { ...this.config, ...updates };
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private calculateDelay(attempt: number): number {
    // Exponential backoff: initialDelay * (multiplier ^ attempt)
    const baseDelay =
      this.config.initialDelayMs * Math.pow(this.config.backoffMultiplier, attempt);

    // Add jitter
    const jitter = this.calculateJitter(baseDelay);

    // Cap at max delay
    const delay = Math.min(baseDelay + jitter, this.config.maxDelayMs);

    // Update average
    this.stats.averageRetryDelay =
      (this.stats.averageRetryDelay * (this.stats.totalRetries - 1) + delay) /
      this.stats.totalRetries;

    return Math.floor(delay);
  }

  private calculateJitter(baseDelay: number): number {
    const jitterRange = baseDelay * (this.config.jitterPercent / 100);
    return Math.random() * jitterRange * 2 - jitterRange;
  }

  private async persistRetryState(job: SyncJob): Promise<void> {
    await this.supabase
      .from('sync_jobs')
      .update({
        status: job.status,
        retry_count: job.retryCount,
        error: job.error,
        scheduled_at: job.scheduledAt.toISOString(),
        updated_at: job.updatedAt.toISOString(),
      })
      .eq('id', job.id);
  }

  private async logRetry(
    job: SyncJob,
    error: SyncError,
    result: RetryResult
  ): Promise<void> {
    await this.supabase.from('sync_retry_log').insert({
      job_id: job.id,
      attempt: result.attempt,
      error: error,
      delay_ms: result.delay,
      status: 'scheduled',
      scheduled_for: new Date(Date.now() + result.delay).toISOString(),
      created_at: new Date().toISOString(),
    });

    // Also log to audit
    await this.supabase.from('sync_audit_log').insert({
      sync_job_id: job.id,
      sync_type: job.type,
      action: 'retried',
      actor: 'system',
      details: {
        attempt: result.attempt,
        error_code: error.code,
        error_message: error.message,
        delay_ms: result.delay,
        scheduled_for: new Date(Date.now() + result.delay).toISOString(),
      },
      timestamp: new Date().toISOString(),
    });
  }

  private async logFailedRetry(
    job: SyncJob,
    error: SyncError,
    reason: string
  ): Promise<void> {
    this.stats.failedRetries++;

    await this.supabase.from('sync_retry_log').insert({
      job_id: job.id,
      attempt: job.retryCount,
      error: error,
      delay_ms: 0,
      status: 'rejected',
      rejection_reason: reason,
      created_at: new Date().toISOString(),
    });

    // Update job to failed status
    await this.supabase
      .from('sync_jobs')
      .update({
        status: 'failed',
        error: {
          ...error,
          finalFailure: true,
          failureReason: reason,
        },
        updated_at: new Date().toISOString(),
      })
      .eq('id', job.id);
  }
}

export default SyncRetryHandler;
