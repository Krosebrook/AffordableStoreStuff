/**
 * Event Processor
 * Processes incoming webhook events and triggers appropriate sync jobs
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  PlatformWebhookEvent,
  SyncType,
  SyncJob,
  WebhookEventCategory,
  SyncEvent,
  SyncEventType,
} from '../types';
import { ConnectorName } from '../../../connectors/index';
import { SyncManager } from '../sync-manager';

// ============================================================================
// Types
// ============================================================================

export interface EventHandler {
  platform: ConnectorName | '*';
  eventTypes: string[];
  handler: (event: PlatformWebhookEvent) => Promise<void>;
  priority: number;
}

export interface ProcessingResult {
  success: boolean;
  eventId: string;
  jobsCreated: string[];
  error?: string;
  processingTime: number;
}

export interface EventMappingConfig {
  platform: ConnectorName;
  eventType: string;
  syncType: SyncType;
  category: WebhookEventCategory;
  extractProductId?: (payload: Record<string, unknown>) => string | undefined;
  extractOrderId?: (payload: Record<string, unknown>) => string | undefined;
  shouldProcess?: (payload: Record<string, unknown>) => boolean;
}

// ============================================================================
// Event Mapping Registry
// ============================================================================

const DEFAULT_EVENT_MAPPINGS: EventMappingConfig[] = [
  // Shopify Events
  {
    platform: 'shopify',
    eventType: 'products/update',
    syncType: 'product',
    category: 'product',
    extractProductId: (p) => String(p.id),
  },
  {
    platform: 'shopify',
    eventType: 'products/create',
    syncType: 'product',
    category: 'product',
    extractProductId: (p) => String(p.id),
  },
  {
    platform: 'shopify',
    eventType: 'inventory_levels/update',
    syncType: 'inventory',
    category: 'inventory',
    extractProductId: (p) => String((p as any).inventory_item_id),
  },
  {
    platform: 'shopify',
    eventType: 'orders/create',
    syncType: 'order',
    category: 'order',
    extractOrderId: (p) => String(p.id),
  },
  {
    platform: 'shopify',
    eventType: 'orders/fulfilled',
    syncType: 'order',
    category: 'fulfillment',
    extractOrderId: (p) => String(p.id),
  },
  // Etsy Events
  {
    platform: 'etsy',
    eventType: 'listing.updated',
    syncType: 'product',
    category: 'product',
    extractProductId: (p) => String(p.listing_id),
  },
  {
    platform: 'etsy',
    eventType: 'listing.inventory_updated',
    syncType: 'inventory',
    category: 'inventory',
    extractProductId: (p) => String(p.listing_id),
  },
  {
    platform: 'etsy',
    eventType: 'transaction.created',
    syncType: 'order',
    category: 'order',
    extractOrderId: (p) => String(p.transaction_id),
  },
  // Printify Events
  {
    platform: 'printify',
    eventType: 'product:publish:started',
    syncType: 'product',
    category: 'product',
    extractProductId: (p) => String((p as any).resource?.id),
  },
  {
    platform: 'printify',
    eventType: 'order:created',
    syncType: 'order',
    category: 'order',
    extractOrderId: (p) => String((p as any).resource?.id),
  },
  {
    platform: 'printify',
    eventType: 'order:shipped',
    syncType: 'order',
    category: 'fulfillment',
    extractOrderId: (p) => String((p as any).resource?.id),
  },
  // WooCommerce Events
  {
    platform: 'woocommerce',
    eventType: 'product.updated',
    syncType: 'product',
    category: 'product',
    extractProductId: (p) => String(p.id),
  },
  {
    platform: 'woocommerce',
    eventType: 'order.created',
    syncType: 'order',
    category: 'order',
    extractOrderId: (p) => String(p.id),
  },
  {
    platform: 'woocommerce',
    eventType: 'order.updated',
    syncType: 'order',
    category: 'order',
    extractOrderId: (p) => String(p.id),
  },
  // Gumroad Events
  {
    platform: 'gumroad',
    eventType: 'sale',
    syncType: 'order',
    category: 'order',
    extractOrderId: (p) => String(p.sale_id),
    extractProductId: (p) => String(p.product_id),
  },
  // TikTok Shop Events
  {
    platform: 'tiktok-shop',
    eventType: 'order.status.update',
    syncType: 'order',
    category: 'order',
    extractOrderId: (p) => String((p as any).order_id),
  },
  {
    platform: 'tiktok-shop',
    eventType: 'product.status.change',
    syncType: 'product',
    category: 'product',
    extractProductId: (p) => String((p as any).product_id),
  },
];

// ============================================================================
// Event Processor Class
// ============================================================================

export class EventProcessor extends EventEmitter {
  private supabase: SupabaseClient;
  private syncManager: SyncManager;
  private handlers: EventHandler[];
  private eventMappings: Map<string, EventMappingConfig>;
  private processingQueue: PlatformWebhookEvent[];
  private isProcessing: boolean;
  private connectedPlatforms: ConnectorName[];

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    syncManager: SyncManager,
    connectedPlatforms: ConnectorName[] = []
  ) {
    super();
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.syncManager = syncManager;
    this.handlers = [];
    this.eventMappings = new Map();
    this.processingQueue = [];
    this.isProcessing = false;
    this.connectedPlatforms = connectedPlatforms;

    // Load default mappings
    DEFAULT_EVENT_MAPPINGS.forEach((mapping) => {
      this.registerEventMapping(mapping);
    });
  }

  /**
   * Process a webhook event
   */
  async process(event: PlatformWebhookEvent): Promise<ProcessingResult> {
    const startTime = Date.now();
    const jobsCreated: string[] = [];

    try {
      // Store event
      await this.storeEvent(event);

      // Mark as processing
      event.status = 'processing';

      // Get event mapping
      const mapping = this.getEventMapping(event.platform, event.eventType);
      if (!mapping) {
        // No mapping - skip but don't fail
        event.status = 'ignored';
        await this.updateEventStatus(event);
        return {
          success: true,
          eventId: event.id,
          jobsCreated: [],
          processingTime: Date.now() - startTime,
        };
      }

      // Check if should process
      if (mapping.shouldProcess && !mapping.shouldProcess(event.payload)) {
        event.status = 'ignored';
        await this.updateEventStatus(event);
        return {
          success: true,
          eventId: event.id,
          jobsCreated: [],
          processingTime: Date.now() - startTime,
        };
      }

      // Extract IDs
      const productId = mapping.extractProductId?.(event.payload);
      const orderId = mapping.extractOrderId?.(event.payload);

      // Determine target platforms
      const targetPlatforms = this.connectedPlatforms.filter(
        (p) => p !== event.platform
      );

      if (targetPlatforms.length === 0) {
        // No other platforms to sync to
        event.status = 'processed';
        await this.updateEventStatus(event);
        return {
          success: true,
          eventId: event.id,
          jobsCreated: [],
          processingTime: Date.now() - startTime,
        };
      }

      // Create sync job
      const syncData = this.buildSyncData(mapping.syncType, event.payload, productId, orderId);
      const job = await this.syncManager.createJob(
        mapping.syncType,
        'push',
        event.platform,
        targetPlatforms,
        syncData,
        {
          priority: this.determinePriority(mapping.category),
          productId,
          orderId,
        }
      );

      jobsCreated.push(job.id);

      // Start the job
      await this.syncManager.startJob(job.id);

      // Execute custom handlers
      await this.executeHandlers(event);

      // Mark as processed
      event.status = 'processed';
      event.processedAt = new Date();
      await this.updateEventStatus(event);

      this.emitEvent('webhook:processed', { event, jobsCreated });

      return {
        success: true,
        eventId: event.id,
        jobsCreated,
        processingTime: Date.now() - startTime,
      };
    } catch (error) {
      event.status = 'failed';
      event.error = error instanceof Error ? error.message : 'Unknown error';
      await this.updateEventStatus(event);

      this.emitEvent('webhook:failed', { event, error: event.error });

      return {
        success: false,
        eventId: event.id,
        jobsCreated,
        error: event.error,
        processingTime: Date.now() - startTime,
      };
    }
  }

  /**
   * Register an event handler
   */
  registerHandler(handler: EventHandler): void {
    this.handlers.push(handler);
    this.handlers.sort((a, b) => b.priority - a.priority);
  }

  /**
   * Register event mapping
   */
  registerEventMapping(mapping: EventMappingConfig): void {
    const key = `${mapping.platform}:${mapping.eventType}`;
    this.eventMappings.set(key, mapping);
  }

  /**
   * Update connected platforms
   */
  updateConnectedPlatforms(platforms: ConnectorName[]): void {
    this.connectedPlatforms = platforms;
  }

  /**
   * Get processing statistics
   */
  async getStats(): Promise<{
    totalProcessed: number;
    successful: number;
    failed: number;
    ignored: number;
    byPlatform: Record<string, number>;
    byCategory: Record<string, number>;
    averageProcessingTime: number;
  }> {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const { data } = await this.supabase
      .from('webhook_events')
      .select('platform, category, status, processing_time_ms')
      .gte('received_at', oneDayAgo.toISOString());

    const events = data || [];

    const byPlatform: Record<string, number> = {};
    const byCategory: Record<string, number> = {};
    let totalTime = 0;
    let successful = 0;
    let failed = 0;
    let ignored = 0;

    for (const event of events) {
      byPlatform[event.platform] = (byPlatform[event.platform] || 0) + 1;
      byCategory[event.category] = (byCategory[event.category] || 0) + 1;
      totalTime += event.processing_time_ms || 0;

      if (event.status === 'processed') successful++;
      else if (event.status === 'failed') failed++;
      else if (event.status === 'ignored') ignored++;
    }

    return {
      totalProcessed: events.length,
      successful,
      failed,
      ignored,
      byPlatform,
      byCategory,
      averageProcessingTime: events.length > 0 ? totalTime / events.length : 0,
    };
  }

  /**
   * Replay failed events
   */
  async replayFailedEvents(
    options: { platform?: ConnectorName; since?: Date; limit?: number } = {}
  ): Promise<ProcessingResult[]> {
    const since = options.since || new Date(Date.now() - 24 * 60 * 60 * 1000);

    let query = this.supabase
      .from('webhook_events')
      .select('*')
      .eq('status', 'failed')
      .gte('received_at', since.toISOString())
      .order('received_at', { ascending: true });

    if (options.platform) {
      query = query.eq('platform', options.platform);
    }

    if (options.limit) {
      query = query.limit(options.limit);
    }

    const { data, error } = await query;

    if (error || !data) {
      return [];
    }

    const results: ProcessingResult[] = [];

    for (const row of data) {
      const event = this.mapDbRowToEvent(row);
      const result = await this.process(event);
      results.push(result);
    }

    return results;
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private getEventMapping(
    platform: ConnectorName,
    eventType: string
  ): EventMappingConfig | undefined {
    const key = `${platform}:${eventType}`;
    return this.eventMappings.get(key);
  }

  private buildSyncData(
    syncType: SyncType,
    payload: Record<string, unknown>,
    productId?: string,
    orderId?: string
  ): SyncJob['data'] {
    switch (syncType) {
      case 'inventory':
        return {
          inventory: {
            productId: productId || '',
            quantity: this.extractQuantity(payload),
            trackInventory: true,
          },
        };
      case 'price':
        return {
          price: {
            productId: productId || '',
            price: this.extractPrice(payload),
            currency: this.extractCurrency(payload),
          },
        };
      case 'order':
        return {
          order: {
            orderId: orderId || '',
            externalOrderId: String(payload.id || payload.order_id || ''),
            status: this.extractOrderStatus(payload),
          },
        };
      case 'product':
        return {
          product: {
            productId: productId || '',
            product: {
              title: String(payload.title || ''),
              description: String(payload.description || payload.body_html || ''),
            },
            fields: ['title', 'description', 'images', 'variants'],
            createIfMissing: false,
          },
        };
      default:
        return {};
    }
  }

  private extractQuantity(payload: Record<string, unknown>): number {
    return (
      Number(payload.available) ||
      Number(payload.quantity) ||
      Number(payload.inventory_quantity) ||
      0
    );
  }

  private extractPrice(payload: Record<string, unknown>): number {
    return (
      Number(payload.price) ||
      Number((payload.variants as any)?.[0]?.price) ||
      0
    );
  }

  private extractCurrency(payload: Record<string, unknown>): string {
    return String(payload.currency || 'USD');
  }

  private extractOrderStatus(payload: Record<string, unknown>): any {
    const status = String(
      payload.status ||
        payload.fulfillment_status ||
        payload.financial_status ||
        'pending'
    ).toLowerCase();

    const statusMap: Record<string, string> = {
      unfulfilled: 'pending',
      pending: 'pending',
      paid: 'processing',
      partially_fulfilled: 'processing',
      processing: 'processing',
      fulfilled: 'shipped',
      shipped: 'shipped',
      delivered: 'delivered',
      cancelled: 'cancelled',
      refunded: 'refunded',
    };

    return statusMap[status] || 'pending';
  }

  private determinePriority(category: WebhookEventCategory): SyncJob['priority'] {
    switch (category) {
      case 'order':
        return 'high';
      case 'fulfillment':
        return 'high';
      case 'inventory':
        return 'normal';
      case 'price':
        return 'normal';
      case 'product':
        return 'low';
      default:
        return 'normal';
    }
  }

  private async executeHandlers(event: PlatformWebhookEvent): Promise<void> {
    for (const handler of this.handlers) {
      // Check if handler matches
      if (
        (handler.platform === '*' || handler.platform === event.platform) &&
        (handler.eventTypes.includes('*') || handler.eventTypes.includes(event.eventType))
      ) {
        try {
          await handler.handler(event);
        } catch (error) {
          console.error(`Handler error for ${event.eventType}:`, error);
        }
      }
    }
  }

  private async storeEvent(event: PlatformWebhookEvent): Promise<void> {
    await this.supabase.from('webhook_events').insert({
      id: event.id,
      platform: event.platform,
      event_type: event.eventType,
      category: event.category,
      payload: event.payload,
      signature: event.signature,
      received_at: event.receivedAt.toISOString(),
      status: event.status,
    });
  }

  private async updateEventStatus(event: PlatformWebhookEvent): Promise<void> {
    await this.supabase
      .from('webhook_events')
      .update({
        status: event.status,
        processed_at: event.processedAt?.toISOString(),
        error: event.error,
      })
      .eq('id', event.id);
  }

  private mapDbRowToEvent(row: Record<string, unknown>): PlatformWebhookEvent {
    return {
      id: row.id as string,
      platform: row.platform as ConnectorName,
      eventType: row.event_type as string,
      category: row.category as WebhookEventCategory,
      payload: row.payload as Record<string, unknown>,
      signature: row.signature as string | undefined,
      receivedAt: new Date(row.received_at as string),
      processedAt: row.processed_at ? new Date(row.processed_at as string) : undefined,
      status: row.status as PlatformWebhookEvent['status'],
      error: row.error as string | undefined,
    };
  }

  private emitEvent(type: SyncEventType | string, payload: Record<string, unknown>): void {
    const event: SyncEvent = {
      type: type as SyncEventType,
      payload,
      timestamp: new Date(),
    };
    this.emit(type, event);
    this.emit('event', event);
  }
}

export default EventProcessor;
