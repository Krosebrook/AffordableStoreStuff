/**
 * Webhook Validator
 * Validates incoming webhooks from various platforms
 */

import { createHmac } from 'crypto';
import { ConnectorName } from '../../../connectors/index';
import { WebhookValidationResult } from '../types';

// ============================================================================
// Types
// ============================================================================

export interface PlatformWebhookConfig {
  platform: ConnectorName;
  secretKey?: string;
  signatureHeader: string;
  signaturePrefix?: string;
  algorithm: 'sha256' | 'sha1' | 'sha512';
  timestampHeader?: string;
  timestampTolerance?: number; // in seconds
  encoding?: 'hex' | 'base64';
  validateTimestamp?: boolean;
}

// ============================================================================
// Default Platform Configurations
// ============================================================================

const PLATFORM_CONFIGS: Record<string, Partial<PlatformWebhookConfig>> = {
  shopify: {
    signatureHeader: 'X-Shopify-Hmac-SHA256',
    algorithm: 'sha256',
    encoding: 'base64',
  },
  etsy: {
    signatureHeader: 'X-Etsy-Signature',
    algorithm: 'sha256',
    encoding: 'base64',
    timestampHeader: 'X-Etsy-Timestamp',
    timestampTolerance: 300,
    validateTimestamp: true,
  },
  printify: {
    signatureHeader: 'X-Printify-Signature',
    algorithm: 'sha256',
    encoding: 'hex',
  },
  gumroad: {
    signatureHeader: 'X-Gumroad-Signature',
    algorithm: 'sha256',
    encoding: 'hex',
  },
  woocommerce: {
    signatureHeader: 'X-WC-Webhook-Signature',
    algorithm: 'sha256',
    encoding: 'base64',
  },
  'tiktok-shop': {
    signatureHeader: 'X-TikTok-Signature',
    algorithm: 'sha256',
    encoding: 'hex',
    timestampHeader: 'X-TikTok-Timestamp',
    timestampTolerance: 300,
    validateTimestamp: true,
  },
  stripe: {
    signatureHeader: 'Stripe-Signature',
    signaturePrefix: 'v1=',
    algorithm: 'sha256',
    encoding: 'hex',
    timestampTolerance: 300,
    validateTimestamp: true,
  },
  generic: {
    signatureHeader: 'X-Webhook-Signature',
    algorithm: 'sha256',
    encoding: 'hex',
  },
};

// ============================================================================
// Webhook Validator Class
// ============================================================================

export class WebhookValidator {
  private configs: Map<string, PlatformWebhookConfig>;

  constructor(platformSecrets: Record<string, string> = {}) {
    this.configs = new Map();

    // Initialize with default configs + secrets
    for (const [platform, defaultConfig] of Object.entries(PLATFORM_CONFIGS)) {
      this.configs.set(platform, {
        platform: platform as ConnectorName,
        secretKey: platformSecrets[platform],
        signatureHeader: defaultConfig.signatureHeader || 'X-Webhook-Signature',
        algorithm: defaultConfig.algorithm || 'sha256',
        encoding: defaultConfig.encoding || 'hex',
        signaturePrefix: defaultConfig.signaturePrefix,
        timestampHeader: defaultConfig.timestampHeader,
        timestampTolerance: defaultConfig.timestampTolerance || 300,
        validateTimestamp: defaultConfig.validateTimestamp || false,
      });
    }
  }

  /**
   * Validate a webhook request
   */
  validate(
    platform: string,
    headers: Record<string, string>,
    body: string | Buffer
  ): WebhookValidationResult {
    const config = this.configs.get(platform);

    if (!config) {
      return {
        valid: false,
        platform: platform as ConnectorName,
        eventType: 'unknown',
        error: `Unknown platform: ${platform}`,
      };
    }

    // Check if secret is configured
    if (!config.secretKey) {
      // No secret configured - allow but log warning
      console.warn(`No webhook secret configured for ${platform}`);
      return {
        valid: true,
        platform: platform as ConnectorName,
        eventType: this.extractEventType(platform, headers, body),
      };
    }

    // Get signature from headers (case-insensitive)
    const signature = this.getHeader(headers, config.signatureHeader);
    if (!signature) {
      return {
        valid: false,
        platform: platform as ConnectorName,
        eventType: 'unknown',
        error: `Missing signature header: ${config.signatureHeader}`,
      };
    }

    // Validate timestamp if configured
    if (config.validateTimestamp && config.timestampHeader) {
      const timestampResult = this.validateTimestamp(
        headers,
        config.timestampHeader,
        config.timestampTolerance || 300
      );
      if (!timestampResult.valid) {
        return {
          valid: false,
          platform: platform as ConnectorName,
          eventType: 'unknown',
          error: timestampResult.error,
        };
      }
    }

    // Compute expected signature
    const bodyString = typeof body === 'string' ? body : body.toString('utf8');
    const expectedSignature = this.computeSignature(
      bodyString,
      config.secretKey,
      config.algorithm,
      config.encoding || 'hex',
      config.signaturePrefix
    );

    // Compare signatures (timing-safe)
    const actualSignature = config.signaturePrefix
      ? signature.replace(config.signaturePrefix, '')
      : signature;

    const isValid = this.timingSafeEqual(actualSignature, expectedSignature);

    if (!isValid) {
      return {
        valid: false,
        platform: platform as ConnectorName,
        eventType: 'unknown',
        error: 'Invalid signature',
      };
    }

    return {
      valid: true,
      platform: platform as ConnectorName,
      eventType: this.extractEventType(platform, headers, body),
    };
  }

  /**
   * Register or update platform configuration
   */
  registerPlatform(config: PlatformWebhookConfig): void {
    this.configs.set(config.platform, config);
  }

  /**
   * Update secret for a platform
   */
  updateSecret(platform: string, secret: string): void {
    const config = this.configs.get(platform);
    if (config) {
      config.secretKey = secret;
    }
  }

  /**
   * Validate Stripe-style signature (with timestamp)
   */
  validateStripeSignature(
    headers: Record<string, string>,
    body: string,
    secret: string
  ): WebhookValidationResult {
    const signature = this.getHeader(headers, 'Stripe-Signature');
    if (!signature) {
      return {
        valid: false,
        platform: 'stripe' as ConnectorName,
        eventType: 'unknown',
        error: 'Missing Stripe-Signature header',
      };
    }

    // Parse signature parts (t=timestamp,v1=signature)
    const parts = signature.split(',').reduce(
      (acc, part) => {
        const [key, value] = part.split('=');
        acc[key] = value;
        return acc;
      },
      {} as Record<string, string>
    );

    const timestamp = parts['t'];
    const v1Signature = parts['v1'];

    if (!timestamp || !v1Signature) {
      return {
        valid: false,
        platform: 'stripe' as ConnectorName,
        eventType: 'unknown',
        error: 'Invalid Stripe-Signature format',
      };
    }

    // Validate timestamp
    const age = Date.now() / 1000 - parseInt(timestamp, 10);
    if (age > 300) {
      return {
        valid: false,
        platform: 'stripe' as ConnectorName,
        eventType: 'unknown',
        error: 'Timestamp too old',
      };
    }

    // Compute expected signature
    const signedPayload = `${timestamp}.${body}`;
    const expectedSignature = createHmac('sha256', secret)
      .update(signedPayload)
      .digest('hex');

    const isValid = this.timingSafeEqual(v1Signature, expectedSignature);

    if (!isValid) {
      return {
        valid: false,
        platform: 'stripe' as ConnectorName,
        eventType: 'unknown',
        error: 'Invalid signature',
      };
    }

    // Extract event type from body
    try {
      const event = JSON.parse(body);
      return {
        valid: true,
        platform: 'stripe' as ConnectorName,
        eventType: event.type || 'unknown',
      };
    } catch {
      return {
        valid: true,
        platform: 'stripe' as ConnectorName,
        eventType: 'unknown',
      };
    }
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private getHeader(headers: Record<string, string>, name: string): string | undefined {
    // Case-insensitive header lookup
    const lowerName = name.toLowerCase();
    for (const [key, value] of Object.entries(headers)) {
      if (key.toLowerCase() === lowerName) {
        return value;
      }
    }
    return undefined;
  }

  private computeSignature(
    payload: string,
    secret: string,
    algorithm: string,
    encoding: 'hex' | 'base64',
    prefix?: string
  ): string {
    const hmac = createHmac(algorithm, secret);
    hmac.update(payload);
    const signature = hmac.digest(encoding);
    return prefix ? `${prefix}${signature}` : signature;
  }

  private validateTimestamp(
    headers: Record<string, string>,
    headerName: string,
    toleranceSeconds: number
  ): { valid: boolean; error?: string } {
    const timestamp = this.getHeader(headers, headerName);
    if (!timestamp) {
      return { valid: false, error: `Missing timestamp header: ${headerName}` };
    }

    const webhookTime = parseInt(timestamp, 10);
    if (isNaN(webhookTime)) {
      return { valid: false, error: 'Invalid timestamp format' };
    }

    const now = Math.floor(Date.now() / 1000);
    const age = Math.abs(now - webhookTime);

    if (age > toleranceSeconds) {
      return {
        valid: false,
        error: `Timestamp too old or in future: ${age}s difference`,
      };
    }

    return { valid: true };
  }

  private timingSafeEqual(a: string, b: string): boolean {
    if (a.length !== b.length) {
      return false;
    }

    let result = 0;
    for (let i = 0; i < a.length; i++) {
      result |= a.charCodeAt(i) ^ b.charCodeAt(i);
    }

    return result === 0;
  }

  private extractEventType(
    platform: string,
    headers: Record<string, string>,
    body: string | Buffer
  ): string {
    // Platform-specific event type extraction
    const bodyString = typeof body === 'string' ? body : body.toString('utf8');

    try {
      const payload = JSON.parse(bodyString);

      switch (platform) {
        case 'shopify':
          return this.getHeader(headers, 'X-Shopify-Topic') || payload.topic || 'unknown';
        case 'etsy':
          return payload.event_type || payload.type || 'unknown';
        case 'printify':
          return payload.type || payload.event || 'unknown';
        case 'gumroad':
          return payload.event || 'unknown';
        case 'woocommerce':
          return this.getHeader(headers, 'X-WC-Webhook-Topic') || payload.action || 'unknown';
        case 'tiktok-shop':
          return payload.event_type || payload.type || 'unknown';
        default:
          return payload.event || payload.type || payload.event_type || 'unknown';
      }
    } catch {
      return 'unknown';
    }
  }
}

export default WebhookValidator;
