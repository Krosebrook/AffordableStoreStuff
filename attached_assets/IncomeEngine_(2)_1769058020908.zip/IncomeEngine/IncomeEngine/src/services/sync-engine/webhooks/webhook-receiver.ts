/**
 * Webhook Receiver
 * HTTP endpoint handler for incoming platform webhooks
 */

import { Request, Response, NextFunction, Router } from 'express';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { ConnectorName } from '../../../connectors/index';
import { PlatformWebhookEvent, WebhookEventCategory } from '../types';
import { WebhookValidator } from './webhook-validator';
import { EventProcessor } from './event-processor';

// ============================================================================
// Types
// ============================================================================

export interface WebhookReceiverConfig {
  supabaseUrl: string;
  supabaseKey: string;
  basePath: string;
  platformSecrets: Record<string, string>;
  enableLogging: boolean;
  maxPayloadSize: string;
}

export interface WebhookRequest extends Request {
  webhookEvent?: PlatformWebhookEvent;
  rawBody?: string;
}

// ============================================================================
// Webhook Receiver Class
// ============================================================================

export class WebhookReceiver {
  private supabase: SupabaseClient;
  private validator: WebhookValidator;
  private processor: EventProcessor;
  private router: Router;
  private config: WebhookReceiverConfig;

  constructor(
    config: WebhookReceiverConfig,
    processor: EventProcessor
  ) {
    this.config = config;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
    this.validator = new WebhookValidator(config.platformSecrets);
    this.processor = processor;
    this.router = Router();

    this.setupRoutes();
  }

  /**
   * Get Express router
   */
  getRouter(): Router {
    return this.router;
  }

  /**
   * Update platform secret
   */
  updatePlatformSecret(platform: string, secret: string): void {
    this.validator.updateSecret(platform, secret);
    this.config.platformSecrets[platform] = secret;
  }

  // ============================================================================
  // Route Setup
  // ============================================================================

  private setupRoutes(): void {
    // Raw body parser for signature validation
    this.router.use(this.rawBodyParser.bind(this));

    // Platform-specific endpoints
    this.router.post(
      '/:platform',
      this.validateWebhook.bind(this),
      this.processWebhook.bind(this)
    );

    // Health check
    this.router.get('/health', (_req: Request, res: Response) => {
      res.json({ status: 'ok', timestamp: new Date().toISOString() });
    });

    // Error handler
    this.router.use(this.errorHandler.bind(this));
  }

  // ============================================================================
  // Middleware
  // ============================================================================

  /**
   * Parse raw body for signature validation
   */
  private rawBodyParser(req: WebhookRequest, res: Response, next: NextFunction): void {
    // Express should already have parsed body, but we need raw for signature
    if (req.body && typeof req.body === 'object') {
      req.rawBody = JSON.stringify(req.body);
    }
    next();
  }

  /**
   * Validate incoming webhook
   */
  private validateWebhook(req: WebhookRequest, res: Response, next: NextFunction): void {
    const platform = req.params.platform;
    const rawBody = req.rawBody || '';
    const headers = req.headers as Record<string, string>;

    // Validate signature
    const validation = this.validator.validate(platform, headers, rawBody);

    if (!validation.valid) {
      if (this.config.enableLogging) {
        console.warn(`Invalid webhook from ${platform}:`, validation.error);
      }

      // Log failed validation
      this.logWebhookAttempt(platform, 'failed', validation.error);

      return res.status(401).json({
        error: 'Invalid webhook signature',
        details: validation.error,
      });
    }

    // Create webhook event
    const event: PlatformWebhookEvent = {
      id: this.generateEventId(),
      platform: platform as ConnectorName,
      eventType: validation.eventType,
      category: this.determineCategory(validation.eventType),
      payload: req.body,
      signature: this.getSignature(headers, platform),
      receivedAt: new Date(),
      status: 'pending',
    };

    req.webhookEvent = event;

    if (this.config.enableLogging) {
      console.log(`Webhook received: ${platform}/${validation.eventType}`);
    }

    next();
  }

  /**
   * Process validated webhook
   */
  private async processWebhook(req: WebhookRequest, res: Response): Promise<void> {
    const event = req.webhookEvent!;

    try {
      // Acknowledge receipt immediately
      res.status(200).json({
        received: true,
        eventId: event.id,
        timestamp: event.receivedAt.toISOString(),
      });

      // Process asynchronously
      this.processor.process(event).catch((error) => {
        console.error(`Failed to process webhook ${event.id}:`, error);
      });
    } catch (error) {
      console.error('Webhook processing error:', error);
      // Already sent response, just log
    }
  }

  /**
   * Error handler
   */
  private errorHandler(
    error: Error,
    _req: Request,
    res: Response,
    _next: NextFunction
  ): void {
    console.error('Webhook error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: process.env.NODE_ENV === 'development' ? error.message : undefined,
    });
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private generateEventId(): string {
    return `wh-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private determineCategory(eventType: string): WebhookEventCategory {
    const lowerType = eventType.toLowerCase();

    if (lowerType.includes('order') || lowerType.includes('transaction') || lowerType.includes('sale')) {
      return 'order';
    }
    if (lowerType.includes('fulfill') || lowerType.includes('ship')) {
      return 'fulfillment';
    }
    if (lowerType.includes('inventory') || lowerType.includes('stock')) {
      return 'inventory';
    }
    if (lowerType.includes('price')) {
      return 'price';
    }
    return 'product';
  }

  private getSignature(headers: Record<string, string>, platform: string): string | undefined {
    const signatureHeaders: Record<string, string> = {
      shopify: 'x-shopify-hmac-sha256',
      etsy: 'x-etsy-signature',
      printify: 'x-printify-signature',
      gumroad: 'x-gumroad-signature',
      woocommerce: 'x-wc-webhook-signature',
      'tiktok-shop': 'x-tiktok-signature',
    };

    const headerName = signatureHeaders[platform];
    if (!headerName) return undefined;

    // Case-insensitive lookup
    for (const [key, value] of Object.entries(headers)) {
      if (key.toLowerCase() === headerName) {
        return value;
      }
    }

    return undefined;
  }

  private async logWebhookAttempt(
    platform: string,
    status: 'success' | 'failed',
    error?: string
  ): Promise<void> {
    await this.supabase.from('webhook_log').insert({
      platform,
      status,
      error,
      timestamp: new Date().toISOString(),
    });
  }
}

// ============================================================================
// Factory Function
// ============================================================================

export function createWebhookReceiver(
  config: WebhookReceiverConfig,
  processor: EventProcessor
): WebhookReceiver {
  return new WebhookReceiver(config, processor);
}

export default WebhookReceiver;
