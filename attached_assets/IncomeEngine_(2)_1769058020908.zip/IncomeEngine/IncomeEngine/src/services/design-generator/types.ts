/**
 * ============================================================================
 * DESIGN GENERATOR TYPES
 * ============================================================================
 *
 * TypeScript interfaces for the AI-powered design generation pipeline.
 * Supports multiple providers (DALL-E 3, Replicate Flux, Stability AI SD3).
 */

// =============================================================================
// PROVIDER TYPES
// =============================================================================

export type ProviderName = 'openai-dalle' | 'replicate-flux' | 'stability-sd3';

export type FluxModel = 'flux-pro' | 'flux-dev' | 'flux-schnell';

export type StabilityModel = 'sd3' | 'sd3-turbo' | 'sd3-large' | 'sd3-large-turbo';

export interface ProviderConfig {
  readonly name: ProviderName;
  readonly displayName: string;
  readonly apiKey: string;
  readonly baseUrl?: string;
  readonly timeout?: number;
  readonly maxRetries?: number;
  readonly priority: number;
  readonly isEnabled: boolean;
  readonly capabilities: ProviderCapabilities;
}

export interface ProviderCapabilities {
  readonly maxWidth: number;
  readonly maxHeight: number;
  readonly supportedFormats: readonly ImageFormat[];
  readonly supportedStyles: readonly string[];
  readonly supportsNegativePrompt: boolean;
  readonly supportsBatchGeneration: boolean;
  readonly maxBatchSize: number;
  readonly supportsImageToImage: boolean;
  readonly supportsInpainting: boolean;
}

// =============================================================================
// GENERATION TYPES
// =============================================================================

export type ImageFormat = 'png' | 'jpg' | 'webp';

export type AspectRatio = '1:1' | '16:9' | '9:16' | '4:3' | '3:4' | '3:2' | '2:3';

export type ImageSize = 'small' | 'medium' | 'large' | 'xlarge';

export interface ImageDimensions {
  readonly width: number;
  readonly height: number;
}

export interface GenerationOptions {
  readonly provider?: ProviderName;
  readonly model?: string;
  readonly size?: ImageSize;
  readonly dimensions?: ImageDimensions;
  readonly aspectRatio?: AspectRatio;
  readonly format?: ImageFormat;
  readonly quality?: 'standard' | 'hd';
  readonly style?: string;
  readonly negativePrompt?: string;
  readonly seed?: number;
  readonly steps?: number;
  readonly guidanceScale?: number;
  readonly niche?: string;
  readonly productType?: string;
  readonly tags?: string[];
  readonly metadata?: Record<string, unknown>;
}

export interface BatchOptions extends GenerationOptions {
  readonly concurrency?: number;
  readonly stopOnError?: boolean;
  readonly retryFailedItems?: boolean;
}

export interface DesignPrompt {
  readonly text: string;
  readonly enhancedText?: string;
  readonly templateId?: string;
  readonly niche?: string;
  readonly variables?: Record<string, string>;
}

// =============================================================================
// RESULT TYPES
// =============================================================================

export interface GenerationResult {
  readonly success: boolean;
  readonly designId: string;
  readonly imageUrl?: string;
  readonly imageBase64?: string;
  readonly thumbnailUrl?: string;
  readonly provider: ProviderName;
  readonly model: string;
  readonly prompt: string;
  readonly enhancedPrompt?: string;
  readonly dimensions: ImageDimensions;
  readonly format: ImageFormat;
  readonly generationTimeMs: number;
  readonly cost: GenerationCost;
  readonly qualityScore?: number;
  readonly metadata: GenerationMetadata;
  readonly error?: GenerationError;
}

export interface BatchResult {
  readonly success: boolean;
  readonly batchId: string;
  readonly totalRequested: number;
  readonly totalSuccessful: number;
  readonly totalFailed: number;
  readonly results: GenerationResult[];
  readonly totalCost: GenerationCost;
  readonly totalTimeMs: number;
}

export interface GenerationCost {
  readonly amount: number;
  readonly currency: string;
  readonly provider: ProviderName;
  readonly model: string;
  readonly breakdown?: {
    readonly basePrice: number;
    readonly qualityMultiplier?: number;
    readonly sizeMultiplier?: number;
  };
}

export interface GenerationMetadata {
  readonly requestId: string;
  readonly timestamp: Date;
  readonly niche?: string;
  readonly productType?: string;
  readonly tags?: string[];
  readonly seed?: number;
  readonly steps?: number;
  readonly guidanceScale?: number;
  readonly templateId?: string;
  readonly failoverAttempts?: number;
  readonly originalProvider?: ProviderName;
}

export interface GenerationError {
  readonly code: string;
  readonly message: string;
  readonly provider?: ProviderName;
  readonly retryable: boolean;
  readonly details?: Record<string, unknown>;
}

// =============================================================================
// TEMPLATE TYPES
// =============================================================================

export interface PromptTemplate {
  readonly id: string;
  readonly name: string;
  readonly niche: string;
  readonly category: string;
  readonly template: string;
  readonly variables: TemplateVariable[];
  readonly style?: string;
  readonly negativePrompt?: string;
  readonly suggestedDimensions?: ImageDimensions;
  readonly tags: string[];
  readonly examples?: string[];
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface TemplateVariable {
  readonly name: string;
  readonly description: string;
  readonly required: boolean;
  readonly type: 'text' | 'select' | 'color' | 'number';
  readonly default?: string;
  readonly options?: string[];
  readonly validation?: {
    readonly minLength?: number;
    readonly maxLength?: number;
    readonly pattern?: string;
  };
}

export interface NicheTemplates {
  readonly niche: string;
  readonly displayName: string;
  readonly description: string;
  readonly templates: PromptTemplate[];
  readonly commonStyles: string[];
  readonly recommendedDimensions: ImageDimensions;
}

// =============================================================================
// POST-PROCESSING TYPES
// =============================================================================

export interface UpscaleOptions {
  readonly scale: 2 | 4;
  readonly provider?: 'replicate-esrgan' | 'stability-esrgan';
  readonly enhanceFace?: boolean;
  readonly denoiseStrength?: number;
}

export interface UpscaleResult {
  readonly success: boolean;
  readonly originalUrl: string;
  readonly upscaledUrl?: string;
  readonly upscaledBase64?: string;
  readonly originalDimensions: ImageDimensions;
  readonly upscaledDimensions: ImageDimensions;
  readonly scale: number;
  readonly processingTimeMs: number;
  readonly cost: number;
  readonly error?: GenerationError;
}

export interface BackgroundRemovalOptions {
  readonly provider?: 'remove-bg' | 'replicate-rembg';
  readonly outputFormat?: ImageFormat;
  readonly backgroundColor?: string;
  readonly crop?: boolean;
  readonly margin?: number;
}

export interface BackgroundRemovalResult {
  readonly success: boolean;
  readonly originalUrl: string;
  readonly processedUrl?: string;
  readonly processedBase64?: string;
  readonly processingTimeMs: number;
  readonly cost: number;
  readonly error?: GenerationError;
}

// =============================================================================
// VALIDATION TYPES
// =============================================================================

export interface QualityCheckResult {
  readonly passed: boolean;
  readonly overallScore: number;
  readonly scores: {
    readonly aesthetic: number;
    readonly technical: number;
    readonly relevance: number;
    readonly originality: number;
  };
  readonly issues: QualityIssue[];
  readonly suggestions: string[];
}

export interface QualityIssue {
  readonly type: 'resolution' | 'blur' | 'watermark' | 'artifacts' | 'composition' | 'style' | 'content';
  readonly severity: 'low' | 'medium' | 'high' | 'critical';
  readonly message: string;
  readonly autoFixable: boolean;
}

export interface PlatformRequirements {
  readonly platform: string;
  readonly minWidth: number;
  readonly minHeight: number;
  readonly maxWidth: number;
  readonly maxHeight: number;
  readonly preferredAspectRatios: AspectRatio[];
  readonly allowedFormats: ImageFormat[];
  readonly maxFileSizeMB: number;
  readonly requiresTransparency?: boolean;
  readonly colorSpace?: 'sRGB' | 'CMYK';
  readonly dpi?: number;
}

export interface PlatformValidationResult {
  readonly valid: boolean;
  readonly platform: string;
  readonly issues: PlatformIssue[];
  readonly recommendations: string[];
  readonly transformations?: ImageTransformation[];
}

export interface PlatformIssue {
  readonly field: string;
  readonly message: string;
  readonly severity: 'error' | 'warning';
  readonly autoFixable: boolean;
}

export interface ImageTransformation {
  readonly type: 'resize' | 'crop' | 'convert' | 'optimize';
  readonly params: Record<string, unknown>;
}

// =============================================================================
// DATABASE TYPES
// =============================================================================

export interface DesignRecord {
  readonly id: string;
  readonly userId?: string;
  readonly prompt: string;
  readonly enhancedPrompt?: string;
  readonly provider: ProviderName;
  readonly model: string;
  readonly imageUrl: string;
  readonly thumbnailUrl?: string;
  readonly width: number;
  readonly height: number;
  readonly format: ImageFormat;
  readonly fileSizeBytes: number;
  readonly generationTimeMs: number;
  readonly costAmount: number;
  readonly costCurrency: string;
  readonly qualityScore?: number;
  readonly niche?: string;
  readonly productType?: string;
  readonly tags: string[];
  readonly metadata: Record<string, unknown>;
  readonly status: 'pending' | 'completed' | 'failed' | 'rejected';
  readonly failureReason?: string;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface GenerationQuota {
  readonly userId: string;
  readonly period: 'daily' | 'monthly';
  readonly limit: number;
  readonly used: number;
  readonly remaining: number;
  readonly resetsAt: Date;
}

export interface CostSummary {
  readonly period: 'daily' | 'weekly' | 'monthly';
  readonly totalCost: number;
  readonly currency: string;
  readonly byProvider: Record<ProviderName, number>;
  readonly byModel: Record<string, number>;
  readonly generationCount: number;
  readonly averageCostPerGeneration: number;
}

// =============================================================================
// EVENT TYPES
// =============================================================================

export interface GenerationEvent {
  readonly type: 'started' | 'completed' | 'failed' | 'retrying' | 'failover';
  readonly designId: string;
  readonly provider: ProviderName;
  readonly timestamp: Date;
  readonly data?: Record<string, unknown>;
}

export type GenerationEventHandler = (event: GenerationEvent) => void | Promise<void>;

// =============================================================================
// PROVIDER HEALTH TYPES
// =============================================================================

export interface ProviderHealth {
  readonly name: ProviderName;
  readonly isHealthy: boolean;
  readonly lastCheckAt: Date;
  readonly responseTimeMs?: number;
  readonly errorRate?: number;
  readonly consecutiveFailures: number;
}

export interface ProviderStatus {
  readonly providers: ProviderHealth[];
  readonly activeProvider: ProviderName;
  readonly failoverHistory: FailoverEvent[];
}

export interface FailoverEvent {
  readonly fromProvider: ProviderName;
  readonly toProvider: ProviderName;
  readonly reason: string;
  readonly timestamp: Date;
}
