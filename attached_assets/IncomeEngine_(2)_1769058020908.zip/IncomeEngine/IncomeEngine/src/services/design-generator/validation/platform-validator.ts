/**
 * ============================================================================
 * PLATFORM VALIDATOR
 * ============================================================================
 *
 * Validates designs against platform-specific requirements.
 * Ensures images meet POD platform specifications before publishing.
 */

import {
  PlatformRequirements,
  PlatformValidationResult,
  PlatformIssue,
  ImageTransformation,
  ImageDimensions,
  AspectRatio,
  ImageFormat,
} from '../types';

// =============================================================================
// PLATFORM REQUIREMENTS
// =============================================================================

const PLATFORM_REQUIREMENTS: Record<string, PlatformRequirements> = {
  printify: {
    platform: 'printify',
    minWidth: 2400,
    minHeight: 3200,
    maxWidth: 16000,
    maxHeight: 16000,
    preferredAspectRatios: ['4:3', '3:4', '1:1'],
    allowedFormats: ['png', 'jpg'],
    maxFileSizeMB: 100,
    requiresTransparency: false,
    colorSpace: 'sRGB',
    dpi: 300,
  },
  redbubble: {
    platform: 'redbubble',
    minWidth: 2400,
    minHeight: 2400,
    maxWidth: 10000,
    maxHeight: 10000,
    preferredAspectRatios: ['1:1'],
    allowedFormats: ['png', 'jpg'],
    maxFileSizeMB: 300,
    requiresTransparency: true,
    colorSpace: 'sRGB',
  },
  teepublic: {
    platform: 'teepublic',
    minWidth: 2400,
    minHeight: 2400,
    maxWidth: 7632,
    maxHeight: 6480,
    preferredAspectRatios: ['1:1', '16:9'],
    allowedFormats: ['png'],
    maxFileSizeMB: 30,
    requiresTransparency: true,
    colorSpace: 'sRGB',
    dpi: 150,
  },
  society6: {
    platform: 'society6',
    minWidth: 3500,
    minHeight: 3500,
    maxWidth: 12000,
    maxHeight: 12000,
    preferredAspectRatios: ['1:1', '2:3', '3:2'],
    allowedFormats: ['png', 'jpg'],
    maxFileSizeMB: 150,
    requiresTransparency: false,
    colorSpace: 'sRGB',
  },
  etsy: {
    platform: 'etsy',
    minWidth: 2000,
    minHeight: 2000,
    maxWidth: 10000,
    maxHeight: 10000,
    preferredAspectRatios: ['4:3', '1:1'],
    allowedFormats: ['png', 'jpg', 'webp'],
    maxFileSizeMB: 20,
    requiresTransparency: false,
    colorSpace: 'sRGB',
  },
  gumroad: {
    platform: 'gumroad',
    minWidth: 1000,
    minHeight: 1000,
    maxWidth: 10000,
    maxHeight: 10000,
    preferredAspectRatios: ['1:1', '16:9', '4:3'],
    allowedFormats: ['png', 'jpg', 'webp'],
    maxFileSizeMB: 50,
    requiresTransparency: false,
    colorSpace: 'sRGB',
  },
  'creative-fabrica': {
    platform: 'creative-fabrica',
    minWidth: 3000,
    minHeight: 3000,
    maxWidth: 12000,
    maxHeight: 12000,
    preferredAspectRatios: ['1:1'],
    allowedFormats: ['png', 'jpg'],
    maxFileSizeMB: 100,
    requiresTransparency: true,
    colorSpace: 'sRGB',
    dpi: 300,
  },
  shopify: {
    platform: 'shopify',
    minWidth: 800,
    minHeight: 800,
    maxWidth: 4472,
    maxHeight: 4472,
    preferredAspectRatios: ['1:1'],
    allowedFormats: ['png', 'jpg', 'webp'],
    maxFileSizeMB: 20,
    requiresTransparency: false,
    colorSpace: 'sRGB',
  },
  woocommerce: {
    platform: 'woocommerce',
    minWidth: 600,
    minHeight: 600,
    maxWidth: 10000,
    maxHeight: 10000,
    preferredAspectRatios: ['1:1', '4:3'],
    allowedFormats: ['png', 'jpg', 'webp'],
    maxFileSizeMB: 50,
    requiresTransparency: false,
    colorSpace: 'sRGB',
  },
  'tiktok-shop': {
    platform: 'tiktok-shop',
    minWidth: 600,
    minHeight: 600,
    maxWidth: 5000,
    maxHeight: 5000,
    preferredAspectRatios: ['1:1', '9:16'],
    allowedFormats: ['png', 'jpg'],
    maxFileSizeMB: 5,
    requiresTransparency: false,
    colorSpace: 'sRGB',
  },
  'amazon-kdp': {
    platform: 'amazon-kdp',
    minWidth: 1600,
    minHeight: 2560,
    maxWidth: 10000,
    maxHeight: 10000,
    preferredAspectRatios: ['2:3'],
    allowedFormats: ['png', 'jpg'],
    maxFileSizeMB: 50,
    requiresTransparency: false,
    colorSpace: 'sRGB',
    dpi: 300,
  },
};

// =============================================================================
// PRODUCT-SPECIFIC REQUIREMENTS
// =============================================================================

const PRODUCT_REQUIREMENTS: Record<string, Partial<PlatformRequirements>> = {
  't-shirt': {
    minWidth: 4500,
    minHeight: 5400,
    preferredAspectRatios: ['3:4', '4:3'],
    requiresTransparency: true,
    dpi: 300,
  },
  'hoodie': {
    minWidth: 4500,
    minHeight: 5400,
    preferredAspectRatios: ['3:4'],
    requiresTransparency: true,
    dpi: 300,
  },
  'mug': {
    minWidth: 2700,
    minHeight: 1100,
    preferredAspectRatios: ['16:9'],
    requiresTransparency: false,
    dpi: 300,
  },
  'poster': {
    minWidth: 7200,
    minHeight: 10800,
    preferredAspectRatios: ['2:3', '3:4'],
    requiresTransparency: false,
    dpi: 300,
  },
  'sticker': {
    minWidth: 1800,
    minHeight: 1800,
    preferredAspectRatios: ['1:1'],
    requiresTransparency: true,
    dpi: 300,
  },
  'phone-case': {
    minWidth: 1500,
    minHeight: 3000,
    preferredAspectRatios: ['9:16'],
    requiresTransparency: false,
    dpi: 300,
  },
  'tote-bag': {
    minWidth: 4500,
    minHeight: 4500,
    preferredAspectRatios: ['1:1'],
    requiresTransparency: true,
    dpi: 300,
  },
  'book': {
    minWidth: 1600,
    minHeight: 2560,
    preferredAspectRatios: ['2:3'],
    requiresTransparency: false,
    dpi: 300,
    colorSpace: 'CMYK',
  },
  'ebook': {
    minWidth: 1600,
    minHeight: 2560,
    preferredAspectRatios: ['2:3'],
    requiresTransparency: false,
    dpi: 72,
  },
};

// =============================================================================
// PLATFORM VALIDATOR CLASS
// =============================================================================

export class PlatformValidator {
  /**
   * Validate design against platform requirements
   */
  validate(
    platform: string,
    imageInfo: {
      width: number;
      height: number;
      format: ImageFormat;
      fileSizeMB?: number;
      hasTransparency?: boolean;
    },
    productType?: string
  ): PlatformValidationResult {
    const requirements = this.getRequirements(platform, productType);

    if (!requirements) {
      return {
        valid: false,
        platform,
        issues: [
          {
            field: 'platform',
            message: `Unknown platform: ${platform}`,
            severity: 'error',
            autoFixable: false,
          },
        ],
        recommendations: [],
      };
    }

    const issues: PlatformIssue[] = [];
    const recommendations: string[] = [];
    const transformations: ImageTransformation[] = [];

    // Check dimensions
    const dimensionResult = this.validateDimensions(imageInfo, requirements);
    issues.push(...dimensionResult.issues);
    recommendations.push(...dimensionResult.recommendations);
    if (dimensionResult.transformation) {
      transformations.push(dimensionResult.transformation);
    }

    // Check format
    const formatResult = this.validateFormat(imageInfo.format, requirements);
    issues.push(...formatResult.issues);
    if (formatResult.transformation) {
      transformations.push(formatResult.transformation);
    }

    // Check file size
    if (imageInfo.fileSizeMB !== undefined) {
      const sizeResult = this.validateFileSize(imageInfo.fileSizeMB, requirements);
      issues.push(...sizeResult.issues);
      recommendations.push(...sizeResult.recommendations);
    }

    // Check transparency
    if (requirements.requiresTransparency && !imageInfo.hasTransparency) {
      issues.push({
        field: 'transparency',
        message: `${platform} requires images with transparent background`,
        severity: 'warning',
        autoFixable: true,
      });
      recommendations.push('Consider removing the background for better results');
    }

    // Check aspect ratio
    const aspectResult = this.validateAspectRatio(imageInfo, requirements);
    recommendations.push(...aspectResult.recommendations);

    const valid = issues.filter((i) => i.severity === 'error').length === 0;

    return {
      valid,
      platform,
      issues,
      recommendations,
      transformations: transformations.length > 0 ? transformations : undefined,
    };
  }

  /**
   * Validate design for multiple platforms at once
   */
  validateMultiple(
    platforms: string[],
    imageInfo: {
      width: number;
      height: number;
      format: ImageFormat;
      fileSizeMB?: number;
      hasTransparency?: boolean;
    },
    productType?: string
  ): Record<string, PlatformValidationResult> {
    const results: Record<string, PlatformValidationResult> = {};

    for (const platform of platforms) {
      results[platform] = this.validate(platform, imageInfo, productType);
    }

    return results;
  }

  /**
   * Get requirements for a platform
   */
  getRequirements(platform: string, productType?: string): PlatformRequirements | undefined {
    const platformReqs = PLATFORM_REQUIREMENTS[platform.toLowerCase()];

    if (!platformReqs) {
      return undefined;
    }

    // Merge with product-specific requirements if applicable
    if (productType && PRODUCT_REQUIREMENTS[productType.toLowerCase()]) {
      const productReqs = PRODUCT_REQUIREMENTS[productType.toLowerCase()];
      return {
        ...platformReqs,
        minWidth: Math.max(platformReqs.minWidth, productReqs.minWidth ?? 0),
        minHeight: Math.max(platformReqs.minHeight, productReqs.minHeight ?? 0),
        preferredAspectRatios: productReqs.preferredAspectRatios ?? platformReqs.preferredAspectRatios,
        requiresTransparency: productReqs.requiresTransparency ?? platformReqs.requiresTransparency,
        dpi: productReqs.dpi ?? platformReqs.dpi,
      };
    }

    return platformReqs;
  }

  /**
   * Get all supported platforms
   */
  getSupportedPlatforms(): string[] {
    return Object.keys(PLATFORM_REQUIREMENTS);
  }

  /**
   * Get all product types
   */
  getProductTypes(): string[] {
    return Object.keys(PRODUCT_REQUIREMENTS);
  }

  /**
   * Calculate recommended dimensions for a platform
   */
  getRecommendedDimensions(
    platform: string,
    productType?: string,
    aspectRatio?: AspectRatio
  ): ImageDimensions {
    const requirements = this.getRequirements(platform, productType);

    if (!requirements) {
      return { width: 4500, height: 5400 }; // Safe default
    }

    // Use preferred aspect ratio
    const ratio = aspectRatio ?? requirements.preferredAspectRatios[0] ?? '1:1';
    const [widthRatio, heightRatio] = ratio.split(':').map(Number);

    // Calculate dimensions that meet minimum requirements
    let width = requirements.minWidth;
    let height = Math.round(width * (heightRatio / widthRatio));

    // Ensure height also meets minimum
    if (height < requirements.minHeight) {
      height = requirements.minHeight;
      width = Math.round(height * (widthRatio / heightRatio));
    }

    return { width, height };
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  /**
   * Validate image dimensions
   */
  private validateDimensions(
    imageInfo: { width: number; height: number },
    requirements: PlatformRequirements
  ): {
    issues: PlatformIssue[];
    recommendations: string[];
    transformation?: ImageTransformation;
  } {
    const issues: PlatformIssue[] = [];
    const recommendations: string[] = [];
    let transformation: ImageTransformation | undefined;

    // Check minimum dimensions
    if (imageInfo.width < requirements.minWidth) {
      issues.push({
        field: 'width',
        message: `Image width ${imageInfo.width}px is below minimum ${requirements.minWidth}px`,
        severity: 'error',
        autoFixable: true,
      });
      transformation = {
        type: 'resize',
        params: { targetWidth: requirements.minWidth },
      };
    }

    if (imageInfo.height < requirements.minHeight) {
      issues.push({
        field: 'height',
        message: `Image height ${imageInfo.height}px is below minimum ${requirements.minHeight}px`,
        severity: 'error',
        autoFixable: true,
      });
      transformation = {
        type: 'resize',
        params: { targetHeight: requirements.minHeight },
      };
    }

    // Check maximum dimensions
    if (imageInfo.width > requirements.maxWidth) {
      issues.push({
        field: 'width',
        message: `Image width ${imageInfo.width}px exceeds maximum ${requirements.maxWidth}px`,
        severity: 'warning',
        autoFixable: true,
      });
      recommendations.push(`Consider resizing to ${requirements.maxWidth}px width`);
    }

    if (imageInfo.height > requirements.maxHeight) {
      issues.push({
        field: 'height',
        message: `Image height ${imageInfo.height}px exceeds maximum ${requirements.maxHeight}px`,
        severity: 'warning',
        autoFixable: true,
      });
      recommendations.push(`Consider resizing to ${requirements.maxHeight}px height`);
    }

    return { issues, recommendations, transformation };
  }

  /**
   * Validate image format
   */
  private validateFormat(
    format: ImageFormat,
    requirements: PlatformRequirements
  ): {
    issues: PlatformIssue[];
    transformation?: ImageTransformation;
  } {
    const issues: PlatformIssue[] = [];
    let transformation: ImageTransformation | undefined;

    if (!requirements.allowedFormats.includes(format)) {
      issues.push({
        field: 'format',
        message: `Format ${format} is not supported. Allowed: ${requirements.allowedFormats.join(', ')}`,
        severity: 'error',
        autoFixable: true,
      });
      transformation = {
        type: 'convert',
        params: { targetFormat: requirements.allowedFormats[0] },
      };
    }

    return { issues, transformation };
  }

  /**
   * Validate file size
   */
  private validateFileSize(
    fileSizeMB: number,
    requirements: PlatformRequirements
  ): {
    issues: PlatformIssue[];
    recommendations: string[];
  } {
    const issues: PlatformIssue[] = [];
    const recommendations: string[] = [];

    if (fileSizeMB > requirements.maxFileSizeMB) {
      issues.push({
        field: 'fileSize',
        message: `File size ${fileSizeMB.toFixed(1)}MB exceeds maximum ${requirements.maxFileSizeMB}MB`,
        severity: 'error',
        autoFixable: true,
      });
      recommendations.push('Compress the image or reduce dimensions to meet size requirements');
    }

    return { issues, recommendations };
  }

  /**
   * Validate aspect ratio
   */
  private validateAspectRatio(
    imageInfo: { width: number; height: number },
    requirements: PlatformRequirements
  ): {
    recommendations: string[];
  } {
    const recommendations: string[] = [];

    const currentRatio = imageInfo.width / imageInfo.height;
    const preferredRatios = requirements.preferredAspectRatios.map((r) => {
      const [w, h] = r.split(':').map(Number);
      return { ratio: r, value: w / h };
    });

    // Check if current ratio matches any preferred
    const matches = preferredRatios.some(
      (p) => Math.abs(currentRatio - p.value) < 0.01
    );

    if (!matches && preferredRatios.length > 0) {
      recommendations.push(
        `For best results, use one of these aspect ratios: ${requirements.preferredAspectRatios.join(', ')}`
      );
    }

    return { recommendations };
  }
}

// =============================================================================
// EXPORTS
// =============================================================================

export default PlatformValidator;

/**
 * Create a platform validator instance
 */
export function createPlatformValidator(): PlatformValidator {
  return new PlatformValidator();
}

/**
 * Quick validation check
 */
export function quickValidate(
  platform: string,
  width: number,
  height: number,
  format: ImageFormat = 'png'
): boolean {
  const validator = new PlatformValidator();
  const result = validator.validate(platform, { width, height, format });
  return result.valid;
}
