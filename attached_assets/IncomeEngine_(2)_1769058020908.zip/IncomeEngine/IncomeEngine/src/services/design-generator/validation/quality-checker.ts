/**
 * ============================================================================
 * QUALITY CHECKER
 * ============================================================================
 *
 * AI-powered quality assessment for generated designs.
 * Evaluates aesthetic quality, technical requirements, and POD suitability.
 */

import OpenAI from 'openai';
import {
  QualityCheckResult,
  QualityIssue,
  ImageDimensions,
  GenerationOptions,
} from '../types';

// =============================================================================
// TYPES
// =============================================================================

interface QualityCheckerConfig {
  readonly openaiApiKey: string;
  readonly minAestheticScore?: number;
  readonly minTechnicalScore?: number;
  readonly enableDetailedAnalysis?: boolean;
}

interface AnalysisResult {
  aesthetic: number;
  technical: number;
  relevance: number;
  originality: number;
  issues: QualityIssue[];
  suggestions: string[];
  detailedFeedback?: string;
}

// =============================================================================
// QUALITY THRESHOLDS
// =============================================================================

const DEFAULT_THRESHOLDS = {
  minAestheticScore: 0.6,
  minTechnicalScore: 0.7,
  minOverallScore: 0.65,
};

// =============================================================================
// QUALITY CHECKER CLASS
// =============================================================================

export class QualityChecker {
  private config: QualityCheckerConfig;
  private openai: OpenAI | null = null;

  constructor(supabaseUrl?: string, supabaseKey?: string, config: Partial<QualityCheckerConfig> = {}) {
    this.config = {
      openaiApiKey: config.openaiApiKey ?? process.env.OPENAI_API_KEY ?? '',
      minAestheticScore: DEFAULT_THRESHOLDS.minAestheticScore,
      minTechnicalScore: DEFAULT_THRESHOLDS.minTechnicalScore,
      enableDetailedAnalysis: false,
      ...config,
    } as QualityCheckerConfig;

    // Initialize OpenAI client if API key available
    if (this.config.openaiApiKey) {
      this.openai = new OpenAI({
        apiKey: this.config.openaiApiKey,
      });
    }
  }

  /**
   * Check quality of a generated design
   */
  async check(
    imageUrl: string,
    prompt?: string,
    options?: GenerationOptions | {
      prompt?: string;
      niche?: string;
      productType?: string;
      dimensions?: ImageDimensions;
    }
  ): Promise<QualityCheckResult> {
    // Handle different call signatures
    const checkOptions = typeof prompt === 'object'
      ? prompt
      : { prompt, ...options };

    // Check if OpenAI client is available
    if (!this.openai) {
      return {
        passed: true,
        overallScore: 0.75,
        scores: {
          aesthetic: 0.75,
          technical: 0.75,
          relevance: 0.75,
          originality: 0.75,
        },
        issues: [],
        suggestions: ['OpenAI API key not configured - using default scores'],
      };
    }

    try {
      // Analyze the image using GPT-4 Vision
      const analysis = await this.analyzeImage(imageUrl, checkOptions);

      // Calculate overall score
      const overallScore = this.calculateOverallScore(analysis);

      // Determine if passed
      const passed = this.evaluatePassCriteria(overallScore, analysis);

      return {
        passed,
        overallScore,
        scores: {
          aesthetic: analysis.aesthetic,
          technical: analysis.technical,
          relevance: analysis.relevance,
          originality: analysis.originality,
        },
        issues: analysis.issues,
        suggestions: analysis.suggestions,
      };
    } catch (error) {
      // Return a failed result on error
      return {
        passed: false,
        overallScore: 0,
        scores: {
          aesthetic: 0,
          technical: 0,
          relevance: 0,
          originality: 0,
        },
        issues: [
          {
            type: 'composition',
            severity: 'critical',
            message: `Quality check failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
            autoFixable: false,
          },
        ],
        suggestions: ['Please try generating a new design'],
      };
    }
  }

  /**
   * Quick check for obvious issues (faster, cheaper)
   */
  async quickCheck(
    imageUrl: string
  ): Promise<{ passed: boolean; issues: QualityIssue[] }> {
    if (!this.openai) {
      return { passed: true, issues: [] };
    }

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: `You are a quality control expert for print-on-demand designs.
            Quickly identify any critical issues in the image.
            Return a JSON object with:
            - passed (boolean): true if no critical issues
            - issues (array): list of critical issues found, each with type, severity, message

            Critical issues include:
            - Visible watermarks or signatures
            - Extremely blurry or pixelated
            - Inappropriate content
            - Text that shouldn't be there
            - Obvious AI artifacts (extra limbs, distorted faces)`,
          },
          {
            role: 'user',
            content: [
              { type: 'text', text: 'Check this design for critical issues:' },
              { type: 'image_url', image_url: { url: imageUrl } },
            ],
          },
        ],
        max_tokens: 500,
        response_format: { type: 'json_object' },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');

      return {
        passed: result.passed ?? false,
        issues: (result.issues || []).map((issue: Record<string, unknown>) => ({
          type: issue.type || 'composition',
          severity: issue.severity || 'high',
          message: issue.message || 'Unknown issue',
          autoFixable: false,
        })),
      };
    } catch (error) {
      return {
        passed: false,
        issues: [
          {
            type: 'composition',
            severity: 'critical',
            message: 'Failed to perform quality check',
            autoFixable: false,
          },
        ],
      };
    }
  }

  /**
   * Check if design is suitable for a specific product type
   */
  async checkForProduct(
    imageUrl: string,
    productType: string
  ): Promise<{ suitable: boolean; score: number; feedback: string }> {
    if (!this.openai) {
      return {
        suitable: true,
        score: 0.75,
        feedback: 'OpenAI not configured - using default assessment',
      };
    }

    const productRequirements: Record<string, string> = {
      't-shirt': 'Design should work on fabric, have good contrast, work in single color if needed',
      'mug': 'Design should be visible at small size, work on curved surface, avoid complex gradients',
      'poster': 'Design should be high resolution, work at large scale, have strong visual impact',
      'sticker': 'Design should have clean edges, work at small size, have transparent background potential',
      'phone-case': 'Design should fit vertical format, avoid important elements at edges',
      'tote-bag': 'Design should be simple enough for bag printing, work in limited colors',
    };

    const requirements = productRequirements[productType] || 'Design should be suitable for printing';

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are evaluating if a design is suitable for ${productType} printing.
            Requirements: ${requirements}

            Return a JSON object with:
            - suitable (boolean): true if design works for this product
            - score (number 0-1): how well it fits
            - feedback (string): brief explanation`,
          },
          {
            role: 'user',
            content: [
              { type: 'text', text: `Is this design suitable for ${productType}?` },
              { type: 'image_url', image_url: { url: imageUrl } },
            ],
          },
        ],
        max_tokens: 300,
        response_format: { type: 'json_object' },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');

      return {
        suitable: result.suitable ?? false,
        score: result.score ?? 0,
        feedback: result.feedback ?? 'Unable to evaluate',
      };
    } catch {
      return {
        suitable: false,
        score: 0,
        feedback: 'Failed to evaluate product suitability',
      };
    }
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  /**
   * Analyze image using GPT-4 Vision
   */
  private async analyzeImage(
    imageUrl: string,
    options: {
      prompt?: string;
      niche?: string;
      productType?: string;
      dimensions?: ImageDimensions;
    }
  ): Promise<AnalysisResult> {
    const contextInfo = [
      options.prompt ? `Original prompt: "${options.prompt}"` : '',
      options.niche ? `Niche: ${options.niche}` : '',
      options.productType ? `Product type: ${options.productType}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    const systemPrompt = `You are an expert quality analyst for print-on-demand designs.
Analyze the image and provide a comprehensive quality assessment.

${contextInfo ? `Context:\n${contextInfo}\n` : ''}

Return a JSON object with:
- aesthetic (number 0-1): Visual appeal, composition, color harmony
- technical (number 0-1): Sharpness, resolution quality, no artifacts
- relevance (number 0-1): How well it matches the intended purpose/prompt
- originality (number 0-1): Uniqueness, not generic stock-like
- issues (array): Any problems found, each with:
  - type: "resolution" | "blur" | "watermark" | "artifacts" | "composition" | "style" | "content"
  - severity: "low" | "medium" | "high" | "critical"
  - message: Description of the issue
  - autoFixable: boolean
- suggestions (array): Improvement recommendations
${this.config.enableDetailedAnalysis ? '- detailedFeedback (string): Comprehensive analysis' : ''}`;

    const response = await this.openai!.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: [
            { type: 'text', text: 'Analyze this design for quality:' },
            { type: 'image_url', image_url: { url: imageUrl } },
          ],
        },
      ],
      max_tokens: 1000,
      response_format: { type: 'json_object' },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');

    return {
      aesthetic: this.clampScore(result.aesthetic),
      technical: this.clampScore(result.technical),
      relevance: this.clampScore(result.relevance),
      originality: this.clampScore(result.originality),
      issues: this.parseIssues(result.issues),
      suggestions: result.suggestions || [],
      detailedFeedback: result.detailedFeedback,
    };
  }

  /**
   * Calculate overall quality score
   */
  private calculateOverallScore(analysis: AnalysisResult): number {
    // Weighted average of scores
    const weights = {
      aesthetic: 0.30,
      technical: 0.30,
      relevance: 0.25,
      originality: 0.15,
    };

    let score =
      analysis.aesthetic * weights.aesthetic +
      analysis.technical * weights.technical +
      analysis.relevance * weights.relevance +
      analysis.originality * weights.originality;

    // Penalize for issues
    const criticalIssues = analysis.issues.filter((i) => i.severity === 'critical').length;
    const highIssues = analysis.issues.filter((i) => i.severity === 'high').length;
    const mediumIssues = analysis.issues.filter((i) => i.severity === 'medium').length;

    score -= criticalIssues * 0.3;
    score -= highIssues * 0.1;
    score -= mediumIssues * 0.03;

    return Math.max(0, Math.min(1, score));
  }

  /**
   * Evaluate if the design passes quality criteria
   */
  private evaluatePassCriteria(overallScore: number, analysis: AnalysisResult): boolean {
    // Check for critical issues - instant fail
    if (analysis.issues.some((i) => i.severity === 'critical')) {
      return false;
    }

    // Check minimum thresholds
    if (overallScore < DEFAULT_THRESHOLDS.minOverallScore) {
      return false;
    }

    if (analysis.aesthetic < (this.config.minAestheticScore ?? DEFAULT_THRESHOLDS.minAestheticScore)) {
      return false;
    }

    if (analysis.technical < (this.config.minTechnicalScore ?? DEFAULT_THRESHOLDS.minTechnicalScore)) {
      return false;
    }

    return true;
  }

  /**
   * Clamp score to 0-1 range
   */
  private clampScore(value: unknown): number {
    const num = typeof value === 'number' ? value : 0.5;
    return Math.max(0, Math.min(1, num));
  }

  /**
   * Parse and validate issues array
   */
  private parseIssues(issues: unknown): QualityIssue[] {
    if (!Array.isArray(issues)) {
      return [];
    }

    return issues.map((issue: Record<string, unknown>) => ({
      type: this.validateIssueType(issue.type),
      severity: this.validateSeverity(issue.severity),
      message: String(issue.message || 'Unknown issue'),
      autoFixable: Boolean(issue.autoFixable),
    }));
  }

  /**
   * Validate issue type
   */
  private validateIssueType(type: unknown): QualityIssue['type'] {
    const validTypes: QualityIssue['type'][] = [
      'resolution',
      'blur',
      'watermark',
      'artifacts',
      'composition',
      'style',
      'content',
    ];

    if (typeof type === 'string' && validTypes.includes(type as QualityIssue['type'])) {
      return type as QualityIssue['type'];
    }

    return 'composition';
  }

  /**
   * Validate severity
   */
  private validateSeverity(severity: unknown): QualityIssue['severity'] {
    const validSeverities: QualityIssue['severity'][] = ['low', 'medium', 'high', 'critical'];

    if (typeof severity === 'string' && validSeverities.includes(severity as QualityIssue['severity'])) {
      return severity as QualityIssue['severity'];
    }

    return 'medium';
  }
}

// =============================================================================
// EXPORTS
// =============================================================================

export default QualityChecker;

/**
 * Create a quality checker with default settings
 */
export function createQualityChecker(openaiApiKey: string): QualityChecker {
  return new QualityChecker({ openaiApiKey });
}

/**
 * Create a strict quality checker for higher standards
 */
export function createStrictQualityChecker(openaiApiKey: string): QualityChecker {
  return new QualityChecker({
    openaiApiKey,
    minAestheticScore: 0.75,
    minTechnicalScore: 0.8,
    enableDetailedAnalysis: true,
  });
}
