/**
 * ============================================================================
 * BACKGROUND REMOVER
 * ============================================================================
 *
 * Background removal service for POD designs.
 * Supports Remove.bg and Replicate rembg models.
 */

import Replicate from 'replicate';
import {
  BackgroundRemovalOptions,
  BackgroundRemovalResult,
  GenerationError,
  ImageFormat,
} from '../types';

// =============================================================================
// TYPES
// =============================================================================

interface BackgroundRemoverConfig {
  readonly removeBgApiKey?: string;
  readonly replicateApiKey?: string;
  readonly defaultProvider?: 'remove-bg' | 'replicate-rembg';
  readonly timeout?: number;
}

type RemovalProvider = 'remove-bg' | 'replicate-rembg';

// =============================================================================
// PRICING
// =============================================================================

const REMOVAL_PRICING: Record<RemovalProvider, number> = {
  'remove-bg': 0.24, // Credits-based, ~$0.24 per image on pay-as-you-go
  'replicate-rembg': 0.002, // Very cheap via Replicate
};

// =============================================================================
// BACKGROUND REMOVER CLASS
// =============================================================================

export class BackgroundRemover {
  private config: BackgroundRemoverConfig;
  private replicateClient?: Replicate;

  constructor(supabaseUrl?: string, supabaseKey?: string, config: BackgroundRemoverConfig = {}) {
    this.config = {
      defaultProvider: 'replicate-rembg',
      timeout: 60000,
      ...config,
    };

    // Initialize Replicate client if API key provided
    if (config.replicateApiKey) {
      this.replicateClient = new Replicate({
        auth: config.replicateApiKey,
      });
    }
  }

  /**
   * Remove background from an image (alias for removeBackground)
   */
  async remove(
    imageUrl: string,
    options: BackgroundRemovalOptions = {}
  ): Promise<BackgroundRemovalResult> {
    return this.removeBackground(imageUrl, options);
  }

  /**
   * Remove background from an image
   */
  async removeBackground(
    imageUrl: string,
    options: BackgroundRemovalOptions = {}
  ): Promise<BackgroundRemovalResult> {
    const startTime = Date.now();
    const provider = options.provider ?? this.config.defaultProvider ?? 'replicate-rembg';

    try {
      // Route to appropriate provider
      let result: { url?: string; base64?: string };

      if (provider === 'remove-bg') {
        result = await this.removeWithRemoveBg(imageUrl, options);
      } else {
        result = await this.removeWithReplicate(imageUrl, options);
      }

      const processingTimeMs = Date.now() - startTime;

      return {
        success: true,
        originalUrl: imageUrl,
        processedUrl: result.url,
        processedBase64: result.base64,
        processingTimeMs,
        cost: REMOVAL_PRICING[provider],
      };
    } catch (error) {
      const processingTimeMs = Date.now() - startTime;

      return {
        success: false,
        originalUrl: imageUrl,
        processingTimeMs,
        cost: 0,
        error: this.mapError(error),
      };
    }
  }

  /**
   * Remove background from multiple images
   */
  async removeBackgroundBatch(
    imageUrls: string[],
    options: BackgroundRemovalOptions = {},
    concurrency: number = 3
  ): Promise<BackgroundRemovalResult[]> {
    const results: BackgroundRemovalResult[] = [];

    // Process in batches for concurrency control
    for (let i = 0; i < imageUrls.length; i += concurrency) {
      const batch = imageUrls.slice(i, i + concurrency);
      const batchResults = await Promise.all(
        batch.map((url) => this.removeBackground(url, options))
      );
      results.push(...batchResults);
    }

    return results;
  }

  /**
   * Check if background remover is available
   */
  isAvailable(): boolean {
    return !!(this.config.removeBgApiKey || this.config.replicateApiKey);
  }

  /**
   * Get available providers
   */
  getAvailableProviders(): RemovalProvider[] {
    const providers: RemovalProvider[] = [];

    if (this.config.removeBgApiKey) {
      providers.push('remove-bg');
    }

    if (this.config.replicateApiKey) {
      providers.push('replicate-rembg');
    }

    return providers;
  }

  /**
   * Estimate cost for background removal
   */
  estimateCost(provider?: RemovalProvider): number {
    const useProvider = provider ?? this.config.defaultProvider ?? 'replicate-rembg';
    return REMOVAL_PRICING[useProvider];
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  /**
   * Remove background using Remove.bg API
   */
  private async removeWithRemoveBg(
    imageUrl: string,
    options: BackgroundRemovalOptions
  ): Promise<{ url?: string; base64?: string }> {
    if (!this.config.removeBgApiKey) {
      throw new Error('Remove.bg API key not configured');
    }

    const formData = new FormData();
    formData.append('image_url', imageUrl);
    formData.append('size', 'auto');

    // Output format
    const format = options.outputFormat ?? 'png';
    formData.append('format', format);

    // Background color (if not transparent)
    if (options.backgroundColor) {
      formData.append('bg_color', options.backgroundColor);
    }

    // Crop to foreground
    if (options.crop) {
      formData.append('crop', 'true');
      if (options.margin !== undefined) {
        formData.append('crop_margin', `${options.margin}px`);
      }
    }

    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': this.config.removeBgApiKey,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(
        `Remove.bg API Error: ${errorData.errors?.[0]?.title || response.statusText}`
      );
    }

    // Get the image data
    const imageBuffer = await response.arrayBuffer();
    const base64 = Buffer.from(imageBuffer).toString('base64');

    return { base64 };
  }

  /**
   * Remove background using Replicate rembg
   */
  private async removeWithReplicate(
    imageUrl: string,
    options: BackgroundRemovalOptions
  ): Promise<{ url?: string; base64?: string }> {
    if (!this.replicateClient) {
      throw new Error('Replicate client not configured');
    }

    // Use rembg model
    const output = await this.replicateClient.run(
      'cjwbw/rembg:fb8af171cfa1616ddcf1242c093f9c46bcada5ad4cf6f2fbe8b81b330ec5c003' as `${string}/${string}:${string}`,
      {
        input: {
          image: imageUrl,
        },
      }
    );

    // Extract URL from output
    const url = typeof output === 'string' ? output : Array.isArray(output) ? output[0] : undefined;

    return { url };
  }

  /**
   * Map error to GenerationError
   */
  private mapError(error: unknown): GenerationError {
    if (error instanceof Error) {
      return {
        code: 'BACKGROUND_REMOVAL_ERROR',
        message: error.message,
        retryable: true,
        details: { name: error.name },
      };
    }

    return {
      code: 'UNKNOWN_ERROR',
      message: String(error),
      retryable: false,
    };
  }
}

// =============================================================================
// EXPORTS
// =============================================================================

export default BackgroundRemover;

/**
 * Create a background remover with Replicate (recommended for cost)
 */
export function createReplicateRemover(apiKey: string): BackgroundRemover {
  return new BackgroundRemover(undefined, undefined, {
    replicateApiKey: apiKey,
    defaultProvider: 'replicate-rembg',
  });
}

/**
 * Create a background remover with Remove.bg (higher quality)
 */
export function createRemoveBgRemover(apiKey: string): BackgroundRemover {
  return new BackgroundRemover(undefined, undefined, {
    removeBgApiKey: apiKey,
    defaultProvider: 'remove-bg',
  });
}

/**
 * Create a background remover with both providers for failover
 */
export function createDualRemover(
  replicateApiKey: string,
  removeBgApiKey: string
): BackgroundRemover {
  return new BackgroundRemover(undefined, undefined, {
    replicateApiKey,
    removeBgApiKey,
    defaultProvider: 'replicate-rembg', // Start with cheaper option
  });
}
