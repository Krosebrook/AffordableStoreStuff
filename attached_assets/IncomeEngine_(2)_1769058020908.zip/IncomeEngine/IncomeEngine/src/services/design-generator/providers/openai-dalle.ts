/**
 * ============================================================================
 * OPENAI DALL-E 3 PROVIDER
 * ============================================================================
 *
 * Integration with OpenAI's DALL-E 3 image generation API.
 * Supports high-quality image generation with natural language prompts.
 */

import OpenAI from 'openai';
import {
  ProviderName,
  ProviderConfig,
  ProviderCapabilities,
  GenerationOptions,
  GenerationResult,
  GenerationCost,
  ImageDimensions,
  ProviderHealth,
} from '../types';
import { BaseProvider } from './base-provider';

// =============================================================================
// TYPES
// =============================================================================

interface DalleConfig extends ProviderConfig {
  readonly organizationId?: string;
}

type DalleSize = '1024x1024' | '1792x1024' | '1024x1792';
type DalleQuality = 'standard' | 'hd';
type DalleStyle = 'vivid' | 'natural';

// =============================================================================
// PRICING (as of Dec 2024)
// =============================================================================

const DALLE_PRICING: Record<DalleQuality, Record<DalleSize, number>> = {
  standard: {
    '1024x1024': 0.04,
    '1792x1024': 0.08,
    '1024x1792': 0.08,
  },
  hd: {
    '1024x1024': 0.08,
    '1792x1024': 0.12,
    '1024x1792': 0.12,
  },
};

// =============================================================================
// OPENAI DALL-E PROVIDER
// =============================================================================

export class OpenAIDalleProvider extends BaseProvider {
  readonly name: ProviderName = 'openai-dalle';
  readonly displayName = 'OpenAI DALL-E 3';

  readonly capabilities: ProviderCapabilities = {
    maxWidth: 1792,
    maxHeight: 1792,
    supportedFormats: ['png', 'webp'] as const,
    supportedStyles: ['vivid', 'natural'] as const,
    supportsNegativePrompt: false, // DALL-E 3 doesn't support negative prompts directly
    supportsBatchGeneration: false, // Must call API individually
    maxBatchSize: 1,
    supportsImageToImage: false,
    supportsInpainting: false,
  };

  private client: OpenAI;

  constructor(config: DalleConfig) {
    super(config);

    this.client = new OpenAI({
      apiKey: config.apiKey,
      organization: config.organizationId,
      timeout: config.timeout ?? 120000,
      maxRetries: 0, // We handle retries ourselves
    });
  }

  /**
   * Generate an image using DALL-E 3
   */
  async generate(
    prompt: string,
    options: GenerationOptions
  ): Promise<GenerationResult> {
    const startTime = Date.now();
    const designId = this.generateDesignId();
    const metadata = this.createMetadata(options);

    try {
      // Resolve generation parameters
      const dimensions = this.resolveDimensions(options);
      const size = this.dimensionsToSize(dimensions);
      const quality = this.resolveQuality(options);
      const style = this.resolveStyle(options);

      // Enhance prompt for better results
      const enhancedPrompt = this.enhancePrompt(prompt, options);

      this.log('info', `Starting generation: ${designId}`, {
        size,
        quality,
        style,
        promptLength: enhancedPrompt.length,
      });

      // Make API request with retry
      const response = await this.executeWithRetry(async () => {
        return await this.client.images.generate({
          model: 'dall-e-3',
          prompt: enhancedPrompt,
          n: 1,
          size,
          quality,
          style,
          response_format: 'url',
        });
      });

      const generationTimeMs = Date.now() - startTime;
      const imageData = response.data[0];

      if (!imageData.url) {
        throw new Error('No image URL returned from DALL-E');
      }

      // DALL-E 3 may revise the prompt - capture it
      const revisedPrompt = imageData.revised_prompt ?? enhancedPrompt;

      this.log('info', `Generation complete: ${designId}`, {
        generationTimeMs,
        hasRevisedPrompt: !!imageData.revised_prompt,
      });

      return {
        success: true,
        designId,
        imageUrl: imageData.url,
        provider: this.name,
        model: 'dall-e-3',
        prompt,
        enhancedPrompt: revisedPrompt,
        dimensions: this.sizeToDimensions(size),
        format: 'png',
        generationTimeMs,
        cost: this.calculateCost(size, quality),
        metadata,
      };
    } catch (error) {
      const generationTimeMs = Date.now() - startTime;
      const genError = this.mapException(error);

      this.log('error', `Generation failed: ${designId}`, {
        error: genError,
        generationTimeMs,
      });

      return {
        success: false,
        designId,
        provider: this.name,
        model: 'dall-e-3',
        prompt,
        dimensions: this.resolveDimensions(options),
        format: 'png',
        generationTimeMs,
        cost: { amount: 0, currency: 'USD', provider: this.name, model: 'dall-e-3' },
        metadata,
        error: genError,
      };
    }
  }

  /**
   * Check provider health
   */
  async healthCheck(): Promise<ProviderHealth> {
    const startTime = Date.now();

    try {
      // Use models endpoint as a lightweight health check
      await this.client.models.retrieve('dall-e-3');

      this.lastHealthCheck = {
        name: this.name,
        isHealthy: true,
        lastCheckAt: new Date(),
        responseTimeMs: Date.now() - startTime,
        consecutiveFailures: 0,
      };
    } catch (error) {
      this.lastHealthCheck = {
        name: this.name,
        isHealthy: false,
        lastCheckAt: new Date(),
        responseTimeMs: Date.now() - startTime,
        consecutiveFailures: this.consecutiveFailures + 1,
      };
    }

    return this.lastHealthCheck;
  }

  /**
   * Estimate cost for generation
   */
  estimateCost(options: GenerationOptions): GenerationCost {
    const dimensions = this.resolveDimensions(options);
    const size = this.dimensionsToSize(dimensions);
    const quality = this.resolveQuality(options);

    return this.calculateCost(size, quality);
  }

  /**
   * Validate API credentials
   */
  async validateCredentials(): Promise<boolean> {
    try {
      await this.client.models.list();
      return true;
    } catch {
      return false;
    }
  }

  // ===========================================================================
  // PRIVATE HELPERS
  // ===========================================================================

  /**
   * Convert dimensions to DALL-E size string
   */
  private dimensionsToSize(dimensions: ImageDimensions): DalleSize {
    const { width, height } = dimensions;

    // DALL-E 3 only supports specific sizes
    if (width === height) {
      return '1024x1024';
    } else if (width > height) {
      return '1792x1024';
    } else {
      return '1024x1792';
    }
  }

  /**
   * Convert DALL-E size string to dimensions
   */
  private sizeToDimensions(size: DalleSize): ImageDimensions {
    const [width, height] = size.split('x').map(Number);
    return { width, height };
  }

  /**
   * Resolve quality from options
   */
  private resolveQuality(options: GenerationOptions): DalleQuality {
    return options.quality === 'hd' ? 'hd' : 'standard';
  }

  /**
   * Resolve style from options
   */
  private resolveStyle(options: GenerationOptions): DalleStyle {
    if (options.style === 'natural') {
      return 'natural';
    }
    return 'vivid'; // Default to vivid for more striking POD designs
  }

  /**
   * Enhance prompt for better POD design results
   */
  private enhancePrompt(prompt: string, options: GenerationOptions): string {
    const enhancements: string[] = [];

    // Add style context for POD
    if (options.productType) {
      enhancements.push(
        `Design suitable for ${options.productType} product printing`
      );
    }

    // Add niche context
    if (options.niche) {
      enhancements.push(`Style: ${options.niche}`);
    }

    // Combine with original prompt
    let enhanced = prompt;

    if (enhancements.length > 0) {
      enhanced = `${prompt}. ${enhancements.join('. ')}.`;
    }

    // Add technical requirements for POD
    enhanced += ' High resolution, clean edges, suitable for merchandise printing.';

    // Ensure no text generation issues
    if (!prompt.toLowerCase().includes('no text')) {
      enhanced += ' No text or words unless specifically requested.';
    }

    return enhanced;
  }

  /**
   * Calculate generation cost
   */
  private calculateCost(size: DalleSize, quality: DalleQuality): GenerationCost {
    const amount = DALLE_PRICING[quality][size];

    return {
      amount,
      currency: 'USD',
      provider: this.name,
      model: 'dall-e-3',
      breakdown: {
        basePrice: DALLE_PRICING.standard['1024x1024'],
        qualityMultiplier: quality === 'hd' ? 2 : 1,
        sizeMultiplier: size === '1024x1024' ? 1 : 2,
      },
    };
  }
}

export default OpenAIDalleProvider;
