/**
 * ============================================================================
 * BASE PROVIDER ABSTRACT CLASS
 * ============================================================================
 *
 * Abstract base class for all AI image generation providers.
 * Provides common functionality and enforces consistent interface.
 */

import {
  ProviderName,
  ProviderConfig,
  ProviderCapabilities,
  GenerationOptions,
  GenerationResult,
  GenerationError,
  GenerationCost,
  GenerationMetadata,
  ImageDimensions,
  ImageFormat,
  ImageSize,
  AspectRatio,
  ProviderHealth,
} from '../types';

// =============================================================================
// CONSTANTS
// =============================================================================

const SIZE_PRESETS: Record<ImageSize, ImageDimensions> = {
  small: { width: 512, height: 512 },
  medium: { width: 1024, height: 1024 },
  large: { width: 1536, height: 1536 },
  xlarge: { width: 2048, height: 2048 },
};

const ASPECT_RATIO_DIMENSIONS: Record<AspectRatio, ImageDimensions> = {
  '1:1': { width: 1024, height: 1024 },
  '16:9': { width: 1792, height: 1024 },
  '9:16': { width: 1024, height: 1792 },
  '4:3': { width: 1365, height: 1024 },
  '3:4': { width: 1024, height: 1365 },
  '3:2': { width: 1536, height: 1024 },
  '2:3': { width: 1024, height: 1536 },
};

// =============================================================================
// ABSTRACT BASE PROVIDER
// =============================================================================

export abstract class BaseProvider {
  // Identity - must be implemented by each provider
  abstract readonly name: ProviderName;
  abstract readonly displayName: string;
  abstract readonly capabilities: ProviderCapabilities;

  // Configuration
  protected config: ProviderConfig;
  protected lastHealthCheck: ProviderHealth | null = null;
  protected consecutiveFailures: number = 0;
  protected lastRequestTime: number = 0;

  constructor(config: ProviderConfig) {
    this.config = {
      timeout: 120000, // 2 minutes default for image generation
      maxRetries: 2,
      ...config,
    };
  }

  // ===========================================================================
  // ABSTRACT METHODS - Must be implemented by each provider
  // ===========================================================================

  /**
   * Generate an image using this provider
   */
  abstract generate(
    prompt: string,
    options: GenerationOptions
  ): Promise<GenerationResult>;

  /**
   * Check if the provider is healthy and available
   */
  abstract healthCheck(): Promise<ProviderHealth>;

  /**
   * Get the cost estimate for a generation
   */
  abstract estimateCost(options: GenerationOptions): GenerationCost;

  /**
   * Validate credentials and API access
   */
  abstract validateCredentials(): Promise<boolean>;

  // ===========================================================================
  // COMMON METHODS
  // ===========================================================================

  /**
   * Check if provider is currently available for use
   */
  isAvailable(): boolean {
    return (
      this.config.isEnabled &&
      this.consecutiveFailures < 5 &&
      (this.lastHealthCheck?.isHealthy ?? true)
    );
  }

  /**
   * Get the provider priority for failover ordering
   */
  getPriority(): number {
    return this.config.priority;
  }

  /**
   * Record a successful generation
   */
  protected recordSuccess(): void {
    this.consecutiveFailures = 0;
  }

  /**
   * Record a failed generation
   */
  protected recordFailure(): void {
    this.consecutiveFailures++;
  }

  /**
   * Get provider health status
   */
  getHealth(): ProviderHealth {
    return (
      this.lastHealthCheck ?? {
        name: this.name,
        isHealthy: true,
        lastCheckAt: new Date(),
        consecutiveFailures: this.consecutiveFailures,
      }
    );
  }

  // ===========================================================================
  // UTILITY METHODS
  // ===========================================================================

  /**
   * Resolve dimensions from various option formats
   */
  protected resolveDimensions(options: GenerationOptions): ImageDimensions {
    // Explicit dimensions take priority
    if (options.dimensions) {
      return this.clampDimensions(options.dimensions);
    }

    // Then aspect ratio
    if (options.aspectRatio) {
      return this.clampDimensions(ASPECT_RATIO_DIMENSIONS[options.aspectRatio]);
    }

    // Then size preset
    if (options.size) {
      return this.clampDimensions(SIZE_PRESETS[options.size]);
    }

    // Default to medium square
    return this.clampDimensions(SIZE_PRESETS.medium);
  }

  /**
   * Clamp dimensions to provider limits
   */
  protected clampDimensions(dimensions: ImageDimensions): ImageDimensions {
    const { maxWidth, maxHeight } = this.capabilities;

    return {
      width: Math.min(dimensions.width, maxWidth),
      height: Math.min(dimensions.height, maxHeight),
    };
  }

  /**
   * Validate that dimensions are supported
   */
  protected validateDimensions(dimensions: ImageDimensions): boolean {
    const { maxWidth, maxHeight } = this.capabilities;

    return dimensions.width <= maxWidth && dimensions.height <= maxHeight;
  }

  /**
   * Resolve output format
   */
  protected resolveFormat(options: GenerationOptions): ImageFormat {
    const format = options.format ?? 'png';

    if (!this.capabilities.supportedFormats.includes(format)) {
      return this.capabilities.supportedFormats[0];
    }

    return format;
  }

  /**
   * Create generation metadata
   */
  protected createMetadata(options: GenerationOptions): GenerationMetadata {
    return {
      requestId: this.generateRequestId(),
      timestamp: new Date(),
      niche: options.niche,
      productType: options.productType,
      tags: options.tags,
      seed: options.seed,
      steps: options.steps,
      guidanceScale: options.guidanceScale,
      templateId: undefined,
    };
  }

  /**
   * Create a generation error
   */
  protected createError(
    code: string,
    message: string,
    retryable: boolean = false,
    details?: Record<string, unknown>
  ): GenerationError {
    return {
      code,
      message,
      provider: this.name,
      retryable,
      details,
    };
  }

  /**
   * Map HTTP error to generation error
   */
  protected mapHttpError(status: number, body: unknown): GenerationError {
    const message =
      typeof body === 'object' && body !== null
        ? (body as Record<string, unknown>).error ||
          (body as Record<string, unknown>).message ||
          'Unknown error'
        : String(body);

    // Determine error code and retryability
    let code: string;
    let retryable: boolean;

    switch (status) {
      case 400:
        code = 'INVALID_REQUEST';
        retryable = false;
        break;
      case 401:
        code = 'AUTHENTICATION_FAILED';
        retryable = false;
        break;
      case 403:
        code = 'FORBIDDEN';
        retryable = false;
        break;
      case 404:
        code = 'NOT_FOUND';
        retryable = false;
        break;
      case 429:
        code = 'RATE_LIMITED';
        retryable = true;
        break;
      case 500:
      case 502:
      case 503:
      case 504:
        code = 'SERVER_ERROR';
        retryable = true;
        break;
      default:
        code = `HTTP_${status}`;
        retryable = status >= 500;
    }

    return {
      code,
      message: String(message),
      provider: this.name,
      retryable,
      details: { status, body },
    };
  }

  /**
   * Map exception to generation error
   */
  protected mapException(error: unknown): GenerationError {
    if (error instanceof Error) {
      const isTimeout =
        error.message.includes('timeout') || error.name === 'AbortError';
      const isNetwork =
        error.message.includes('network') ||
        error.message.includes('ECONNREFUSED');

      return {
        code: isTimeout ? 'TIMEOUT' : isNetwork ? 'NETWORK_ERROR' : 'UNKNOWN',
        message: error.message,
        provider: this.name,
        retryable: isTimeout || isNetwork,
        details: { name: error.name, stack: error.stack },
      };
    }

    return {
      code: 'UNKNOWN',
      message: String(error),
      provider: this.name,
      retryable: false,
    };
  }

  /**
   * Generate unique request ID
   */
  protected generateRequestId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 10);
    return `${this.name}-${timestamp}-${random}`;
  }

  /**
   * Generate unique design ID
   */
  protected generateDesignId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 12);
    return `design-${timestamp}-${random}`;
  }

  /**
   * Sleep for specified milliseconds
   */
  protected sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Calculate retry delay with exponential backoff
   */
  protected calculateRetryDelay(attempt: number, baseDelay: number = 1000): number {
    // Exponential backoff: 1s, 2s, 4s, 8s... with jitter
    const exponentialDelay = baseDelay * Math.pow(2, attempt);
    const jitter = Math.random() * 1000;
    return Math.min(exponentialDelay + jitter, 30000); // Max 30 seconds
  }

  /**
   * Execute with retry logic
   */
  protected async executeWithRetry<T>(
    operation: () => Promise<T>,
    maxRetries: number = this.config.maxRetries ?? 2
  ): Promise<T> {
    let lastError: Error | undefined;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const result = await operation();
        this.recordSuccess();
        return result;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));

        // Check if error is retryable
        const genError = this.mapException(error);
        if (!genError.retryable || attempt >= maxRetries) {
          this.recordFailure();
          throw error;
        }

        // Wait before retry
        const delay = this.calculateRetryDelay(attempt);
        await this.sleep(delay);
      }
    }

    throw lastError;
  }

  /**
   * Log operation for debugging
   */
  protected log(
    level: 'debug' | 'info' | 'warn' | 'error',
    message: string,
    data?: unknown
  ): void {
    const prefix = `[${this.displayName}]`;
    const logData = data ? JSON.stringify(data, null, 2) : '';

    switch (level) {
      case 'debug':
        console.debug(`${prefix} ${message}`, logData);
        break;
      case 'info':
        console.info(`${prefix} ${message}`, logData);
        break;
      case 'warn':
        console.warn(`${prefix} ${message}`, logData);
        break;
      case 'error':
        console.error(`${prefix} ${message}`, logData);
        break;
    }
  }
}

export default BaseProvider;
