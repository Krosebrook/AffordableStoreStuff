#!/usr/bin/env node

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config({ path: '../.env' });

// Initialize Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_KEY || ''
);

// Import tools
import { platformTools, handlePlatformTool } from './tools/platforms.js';
import { productTools, handleProductTool } from './tools/products.js';
import { analyticsTools, handleAnalyticsTool } from './tools/analytics.js';
import { safeguardTools, handleSafeguardTool } from './tools/safeguards.js';
import { workflowTools, handleWorkflowTool } from './tools/workflows.js';

// Import resources
import { getResourceList, readResource } from './resources/index.js';

// Combine all tools
const allTools = [
  ...platformTools,
  ...productTools,
  ...analyticsTools,
  ...safeguardTools,
  ...workflowTools,
];

// Create MCP server
const server = new Server(
  {
    name: 'income-engine',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
      resources: {},
    },
  }
);

// Handle list tools request
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return { tools: allTools };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    // Route to appropriate handler
    if (platformTools.some((t) => t.name === name)) {
      return await handlePlatformTool(name, args, supabase);
    }
    if (productTools.some((t) => t.name === name)) {
      return await handleProductTool(name, args, supabase);
    }
    if (analyticsTools.some((t) => t.name === name)) {
      return await handleAnalyticsTool(name, args, supabase);
    }
    if (safeguardTools.some((t) => t.name === name)) {
      return await handleSafeguardTool(name, args, supabase);
    }
    if (workflowTools.some((t) => t.name === name)) {
      return await handleWorkflowTool(name, args, supabase);
    }

    throw new Error(`Unknown tool: ${name}`);
  } catch (error) {
    return {
      content: [
        {
          type: 'text',
          text: `Error: ${error.message}`,
        },
      ],
      isError: true,
    };
  }
});

// Handle list resources request
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return { resources: getResourceList() };
});

// Handle read resource request
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;
  return await readResource(uri, supabase);
});

// Test mode
if (process.argv.includes('--test')) {
  console.log('Income Engine MCP Server - Test Mode');
  console.log('Available tools:', allTools.map((t) => t.name).join(', '));
  console.log('Available resources:', getResourceList().map((r) => r.uri).join(', '));
  console.log('Supabase configured:', !!process.env.SUPABASE_URL);
  process.exit(0);
}

// Start server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('Income Engine MCP Server running on stdio');
}

main().catch((error) => {
  console.error('Server error:', error);
  process.exit(1);
});
