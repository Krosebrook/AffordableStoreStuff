/**
 * Platform management tools for MCP server
 */

export const platformTools = [
  {
    name: 'list_platforms',
    description: 'Get all connected platforms with their status',
    inputSchema: {
      type: 'object',
      properties: {},
      required: [],
    },
  },
  {
    name: 'connect_platform',
    description: 'Initiate connection to a platform',
    inputSchema: {
      type: 'object',
      properties: {
        platform: {
          type: 'string',
          description: 'Platform name (printify, etsy, gumroad, shopify, etc.)',
          enum: [
            'printify',
            'etsy',
            'teepublic',
            'society6',
            'redbubble',
            'gumroad',
            'creative-fabrica',
            'amazon-kdp',
            'shopify',
            'woocommerce',
            'tiktok-shop',
          ],
        },
        credentials: {
          type: 'object',
          description: 'Platform-specific credentials',
        },
      },
      required: ['platform'],
    },
  },
];

export async function handlePlatformTool(name, args, supabase) {
  switch (name) {
    case 'list_platforms':
      return await listPlatforms(supabase);
    case 'connect_platform':
      return await connectPlatform(args.platform, args.credentials, supabase);
    default:
      throw new Error(`Unknown platform tool: ${name}`);
  }
}

async function listPlatforms(supabase) {
  const { data, error } = await supabase
    .from('platform_connections')
    .select('*')
    .order('platform_name');

  if (error) {
    throw new Error(`Failed to fetch platforms: ${error.message}`);
  }

  const platforms = data.map((p) => ({
    name: p.platform_name,
    status: p.is_active ? 'connected' : 'disconnected',
    lastSync: p.last_sync_at,
    expiresAt: p.token_expires_at,
  }));

  // Check for expiring tokens
  const now = new Date();
  const fiveDaysFromNow = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);

  platforms.forEach((p) => {
    if (p.expiresAt && new Date(p.expiresAt) < fiveDaysFromNow) {
      p.status = 'token_expiring';
      const daysUntilExpiry = Math.ceil(
        (new Date(p.expiresAt) - now) / (24 * 60 * 60 * 1000)
      );
      p.expiresIn = `${daysUntilExpiry} days`;
    }
  });

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify({ platforms }, null, 2),
      },
    ],
  };
}

async function connectPlatform(platform, credentials, supabase) {
  // Check if platform already exists
  const { data: existing } = await supabase
    .from('platform_connections')
    .select('id')
    .eq('platform_name', platform)
    .single();

  if (existing) {
    // Update existing connection
    const { error } = await supabase
      .from('platform_connections')
      .update({
        credentials: credentials || {},
        is_active: true,
        updated_at: new Date().toISOString(),
      })
      .eq('platform_name', platform);

    if (error) {
      throw new Error(`Failed to update platform: ${error.message}`);
    }

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Platform ${platform} connection updated`,
            action: 'updated',
          }),
        },
      ],
    };
  }

  // Create new connection
  const { error } = await supabase.from('platform_connections').insert({
    platform_name: platform,
    credentials: credentials || {},
    is_active: true,
    created_at: new Date().toISOString(),
  });

  if (error) {
    throw new Error(`Failed to connect platform: ${error.message}`);
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify({
          success: true,
          message: `Platform ${platform} connected successfully`,
          action: 'created',
        }),
      },
    ],
  };
}
