/**
 * Analytics tools for MCP server
 */

export const analyticsTools = [
  {
    name: 'get_analytics',
    description: 'Retrieve performance metrics for platforms',
    inputSchema: {
      type: 'object',
      properties: {
        platform: {
          type: 'string',
          description: 'Platform name or "all" for aggregate',
        },
        period: {
          type: 'string',
          description: 'Time period for metrics',
          enum: ['today', 'week', 'month', 'year'],
        },
        metrics: {
          type: 'array',
          description: 'Metrics to include',
          items: {
            type: 'string',
            enum: ['revenue', 'orders', 'views', 'conversion'],
          },
        },
      },
      required: ['period'],
    },
  },
];

export async function handleAnalyticsTool(name, args, supabase) {
  switch (name) {
    case 'get_analytics':
      return await getAnalytics(
        args.platform || 'all',
        args.period,
        args.metrics || ['revenue', 'orders', 'views'],
        supabase
      );
    default:
      throw new Error(`Unknown analytics tool: ${name}`);
  }
}

function getPeriodDates(period) {
  const now = new Date();
  let startDate;

  switch (period) {
    case 'today':
      startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      break;
    case 'week':
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    case 'month':
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      break;
    case 'year':
      startDate = new Date(now.getFullYear(), 0, 1);
      break;
    default:
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  }

  return { startDate, endDate: now };
}

async function getAnalytics(platform, period, metrics, supabase) {
  const { startDate, endDate } = getPeriodDates(period);

  // Fetch orders for revenue and order counts
  let ordersQuery = supabase
    .from('orders')
    .select('platform, total_amount, created_at')
    .gte('created_at', startDate.toISOString())
    .lte('created_at', endDate.toISOString());

  if (platform !== 'all') {
    ordersQuery = ordersQuery.eq('platform', platform);
  }

  const { data: orders, error: ordersError } = await ordersQuery;

  if (ordersError) {
    throw new Error(`Failed to fetch orders: ${ordersError.message}`);
  }

  // Fetch views if requested
  let views = 0;
  if (metrics.includes('views')) {
    let viewsQuery = supabase
      .from('product_views')
      .select('view_count')
      .gte('created_at', startDate.toISOString())
      .lte('created_at', endDate.toISOString());

    if (platform !== 'all') {
      viewsQuery = viewsQuery.eq('platform', platform);
    }

    const { data: viewsData } = await viewsQuery;
    views = viewsData?.reduce((sum, v) => sum + (v.view_count || 0), 0) || 0;
  }

  // Calculate metrics
  const totalRevenue = orders.reduce((sum, o) => sum + (o.total_amount || 0), 0);
  const totalOrders = orders.length;

  // Group by platform
  const byPlatform = {};
  orders.forEach((order) => {
    if (!byPlatform[order.platform]) {
      byPlatform[order.platform] = { revenue: 0, orders: 0 };
    }
    byPlatform[order.platform].revenue += order.total_amount || 0;
    byPlatform[order.platform].orders += 1;
  });

  const result = {
    period,
    dateRange: {
      start: startDate.toISOString(),
      end: endDate.toISOString(),
    },
  };

  if (metrics.includes('revenue')) {
    result.revenue = Math.round(totalRevenue * 100) / 100;
  }
  if (metrics.includes('orders')) {
    result.orders = totalOrders;
  }
  if (metrics.includes('views')) {
    result.views = views;
  }
  if (metrics.includes('conversion') && views > 0) {
    result.conversionRate = Math.round((totalOrders / views) * 10000) / 100;
  }

  if (platform === 'all') {
    result.byPlatform = byPlatform;
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify(result, null, 2),
      },
    ],
  };
}
