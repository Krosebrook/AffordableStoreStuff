/**
 * Budget status resource
 */

export async function getBudgetCurrent(supabase) {
  // Get budget tracking data
  const { data: budget, error: budgetError } = await supabase
    .from('budget_tracking')
    .select('*')
    .single();

  if (budgetError && budgetError.code !== 'PGRST116') {
    throw new Error(`Failed to fetch budget: ${budgetError.message}`);
  }

  // Get today's API costs
  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());

  const { data: todayCosts } = await supabase
    .from('api_costs')
    .select('provider, cost')
    .gte('created_at', todayStart.toISOString());

  // Get this month's costs
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

  const { data: monthCosts } = await supabase
    .from('api_costs')
    .select('provider, cost')
    .gte('created_at', monthStart.toISOString());

  // Calculate totals
  const todayTotal = (todayCosts || []).reduce((sum, c) => sum + (c.cost || 0), 0);
  const monthTotal = (monthCosts || []).reduce((sum, c) => sum + (c.cost || 0), 0);

  // Cost breakdown by provider
  const byProvider = {};
  (monthCosts || []).forEach((cost) => {
    if (!byProvider[cost.provider]) {
      byProvider[cost.provider] = 0;
    }
    byProvider[cost.provider] += cost.cost || 0;
  });

  // Get limits from env or defaults
  const dailyLimit = parseFloat(process.env.MAX_DAILY_AI_SPEND) || 5.0;
  const monthlyLimit = parseFloat(process.env.MAX_MONTHLY_BUDGET) || 150.0;
  const warningThreshold = parseFloat(process.env.BUDGET_WARNING_THRESHOLD) || 0.75;
  const criticalThreshold = parseFloat(process.env.BUDGET_CRITICAL_THRESHOLD) || 0.9;

  // Calculate status
  const dailyUsage = todayTotal / dailyLimit;
  const monthlyUsage = monthTotal / monthlyLimit;

  let status = 'healthy';
  let alerts = [];

  if (dailyUsage >= criticalThreshold) {
    status = 'critical';
    alerts.push('Daily budget critically low');
  } else if (dailyUsage >= warningThreshold) {
    status = 'warning';
    alerts.push('Daily budget running low');
  }

  if (monthlyUsage >= criticalThreshold) {
    status = 'critical';
    alerts.push('Monthly budget critically low');
  } else if (monthlyUsage >= warningThreshold && status !== 'critical') {
    status = 'warning';
    alerts.push('Monthly budget running low');
  }

  const budgetStatus = {
    status,
    alerts,
    today: {
      spent: Math.round(todayTotal * 100) / 100,
      limit: dailyLimit,
      remaining: Math.round((dailyLimit - todayTotal) * 100) / 100,
      usagePercent: Math.round(dailyUsage * 100),
    },
    thisMonth: {
      spent: Math.round(monthTotal * 100) / 100,
      limit: monthlyLimit,
      remaining: Math.round((monthlyLimit - monthTotal) * 100) / 100,
      usagePercent: Math.round(monthlyUsage * 100),
    },
    byProvider: Object.entries(byProvider)
      .map(([provider, cost]) => ({
        provider,
        cost: Math.round(cost * 100) / 100,
      }))
      .sort((a, b) => b.cost - a.cost),
    thresholds: {
      warning: `${warningThreshold * 100}%`,
      critical: `${criticalThreshold * 100}%`,
    },
  };

  return {
    contents: [
      {
        uri: 'budget://current',
        mimeType: 'application/json',
        text: JSON.stringify(budgetStatus, null, 2),
      },
    ],
  };
}
