/**
 * MCP Resources - Read-only data endpoints
 */

import { getPlatformsStatus } from './platforms-status.js';
import { getProductsPending } from './products-pending.js';
import { getAnalyticsDashboard } from './analytics-dashboard.js';
import { getBudgetCurrent } from './budget-current.js';

const resources = [
  {
    uri: 'platforms://status',
    name: 'Platform Status',
    description: 'Current status of all connected platforms',
    mimeType: 'application/json',
  },
  {
    uri: 'products://pending',
    name: 'Pending Products',
    description: 'Products awaiting approval or processing',
    mimeType: 'application/json',
  },
  {
    uri: 'analytics://dashboard',
    name: 'Dashboard Summary',
    description: 'Overview metrics for the dashboard',
    mimeType: 'application/json',
  },
  {
    uri: 'budget://current',
    name: 'Budget Status',
    description: 'Current budget utilization and limits',
    mimeType: 'application/json',
  },
];

export function getResourceList() {
  return resources;
}

export async function readResource(uri, supabase) {
  switch (uri) {
    case 'platforms://status':
      return await getPlatformsStatus(supabase);
    case 'products://pending':
      return await getProductsPending(supabase);
    case 'analytics://dashboard':
      return await getAnalyticsDashboard(supabase);
    case 'budget://current':
      return await getBudgetCurrent(supabase);
    default:
      throw new Error(`Unknown resource: ${uri}`);
  }
}
