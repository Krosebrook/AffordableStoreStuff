/**
 * Platforms status resource
 */

export async function getPlatformsStatus(supabase) {
  const { data, error } = await supabase
    .from('platform_connections')
    .select('*')
    .order('platform_name');

  if (error) {
    throw new Error(`Failed to fetch platform status: ${error.message}`);
  }

  const now = new Date();
  const platforms = (data || []).map((p) => {
    const status = {
      name: p.platform_name,
      isActive: p.is_active,
      lastSync: p.last_sync_at,
      health: 'healthy',
    };

    // Check token expiry
    if (p.token_expires_at) {
      const expiresAt = new Date(p.token_expires_at);
      const daysUntilExpiry = Math.ceil((expiresAt - now) / (24 * 60 * 60 * 1000));

      if (daysUntilExpiry <= 0) {
        status.health = 'expired';
        status.action = 'Reauthorize immediately';
      } else if (daysUntilExpiry <= 5) {
        status.health = 'expiring_soon';
        status.expiresIn = `${daysUntilExpiry} days`;
        status.action = 'Reauthorize soon';
      }
    }

    // Check last sync
    if (p.last_sync_at) {
      const lastSync = new Date(p.last_sync_at);
      const hoursSinceSync = (now - lastSync) / (60 * 60 * 1000);

      if (hoursSinceSync > 24) {
        status.syncStatus = 'stale';
      } else {
        status.syncStatus = 'recent';
      }
    }

    return status;
  });

  // Summary
  const summary = {
    total: platforms.length,
    healthy: platforms.filter((p) => p.health === 'healthy').length,
    needsAttention: platforms.filter((p) => p.health !== 'healthy').length,
    active: platforms.filter((p) => p.isActive).length,
  };

  return {
    contents: [
      {
        uri: 'platforms://status',
        mimeType: 'application/json',
        text: JSON.stringify({ summary, platforms }, null, 2),
      },
    ],
  };
}
