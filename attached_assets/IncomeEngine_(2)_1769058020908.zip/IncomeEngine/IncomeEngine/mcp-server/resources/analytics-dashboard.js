/**
 * Analytics dashboard resource
 */

export async function getAnalyticsDashboard(supabase) {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  // Today's metrics
  const { data: todayOrders } = await supabase
    .from('orders')
    .select('total_amount, platform')
    .gte('created_at', todayStart.toISOString());

  // This week's metrics
  const { data: weekOrders } = await supabase
    .from('orders')
    .select('total_amount, platform')
    .gte('created_at', weekStart.toISOString());

  // This month's metrics
  const { data: monthOrders } = await supabase
    .from('orders')
    .select('total_amount, platform')
    .gte('created_at', monthStart.toISOString());

  // Product counts
  const { count: totalProducts } = await supabase
    .from('products')
    .select('*', { count: 'exact', head: true });

  const { count: activeProducts } = await supabase
    .from('products')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'active');

  // Calculate totals
  const calcMetrics = (orders) => ({
    revenue: orders?.reduce((sum, o) => sum + (o.total_amount || 0), 0) || 0,
    orders: orders?.length || 0,
  });

  const today = calcMetrics(todayOrders);
  const week = calcMetrics(weekOrders);
  const month = calcMetrics(monthOrders);

  // Platform breakdown for the month
  const platformBreakdown = {};
  (monthOrders || []).forEach((order) => {
    if (!platformBreakdown[order.platform]) {
      platformBreakdown[order.platform] = { revenue: 0, orders: 0 };
    }
    platformBreakdown[order.platform].revenue += order.total_amount || 0;
    platformBreakdown[order.platform].orders += 1;
  });

  // Top platforms
  const topPlatforms = Object.entries(platformBreakdown)
    .sort((a, b) => b[1].revenue - a[1].revenue)
    .slice(0, 5)
    .map(([name, data]) => ({ name, ...data }));

  const dashboard = {
    generatedAt: now.toISOString(),
    today: {
      revenue: Math.round(today.revenue * 100) / 100,
      orders: today.orders,
    },
    thisWeek: {
      revenue: Math.round(week.revenue * 100) / 100,
      orders: week.orders,
    },
    thisMonth: {
      revenue: Math.round(month.revenue * 100) / 100,
      orders: month.orders,
    },
    products: {
      total: totalProducts || 0,
      active: activeProducts || 0,
    },
    topPlatforms,
  };

  return {
    contents: [
      {
        uri: 'analytics://dashboard',
        mimeType: 'application/json',
        text: JSON.stringify(dashboard, null, 2),
      },
    ],
  };
}
