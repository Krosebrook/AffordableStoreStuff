# Contributing to Income Engine

Thank you for your interest in contributing to Income Engine! This document provides guidelines and standards for contributions.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Code Standards](#code-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)
- [Testing Requirements](#testing-requirements)

## Code of Conduct

Be respectful, inclusive, and constructive. We're building something together.

## Getting Started

1. Fork the repository
2. Clone your fork locally
3. Create a feature branch from `main`
4. Make your changes
5. Submit a pull request

## Development Setup

### Prerequisites

- Node.js 20+
- npm or pnpm
- Supabase account (for database)
- Platform API keys (as needed)

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/IncomeEngine.git
cd IncomeEngine

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Configure your environment variables
# Edit .env with your credentials

# Start development server
npm run dev
```

### MCP Server Development

```bash
cd mcp-server
npm install
node index.js --test
```

## Code Standards

### TypeScript

- **Strict mode**: Always enabled
- **Interfaces over types**: Use `interface` for object shapes
- **No `any`**: Use `unknown` instead, then narrow with type guards
- **Readonly**: Use for immutable data

```typescript
// Good
interface ProductConfig {
  readonly id: string;
  title: string;
  metadata?: Record<string, unknown>;
}

// Bad
type ProductConfig = {
  id: any;
  title: string;
  metadata?: any;
}
```

### React Components

- Functional components only
- Use `memo()` for expensive renders
- Extract hooks to `src/client/hooks/`
- Use ErrorBoundary for error handling

```typescript
// Good
export const ProductCard = memo(function ProductCard({ product }: Props) {
  const { data, isLoading } = useProduct(product.id);
  // ...
});

// Bad
export class ProductCard extends React.Component {
  // ...
}
```

### Naming Conventions

| Type | Convention | Example |
|------|------------|---------|
| Files (utilities) | kebab-case | `rate-limiter.ts` |
| Files (components) | PascalCase | `ProductCard.tsx` |
| Components | PascalCase | `ProductCard` |
| Hooks | useCamelCase | `useProductQuery` |
| Interfaces | PascalCase | `ProductInput` |
| Constants | SCREAMING_SNAKE | `MAX_RETRIES` |

### File Organization

```
src/
├── client/
│   ├── components/    # Reusable UI components
│   ├── pages/         # Route-level components
│   ├── hooks/         # Custom React hooks
│   ├── lib/           # Utilities
│   └── types/         # TypeScript types
├── server/
│   └── index.ts       # Express API server
├── safeguards/        # Safeguard modules
└── connectors/
    ├── adapters/      # Platform adapters
    ├── core/          # Base classes and types
    ├── utils/         # Utilities
    └── workflows/     # Workflow engines
```

## Commit Guidelines

We use [Conventional Commits](https://www.conventionalcommits.org/).

### Format

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

### Types

| Type | Description |
|------|-------------|
| `feat` | New feature |
| `fix` | Bug fix |
| `docs` | Documentation only |
| `style` | Code style (formatting, semicolons) |
| `refactor` | Code refactoring |
| `perf` | Performance improvement |
| `test` | Adding or updating tests |
| `chore` | Maintenance tasks |

### Examples

```bash
feat(connectors): add TikTok Shop adapter
fix(kdp): resolve 2FA authentication issue
docs(readme): update installation instructions
refactor(safeguards): extract rate limit logic
test(quality-gate): add edge case coverage
```

## Pull Request Process

### Before Submitting

1. **Test locally**: Run `npm run test` and ensure all tests pass
2. **Lint your code**: Run `npm run lint`
3. **Update documentation**: If your change affects behavior
4. **Add tests**: For new features or bug fixes

### PR Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] Manual testing completed

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] No new warnings introduced
```

### Review Process

1. Create PR against `main` branch
2. Automated tests must pass
3. At least one maintainer review required
4. Address feedback promptly
5. Squash and merge when approved

## Testing Requirements

### Unit Tests

- Use Vitest (`npm run test`)
- Test files co-located with source (`*.test.ts`)
- Aim for 80%+ coverage on new code

```typescript
import { describe, it, expect, vi } from 'vitest';
import { RateLimiter } from './rate-limiter';

describe('RateLimiter', () => {
  it('should allow requests under limit', async () => {
    const limiter = new RateLimiter({ requestsPerMinute: 10 });
    const result = await limiter.checkLimit('test-api');
    expect(result.allowed).toBe(true);
  });
});
```

### Integration Tests

- Test connector workflows end-to-end
- Use test/mock credentials
- Clean up test data after runs

### Test Commands

```bash
# Run all tests
npm run test

# Run specific test file
npm run test -- rate-limiter

# Run with coverage
npm run test -- --coverage

# Watch mode
npm run test:watch
```

## Adding a New Connector

1. Create adapter in `src/connectors/adapters/{platform}-adapter.ts`
2. Extend `BaseConnector`
3. Implement required methods:
   - `authenticate()`, `refreshAuth()`, `validateCredentials()`
   - `listProducts()`, `getProduct()`, `createProduct()`, `updateProduct()`, `deleteProduct()`
   - `normalizeProduct()`, `denormalizeProduct()`, `validateProductForPlatform()`
4. Add tests in `src/connectors/adapters/__tests__/`
5. Export from `src/connectors/index.ts`
6. Update `createConnector()` factory
7. Add documentation in `docs/platform-guides/`

## Adding a New Safeguard

1. Create in `src/safeguards/{name}.ts`
2. Implement `check()` method
3. Add to orchestrator in `orchestrator.ts`
4. Add database tables if needed
5. Add API endpoint in `src/server/index.ts`
6. Add tests

## Questions?

- Check existing issues and discussions
- Open a new issue for bugs or feature requests
- Reach out to maintainers

---

Thank you for contributing!
