# Deployment Guide - Income Engine

## TL;DR

Deploy the Income Engine on Replit Autoscale, Capacitor mobile apps, or a VPS for automated ecommerce product management across 11 platforms with 8 safeguard systems.

---

## Prerequisites Checklist

Before you begin, ensure you have:

### Required
- [ ] Node.js 20+ installed locally (for development)
- [ ] Supabase account (free tier works)
- [ ] OpenAI API key (for quality gates)
- [ ] At least one platform account (see Platform Setup below)

### Platform Accounts
- [ ] Printify account (free, POD)
- [ ] Etsy seller account (~$15 to open)
- [ ] Gumroad account (free, digital products)
- [ ] Shopify Partner account (free for development)
- [ ] WooCommerce store (self-hosted)
- [ ] Amazon KDP account (free, ebooks) - requires 2FA setup
- [ ] Redbubble account (free, POD)
- [ ] TeePublic account (free, POD)
- [ ] Society6 account (free, POD)
- [ ] Creative Fabrica account (digital assets)
- [ ] TikTok Shop seller account

### AI/API Services
- [ ] OpenAI API key (for quality gates and content generation)
- [ ] Replicate account ($5 credit for image generation)
- [ ] Anthropic API key (optional, for provider failover)
- [ ] Stability AI key (optional, for image generation)
- [ ] Slack workspace (optional, for notifications)

---

## Deployment Options

### Option 1: Replit Autoscale (Recommended)

**Cost**: $1/month base + usage (scales to zero)

#### Step 1: Import Project

1. Go to [replit.com](https://replit.com)
2. Click **Create Repl** → **Import from GitHub**
3. Or drag-and-drop the project folder

#### Step 2: Configure Secrets

Click the 🔒 **Secrets** tab and add:

| Secret Name | Description | Required |
|-------------|-------------|----------|
| `SUPABASE_URL` | Your Supabase project URL | Yes |
| `SUPABASE_SERVICE_KEY` | Supabase service role key | Yes |
| `SUPABASE_ANON_KEY` | Supabase anonymous key | Yes |
| `OPENAI_API_KEY` | OpenAI API key | Yes |
| `PRINTIFY_API_KEY` | Printify API token | No |
| `ETSY_API_KEY` | Etsy API keystring | No |
| `ETSY_SHARED_SECRET` | Etsy OAuth secret | No |
| `GUMROAD_ACCESS_TOKEN` | Gumroad API token | No |
| `SHOPIFY_API_KEY` | Shopify API key | No |
| `SHOPIFY_API_SECRET` | Shopify secret | No |
| `WOOCOMMERCE_KEY` | WooCommerce consumer key | No |
| `WOOCOMMERCE_SECRET` | WooCommerce consumer secret | No |
| `TIKTOK_APP_KEY` | TikTok Shop app key | No |
| `TIKTOK_APP_SECRET` | TikTok Shop secret | No |
| `CREATIVE_FABRICA_API_KEY` | Creative Fabrica API | No |
| `SLACK_WEBHOOK_URL` | Slack notifications | No |

#### Step 3: Deploy

1. Click **Deploy** (top right corner)
2. Select **Autoscale** deployment
3. Configure:
   - Build command: `npm run build`
   - Run command: `npm run start`
4. Click **Deploy**

Your app will be live at `https://your-repl-name.replit.app`

---

### Option 2: Android/iOS Mobile App (Capacitor)

#### Android Build

```bash
# Install dependencies
npm install

# Build web assets
npm run build

# Sync to Android project
npx cap sync android

# Open in Android Studio
npx cap open android
```

In Android Studio:
1. Build → Generate Signed Bundle/APK
2. Choose APK or App Bundle
3. Create/select keystore
4. Build release variant

#### iOS Build

```bash
# Sync to iOS project
npx cap sync ios

# Open in Xcode
npx cap open ios
```

In Xcode:
1. Select your team in Signing & Capabilities
2. Product → Archive
3. Distribute App → App Store Connect

---

### Option 3: VPS Deployment (Docker)

For self-hosted deployments on Hetzner, DigitalOcean, etc.

#### Requirements

| Provider | Plan | Price | Specs |
|----------|------|-------|-------|
| Hetzner | CX11 | €4.50/mo | 1 vCPU, 2GB RAM |
| DigitalOcean | Basic | $6/mo | 1 vCPU, 1GB RAM |
| Vultr | Regular | $6/mo | 1 vCPU, 1GB RAM |

#### Docker Compose Setup

```yaml
# docker-compose.yml
version: '3.8'
services:
  income-engine:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - SUPABASE_URL=${SUPABASE_URL}
      - SUPABASE_SERVICE_KEY=${SUPABASE_SERVICE_KEY}
    restart: unless-stopped
```

```bash
# Deploy
docker-compose up -d

# View logs
docker-compose logs -f

# Update
git pull && docker-compose up -d --build
```

---

## Database Setup

### Step 1: Create Supabase Project

1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Note down:
   - Project URL: `https://xxxxx.supabase.co`
   - Service Role Key (Settings → API)
   - Anon Key (Settings → API)

### Step 2: Run Schema Migration

1. Go to Supabase SQL Editor
2. Copy contents of `database/schema.sql`
3. Execute the SQL
4. Then run `database/schema-v2.sql` for v2 tables
5. Finally run `database/schema-extensions.sql`

### Step 3: Verify Tables

```sql
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public';
```

Expected tables (30+):
- `trending_niches`, `generated_products`, `rejected_products`
- `revenue_snapshots`, `sales_records`, `ai_generation_costs`
- `platform_credentials`, `platform_tokens`
- `api_rate_limits`, `circuit_breaker_state`
- `approval_queue`, `approval_decisions`
- And more...

---

## Platform Connector Setup

### POD Platforms (Print-on-Demand)

#### Printify
1. Go to [printify.com](https://printify.com) → Settings → API
2. Generate API token
3. Note your Shop ID from URL
4. **Cost**: Free (pay per order)

#### Etsy (OAuth 2.0)
1. Go to [etsy.com/developers](https://www.etsy.com/developers)
2. Create new app
3. Get API Key and Shared Secret
4. Configure callback: `https://your-app.com/auth/etsy/callback`
5. **Cost**: $0.20/listing + 6.5% transaction fee

#### TeePublic (Browser Automation)
1. Create account at [teepublic.com](https://teepublic.com)
2. Uses email/password for Playwright automation
3. **Cost**: Free (fixed royalties per product type)

#### Society6 (Browser Automation)
1. Create artist account at [society6.com](https://society6.com)
2. Uses email/password for Playwright automation
3. **Cost**: Free (10% royalty on retail price)

#### Redbubble (Browser Automation)
1. Create account at [redbubble.com](https://redbubble.com)
2. Uses email/password for Playwright automation
3. **Cost**: Free (variable markup pricing)

### Digital Product Platforms

#### Gumroad
1. Go to [gumroad.com/settings/advanced](https://gumroad.com/settings/advanced)
2. Create OAuth application
3. Get Client ID and Secret
4. **Cost**: 10% per sale

#### Creative Fabrica
1. Apply for creator account at [creativefabrica.com](https://creativefabrica.com)
2. Once approved, generate API key
3. **Cost**: Free (50% royalty)

#### Amazon KDP (Browser Automation)
1. Create account at [kdp.amazon.com](https://kdp.amazon.com)
2. Uses email/password for Playwright automation
3. **Cost**: Free (35-70% royalty)

### Marketplace Platforms

#### Shopify (OAuth 2.0)
1. Create Shopify Partner account
2. Create app in Partner Dashboard
3. Get API key and secret
4. **Cost**: Shopify plan fees + 2.9% + $0.30 per transaction

#### WooCommerce
1. Go to WooCommerce → Settings → Advanced → REST API
2. Create API keys (Read/Write)
3. **Cost**: Self-hosted (hosting costs only)

#### TikTok Shop (OAuth 2.0)
1. Apply at [seller.tiktok.com](https://seller.tiktok.com)
2. Create app in TikTok Shop Partner Center
3. Get App Key and Secret
4. **Cost**: Platform commission varies by category

---

## Environment Variables Reference

Create `.env` file from `.env.example`:

```bash
# =============================================================================
# REQUIRED - Database & Core
# =============================================================================
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...
SUPABASE_ANON_KEY=eyJhbGc...

# =============================================================================
# REQUIRED - AI Services
# =============================================================================
OPENAI_API_KEY=sk-...
REPLICATE_API_TOKEN=r8_...

# Optional AI Providers (for failover)
ANTHROPIC_API_KEY=sk-ant-...
STABILITY_API_KEY=sk-...

# =============================================================================
# POD Platforms
# =============================================================================
PRINTIFY_API_KEY=...
PRINTIFY_SHOP_ID=...

ETSY_API_KEY=...
ETSY_SHARED_SECRET=...
ETSY_SHOP_ID=...

# Browser automation platforms (TeePublic, Society6, Redbubble)
# Credentials stored encrypted in database, set via dashboard

# =============================================================================
# Digital Platforms
# =============================================================================
GUMROAD_ACCESS_TOKEN=...
GUMROAD_CLIENT_ID=...
GUMROAD_CLIENT_SECRET=...

CREATIVE_FABRICA_API_KEY=...

# Amazon KDP (browser automation with 2FA)
# Credentials stored encrypted in database
# TOTP secret configured via: INSERT INTO totp_credentials (...)

# =============================================================================
# Marketplace Platforms
# =============================================================================
SHOPIFY_API_KEY=...
SHOPIFY_API_SECRET=...
SHOPIFY_SHOP_DOMAIN=your-store.myshopify.com

WOOCOMMERCE_URL=https://your-store.com
WOOCOMMERCE_KEY=ck_...
WOOCOMMERCE_SECRET=cs_...

TIKTOK_APP_KEY=...
TIKTOK_APP_SECRET=...

# =============================================================================
# Budget Controls
# =============================================================================
MAX_DAILY_AI_SPEND=5.00
MAX_WEEKLY_AI_SPEND=35.00
MAX_MONTHLY_BUDGET=150.00
BUDGET_WARNING_THRESHOLD=0.75
BUDGET_CRITICAL_THRESHOLD=0.90

# =============================================================================
# Rate Limiting
# =============================================================================
RATE_LIMIT_WINDOW_MS=60000
DEFAULT_REQUESTS_PER_MINUTE=30

# =============================================================================
# Quality Gates
# =============================================================================
MIN_QUALITY_SCORE=70
AUTO_APPROVE_THRESHOLD=80

# =============================================================================
# Application Settings
# =============================================================================
NODE_ENV=production
PORT=3000
SESSION_SECRET=your-random-secret-here
APP_BASE_URL=https://your-app.replit.app

# =============================================================================
# Notifications
# =============================================================================
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/xxx

# =============================================================================
# Workflow Settings (n8n)
# =============================================================================
N8N_WEBHOOK_URL=https://your-n8n.app.n8n.cloud
DRY_RUN=false
```

### Environment Variable Categories

| Category | Variables | Required |
|----------|-----------|----------|
| Database | SUPABASE_URL, SUPABASE_SERVICE_KEY, SUPABASE_ANON_KEY | Yes |
| AI Services | OPENAI_API_KEY, REPLICATE_API_TOKEN | Yes |
| POD Platforms | PRINTIFY_*, ETSY_* | At least one |
| Digital | GUMROAD_*, CREATIVE_FABRICA_* | Optional |
| Marketplace | SHOPIFY_*, WOOCOMMERCE_*, TIKTOK_* | Optional |
| Budget | MAX_DAILY_AI_SPEND, MAX_MONTHLY_BUDGET | Recommended |
| App | NODE_ENV, PORT, APP_BASE_URL | Yes |
| Notifications | SLACK_WEBHOOK_URL | Optional |

---

## Post-Deployment Verification

### Health Check

```bash
curl https://your-app.com/health
# Expected: {"status":"healthy","timestamp":"..."}
```

### API Status

```bash
curl https://your-app.com/api/status
# Returns full system status with all safeguards
```

### Test Platform Connection

```bash
curl -X POST https://your-app.com/api/connectors/test \
  -H "Content-Type: application/json" \
  -d '{"platform": "printify"}'
```

---

## Monitoring & Maintenance

### Daily Checks
- [ ] Review Slack notifications for alerts
- [ ] Check budget utilization (< 50% = healthy)
- [ ] Verify products being generated

### Weekly Tasks
- [ ] Review rejection reasons
- [ ] Analyze top-performing niches
- [ ] Check API costs vs revenue

### Monthly Tasks
- [ ] Update niche research
- [ ] Review and optimize workflows
- [ ] Backup database

---

## Troubleshooting

### Common Issues

| Error | Cause | Solution |
|-------|-------|----------|
| "Missing Secrets" | Environment not configured | Set all required secrets |
| Build fails | Dependency issues | Run `npm install` manually |
| API returns 503 | Database connection | Verify Supabase credentials |
| OAuth fails | Callback URL mismatch | Update callback in platform settings |
| Playwright timeout | Browser issue | Increase timeout or restart |

### Log Access

```bash
# Replit: View in Console tab

# Docker:
docker-compose logs -f income-engine

# VPS:
tail -f /var/log/income-engine/app.log
```

---

## Security Best Practices

1. **Never commit secrets** - Use environment variables
2. **Rotate API keys** quarterly
3. **Enable 2FA** on all platform accounts
4. **Use strong passwords** for browser automation accounts
5. **Monitor for suspicious activity** via Slack alerts
6. **Regular backups** of database

---

## MCP Server Setup (Optional)

For AI-assisted management via Claude Code or other MCP clients:

### Installation

```bash
cd mcp-server
npm install
```

### Configuration

Create/update `.claude/mcp-servers.json`:

```json
{
  "servers": {
    "income-engine": {
      "command": "node",
      "args": ["mcp-server/index.js"],
      "env": {
        "SUPABASE_URL": "${SUPABASE_URL}",
        "SUPABASE_SERVICE_KEY": "${SUPABASE_SERVICE_KEY}"
      }
    }
  }
}
```

### Verification

```bash
node mcp-server/index.js --test
```

Expected output: List of available tools and resources.

See `docs/ai-tools/MCP-INTEGRATION.md` for full documentation.

---

## Mobile App Deployment

### PWA Installation

The PWA is automatically available at your deployed URL. Users can install it:

**iOS (Safari)**
1. Open deployed URL in Safari
2. Tap Share button
3. Tap "Add to Home Screen"
4. Tap "Add"

**Android (Chrome)**
1. Open deployed URL in Chrome
2. Tap menu (three dots)
3. Tap "Install app" or "Add to Home screen"
4. Tap "Install"

### Native App Build (Capacitor)

#### Prerequisites
- Android Studio (for Android)
- Xcode (for iOS, macOS only)
- JDK 17+ (for Android)

#### Android Build

```bash
# Build web assets
npm run build

# Sync to Android project
npx cap sync android

# Open in Android Studio
npx cap open android
```

In Android Studio:
1. Build > Generate Signed Bundle/APK
2. Choose APK or App Bundle
3. Create/select keystore
4. Build release variant

#### iOS Build

```bash
# Sync to iOS project
npx cap sync ios

# Open in Xcode
npx cap open ios
```

In Xcode:
1. Select your team in Signing & Capabilities
2. Product > Archive
3. Distribute App > App Store Connect

#### Live Reload for Development

```bash
# Android with live reload
npm run android:dev

# iOS with live reload
npm run ios:dev
```

### Push Notifications (Future)

Push notification support requires additional configuration:
1. Firebase Cloud Messaging (Android)
2. Apple Push Notification Service (iOS)
3. Capacitor Push Notifications plugin

---

## Webhook Configuration

### Setting Up Webhook Endpoints

Webhooks notify external systems of events. Configure endpoints in the database:

```sql
INSERT INTO webhook_endpoints (
  name,
  url,
  event_types,
  is_active
) VALUES (
  'Slack Alerts',
  'https://hooks.slack.com/services/xxx',
  ARRAY['low_stock', 'budget_warning', 'order_created'],
  true
);
```

### Available Event Types

| Event | Description |
|-------|-------------|
| `low_stock` | Inventory below threshold |
| `out_of_stock` | Product out of stock |
| `order_created` | New order received |
| `order_shipped` | Order shipped |
| `order_delivered` | Order delivered |
| `product_approved` | Product approved for publishing |
| `product_rejected` | Product rejected |
| `product_published` | Product published to platform |
| `budget_warning` | Budget threshold reached |
| `budget_exceeded` | Budget limit exceeded |
| `sync_completed` | Inventory sync completed |

### Webhook Security

Webhooks include a signature header for verification:
- Header: `X-Webhook-Signature`
- Algorithm: HMAC-SHA256
- Secret: Stored per endpoint in database

---

## Support Resources

- **API Documentation**: `docs/API.md`
- **Architecture Guide**: `docs/ARCHITECTURE.md`
- **Operations Runbook**: `docs/RUNBOOK.md`
- **n8n Documentation**: https://docs.n8n.io
- **Supabase Docs**: https://supabase.com/docs
- **MCP Integration**: `docs/ai-tools/MCP-INTEGRATION.md`
- **Platform APIs**:
  - Printify: https://developers.printify.com
  - Etsy: https://developer.etsy.com
  - Shopify: https://shopify.dev
  - TikTok Shop: https://partner.tiktokshop.com/doc
  - WooCommerce: https://woocommerce.github.io/woocommerce-rest-api-docs/

---

*Last Updated: December 2025*
*Version: 2.0.0*
