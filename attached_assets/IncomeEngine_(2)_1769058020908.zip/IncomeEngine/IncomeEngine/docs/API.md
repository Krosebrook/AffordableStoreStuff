# Income Engine API Reference

This document provides complete documentation for all REST API endpoints in the Income Engine.

## Base URL

- **Development**: `http://localhost:3000`
- **Production**: `https://your-app.replit.app`

## Authentication

Currently, the API uses environment-based authentication. The server validates that required Supabase credentials are configured. Future versions will implement JWT-based authentication.

## Rate Limiting

All `/api/*` endpoints are rate-limited:
- **Window**: 15 minutes
- **Max Requests**: 100 per window
- **Response on Limit**: `429 Too Many Requests`

```json
{
  "error": "Too many requests, please try again later"
}
```

---

## Health Endpoints

### GET /health

Health check endpoint required for Replit Autoscale deployments.

**Response**
```json
{
  "status": "healthy",
  "timestamp": "2025-12-29T10:30:00.000Z",
  "environment": "production"
}
```

### GET /__replit_health

Internal Replit health check.

**Response**
```
OK
```

---

## System Status

### GET /api/status

Returns complete system status including all safeguards, queues, and budget information.

**Response**
```json
{
  "budget": [
    {
      "period": "daily",
      "currentSpend": 2.50,
      "limit": 5.00,
      "percentUsed": 50,
      "isWarning": false,
      "isExceeded": false,
      "remainingBudget": 2.50,
      "resetAt": "2025-12-30T00:00:00.000Z"
    }
  ],
  "queues": {
    "queued": 5,
    "processing": 2,
    "rateLimited": 0,
    "deadLetter": 0,
    "completedToday": 45
  },
  "approvalStats": {
    "totalApproved": 150,
    "totalRejected": 12,
    "approvalRate": 92.6,
    "pendingCount": 3
  },
  "circuitBreakers": {
    "budget_daily": {
      "isOpen": false
    },
    "budget_weekly": {
      "isOpen": false
    }
  },
  "providers": {
    "image": [
      {
        "id": "replicate",
        "providerType": "image",
        "providerName": "Replicate",
        "isPrimary": true,
        "isAvailable": true,
        "healthScore": 100,
        "lastCheckAt": "2025-12-29T10:25:00.000Z"
      }
    ]
  }
}
```

**Error Response**
```json
{
  "error": "Safeguards not configured"
}
```

---

## Budget Endpoints

### GET /api/budget

Returns current budget status and circuit breaker states.

**Response**
```json
{
  "budget": [
    {
      "period": "daily",
      "currentSpend": 2.50,
      "limit": 5.00,
      "percentUsed": 50,
      "isWarning": false,
      "isExceeded": false,
      "remainingBudget": 2.50,
      "resetAt": "2025-12-30T00:00:00.000Z"
    },
    {
      "period": "weekly",
      "currentSpend": 18.75,
      "limit": 35.00,
      "percentUsed": 53.6,
      "isWarning": false,
      "isExceeded": false,
      "remainingBudget": 16.25
    },
    {
      "period": "monthly",
      "currentSpend": 78.50,
      "limit": 150.00,
      "percentUsed": 52.3,
      "isWarning": false,
      "isExceeded": false,
      "remainingBudget": 71.50
    }
  ],
  "circuitBreakers": {
    "budget_daily": {
      "isOpen": false
    },
    "budget_weekly": {
      "isOpen": false
    },
    "budget_monthly": {
      "isOpen": false
    }
  }
}
```

---

## Approval Endpoints

### GET /api/approvals

Returns approval statistics and queue information.

**Response**
```json
{
  "totalApproved": 150,
  "totalRejected": 12,
  "approvalRate": 92.6,
  "pendingCount": 3
}
```

### POST /api/approvals/:id/approve

Approve a pending product.

**Headers**
| Header | Type | Description |
|--------|------|-------------|
| `X-Reviewer-Id` | string | ID of the reviewer (optional) |

**Request Body**
```json
{
  "notes": "Product looks good, approved for publishing"
}
```

**Response**
```json
{
  "success": true,
  "message": "Product approved"
}
```

### POST /api/approvals/:id/reject

Reject a pending product.

**Headers**
| Header | Type | Description |
|--------|------|-------------|
| `X-Reviewer-Id` | string | ID of the reviewer (optional) |

**Request Body**
```json
{
  "reason": "Trademark issue detected",
  "notes": "Contains protected brand name"
}
```

**Response**
```json
{
  "success": true,
  "message": "Product rejected",
  "reason": "Trademark issue detected"
}
```

---

## Product Endpoints

### POST /api/products/process

Process a product through all safeguards.

**Request Body**
```json
{
  "id": "prod_123",
  "title": "Dog Mom T-Shirt",
  "description": "Perfect gift for dog lovers",
  "type": "tshirt",
  "tags": ["dog", "mom", "gift", "pet lover"],
  "price": 24.99,
  "images": ["https://example.com/design.png"],
  "metadata": {
    "niche": "dog lovers",
    "category": "apparel"
  }
}
```

**Response**
```json
{
  "success": true,
  "productId": "prod_123",
  "status": "approved",
  "safeguardResults": {
    "rateLimiter": { "passed": true },
    "qualityGate": { "passed": true, "score": 85 },
    "trademarkScreener": { "passed": true, "flagged": [] },
    "budgetCheck": { "passed": true, "cost": 0.05 }
  },
  "nextStep": "publishing"
}
```

**Error Response**
```json
{
  "error": "Missing required fields: id, title, type"
}
```

### POST /api/products/:id/publish/pod

Publish a product to POD (Print-on-Demand) platforms.

**Request Body**
```json
{
  "product": {
    "title": "Dog Mom T-Shirt",
    "description": "Perfect gift for dog lovers",
    "images": ["https://example.com/design.png"],
    "tags": ["dog", "mom", "gift"],
    "price": 24.99
  },
  "targets": [
    {
      "platform": "printify",
      "blueprintId": "3",
      "printProviderId": "99",
      "variants": [
        { "size": "S", "color": "Black" },
        { "size": "M", "color": "Black" },
        { "size": "L", "color": "Black" }
      ]
    },
    {
      "platform": "teepublic",
      "productTypes": ["t-shirt", "hoodie"]
    }
  ]
}
```

**Response**
```json
{
  "success": true,
  "workflowId": "wf_abc123",
  "results": [
    {
      "platform": "printify",
      "success": true,
      "productId": "print_xyz789"
    },
    {
      "platform": "teepublic",
      "success": true,
      "productId": "tp_456"
    }
  ]
}
```

### POST /api/products/:id/publish/marketplace

Publish a product to marketplace platforms.

**Request Body**
```json
{
  "product": {
    "title": "Custom Dog Portrait",
    "description": "Personalized pet portrait",
    "images": ["https://example.com/product.png"],
    "price": 49.99,
    "inventory": 100
  },
  "listings": [
    {
      "platform": "shopify",
      "collectionId": "col_123",
      "tags": ["custom", "pet", "portrait"]
    },
    {
      "platform": "woocommerce",
      "categoryId": 15
    }
  ]
}
```

**Response**
```json
{
  "success": true,
  "results": [
    {
      "platform": "shopify",
      "success": true,
      "productId": "shop_123"
    },
    {
      "platform": "woocommerce",
      "success": true,
      "productId": "woo_456"
    }
  ]
}
```

---

## Connector Endpoints

### GET /api/connectors

List all available platform connectors.

**Response**
```json
[
  {
    "name": "printify",
    "displayName": "Printify",
    "workflowGroup": "pod_digital",
    "connectorType": "api_key",
    "status": "available"
  },
  {
    "name": "etsy",
    "displayName": "Etsy",
    "workflowGroup": "pod_digital",
    "connectorType": "oauth2",
    "status": "available"
  },
  {
    "name": "shopify",
    "displayName": "Shopify",
    "workflowGroup": "marketplace",
    "connectorType": "oauth2",
    "status": "available"
  }
]
```

### GET /api/connectors/:platform

Get metadata for a specific connector.

**Parameters**
| Parameter | Type | Description |
|-----------|------|-------------|
| `platform` | string | Platform name (e.g., `printify`, `etsy`) |

**Response**
```json
{
  "name": "printify",
  "displayName": "Printify",
  "workflowGroup": "pod_digital",
  "connectorType": "api_key",
  "status": "available"
}
```

### POST /api/connectors/:platform/test

Test connection to a platform.

**Parameters**
| Parameter | Type | Description |
|-----------|------|-------------|
| `platform` | string | Platform name |

**Request Body**
```json
{
  "shopDomain": "mystore.myshopify.com",
  "siteUrl": "https://mystore.com"
}
```

**Response**
```json
{
  "success": true,
  "platform": "shopify",
  "message": "Connection successful"
}
```

**Error Response**
```json
{
  "success": false,
  "error": "Invalid API credentials"
}
```

### POST /api/connectors/:platform/connect

Connect and authenticate with a platform.

**Request Body**
```json
{
  "credentials": {
    "apiKey": "your-api-key",
    "apiSecret": "your-api-secret"
  },
  "settings": {
    "shopDomain": "mystore.myshopify.com"
  }
}
```

**Response**
```json
{
  "success": true,
  "platform": "shopify",
  "message": "Connected to shopify"
}
```

### POST /api/connectors/:platform/disconnect

Disconnect from a platform.

**Response**
```json
{
  "success": true,
  "platform": "shopify",
  "message": "Disconnected from shopify"
}
```

### GET /api/connectors/:platform/products

List products from a connected platform.

**Query Parameters**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `page` | number | 1 | Page number |
| `limit` | number | 20 | Items per page |

**Response**
```json
{
  "products": [
    {
      "id": "prod_123",
      "title": "Dog Mom T-Shirt",
      "status": "active",
      "price": 24.99,
      "images": ["https://..."],
      "variants": 12,
      "createdAt": "2025-12-01T10:00:00.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 45,
    "hasMore": true
  }
}
```

---

## Analytics Endpoints

### GET /api/analytics/platforms

Get cross-platform analytics.

**Query Parameters**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `start` | ISO date | 30 days ago | Start date |
| `end` | ISO date | Now | End date |

**Response**
```json
{
  "pod": {
    "totalRevenue": 1250.00,
    "totalOrders": 85,
    "platforms": {
      "printify": {
        "revenue": 650.00,
        "orders": 45
      },
      "etsy": {
        "revenue": 420.00,
        "orders": 28
      },
      "gumroad": {
        "revenue": 180.00,
        "orders": 12
      }
    },
    "topProducts": [
      {
        "id": "prod_123",
        "title": "Dog Mom T-Shirt",
        "revenue": 145.00,
        "orders": 12
      }
    ]
  },
  "marketplace": {
    "totalRevenue": 890.00,
    "totalOrders": 42,
    "platforms": {
      "shopify": {
        "revenue": 520.00,
        "orders": 25
      },
      "woocommerce": {
        "revenue": 370.00,
        "orders": 17
      }
    }
  }
}
```

---

## Inventory Endpoints

### POST /api/inventory/sync

Synchronize inventory across all connected marketplace platforms.

**Response**
```json
{
  "success": true,
  "syncedPlatforms": ["shopify", "woocommerce"],
  "results": [
    {
      "platform": "shopify",
      "productsUpdated": 15,
      "errors": []
    },
    {
      "platform": "woocommerce",
      "productsUpdated": 12,
      "errors": []
    }
  ],
  "timestamp": "2025-12-29T10:30:00.000Z"
}
```

---

## Provider Endpoints

### GET /api/providers

Get health status of all AI providers.

**Response**
```json
{
  "image": [
    {
      "id": "replicate",
      "providerType": "image",
      "providerName": "Replicate",
      "isPrimary": true,
      "isAvailable": true,
      "healthScore": 100,
      "lastCheckAt": "2025-12-29T10:25:00.000Z",
      "avgResponseTimeMs": 2500
    },
    {
      "id": "openai-dalle",
      "providerType": "image",
      "providerName": "DALL-E",
      "isPrimary": false,
      "isAvailable": true,
      "healthScore": 98,
      "lastCheckAt": "2025-12-29T10:25:00.000Z"
    }
  ],
  "text": [
    {
      "id": "openai-gpt4",
      "providerType": "text",
      "providerName": "GPT-4o",
      "isPrimary": true,
      "isAvailable": true,
      "healthScore": 100,
      "lastCheckAt": "2025-12-29T10:25:00.000Z"
    }
  ]
}
```

---

## Queue Endpoints

### GET /api/queue

Get API queue statistics.

**Response**
```json
{
  "queued": 5,
  "processing": 2,
  "rateLimited": 0,
  "deadLetter": 0,
  "completedToday": 145
}
```

---

## Workflow Endpoints

### GET /api/workflows/status

Get status of active workflows.

**Response**
```json
{
  "activeWorkflows": 2,
  "workflows": [
    {
      "id": "wf_abc123",
      "type": "pod_publish",
      "status": "running",
      "startedAt": "2025-12-29T10:28:00.000Z",
      "progress": 60
    },
    {
      "id": "wf_def456",
      "type": "inventory_sync",
      "status": "running",
      "startedAt": "2025-12-29T10:29:00.000Z",
      "progress": 30
    }
  ]
}
```

---

## Error Responses

All endpoints may return the following error responses:

### 400 Bad Request
```json
{
  "error": "Missing required fields: id, title, type"
}
```

### 404 Not Found
```json
{
  "error": "Unknown connector: invalid-platform"
}
```

### 429 Too Many Requests
```json
{
  "error": "Too many requests, please try again later"
}
```

### 500 Internal Server Error
```json
{
  "error": "Failed to process product"
}
```

### 503 Service Unavailable
```json
{
  "error": "Safeguards not configured"
}
```

---

## TypeScript Types

Types for API responses are available in `src/client/types/index.ts`:

```typescript
interface BudgetStatus {
  period: string;
  currentSpend: number;
  limit: number;
  percentUsed: number;
  isWarning: boolean;
  isExceeded: boolean;
  remainingBudget: number;
  resetAt?: string;
}

interface QueueStats {
  queued: number;
  processing: number;
  rateLimited: number;
  deadLetter: number;
  completedToday: number;
}

interface ApprovalStats {
  totalApproved: number;
  totalRejected: number;
  approvalRate: number;
  pendingCount: number;
}

interface SystemStatus {
  budget: BudgetStatus[];
  queues: QueueStats;
  approvalStats: ApprovalStats;
  circuitBreakers: Record<string, CircuitBreakerState>;
  providers?: Record<string, ProviderStatus[]>;
}
```

---

## Changelog

| Version | Date | Changes |
|---------|------|---------|
| 2.0.0 | 2025-12-29 | Added connector, workflow, and analytics endpoints |
| 1.0.0 | 2025-11-01 | Initial API release |
