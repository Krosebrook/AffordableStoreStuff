# Income Engine Architecture

This document describes the system architecture of the Income Engine, including component relationships, data flows, and integration patterns.

## System Overview

```
+-----------------------------------------------------------------------------------+
|                              CLIENT LAYER                                          |
+-----------------------------------------------------------------------------------+
|                                                                                    |
|   +------------------+     +------------------+     +------------------+           |
|   |   React PWA      |     |  Capacitor App   |     |   MCP Client     |           |
|   |   Dashboard      |     |  (iOS/Android)   |     |  (Claude Code)   |           |
|   +--------+---------+     +--------+---------+     +--------+---------+           |
|            |                        |                        |                     |
+------------+------------------------+------------------------+---------------------+
             |                        |                        |
             v                        v                        v
+-----------------------------------------------------------------------------------+
|                              API LAYER                                             |
+-----------------------------------------------------------------------------------+
|                                                                                    |
|   +------------------+     +------------------+     +------------------+           |
|   |  Express.js      |     |   MCP Server     |     |   n8n Webhooks   |           |
|   |  REST API        |     |   (Tools/Res)    |     |   (Workflows)    |           |
|   +--------+---------+     +--------+---------+     +--------+---------+           |
|            |                        |                        |                     |
+------------+------------------------+------------------------+---------------------+
             |                        |                        |
             v                        v                        v
+-----------------------------------------------------------------------------------+
|                           ORCHESTRATION LAYER                                      |
+-----------------------------------------------------------------------------------+
|                                                                                    |
|   +-----------------------------------------------------------------------+        |
|   |                      Safeguards Orchestrator                           |        |
|   +-----------------------------------------------------------------------+        |
|   |                                                                        |        |
|   |   +-----------+  +-----------+  +-----------+  +-----------+          |        |
|   |   |   Rate    |  |  Quality  |  | Trademark |  |  Budget   |          |        |
|   |   |  Limiter  |  |   Gate    |  | Screener  |  |  Breaker  |          |        |
|   |   +-----------+  +-----------+  +-----------+  +-----------+          |        |
|   |                                                                        |        |
|   |   +-----------+  +-----------+  +-----------+  +-----------+          |        |
|   |   |    API    |  | Provider  |  |    Tax    |  |  Human    |          |        |
|   |   |   Queue   |  | Failover  |  | Compliance|  | in Loop   |          |        |
|   |   +-----------+  +-----------+  +-----------+  +-----------+          |        |
|   |                                                                        |        |
|   +-----------------------------------------------------------------------+        |
|                                                                                    |
+-----------------------------------------------------------------------------------+
             |
             v
+-----------------------------------------------------------------------------------+
|                           CONNECTOR LAYER                                          |
+-----------------------------------------------------------------------------------+
|                                                                                    |
|   +-------------------------------+     +-------------------------------+          |
|   |      POD/Digital Workflow     |     |     Marketplace Workflow      |          |
|   +-------------------------------+     +-------------------------------+          |
|   |                               |     |                               |          |
|   |  +----------+ +----------+   |     |  +----------+ +----------+    |          |
|   |  | Printify | |   Etsy   |   |     |  | Shopify  | |WooCommerce|   |          |
|   |  +----------+ +----------+   |     |  +----------+ +----------+    |          |
|   |  +----------+ +----------+   |     |  +----------+ +----------+    |          |
|   |  | TeePublic| | Society6 |   |     |  | TikTok   | |Amazon KDP|   |          |
|   |  +----------+ +----------+   |     |  |   Shop   | |          |    |          |
|   |  +----------+ +----------+   |     |  +----------+ +----------+    |          |
|   |  |Redbubble | | Gumroad  |   |     |                               |          |
|   |  +----------+ +----------+   |     |                               |          |
|   |  +----------+                |     |                               |          |
|   |  | Creative |                |     |                               |          |
|   |  | Fabrica  |                |     |                               |          |
|   |  +----------+                |     |                               |          |
|   +-------------------------------+     +-------------------------------+          |
|                                                                                    |
+-----------------------------------------------------------------------------------+
             |
             v
+-----------------------------------------------------------------------------------+
|                            DATA LAYER                                              |
+-----------------------------------------------------------------------------------+
|                                                                                    |
|   +------------------+     +------------------+     +------------------+           |
|   |    Supabase      |     |   Webhook Queue  |     |   File Storage   |           |
|   |   PostgreSQL     |     |   (Notifications)|     |   (Designs)      |           |
|   +------------------+     +------------------+     +------------------+           |
|                                                                                    |
+-----------------------------------------------------------------------------------+
```

## Component Details

### Client Layer

#### React PWA Dashboard
- **Technology**: React 18, TypeScript, Vite, Tailwind CSS
- **Location**: `src/client/`
- **Features**:
  - Real-time system status monitoring
  - Product approval workflow
  - Budget tracking and alerts
  - Platform connection management
  - Offline support via service worker

#### Capacitor Mobile App
- **Technology**: Capacitor 6
- **Location**: `android/`, configuration in `capacitor.config.ts`
- **Features**:
  - Native Android/iOS builds
  - Push notifications (planned)
  - Biometric authentication (planned)

#### MCP Client
- **Technology**: Model Context Protocol
- **Integration**: Claude Code, other MCP-compatible AI assistants
- **Features**:
  - Natural language platform management
  - AI-assisted analytics
  - Workflow automation

### API Layer

#### Express.js REST API
- **Location**: `src/server/index.ts`
- **Port**: 3000 (configurable via PORT env)
- **Features**:
  - RESTful endpoints for all operations
  - Rate limiting (100 req/15min)
  - CORS and Helmet security
  - Static file serving for PWA

#### MCP Server
- **Location**: `mcp-server/`
- **Tools** (9 total):
  - `list_platforms`, `connect_platform`
  - `create_product`, `list_products`
  - `get_analytics`
  - `check_safeguards`, `reset_safeguard`
  - `run_workflow`, `get_workflow_status`
- **Resources** (4 total):
  - `platforms://status`
  - `products://pending`
  - `analytics://dashboard`
  - `budget://current`

#### n8n Webhooks
- **Location**: Workflow JSON files (`01-*.json` to `08-*.json`)
- **Workflows**:
  - Niche scanning and product generation
  - Multi-platform publishing
  - Revenue aggregation and reporting

### Orchestration Layer

#### Safeguards Orchestrator
- **Location**: `src/safeguards/orchestrator.ts`
- **Purpose**: Coordinates all 8 safeguards for product processing

```
Product Input
     |
     v
+----+----+     +----+----+     +----+----+     +----+----+
|  Rate   | --> | Quality | --> |Trademark| --> | Budget  |
| Limiter |     |  Gate   |     | Screen  |     | Check   |
+---------+     +---------+     +---------+     +---------+
     |               |               |               |
     v               v               v               v
  Pass/Fail      Score 0-100     Hit/Clear      Available
                                                    |
                                                    v
                                            +-------+-------+
                                            | Human Review  |
                                            | (if required) |
                                            +-------+-------+
                                                    |
                                                    v
                                            +-------+-------+
                                            |   API Queue   |
                                            | (prioritized) |
                                            +-------+-------+
                                                    |
                                                    v
                                              Publishing
```

#### Individual Safeguards

| Safeguard | File | Purpose | Key Metrics |
|-----------|------|---------|-------------|
| Rate Limiter | `rate-limiter.ts` | Prevent API abuse | Requests/minute per platform |
| Quality Gate | `quality-gate.ts` | Content quality scoring | Score 0-100, threshold 70 |
| Trademark Screener | `trademark-screener.ts` | USPTO TESS lookup | Hit/clear status |
| API Queue | `api-queue.ts` | Request queuing | Priority, backoff, retries |
| Provider Failover | `provider-failover.ts` | AI redundancy | Health scores, failover order |
| Tax Compliance | `tax-compliance.ts` | Nexus tracking | State thresholds, registration |
| Human-in-Loop | `human-in-the-loop.ts` | Manual review | Approval count, threshold |
| Budget Breaker | `budget-circuit-breaker.ts` | Spending limits | Daily/weekly/monthly caps |

### Connector Layer

#### Base Architecture

```
+------------------+
|  BaseConnector   |  <-- Abstract base class
+------------------+
| - supabaseUrl    |
| - supabaseKey    |
| - rateLimiter    |
+------------------+
| + authenticate() |
| + listProducts() |
| + createProduct()|
| + normalizeProduct() |
+------------------+
         ^
         |
    +----+----+----+----+----+
    |    |    |    |    |    |
+---+  +-+-+  +-+-+  +--++  +-+-+
|Printify| |Etsy|  |Shopify| |WC|  |TikTok|
+---------+ +---+  +-------+ +--+  +------+
```

#### Platform Adapters
- **Location**: `src/connectors/adapters/`
- **Pattern**: Each platform extends `BaseConnector`
- **Methods**:
  - `authenticate()` - Initial auth
  - `refreshAuth()` - Token refresh
  - `validateCredentials()` - Test connection
  - `listProducts()`, `getProduct()`, `createProduct()`, `updateProduct()`, `deleteProduct()`
  - `normalizeProduct()`, `denormalizeProduct()` - Data mapping

#### Workflow Engines

**POD/Digital Workflow** (`pod-digital-workflow.ts`)
```
Product
   |
   v
+--+--+     +--+--+     +--+--+
|Check| --> |Upload| --> |Create|
|Safe | --> |Design| --> |Product|
+-----+     +-----+     +------+
   |
   +---> Parallel publish to multiple POD platforms
   |
   v
Analytics aggregation
```

**Marketplace Workflow** (`marketplace-workflow.ts`)
```
Product
   |
   v
+--+--+     +--+--+     +--+--+
|Create| --> |Sync | --> |Track|
|Listing| --> |Inventory| --> |Orders|
+------+     +-----+     +-----+
   |
   +---> Webhook notifications for low stock
   |
   v
Revenue and return tracking
```

#### Utility Services

| Service | File | Purpose |
|---------|------|---------|
| TOTP | `utils/totp.ts` | 2FA code generation for Amazon KDP |
| Webhooks | `utils/webhook.ts` | Queue-based notification delivery |
| Retry Handler | `utils/retry-handler.ts` | Exponential backoff, circuit breaker |
| Error Mapper | `utils/error-mapper.ts` | Platform error normalization |

### Data Layer

#### Supabase PostgreSQL

**Core Tables** (schema-v2.sql):
```
+-------------------+     +-------------------+     +-------------------+
|     products      |     |   generated_      |     |   platform_       |
|                   |     |   products        |     |   credentials     |
+-------------------+     +-------------------+     +-------------------+
| id                |     | id                |     | id                |
| title             |     | niche             |     | platform          |
| description       |     | design_url        |     | encrypted_creds   |
| status            |     | quality_score     |     | token_expires_at  |
| platform_ids      |     | safeguard_results |     | refresh_token     |
+-------------------+     +-------------------+     +-------------------+
         |                         |                         |
         v                         v                         v
+-------------------+     +-------------------+     +-------------------+
|  approval_queue   |     |   cost_events     |     |   platform_tokens |
+-------------------+     +-------------------+     +-------------------+
| id                |     | id                |     | id                |
| product_id        |     | service_name      |     | platform          |
| reason            |     | cost_usd          |     | access_token      |
| risk_level        |     | product_id        |     | expires_at        |
| status            |     | created_at        |     | scope             |
+-------------------+     +-------------------+     +-------------------+
```

**Supporting Tables**:
- `api_rate_limits` - Per-platform rate tracking
- `circuit_breaker_state` - Circuit breaker status
- `nexus_tracking` - Tax nexus by state
- `webhook_queue` - Outbound notification queue
- `agent_identities` - AI agent IAM
- `mcp_servers` - MCP server registry
- `feature_flags` - Feature toggles

#### Database Migrations

```
database/
├── schema.sql              # Original schema (v1)
├── schema-extensions.sql   # Extended features
├── schema-v2.sql           # Current complete schema
└── migrations/
    ├── 002-add-connector-tables.sql
    ├── 003-add-webhook-tables.sql
    ├── 004-enhance-products-table.sql
    └── 005-add-2fa-support.sql
```

## Data Flow Diagrams

### Product Creation Flow

```
User/AI                    API                    Orchestrator               Connector
  |                         |                          |                        |
  |  POST /products/process |                          |                        |
  |------------------------>|                          |                        |
  |                         |  processProduct()        |                        |
  |                         |------------------------->|                        |
  |                         |                          |                        |
  |                         |                    Rate Limit Check               |
  |                         |                          |                        |
  |                         |                    Quality Gate                   |
  |                         |                          |                        |
  |                         |                    Trademark Screen               |
  |                         |                          |                        |
  |                         |                    Budget Check                   |
  |                         |                          |                        |
  |                         |                    Human Review?                  |
  |                         |                          |                        |
  |                         |  { status, results }     |                        |
  |                         |<-------------------------|                        |
  |  { success, status }    |                          |                        |
  |<------------------------|                          |                        |
  |                         |                          |                        |
  |  POST /products/:id/publish/pod                    |                        |
  |------------------------>|                          |                        |
  |                         |  publishToTargets()      |                        |
  |                         |------------------------->|                        |
  |                         |                          |  createProduct()       |
  |                         |                          |----------------------->|
  |                         |                          |                        |
  |                         |                          |  { productId }         |
  |                         |                          |<-----------------------|
  |                         |  { results }             |                        |
  |                         |<-------------------------|                        |
  |  { success, results }   |                          |                        |
  |<------------------------|                          |                        |
```

### Inventory Sync Flow

```
Scheduler/API              Marketplace Workflow        Connectors              Webhook
     |                            |                        |                     |
     |  syncAllInventory()        |                        |                     |
     |--------------------------->|                        |                     |
     |                            |                        |                     |
     |                      For each platform:             |                     |
     |                            |                        |                     |
     |                            |  getInventory()        |                     |
     |                            |----------------------->|                     |
     |                            |                        |                     |
     |                            |  { products, stock }   |                     |
     |                            |<-----------------------|                     |
     |                            |                        |                     |
     |                      Compare across platforms       |                     |
     |                            |                        |                     |
     |                            |  updateInventory()     |                     |
     |                            |----------------------->|                     |
     |                            |                        |                     |
     |                      If low stock:                  |                     |
     |                            |                        |                     |
     |                            |  sendNotification()    |                     |
     |                            |--------------------------------------->     |
     |                            |                        |                     |
     |  { syncResults }           |                        |                     |
     |<---------------------------|                        |                     |
```

## Security Architecture

### Authentication Layers

```
+------------------+
|   User/Client    |
+--------+---------+
         |
         v
+--------+---------+
|   Rate Limiting  |  <-- 100 req/15min per IP
+--------+---------+
         |
         v
+--------+---------+
|  CORS / Helmet   |  <-- Origin validation, security headers
+--------+---------+
         |
         v
+--------+---------+
|  Supabase RLS    |  <-- Row-level security policies
+--------+---------+
         |
         v
+--------+---------+
|  Service Role    |  <-- Backend uses service key
+------------------+
```

### Credential Management

```
Platform Credentials
        |
        v
+-------+--------+
| Credential     |
| Manager        |
+-------+--------+
        |
        +---> Encrypted storage in Supabase
        |
        +---> Token refresh automation
        |
        +---> Audit logging
```

### Agent IAM (AI Agents)

```
+------------------+
| agent_identities |
+------------------+
| agent_name       |
| agent_type       |  workflow, mcp_server, cli, api
| privilege_level  |  read, write, admin, superadmin
| scopes[]         |
| rate_limits      |
+------------------+
         |
         v
+------------------+
| agent_audit_log  |
+------------------+
| action           |
| resource_type    |
| outcome          |
| risk_score       |
+------------------+
```

## Deployment Architecture

### Replit Autoscale

```
+------------------+
|   Load Balancer  |
+--------+---------+
         |
         v
+--------+---------+
|  Container Pool  |
|  (0-N instances) |
+--------+---------+
         |
         +---> Scale to 0 when idle
         |
         +---> Scale up on traffic
         |
         +---> Health check: /health
```

### Container Configuration

```
+------------------+
|    Node.js 20    |
+------------------+
| - Express server |
| - Vite build     |
| - TypeScript     |
+------------------+
         |
         +---> Playwright browsers (for POD platforms)
         |
         +---> Static asset serving
```

## Performance Considerations

### Caching Strategy

| Layer | Cache | TTL | Purpose |
|-------|-------|-----|---------|
| Client | TanStack Query | 5 min | API response caching |
| API | In-memory | Request | Connector instances |
| Database | PostgreSQL | N/A | Query optimization via indexes |

### Rate Limiting

| Level | Limit | Window | Scope |
|-------|-------|--------|-------|
| API | 100 req | 15 min | Per IP |
| Platform | Varies | 1 min | Per platform |
| AI | Budget | Daily | Per provider |

### Database Indexes

Key indexes for performance:
- `workflow_executions(status, started_at)`
- `safeguard_audit_log(product_id, assessed_at)`
- `analytics_events(event_type, created_at)`
- `mcp_tool_executions(server_name, created_at)`

## Scalability

### Horizontal Scaling

- Stateless API design allows multiple instances
- Supabase handles database scaling
- Webhook queue enables async processing

### Vertical Scaling

- Increase container resources for more throughput
- Optimize expensive operations (Playwright, AI calls)

### Bottlenecks

| Component | Potential Bottleneck | Mitigation |
|-----------|---------------------|------------|
| Playwright | Browser memory | Instance pooling, cleanup |
| AI APIs | Rate limits, cost | Provider failover, budget controls |
| Database | Connection pool | Connection pooling, query optimization |
| Webhooks | Delivery delays | Queue-based async processing |

## Monitoring

### Health Checks

- `/health` - API health (required for Autoscale)
- `/__replit_health` - Replit internal check
- Provider health scores tracked in database

### Metrics

| Metric | Source | Purpose |
|--------|--------|---------|
| API latency | Express middleware | Performance monitoring |
| Safeguard decisions | Audit log | Decision tracking |
| Budget usage | Cost events | Spending control |
| Queue depth | API queue | Backlog monitoring |

### Alerting

- Slack webhooks for critical events
- Budget threshold notifications
- Low stock alerts
- Circuit breaker state changes

---

*Last Updated: December 2025*
*Architecture Version: 2.0.0*
