# TikTok Shop Integration Guide

## Overview

TikTok Shop is a social commerce platform integrated with TikTok's video and live streaming features. Ideal for viral products and trend-driven merchandise.

| Attribute | Value |
|-----------|-------|
| Platform Type | Marketplace |
| Auth Method | OAuth 2.0 |
| Connector Type | `oauth2` |
| Rate Limit | 100 requests/10 seconds |
| API Documentation | https://partner.tiktokshop.com/doc |

## Setup

### Step 1: Seller Registration

1. Go to [seller.tiktok.com](https://seller.tiktok.com)
2. Register as a seller
3. Complete business verification
4. Wait for approval (1-3 business days)

### Step 2: Create App

1. Go to TikTok Shop Partner Center
2. Navigate to App Management
3. Create new application
4. Select required permissions:
   - Product Management
   - Order Management
   - Fulfillment Management
   - Shop Analytics

### Step 3: Configure OAuth

1. Set callback URL: `https://your-app.com/auth/tiktok/callback`
2. Note App Key and App Secret
3. Generate initial access token

### Step 4: Configure Environment

```bash
# .env
TIKTOK_APP_KEY=your_app_key
TIKTOK_APP_SECRET=your_app_secret
```

## Usage

### Connecting

```typescript
import { createConnector } from '@/connectors';

const tiktok = createConnector('tiktok-shop', {
  appKey: process.env.TIKTOK_APP_KEY,
  appSecret: process.env.TIKTOK_APP_SECRET,
});

await tiktok.authenticate();
```

### Creating a Product

```typescript
const result = await tiktok.createProduct({
  title: 'Trending Viral T-Shirt',
  description: 'As seen on TikTok! The viral design everyone is wearing...',
  images: [
    { url: 'https://cdn.com/product.jpg', isPrimary: true },
    { url: 'https://cdn.com/product-2.jpg' },
  ],
  price: 24.99,
  inventory: 100,
  category: 'Apparel',
  tags: ['viral', 'trending', 'tiktok', 'fashion'],
});
```

### Managing Orders

```typescript
// Get pending orders
const orders = await tiktok.getOrders({
  status: 'pending',
  startDate: '2025-01-01',
  endDate: '2025-01-31',
});

// Fulfill order
await tiktok.fulfillOrder({
  orderId: 'order_123',
  trackingNumber: '1Z999AA10123456784',
  shippingProvider: 'ups',
});
```

## Product Categories

### Popular Categories

| Category | Commission | Best Sellers |
|----------|------------|--------------|
| Apparel | 8% | T-shirts, hoodies |
| Beauty | 5% | Skincare, makeup |
| Home | 6% | Decor, gadgets |
| Electronics | 4% | Accessories |
| Pet Supplies | 7% | Toys, accessories |

### Category Requirements

Each category has specific requirements:
- Image specifications
- Required attributes
- Brand authorization (for some)

## Live Shopping Integration

### Linking Products to Lives

```typescript
// Get live session
const liveSession = await tiktok.getLiveSession();

// Pin product during live
await tiktok.pinProduct({
  liveId: liveSession.id,
  productId: 'prod_123',
  duration: 300, // 5 minutes
});
```

### Live Analytics

```typescript
const analytics = await tiktok.getLiveAnalytics({
  liveId: 'live_123',
});

// Returns: viewers, engagement, sales, conversion rate
```

## Affiliate Program

### Setting Up Affiliates

```typescript
// Enable affiliate for product
await tiktok.enableAffiliate({
  productId: 'prod_123',
  commissionRate: 15, // percentage
});

// Get affiliate performance
const affiliateStats = await tiktok.getAffiliateStats({
  startDate: '2025-01-01',
  endDate: '2025-01-31',
});
```

## Image Requirements

| Requirement | Value |
|-------------|-------|
| Minimum Size | 600 x 600 px |
| Maximum Size | 5000 x 5000 px |
| Format | JPG, PNG |
| Background | White preferred |
| Max Images | 9 per product |

## Rate Limits

| Limit | Value |
|-------|-------|
| Requests/10 seconds | 100 |
| Products/request | 20 |
| Orders/request | 100 |

## Token Management

TikTok tokens expire and need refreshing:

```typescript
// Tokens refresh automatically in the adapter
// Manual refresh if needed:
await tiktok.refreshAuth();
```

## Troubleshooting

### "Product rejected"
- Review TikTok's content policy
- Check category requirements
- Ensure images meet specifications
- Verify pricing is competitive

### "Order sync failed"
- Check API rate limits
- Verify OAuth tokens are valid
- Ensure shop status is active

### "Live shopping unavailable"
- Feature may require approval
- Check seller tier requirements
- Verify live streaming is enabled

### "Affiliate not working"
- Product must be approved first
- Commission rate must be set
- Category must support affiliates

## Best Practices

1. **Trend-focused products** - TikTok users expect viral, trendy items
2. **Video-first approach** - Create engaging product videos
3. **Use hashtags** - Research trending hashtags for discoverability
4. **Competitive pricing** - TikTok users are price-sensitive
5. **Fast shipping** - Quick fulfillment improves ratings
6. **Engage with comments** - Build community around products
7. **Leverage influencers** - Use affiliate program for promotion

## Commission Structure

| Category | Commission |
|----------|------------|
| Apparel | 8% |
| Beauty | 5% |
| Electronics | 4% |
| Home & Garden | 6% |
| Sports | 7% |
| Pet Supplies | 7% |
| Other | 5-8% |
