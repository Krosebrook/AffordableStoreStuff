# Etsy Platform Guide

Connect Income Engine to your Etsy shop to automate product listings, manage inventory, and track sales.

## Overview

| Property | Value |
|----------|-------|
| **Platform Type** | POD / Digital Marketplace |
| **Authentication** | OAuth 2.0 with PKCE |
| **API Version** | Open API v3 |
| **Rate Limit** | 10 requests/second |
| **Adapter File** | `src/connectors/adapters/etsy-adapter.ts` |

## Prerequisites

1. **Etsy Seller Account** with an active shop
2. **Etsy Developer Account** at [etsy.com/developers](https://www.etsy.com/developers)
3. **Approved API Application** with appropriate scopes

## Step 1: Create an Etsy API Application

1. Go to [Etsy Developer Portal](https://www.etsy.com/developers/your-apps)
2. Click **Create a New App**
3. Fill in the application details:
   - **App Name**: Income Engine (or your preferred name)
   - **Description**: Automated product management
   - **App Type**: Web Application
4. Accept the API Terms of Use
5. Note your **Keystring** (Client ID) and **Shared Secret** (Client Secret)

## Step 2: Configure OAuth Callback

Set up your OAuth callback URL:

```
https://your-app-url.com/api/auth/etsy/callback
```

Add this URL to your Etsy app's **Callback URLs** in the developer portal.

## Step 3: Environment Variables

Add these to your `.env` file:

```bash
# Etsy OAuth Credentials
ETSY_CLIENT_ID=your_keystring_here
ETSY_CLIENT_SECRET=your_shared_secret_here
ETSY_REDIRECT_URI=https://your-app-url.com/api/auth/etsy/callback

# Your Etsy Shop ID (numeric)
ETSY_SHOP_ID=12345678
```

### Finding Your Shop ID

Your Shop ID is the numeric identifier for your shop. Find it by:

1. Go to your Etsy shop manager
2. Look at the URL: `etsy.com/your-shop/listing/...`
3. Or use the API: After OAuth, call `/application/users/me` to get your user ID, then `/application/users/{user_id}/shops`

## Step 4: Required OAuth Scopes

The adapter requests these scopes during authorization:

| Scope | Purpose |
|-------|---------|
| `listings_r` | Read listing data |
| `listings_w` | Create and update listings |
| `listings_d` | Delete listings |
| `shops_r` | Read shop information |
| `shops_w` | Update shop settings |
| `transactions_r` | Read sales transactions |
| `profile_r` | Read user profile |

## Step 5: Connect via API

### Initiate OAuth Flow

```bash
# Get authorization URL
GET /api/connectors/etsy/auth-url

# Response
{
  "authUrl": "https://www.etsy.com/oauth/connect?..."
}
```

### Complete OAuth Callback

After user authorizes, Etsy redirects to your callback with a `code` parameter:

```bash
GET /api/auth/etsy/callback?code=xxx&state=yyy
```

The system exchanges this code for access/refresh tokens and stores them securely.

### Test Connection

```bash
POST /api/connectors/etsy/test

# Success Response
{
  "success": true,
  "shop": {
    "shop_id": 12345678,
    "shop_name": "YourShopName",
    "currency_code": "USD"
  }
}
```

## Platform Limits

| Limit | Value |
|-------|-------|
| Max Title Length | 140 characters |
| Max Description Length | 65,535 characters |
| Max Images per Listing | 10 |
| Max Tags | 13 |
| Max Variants | 70 |
| Allowed Image Formats | JPG, JPEG, PNG, GIF |
| Max Image Size | 10 MB |
| Minimum Price | $0.20 |
| Recommended Image Size | 2000x2000 px |

## Required Fields for Listings

Every Etsy listing requires:

- **title** - Product title (max 140 chars)
- **description** - Product description
- **price** - Listing price (min $0.20)
- **who_made** - `i_did`, `someone_else`, or `collective`
- **when_made** - Production timeframe (e.g., `made_to_order`)
- **taxonomy_id** - Category ID from Etsy taxonomy
- **shipping_profile_id** - Pre-configured shipping profile

## Shipping Profiles

Before creating listings, set up shipping profiles in your Etsy shop:

1. Go to **Shop Manager** > **Settings** > **Shipping settings**
2. Create profiles for your product types
3. Note the **profile IDs** for use in the API

Get shipping profiles via API:

```bash
GET /api/connectors/etsy/shipping-profiles

# Response
{
  "profiles": [
    {
      "shipping_profile_id": 123456,
      "title": "Standard US Shipping",
      "origin_country_iso": "US"
    }
  ]
}
```

## Category (Taxonomy) IDs

Etsy uses taxonomy IDs for categories. Common mappings:

| Product Type | Taxonomy ID |
|--------------|-------------|
| T-Shirts | 1 |
| Mugs | 69150433 |
| Posters/Prints | 69150537 |
| Stickers | 66 |

Get full taxonomy:

```bash
GET /api/connectors/etsy/taxonomies
```

## Usage Examples

### List Products

```bash
GET /api/connectors/etsy/products?page=1&limit=25

# Response
{
  "items": [...],
  "total": 150,
  "page": 1,
  "limit": 25,
  "hasMore": true
}
```

### Create a Listing

```bash
POST /api/connectors/etsy/products
Content-Type: application/json

{
  "title": "Funny Cat T-Shirt - Purrfect Gift",
  "description": "High-quality cotton t-shirt featuring an adorable cat design...",
  "images": [
    { "url": "https://your-cdn.com/design.png" }
  ],
  "pricing": {
    "price": 24.99,
    "currency": "USD"
  },
  "tags": ["cat shirt", "funny cat", "cat lover gift"],
  "metadata": {
    "taxonomy_id": 1,
    "who_made": "i_did",
    "when_made": "made_to_order"
  },
  "platformData": {
    "shipping_profile_id": 123456
  }
}
```

### Update Inventory

```bash
PUT /api/connectors/etsy/products/{listing_id}/inventory
Content-Type: application/json

{
  "inventory": [
    { "sku": "CAT-SHIRT-S", "quantity": 100, "price": 24.99 },
    { "sku": "CAT-SHIRT-M", "quantity": 100, "price": 24.99 },
    { "sku": "CAT-SHIRT-L", "quantity": 100, "price": 24.99 }
  ]
}
```

### Get Analytics

```bash
GET /api/connectors/etsy/analytics?start=2025-01-01&end=2025-01-31

# Response
{
  "platform": "etsy",
  "revenue": {
    "total": 1234.56,
    "currency": "USD",
    "byDay": [...],
    "byProduct": [...]
  },
  "orderCount": 45,
  "topProducts": [...]
}
```

## n8n Workflow Integration

The `04-etsy-publisher.json` workflow automates Etsy publishing:

1. Fetches approved products from database
2. Checks if already published to Printify (for POD)
3. Creates Etsy listings with proper taxonomy
4. Uploads product images
5. Activates listings
6. Updates database with Etsy listing IDs

## Rate Limiting

Etsy allows 10 requests per second. The adapter automatically:

- Queues requests to stay within limits
- Adds jitter to prevent burst patterns
- Tracks rate limit headers from responses
- Backs off when approaching limits

## Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `OAUTH_EXPIRED` | Access token expired | System auto-refreshes; if persistent, re-authorize |
| `RATE_LIMITED` | Too many requests | Wait and retry; reduce batch sizes |
| `INVALID_TAXONOMY` | Wrong category ID | Use `/taxonomies` endpoint to find correct ID |
| `SHIPPING_REQUIRED` | Missing shipping profile | Create profile in Etsy shop settings |
| `PRICE_TOO_LOW` | Price below $0.20 | Increase listing price |
| `TITLE_TOO_LONG` | Title exceeds 140 chars | Shorten title |

## Troubleshooting

### OAuth Token Refresh Fails

```sql
-- Check token status in database
SELECT * FROM platform_connections WHERE platform = 'etsy';

-- If refresh_token is null or expired, user must re-authorize
```

### Listings Not Appearing

1. Check listing state (may be `draft` not `active`)
2. Verify shipping profile is valid
3. Check for policy violations in Etsy dashboard
4. Ensure images meet requirements (min 2000px recommended)

### Image Upload Failures

- Ensure image URL is publicly accessible
- Check image format (JPG, PNG, GIF only)
- Verify size is under 10 MB
- Minimum dimensions: 2000x2000px recommended

## Fee Structure

Etsy charges several fees (accounted for in revenue calculations):

| Fee Type | Amount |
|----------|--------|
| Listing Fee | $0.20 per listing (4-month duration) |
| Transaction Fee | 6.5% of sale price |
| Payment Processing | 3% + $0.25 per transaction |
| Offsite Ads (if enrolled) | 12-15% of sale |

The revenue aggregator workflow accounts for ~13% total fees when calculating net revenue.

## Security Best Practices

1. **Never commit credentials** - Use environment variables
2. **Store tokens encrypted** - Database uses encrypted column for OAuth tokens
3. **Use secure callback URLs** - HTTPS only for production
4. **Monitor for suspicious activity** - Check Etsy API usage in developer dashboard

## Related Documentation

- [Etsy Open API v3 Docs](https://developers.etsy.com/documentation/)
- [Etsy OAuth Guide](https://developers.etsy.com/documentation/essentials/authentication)
- [Income Engine API Reference](../API.md)
- [Connector Architecture](../ARCHITECTURE.md)
