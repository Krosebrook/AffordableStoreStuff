# Claude Code CLI Integration

## Overview

This project is optimized for development with Claude Code, Anthropic's AI-powered CLI tool for software engineering tasks.

## Quick Reference

### Common Commands

```bash
# Start Claude Code in project
cd D:\IncomeEngine
claude

# With specific context
claude --context "Working on connector adapters"

# Resume previous session
claude --continue
```

## Project-Specific Usage

### Understanding the Codebase

```
> Explain the connector architecture

> What safeguards are implemented?

> How does the OAuth flow work for Etsy?
```

### Adding New Features

```
> Add a new platform connector for Zazzle

> Implement webhook support for order notifications

> Create a analytics dashboard component
```

### Debugging

```
> Why is the TikTok OAuth failing?

> Debug the rate limiter not resetting

> Fix the TypeScript error in quality-gate.ts
```

### Testing

```
> Write tests for the Creative Fabrica adapter

> Run the test suite and fix failures

> Add integration tests for the workflow engine
```

## CLAUDE.md Guidelines

The `CLAUDE.md` file in the project root provides context to Claude:

- Project architecture overview
- Coding standards
- Common tasks and patterns
- Do's and Don'ts
- Troubleshooting tips

**Always keep CLAUDE.md updated** when making significant changes.

## MCP Integration

This project supports Model Context Protocol for enhanced AI capabilities.

### Configuration

Create/update `.claude/mcp-servers.json`:

```json
{
  "servers": {
    "income-engine": {
      "command": "node",
      "args": ["mcp-server/index.js"],
      "env": {
        "SUPABASE_URL": "${SUPABASE_URL}",
        "SUPABASE_SERVICE_KEY": "${SUPABASE_SERVICE_KEY}"
      }
    }
  }
}
```

### Available MCP Tools

| Tool | Description |
|------|-------------|
| `list_platforms` | Get all connected platforms |
| `create_product` | Create product on platform |
| `get_analytics` | Fetch performance metrics |
| `check_safeguards` | Verify safeguard status |
| `run_workflow` | Execute n8n workflow |

## Skills (Claude Code)

Custom skills can be added to `.claude/skills/`:

### Available Skills

| Skill | File | Description |
|-------|------|-------------|
| `/create-connector` | `create-connector.md` | Scaffold new platform adapter |
| `/add-safeguard` | `add-safeguard.md` | Add new safeguard module |
| `/deploy-replit` | `deploy-replit.md` | Deploy to Replit |
| `/run-tests` | `run-tests.md` | Run test suite |
| `/revenue-report` | `revenue-report.md` | Generate revenue report |

### Using Skills

```
> /create-connector zazzle

> /run-tests --coverage

> /revenue-report --last-30-days
```

## Best Practices

### Effective Prompts

```
Good:
"Add OAuth 2.0 support to the Society6 adapter, following
the same pattern as the Etsy adapter"

Less Effective:
"Make Society6 work with OAuth"
```

### Context Hints

```
Good:
"In the connectors/adapters directory, create a new adapter
for Zazzle using the BaseConnector pattern"

Less Effective:
"Add Zazzle support"
```

### Iterative Development

1. Start with a clear goal
2. Let Claude explore the codebase
3. Review proposed changes
4. Approve and iterate

## Hooks Configuration

Create `.claude/settings.json` for custom hooks:

```json
{
  "hooks": {
    "preCommit": "npm run lint && npm run test",
    "postFileWrite": "npm run format"
  }
}
```

## Troubleshooting

### "Context too large"
- Use more specific file references
- Let Claude summarize first
- Work on smaller chunks

### "Missing context"
- Reference relevant files explicitly
- Update CLAUDE.md with recent changes
- Use `/context add` for important files

### "Unexpected changes"
- Review diffs before accepting
- Use git to track changes
- Ask Claude to explain reasoning
