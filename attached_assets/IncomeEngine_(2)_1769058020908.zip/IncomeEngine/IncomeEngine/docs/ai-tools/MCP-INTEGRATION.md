# Model Context Protocol (MCP) Integration

## Overview

The Income Engine supports MCP for enhanced AI assistant capabilities, allowing Claude and other AI tools to interact directly with the platform.

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Claude Code   │────▶│   MCP Server    │────▶│  Income Engine  │
│   (AI Client)   │◀────│   (Bridge)      │◀────│     (APIs)      │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

## Server Structure

```
mcp-server/
├── index.js              # Main entry point
├── package.json          # Dependencies
├── tools/
│   ├── platforms.js      # list_platforms, connect_platform
│   ├── products.js       # create_product, list_products
│   ├── analytics.js      # get_analytics
│   ├── safeguards.js     # check_safeguards, reset_safeguard
│   └── workflows.js      # run_workflow, get_workflow_status
└── resources/
    ├── index.js          # Resource router
    ├── platforms-status.js
    ├── products-pending.js
    ├── analytics-dashboard.js
    └── budget-current.js
```

## Setup

### 1. Configure MCP Server

Create `.claude/mcp-servers.json`:

```json
{
  "servers": {
    "income-engine": {
      "command": "node",
      "args": ["mcp-server/index.js"],
      "env": {
        "SUPABASE_URL": "${SUPABASE_URL}",
        "SUPABASE_SERVICE_KEY": "${SUPABASE_SERVICE_KEY}",
        "NODE_ENV": "development"
      }
    }
  }
}
```

### 2. Install Dependencies

```bash
cd mcp-server
npm install
```

### 3. Verify Connection

```bash
# Test MCP server standalone
node mcp-server/index.js --test
```

## Available Tools

### Platform Management

#### `list_platforms`
Lists all configured platform connections.

```json
{
  "name": "list_platforms",
  "description": "Get all connected platforms with status"
}
```

**Response:**
```json
{
  "platforms": [
    {
      "name": "printify",
      "status": "connected",
      "lastSync": "2025-01-15T10:30:00Z"
    },
    {
      "name": "etsy",
      "status": "token_expiring",
      "expiresIn": "5 days"
    }
  ]
}
```

#### `connect_platform`
Initiates platform connection.

```json
{
  "name": "connect_platform",
  "arguments": {
    "platform": "string",
    "credentials": "object"
  }
}
```

### Product Operations

#### `create_product`
Creates a product on specified platform.

```json
{
  "name": "create_product",
  "arguments": {
    "platform": "printify",
    "product": {
      "title": "string",
      "description": "string",
      "images": ["array"],
      "tags": ["array"],
      "price": "number"
    }
  }
}
```

#### `list_products`
Fetches products from platform.

```json
{
  "name": "list_products",
  "arguments": {
    "platform": "string",
    "page": "number",
    "limit": "number",
    "status": "string"
  }
}
```

### Analytics

#### `get_analytics`
Retrieves performance metrics.

```json
{
  "name": "get_analytics",
  "arguments": {
    "platform": "string | 'all'",
    "period": "'today' | 'week' | 'month' | 'year'",
    "metrics": ["revenue", "orders", "views"]
  }
}
```

**Response:**
```json
{
  "period": "month",
  "revenue": 892.50,
  "orders": 45,
  "views": 12500,
  "byPlatform": {
    "etsy": { "revenue": 420.00, "orders": 20 },
    "shopify": { "revenue": 312.50, "orders": 15 },
    "gumroad": { "revenue": 160.00, "orders": 10 }
  }
}
```

### Safeguards

#### `check_safeguards`
Verifies all safeguard statuses.

```json
{
  "name": "check_safeguards",
  "description": "Get status of all 8 safeguard modules"
}
```

#### `reset_safeguard`
Resets a specific safeguard.

```json
{
  "name": "reset_safeguard",
  "arguments": {
    "safeguard": "rate-limiter | budget | circuit-breaker",
    "target": "string (optional)"
  }
}
```

### Workflows

#### `run_workflow`
Executes an n8n workflow.

```json
{
  "name": "run_workflow",
  "arguments": {
    "workflow": "niche-scanner | product-generator | printify-publisher | etsy-publisher | gumroad-publisher | revenue-aggregator | daily-report | batch-processor",
    "parameters": "object"
  }
}
```

**Available Workflows:**
| Workflow | File | Description |
|----------|------|-------------|
| niche-scanner | 01-niche-scanner.json | Scan for trending niches |
| product-generator | 02-product-generator.json | Generate product designs |
| printify-publisher | 03-printify-publisher.json | Publish to Printify |
| etsy-publisher | 04-etsy-publisher.json | Publish to Etsy |
| gumroad-publisher | 05-gumroad-publisher.json | Publish to Gumroad |
| revenue-aggregator | 06-revenue-aggregator.json | Aggregate revenue data |
| daily-report | 07-daily-report.json | Generate daily reports |
| batch-processor | 08-batch-processor.json | Process batch operations |

#### `get_workflow_status`
Checks workflow execution status.

```json
{
  "name": "get_workflow_status",
  "arguments": {
    "executionId": "string"
  }
}
```

## Resources

MCP Resources provide read-only data:

### `platforms://status`
Current status of all platforms.

### `products://pending`
Products awaiting approval.

### `analytics://dashboard`
Dashboard summary data.

### `budget://current`
Current budget utilization.

## Example Interactions

### Via Claude Code

```
User: Check which platforms need attention

Claude: [Uses list_platforms tool]

The following platforms need attention:
- Etsy: OAuth token expires in 5 days (reauthorize soon)
- TikTok Shop: 3 products pending review
- Printify: All healthy
```

### Automated Reporting

```
User: Generate a revenue report for last month

Claude: [Uses get_analytics tool with period='month']

## Monthly Revenue Report (December 2025)

Total Revenue: $892.50
Total Orders: 45

### By Platform
| Platform | Revenue | Orders | Avg Order |
|----------|---------|--------|-----------|
| Etsy     | $420.00 | 20     | $21.00    |
| Shopify  | $312.50 | 15     | $20.83    |
| Gumroad  | $160.00 | 10     | $16.00    |

### Top Products
1. Dog Mom T-Shirt - $145.00 (12 sales)
2. Custom Mug Bundle - $98.50 (7 sales)
...
```

## Security Considerations

1. **Never expose API keys** in MCP responses
2. **Rate limit MCP requests** (100/minute recommended)
3. **Audit logging** for all tool invocations
4. **Scope permissions** based on environment

## Development

### Adding New Tools

1. Create or edit a tool file in `mcp-server/tools/`:

```javascript
// mcp-server/tools/my-tools.js
export const myTools = [
  {
    name: 'my_tool',
    description: 'Description of what this tool does',
    inputSchema: {
      type: 'object',
      properties: {
        param1: { type: 'string', description: 'Parameter description' }
      },
      required: ['param1']
    },
  },
];

export async function handleMyTool(name, args, supabase) {
  switch (name) {
    case 'my_tool':
      // Implementation using supabase client
      const { data, error } = await supabase.from('table').select('*');
      if (error) throw new Error(error.message);
      return {
        content: [{ type: 'text', text: JSON.stringify(data) }],
      };
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}
```

2. Register in `mcp-server/index.js`:

```javascript
import { myTools, handleMyTool } from './tools/my-tools.js';

// Add to allTools array
const allTools = [...existingTools, ...myTools];

// Add handler routing in CallToolRequestSchema handler
if (myTools.some((t) => t.name === name)) {
  return await handleMyTool(name, args, supabase);
}
```

### Adding New Resources

1. Create resource file in `mcp-server/resources/`:

```javascript
// mcp-server/resources/my-resource.js
export async function getMyResource(supabase) {
  const { data } = await supabase.from('table').select('*');
  return {
    contents: [{
      uri: 'my://resource',
      mimeType: 'application/json',
      text: JSON.stringify(data, null, 2),
    }],
  };
}
```

2. Register in `mcp-server/resources/index.js`.

### Testing

```bash
# Run MCP server in test mode
node mcp-server/index.js --test

# Output shows available tools and resources
```

## Troubleshooting

### "MCP server not responding"
- Check server is running
- Verify socket connection
- Check for port conflicts

### "Tool not found"
- Ensure tool is registered
- Check tool name spelling
- Restart MCP server

### "Permission denied"
- Verify environment variables
- Check API credentials
- Review scope settings
