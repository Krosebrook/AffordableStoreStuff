-- ============================================================================
-- MIGRATION 006: Design Generator Tables
-- ============================================================================
-- Adds tables for AI design generation tracking, cost management, and templates
-- Run after 005-add-2fa-support.sql
-- ============================================================================

-- ============================================================================
-- DESIGN GENERATIONS TABLE
-- Primary table for storing generated designs
-- ============================================================================

CREATE TABLE IF NOT EXISTS design_generations (
    id TEXT PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,

    -- Prompt information
    prompt TEXT NOT NULL,
    enhanced_prompt TEXT,
    template_id TEXT,

    -- Generation details
    provider TEXT NOT NULL CHECK (provider IN ('openai-dalle', 'replicate-flux', 'stability-sd3')),
    model TEXT NOT NULL,

    -- Image data
    image_url TEXT NOT NULL,
    thumbnail_url TEXT,
    width INTEGER NOT NULL,
    height INTEGER NOT NULL,
    format TEXT NOT NULL CHECK (format IN ('png', 'jpg', 'webp')),
    file_size_bytes BIGINT DEFAULT 0,

    -- Timing
    generation_time_ms INTEGER NOT NULL,

    -- Cost tracking
    cost_amount DECIMAL(10, 6) NOT NULL DEFAULT 0,
    cost_currency TEXT NOT NULL DEFAULT 'USD',

    -- Quality assessment
    quality_score DECIMAL(3, 2) CHECK (quality_score >= 0 AND quality_score <= 1),
    quality_assessment JSONB,

    -- Categorization
    niche TEXT,
    product_type TEXT,
    tags TEXT[] DEFAULT '{}',

    -- Metadata
    metadata JSONB DEFAULT '{}',
    seed BIGINT,
    steps INTEGER,
    guidance_scale DECIMAL(4, 2),

    -- Status
    status TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'failed', 'rejected')),
    failure_reason TEXT,

    -- Failover tracking
    failover_attempts INTEGER DEFAULT 0,
    original_provider TEXT,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for design generations
CREATE INDEX idx_design_gen_user ON design_generations(user_id, created_at DESC);
CREATE INDEX idx_design_gen_provider ON design_generations(provider, created_at DESC);
CREATE INDEX idx_design_gen_niche ON design_generations(niche, created_at DESC) WHERE niche IS NOT NULL;
CREATE INDEX idx_design_gen_status ON design_generations(status, created_at DESC);
CREATE INDEX idx_design_gen_quality ON design_generations(quality_score DESC) WHERE quality_score IS NOT NULL;
CREATE INDEX idx_design_gen_tags ON design_generations USING GIN(tags);

-- ============================================================================
-- DESIGN GENERATION COSTS TABLE
-- Detailed cost tracking for all AI operations
-- ============================================================================

CREATE TABLE IF NOT EXISTS design_generation_costs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    design_id TEXT REFERENCES design_generations(id) ON DELETE SET NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,

    -- Cost details
    amount DECIMAL(10, 6) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',

    -- Provider info
    provider TEXT NOT NULL,
    model TEXT NOT NULL,
    operation TEXT NOT NULL DEFAULT 'generation' CHECK (operation IN (
        'generation', 'upscale', 'background_removal', 'quality_check', 'inpainting'
    )),

    -- Breakdown
    breakdown JSONB,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for cost tracking
CREATE INDEX idx_gen_costs_user ON design_generation_costs(user_id, created_at DESC);
CREATE INDEX idx_gen_costs_provider ON design_generation_costs(provider, created_at DESC);
CREATE INDEX idx_gen_costs_daily ON design_generation_costs(created_at::DATE, user_id);
CREATE INDEX idx_gen_costs_monthly ON design_generation_costs(DATE_TRUNC('month', created_at), user_id);

-- ============================================================================
-- PROMPT TEMPLATES TABLE
-- Custom user-defined prompt templates
-- ============================================================================

CREATE TABLE IF NOT EXISTS prompt_templates (
    id TEXT PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,

    -- Template info
    name TEXT NOT NULL,
    description TEXT,
    niche TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'custom',

    -- Template content
    template TEXT NOT NULL,
    variables JSONB NOT NULL DEFAULT '[]',

    -- Generation hints
    style TEXT,
    negative_prompt TEXT,
    suggested_dimensions JSONB,

    -- Categorization
    tags TEXT[] DEFAULT '{}',
    examples TEXT[] DEFAULT '{}',

    -- Usage tracking
    use_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMPTZ,

    -- Status
    is_public BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for templates
CREATE INDEX idx_templates_user ON prompt_templates(user_id, is_active);
CREATE INDEX idx_templates_niche ON prompt_templates(niche, is_active, is_public);
CREATE INDEX idx_templates_public ON prompt_templates(is_public, use_count DESC) WHERE is_public = TRUE;
CREATE INDEX idx_templates_tags ON prompt_templates USING GIN(tags);

-- ============================================================================
-- AI PROVIDER CONFIGS TABLE
-- Store provider-specific configurations and rate limits
-- ============================================================================

CREATE TABLE IF NOT EXISTS ai_provider_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider TEXT NOT NULL UNIQUE CHECK (provider IN ('openai-dalle', 'replicate-flux', 'stability-sd3')),

    -- Display info
    display_name TEXT NOT NULL,
    description TEXT,

    -- Status
    is_enabled BOOLEAN DEFAULT TRUE,
    priority INTEGER NOT NULL DEFAULT 100,

    -- Rate limiting
    requests_per_minute INTEGER,
    requests_per_hour INTEGER,
    max_concurrent INTEGER DEFAULT 5,

    -- Cost info
    base_cost_per_generation DECIMAL(10, 6),
    cost_currency TEXT DEFAULT 'USD',

    -- Capabilities
    capabilities JSONB NOT NULL DEFAULT '{}',
    supported_models JSONB NOT NULL DEFAULT '[]',

    -- Default settings
    default_model TEXT,
    default_quality TEXT,
    default_steps INTEGER,

    -- Health tracking
    last_health_check TIMESTAMPTZ,
    health_status TEXT DEFAULT 'healthy' CHECK (health_status IN ('healthy', 'degraded', 'unavailable')),
    failure_count_24h INTEGER DEFAULT 0,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- GENERATION QUALITY ASSESSMENTS TABLE
-- Store detailed quality assessment results
-- ============================================================================

CREATE TABLE IF NOT EXISTS generation_quality_assessments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    design_id TEXT NOT NULL REFERENCES design_generations(id) ON DELETE CASCADE,

    -- Overall score
    overall_score DECIMAL(3, 2) NOT NULL CHECK (overall_score >= 0 AND overall_score <= 1),
    passed BOOLEAN NOT NULL,

    -- Individual scores
    aesthetic_score DECIMAL(3, 2) CHECK (aesthetic_score >= 0 AND aesthetic_score <= 1),
    technical_score DECIMAL(3, 2) CHECK (technical_score >= 0 AND technical_score <= 1),
    relevance_score DECIMAL(3, 2) CHECK (relevance_score >= 0 AND relevance_score <= 1),
    originality_score DECIMAL(3, 2) CHECK (originality_score >= 0 AND originality_score <= 1),

    -- Issues and suggestions
    issues JSONB DEFAULT '[]',
    suggestions TEXT[] DEFAULT '{}',
    detailed_feedback TEXT,

    -- Assessment method
    assessor TEXT DEFAULT 'ai' CHECK (assessor IN ('ai', 'human')),
    model_used TEXT,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for quality assessments
CREATE INDEX idx_quality_design ON generation_quality_assessments(design_id);
CREATE INDEX idx_quality_score ON generation_quality_assessments(overall_score DESC);
CREATE INDEX idx_quality_passed ON generation_quality_assessments(passed, created_at DESC);

-- ============================================================================
-- GENERATION BUDGET LIMITS TABLE
-- User-specific budget controls
-- ============================================================================

CREATE TABLE IF NOT EXISTS generation_budget_limits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,

    -- Daily limits
    daily_budget DECIMAL(10, 2),
    daily_spent DECIMAL(10, 2) DEFAULT 0,
    daily_generation_count INTEGER DEFAULT 0,
    daily_reset_at TIMESTAMPTZ,

    -- Monthly limits
    monthly_budget DECIMAL(10, 2),
    monthly_spent DECIMAL(10, 2) DEFAULT 0,
    monthly_generation_count INTEGER DEFAULT 0,
    monthly_reset_at TIMESTAMPTZ,

    -- Generation limits
    daily_generation_limit INTEGER,
    monthly_generation_limit INTEGER,

    -- Status
    is_blocked BOOLEAN DEFAULT FALSE,
    blocked_reason TEXT,
    blocked_until TIMESTAMPTZ,

    -- Currency
    currency TEXT DEFAULT 'USD',

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- GENERATION FAILOVER EVENTS TABLE
-- Track provider failover events for monitoring
-- ============================================================================

CREATE TABLE IF NOT EXISTS generation_failover_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    design_id TEXT REFERENCES design_generations(id) ON DELETE SET NULL,

    -- Failover details
    from_provider TEXT NOT NULL,
    to_provider TEXT NOT NULL,
    reason TEXT NOT NULL,

    -- Error details
    error_code TEXT,
    error_message TEXT,

    -- Resolution
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMPTZ,

    -- Timestamps
    triggered_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for failover events
CREATE INDEX idx_failover_from ON generation_failover_events(from_provider, triggered_at DESC);
CREATE INDEX idx_failover_unresolved ON generation_failover_events(resolved, triggered_at DESC) WHERE resolved = FALSE;

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Function to reset daily budgets
CREATE OR REPLACE FUNCTION reset_daily_generation_budgets()
RETURNS void AS $$
BEGIN
    UPDATE generation_budget_limits
    SET
        daily_spent = 0,
        daily_generation_count = 0,
        daily_reset_at = NOW(),
        updated_at = NOW()
    WHERE daily_reset_at IS NULL
       OR daily_reset_at::DATE < CURRENT_DATE;
END;
$$ LANGUAGE plpgsql;

-- Function to reset monthly budgets
CREATE OR REPLACE FUNCTION reset_monthly_generation_budgets()
RETURNS void AS $$
BEGIN
    UPDATE generation_budget_limits
    SET
        monthly_spent = 0,
        monthly_generation_count = 0,
        monthly_reset_at = NOW(),
        updated_at = NOW()
    WHERE monthly_reset_at IS NULL
       OR DATE_TRUNC('month', monthly_reset_at) < DATE_TRUNC('month', CURRENT_DATE);
END;
$$ LANGUAGE plpgsql;

-- Function to check if user is within budget
CREATE OR REPLACE FUNCTION check_generation_budget(
    p_user_id UUID,
    p_estimated_cost DECIMAL DEFAULT 0
)
RETURNS TABLE (
    allowed BOOLEAN,
    reason TEXT,
    daily_remaining DECIMAL,
    monthly_remaining DECIMAL
) AS $$
DECLARE
    v_limits generation_budget_limits%ROWTYPE;
BEGIN
    -- Get user limits
    SELECT * INTO v_limits
    FROM generation_budget_limits
    WHERE user_id = p_user_id;

    -- If no limits set, allow
    IF NOT FOUND THEN
        RETURN QUERY SELECT TRUE, NULL::TEXT, NULL::DECIMAL, NULL::DECIMAL;
        RETURN;
    END IF;

    -- Check if blocked
    IF v_limits.is_blocked AND (v_limits.blocked_until IS NULL OR v_limits.blocked_until > NOW()) THEN
        RETURN QUERY SELECT FALSE, v_limits.blocked_reason, 0::DECIMAL, 0::DECIMAL;
        RETURN;
    END IF;

    -- Check daily budget
    IF v_limits.daily_budget IS NOT NULL THEN
        IF v_limits.daily_spent + p_estimated_cost > v_limits.daily_budget THEN
            RETURN QUERY SELECT
                FALSE,
                'Daily budget exceeded',
                v_limits.daily_budget - v_limits.daily_spent,
                v_limits.monthly_budget - v_limits.monthly_spent;
            RETURN;
        END IF;
    END IF;

    -- Check monthly budget
    IF v_limits.monthly_budget IS NOT NULL THEN
        IF v_limits.monthly_spent + p_estimated_cost > v_limits.monthly_budget THEN
            RETURN QUERY SELECT
                FALSE,
                'Monthly budget exceeded',
                v_limits.daily_budget - v_limits.daily_spent,
                v_limits.monthly_budget - v_limits.monthly_spent;
            RETURN;
        END IF;
    END IF;

    -- Check generation limits
    IF v_limits.daily_generation_limit IS NOT NULL THEN
        IF v_limits.daily_generation_count >= v_limits.daily_generation_limit THEN
            RETURN QUERY SELECT
                FALSE,
                'Daily generation limit reached',
                v_limits.daily_budget - v_limits.daily_spent,
                v_limits.monthly_budget - v_limits.monthly_spent;
            RETURN;
        END IF;
    END IF;

    -- All checks passed
    RETURN QUERY SELECT
        TRUE,
        NULL::TEXT,
        COALESCE(v_limits.daily_budget - v_limits.daily_spent, NULL::DECIMAL),
        COALESCE(v_limits.monthly_budget - v_limits.monthly_spent, NULL::DECIMAL);
END;
$$ LANGUAGE plpgsql;

-- Function to record generation cost
CREATE OR REPLACE FUNCTION record_generation_cost(
    p_user_id UUID,
    p_design_id TEXT,
    p_amount DECIMAL,
    p_provider TEXT,
    p_model TEXT,
    p_operation TEXT DEFAULT 'generation'
)
RETURNS void AS $$
BEGIN
    -- Insert cost record
    INSERT INTO design_generation_costs (
        design_id, user_id, amount, provider, model, operation
    ) VALUES (
        p_design_id, p_user_id, p_amount, p_provider, p_model, p_operation
    );

    -- Update user budget tracking
    UPDATE generation_budget_limits
    SET
        daily_spent = daily_spent + p_amount,
        daily_generation_count = daily_generation_count + 1,
        monthly_spent = monthly_spent + p_amount,
        monthly_generation_count = monthly_generation_count + 1,
        updated_at = NOW()
    WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- VIEWS
-- ============================================================================

-- View for generation statistics
CREATE OR REPLACE VIEW generation_stats AS
SELECT
    DATE_TRUNC('day', created_at) AS date,
    provider,
    COUNT(*) AS total_generations,
    COUNT(*) FILTER (WHERE status = 'completed') AS successful,
    COUNT(*) FILTER (WHERE status = 'failed') AS failed,
    SUM(cost_amount) AS total_cost,
    AVG(generation_time_ms) AS avg_generation_time_ms,
    AVG(quality_score) AS avg_quality_score,
    AVG(failover_attempts) AS avg_failover_attempts
FROM design_generations
GROUP BY DATE_TRUNC('day', created_at), provider
ORDER BY date DESC, provider;

-- View for provider health summary
CREATE OR REPLACE VIEW provider_health_summary AS
SELECT
    pc.provider,
    pc.display_name,
    pc.is_enabled,
    pc.priority,
    pc.health_status,
    pc.failure_count_24h,
    COALESCE(stats.generations_24h, 0) AS generations_24h,
    COALESCE(stats.success_rate, 0) AS success_rate_24h,
    COALESCE(stats.avg_time, 0) AS avg_generation_time_24h
FROM ai_provider_configs pc
LEFT JOIN (
    SELECT
        provider,
        COUNT(*) AS generations_24h,
        ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'completed') / NULLIF(COUNT(*), 0), 2) AS success_rate,
        AVG(generation_time_ms) AS avg_time
    FROM design_generations
    WHERE created_at > NOW() - INTERVAL '24 hours'
    GROUP BY provider
) stats ON stats.provider = pc.provider;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE design_generations ENABLE ROW LEVEL SECURITY;
ALTER TABLE design_generation_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompt_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE generation_budget_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE generation_quality_assessments ENABLE ROW LEVEL SECURITY;

-- Users can see their own generations
CREATE POLICY "Users can view own generations" ON design_generations
    FOR SELECT USING (auth.uid() = user_id);

-- Users can see their own costs
CREATE POLICY "Users can view own costs" ON design_generation_costs
    FOR SELECT USING (auth.uid() = user_id);

-- Users can manage their own templates
CREATE POLICY "Users can manage own templates" ON prompt_templates
    FOR ALL USING (auth.uid() = user_id);

-- Users can view public templates
CREATE POLICY "Users can view public templates" ON prompt_templates
    FOR SELECT USING (is_public = TRUE);

-- Users can view their own budget limits
CREATE POLICY "Users can view own budget" ON generation_budget_limits
    FOR SELECT USING (auth.uid() = user_id);

-- Users can view quality assessments for their designs
CREATE POLICY "Users can view own assessments" ON generation_quality_assessments
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM design_generations dg
            WHERE dg.id = design_id AND dg.user_id = auth.uid()
        )
    );

-- Service role has full access
CREATE POLICY "Service role full access generations" ON design_generations
    FOR ALL USING (true);

CREATE POLICY "Service role full access costs" ON design_generation_costs
    FOR ALL USING (true);

CREATE POLICY "Service role full access templates" ON prompt_templates
    FOR ALL USING (true);

CREATE POLICY "Service role full access budget" ON generation_budget_limits
    FOR ALL USING (true);

CREATE POLICY "Service role full access assessments" ON generation_quality_assessments
    FOR ALL USING (true);

-- ============================================================================
-- SEED DATA: AI Provider Configurations
-- ============================================================================

INSERT INTO ai_provider_configs (
    provider, display_name, description, is_enabled, priority,
    requests_per_minute, requests_per_hour, max_concurrent,
    base_cost_per_generation, capabilities, supported_models, default_model
) VALUES
(
    'openai-dalle',
    'OpenAI DALL-E 3',
    'High-quality image generation with excellent prompt understanding',
    TRUE, 1,
    50, 500, 5,
    0.04,
    '{"maxWidth": 1792, "maxHeight": 1792, "supportedFormats": ["png", "webp"], "supportsNegativePrompt": false, "supportsBatchGeneration": false}',
    '["dall-e-3"]',
    'dall-e-3'
),
(
    'replicate-flux',
    'Replicate Flux',
    'Fast and cost-effective image generation with multiple model options',
    TRUE, 2,
    100, 1000, 10,
    0.025,
    '{"maxWidth": 2048, "maxHeight": 2048, "supportedFormats": ["png", "jpg", "webp"], "supportsNegativePrompt": true, "supportsBatchGeneration": true}',
    '["flux-pro", "flux-dev", "flux-schnell"]',
    'flux-pro'
),
(
    'stability-sd3',
    'Stability AI SD3',
    'Advanced stable diffusion with extensive customization options',
    TRUE, 3,
    100, 1000, 10,
    0.035,
    '{"maxWidth": 2048, "maxHeight": 2048, "supportedFormats": ["png", "jpg", "webp"], "supportsNegativePrompt": true, "supportsBatchGeneration": true, "supportsInpainting": true}',
    '["sd3", "sd3-turbo", "sd3-large", "sd3-large-turbo"]',
    'sd3'
)
ON CONFLICT (provider) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description,
    capabilities = EXCLUDED.capabilities,
    supported_models = EXCLUDED.supported_models,
    updated_at = NOW();

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Auto-update updated_at timestamps
CREATE OR REPLACE FUNCTION update_design_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_design_generations_updated_at
    BEFORE UPDATE ON design_generations
    FOR EACH ROW
    EXECUTE FUNCTION update_design_updated_at();

CREATE TRIGGER trigger_prompt_templates_updated_at
    BEFORE UPDATE ON prompt_templates
    FOR EACH ROW
    EXECUTE FUNCTION update_design_updated_at();

CREATE TRIGGER trigger_budget_limits_updated_at
    BEFORE UPDATE ON generation_budget_limits
    FOR EACH ROW
    EXECUTE FUNCTION update_design_updated_at();

-- ============================================================================
-- VERSION TRACKING
-- ============================================================================

INSERT INTO schema_versions (version, description)
VALUES ('2.5.0', 'Added design generator tables: generations, costs, templates, budget limits, quality assessments, and provider configs')
ON CONFLICT (version) DO NOTHING;
