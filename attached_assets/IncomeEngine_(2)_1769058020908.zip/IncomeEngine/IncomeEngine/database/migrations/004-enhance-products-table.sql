-- ============================================================================
-- MIGRATION 004: Enhance Products Table for Inventory and Marketplace Support
-- ============================================================================
-- Adds columns required for inventory tracking, marketplace sync, and analytics
-- Run after 003-add-webhook-tables.sql
-- ============================================================================

-- ============================================================================
-- PRODUCTS TABLE ENHANCEMENTS
-- Add missing columns for full marketplace workflow support
-- ============================================================================

-- Inventory tracking columns
ALTER TABLE products ADD COLUMN IF NOT EXISTS inventory_quantity INTEGER DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS track_inventory BOOLEAN DEFAULT FALSE;
ALTER TABLE products ADD COLUMN IF NOT EXISTS allow_backorder BOOLEAN DEFAULT FALSE;
ALTER TABLE products ADD COLUMN IF NOT EXISTS low_stock_threshold INTEGER DEFAULT 5;

-- Product identification
ALTER TABLE products ADD COLUMN IF NOT EXISTS sku TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS barcode TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS barcode_type TEXT CHECK (barcode_type IN ('upc', 'ean', 'isbn', 'gtin'));

-- Enhanced metadata
ALTER TABLE products ADD COLUMN IF NOT EXISTS weight_grams INTEGER;
ALTER TABLE products ADD COLUMN IF NOT EXISTS dimensions JSONB; -- {length, width, height, unit}
ALTER TABLE products ADD COLUMN IF NOT EXISTS variant_options JSONB DEFAULT '[]'::JSONB;
ALTER TABLE products ADD COLUMN IF NOT EXISTS seo_metadata JSONB DEFAULT '{}'::JSONB;

-- Multi-platform publishing
ALTER TABLE products ADD COLUMN IF NOT EXISTS publish_targets TEXT[] DEFAULT ARRAY[]::TEXT[];
ALTER TABLE products ADD COLUMN IF NOT EXISTS published_platforms TEXT[] DEFAULT ARRAY[]::TEXT[];
ALTER TABLE products ADD COLUMN IF NOT EXISTS sync_status TEXT CHECK (sync_status IN ('synced', 'pending', 'error', 'never')) DEFAULT 'never';
ALTER TABLE products ADD COLUMN IF NOT EXISTS last_sync_at TIMESTAMPTZ;

-- Revenue tracking
ALTER TABLE products ADD COLUMN IF NOT EXISTS revenue_total_usd DECIMAL(12,2) DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS units_sold INTEGER DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS last_sale_at TIMESTAMPTZ;

-- AI generation metadata
ALTER TABLE products ADD COLUMN IF NOT EXISTS ai_model_used TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS generation_cost_usd DECIMAL(10,4) DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS generation_attempts INTEGER DEFAULT 0;

-- Seasonal/trending data
ALTER TABLE products ADD COLUMN IF NOT EXISTS seasonal_keywords TEXT[] DEFAULT ARRAY[]::TEXT[];
ALTER TABLE products ADD COLUMN IF NOT EXISTS trending_score DECIMAL(5,2) DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS last_trending_check TIMESTAMPTZ;

-- Competitor tracking
ALTER TABLE products ADD COLUMN IF NOT EXISTS competitor_products UUID[] DEFAULT ARRAY[]::UUID[];
ALTER TABLE products ADD COLUMN IF NOT EXISTS competitive_price_min DECIMAL(10,2);
ALTER TABLE products ADD COLUMN IF NOT EXISTS competitive_price_max DECIMAL(10,2);
ALTER TABLE products ADD COLUMN IF NOT EXISTS last_competitive_check TIMESTAMPTZ;

-- Create indexes for new columns
CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku) WHERE sku IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_products_inventory ON products(track_inventory, inventory_quantity);
CREATE INDEX IF NOT EXISTS idx_products_low_stock ON products(inventory_quantity, low_stock_threshold)
    WHERE track_inventory = TRUE AND inventory_quantity <= low_stock_threshold;
CREATE INDEX IF NOT EXISTS idx_products_sync_status ON products(sync_status, last_sync_at);
CREATE INDEX IF NOT EXISTS idx_products_revenue ON products(revenue_total_usd DESC);
CREATE INDEX IF NOT EXISTS idx_products_published ON products USING GIN(published_platforms);
CREATE INDEX IF NOT EXISTS idx_products_trending ON products(trending_score DESC) WHERE trending_score > 0;

-- ============================================================================
-- PRODUCTS TABLE - SKU GENERATION FUNCTION
-- ============================================================================

-- Function to generate unique SKU
CREATE OR REPLACE FUNCTION generate_product_sku(
    p_product_id UUID,
    p_prefix TEXT DEFAULT 'IE'
)
RETURNS TEXT AS $$
DECLARE
    v_timestamp TEXT;
    v_random TEXT;
    v_sku TEXT;
BEGIN
    -- Format: PREFIX-YYYYMMDD-XXXX (where XXXX is random alphanumeric)
    v_timestamp := TO_CHAR(NOW(), 'YYYYMMDD');
    v_random := UPPER(SUBSTRING(MD5(p_product_id::TEXT || NOW()::TEXT) FROM 1 FOR 4));
    v_sku := p_prefix || '-' || v_timestamp || '-' || v_random;

    RETURN v_sku;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-generate SKU if not provided
CREATE OR REPLACE FUNCTION auto_generate_sku()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.sku IS NULL THEN
        NEW.sku := generate_product_sku(NEW.id);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Only create trigger if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'trigger_auto_generate_sku'
    ) THEN
        CREATE TRIGGER trigger_auto_generate_sku
            BEFORE INSERT ON products
            FOR EACH ROW
            EXECUTE FUNCTION auto_generate_sku();
    END IF;
END;
$$;

-- ============================================================================
-- INVENTORY ALERT FUNCTION
-- ============================================================================

-- Function to check and create low stock alerts
CREATE OR REPLACE FUNCTION check_low_stock_alert()
RETURNS TRIGGER AS $$
BEGIN
    -- Only check if inventory tracking is enabled and quantity decreased
    IF NEW.track_inventory = TRUE
       AND OLD.inventory_quantity > NEW.inventory_quantity
       AND NEW.inventory_quantity <= NEW.low_stock_threshold THEN

        -- Insert alert if one doesn't already exist for this product today
        INSERT INTO alerts (type, severity, title, message, metadata)
        SELECT
            CASE WHEN NEW.inventory_quantity = 0 THEN 'low_stock' ELSE 'low_stock' END,
            CASE WHEN NEW.inventory_quantity = 0 THEN 'critical' ELSE 'warning' END,
            CASE WHEN NEW.inventory_quantity = 0
                 THEN 'Out of Stock: ' || COALESCE(NEW.title, NEW.sku, NEW.id::TEXT)
                 ELSE 'Low Stock Alert: ' || COALESCE(NEW.title, NEW.sku, NEW.id::TEXT)
            END,
            CASE WHEN NEW.inventory_quantity = 0
                 THEN 'Product is now out of stock'
                 ELSE 'Product inventory (' || NEW.inventory_quantity || ') is below threshold (' || NEW.low_stock_threshold || ')'
            END,
            jsonb_build_object(
                'product_id', NEW.id,
                'sku', NEW.sku,
                'current_stock', NEW.inventory_quantity,
                'threshold', NEW.low_stock_threshold,
                'previous_stock', OLD.inventory_quantity
            )
        WHERE NOT EXISTS (
            SELECT 1 FROM alerts
            WHERE type = 'low_stock'
              AND (metadata->>'product_id')::UUID = NEW.id
              AND created_at > NOW() - INTERVAL '1 hour'
              AND NOT is_resolved
        );
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Only create trigger if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'trigger_check_low_stock'
    ) THEN
        CREATE TRIGGER trigger_check_low_stock
            AFTER UPDATE OF inventory_quantity ON products
            FOR EACH ROW
            EXECUTE FUNCTION check_low_stock_alert();
    END IF;
END;
$$;

-- ============================================================================
-- REVENUE TRACKING FUNCTION
-- ============================================================================

-- Function to update product revenue when order is created/updated
CREATE OR REPLACE FUNCTION update_product_revenue()
RETURNS TRIGGER AS $$
DECLARE
    v_item JSONB;
    v_product_id UUID;
    v_quantity INTEGER;
    v_price DECIMAL;
BEGIN
    -- Only process completed/paid orders
    IF NEW.status IN ('delivered', 'shipped') AND NEW.payment_status = 'paid' THEN
        -- Parse order items from order_data
        FOR v_item IN SELECT * FROM jsonb_array_elements(NEW.order_data->'items')
        LOOP
            v_product_id := (v_item->>'productId')::UUID;
            v_quantity := COALESCE((v_item->>'quantity')::INTEGER, 1);
            v_price := COALESCE((v_item->>'price')::DECIMAL, 0);

            -- Update product stats
            UPDATE products
            SET
                revenue_total_usd = revenue_total_usd + (v_quantity * v_price),
                units_sold = units_sold + v_quantity,
                last_sale_at = NOW()
            WHERE id = v_product_id;
        END LOOP;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Only create trigger if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'trigger_update_product_revenue'
    ) THEN
        CREATE TRIGGER trigger_update_product_revenue
            AFTER INSERT OR UPDATE OF status, payment_status ON orders
            FOR EACH ROW
            EXECUTE FUNCTION update_product_revenue();
    END IF;
END;
$$;

-- ============================================================================
-- PRODUCT ANALYTICS VIEW
-- ============================================================================

CREATE OR REPLACE VIEW product_analytics_summary AS
SELECT
    p.id,
    p.title,
    p.sku,
    p.status,
    p.inventory_quantity,
    p.track_inventory,
    p.low_stock_threshold,
    CASE
        WHEN p.inventory_quantity = 0 THEN 'out_of_stock'
        WHEN p.inventory_quantity <= p.low_stock_threshold THEN 'low_stock'
        ELSE 'in_stock'
    END AS stock_status,
    p.revenue_total_usd,
    p.units_sold,
    CASE WHEN p.units_sold > 0
         THEN ROUND(p.revenue_total_usd / p.units_sold, 2)
         ELSE 0
    END AS avg_sale_price,
    p.last_sale_at,
    p.trending_score,
    ARRAY_LENGTH(p.published_platforms, 1) AS platform_count,
    p.published_platforms,
    p.sync_status,
    p.last_sync_at,
    p.generation_cost_usd,
    p.created_at,
    p.updated_at
FROM products p
WHERE p.status != 'deleted';

-- ============================================================================
-- LOW STOCK PRODUCTS VIEW
-- ============================================================================

CREATE OR REPLACE VIEW low_stock_products AS
SELECT
    p.id,
    p.title,
    p.sku,
    p.inventory_quantity,
    p.low_stock_threshold,
    (p.low_stock_threshold - p.inventory_quantity) AS units_needed,
    p.last_sale_at,
    p.units_sold,
    CASE
        WHEN p.units_sold > 0 AND p.last_sale_at IS NOT NULL
        THEN ROUND(p.units_sold::DECIMAL / GREATEST(1, EXTRACT(EPOCH FROM (NOW() - p.created_at)) / 86400), 2)
        ELSE 0
    END AS avg_daily_sales,
    p.published_platforms
FROM products p
WHERE p.track_inventory = TRUE
  AND p.inventory_quantity <= p.low_stock_threshold
  AND p.status NOT IN ('deleted', 'draft')
ORDER BY p.inventory_quantity ASC, p.units_sold DESC;

-- ============================================================================
-- VERSION TRACKING
-- ============================================================================

INSERT INTO schema_versions (version, description)
VALUES ('2.3.0', 'Enhanced products table with inventory tracking, revenue metrics, SKU generation, and analytics views')
ON CONFLICT (version) DO NOTHING;
