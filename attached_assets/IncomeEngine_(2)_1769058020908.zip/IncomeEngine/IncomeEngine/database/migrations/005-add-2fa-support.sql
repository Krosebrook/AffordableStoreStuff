-- ============================================================================
-- MIGRATION 005: Add 2FA/TOTP Support for Platform Credentials
-- ============================================================================
-- Adds columns for storing TOTP secrets for platforms requiring 2FA (Amazon KDP, etc.)
-- Run after 004-enhance-products-table.sql
-- ============================================================================

-- ============================================================================
-- PLATFORM CREDENTIALS ENHANCEMENTS
-- Add 2FA/TOTP support columns
-- ============================================================================

-- TOTP configuration columns
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS totp_secret_encrypted TEXT;
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS totp_algorithm TEXT CHECK (totp_algorithm IN ('sha1', 'sha256', 'sha512')) DEFAULT 'sha1';
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS totp_period INTEGER DEFAULT 30;
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS totp_digits INTEGER DEFAULT 6;

-- 2FA status tracking
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS requires_2fa BOOLEAN DEFAULT FALSE;
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS last_2fa_at TIMESTAMPTZ;
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS last_2fa_error TEXT;
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS consecutive_2fa_failures INTEGER DEFAULT 0;

-- Browser automation session data
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS session_cookies_encrypted TEXT;
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS session_expires_at TIMESTAMPTZ;
ALTER TABLE platform_credentials ADD COLUMN IF NOT EXISTS browser_fingerprint TEXT; -- For maintaining consistent sessions

-- ============================================================================
-- AUTH ATTEMPTS LOG
-- Track authentication attempts for security monitoring
-- ============================================================================

CREATE TABLE IF NOT EXISTS auth_attempts_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform TEXT NOT NULL,
    credential_id UUID REFERENCES platform_credentials(id) ON DELETE SET NULL,
    -- Attempt details
    attempt_type TEXT CHECK (attempt_type IN ('password', 'oauth', 'api_key', 'totp', 'session_refresh')) NOT NULL,
    success BOOLEAN NOT NULL,
    error_code TEXT,
    error_message TEXT,
    -- Risk indicators
    ip_address INET,
    user_agent TEXT,
    was_captcha_required BOOLEAN DEFAULT FALSE,
    captcha_solved BOOLEAN,
    was_rate_limited BOOLEAN DEFAULT FALSE,
    -- TOTP specific
    totp_was_used BOOLEAN DEFAULT FALSE,
    totp_remaining_seconds INTEGER, -- Time remaining when code was used
    totp_attempt_count INTEGER DEFAULT 1, -- How many codes tried this session
    -- Timing
    duration_ms INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for auth attempts
CREATE INDEX idx_auth_attempts_platform ON auth_attempts_log(platform, created_at DESC);
CREATE INDEX idx_auth_attempts_credential ON auth_attempts_log(credential_id, created_at DESC);
CREATE INDEX idx_auth_attempts_failed ON auth_attempts_log(success, platform, created_at DESC) WHERE success = FALSE;

-- ============================================================================
-- SECURITY FUNCTIONS
-- ============================================================================

-- Function to check if credential is blocked due to too many failures
CREATE OR REPLACE FUNCTION is_credential_blocked(
    p_credential_id UUID,
    p_max_failures INTEGER DEFAULT 5,
    p_lockout_minutes INTEGER DEFAULT 30
)
RETURNS BOOLEAN AS $$
DECLARE
    v_recent_failures INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_recent_failures
    FROM auth_attempts_log
    WHERE credential_id = p_credential_id
      AND success = FALSE
      AND created_at > NOW() - (p_lockout_minutes || ' minutes')::INTERVAL;

    RETURN v_recent_failures >= p_max_failures;
END;
$$ LANGUAGE plpgsql;

-- Function to record auth attempt and update credential status
CREATE OR REPLACE FUNCTION record_auth_attempt(
    p_platform TEXT,
    p_credential_id UUID,
    p_attempt_type TEXT,
    p_success BOOLEAN,
    p_error TEXT DEFAULT NULL,
    p_totp_used BOOLEAN DEFAULT FALSE
)
RETURNS UUID AS $$
DECLARE
    v_attempt_id UUID;
BEGIN
    -- Insert auth attempt record
    INSERT INTO auth_attempts_log (
        platform,
        credential_id,
        attempt_type,
        success,
        error_message,
        totp_was_used
    ) VALUES (
        p_platform,
        p_credential_id,
        p_attempt_type,
        p_success,
        p_error,
        p_totp_used
    ) RETURNING id INTO v_attempt_id;

    -- Update credential status
    IF p_success THEN
        UPDATE platform_credentials
        SET
            is_valid = TRUE,
            last_validated_at = NOW(),
            validation_error = NULL,
            consecutive_2fa_failures = 0,
            last_2fa_at = CASE WHEN p_totp_used THEN NOW() ELSE last_2fa_at END
        WHERE id = p_credential_id;
    ELSE
        UPDATE platform_credentials
        SET
            validation_error = p_error,
            consecutive_2fa_failures = CASE
                WHEN p_totp_used THEN consecutive_2fa_failures + 1
                ELSE consecutive_2fa_failures
            END,
            last_2fa_error = CASE WHEN p_totp_used THEN p_error ELSE last_2fa_error END,
            is_valid = CASE
                WHEN consecutive_2fa_failures + 1 >= 5 THEN FALSE
                ELSE is_valid
            END
        WHERE id = p_credential_id;
    END IF;

    -- Log to credential audit
    INSERT INTO credential_audit_log (
        credential_id,
        credential_type,
        platform,
        action,
        success,
        failure_reason,
        metadata
    ) VALUES (
        p_credential_id,
        'oauth_token',
        p_platform,
        CASE WHEN p_success THEN 'accessed' ELSE 'failed_auth' END,
        p_success,
        p_error,
        jsonb_build_object(
            'attempt_type', p_attempt_type,
            'totp_used', p_totp_used,
            'attempt_id', v_attempt_id
        )
    );

    RETURN v_attempt_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TOTP HELPER VIEW
-- Shows platforms that require TOTP and their configuration status
-- ============================================================================

CREATE OR REPLACE VIEW platform_2fa_status AS
SELECT
    pc.platform,
    pc.requires_2fa,
    CASE
        WHEN pc.totp_secret_encrypted IS NOT NULL THEN 'configured'
        WHEN pc.requires_2fa THEN 'required_not_configured'
        ELSE 'not_required'
    END AS totp_status,
    pc.totp_algorithm,
    pc.totp_period,
    pc.totp_digits,
    pc.last_2fa_at,
    pc.consecutive_2fa_failures,
    pc.last_2fa_error,
    pc.is_valid,
    pc.last_validated_at,
    pconn.display_name,
    pconn.connector_type
FROM platform_credentials pc
JOIN platform_connectors pconn ON pconn.platform = pc.platform
WHERE pc.requires_2fa = TRUE OR pc.totp_secret_encrypted IS NOT NULL;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE auth_attempts_log ENABLE ROW LEVEL SECURITY;

-- Service role policy
CREATE POLICY "Service role full access" ON auth_attempts_log FOR ALL USING (true);

-- ============================================================================
-- SEED DATA: Mark Amazon KDP as requiring 2FA
-- ============================================================================

-- Update Amazon KDP connector to indicate 2FA requirement
UPDATE platform_connectors
SET
    required_credentials = jsonb_set(
        COALESCE(required_credentials, '[]'::JSONB),
        '{0}',
        '{"name": "email", "type": "text", "required": true}'::JSONB
    ) || '[
        {"name": "password", "type": "password", "required": true},
        {"name": "totp_secret", "type": "secret", "required": false, "description": "Base32-encoded TOTP secret for 2FA"}
    ]'::JSONB,
    capabilities = capabilities || '{"requires_2fa": true, "requires_browser": true}'::JSONB,
    updated_at = NOW()
WHERE platform = 'amazon_kdp';

-- ============================================================================
-- VERSION TRACKING
-- ============================================================================

INSERT INTO schema_versions (version, description)
VALUES ('2.4.0', 'Added 2FA/TOTP support for platform credentials, auth attempts logging, and security functions')
ON CONFLICT (version) DO NOTHING;
