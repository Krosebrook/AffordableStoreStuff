# Best Practices

-   Clean margins
-   Typography consistency
-   Keyword strategy
