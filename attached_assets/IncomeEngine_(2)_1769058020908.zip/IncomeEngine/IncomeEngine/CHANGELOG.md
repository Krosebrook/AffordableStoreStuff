# Changelog

All notable changes to the Income Engine project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

#### AI Design Generation Pipeline (PRD #1)
- Multi-provider image generation with failover (DALL-E 3 → Flux → Stability SD3)
- `src/services/design-generator/` with:
  - Provider abstraction layer (`providers/base-provider.ts`)
  - OpenAI DALL-E 3 integration (`providers/openai-dalle.ts`)
  - Replicate Flux Pro/Dev/Schnell (`providers/replicate-flux.ts`)
  - Stability AI SD3 (`providers/stability-sd3.ts`)
  - Dynamic prompt builder with niche templates (`templates/prompt-builder.ts`)
  - Post-processing: upscaler, background remover
  - Quality validation and platform-specific requirements

#### Predictive Analytics Engine (PRD #2)
- ML-powered forecasting at `src/services/analytics-engine/`
  - Moving average model for short-term predictions
  - Exponential smoothing (Holt-Winters) for trends
  - Linear regression for growth analysis
  - Seasonal decomposition for pattern detection
  - Revenue predictor with confidence intervals

#### Multi-Platform Sync Engine (PRD #3)
- Real-time bidirectional sync at `src/services/sync-engine/`
  - Sync manager with conflict detection
  - Conflict resolver with configurable strategies
  - Inventory sync strategy
  - Price sync strategy
  - Order sync strategy

#### Intelligent Pricing Optimizer (PRD #4)
- Dynamic pricing at `src/services/pricing-optimizer/`
  - Competitor price scraper and tracker
  - Price change alert service
  - Elasticity calculator for demand analysis
  - Seasonality detector
  - Conversion rate analyzer
  - Margin protector with rules engine

#### Mobile Command Center (PRD #5)
- Mobile-first components at `src/client/components/mobile/`
  - MobileHeader with status indicators
  - TabBar with notification badges
  - SwipeableCard for approve/reject gestures
  - PullToRefresh for native-like experience
  - OfflineIndicator for connectivity status
- Mobile navigation at `src/client/mobile/navigation/`
- Push notification service with FCM/APNs support

#### Niche Research Automation
- `src/services/niche-research/` with:
  - Trend scanner for Google Trends and social signals
  - Keyword analyzer for search volume and competition
  - Competitor tracker for listing monitoring
  - Opportunity scorer for niche ranking

#### Bulk Operations Processor
- `src/services/bulk-operations/` with:
  - Batch processor for 100+ products
  - Progress tracker with webhook callbacks
  - Rollback manager for partial failures

#### Order Fulfillment Pipeline
- `src/services/fulfillment/` with:
  - Order aggregator from all platforms
  - Fulfillment router to POD providers
  - Tracking updater for all platforms
  - Return handler for refunds

#### Analytics Dashboard
- New Analytics page with interactive charts
- Chart components at `src/client/components/analytics/`
  - RevenueChart with time series
  - PlatformComparison with bar charts
  - ProductPerformance with rankings
  - TrendIndicators with sparklines
- Analytics hooks for data fetching

#### Reporting System
- `src/services/reporting/` with:
  - CSV export for spreadsheets
  - PDF export for reports
  - Email sender for scheduled reports

#### Production Hardening
- Structured logging with Winston (`src/server/services/logger.ts`)
- Health monitoring (`src/server/services/monitoring.ts`)
- Caching layer (`src/server/services/cache.ts`)
- Error handling middleware (`src/server/middleware/error-handler.ts`)
- Response optimizer (`src/server/middleware/response-optimizer.ts`)
- Analytics API routes (`src/server/routes/analytics.ts`)

#### Test Coverage
- Comprehensive safeguard tests at `src/safeguards/__tests__/`
  - rate-limiter.test.ts
  - quality-gate.test.ts
  - trademark-screener.test.ts
  - api-queue.test.ts
  - provider-failover.test.ts
  - tax-compliance.test.ts
  - human-in-the-loop.test.ts
  - budget-circuit-breaker.test.ts
  - orchestrator.test.ts
- Test utilities with comprehensive mocks

#### Hooks and Utilities
- useAnalytics - Revenue, platform, product analytics
- useChartData - Chart data transformation
- useNetworkStatus - Online/offline detection
- useOfflineSync - Queue actions offline
- usePushNotifications - Push notification management

#### Database Migrations
- `006-design-generator.sql` - Design generations and prompt templates

#### Previous (MCP Server)
- MCP (Model Context Protocol) server for AI assistant integration
  - 9 tools: list_platforms, connect_platform, create_product, list_products, get_analytics, check_safeguards, reset_safeguard, run_workflow, get_workflow_status
  - 4 resources: platforms://status, products://pending, analytics://dashboard, budget://current
- TOTP/2FA support for Amazon KDP adapter (`src/connectors/utils/totp.ts`)
- Webhook notification service (`src/connectors/utils/webhook.ts`)
  - Queue-based delivery with retry and exponential backoff
  - Support for 11 event types (low stock, orders, products, budget, etc.)
- Complete marketplace analytics with webhook notifications
- Daily revenue aggregation and return rate calculations
- Database migrations:
  - `003-add-webhook-tables.sql` - Webhook queue, log, and endpoints
  - `004-enhance-products-table.sql` - Inventory tracking, SKU generation, analytics views
  - `005-add-2fa-support.sql` - TOTP credentials and auth attempt logging

#### Documentation Overhaul
- New `docs/API.md` with complete REST API reference (20+ endpoints documented)
- New `docs/ARCHITECTURE.md` with ASCII system diagrams and data flows
- Updated `CLAUDE.md` with:
  - Workflow engines (POD/Digital and Marketplace)
  - Utility services (TOTP, Webhooks, Retry Handler)
  - Complete API endpoint reference
  - Mobile app setup instructions
  - n8n workflow reference
- Updated `README.md` with:
  - Architecture diagram
  - Comprehensive feature list
  - Enhanced platform support table
  - Native app build instructions
- Updated `docs/DEPLOYMENT.md` with:
  - Mobile app deployment (PWA and Capacitor)
  - Webhook configuration
  - Expanded environment variables (50+ documented)
  - Push notification setup guidance
- Updated `docs/RUNBOOK.md` with:
  - New troubleshooting sections for sync, webhooks, TOTP, mobile
  - Workflow engine issues
  - Database troubleshooting
  - Feature flag management
  - Expanded emergency procedures

### Changed
- Updated all documentation to reflect new services
- Improved Amazon KDP browser automation with proper 2FA handling
- Enhanced marketplace workflow with complete analytics
- Refactored server with middleware architecture
- Added lazy loading for frontend routes
- Improved error messages with actionable guidance

### Fixed
- Amazon KDP authentication now supports 2FA/OTP
- Marketplace analytics calculations now complete
- Webhook notification delivery system
- Memory leaks in Playwright adapters
- Browser cleanup in trademark screener
- Fixed malformed Bash permission patterns in `.claude/settings.local.json`
- Added comprehensive tool permissions for MCP server, agents, and development commands

## [2.0.0] - 2025-12-29

### Added
- 11 Platform Connectors
  - POD: Printify, Etsy, TeePublic, Society6, Redbubble
  - Digital: Gumroad, Creative Fabrica, Amazon KDP
  - Marketplace: Shopify, WooCommerce, TikTok Shop
- 8 Safeguard Systems
  - Rate Limiter with per-API throttling
  - Quality Gate with AI-powered scoring
  - Trademark Screener with USPTO TESS integration
  - API Queue with priority and exponential backoff
  - Provider Failover for multi-provider redundancy
  - Tax Compliance with nexus tracking
  - Human-in-the-Loop approval workflow
  - Budget Circuit Breaker with spending limits
- React 18 PWA Dashboard
  - Overview, Approvals, Budget, Settings pages
  - Mobile-responsive design with Tailwind CSS
  - Offline support with service worker
- n8n Workflow Integration
  - 8 automated workflows for product lifecycle
- Capacitor Mobile App Support
  - Android and iOS builds

### Changed
- Migrated to TypeScript strict mode
- Updated to TanStack Query v5
- Improved error handling across all connectors

## [1.0.0] - 2025-11-01

### Added
- Initial release
- Basic product management
- Printify and Etsy integrations
- Simple dashboard

---

## Version History

| Version | Date | Highlights |
|---------|------|------------|
| Unreleased | - | Design generator, analytics engine, sync engine, pricing optimizer, mobile, docs |
| 2.0.0 | 2025-12-29 | 11 connectors, 8 safeguards, MCP server, PWA dashboard |
| 1.0.0 | 2025-11-01 | Initial release |

---

## Migration Guide

### From 1.0.0 to 2.0.0

1. **Database Migration**
   ```bash
   # Run schema v2
   psql -f database/schema-v2.sql

   # Run connector migrations
   psql -f database/migrations/002-add-connector-tables.sql
   ```

2. **Environment Variables**
   Add new required variables:
   ```
   REPLICATE_API_TOKEN=
   MAX_DAILY_AI_SPEND=5.00
   MAX_MONTHLY_BUDGET=150.00
   ```

3. **Frontend Updates**
   The new PWA dashboard replaces the old interface:
   ```bash
   npm run build
   ```

### From 2.0.0 to Unreleased

1. **Database Migrations**
   ```bash
   psql -f database/migrations/003-add-webhook-tables.sql
   psql -f database/migrations/004-enhance-products-table.sql
   psql -f database/migrations/005-add-2fa-support.sql
   psql -f database/migrations/006-design-generator.sql
   ```

2. **New Environment Variables**
   ```
   # Inventory Sync
   INVENTORY_SYNC_INTERVAL_MS=300000
   ORDER_SYNC_INTERVAL_MS=120000
   LOW_STOCK_THRESHOLD=5

   # AI Providers (optional failover)
   ANTHROPIC_API_KEY=
   STABILITY_API_KEY=
   ```

3. **MCP Server Setup**
   ```bash
   cd mcp-server
   npm install
   node index.js --test
   ```

---

*Last Updated: December 2025*
