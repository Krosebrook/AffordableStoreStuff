#!/bin/bash
# ============================================================
# n8n Self-Hosted Setup Script
# For Ubuntu 22.04 LTS VPS ($5-10/month tier)
# ============================================================

set -e

echo "🚀 n8n Passive Income Engine Setup"
echo "==================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root (sudo)${NC}"
    exit 1
fi

# ============================================================
# SYSTEM PREPARATION
# ============================================================

echo -e "\n${YELLOW}[1/6] Updating system...${NC}"
apt update && apt upgrade -y

echo -e "\n${YELLOW}[2/6] Installing dependencies...${NC}"
apt install -y \
    curl \
    git \
    nginx \
    certbot \
    python3-certbot-nginx \
    ufw

# ============================================================
# DOCKER INSTALLATION
# ============================================================

echo -e "\n${YELLOW}[3/6] Installing Docker...${NC}"

if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
fi

if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

echo -e "${GREEN}Docker version: $(docker --version)${NC}"

# ============================================================
# CREATE n8n DIRECTORY STRUCTURE
# ============================================================

echo -e "\n${YELLOW}[4/6] Setting up n8n directories...${NC}"

N8N_DIR="/opt/n8n"
mkdir -p $N8N_DIR
cd $N8N_DIR

# Create docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  n8n:
    image: docker.n8n.io/n8nio/n8n:latest
    container_name: n8n
    restart: always
    ports:
      - "5678:5678"
    environment:
      # Basic auth (change these!)
      - N8N_BASIC_AUTH_ACTIVE=true
      - N8N_BASIC_AUTH_USER=${N8N_USER:-admin}
      - N8N_BASIC_AUTH_PASSWORD=${N8N_PASSWORD:-changeme123}
      
      # Database (PostgreSQL for production)
      - DB_TYPE=postgresdb
      - DB_POSTGRESDB_HOST=postgres
      - DB_POSTGRESDB_PORT=5432
      - DB_POSTGRESDB_DATABASE=n8n
      - DB_POSTGRESDB_USER=n8n
      - DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD:-n8n_password}
      
      # Webhook URL (update with your domain)
      - WEBHOOK_URL=${WEBHOOK_URL:-http://localhost:5678/}
      - N8N_HOST=${N8N_HOST:-localhost}
      - N8N_PROTOCOL=https
      
      # Execution settings
      - EXECUTIONS_DATA_SAVE_ON_ERROR=all
      - EXECUTIONS_DATA_SAVE_ON_SUCCESS=all
      - EXECUTIONS_DATA_SAVE_ON_PROGRESS=true
      - EXECUTIONS_DATA_SAVE_MANUAL_EXECUTIONS=true
      
      # Performance
      - N8N_METRICS=true
      - N8N_LOG_LEVEL=info
      
      # Timezone
      - GENERIC_TIMEZONE=America/Chicago
      - TZ=America/Chicago
      
    volumes:
      - n8n_data:/home/node/.n8n
      - ./workflows:/home/node/workflows
    depends_on:
      - postgres

  postgres:
    image: postgres:15-alpine
    container_name: n8n-postgres
    restart: always
    environment:
      - POSTGRES_USER=n8n
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-n8n_password}
      - POSTGRES_DB=n8n
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U n8n"]
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  n8n_data:
  postgres_data:
EOF

# Create .env file
cat > .env << 'EOF'
# n8n Configuration
N8N_USER=admin
N8N_PASSWORD=YOUR_SECURE_PASSWORD_HERE
POSTGRES_PASSWORD=YOUR_POSTGRES_PASSWORD_HERE

# Domain configuration (update these!)
N8N_HOST=n8n.yourdomain.com
WEBHOOK_URL=https://n8n.yourdomain.com/

# API Keys (add in n8n UI, not here for security)
# REPLICATE_API_TOKEN=
# OPENAI_API_KEY=
# PRINTIFY_API_TOKEN=
EOF

echo -e "${GREEN}Created docker-compose.yml and .env${NC}"

# ============================================================
# NGINX CONFIGURATION
# ============================================================

echo -e "\n${YELLOW}[5/6] Configuring Nginx reverse proxy...${NC}"

# Get domain from user
read -p "Enter your domain (e.g., n8n.yourdomain.com): " DOMAIN

if [ -z "$DOMAIN" ]; then
    echo -e "${YELLOW}No domain provided. Using localhost.${NC}"
    DOMAIN="localhost"
fi

# Create Nginx config
cat > /etc/nginx/sites-available/n8n << EOF
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://localhost:5678;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        
        # Timeouts for long-running workflows
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
        proxy_read_timeout 300;
        send_timeout 300;
        
        # Buffer settings
        proxy_buffer_size 128k;
        proxy_buffers 4 256k;
        proxy_busy_buffers_size 256k;
    }
}
EOF

ln -sf /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# ============================================================
# SSL CERTIFICATE (if real domain)
# ============================================================

if [ "$DOMAIN" != "localhost" ]; then
    echo -e "\n${YELLOW}Setting up SSL with Let's Encrypt...${NC}"
    
    read -p "Enter your email for SSL certificate: " EMAIL
    
    if [ -n "$EMAIL" ]; then
        certbot --nginx -d $DOMAIN --non-interactive --agree-tos -m $EMAIL
    else
        echo -e "${YELLOW}Skipping SSL setup (no email provided)${NC}"
    fi
fi

# ============================================================
# FIREWALL CONFIGURATION
# ============================================================

echo -e "\n${YELLOW}[6/6] Configuring firewall...${NC}"

ufw allow ssh
ufw allow http
ufw allow https
ufw --force enable

# ============================================================
# START n8n
# ============================================================

echo -e "\n${YELLOW}Starting n8n...${NC}"

cd $N8N_DIR
docker-compose up -d

# Wait for n8n to start
echo "Waiting for n8n to start..."
sleep 10

# Check if n8n is running
if docker ps | grep -q n8n; then
    echo -e "${GREEN}✅ n8n is running!${NC}"
else
    echo -e "${RED}❌ n8n failed to start. Check logs with: docker-compose logs${NC}"
    exit 1
fi

# ============================================================
# CREATE WORKFLOW IMPORT SCRIPT
# ============================================================

cat > $N8N_DIR/import-workflows.sh << 'IMPORT_EOF'
#!/bin/bash
# Import Income Engine workflows to n8n

N8N_URL="${N8N_URL:-http://localhost:5678}"
N8N_API_KEY="${N8N_API_KEY:-}"

if [ -z "$N8N_API_KEY" ]; then
    echo "Please set N8N_API_KEY environment variable"
    echo "Get it from: n8n Settings > API > Create API Key"
    exit 1
fi

WORKFLOWS_DIR="./workflows"

for workflow in $WORKFLOWS_DIR/*.json; do
    echo "Importing: $workflow"
    curl -X POST "$N8N_URL/api/v1/workflows" \
        -H "X-N8N-API-KEY: $N8N_API_KEY" \
        -H "Content-Type: application/json" \
        -d @"$workflow"
    echo ""
done

echo "Done! Check n8n UI for imported workflows."
IMPORT_EOF

chmod +x $N8N_DIR/import-workflows.sh

# ============================================================
# FINAL OUTPUT
# ============================================================

echo ""
echo "============================================================"
echo -e "${GREEN}✅ n8n Installation Complete!${NC}"
echo "============================================================"
echo ""
echo "📍 n8n URL: https://$DOMAIN"
echo "📍 Default Login: admin / YOUR_SECURE_PASSWORD_HERE"
echo ""
echo "⚠️  IMPORTANT NEXT STEPS:"
echo "1. Update passwords in: $N8N_DIR/.env"
echo "2. Restart n8n: cd $N8N_DIR && docker-compose restart"
echo "3. Add API credentials in n8n UI:"
echo "   - Replicate (for Flux image generation)"
echo "   - OpenAI (for GPT-4o-mini)"
echo "   - Printify API token"
echo "   - Etsy OAuth"
echo "   - Gumroad OAuth"
echo "   - Supabase"
echo "   - Slack webhook"
echo ""
echo "4. Import workflows:"
echo "   - Copy workflow JSON files to: $N8N_DIR/workflows/"
echo "   - Get API key from n8n Settings > API"
echo "   - Run: N8N_API_KEY=your_key $N8N_DIR/import-workflows.sh"
echo ""
echo "📚 Useful commands:"
echo "   docker-compose logs -f n8n     # View n8n logs"
echo "   docker-compose restart         # Restart n8n"
echo "   docker-compose down            # Stop n8n"
echo "   docker-compose up -d           # Start n8n"
echo ""
echo "💡 Estimated monthly cost:"
echo "   VPS: \$5-10"
echo "   APIs: \$15-30"
echo "   Total: \$20-40"
echo ""
echo "============================================================"
