-- ============================================================
-- INCOME ENGINE DATABASE SCHEMA EXTENSIONS
-- Extends the existing safeguards schema with revenue tracking
-- ============================================================

-- ============================================================
-- TRENDING NICHES TABLE
-- Stores discovered niches with scoring
-- ============================================================
CREATE TABLE IF NOT EXISTS public.trending_niches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL,
    products JSONB DEFAULT '[]',
    demand_score INTEGER DEFAULT 0 CHECK (demand_score >= 0 AND demand_score <= 100),
    seasonal_boost DECIMAL(3,2) DEFAULT 1.0,
    final_score INTEGER DEFAULT 0,
    competition_level VARCHAR(20) DEFAULT 'medium' CHECK (competition_level IN ('low', 'medium', 'high')),
    recommended_products JSONB DEFAULT '[]',
    scanned_at TIMESTAMPTZ DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_trending_niches_score ON public.trending_niches(final_score DESC);
CREATE INDEX idx_trending_niches_category ON public.trending_niches(category);

-- ============================================================
-- GENERATED PRODUCTS TABLE
-- Stores all generated products and their status
-- ============================================================
CREATE TABLE IF NOT EXISTS public.generated_products (
    id VARCHAR(100) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    tags JSONB DEFAULT '[]',
    image_url TEXT,
    image_prompt TEXT,
    niche VARCHAR(100) REFERENCES public.trending_niches(name),
    sub_niche VARCHAR(100),
    product_type VARCHAR(50) NOT NULL,
    target_platform VARCHAR(50) NOT NULL,
    target_audience TEXT,
    price_range VARCHAR(20) DEFAULT 'medium',
    design_concept VARCHAR(100),
    
    -- Status tracking
    status VARCHAR(30) DEFAULT 'pending' CHECK (status IN ('pending', 'pending_safeguards', 'approved', 'rejected', 'published', 'archived')),
    rejection_reason TEXT,
    quality_score INTEGER,
    
    -- Publishing status
    published_printify BOOLEAN DEFAULT FALSE,
    printify_product_id VARCHAR(100),
    published_etsy BOOLEAN DEFAULT FALSE,
    etsy_listing_id VARCHAR(100),
    published_gumroad BOOLEAN DEFAULT FALSE,
    gumroad_product_id VARCHAR(100),
    gumroad_url TEXT,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    approved_at TIMESTAMPTZ,
    published_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_generated_products_status ON public.generated_products(status);
CREATE INDEX idx_generated_products_niche ON public.generated_products(niche);
CREATE INDEX idx_generated_products_platform ON public.generated_products(target_platform);
CREATE INDEX idx_generated_products_published ON public.generated_products(published_printify, published_etsy, published_gumroad);

-- ============================================================
-- REJECTED PRODUCTS TABLE
-- Stores rejected products for analysis
-- ============================================================
CREATE TABLE IF NOT EXISTS public.rejected_products (
    id VARCHAR(100) PRIMARY KEY,
    title VARCHAR(200),
    rejection_reason TEXT NOT NULL,
    rejection_stage VARCHAR(50),
    niche VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_rejected_products_reason ON public.rejected_products(rejection_reason);

-- ============================================================
-- REVENUE SNAPSHOTS TABLE
-- Stores periodic revenue aggregations
-- ============================================================
CREATE TABLE IF NOT EXISTS public.revenue_snapshots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period VARCHAR(30) UNIQUE NOT NULL,
    aggregated_at TIMESTAMPTZ NOT NULL,
    platforms JSONB NOT NULL DEFAULT '{}',
    totals JSONB NOT NULL DEFAULT '{}',
    goal_tracking JSONB DEFAULT '{}',
    estimated_costs JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_revenue_snapshots_period ON public.revenue_snapshots(period);
CREATE INDEX idx_revenue_snapshots_date ON public.revenue_snapshots(aggregated_at DESC);

-- ============================================================
-- SALES RECORDS TABLE
-- Individual sales for detailed tracking
-- ============================================================
CREATE TABLE IF NOT EXISTS public.sales_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform VARCHAR(50) NOT NULL,
    platform_order_id VARCHAR(100),
    product_id VARCHAR(100) REFERENCES public.generated_products(id),
    
    -- Financial
    gross_amount DECIMAL(10,2) NOT NULL,
    platform_fees DECIMAL(10,2) DEFAULT 0,
    production_cost DECIMAL(10,2) DEFAULT 0,
    net_profit DECIMAL(10,2) GENERATED ALWAYS AS (gross_amount - platform_fees - production_cost) STORED,
    currency VARCHAR(3) DEFAULT 'USD',
    
    -- Order details
    quantity INTEGER DEFAULT 1,
    customer_country VARCHAR(2),
    
    -- Timestamps
    sale_date TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sales_records_platform ON public.sales_records(platform);
CREATE INDEX idx_sales_records_date ON public.sales_records(sale_date DESC);
CREATE INDEX idx_sales_records_product ON public.sales_records(product_id);

-- ============================================================
-- AI GENERATION COSTS TABLE
-- Track API costs for budget management
-- ============================================================
CREATE TABLE IF NOT EXISTS public.ai_generation_costs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    operation VARCHAR(50) NOT NULL, -- 'image_generation', 'text_generation', etc.
    
    -- Cost details
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    images_generated INTEGER DEFAULT 0,
    cost_usd DECIMAL(10,6) NOT NULL,
    
    -- Metadata
    product_id VARCHAR(100),
    workflow_id VARCHAR(100),
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_ai_costs_provider ON public.ai_generation_costs(provider);
CREATE INDEX idx_ai_costs_date ON public.ai_generation_costs(created_at DESC);

-- ============================================================
-- PRODUCT TEMPLATES TABLE
-- Reusable product templates
-- ============================================================
CREATE TABLE IF NOT EXISTS public.product_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) UNIQUE NOT NULL,
    product_type VARCHAR(50) NOT NULL,
    platform VARCHAR(50) NOT NULL,
    
    -- Template data
    title_template TEXT,
    description_template TEXT,
    tags_template JSONB DEFAULT '[]',
    image_prompt_template TEXT,
    
    -- Printify specifics
    blueprint_id INTEGER,
    print_provider_id INTEGER,
    placement_config JSONB DEFAULT '{}',
    
    -- Pricing
    base_price_cents INTEGER,
    markup_cents INTEGER,
    
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- DAILY METRICS VIEW
-- Aggregated daily metrics
-- ============================================================
CREATE OR REPLACE VIEW public.daily_metrics AS
SELECT 
    DATE(sale_date) as date,
    COUNT(*) as total_sales,
    SUM(gross_amount) as gross_revenue,
    SUM(net_profit) as net_profit,
    AVG(gross_amount) as avg_order_value,
    COUNT(DISTINCT product_id) as unique_products_sold
FROM public.sales_records
GROUP BY DATE(sale_date)
ORDER BY date DESC;

-- ============================================================
-- PLATFORM PERFORMANCE VIEW
-- Performance by platform
-- ============================================================
CREATE OR REPLACE VIEW public.platform_performance AS
SELECT 
    platform,
    COUNT(*) as total_sales,
    SUM(gross_amount) as gross_revenue,
    SUM(net_profit) as net_profit,
    AVG(net_profit) as avg_profit_per_sale,
    SUM(platform_fees) as total_fees,
    (SUM(net_profit) / NULLIF(SUM(gross_amount), 0) * 100)::DECIMAL(5,2) as profit_margin_pct
FROM public.sales_records
WHERE sale_date >= NOW() - INTERVAL '30 days'
GROUP BY platform;

-- ============================================================
-- NICHE PERFORMANCE VIEW
-- Performance by niche
-- ============================================================
CREATE OR REPLACE VIEW public.niche_performance AS
SELECT 
    gp.niche,
    COUNT(sr.*) as total_sales,
    SUM(sr.gross_amount) as gross_revenue,
    SUM(sr.net_profit) as net_profit,
    COUNT(DISTINCT gp.id) as products_count,
    (COUNT(sr.*) / NULLIF(COUNT(DISTINCT gp.id), 0))::DECIMAL(5,2) as sales_per_product
FROM public.generated_products gp
LEFT JOIN public.sales_records sr ON sr.product_id = gp.id
WHERE gp.status = 'published'
GROUP BY gp.niche;

-- ============================================================
-- GOAL PROGRESS FUNCTION
-- Calculate progress towards monthly goal
-- ============================================================
CREATE OR REPLACE FUNCTION public.get_goal_progress(goal_amount DECIMAL DEFAULT 1000)
RETURNS TABLE (
    current_month_profit DECIMAL,
    goal DECIMAL,
    percent_complete DECIMAL,
    days_remaining INTEGER,
    daily_target DECIMAL,
    projected_total DECIMAL,
    on_track BOOLEAN
) AS $$
DECLARE
    month_start DATE := DATE_TRUNC('month', CURRENT_DATE);
    month_end DATE := (DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::DATE;
    days_in_month INTEGER := EXTRACT(DAY FROM month_end);
    current_day INTEGER := EXTRACT(DAY FROM CURRENT_DATE);
    total_profit DECIMAL;
    daily_avg DECIMAL;
BEGIN
    -- Get current month profit
    SELECT COALESCE(SUM(net_profit), 0) INTO total_profit
    FROM public.sales_records
    WHERE sale_date >= month_start;
    
    daily_avg := total_profit / GREATEST(current_day, 1);
    
    RETURN QUERY SELECT 
        total_profit,
        goal_amount,
        (total_profit / goal_amount * 100)::DECIMAL(5,2),
        days_in_month - current_day,
        ((goal_amount - total_profit) / GREATEST(days_in_month - current_day, 1))::DECIMAL(10,2),
        (daily_avg * days_in_month)::DECIMAL(10,2),
        (daily_avg * days_in_month) >= goal_amount;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
ALTER TABLE public.trending_niches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generated_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rejected_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.revenue_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_generation_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_templates ENABLE ROW LEVEL SECURITY;

-- Service role access (for n8n workflows)
CREATE POLICY "Service role full access" ON public.trending_niches FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.generated_products FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.rejected_products FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.revenue_snapshots FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.sales_records FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.ai_generation_costs FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.product_templates FOR ALL USING (auth.role() = 'service_role');

-- ============================================================
-- SEED DATA: TOP NICHES
-- ============================================================
INSERT INTO public.trending_niches (name, category, products, demand_score, competition_level, recommended_products) VALUES
('dog-breed-specific', 'pets', '["mugs", "tshirts", "totes", "posters"]', 90, 'medium', '["mugs", "tshirts"]'),
('pet-portraits', 'pets', '["mugs", "posters", "canvas", "blankets"]', 85, 'medium', '["posters", "mugs"]'),
('teacher-appreciation', 'occupation', '["totes", "mugs", "stickers", "tshirts"]', 80, 'medium', '["totes", "mugs"]'),
('nurse-healthcare', 'occupation', '["tumblers", "tshirts", "badges", "mugs"]', 78, 'low', '["tumblers", "tshirts"]'),
('plant-parent', 'lifestyle', '["mugs", "totes", "stickers", "posters"]', 75, 'low', '["mugs", "totes"]'),
('astrology-zodiac', 'spiritual', '["posters", "journals", "mugs", "tshirts"]', 82, 'medium', '["posters", "journals"]'),
('gaming-retro', 'hobby', '["posters", "mousepads", "hoodies", "tshirts"]', 88, 'high', '["posters", "mousepads"]'),
('minimalist-quotes', 'decor', '["posters", "printables", "mugs", "canvas"]', 70, 'high', '["posters", "printables"]'),
('eco-activism', 'values', '["totes", "stickers", "tshirts", "water_bottles"]', 72, 'low', '["totes", "stickers"]'),
('mom-life-humor', 'parenting', '["mugs", "tshirts", "tumblers", "totes"]', 85, 'medium', '["mugs", "tshirts"]')
ON CONFLICT (name) DO UPDATE SET
    demand_score = EXCLUDED.demand_score,
    updated_at = NOW();

-- ============================================================
-- SEED DATA: PRODUCT TEMPLATES
-- ============================================================
INSERT INTO public.product_templates (name, product_type, platform, blueprint_id, print_provider_id, title_template, description_template, base_price_cents, markup_cents) VALUES
('bella-canvas-tshirt', 'pod_tshirt', 'printify', 145, 99, 
 '{{design_name}} T-Shirt | {{niche}} Gift | Unisex Bella Canvas',
 'Show off your {{niche}} pride with this comfortable, premium quality t-shirt.\n\n✨ Features:\n• 100% ring-spun cotton\n• Pre-shrunk fabric\n• Side-seamed construction\n• Unisex fit\n\nPerfect for {{target_audience}}!',
 1500, 800),
 
('classic-mug', 'pod_mug', 'printify', 68, 28,
 '{{design_name}} Mug | {{niche}} Coffee Cup | 11oz Ceramic',
 'Start your day with this beautiful {{niche}}-themed mug!\n\n☕ Features:\n• 11oz ceramic mug\n• Microwave & dishwasher safe\n• Vibrant, fade-resistant print\n\nMakes a perfect gift for {{target_audience}}!',
 800, 600),

('poster-print', 'pod_poster', 'printify', 1, 27,
 '{{design_name}} Wall Art | {{niche}} Poster | Home Decor Print',
 'Transform your space with this stunning {{niche}} wall art!\n\n🖼️ Features:\n• Museum-quality print\n• Matte finish\n• Available in multiple sizes\n• Fade-resistant inks\n\nPerfect for {{target_audience}} looking to add personality to their space!',
 1000, 1000),

('digital-printable', 'digital_printable', 'gumroad',
 NULL, NULL,
 '{{design_name}} Digital Download | {{niche}} Printable Art | Instant Download',
 'Instantly download this beautiful {{niche}} printable art!\n\n📥 What You Get:\n• High-resolution PDF & PNG files\n• Multiple sizes included (8x10, 11x14, 16x20)\n• Print at home or at any print shop\n• Lifetime access\n\n⚠️ This is a DIGITAL product. No physical item will be shipped.',
 299, 0)
ON CONFLICT (name) DO NOTHING;

-- ============================================================
-- BATCH JOBS TABLE
-- Track batch processing jobs
-- ============================================================
CREATE TABLE IF NOT EXISTS public.batch_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id VARCHAR(100) UNIQUE NOT NULL,
    niche VARCHAR(100),
    sub_niches JSONB DEFAULT '[]',
    total_products INTEGER NOT NULL,
    completed_products INTEGER DEFAULT 0,
    failed_products INTEGER DEFAULT 0,
    estimated_cost DECIMAL(10,4),
    actual_cost DECIMAL(10,4),
    status VARCHAR(30) DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
    error_message TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_batch_jobs_status ON public.batch_jobs(status);
CREATE INDEX idx_batch_jobs_created ON public.batch_jobs(created_at DESC);

-- ============================================================
-- PLATFORM CREDENTIALS TABLE
-- Securely store OAuth tokens (encrypted at rest by Supabase)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.platform_credentials (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform VARCHAR(50) NOT NULL,
    shop_id VARCHAR(100),
    credentials JSONB NOT NULL, -- Encrypted by Supabase vault
    expires_at TIMESTAMPTZ,
    is_valid BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(platform, shop_id)
);

CREATE INDEX idx_platform_credentials_platform ON public.platform_credentials(platform);

-- ============================================================
-- PLATFORM ACTIVITY LOG TABLE
-- Track all platform API interactions
-- ============================================================
CREATE TABLE IF NOT EXISTS public.platform_activity_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    details JSONB DEFAULT '{}',
    status VARCHAR(20) DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_platform_activity_platform ON public.platform_activity_log(platform);
CREATE INDEX idx_platform_activity_action ON public.platform_activity_log(action);
CREATE INDEX idx_platform_activity_created ON public.platform_activity_log(created_at DESC);

-- Partition by month for performance (optional, for high-volume)
-- CREATE TABLE public.platform_activity_log_y2024m12 PARTITION OF public.platform_activity_log
-- FOR VALUES FROM ('2024-12-01') TO ('2025-01-01');

-- ============================================================
-- GUMROAD PRODUCTS SYNC TABLE
-- Cache of Gumroad products for faster lookups
-- ============================================================
CREATE TABLE IF NOT EXISTS public.gumroad_products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    gumroad_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2),
    url TEXT,
    short_url TEXT,
    published BOOLEAN DEFAULT FALSE,
    sales_count INTEGER DEFAULT 0,
    revenue DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_gumroad_products_published ON public.gumroad_products(published);

-- ============================================================
-- SAFEGUARD CHECKS TABLE
-- Log all safeguard validation results
-- ============================================================
CREATE TABLE IF NOT EXISTS public.safeguard_checks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id VARCHAR(100) REFERENCES public.generated_products(id),
    check_type VARCHAR(50) NOT NULL, -- 'trademark', 'quality', 'content', 'rate_limit'
    passed BOOLEAN NOT NULL,
    score DECIMAL(5,2),
    details JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_safeguard_checks_product ON public.safeguard_checks(product_id);
CREATE INDEX idx_safeguard_checks_type ON public.safeguard_checks(check_type);

-- ============================================================
-- BUDGET TRACKING TABLE
-- Daily budget usage tracking
-- ============================================================
CREATE TABLE IF NOT EXISTS public.budget_tracking (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    category VARCHAR(50) NOT NULL, -- 'ai_generation', 'platform_fees', 'hosting', etc.
    amount DECIMAL(10,4) NOT NULL,
    budget_limit DECIMAL(10,4),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(date, category)
);

CREATE INDEX idx_budget_tracking_date ON public.budget_tracking(date DESC);

-- Function to check budget remaining
CREATE OR REPLACE FUNCTION public.check_budget(
    p_category VARCHAR,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE (
    spent DECIMAL,
    budget DECIMAL,
    remaining DECIMAL,
    percent_used DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE(SUM(bt.amount), 0)::DECIMAL as spent,
        COALESCE(MAX(bt.budget_limit), 5.00)::DECIMAL as budget,
        (COALESCE(MAX(bt.budget_limit), 5.00) - COALESCE(SUM(bt.amount), 0))::DECIMAL as remaining,
        (COALESCE(SUM(bt.amount), 0) / NULLIF(MAX(bt.budget_limit), 0) * 100)::DECIMAL(5,2) as percent_used
    FROM public.budget_tracking bt
    WHERE bt.date = p_date AND bt.category = p_category;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- ADDITIONAL RLS POLICIES
-- ============================================================
ALTER TABLE public.batch_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_activity_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gumroad_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.safeguard_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_tracking ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role full access" ON public.batch_jobs FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.platform_credentials FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.platform_activity_log FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.gumroad_products FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.safeguard_checks FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Service role full access" ON public.budget_tracking FOR ALL USING (auth.role() = 'service_role');

-- ============================================================
-- TRIGGERS FOR UPDATED_AT
-- ============================================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_trending_niches_updated_at
    BEFORE UPDATE ON public.trending_niches
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_generated_products_updated_at
    BEFORE UPDATE ON public.generated_products
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_product_templates_updated_at
    BEFORE UPDATE ON public.product_templates
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_platform_credentials_updated_at
    BEFORE UPDATE ON public.platform_credentials
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_gumroad_products_updated_at
    BEFORE UPDATE ON public.gumroad_products
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================================
-- GRANT PERMISSIONS
-- ============================================================
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO service_role;
