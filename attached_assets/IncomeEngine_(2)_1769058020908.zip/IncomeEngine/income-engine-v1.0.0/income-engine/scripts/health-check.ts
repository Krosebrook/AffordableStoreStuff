#!/usr/bin/env ts-node
/**
 * Health Check Script
 * Validates all system components and connections
 * 
 * Usage: npm run health
 */

import { config } from 'dotenv';
config();

import { createClient } from '@supabase/supabase-js';

interface HealthCheckResult {
  component: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  message: string;
  latencyMs?: number;
  details?: Record<string, any>;
}

interface SystemHealth {
  overall: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  checks: HealthCheckResult[];
  recommendations: string[];
}

async function checkSupabase(): Promise<HealthCheckResult> {
  const start = Date.now();
  
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
    return {
      component: 'Supabase',
      status: 'unhealthy',
      message: 'Missing SUPABASE_URL or SUPABASE_ANON_KEY environment variables',
    };
  }
  
  try {
    const supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_ANON_KEY
    );
    
    // Test connection with a simple query
    const { data, error } = await supabase
      .from('trending_niches')
      .select('count')
      .limit(1);
    
    const latency = Date.now() - start;
    
    if (error) {
      return {
        component: 'Supabase',
        status: 'degraded',
        message: `Connection works but query failed: ${error.message}`,
        latencyMs: latency,
      };
    }
    
    return {
      component: 'Supabase',
      status: 'healthy',
      message: 'Connected successfully',
      latencyMs: latency,
    };
  } catch (error) {
    return {
      component: 'Supabase',
      status: 'unhealthy',
      message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      latencyMs: Date.now() - start,
    };
  }
}

async function checkPrintify(): Promise<HealthCheckResult> {
  const start = Date.now();
  
  if (!process.env.PRINTIFY_API_KEY) {
    return {
      component: 'Printify',
      status: 'unhealthy',
      message: 'Missing PRINTIFY_API_KEY environment variable',
    };
  }
  
  try {
    const response = await fetch('https://api.printify.com/v1/shops.json', {
      headers: {
        'Authorization': `Bearer ${process.env.PRINTIFY_API_KEY}`,
      },
    });
    
    const latency = Date.now() - start;
    
    if (!response.ok) {
      return {
        component: 'Printify',
        status: 'unhealthy',
        message: `API returned ${response.status}: ${response.statusText}`,
        latencyMs: latency,
      };
    }
    
    const shops = await response.json();
    
    return {
      component: 'Printify',
      status: 'healthy',
      message: `Connected successfully. Found ${shops.length} shop(s)`,
      latencyMs: latency,
      details: { shopCount: shops.length },
    };
  } catch (error) {
    return {
      component: 'Printify',
      status: 'unhealthy',
      message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      latencyMs: Date.now() - start,
    };
  }
}

async function checkGumroad(): Promise<HealthCheckResult> {
  const start = Date.now();
  
  if (!process.env.GUMROAD_ACCESS_TOKEN) {
    return {
      component: 'Gumroad',
      status: 'unhealthy',
      message: 'Missing GUMROAD_ACCESS_TOKEN environment variable',
    };
  }
  
  try {
    const response = await fetch(
      `https://api.gumroad.com/v2/user?access_token=${process.env.GUMROAD_ACCESS_TOKEN}`
    );
    
    const latency = Date.now() - start;
    const data = await response.json();
    
    if (!data.success) {
      return {
        component: 'Gumroad',
        status: 'unhealthy',
        message: `API error: ${data.message || 'Unknown error'}`,
        latencyMs: latency,
      };
    }
    
    return {
      component: 'Gumroad',
      status: 'healthy',
      message: `Connected as ${data.user.email}`,
      latencyMs: latency,
      details: { email: data.user.email },
    };
  } catch (error) {
    return {
      component: 'Gumroad',
      status: 'unhealthy',
      message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      latencyMs: Date.now() - start,
    };
  }
}

async function checkReplicate(): Promise<HealthCheckResult> {
  const start = Date.now();
  
  if (!process.env.REPLICATE_API_TOKEN) {
    return {
      component: 'Replicate (AI Images)',
      status: 'unhealthy',
      message: 'Missing REPLICATE_API_TOKEN environment variable',
    };
  }
  
  try {
    const response = await fetch('https://api.replicate.com/v1/account', {
      headers: {
        'Authorization': `Token ${process.env.REPLICATE_API_TOKEN}`,
      },
    });
    
    const latency = Date.now() - start;
    
    if (!response.ok) {
      return {
        component: 'Replicate (AI Images)',
        status: 'unhealthy',
        message: `API returned ${response.status}`,
        latencyMs: latency,
      };
    }
    
    const data = await response.json();
    
    return {
      component: 'Replicate (AI Images)',
      status: 'healthy',
      message: `Connected as ${data.username}`,
      latencyMs: latency,
      details: { username: data.username },
    };
  } catch (error) {
    return {
      component: 'Replicate (AI Images)',
      status: 'unhealthy',
      message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      latencyMs: Date.now() - start,
    };
  }
}

async function checkOpenAI(): Promise<HealthCheckResult> {
  const start = Date.now();
  
  if (!process.env.OPENAI_API_KEY) {
    return {
      component: 'OpenAI (AI Text)',
      status: 'unhealthy',
      message: 'Missing OPENAI_API_KEY environment variable',
    };
  }
  
  try {
    const response = await fetch('https://api.openai.com/v1/models', {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      },
    });
    
    const latency = Date.now() - start;
    
    if (!response.ok) {
      return {
        component: 'OpenAI (AI Text)',
        status: 'unhealthy',
        message: `API returned ${response.status}`,
        latencyMs: latency,
      };
    }
    
    return {
      component: 'OpenAI (AI Text)',
      status: 'healthy',
      message: 'API key valid',
      latencyMs: latency,
    };
  } catch (error) {
    return {
      component: 'OpenAI (AI Text)',
      status: 'unhealthy',
      message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      latencyMs: Date.now() - start,
    };
  }
}

async function checkN8N(): Promise<HealthCheckResult> {
  const start = Date.now();
  
  if (!process.env.N8N_WEBHOOK_URL) {
    return {
      component: 'n8n',
      status: 'degraded',
      message: 'N8N_WEBHOOK_URL not configured (optional for local testing)',
    };
  }
  
  try {
    // Try to reach n8n health endpoint
    const url = new URL(process.env.N8N_WEBHOOK_URL);
    const healthUrl = `${url.protocol}//${url.host}/healthz`;
    
    const response = await fetch(healthUrl, { 
      method: 'GET',
      signal: AbortSignal.timeout(5000),
    });
    
    const latency = Date.now() - start;
    
    if (response.ok) {
      return {
        component: 'n8n',
        status: 'healthy',
        message: 'n8n instance is running',
        latencyMs: latency,
      };
    }
    
    return {
      component: 'n8n',
      status: 'degraded',
      message: `Health check returned ${response.status}`,
      latencyMs: latency,
    };
  } catch (error) {
    return {
      component: 'n8n',
      status: 'degraded',
      message: `Could not reach n8n: ${error instanceof Error ? error.message : 'Unknown error'}`,
      latencyMs: Date.now() - start,
    };
  }
}

async function checkBudget(): Promise<HealthCheckResult> {
  const dailyLimit = parseFloat(process.env.MAX_DAILY_AI_SPEND || '5');
  const monthlyLimit = parseFloat(process.env.MAX_MONTHLY_SPEND || '100');
  
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
    return {
      component: 'Budget Tracking',
      status: 'degraded',
      message: 'Cannot check budget without Supabase connection',
    };
  }
  
  try {
    const supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_ANON_KEY
    );
    
    // Get today's AI costs
    const today = new Date().toISOString().split('T')[0];
    const { data: todayCosts } = await supabase
      .from('ai_generation_costs')
      .select('cost_usd')
      .gte('created_at', `${today}T00:00:00Z`);
    
    const todaySpent = todayCosts?.reduce((sum, c) => sum + (c.cost_usd || 0), 0) || 0;
    const percentUsed = (todaySpent / dailyLimit) * 100;
    
    if (percentUsed >= 90) {
      return {
        component: 'Budget Tracking',
        status: 'degraded',
        message: `Daily budget ${percentUsed.toFixed(1)}% used ($${todaySpent.toFixed(2)}/$${dailyLimit})`,
        details: { todaySpent, dailyLimit, percentUsed },
      };
    }
    
    return {
      component: 'Budget Tracking',
      status: 'healthy',
      message: `Daily budget ${percentUsed.toFixed(1)}% used ($${todaySpent.toFixed(2)}/$${dailyLimit})`,
      details: { todaySpent, dailyLimit, percentUsed },
    };
  } catch (error) {
    return {
      component: 'Budget Tracking',
      status: 'degraded',
      message: `Could not check budget: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

function generateRecommendations(checks: HealthCheckResult[]): string[] {
  const recommendations: string[] = [];
  
  const unhealthyComponents = checks.filter(c => c.status === 'unhealthy');
  const degradedComponents = checks.filter(c => c.status === 'degraded');
  
  for (const check of unhealthyComponents) {
    switch (check.component) {
      case 'Supabase':
        recommendations.push('🔴 CRITICAL: Configure Supabase credentials in .env file');
        break;
      case 'Printify':
        recommendations.push('🔴 CRITICAL: Add PRINTIFY_API_KEY to enable POD products');
        break;
      case 'Gumroad':
        recommendations.push('🟡 Add GUMROAD_ACCESS_TOKEN for digital product sales');
        break;
      case 'Replicate (AI Images)':
        recommendations.push('🔴 CRITICAL: Add REPLICATE_API_TOKEN for image generation');
        break;
      case 'OpenAI (AI Text)':
        recommendations.push('🔴 CRITICAL: Add OPENAI_API_KEY for SEO copy generation');
        break;
    }
  }
  
  for (const check of degradedComponents) {
    if (check.component === 'n8n') {
      recommendations.push('🟡 Configure N8N_WEBHOOK_URL for workflow automation');
    }
    if (check.component === 'Budget Tracking' && check.details?.percentUsed >= 90) {
      recommendations.push('⚠️ Daily budget nearly exhausted - reduce generation or increase limit');
    }
  }
  
  if (recommendations.length === 0) {
    recommendations.push('✅ All systems operational - ready for production');
  }
  
  return recommendations;
}

async function runHealthCheck(): Promise<SystemHealth> {
  console.log('🏥 Running Income Engine Health Check...\n');
  
  const checks = await Promise.all([
    checkSupabase(),
    checkPrintify(),
    checkGumroad(),
    checkReplicate(),
    checkOpenAI(),
    checkN8N(),
    checkBudget(),
  ]);
  
  const unhealthyCount = checks.filter(c => c.status === 'unhealthy').length;
  const degradedCount = checks.filter(c => c.status === 'degraded').length;
  
  let overall: 'healthy' | 'degraded' | 'unhealthy';
  if (unhealthyCount > 0) {
    overall = 'unhealthy';
  } else if (degradedCount > 0) {
    overall = 'degraded';
  } else {
    overall = 'healthy';
  }
  
  const recommendations = generateRecommendations(checks);
  
  return {
    overall,
    timestamp: new Date().toISOString(),
    checks,
    recommendations,
  };
}

function printResults(health: SystemHealth): void {
  const statusEmoji = {
    healthy: '✅',
    degraded: '⚠️',
    unhealthy: '❌',
  };
  
  console.log('═══════════════════════════════════════════════════════');
  console.log(`  INCOME ENGINE HEALTH CHECK`);
  console.log(`  ${health.timestamp}`);
  console.log('═══════════════════════════════════════════════════════\n');
  
  console.log(`Overall Status: ${statusEmoji[health.overall]} ${health.overall.toUpperCase()}\n`);
  
  console.log('Component Status:');
  console.log('─────────────────────────────────────────────────────────');
  
  for (const check of health.checks) {
    const emoji = statusEmoji[check.status];
    const latency = check.latencyMs ? ` (${check.latencyMs}ms)` : '';
    console.log(`${emoji} ${check.component.padEnd(25)} ${check.message}${latency}`);
  }
  
  console.log('\n─────────────────────────────────────────────────────────');
  console.log('Recommendations:');
  for (const rec of health.recommendations) {
    console.log(`  ${rec}`);
  }
  
  console.log('\n═══════════════════════════════════════════════════════\n');
}

// Main execution
runHealthCheck()
  .then(health => {
    printResults(health);
    process.exit(health.overall === 'healthy' ? 0 : 1);
  })
  .catch(error => {
    console.error('Health check failed:', error);
    process.exit(1);
  });
