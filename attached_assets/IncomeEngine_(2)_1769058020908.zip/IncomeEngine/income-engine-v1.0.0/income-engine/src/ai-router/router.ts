/**
 * AI Router - Multi-Model Cost Optimizer
 * 
 * Routes AI requests to the most cost-effective provider based on:
 * - Task complexity
 * - Quality requirements
 * - Current budget status
 * - Provider availability
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// ============================================================
// PROVIDER CONFIGURATIONS
// ============================================================

interface ProviderConfig {
  name: string;
  type: 'image' | 'text';
  model: string;
  endpoint: string;
  costPer1K?: number;      // For text models (per 1K tokens)
  costPerImage?: number;   // For image models
  qualityScore: number;    // 1-100
  speedScore: number;      // 1-100 (higher = faster)
  maxTokens?: number;
  maxImages?: number;
}

const TEXT_PROVIDERS: ProviderConfig[] = [
  {
    name: 'openai-gpt4o-mini',
    type: 'text',
    model: 'gpt-4o-mini',
    endpoint: 'https://api.openai.com/v1/chat/completions',
    costPer1K: 0.00015,  // $0.15 per 1M input
    qualityScore: 85,
    speedScore: 90,
    maxTokens: 128000
  },
  {
    name: 'openai-gpt4o',
    type: 'text',
    model: 'gpt-4o',
    endpoint: 'https://api.openai.com/v1/chat/completions',
    costPer1K: 0.005,    // $5 per 1M input
    qualityScore: 95,
    speedScore: 80,
    maxTokens: 128000
  },
  {
    name: 'anthropic-haiku',
    type: 'text',
    model: 'claude-3-haiku-20240307',
    endpoint: 'https://api.anthropic.com/v1/messages',
    costPer1K: 0.00025,  // $0.25 per 1M input
    qualityScore: 80,
    speedScore: 95,
    maxTokens: 200000
  },
  {
    name: 'anthropic-sonnet',
    type: 'text',
    model: 'claude-sonnet-4-20250514',
    endpoint: 'https://api.anthropic.com/v1/messages',
    costPer1K: 0.003,    // $3 per 1M input
    qualityScore: 92,
    speedScore: 85,
    maxTokens: 200000
  }
];

const IMAGE_PROVIDERS: ProviderConfig[] = [
  {
    name: 'replicate-flux-schnell',
    type: 'image',
    model: 'black-forest-labs/flux-schnell',
    endpoint: 'https://api.replicate.com/v1/predictions',
    costPerImage: 0.003,   // $0.003 per image
    qualityScore: 85,
    speedScore: 95,
    maxImages: 4
  },
  {
    name: 'replicate-flux-dev',
    type: 'image',
    model: 'black-forest-labs/flux-dev',
    endpoint: 'https://api.replicate.com/v1/predictions',
    costPerImage: 0.025,   // $0.025 per image
    qualityScore: 95,
    speedScore: 70,
    maxImages: 4
  },
  {
    name: 'openai-dalle3',
    type: 'image',
    model: 'dall-e-3',
    endpoint: 'https://api.openai.com/v1/images/generations',
    costPerImage: 0.04,    // $0.04 per image (1024x1024)
    qualityScore: 90,
    speedScore: 75,
    maxImages: 1
  },
  {
    name: 'huggingface-flux',
    type: 'image',
    model: 'black-forest-labs/FLUX.1-schnell',
    endpoint: 'https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-schnell',
    costPerImage: 0,       // Free tier (rate limited)
    qualityScore: 80,
    speedScore: 50,        // Queue-based, variable
    maxImages: 1
  }
];

// ============================================================
// TASK COMPLEXITY DEFINITIONS
// ============================================================

type TaskComplexity = 'simple' | 'medium' | 'complex';

interface TaskConfig {
  complexity: TaskComplexity;
  minQuality: number;
  maxCost: number;
  description: string;
}

const TASK_CONFIGS: Record<string, TaskConfig> = {
  // Text tasks
  'product_title': { complexity: 'simple', minQuality: 70, maxCost: 0.001, description: 'Generate product title' },
  'product_description': { complexity: 'medium', minQuality: 80, maxCost: 0.005, description: 'Generate product description' },
  'seo_tags': { complexity: 'simple', minQuality: 70, maxCost: 0.001, description: 'Generate SEO tags' },
  'image_prompt': { complexity: 'medium', minQuality: 85, maxCost: 0.003, description: 'Generate image prompt' },
  'niche_analysis': { complexity: 'complex', minQuality: 90, maxCost: 0.01, description: 'Analyze niche potential' },
  
  // Image tasks
  'product_image': { complexity: 'medium', minQuality: 85, maxCost: 0.01, description: 'Generate product image' },
  'mockup_image': { complexity: 'simple', minQuality: 75, maxCost: 0.005, description: 'Generate mockup' },
  'premium_image': { complexity: 'complex', minQuality: 95, maxCost: 0.05, description: 'Generate premium quality image' }
};

// ============================================================
// AI ROUTER CLASS
// ============================================================

export class AIRouter {
  private supabase: SupabaseClient;
  private dailyBudget: number;
  private dailySpent: number = 0;
  private lastBudgetCheck: Date = new Date(0);
  
  constructor(supabaseUrl: string, supabaseKey: string, dailyBudget: number = 5) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.dailyBudget = dailyBudget;
  }
  
  /**
   * Route a request to the optimal provider
   */
  async route(
    task: string,
    type: 'text' | 'image',
    options: {
      forceProvider?: string;
      forceQuality?: 'low' | 'medium' | 'high';
      budgetOverride?: number;
    } = {}
  ): Promise<{ provider: ProviderConfig; estimatedCost: number; reason: string }> {
    
    // Get task configuration
    const taskConfig = TASK_CONFIGS[task] || {
      complexity: 'medium' as TaskComplexity,
      minQuality: 80,
      maxCost: 0.01,
      description: task
    };
    
    // Apply quality override
    if (options.forceQuality) {
      taskConfig.minQuality = options.forceQuality === 'low' ? 70 :
                              options.forceQuality === 'high' ? 95 : 85;
    }
    
    // Check budget
    await this.refreshBudgetStatus();
    const remainingBudget = this.dailyBudget - this.dailySpent;
    const maxCost = Math.min(taskConfig.maxCost, options.budgetOverride || remainingBudget * 0.1);
    
    // Get available providers
    const providers = type === 'text' ? TEXT_PROVIDERS : IMAGE_PROVIDERS;
    
    // Force specific provider if requested
    if (options.forceProvider) {
      const forced = providers.find(p => p.name === options.forceProvider);
      if (forced) {
        return {
          provider: forced,
          estimatedCost: type === 'text' ? (forced.costPer1K || 0) * 0.5 : (forced.costPerImage || 0),
          reason: `Forced provider: ${options.forceProvider}`
        };
      }
    }
    
    // Score and rank providers
    const scored = providers
      .filter(p => {
        const cost = type === 'text' ? (p.costPer1K || 0) * 0.5 : (p.costPerImage || 0);
        return p.qualityScore >= taskConfig.minQuality && cost <= maxCost;
      })
      .map(p => {
        const cost = type === 'text' ? (p.costPer1K || 0) * 0.5 : (p.costPerImage || 0);
        
        // Calculate composite score
        // Weight: 40% cost efficiency, 30% quality, 30% speed
        const costScore = maxCost > 0 ? (1 - cost / maxCost) * 100 : 100;
        const compositeScore = (costScore * 0.4) + (p.qualityScore * 0.3) + (p.speedScore * 0.3);
        
        return { provider: p, cost, compositeScore };
      })
      .sort((a, b) => b.compositeScore - a.compositeScore);
    
    if (scored.length === 0) {
      // Fallback to cheapest provider
      const cheapest = [...providers].sort((a, b) => {
        const costA = type === 'text' ? (a.costPer1K || 0) : (a.costPerImage || 0);
        const costB = type === 'text' ? (b.costPer1K || 0) : (b.costPerImage || 0);
        return costA - costB;
      })[0];
      
      return {
        provider: cheapest,
        estimatedCost: type === 'text' ? (cheapest.costPer1K || 0) * 0.5 : (cheapest.costPerImage || 0),
        reason: `Fallback to cheapest: no provider met criteria (minQuality: ${taskConfig.minQuality}, maxCost: ${maxCost})`
      };
    }
    
    const best = scored[0];
    
    return {
      provider: best.provider,
      estimatedCost: best.cost,
      reason: `Optimal for ${task}: quality ${best.provider.qualityScore}, cost $${best.cost.toFixed(4)}`
    };
  }
  
  /**
   * Log cost to database
   */
  async logCost(
    provider: string,
    model: string,
    operation: string,
    cost: number,
    metadata: { inputTokens?: number; outputTokens?: number; imagesGenerated?: number; productId?: string }
  ): Promise<void> {
    await this.supabase.from('ai_generation_costs').insert({
      provider,
      model,
      operation,
      cost_usd: cost,
      input_tokens: metadata.inputTokens || 0,
      output_tokens: metadata.outputTokens || 0,
      images_generated: metadata.imagesGenerated || 0,
      product_id: metadata.productId
    });
    
    this.dailySpent += cost;
  }
  
  /**
   * Get budget status
   */
  async getBudgetStatus(): Promise<{
    dailyBudget: number;
    dailySpent: number;
    remaining: number;
    percentUsed: number;
    isWarning: boolean;
    isExceeded: boolean;
  }> {
    await this.refreshBudgetStatus();
    
    const remaining = this.dailyBudget - this.dailySpent;
    const percentUsed = (this.dailySpent / this.dailyBudget) * 100;
    
    return {
      dailyBudget: this.dailyBudget,
      dailySpent: this.dailySpent,
      remaining,
      percentUsed,
      isWarning: percentUsed >= 80,
      isExceeded: percentUsed >= 100
    };
  }
  
  /**
   * Refresh budget from database
   */
  private async refreshBudgetStatus(): Promise<void> {
    const now = new Date();
    
    // Only refresh every 5 minutes
    if (now.getTime() - this.lastBudgetCheck.getTime() < 5 * 60 * 1000) {
      return;
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const { data, error } = await this.supabase
      .from('ai_generation_costs')
      .select('cost_usd')
      .gte('created_at', today.toISOString());
    
    if (!error && data) {
      this.dailySpent = data.reduce((sum, row) => sum + (row.cost_usd || 0), 0);
    }
    
    this.lastBudgetCheck = now;
  }
  
  /**
   * Get cost estimate for a batch
   */
  estimateBatchCost(
    batchSize: number,
    tasks: { task: string; type: 'text' | 'image' }[]
  ): number {
    let total = 0;
    
    for (const { task, type } of tasks) {
      const taskConfig = TASK_CONFIGS[task] || { maxCost: 0.01 };
      total += taskConfig.maxCost * batchSize;
    }
    
    return total;
  }
  
  /**
   * Get recommended batch size based on budget
   */
  async getRecommendedBatchSize(
    tasks: { task: string; type: 'text' | 'image' }[]
  ): Promise<number> {
    const status = await this.getBudgetStatus();
    const costPerProduct = this.estimateBatchCost(1, tasks);
    
    if (costPerProduct === 0) return 50; // Max batch
    
    const maxAffordable = Math.floor(status.remaining / costPerProduct);
    
    // Leave 20% buffer
    const recommended = Math.floor(maxAffordable * 0.8);
    
    // Clamp between 1 and 50
    return Math.max(1, Math.min(50, recommended));
  }
}

// ============================================================
// PROVIDER IMPLEMENTATIONS
// ============================================================

export async function callTextProvider(
  provider: ProviderConfig,
  prompt: string,
  systemPrompt?: string,
  options: { temperature?: number; maxTokens?: number } = {}
): Promise<{ content: string; usage: { inputTokens: number; outputTokens: number } }> {
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  
  let body: any;
  let response: Response;
  
  if (provider.name.startsWith('openai')) {
    headers['Authorization'] = `Bearer ${process.env.OPENAI_API_KEY}`;
    body = {
      model: provider.model,
      messages: [
        ...(systemPrompt ? [{ role: 'system', content: systemPrompt }] : []),
        { role: 'user', content: prompt }
      ],
      temperature: options.temperature || 0.7,
      max_tokens: options.maxTokens || 1000
    };
  } else if (provider.name.startsWith('anthropic')) {
    headers['x-api-key'] = process.env.ANTHROPIC_API_KEY || '';
    headers['anthropic-version'] = '2023-06-01';
    body = {
      model: provider.model,
      max_tokens: options.maxTokens || 1000,
      system: systemPrompt || '',
      messages: [{ role: 'user', content: prompt }]
    };
  }
  
  response = await fetch(provider.endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body)
  });
  
  const data = await response.json();
  
  // Parse response based on provider
  if (provider.name.startsWith('openai')) {
    return {
      content: data.choices?.[0]?.message?.content || '',
      usage: {
        inputTokens: data.usage?.prompt_tokens || 0,
        outputTokens: data.usage?.completion_tokens || 0
      }
    };
  } else if (provider.name.startsWith('anthropic')) {
    return {
      content: data.content?.[0]?.text || '',
      usage: {
        inputTokens: data.usage?.input_tokens || 0,
        outputTokens: data.usage?.output_tokens || 0
      }
    };
  }
  
  throw new Error(`Unknown provider: ${provider.name}`);
}

export async function callImageProvider(
  provider: ProviderConfig,
  prompt: string,
  options: { size?: string; quality?: string } = {}
): Promise<{ imageUrl: string; cost: number }> {
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  
  let body: any;
  
  if (provider.name.startsWith('replicate')) {
    headers['Authorization'] = `Token ${process.env.REPLICATE_API_TOKEN}`;
    body = {
      version: provider.model.includes('schnell') ? 'schnell' : 'dev',
      input: {
        prompt,
        num_outputs: 1,
        aspect_ratio: '1:1',
        output_format: 'png'
      }
    };
    
    const response = await fetch(provider.endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });
    
    const prediction = await response.json();
    
    // Poll for result
    let result = prediction;
    while (result.status !== 'succeeded' && result.status !== 'failed') {
      await new Promise(resolve => setTimeout(resolve, 2000));
      const pollResponse = await fetch(prediction.urls.get, { headers });
      result = await pollResponse.json();
    }
    
    if (result.status === 'failed') {
      throw new Error(`Image generation failed: ${result.error}`);
    }
    
    return {
      imageUrl: result.output?.[0] || result.output,
      cost: provider.costPerImage || 0
    };
    
  } else if (provider.name === 'openai-dalle3') {
    headers['Authorization'] = `Bearer ${process.env.OPENAI_API_KEY}`;
    body = {
      model: 'dall-e-3',
      prompt,
      n: 1,
      size: options.size || '1024x1024',
      quality: options.quality || 'standard'
    };
    
    const response = await fetch(provider.endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });
    
    const data = await response.json();
    
    return {
      imageUrl: data.data?.[0]?.url || '',
      cost: provider.costPerImage || 0.04
    };
    
  } else if (provider.name === 'huggingface-flux') {
    headers['Authorization'] = `Bearer ${process.env.HUGGINGFACE_API_KEY}`;
    
    const response = await fetch(provider.endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify({ inputs: prompt })
    });
    
    // HuggingFace returns binary image data
    const blob = await response.blob();
    // In a real implementation, you'd upload this to storage and get a URL
    
    return {
      imageUrl: URL.createObjectURL(blob),
      cost: 0 // Free tier
    };
  }
  
  throw new Error(`Unknown image provider: ${provider.name}`);
}

// ============================================================
// EXPORTS
// ============================================================

export { TEXT_PROVIDERS, IMAGE_PROVIDERS, TASK_CONFIGS };
export type { ProviderConfig, TaskConfig, TaskComplexity };
