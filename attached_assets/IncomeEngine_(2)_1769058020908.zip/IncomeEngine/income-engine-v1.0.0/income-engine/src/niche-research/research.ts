/**
 * Niche Research Module
 * Automated niche discovery and trend analysis
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Types
export interface NicheData {
  name: string;
  category: string;
  demandScore: number;
  competitionLevel: 'low' | 'medium' | 'high';
  seasonalBoost: number;
  finalScore: number;
  recommendedProducts: string[];
  subNiches: string[];
  keywords: string[];
  trendDirection: 'rising' | 'stable' | 'declining';
}

export interface NicheAnalysis {
  niche: string;
  viability: 'excellent' | 'good' | 'moderate' | 'poor';
  score: number;
  factors: {
    demand: number;
    competition: number;
    seasonality: number;
    profitPotential: number;
  };
  recommendations: string[];
  bestProducts: string[];
  estimatedMonthlySales: { low: number; mid: number; high: number };
}

// Comprehensive niche database
const NICHE_DATABASE: Record<string, Omit<NicheData, 'finalScore'>> = {
  'dog-breed-specific': {
    name: 'dog-breed-specific',
    category: 'pets',
    demandScore: 90,
    competitionLevel: 'medium',
    seasonalBoost: 1.0,
    recommendedProducts: ['pod_mug', 'pod_tshirt', 'pod_tote', 'pod_poster'],
    subNiches: [
      'golden-retriever', 'labrador', 'german-shepherd', 'bulldog', 
      'poodle', 'beagle', 'husky', 'corgi', 'dachshund', 'boxer',
      'rottweiler', 'yorkie', 'shih-tzu', 'chihuahua', 'pitbull'
    ],
    keywords: ['dog mom', 'dog dad', 'fur baby', 'puppy love', 'breed lover'],
    trendDirection: 'stable',
  },
  'cat-lovers': {
    name: 'cat-lovers',
    category: 'pets',
    demandScore: 85,
    competitionLevel: 'medium',
    seasonalBoost: 1.0,
    recommendedProducts: ['pod_mug', 'pod_tshirt', 'pod_poster', 'pod_pillow'],
    subNiches: [
      'black-cat', 'tabby', 'persian', 'siamese', 'maine-coon',
      'ragdoll', 'bengal', 'sphynx', 'calico', 'orange-cat'
    ],
    keywords: ['cat mom', 'cat dad', 'crazy cat lady', 'meow', 'feline'],
    trendDirection: 'stable',
  },
  'teacher-appreciation': {
    name: 'teacher-appreciation',
    category: 'occupation',
    demandScore: 80,
    competitionLevel: 'medium',
    seasonalBoost: 1.0, // Boosted in May, August-September
    recommendedProducts: ['pod_tote', 'pod_mug', 'pod_tshirt', 'digital_printable'],
    subNiches: [
      'elementary-teacher', 'high-school-teacher', 'math-teacher',
      'art-teacher', 'pe-teacher', 'music-teacher', 'substitute-teacher',
      'special-ed-teacher', 'preschool-teacher', 'science-teacher'
    ],
    keywords: ['teach', 'educator', 'classroom', 'school', 'inspire'],
    trendDirection: 'stable',
  },
  'nurse-healthcare': {
    name: 'nurse-healthcare',
    category: 'occupation',
    demandScore: 78,
    competitionLevel: 'low',
    seasonalBoost: 1.0, // Boosted during Nurses Week (May)
    recommendedProducts: ['pod_tshirt', 'pod_mug', 'pod_tote', 'pod_sticker'],
    subNiches: [
      'rn', 'lpn', 'er-nurse', 'nicu-nurse', 'icu-nurse', 
      'nurse-practitioner', 'pediatric-nurse', 'surgical-nurse',
      'oncology-nurse', 'labor-delivery-nurse'
    ],
    keywords: ['scrubs', 'stethoscope', 'hero', 'healthcare', 'save lives'],
    trendDirection: 'stable',
  },
  'gaming-retro': {
    name: 'gaming-retro',
    category: 'hobby',
    demandScore: 88,
    competitionLevel: 'high',
    seasonalBoost: 1.0,
    recommendedProducts: ['pod_poster', 'pod_tshirt', 'pod_mousepad', 'pod_hoodie'],
    subNiches: [
      '8-bit', 'pixel-art', 'arcade', 'console-gaming', 'pc-gaming',
      'speedrunning', 'esports', 'retro-games', 'indie-games'
    ],
    keywords: ['level up', 'game on', 'player', 'respawn', 'achievement'],
    trendDirection: 'rising',
  },
  'plant-parent': {
    name: 'plant-parent',
    category: 'lifestyle',
    demandScore: 75,
    competitionLevel: 'low',
    seasonalBoost: 1.2, // Spring boost
    recommendedProducts: ['pod_mug', 'pod_tote', 'pod_poster', 'pod_sticker'],
    subNiches: [
      'succulent', 'monstera', 'pothos', 'fiddle-leaf', 'cactus',
      'house-plants', 'garden', 'botanical', 'terrarium'
    ],
    keywords: ['plant mama', 'green thumb', 'grow', 'botanical', 'jungle'],
    trendDirection: 'rising',
  },
  'astrology-zodiac': {
    name: 'astrology-zodiac',
    category: 'spiritual',
    demandScore: 82,
    competitionLevel: 'medium',
    seasonalBoost: 1.0,
    recommendedProducts: ['pod_poster', 'pod_mug', 'digital_printable', 'pod_tshirt'],
    subNiches: [
      'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
      'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'
    ],
    keywords: ['zodiac', 'horoscope', 'stars', 'cosmic', 'birth chart'],
    trendDirection: 'stable',
  },
  'mom-life-humor': {
    name: 'mom-life-humor',
    category: 'parenting',
    demandScore: 85,
    competitionLevel: 'medium',
    seasonalBoost: 1.0, // Mother's Day boost
    recommendedProducts: ['pod_mug', 'pod_tshirt', 'pod_tote', 'pod_tumbler'],
    subNiches: [
      'new-mom', 'boy-mom', 'girl-mom', 'twin-mom', 'toddler-mom',
      'wine-mom', 'coffee-mom', 'sports-mom', 'homeschool-mom'
    ],
    keywords: ['mom life', 'motherhood', 'mama', 'tired mom', 'blessed'],
    trendDirection: 'stable',
  },
  'dad-jokes': {
    name: 'dad-jokes',
    category: 'parenting',
    demandScore: 75,
    competitionLevel: 'medium',
    seasonalBoost: 1.0, // Father's Day boost
    recommendedProducts: ['pod_tshirt', 'pod_mug', 'pod_poster'],
    subNiches: [
      'new-dad', 'grill-dad', 'golf-dad', 'fishing-dad', 'sports-dad',
      'tech-dad', 'cool-dad', 'grandpa'
    ],
    keywords: ['dad bod', 'fatherhood', 'papa', 'daddy', 'legend'],
    trendDirection: 'stable',
  },
  'minimalist-quotes': {
    name: 'minimalist-quotes',
    category: 'decor',
    demandScore: 70,
    competitionLevel: 'high',
    seasonalBoost: 1.0,
    recommendedProducts: ['pod_poster', 'digital_printable', 'pod_mug', 'pod_canvas'],
    subNiches: [
      'motivational', 'inspirational', 'self-care', 'mindfulness',
      'gratitude', 'positivity', 'affirmations', 'typography'
    ],
    keywords: ['breathe', 'be kind', 'good vibes', 'grateful', 'positive'],
    trendDirection: 'stable',
  },
  'eco-activism': {
    name: 'eco-activism',
    category: 'values',
    demandScore: 72,
    competitionLevel: 'low',
    seasonalBoost: 1.1, // Earth Day boost
    recommendedProducts: ['pod_tote', 'pod_sticker', 'pod_tshirt'],
    subNiches: [
      'save-the-planet', 'zero-waste', 'climate-action', 'ocean-cleanup',
      'sustainable', 'recycle', 'vegan', 'plant-based'
    ],
    keywords: ['earth', 'green', 'eco', 'sustainable', 'future'],
    trendDirection: 'rising',
  },
  'coffee-lover': {
    name: 'coffee-lover',
    category: 'lifestyle',
    demandScore: 80,
    competitionLevel: 'high',
    seasonalBoost: 1.0,
    recommendedProducts: ['pod_mug', 'pod_tshirt', 'pod_tote'],
    subNiches: [
      'espresso', 'latte', 'cold-brew', 'barista', 'caffeine-addict',
      'morning-coffee', 'iced-coffee'
    ],
    keywords: ['caffeine', 'brew', 'espresso', 'latte', 'morning'],
    trendDirection: 'stable',
  },
  'fitness-motivation': {
    name: 'fitness-motivation',
    category: 'health',
    demandScore: 76,
    competitionLevel: 'high',
    seasonalBoost: 1.3, // January boost
    recommendedProducts: ['pod_tshirt', 'pod_poster', 'digital_planner'],
    subNiches: [
      'gym-rat', 'weightlifting', 'running', 'yoga', 'crossfit',
      'bodybuilding', 'marathon', 'hiit'
    ],
    keywords: ['gains', 'beast mode', 'no excuses', 'stronger', 'grind'],
    trendDirection: 'stable',
  },
  'book-lover': {
    name: 'book-lover',
    category: 'hobby',
    demandScore: 74,
    competitionLevel: 'medium',
    seasonalBoost: 1.0,
    recommendedProducts: ['pod_tote', 'pod_mug', 'pod_tshirt', 'pod_sticker'],
    subNiches: [
      'romance-reader', 'fantasy-reader', 'thriller-reader', 'bookworm',
      'library', 'literary', 'bibliophile'
    ],
    keywords: ['read', 'books', 'library', 'chapter', 'page-turner'],
    trendDirection: 'stable',
  },
  'travel-wanderlust': {
    name: 'travel-wanderlust',
    category: 'lifestyle',
    demandScore: 73,
    competitionLevel: 'medium',
    seasonalBoost: 1.2, // Summer boost
    recommendedProducts: ['pod_tshirt', 'pod_tote', 'digital_planner', 'pod_poster'],
    subNiches: [
      'adventure', 'road-trip', 'camping', 'hiking', 'beach',
      'mountain', 'explore', 'passport'
    ],
    keywords: ['wanderlust', 'explore', 'adventure', 'travel', 'destination'],
    trendDirection: 'rising',
  },
};

// Seasonal multipliers by month
const SEASONAL_MULTIPLIERS: Record<string, Record<number, number>> = {
  'teacher-appreciation': { 5: 1.5, 8: 1.3, 9: 1.3 }, // May, Aug, Sept
  'nurse-healthcare': { 5: 1.5 }, // Nurses Week in May
  'mom-life-humor': { 5: 2.0 }, // Mother's Day
  'dad-jokes': { 6: 2.0 }, // Father's Day
  'eco-activism': { 4: 1.5 }, // Earth Day
  'fitness-motivation': { 1: 1.5 }, // New Year
  'travel-wanderlust': { 6: 1.3, 7: 1.3, 8: 1.3 }, // Summer
  'plant-parent': { 3: 1.3, 4: 1.3, 5: 1.3 }, // Spring
};

export class NicheResearch {
  private supabase: SupabaseClient;
  
  constructor(config: { supabaseUrl: string; supabaseKey: string }) {
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
  }
  
  /**
   * Get all available niches with current scoring
   */
  getAllNiches(): NicheData[] {
    const currentMonth = new Date().getMonth() + 1;
    
    return Object.values(NICHE_DATABASE).map(niche => {
      // Apply seasonal boost
      const seasonalMultiplier = SEASONAL_MULTIPLIERS[niche.name]?.[currentMonth] || niche.seasonalBoost;
      
      // Calculate final score
      const competitionMultiplier = 
        niche.competitionLevel === 'low' ? 1.2 :
        niche.competitionLevel === 'high' ? 0.8 : 1.0;
      
      const trendMultiplier =
        niche.trendDirection === 'rising' ? 1.1 :
        niche.trendDirection === 'declining' ? 0.9 : 1.0;
      
      const finalScore = Math.round(
        niche.demandScore * seasonalMultiplier * competitionMultiplier * trendMultiplier
      );
      
      return {
        ...niche,
        seasonalBoost: seasonalMultiplier,
        finalScore: Math.min(100, finalScore),
      };
    }).sort((a, b) => b.finalScore - a.finalScore);
  }
  
  /**
   * Get top N niches by score
   */
  getTopNiches(count: number = 10): NicheData[] {
    return this.getAllNiches().slice(0, count);
  }
  
  /**
   * Analyze a specific niche
   */
  analyzeNiche(nicheName: string): NicheAnalysis | null {
    const niche = NICHE_DATABASE[nicheName];
    if (!niche) return null;
    
    const currentMonth = new Date().getMonth() + 1;
    const seasonalMultiplier = SEASONAL_MULTIPLIERS[nicheName]?.[currentMonth] || niche.seasonalBoost;
    
    // Calculate factor scores
    const demandFactor = niche.demandScore;
    const competitionFactor = 
      niche.competitionLevel === 'low' ? 90 :
      niche.competitionLevel === 'high' ? 50 : 70;
    const seasonalityFactor = Math.round(seasonalMultiplier * 75);
    const profitFactor = 
      niche.competitionLevel === 'low' ? 85 :
      niche.competitionLevel === 'high' ? 60 : 72;
    
    const overallScore = Math.round(
      (demandFactor * 0.3 + competitionFactor * 0.25 + seasonalityFactor * 0.2 + profitFactor * 0.25)
    );
    
    // Determine viability
    let viability: 'excellent' | 'good' | 'moderate' | 'poor';
    if (overallScore >= 80) viability = 'excellent';
    else if (overallScore >= 65) viability = 'good';
    else if (overallScore >= 50) viability = 'moderate';
    else viability = 'poor';
    
    // Generate recommendations
    const recommendations: string[] = [];
    if (niche.competitionLevel === 'high') {
      recommendations.push('Focus on unique sub-niches to stand out');
      recommendations.push('Invest in high-quality, distinctive designs');
    }
    if (niche.competitionLevel === 'low') {
      recommendations.push('Great opportunity for market entry');
      recommendations.push('Consider scaling quickly while competition is low');
    }
    if (seasonalMultiplier > 1) {
      recommendations.push(`Current seasonal boost active (${Math.round((seasonalMultiplier - 1) * 100)}% increase)`);
    }
    if (niche.trendDirection === 'rising') {
      recommendations.push('Trending upward - prioritize this niche');
    }
    
    // Estimate monthly sales (rough projections)
    const baseSales = niche.demandScore * 0.5;
    const estimatedMonthlySales = {
      low: Math.round(baseSales * 0.5),
      mid: Math.round(baseSales),
      high: Math.round(baseSales * 2),
    };
    
    return {
      niche: nicheName,
      viability,
      score: overallScore,
      factors: {
        demand: demandFactor,
        competition: competitionFactor,
        seasonality: seasonalityFactor,
        profitPotential: profitFactor,
      },
      recommendations,
      bestProducts: niche.recommendedProducts.slice(0, 3),
      estimatedMonthlySales,
    };
  }
  
  /**
   * Get sub-niches for a niche
   */
  getSubNiches(nicheName: string): string[] {
    return NICHE_DATABASE[nicheName]?.subNiches || [];
  }
  
  /**
   * Get keywords for a niche
   */
  getKeywords(nicheName: string): string[] {
    return NICHE_DATABASE[nicheName]?.keywords || [];
  }
  
  /**
   * Find niches by category
   */
  getNichesByCategory(category: string): NicheData[] {
    return this.getAllNiches().filter(n => n.category === category);
  }
  
  /**
   * Get niches with low competition
   */
  getLowCompetitionNiches(): NicheData[] {
    return this.getAllNiches().filter(n => n.competitionLevel === 'low');
  }
  
  /**
   * Get currently boosted niches (seasonal)
   */
  getSeasonallyBoostedNiches(): NicheData[] {
    return this.getAllNiches().filter(n => n.seasonalBoost > 1);
  }
  
  /**
   * Get rising trend niches
   */
  getRisingNiches(): NicheData[] {
    return this.getAllNiches().filter(n => n.trendDirection === 'rising');
  }
  
  /**
   * Sync niches to database
   */
  async syncToDatabase(): Promise<{ synced: number; errors: string[] }> {
    const niches = this.getAllNiches();
    const errors: string[] = [];
    let synced = 0;
    
    for (const niche of niches) {
      try {
        await this.supabase.from('trending_niches').upsert({
          name: niche.name,
          category: niche.category,
          products: niche.recommendedProducts,
          demand_score: niche.demandScore,
          seasonal_boost: niche.seasonalBoost,
          final_score: niche.finalScore,
          competition_level: niche.competitionLevel,
          recommended_products: niche.recommendedProducts,
          scanned_at: new Date().toISOString(),
          is_active: true,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'name' });
        
        synced++;
      } catch (error) {
        errors.push(`Failed to sync ${niche.name}: ${error}`);
      }
    }
    
    return { synced, errors };
  }
  
  /**
   * Generate product ideas for a niche
   */
  generateProductIdeas(nicheName: string, count: number = 5): {
    subNiche: string;
    productType: string;
    conceptIdea: string;
  }[] {
    const niche = NICHE_DATABASE[nicheName];
    if (!niche) return [];
    
    const ideas: { subNiche: string; productType: string; conceptIdea: string }[] = [];
    
    for (let i = 0; i < count && i < niche.subNiches.length; i++) {
      const subNiche = niche.subNiches[i];
      const productType = niche.recommendedProducts[i % niche.recommendedProducts.length];
      const keyword = niche.keywords[i % niche.keywords.length];
      
      ideas.push({
        subNiche,
        productType,
        conceptIdea: `${subNiche} themed ${productType.replace('pod_', '').replace('digital_', '')} with "${keyword}" messaging`,
      });
    }
    
    return ideas;
  }
}

export default NicheResearch;
