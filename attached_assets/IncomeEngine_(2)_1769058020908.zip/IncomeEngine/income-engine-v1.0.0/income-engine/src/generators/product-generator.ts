/**
 * Product Generator
 * AI-powered product creation with multi-model routing
 */

import { createClient } from '@supabase/supabase-js';
import { AIRouter, TaskType } from '../ai-router/router';

// Types
export interface ProductConfig {
  niche: string;
  subNiche?: string;
  productType: string;
  style?: string;
  targetPlatform?: 'etsy' | 'gumroad' | 'printify';
  qualityTier?: 'economy' | 'standard' | 'premium';
}

export interface GeneratedProduct {
  id?: string;
  title: string;
  description: string;
  tags: string[];
  imageUrl: string;
  imagePrompt: string;
  niche: string;
  subNiche?: string;
  productType: string;
  targetPlatform: string;
  priceRange: 'low' | 'medium' | 'high';
  generationCost: number;
  status: 'pending' | 'approved' | 'rejected' | 'published';
  createdAt: string;
}

// Niche-specific prompt templates
const NICHE_PROMPTS: Record<string, {
  styles: string[];
  keywords: string[];
  colorPalettes: string[];
  avoidWords: string[];
}> = {
  'dog-breed-specific': {
    styles: ['cute cartoon', 'realistic portrait', 'minimalist line art', 'watercolor'],
    keywords: ['loyal', 'playful', 'best friend', 'fur baby', 'paw', 'woof'],
    colorPalettes: ['warm earth tones', 'pastel soft', 'bold primary'],
    avoidWords: ['aggressive', 'attack', 'dangerous'],
  },
  'pet-portraits': {
    styles: ['pop art', 'royal portrait', 'cartoon', 'silhouette'],
    keywords: ['beloved', 'family member', 'furry friend', 'companion'],
    colorPalettes: ['vibrant', 'muted vintage', 'monochrome'],
    avoidWords: ['sad', 'sick', 'lost'],
  },
  'teacher-appreciation': {
    styles: ['hand-lettered', 'chalkboard', 'apple motif', 'school supplies'],
    keywords: ['inspire', 'educate', 'shape future', 'make difference', 'thank you'],
    colorPalettes: ['bright cheerful', 'classic red/green', 'soft pastels'],
    avoidWords: ['worst', 'hate', 'boring'],
  },
  'nurse-healthcare': {
    styles: ['heartbeat line', 'medical symbols', 'bold text', 'caring hands'],
    keywords: ['hero', 'healing', 'compassion', 'dedication', 'scrubs life'],
    colorPalettes: ['medical blue/teal', 'pink/red hearts', 'clean white'],
    avoidWords: ['death', 'blood', 'gore'],
  },
  'gaming-retro': {
    styles: ['pixel art', '8-bit', 'neon glow', 'retro arcade'],
    keywords: ['level up', 'game on', 'player', 'respawn', 'high score'],
    colorPalettes: ['neon synthwave', 'classic nintendo', 'arcade cabinet'],
    avoidWords: ['violence', 'kill', 'death'],
  },
  'mom-life-humor': {
    styles: ['hand-lettered', 'coffee cup', 'messy bun', 'wine glass'],
    keywords: ['chaos coordinator', 'mom fuel', 'tired but blessed', 'wine o\'clock'],
    colorPalettes: ['soft pink/gray', 'rose gold', 'coffee browns'],
    avoidWords: ['hate', 'regret', 'drunk'],
  },
  'plant-parent': {
    styles: ['botanical illustration', 'minimalist line', 'watercolor', 'cute cartoon'],
    keywords: ['plant mama', 'crazy plant lady', 'grow', 'green thumb'],
    colorPalettes: ['green/earth tones', 'botanical', 'terracotta'],
    avoidWords: ['dead', 'killed', 'dying'],
  },
  'astrology-zodiac': {
    styles: ['celestial', 'constellation', 'mystical', 'minimalist symbols'],
    keywords: ['stars aligned', 'cosmic', 'birth chart', 'zodiac energy'],
    colorPalettes: ['midnight blue/gold', 'cosmic purple', 'constellation white'],
    avoidWords: ['evil', 'cursed', 'doomed'],
  },
  'minimalist-quotes': {
    styles: ['clean typography', 'simple line art', 'modern sans-serif', 'elegant script'],
    keywords: ['breathe', 'be kind', 'good vibes', 'positive', 'grateful'],
    colorPalettes: ['black/white', 'neutral tones', 'single accent color'],
    avoidWords: ['hate', 'die', 'negative'],
  },
  'eco-activism': {
    styles: ['nature illustration', 'earth motif', 'hand-drawn', 'vintage poster'],
    keywords: ['save earth', 'eco warrior', 'sustainable', 'green', 'recycle'],
    colorPalettes: ['earth greens/browns', 'ocean blues', 'sunset oranges'],
    avoidWords: ['destroy', 'pollution', 'death'],
  },
};

// Product type templates
const PRODUCT_TEMPLATES: Record<string, {
  titleFormat: string[];
  descriptionFormat: string;
  imageSize: { width: number; height: number };
  tagSuggestions: string[];
}> = {
  'pod_tshirt': {
    titleFormat: [
      '{adjective} {subject} T-Shirt - {niche} Gift',
      '{subject} Lover Shirt - Funny {niche} Tee',
      '{quote} - {niche} T-Shirt Gift Idea',
    ],
    descriptionFormat: `Express your love for {niche} with this {adjective} t-shirt! Perfect for {occasion}.

✨ Features:
• Premium soft cotton blend
• Unisex fit (S-3XL)
• Vibrant, fade-resistant print
• Pre-shrunk fabric

🎁 Makes a perfect gift for {recipient}!

📦 Shipping: Made to order, ships within 3-5 business days.`,
    imageSize: { width: 4500, height: 5400 },
    tagSuggestions: ['tshirt', 'gift', 'unisex', 'funny', 'cute'],
  },
  'pod_mug': {
    titleFormat: [
      '{adjective} {subject} Coffee Mug - {niche} Lover Gift',
      '{quote} Mug - Perfect {niche} Present',
      '{subject} 11oz Ceramic Mug - {niche} Style',
    ],
    descriptionFormat: `Start your day with this {adjective} {niche} mug!

☕ Specifications:
• 11oz ceramic mug
• Dishwasher & microwave safe
• High-quality, vibrant print
• Comfortable C-handle

Perfect for {recipient} who love {niche}!

🎁 Gift-ready packaging available.`,
    imageSize: { width: 3000, height: 3000 },
    tagSuggestions: ['mug', 'coffee', 'tea', 'gift', 'ceramic'],
  },
  'pod_poster': {
    titleFormat: [
      '{adjective} {subject} Wall Art - {niche} Poster Print',
      '{subject} Poster - {niche} Home Decor',
      '{quote} Art Print - {niche} Wall Decor',
    ],
    descriptionFormat: `Transform your space with this {adjective} {niche} poster!

🖼️ Details:
• Premium matte finish
• Vibrant, fade-resistant inks
• Multiple sizes available
• Museum-quality paper

Perfect for {room} or as a gift for {recipient}.`,
    imageSize: { width: 4500, height: 6000 },
    tagSuggestions: ['poster', 'wall art', 'print', 'decor', 'home'],
  },
  'digital_printable': {
    titleFormat: [
      '{adjective} {subject} Printable - Instant Download',
      '{niche} Wall Art Digital Download',
      '{quote} Printable Art - DIY Home Decor',
    ],
    descriptionFormat: `Instant download {niche} printable art!

📥 What You Get:
• High-resolution PDF (300 DPI)
• Multiple sizes included (8x10, 11x14, 16x20)
• Print at home or local print shop
• Unlimited personal use

⚡ Instant access after purchase!`,
    imageSize: { width: 3000, height: 4000 },
    tagSuggestions: ['printable', 'digital download', 'instant download', 'wall art', 'diy'],
  },
  'digital_planner': {
    titleFormat: [
      '{year} Digital Planner - {niche} Theme',
      '{adjective} {niche} Planner - GoodNotes/Notability',
      '{subject} Digital Planner - iPad Planner',
    ],
    descriptionFormat: `Stay organized with this {adjective} {niche} digital planner!

📱 Features:
• Compatible with GoodNotes, Notability, PDF apps
• Hyperlinked tabs for easy navigation
• {pages} pages of planning templates
• Undated - start anytime!

Includes: Monthly, weekly, daily spreads, goal trackers, notes pages.`,
    imageSize: { width: 2048, height: 2732 },
    tagSuggestions: ['digital planner', 'goodnotes', 'ipad planner', 'notability', 'pdf'],
  },
};

export class ProductGenerator {
  private supabase: ReturnType<typeof createClient>;
  private aiRouter: AIRouter;
  
  constructor(config: {
    supabaseUrl: string;
    supabaseKey: string;
    aiRouter: AIRouter;
  }) {
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
    this.aiRouter = config.aiRouter;
  }
  
  /**
   * Generate a complete product
   */
  async generateProduct(config: ProductConfig): Promise<GeneratedProduct> {
    const startTime = Date.now();
    let totalCost = 0;
    
    // Get niche-specific data
    const nicheData = NICHE_PROMPTS[config.niche] || NICHE_PROMPTS['minimalist-quotes'];
    const productTemplate = PRODUCT_TEMPLATES[config.productType] || PRODUCT_TEMPLATES['pod_tshirt'];
    
    // Step 1: Generate SEO title
    const titleResult = await this.generateTitle(config, nicheData, productTemplate);
    totalCost += titleResult.cost;
    
    // Step 2: Generate description
    const descResult = await this.generateDescription(config, nicheData, productTemplate, titleResult.title);
    totalCost += descResult.cost;
    
    // Step 3: Generate tags
    const tagsResult = await this.generateTags(config, nicheData, titleResult.title);
    totalCost += tagsResult.cost;
    
    // Step 4: Generate image prompt
    const imagePromptResult = await this.generateImagePrompt(config, nicheData, titleResult.title);
    totalCost += imagePromptResult.cost;
    
    // Step 5: Generate image
    const imageResult = await this.generateImage(imagePromptResult.prompt, productTemplate.imageSize, config.qualityTier);
    totalCost += imageResult.cost;
    
    // Determine price range based on quality tier
    const priceRange = config.qualityTier === 'premium' ? 'high' : 
                       config.qualityTier === 'economy' ? 'low' : 'medium';
    
    const product: GeneratedProduct = {
      title: titleResult.title,
      description: descResult.description,
      tags: tagsResult.tags,
      imageUrl: imageResult.url,
      imagePrompt: imagePromptResult.prompt,
      niche: config.niche,
      subNiche: config.subNiche,
      productType: config.productType,
      targetPlatform: config.targetPlatform || 'etsy',
      priceRange,
      generationCost: totalCost,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    
    // Save to database
    const { data, error } = await this.supabase
      .from('generated_products')
      .insert({
        title: product.title,
        description: product.description,
        tags: product.tags,
        image_url: product.imageUrl,
        image_prompt: product.imagePrompt,
        niche: product.niche,
        sub_niche: product.subNiche,
        product_type: product.productType,
        target_platform: product.targetPlatform,
        price_range: product.priceRange,
        generation_cost: product.generationCost,
        status: product.status,
        created_at: product.createdAt,
      })
      .select('id')
      .single();
    
    if (data) {
      product.id = data.id;
    }
    
    // Log generation time
    console.log(`Product generated in ${Date.now() - startTime}ms, cost: $${totalCost.toFixed(4)}`);
    
    return product;
  }
  
  /**
   * Generate SEO-optimized title
   */
  private async generateTitle(
    config: ProductConfig,
    nicheData: typeof NICHE_PROMPTS[string],
    template: typeof PRODUCT_TEMPLATES[string]
  ): Promise<{ title: string; cost: number }> {
    const prompt = `Generate a catchy, SEO-optimized product title for an Etsy listing.

Niche: ${config.niche}
Sub-niche: ${config.subNiche || 'general'}
Product type: ${config.productType}
Style keywords: ${nicheData.keywords.slice(0, 5).join(', ')}

Requirements:
- Maximum 140 characters
- Include 2-3 relevant keywords
- Make it appealing and searchable
- Do NOT use generic filler words
- Avoid: ${nicheData.avoidWords.join(', ')}

Example formats:
${template.titleFormat.join('\n')}

Return ONLY the title, no quotes or explanation.`;

    const result = await this.aiRouter.generateText(prompt, 'product_title');
    
    return {
      title: result.text.trim().substring(0, 140),
      cost: result.cost,
    };
  }
  
  /**
   * Generate product description
   */
  private async generateDescription(
    config: ProductConfig,
    nicheData: typeof NICHE_PROMPTS[string],
    template: typeof PRODUCT_TEMPLATES[string],
    title: string
  ): Promise<{ description: string; cost: number }> {
    const prompt = `Write a compelling product description for an Etsy listing.

Product title: ${title}
Niche: ${config.niche}
Product type: ${config.productType}

Use this template structure but make it unique:
${template.descriptionFormat}

Requirements:
- Be enthusiastic but not over-the-top
- Include relevant emoji (2-4 max)
- Highlight key features and benefits
- Include gift-giving angle
- 150-300 words
- Avoid: ${nicheData.avoidWords.join(', ')}

Return ONLY the description, no quotes.`;

    const result = await this.aiRouter.generateText(prompt, 'product_description');
    
    return {
      description: result.text.trim(),
      cost: result.cost,
    };
  }
  
  /**
   * Generate SEO tags
   */
  private async generateTags(
    config: ProductConfig,
    nicheData: typeof NICHE_PROMPTS[string],
    title: string
  ): Promise<{ tags: string[]; cost: number }> {
    const template = PRODUCT_TEMPLATES[config.productType];
    
    const prompt = `Generate 13 SEO tags for an Etsy product listing.

Title: ${title}
Niche: ${config.niche}
Sub-niche: ${config.subNiche || 'general'}
Product type: ${config.productType}

Suggested tags to consider: ${[...template?.tagSuggestions || [], ...nicheData.keywords].join(', ')}

Requirements:
- Exactly 13 tags (Etsy maximum)
- Mix of broad and specific keywords
- Include long-tail keywords
- No duplicate concepts
- Each tag max 20 characters

Return as comma-separated list, no quotes or numbers.`;

    const result = await this.aiRouter.generateText(prompt, 'seo_tags');
    
    // Parse tags
    const tags = result.text
      .split(',')
      .map(t => t.trim().toLowerCase())
      .filter(t => t.length > 0 && t.length <= 20)
      .slice(0, 13);
    
    return { tags, cost: result.cost };
  }
  
  /**
   * Generate image prompt
   */
  private async generateImagePrompt(
    config: ProductConfig,
    nicheData: typeof NICHE_PROMPTS[string],
    title: string
  ): Promise<{ prompt: string; cost: number }> {
    const style = config.style || nicheData.styles[Math.floor(Math.random() * nicheData.styles.length)];
    const colorPalette = nicheData.colorPalettes[Math.floor(Math.random() * nicheData.colorPalettes.length)];
    
    const prompt = `Create a detailed image generation prompt for a ${config.productType} design.

Product title: ${title}
Niche: ${config.niche}
Style: ${style}
Color palette: ${colorPalette}

Requirements:
- Design suitable for printing on ${config.productType.replace('pod_', '').replace('digital_', '')}
- Clean, high-contrast design
- No text in the image (text will be added separately if needed)
- Transparent or solid background suitable for the product
- Professional quality

Generate a detailed Flux/DALL-E compatible prompt. Include:
- Subject description
- Art style
- Color specifications
- Composition details
- Quality modifiers (high resolution, professional, etc.)

Return ONLY the prompt, no explanation.`;

    const result = await this.aiRouter.generateText(prompt, 'image_prompt');
    
    // Add quality modifiers
    const enhancedPrompt = `${result.text.trim()}, high resolution, professional quality, suitable for print-on-demand, clean design, 300 DPI`;
    
    return {
      prompt: enhancedPrompt,
      cost: result.cost,
    };
  }
  
  /**
   * Generate image using AI
   */
  private async generateImage(
    prompt: string,
    size: { width: number; height: number },
    qualityTier?: string
  ): Promise<{ url: string; cost: number }> {
    // Determine task type based on quality tier
    const taskType: TaskType = qualityTier === 'premium' ? 'premium_image' : 'product_image';
    
    const result = await this.aiRouter.generateImage(prompt, taskType, {
      width: Math.min(size.width, 1024), // Most AI models cap at 1024
      height: Math.min(size.height, 1024),
    });
    
    return {
      url: result.url,
      cost: result.cost,
    };
  }
  
  /**
   * Generate batch of products
   */
  async generateBatch(
    configs: ProductConfig[],
    options?: {
      delayMs?: number;
      onProgress?: (completed: number, total: number, product?: GeneratedProduct) => void;
    }
  ): Promise<{
    products: GeneratedProduct[];
    totalCost: number;
    errors: { config: ProductConfig; error: string }[];
  }> {
    const products: GeneratedProduct[] = [];
    const errors: { config: ProductConfig; error: string }[] = [];
    let totalCost = 0;
    
    for (let i = 0; i < configs.length; i++) {
      const config = configs[i];
      
      try {
        const product = await this.generateProduct(config);
        products.push(product);
        totalCost += product.generationCost;
        
        options?.onProgress?.(i + 1, configs.length, product);
      } catch (error) {
        errors.push({
          config,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
        
        options?.onProgress?.(i + 1, configs.length);
      }
      
      // Delay between generations
      if (options?.delayMs && i < configs.length - 1) {
        await new Promise(resolve => setTimeout(resolve, options.delayMs));
      }
    }
    
    return { products, totalCost, errors };
  }
  
  /**
   * Get generation cost estimate
   */
  estimateCost(config: ProductConfig): {
    estimated: number;
    breakdown: { task: string; cost: number }[];
  } {
    const isDigital = config.productType.startsWith('digital_');
    const isPremium = config.qualityTier === 'premium';
    
    // Based on AI router pricing
    const breakdown = [
      { task: 'Title generation', cost: 0.0005 },
      { task: 'Description generation', cost: 0.001 },
      { task: 'Tags generation', cost: 0.0005 },
      { task: 'Image prompt', cost: 0.001 },
      { task: 'Image generation', cost: isPremium ? 0.025 : 0.003 },
    ];
    
    const estimated = breakdown.reduce((sum, item) => sum + item.cost, 0);
    
    return { estimated, breakdown };
  }
}

export default ProductGenerator;
