/**
 * Platform Connectors Index
 * Unified interface for multi-platform automation
 */

export { PrintifyConnector, BLUEPRINT_MAP, PRICING_TIERS } from './printify';
export { EtsyConnector, TAXONOMY_MAP } from './etsy';
export { GumroadConnector, DIGITAL_PRICING } from './gumroad';

import { PrintifyConnector } from './printify';
import { EtsyConnector } from './etsy';
import { GumroadConnector } from './gumroad';

// Unified platform types
export type Platform = 'printify' | 'etsy' | 'gumroad';

export interface PlatformConfig {
  printify?: {
    apiKey: string;
    shopId: string;
  };
  etsy?: {
    clientId: string;
    clientSecret: string;
    redirectUri: string;
    shopId: string;
  };
  gumroad?: {
    accessToken: string;
  };
  supabase: {
    url: string;
    key: string;
  };
}

export interface PlatformHealthStatus {
  platform: Platform;
  healthy: boolean;
  details: Record<string, any>;
  checkedAt: string;
}

export interface UnifiedProduct {
  id?: string;
  title: string;
  description: string;
  price: number;
  productType: string;
  imageUrl: string;
  tags?: string[];
  platform: Platform;
  externalId?: string;
  externalUrl?: string;
  status: 'draft' | 'active' | 'inactive' | 'error';
}

/**
 * Platform Manager - Coordinates multi-platform operations
 */
export class PlatformManager {
  private printify?: PrintifyConnector;
  private etsy?: EtsyConnector;
  private gumroad?: GumroadConnector;
  
  constructor(config: PlatformConfig) {
    if (config.printify) {
      this.printify = new PrintifyConnector({
        ...config.printify,
        supabaseUrl: config.supabase.url,
        supabaseKey: config.supabase.key,
      });
    }
    
    if (config.etsy) {
      this.etsy = new EtsyConnector({
        ...config.etsy,
        supabaseUrl: config.supabase.url,
        supabaseKey: config.supabase.key,
      });
    }
    
    if (config.gumroad) {
      this.gumroad = new GumroadConnector({
        ...config.gumroad,
        supabaseUrl: config.supabase.url,
        supabaseKey: config.supabase.key,
      });
    }
  }
  
  /**
   * Get available platforms
   */
  getAvailablePlatforms(): Platform[] {
    const platforms: Platform[] = [];
    if (this.printify) platforms.push('printify');
    if (this.etsy) platforms.push('etsy');
    if (this.gumroad) platforms.push('gumroad');
    return platforms;
  }
  
  /**
   * Health check all platforms
   */
  async healthCheckAll(): Promise<PlatformHealthStatus[]> {
    const results: PlatformHealthStatus[] = [];
    
    if (this.printify) {
      const health = await this.printify.healthCheck();
      results.push({
        platform: 'printify',
        healthy: health.healthy,
        details: health,
        checkedAt: new Date().toISOString(),
      });
    }
    
    if (this.etsy) {
      const health = await this.etsy.healthCheck();
      results.push({
        platform: 'etsy',
        healthy: health.healthy,
        details: health,
        checkedAt: new Date().toISOString(),
      });
    }
    
    if (this.gumroad) {
      const health = await this.gumroad.healthCheck();
      results.push({
        platform: 'gumroad',
        healthy: health.healthy,
        details: health,
        checkedAt: new Date().toISOString(),
      });
    }
    
    return results;
  }
  
  /**
   * Publish product to appropriate platform
   */
  async publishProduct(product: UnifiedProduct): Promise<{
    success: boolean;
    externalId?: string;
    externalUrl?: string;
    error?: string;
  }> {
    try {
      // Route to appropriate platform based on product type
      const isDigital = product.productType.startsWith('digital_');
      
      if (isDigital && this.gumroad) {
        // Digital products go to Gumroad
        const result = await this.gumroad.createOptimizedProduct({
          name: product.title,
          description: product.description,
          productType: product.productType,
          previewUrl: product.imageUrl,
          tags: product.tags,
        });
        
        return {
          success: true,
          externalId: result.product.id,
          externalUrl: result.productUrl,
        };
      }
      
      if (!isDigital && this.printify) {
        // POD products go to Printify
        const result = await this.printify.createAndPublishProduct({
          title: product.title,
          description: product.description,
          productType: product.productType,
          imageUrl: product.imageUrl,
          tags: product.tags,
        });
        
        return {
          success: true,
          externalId: result.productId,
        };
      }
      
      // If Etsy is available as alternative
      if (this.etsy) {
        const result = await this.etsy.createAndPublishListing({
          title: product.title,
          description: product.description,
          price: product.price,
          productType: product.productType,
          imageUrl: product.imageUrl,
          tags: product.tags,
          isDigital,
        });
        
        return {
          success: true,
          externalId: result.listingId.toString(),
          externalUrl: result.listingUrl,
        };
      }
      
      return {
        success: false,
        error: 'No suitable platform available for this product type',
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Get aggregated revenue across all platforms
   */
  async getAggregatedRevenue(days: number = 30): Promise<{
    total: {
      grossRevenue: number;
      fees: number;
      netRevenue: number;
    };
    byPlatform: Record<Platform, {
      grossRevenue: number;
      fees: number;
      netRevenue: number;
      salesCount: number;
    }>;
    calculatedAt: string;
  }> {
    const byPlatform: Record<string, any> = {};
    let totalGross = 0;
    let totalFees = 0;
    
    if (this.etsy) {
      try {
        const revenue = await this.etsy.calculateRevenue(days);
        byPlatform.etsy = {
          grossRevenue: revenue.grossRevenue,
          fees: revenue.fees,
          netRevenue: revenue.netRevenue,
          salesCount: revenue.orderCount,
        };
        totalGross += revenue.grossRevenue;
        totalFees += revenue.fees;
      } catch (error) {
        console.error('Etsy revenue fetch failed:', error);
      }
    }
    
    if (this.gumroad) {
      try {
        const revenue = await this.gumroad.calculateRevenue(days);
        byPlatform.gumroad = {
          grossRevenue: revenue.grossRevenue,
          fees: revenue.gumroadFees,
          netRevenue: revenue.netRevenue,
          salesCount: revenue.salesCount,
        };
        totalGross += revenue.grossRevenue;
        totalFees += revenue.gumroadFees;
      } catch (error) {
        console.error('Gumroad revenue fetch failed:', error);
      }
    }
    
    // Note: Printify revenue comes from connected sales channels
    // (Etsy, Shopify, etc.) - we don't double-count
    
    return {
      total: {
        grossRevenue: Math.round(totalGross * 100) / 100,
        fees: Math.round(totalFees * 100) / 100,
        netRevenue: Math.round((totalGross - totalFees) * 100) / 100,
      },
      byPlatform: byPlatform as any,
      calculatedAt: new Date().toISOString(),
    };
  }
  
  /**
   * Get connector instance
   */
  getPrintify(): PrintifyConnector | undefined { return this.printify; }
  getEtsy(): EtsyConnector | undefined { return this.etsy; }
  getGumroad(): GumroadConnector | undefined { return this.gumroad; }
}

export default PlatformManager;
