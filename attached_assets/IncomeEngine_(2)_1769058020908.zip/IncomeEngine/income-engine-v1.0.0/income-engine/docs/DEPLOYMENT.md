# Deployment Guide - Passive Income Engine

## TL;DR

Deploy n8n on a $5-10/month VPS, configure API credentials, import workflows, and start generating $1K/month in passive income.

---

## Prerequisites Checklist

Before you begin, ensure you have:

- [ ] VPS server ($5-10/month) - Hetzner, DigitalOcean, or Hostinger
- [ ] Domain name (optional but recommended)
- [ ] Supabase account (free tier)
- [ ] Printify account (free)
- [ ] Etsy seller account (~$15 to open)
- [ ] Gumroad account (free)
- [ ] Replicate account ($5 credit)
- [ ] OpenAI API key
- [ ] Slack workspace (for notifications)

---

## Phase 1: Infrastructure Setup (30 minutes)

### 1.1 Provision VPS

**Recommended providers (cheapest to most featured):**

| Provider | Plan | Price | Specs |
|----------|------|-------|-------|
| Hetzner | CX11 | €4.50/mo | 1 vCPU, 2GB RAM, 20GB SSD |
| DigitalOcean | Basic Droplet | $6/mo | 1 vCPU, 1GB RAM, 25GB SSD |
| Hostinger | KVM 1 | $5.99/mo | 1 vCPU, 4GB RAM, 50GB NVMe |
| Vultr | Regular | $6/mo | 1 vCPU, 1GB RAM, 25GB SSD |

**Setup steps:**
1. Create account with chosen provider
2. Provision Ubuntu 22.04 LTS server
3. Note the IP address
4. SSH into server: `ssh root@YOUR_IP`

### 1.2 Run Setup Script

```bash
# Download and run setup script
curl -sSL https://raw.githubusercontent.com/YOUR_REPO/income-engine/main/scripts/setup-n8n.sh | sudo bash
```

Or manually:

```bash
# Update system
apt update && apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh

# Create n8n directory
mkdir -p /opt/n8n && cd /opt/n8n

# Create docker-compose.yml (copy from scripts/setup-n8n.sh)
# Edit .env with secure passwords

# Start n8n
docker-compose up -d
```

### 1.3 Configure SSL (if using domain)

```bash
# Install certbot
apt install certbot python3-certbot-nginx -y

# Get certificate
certbot --nginx -d n8n.yourdomain.com
```

---

## Phase 2: Database Setup (15 minutes)

### 2.1 Create Supabase Project

1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Note down:
   - Project URL: `https://xxxxx.supabase.co`
   - Service Role Key (Settings → API)

### 2.2 Run Schema Migration

1. Go to Supabase SQL Editor
2. Copy contents of `database/schema-extensions.sql`
3. Execute the SQL

### 2.3 Verify Tables Created

```sql
-- Run this to verify
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public';
```

Expected tables:
- `trending_niches`
- `generated_products`
- `rejected_products`
- `revenue_snapshots`
- `sales_records`
- `ai_generation_costs`
- `product_templates`

---

## Phase 3: API Credentials Setup (20 minutes)

### 3.1 Replicate (Image Generation)

1. Go to [replicate.com](https://replicate.com)
2. Sign up / Sign in
3. Go to Account Settings → API Tokens
4. Create new token
5. Note: `r8_xxxxxxxxxxxx`

**Cost:** ~$0.003/image (Flux Schnell)

### 3.2 OpenAI (Text Generation)

1. Go to [platform.openai.com](https://platform.openai.com)
2. Go to API Keys
3. Create new secret key
4. Note: `sk-xxxxxxxxxxxx`

**Cost:** ~$0.15/1M tokens (GPT-4o-mini)

### 3.3 Printify

1. Go to [printify.com](https://printify.com)
2. Sign up (free)
3. Go to Settings → API
4. Generate API token
5. Note your Shop ID (from URL)

**Cost:** Free (pay per order)

### 3.4 Etsy OAuth

1. Go to [etsy.com/developers](https://www.etsy.com/developers)
2. Create new app
3. Get API Key and Shared Secret
4. Configure OAuth callback: `https://n8n.yourdomain.com/rest/oauth2-credential/callback`

**Cost:** $0.20/listing + 6.5% transaction fee

### 3.5 Gumroad OAuth

1. Go to [gumroad.com/settings/advanced](https://gumroad.com/settings/advanced)
2. Create OAuth application
3. Get Client ID and Secret
4. Configure callback URL

**Cost:** 10% per sale

### 3.6 Slack Webhook

1. Go to [api.slack.com/apps](https://api.slack.com/apps)
2. Create new app → From scratch
3. Enable Incoming Webhooks
4. Add webhook to workspace
5. Copy webhook URL

---

## Phase 4: n8n Configuration (15 minutes)

### 4.1 Access n8n

Open `https://n8n.yourdomain.com` in browser

### 4.2 Add Credentials

Go to Settings → Credentials → Add Credential:

1. **Replicate Auth** (HTTP Header Auth)
   - Header Name: `Authorization`
   - Header Value: `Token r8_xxxxxxxxxxxx`

2. **OpenAI**
   - API Key: `sk-xxxxxxxxxxxx`

3. **Printify Auth** (HTTP Header Auth)
   - Header Name: `Authorization`
   - Header Value: `Bearer YOUR_PRINTIFY_TOKEN`

4. **Supabase**
   - Host: `https://xxxxx.supabase.co`
   - Service Role Key: `eyJxxxx...`

5. **Etsy OAuth2**
   - Client ID: `xxxxxxxx`
   - Client Secret: `xxxxxxxx`
   - Authorization URL: `https://www.etsy.com/oauth/connect`
   - Access Token URL: `https://api.etsy.com/v3/public/oauth/token`
   - Scope: `listings_w shops_r transactions_r`

6. **Gumroad OAuth2**
   - Client ID: `xxxxxxxx`
   - Client Secret: `xxxxxxxx`
   - Scope: `edit_products view_sales`

7. **Slack**
   - Webhook URL: `https://hooks.slack.com/services/xxx/xxx/xxx`

### 4.3 Set Environment Variables

In n8n Settings → Variables, add:

| Variable | Value |
|----------|-------|
| `PRINTIFY_SHOP_ID` | Your Printify shop ID |
| `ETSY_SHOP_ID` | Your Etsy shop ID |
| `SAFEGUARDS_API_URL` | URL of your safeguards dashboard |

---

## Phase 5: Import Workflows (10 minutes)

### 5.1 Get n8n API Key

1. Go to n8n Settings → API
2. Create API Key
3. Copy the key

### 5.2 Import Workflows

```bash
# SSH into your server
ssh root@YOUR_IP

# Navigate to n8n directory
cd /opt/n8n

# Copy workflow files
mkdir -p workflows
# Upload workflow JSON files to this directory

# Set API key
export N8N_API_KEY="your_api_key_here"
export N8N_URL="https://n8n.yourdomain.com"

# Run import script
./import-workflows.sh
```

Or manually import via UI:
1. Go to n8n → Workflows
2. Click "..." → Import from file
3. Select each JSON file

### 5.3 Activate Workflows

After import, activate each workflow:
- 01-Niche-Scanner ✅
- 02-Product-Generator ✅
- 03-Printify-Publisher ✅
- 05-Gumroad-Publisher ✅
- 06-Revenue-Aggregator ✅

---

## Phase 6: First Test Run (15 minutes)

### 6.1 Test Niche Scanner

1. Open "01-Niche-Scanner" workflow
2. Click "Execute Workflow"
3. Check Supabase `trending_niches` table
4. Verify Slack notification received

### 6.2 Test Product Generator

1. Use webhook trigger or manual execution
2. Set parameters:
   ```json
   {
     "niche": "dog-breed-specific",
     "subNiche": "golden-retriever",
     "batchSize": 1,
     "productType": "pod_tshirt"
   }
   ```
3. Monitor execution
4. Check `generated_products` table

### 6.3 Test Printify Publisher

1. Ensure a product exists with `status: approved`
2. Execute "03-Printify-Publisher"
3. Verify product created in Printify dashboard

---

## Monitoring & Maintenance

### Daily Checks

- [ ] Revenue report in Slack
- [ ] No error notifications
- [ ] Products being generated

### Weekly Tasks

- [ ] Review rejection reasons
- [ ] Analyze top-performing niches
- [ ] Adjust budget limits if needed

### Monthly Tasks

- [ ] Update niche research
- [ ] Review and optimize workflows
- [ ] Check API costs vs revenue

---

## Troubleshooting

### n8n Won't Start

```bash
# Check logs
docker-compose logs -f n8n

# Common fix: restart
docker-compose restart

# Nuclear option: recreate
docker-compose down && docker-compose up -d
```

### Workflow Errors

1. Check execution logs in n8n UI
2. Verify credentials are correct
3. Check API rate limits
4. Ensure environment variables set

### Database Connection Issues

```bash
# Check PostgreSQL
docker-compose logs postgres

# Verify connection
docker exec -it n8n-postgres psql -U n8n -d n8n -c "SELECT 1"
```

### Image Generation Fails

- Check Replicate API token is valid
- Verify balance/credits available
- Check prompt doesn't violate content policy

---

## Cost Tracking

### Monthly Budget Template

| Category | Budget | Actual |
|----------|--------|--------|
| VPS Hosting | $10 | |
| Replicate (Images) | $20 | |
| OpenAI (Text) | $10 | |
| Etsy Fees | $15 | |
| **Total** | **$55** | |

### ROI Calculation

```
Net Profit = Revenue - (Platform Fees + API Costs + Hosting)
ROI = (Net Profit / Total Costs) × 100
```

---

## Scaling Checklist

When ready to scale:

- [ ] Increase VPS RAM to 4GB ($15-20/mo)
- [ ] Enable n8n queue mode for parallel execution
- [ ] Add more niches (5-10 total)
- [ ] Increase batch sizes (10-25 products)
- [ ] Add more platforms (Shopify, Amazon)
- [ ] Consider dedicated database (Supabase Pro)

---

## Support Resources

- n8n Documentation: https://docs.n8n.io
- n8n Community: https://community.n8n.io
- Printify API: https://developers.printify.com
- Etsy API: https://developer.etsy.com
- Gumroad API: https://gumroad.com/api

---

## Quick Reference Commands

```bash
# Start n8n
cd /opt/n8n && docker-compose up -d

# Stop n8n
docker-compose down

# View logs
docker-compose logs -f

# Restart
docker-compose restart

# Update n8n
docker-compose pull && docker-compose up -d

# Backup
docker-compose exec postgres pg_dump -U n8n n8n > backup.sql

# Restore
docker-compose exec -i postgres psql -U n8n n8n < backup.sql
```
