import SyncConfigurationManager from '../components/integrations/SyncConfigurationManager';

export default SyncConfiguration;

function SyncConfiguration() {
  return <SyncConfigurationManager />;
}