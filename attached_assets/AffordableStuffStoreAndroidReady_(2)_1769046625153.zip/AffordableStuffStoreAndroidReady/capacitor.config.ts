import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.affordablestuffstore.app',
  appName: 'AffordableStuffStore',
  webDir: 'dist/client',
  bundledWebRuntime: false,
  server: {
    // For production builds, Capacitor loads local assets from webDir.
    // During Android dev, you can uncomment url to live-reload from your LAN.
    // url: 'http://192.168.1.100:5173',
    // cleartext: true,
  },
};

export default config;
