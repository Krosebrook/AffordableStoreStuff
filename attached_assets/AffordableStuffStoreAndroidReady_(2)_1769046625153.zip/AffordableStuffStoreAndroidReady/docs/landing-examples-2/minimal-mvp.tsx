// examples/minimal-mvp.tsx
// Minimal landing page for quick MVPs and product validation
// Use this when: Testing product-market fit, launching in <1 week, validating demand

import { CenterHero } from '@/components/Hero';
import { Button } from '@/components/Button';

export default function MinimalMVP() {
  return (
    <main>
      {/* Single-focus hero with email capture */}
      <CenterHero
        heading="Ship your SaaS in days, not months"
        subheading="The fastest way to validate your idea. No code required."
        primaryCTA={{
          text: 'Join Waitlist',
          href: '#waitlist',
        }}
      />

      {/* Simple 3-feature grid */}
      <section className="features">
        <div className="container">
          <div className="feature-row">
            <div className="feature">
              <span className="feature-icon">⚡</span>
              <h3>Fast Setup</h3>
              <p>Launch in minutes with our templates</p>
            </div>
            <div className="feature">
              <span className="feature-icon">🔒</span>
              <h3>Secure</h3>
              <p>Enterprise-grade security built-in</p>
            </div>
            <div className="feature">
              <span className="feature-icon">📊</span>
              <h3>Analytics</h3>
              <p>Track what matters from day one</p>
            </div>
          </div>
        </div>

        <style jsx>{`
          .features {
            padding: 80px 0;
            background: white;
          }

          .feature-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            max-width: 900px;
            margin: 0 auto;
          }

          .feature {
            text-align: center;
          }

          .feature-icon {
            display: block;
            font-size: 48px;
            margin-bottom: 16px;
          }

          .feature h3 {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--gray-900);
          }

          .feature p {
            font-size: 14px;
            color: var(--gray-600);
          }

          @media (max-width: 640px) {
            .features {
              padding: 60px 0;
            }

            .feature-row {
              grid-template-columns: 1fr;
              gap: 32px;
            }
          }
        `}</style>
      </section>

      {/* Waitlist form */}
      <section className="waitlist" id="waitlist">
        <div className="container">
          <div className="waitlist-content">
            <h2>Join 500+ developers on the waitlist</h2>
            <p>Be the first to know when we launch</p>
            
            <form className="waitlist-form" onSubmit={(e) => {
              e.preventDefault();
              // TODO: Connect to your email provider (Resend, SendGrid, etc.)
              const email = (e.currentTarget.elements.namedItem('email') as HTMLInputElement).value;
              console.log('Waitlist signup:', email);
              alert('Thanks! We\'ll notify you at launch.');
            }}>
              <input
                type="email"
                name="email"
                placeholder="your@email.com"
                required
                className="email-input"
              />
              <Button type="submit" variant="primary" size="lg">
                Join Waitlist
              </Button>
            </form>

            <p className="privacy-note">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>

        <style jsx>{`
          .waitlist {
            padding: 100px 0;
            background: linear-gradient(
              135deg,
              var(--primary-50) 0%,
              var(--gray-50) 100%
            );
          }

          .waitlist-content {
            text-align: center;
            max-width: 600px;
            margin: 0 auto;
          }

          .waitlist-content h2 {
            font-size: clamp(28px, 4vw, 40px);
            font-weight: 700;
            margin-bottom: 12px;
            color: var(--gray-900);
          }

          .waitlist-content > p {
            font-size: 18px;
            color: var(--gray-600);
            margin-bottom: 32px;
          }

          .waitlist-form {
            display: flex;
            gap: 12px;
            max-width: 500px;
            margin: 0 auto 16px;
          }

          .email-input {
            flex: 1;
            height: 52px;
            padding: 0 20px;
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            font-size: 16px;
            transition: all 200ms ease-out;
          }

          .email-input:focus {
            outline: none;
            border-color: var(--primary-500);
            box-shadow: 0 0 0 3px var(--primary-100);
          }

          .privacy-note {
            font-size: 12px;
            color: var(--gray-500);
          }

          @media (max-width: 640px) {
            .waitlist {
              padding: 80px 0;
            }

            .waitlist-form {
              flex-direction: column;
            }

            .waitlist-form :global(button) {
              width: 100%;
            }
          }
        `}</style>
      </section>

      {/* Simple footer */}
      <footer className="footer">
        <div className="container">
          <p>&copy; 2025 Your SaaS. All rights reserved.</p>
          <div className="footer-links">
            <a href="/privacy">Privacy</a>
            <a href="/terms">Terms</a>
          </div>
        </div>

        <style jsx>{`
          .footer {
            padding: 40px 0;
            background: white;
            border-top: 1px solid var(--gray-200);
          }

          .footer .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
          }

          .footer p {
            font-size: 14px;
            color: var(--gray-600);
          }

          .footer-links {
            display: flex;
            gap: 24px;
          }

          .footer-links a {
            font-size: 14px;
            color: var(--gray-600);
            text-decoration: none;
            transition: color 200ms ease-out;
          }

          .footer-links a:hover {
            color: var(--gray-900);
          }

          @media (max-width: 640px) {
            .footer .container {
              flex-direction: column;
              gap: 16px;
              text-align: center;
            }
          }
        `}</style>
      </footer>
    </main>
  );
}
