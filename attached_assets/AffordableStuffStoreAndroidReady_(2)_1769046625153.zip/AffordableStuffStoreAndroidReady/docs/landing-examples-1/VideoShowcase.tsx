'use client';

import React, { useState, useRef } from 'react';

interface VideoShowcaseProps {
  title?: string;
  subtitle?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  transcript?: string;
  ctaText?: string;
  ctaLink?: string;
  autoplay?: boolean;
  layout?: 'centered' | 'wide' | 'split';
}

/**
 * VideoShowcase - Product demo video player
 * 
 * Usage: Demo videos result in 49% faster revenue growth.
 * 30% of sites show demo videos, but only with actual UI.
 * 
 * @param title - Section heading
 * @param subtitle - Supporting description
 * @param videoUrl - URL to video file
 * @param thumbnailUrl - Poster image before playback
 * @param transcript - Optional video transcript for accessibility
 * @param ctaText - Call-to-action button text
 * @param ctaLink - CTA destination
 * @param autoplay - Auto-play video (muted, on scroll into view)
 * @param layout - Display style: centered, wide (full-width), split (text + video)
 */
export default function VideoShowcase({
  title,
  subtitle,
  videoUrl,
  thumbnailUrl,
  transcript,
  ctaText,
  ctaLink = '#',
  autoplay = false,
  layout = 'centered',
}: VideoShowcaseProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handlePlayClick = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className={`video-showcase layout-${layout}`}>
      <div className="video-container">
        {(title || subtitle) && (
          <div className="video-header">
            {title && <h2>{title}</h2>}
            {subtitle && <p className="subtitle">{subtitle}</p>}
          </div>
        )}

        <div className="video-wrapper">
          <div className="video-player">
            <video
              ref={videoRef}
              src={videoUrl}
              poster={thumbnailUrl}
              controls
              playsInline
              autoPlay={autoplay}
              muted={autoplay}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              aria-label={title || 'Product demo video'}
            >
              Your browser does not support the video tag.
            </video>

            {!isPlaying && thumbnailUrl && (
              <button
                className="play-overlay"
                onClick={handlePlayClick}
                aria-label="Play video"
              >
                <svg
                  width="80"
                  height="80"
                  viewBox="0 0 80 80"
                  fill="none"
                >
                  <circle
                    cx="40"
                    cy="40"
                    r="40"
                    fill="rgba(255, 255, 255, 0.95)"
                  />
                  <path
                    d="M32 25L55 40L32 55V25Z"
                    fill="var(--primary)"
                  />
                </svg>
              </button>
            )}
          </div>

          {transcript && (
            <div className="transcript-section">
              <button
                className="transcript-toggle"
                onClick={() => setShowTranscript(!showTranscript)}
                aria-expanded={showTranscript}
              >
                {showTranscript ? 'Hide' : 'Show'} Transcript
              </button>
              {showTranscript && (
                <div className="transcript-content">
                  <p>{transcript}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {ctaText && (
          <div className="video-cta">
            <a href={ctaLink} className="btn-primary">
              {ctaText}
            </a>
          </div>
        )}
      </div>

      <style jsx>{`
        .video-showcase {
          padding: 80px 20px;
          background: var(--gray-50);
        }

        .video-container {
          max-width: 1200px;
          margin: 0 auto;
        }

        /* Layout Variants */
        .layout-centered .video-container {
          max-width: 900px;
        }

        .layout-wide .video-container {
          max-width: 100%;
          padding: 0;
        }

        .layout-split .video-container {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 60px;
          align-items: center;
        }

        /* Header */
        .video-header {
          text-align: center;
          margin-bottom: 48px;
        }

        .layout-split .video-header {
          text-align: left;
        }

        .video-header h2 {
          font-size: 2.5rem;
          font-weight: 700;
          margin-bottom: 16px;
          color: var(--gray-900);
        }

        .subtitle {
          font-size: 1.25rem;
          color: var(--gray-600);
          line-height: 1.7;
        }

        /* Video Wrapper */
        .video-wrapper {
          position: relative;
        }

        .video-player {
          position: relative;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
          background: black;
        }

        .video-player video {
          width: 100%;
          height: auto;
          display: block;
        }

        /* Play Overlay */
        .play-overlay {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: none;
          border: none;
          cursor: pointer;
          transition: all 0.3s ease;
          z-index: 2;
        }

        .play-overlay:hover {
          transform: translate(-50%, -50%) scale(1.1);
        }

        .play-overlay svg {
          filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.3));
        }

        /* Transcript */
        .transcript-section {
          margin-top: 24px;
        }

        .transcript-toggle {
          padding: 12px 24px;
          background: white;
          border: 2px solid var(--gray-200);
          border-radius: 8px;
          font-weight: 600;
          color: var(--gray-700);
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .transcript-toggle:hover {
          border-color: var(--primary);
          color: var(--primary);
        }

        .transcript-content {
          margin-top: 16px;
          padding: 20px;
          background: white;
          border-radius: 8px;
          border: 1px solid var(--gray-200);
        }

        .transcript-content p {
          font-size: 0.9375rem;
          line-height: 1.8;
          color: var(--gray-700);
        }

        /* CTA */
        .video-cta {
          text-align: center;
          margin-top: 40px;
        }

        .layout-split .video-cta {
          text-align: left;
        }

        .btn-primary {
          display: inline-block;
          padding: 16px 32px;
          background: var(--primary);
          color: white;
          font-weight: 600;
          border-radius: 8px;
          text-decoration: none;
          transition: all 0.2s ease;
        }

        .btn-primary:hover {
          background: var(--primary-dark);
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        /* Responsive */
        @media (max-width: 1024px) {
          .layout-split .video-container {
            grid-template-columns: 1fr;
            gap: 40px;
          }

          .layout-split .video-header {
            text-align: center;
          }

          .layout-split .video-cta {
            text-align: center;
          }
        }

        @media (max-width: 768px) {
          .video-showcase {
            padding: 60px 16px;
          }

          .video-header h2 {
            font-size: 2rem;
          }

          .subtitle {
            font-size: 1.125rem;
          }

          .video-header {
            margin-bottom: 32px;
          }

          .play-overlay svg {
            width: 60px;
            height: 60px;
          }

          .transcript-toggle {
            width: 100%;
            padding: 12px 16px;
          }

          .video-cta {
            margin-top: 32px;
          }

          .btn-primary {
            width: 100%;
            padding: 14px 24px;
          }
        }
      `}</style>
    </div>
  );
}
