-- ============================================================================
-- PASSIVE INCOME SAFEGUARDS - DATABASE SCHEMA
-- ============================================================================
-- Purpose: Track all safeguard state, approvals, rate limits, and budgets
-- Database: Supabase PostgreSQL with RLS enabled
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- 1. RATE LIMITING & ANTI-SUSPENSION
-- ============================================================================

-- Platform rate limit configuration
CREATE TABLE platform_rate_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform TEXT NOT NULL UNIQUE,
    max_uploads_per_day INTEGER NOT NULL DEFAULT 5,
    max_uploads_per_hour INTEGER NOT NULL DEFAULT 2,
    cooldown_minutes INTEGER NOT NULL DEFAULT 30,
    jitter_min_seconds INTEGER NOT NULL DEFAULT 60,
    jitter_max_seconds INTEGER NOT NULL DEFAULT 300,
    require_human_review BOOLEAN NOT NULL DEFAULT true,
    suspension_risk_level TEXT CHECK (suspension_risk_level IN ('low', 'medium', 'high', 'critical')) DEFAULT 'medium',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Default platform configurations
INSERT INTO platform_rate_limits (platform, max_uploads_per_day, max_uploads_per_hour, cooldown_minutes, suspension_risk_level, notes) VALUES
('amazon_kdp', 5, 2, 60, 'critical', 'No API - browser automation. High suspension risk. NEVER exceed limits.'),
('printify', 50, 20, 5, 'low', 'Full API support. Generous limits.'),
('etsy', 20, 5, 15, 'medium', 'API available but strict ToS enforcement.'),
('shopify', 100, 40, 2, 'low', 'Your own store - no platform risk.'),
('woocommerce', 100, 40, 2, 'low', 'Self-hosted - no platform risk.'),
('tiktok_shop', 30, 10, 10, 'medium', 'New platform, ToS evolving.'),
('gumroad', 30, 10, 10, 'low', 'Lenient ToS for digital products.'),
('redbubble', 10, 3, 30, 'high', 'No API - browser automation required.'),
('teepublic', 10, 3, 30, 'high', 'No API - browser automation required.'),
('creative_fabrica', 5, 2, 60, 'high', 'Manual upload only - very cautious.'),
('lulu', 20, 8, 15, 'low', 'API available. Professional platform.');

-- Upload tracking for rate limiting
CREATE TABLE upload_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform TEXT NOT NULL REFERENCES platform_rate_limits(platform),
    product_id UUID NOT NULL,
    upload_status TEXT CHECK (upload_status IN ('pending', 'in_progress', 'success', 'failed', 'rate_limited', 'suspended')) DEFAULT 'pending',
    attempt_number INTEGER NOT NULL DEFAULT 1,
    error_message TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    next_allowed_upload_at TIMESTAMPTZ
);

-- Index for efficient rate limit queries
CREATE INDEX idx_upload_events_platform_time ON upload_events(platform, started_at DESC);

-- ============================================================================
-- 2. AI QUALITY GATES
-- ============================================================================

-- Quality gate configuration per product type
CREATE TABLE quality_gate_configs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_type TEXT NOT NULL UNIQUE,
    min_resolution_width INTEGER NOT NULL DEFAULT 300,
    min_resolution_height INTEGER NOT NULL DEFAULT 300,
    min_quality_score DECIMAL(3,2) NOT NULL DEFAULT 0.70,
    banned_style_keywords TEXT[] DEFAULT ARRAY[]::TEXT[],
    required_style_keywords TEXT[] DEFAULT ARRAY[]::TEXT[],
    niche_consistency_threshold DECIMAL(3,2) NOT NULL DEFAULT 0.75,
    max_similarity_to_existing DECIMAL(3,2) NOT NULL DEFAULT 0.85,
    require_unique_composition BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Default quality configurations
INSERT INTO quality_gate_configs (product_type, min_resolution_width, min_resolution_height, min_quality_score, banned_style_keywords) VALUES
('coloring_book', 2400, 3000, 0.75, ARRAY['blurry', 'low-res', 'watermark', 'text-heavy']),
('journal', 2400, 3000, 0.70, ARRAY['blurry', 'copyrighted', 'brand-logo']),
('planner', 2400, 3000, 0.70, ARRAY['blurry', 'copyrighted']),
('tshirt', 4500, 5400, 0.80, ARRAY['blurry', 'pixelated', 'trademark', 'celebrity']),
('mug', 2000, 2000, 0.75, ARRAY['blurry', 'trademark']),
('sticker', 1500, 1500, 0.80, ARRAY['blurry', 'trademark', 'copyrighted-character']),
('digital_planner', 2400, 3000, 0.70, ARRAY['blurry']);

-- Quality assessment results per product
CREATE TABLE quality_assessments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID NOT NULL,
    assessment_type TEXT NOT NULL CHECK (assessment_type IN ('image', 'copy', 'overall')),
    quality_score DECIMAL(3,2) NOT NULL,
    style_consistency_score DECIMAL(3,2),
    niche_relevance_score DECIMAL(3,2),
    originality_score DECIMAL(3,2),
    composition_score DECIMAL(3,2),
    issues_detected JSONB DEFAULT '[]'::JSONB,
    passed BOOLEAN NOT NULL DEFAULT false,
    assessed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assessor TEXT NOT NULL DEFAULT 'ai' CHECK (assessor IN ('ai', 'human'))
);

-- Style embeddings for consistency checking
CREATE TABLE style_embeddings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    niche TEXT NOT NULL,
    style_name TEXT NOT NULL,
    embedding VECTOR(1536), -- OpenAI embedding dimension
    reference_image_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(niche, style_name)
);

-- ============================================================================
-- 3. TRADEMARK SCREENING (TESS Integration)
-- ============================================================================

-- Trademark check results cache
CREATE TABLE trademark_checks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    search_term TEXT NOT NULL,
    search_type TEXT NOT NULL CHECK (search_type IN ('word_mark', 'design_mark', 'combined')),
    tess_results JSONB DEFAULT '[]'::JSONB,
    risk_level TEXT CHECK (risk_level IN ('clear', 'caution', 'blocked')) NOT NULL DEFAULT 'clear',
    matching_marks JSONB DEFAULT '[]'::JSONB,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '30 days'),
    notes TEXT
);

-- Index for efficient trademark lookups
CREATE INDEX idx_trademark_checks_term ON trademark_checks(search_term, search_type);
CREATE INDEX idx_trademark_checks_expiry ON trademark_checks(expires_at);

-- Known blocked terms (instant rejection)
CREATE TABLE blocked_terms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    term TEXT NOT NULL UNIQUE,
    reason TEXT NOT NULL,
    category TEXT CHECK (category IN ('trademark', 'copyright', 'celebrity', 'brand', 'offensive')) NOT NULL,
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    added_by TEXT
);

-- Common blocked terms
INSERT INTO blocked_terms (term, reason, category) VALUES
('disney', 'Major trademark holder - aggressive enforcement', 'trademark'),
('marvel', 'Disney subsidiary - aggressive enforcement', 'trademark'),
('star wars', 'Lucasfilm/Disney trademark', 'trademark'),
('pokemon', 'Nintendo trademark - aggressive enforcement', 'trademark'),
('nike', 'Major trademark - aggressive enforcement', 'trademark'),
('coca-cola', 'Major trademark', 'trademark'),
('supreme', 'Fashion trademark - litigious', 'trademark'),
('louis vuitton', 'Luxury brand trademark', 'trademark'),
('gucci', 'Luxury brand trademark', 'trademark'),
('taylor swift', 'Celebrity name rights', 'celebrity'),
('beyonce', 'Celebrity name rights', 'celebrity'),
('mickey mouse', 'Disney character (still protected elements)', 'copyright'),
('hello kitty', 'Sanrio trademark', 'trademark'),
('peppa pig', 'Entertainment One trademark', 'trademark'),
('paw patrol', 'Spin Master trademark', 'trademark');

-- ============================================================================
-- 4. API QUEUE WITH BACKOFF
-- ============================================================================

-- API request queue
CREATE TABLE api_queue (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    api_name TEXT NOT NULL,
    endpoint TEXT NOT NULL,
    method TEXT NOT NULL DEFAULT 'POST',
    payload JSONB NOT NULL,
    priority INTEGER NOT NULL DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
    status TEXT CHECK (status IN ('queued', 'processing', 'completed', 'failed', 'rate_limited', 'dead_letter')) DEFAULT 'queued',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 5,
    last_error TEXT,
    backoff_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed_at TIMESTAMPTZ,
    response JSONB
);

-- Index for queue processing
CREATE INDEX idx_api_queue_status_priority ON api_queue(status, priority DESC, created_at ASC)
WHERE status IN ('queued', 'rate_limited');

-- API rate limit tracking per service
CREATE TABLE api_rate_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    api_name TEXT NOT NULL UNIQUE,
    requests_per_minute INTEGER NOT NULL DEFAULT 60,
    requests_per_hour INTEGER NOT NULL DEFAULT 1000,
    requests_per_day INTEGER NOT NULL DEFAULT 10000,
    current_minute_count INTEGER NOT NULL DEFAULT 0,
    current_hour_count INTEGER NOT NULL DEFAULT 0,
    current_day_count INTEGER NOT NULL DEFAULT 0,
    minute_reset_at TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '1 minute',
    hour_reset_at TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '1 hour',
    day_reset_at TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '1 day',
    backoff_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.5,
    max_backoff_seconds INTEGER NOT NULL DEFAULT 3600,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Default API rate limits
INSERT INTO api_rate_limits (api_name, requests_per_minute, requests_per_hour, requests_per_day) VALUES
('openai', 60, 3500, 10000),
('anthropic', 60, 1000, 10000),
('replicate', 30, 500, 5000),
('printify', 120, 3600, 50000),
('shopify', 40, 2000, 40000),
('etsy', 20, 500, 5000),
('tiktok_shop', 30, 1000, 10000),
('gumroad', 60, 1000, 10000);

-- ============================================================================
-- 5. PROVIDER FAILOVER
-- ============================================================================

-- Provider health status
CREATE TABLE provider_health (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_type TEXT NOT NULL CHECK (provider_type IN ('pod_fulfillment', 'ai_generation', 'storage', 'payment')),
    provider_name TEXT NOT NULL,
    is_primary BOOLEAN NOT NULL DEFAULT false,
    is_available BOOLEAN NOT NULL DEFAULT true,
    health_score DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    last_check_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_failure_at TIMESTAMPTZ,
    failure_count_24h INTEGER NOT NULL DEFAULT 0,
    avg_response_time_ms INTEGER,
    capabilities JSONB DEFAULT '{}'::JSONB,
    priority_order INTEGER NOT NULL DEFAULT 1,
    UNIQUE(provider_type, provider_name)
);

-- POD provider configurations
INSERT INTO provider_health (provider_type, provider_name, is_primary, priority_order, capabilities) VALUES
-- Printify print providers
('pod_fulfillment', 'monster_digital', true, 1, '{"products": ["tshirts", "hoodies"], "shipping": ["US", "EU", "UK"]}'),
('pod_fulfillment', 'printful', false, 2, '{"products": ["tshirts", "hoodies", "mugs"], "shipping": ["US", "EU", "UK", "AU"]}'),
('pod_fulfillment', 'gooten', false, 3, '{"products": ["tshirts", "mugs", "posters"], "shipping": ["US", "EU"]}'),
('pod_fulfillment', 'scalable_press', false, 4, '{"products": ["tshirts", "hoodies"], "shipping": ["US"]}'),
-- AI generation providers
('ai_generation', 'replicate_flux', true, 1, '{"models": ["flux-schnell", "flux-dev"]}'),
('ai_generation', 'openai_dalle', false, 2, '{"models": ["dall-e-3"]}'),
('ai_generation', 'stability_ai', false, 3, '{"models": ["sdxl", "sd3"]}'),
('ai_generation', 'midjourney', false, 4, '{"models": ["v6"]}');

-- Failover events log
CREATE TABLE failover_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider_type TEXT NOT NULL,
    from_provider TEXT NOT NULL,
    to_provider TEXT NOT NULL,
    reason TEXT NOT NULL,
    triggered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    auto_resolved BOOLEAN DEFAULT false
);

-- ============================================================================
-- 6. TAX COMPLIANCE
-- ============================================================================

-- Tax configuration per region
CREATE TABLE tax_configurations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    region_code TEXT NOT NULL UNIQUE,
    region_name TEXT NOT NULL,
    tax_type TEXT NOT NULL CHECK (tax_type IN ('sales_tax', 'vat', 'gst', 'none')),
    default_rate DECIMAL(5,4) NOT NULL DEFAULT 0.0000,
    requires_registration BOOLEAN NOT NULL DEFAULT false,
    registration_threshold_usd DECIMAL(10,2),
    tax_provider TEXT CHECK (tax_provider IN ('shopify_tax', 'taxjar', 'avalara', 'manual')) DEFAULT 'shopify_tax',
    notes TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- US Sales Tax Nexus States
INSERT INTO tax_configurations (region_code, region_name, tax_type, default_rate, requires_registration, registration_threshold_usd, notes) VALUES
('US-CA', 'California', 'sales_tax', 0.0725, true, 500000.00, 'Economic nexus threshold $500k'),
('US-TX', 'Texas', 'sales_tax', 0.0625, true, 500000.00, 'Economic nexus threshold $500k'),
('US-NY', 'New York', 'sales_tax', 0.0800, true, 500000.00, 'Complex local rates'),
('US-FL', 'Florida', 'sales_tax', 0.0600, true, 100000.00, 'Lower threshold'),
('US-WA', 'Washington', 'sales_tax', 0.0650, true, 100000.00, 'No income tax state'),
-- EU VAT
('EU-DE', 'Germany', 'vat', 0.1900, true, 10000.00, 'EU OSS threshold €10k'),
('EU-FR', 'France', 'vat', 0.2000, true, 10000.00, 'EU OSS threshold €10k'),
('EU-UK', 'United Kingdom', 'vat', 0.2000, true, 85000.00, 'Post-Brexit, GBP threshold'),
('EU-NL', 'Netherlands', 'vat', 0.2100, true, 10000.00, 'EU OSS threshold €10k'),
-- Other
('AU', 'Australia', 'gst', 0.1000, true, 75000.00, 'AUD threshold'),
('CA', 'Canada', 'gst', 0.0500, true, 30000.00, 'CAD threshold, provincial varies');

-- Tax transaction log
CREATE TABLE tax_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id TEXT NOT NULL,
    platform TEXT NOT NULL,
    customer_region TEXT NOT NULL,
    subtotal_usd DECIMAL(10,2) NOT NULL,
    tax_amount_usd DECIMAL(10,2) NOT NULL,
    tax_rate DECIMAL(5,4) NOT NULL,
    tax_provider TEXT NOT NULL,
    tax_provider_transaction_id TEXT,
    calculated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================================
-- 7. HUMAN-IN-THE-LOOP APPROVAL
-- ============================================================================

-- Product approval queue
CREATE TABLE approval_queue (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID NOT NULL UNIQUE,
    product_type TEXT NOT NULL,
    product_data JSONB NOT NULL,
    preview_urls JSONB DEFAULT '[]'::JSONB,
    quality_assessment_id UUID REFERENCES quality_assessments(id),
    trademark_check_id UUID REFERENCES trademark_checks(id),
    status TEXT CHECK (status IN ('pending', 'approved', 'rejected', 'revision_requested')) DEFAULT 'pending',
    priority INTEGER NOT NULL DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
    reviewer_id TEXT,
    reviewer_notes TEXT,
    rejection_reason TEXT,
    auto_approve_eligible BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reviewed_at TIMESTAMPTZ,
    target_platforms TEXT[] DEFAULT ARRAY[]::TEXT[]
);

-- Index for pending reviews
CREATE INDEX idx_approval_queue_pending ON approval_queue(status, priority DESC, created_at ASC)
WHERE status = 'pending';

-- Approval settings
CREATE TABLE approval_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    setting_key TEXT NOT NULL UNIQUE,
    setting_value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Default approval settings
INSERT INTO approval_settings (setting_key, setting_value) VALUES
('human_review_threshold', '{"min_products_before_auto": 50, "quality_score_for_auto": 0.85, "enabled": true}'::JSONB),
('auto_approve_rules', '{"platforms": ["shopify", "woocommerce"], "product_types": [], "max_daily_auto": 10}'::JSONB),
('notification_channels', '{"slack_webhook": "", "email": "", "discord_webhook": ""}'::JSONB);

-- Approval statistics (for determining when to enable auto-approve)
CREATE TABLE approval_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    stat_date DATE NOT NULL DEFAULT CURRENT_DATE,
    total_submitted INTEGER NOT NULL DEFAULT 0,
    total_approved INTEGER NOT NULL DEFAULT 0,
    total_rejected INTEGER NOT NULL DEFAULT 0,
    total_revision_requested INTEGER NOT NULL DEFAULT 0,
    avg_quality_score_approved DECIMAL(3,2),
    avg_quality_score_rejected DECIMAL(3,2),
    reviewer_id TEXT,
    UNIQUE(stat_date, reviewer_id)
);

-- ============================================================================
-- 8. BUDGET CIRCUIT BREAKERS
-- ============================================================================

-- Budget configuration
CREATE TABLE budget_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    budget_type TEXT NOT NULL UNIQUE CHECK (budget_type IN ('daily', 'weekly', 'monthly', 'per_product')),
    limit_usd DECIMAL(10,2) NOT NULL,
    warning_threshold_percent INTEGER NOT NULL DEFAULT 80,
    hard_stop_enabled BOOLEAN NOT NULL DEFAULT true,
    notification_channels JSONB DEFAULT '[]'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Default budget limits
INSERT INTO budget_config (budget_type, limit_usd, warning_threshold_percent) VALUES
('daily', 25.00, 80),
('weekly', 150.00, 80),
('monthly', 500.00, 75),
('per_product', 0.50, 90);

-- Cost tracking per API/service
CREATE TABLE cost_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service_name TEXT NOT NULL,
    operation TEXT NOT NULL,
    cost_usd DECIMAL(10,6) NOT NULL,
    units_consumed INTEGER NOT NULL DEFAULT 1,
    product_id UUID,
    workflow_run_id TEXT,
    metadata JSONB DEFAULT '{}'::JSONB,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for budget queries
CREATE INDEX idx_cost_events_time ON cost_events(recorded_at DESC);
CREATE INDEX idx_cost_events_service ON cost_events(service_name, recorded_at DESC);

-- Budget alerts log
CREATE TABLE budget_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alert_type TEXT NOT NULL CHECK (alert_type IN ('warning', 'critical', 'circuit_breaker_triggered')),
    budget_type TEXT NOT NULL,
    current_spend_usd DECIMAL(10,2) NOT NULL,
    limit_usd DECIMAL(10,2) NOT NULL,
    percent_used INTEGER NOT NULL,
    message TEXT NOT NULL,
    notified_channels TEXT[] DEFAULT ARRAY[]::TEXT[],
    triggered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    resolved_by TEXT
);

-- Circuit breaker state
CREATE TABLE circuit_breaker_state (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    breaker_name TEXT NOT NULL UNIQUE,
    is_open BOOLEAN NOT NULL DEFAULT false,
    opened_at TIMESTAMPTZ,
    opened_reason TEXT,
    will_retry_at TIMESTAMPTZ,
    consecutive_failures INTEGER NOT NULL DEFAULT 0,
    last_failure_at TIMESTAMPTZ,
    last_success_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Default circuit breakers
INSERT INTO circuit_breaker_state (breaker_name) VALUES
('budget_daily'),
('budget_weekly'),
('budget_monthly'),
('api_openai'),
('api_printify'),
('api_etsy'),
('kdp_automation'),
('workflow_main');

-- ============================================================================
-- PRODUCTS TABLE (Central Product Registry)
-- ============================================================================

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_type TEXT NOT NULL,
    niche TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    keywords TEXT[] DEFAULT ARRAY[]::TEXT[],
    assets JSONB DEFAULT '{}'::JSONB,
    generation_cost_usd DECIMAL(10,4) NOT NULL DEFAULT 0,
    status TEXT CHECK (status IN ('generating', 'quality_check', 'trademark_check', 'pending_approval', 'approved', 'publishing', 'published', 'rejected', 'failed')) DEFAULT 'generating',
    quality_score DECIMAL(3,2),
    trademark_status TEXT CHECK (trademark_status IN ('pending', 'clear', 'caution', 'blocked')) DEFAULT 'pending',
    published_platforms JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for product queries
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_products_niche ON products(niche);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================================

ALTER TABLE platform_rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE upload_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE quality_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE trademark_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Service role has full access (for n8n/backend)
CREATE POLICY "Service role full access" ON platform_rate_limits FOR ALL USING (true);
CREATE POLICY "Service role full access" ON upload_events FOR ALL USING (true);
CREATE POLICY "Service role full access" ON quality_assessments FOR ALL USING (true);
CREATE POLICY "Service role full access" ON trademark_checks FOR ALL USING (true);
CREATE POLICY "Service role full access" ON approval_queue FOR ALL USING (true);
CREATE POLICY "Service role full access" ON cost_events FOR ALL USING (true);
CREATE POLICY "Service role full access" ON products FOR ALL USING (true);

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to check if upload is allowed (rate limiting)
CREATE OR REPLACE FUNCTION check_upload_allowed(p_platform TEXT)
RETURNS TABLE (
    allowed BOOLEAN,
    reason TEXT,
    next_allowed_at TIMESTAMPTZ,
    current_hour_count INTEGER,
    current_day_count INTEGER
) AS $$
DECLARE
    v_config platform_rate_limits%ROWTYPE;
    v_hour_count INTEGER;
    v_day_count INTEGER;
BEGIN
    -- Get platform config
    SELECT * INTO v_config FROM platform_rate_limits WHERE platform = p_platform;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT false, 'Platform not configured', NULL::TIMESTAMPTZ, 0, 0;
        RETURN;
    END IF;
    
    -- Count uploads in last hour
    SELECT COUNT(*) INTO v_hour_count
    FROM upload_events
    WHERE platform = p_platform
      AND started_at > NOW() - INTERVAL '1 hour'
      AND upload_status NOT IN ('failed', 'rate_limited');
    
    -- Count uploads in last day
    SELECT COUNT(*) INTO v_day_count
    FROM upload_events
    WHERE platform = p_platform
      AND started_at > NOW() - INTERVAL '1 day'
      AND upload_status NOT IN ('failed', 'rate_limited');
    
    -- Check limits
    IF v_hour_count >= v_config.max_uploads_per_hour THEN
        RETURN QUERY SELECT 
            false, 
            'Hourly limit reached (' || v_config.max_uploads_per_hour || ')',
            NOW() + INTERVAL '1 hour',
            v_hour_count,
            v_day_count;
        RETURN;
    END IF;
    
    IF v_day_count >= v_config.max_uploads_per_day THEN
        RETURN QUERY SELECT 
            false, 
            'Daily limit reached (' || v_config.max_uploads_per_day || ')',
            (CURRENT_DATE + INTERVAL '1 day')::TIMESTAMPTZ,
            v_hour_count,
            v_day_count;
        RETURN;
    END IF;
    
    -- Allowed
    RETURN QUERY SELECT true, 'OK', NULL::TIMESTAMPTZ, v_hour_count, v_day_count;
END;
$$ LANGUAGE plpgsql;

-- Function to get current budget status
CREATE OR REPLACE FUNCTION get_budget_status(p_budget_type TEXT)
RETURNS TABLE (
    current_spend DECIMAL(10,2),
    limit_amount DECIMAL(10,2),
    percent_used INTEGER,
    is_warning BOOLEAN,
    is_exceeded BOOLEAN
) AS $$
DECLARE
    v_config budget_config%ROWTYPE;
    v_spend DECIMAL(10,2);
    v_interval INTERVAL;
BEGIN
    SELECT * INTO v_config FROM budget_config WHERE budget_type = p_budget_type;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT 0::DECIMAL, 0::DECIMAL, 0, false, false;
        RETURN;
    END IF;
    
    -- Determine time interval
    v_interval := CASE p_budget_type
        WHEN 'daily' THEN INTERVAL '1 day'
        WHEN 'weekly' THEN INTERVAL '7 days'
        WHEN 'monthly' THEN INTERVAL '30 days'
        ELSE INTERVAL '1 day'
    END;
    
    -- Sum costs in period
    SELECT COALESCE(SUM(cost_usd), 0) INTO v_spend
    FROM cost_events
    WHERE recorded_at > NOW() - v_interval;
    
    RETURN QUERY SELECT 
        v_spend,
        v_config.limit_usd,
        (v_spend / v_config.limit_usd * 100)::INTEGER,
        (v_spend / v_config.limit_usd * 100) >= v_config.warning_threshold_percent,
        v_spend >= v_config.limit_usd;
END;
$$ LANGUAGE plpgsql;

-- Function to check if human review is still required
CREATE OR REPLACE FUNCTION is_human_review_required()
RETURNS BOOLEAN AS $$
DECLARE
    v_settings JSONB;
    v_approved_count INTEGER;
BEGIN
    SELECT setting_value INTO v_settings
    FROM approval_settings
    WHERE setting_key = 'human_review_threshold';
    
    IF NOT (v_settings->>'enabled')::BOOLEAN THEN
        RETURN false;
    END IF;
    
    SELECT COUNT(*) INTO v_approved_count
    FROM approval_queue
    WHERE status = 'approved';
    
    RETURN v_approved_count < (v_settings->>'min_products_before_auto')::INTEGER;
END;
$$ LANGUAGE plpgsql;
