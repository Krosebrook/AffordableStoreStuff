/**
 * Printify API Connector
 * Production-ready integration for Print-on-Demand automation
 * 
 * @see https://developers.printify.com/
 */

import { createClient } from '@supabase/supabase-js';

// Types
interface PrintifyProduct {
  id?: string;
  title: string;
  description: string;
  blueprint_id: number;
  print_provider_id: number;
  variants: PrintifyVariant[];
  print_areas: PrintifyPrintArea[];
  tags?: string[];
}

interface PrintifyVariant {
  id: number;
  price: number;
  is_enabled: boolean;
}

interface PrintifyPrintArea {
  variant_ids: number[];
  placeholders: PrintifyPlaceholder[];
}

interface PrintifyPlaceholder {
  position: string;
  images: PrintifyImage[];
}

interface PrintifyImage {
  id: string;
  x: number;
  y: number;
  scale: number;
  angle: number;
}

interface PrintifyShop {
  id: number;
  title: string;
  sales_channel: string;
}

interface PrintifyBlueprint {
  id: number;
  title: string;
  brand: string;
  model: string;
  images: string[];
}

interface PrintifyUploadResult {
  id: string;
  file_name: string;
  height: number;
  width: number;
  size: number;
  mime_type: string;
  preview_url: string;
  upload_time: string;
}

// Blueprint mapping for common product types
export const BLUEPRINT_MAP: Record<string, { id: number; provider: number; name: string }> = {
  'pod_tshirt': { id: 145, provider: 99, name: 'Bella Canvas 3001' },
  'pod_tshirt_premium': { id: 6, provider: 99, name: 'Gildan 64000' },
  'pod_mug': { id: 68, provider: 28, name: '11oz Ceramic Mug' },
  'pod_mug_15oz': { id: 69, provider: 28, name: '15oz Ceramic Mug' },
  'pod_poster': { id: 1, provider: 28, name: 'Enhanced Matte Poster' },
  'pod_canvas': { id: 3, provider: 28, name: 'Canvas Print' },
  'pod_tote': { id: 83, provider: 28, name: 'AOP Tote Bag' },
  'pod_hoodie': { id: 77, provider: 99, name: 'Gildan 18500 Hoodie' },
  'pod_sweatshirt': { id: 78, provider: 99, name: 'Gildan 18000 Sweatshirt' },
  'pod_phonecase': { id: 26, provider: 28, name: 'iPhone Snap Case' },
  'pod_mousepad': { id: 279, provider: 28, name: 'Rectangle Mouse Pad' },
  'pod_pillow': { id: 81, provider: 28, name: 'Spun Polyester Pillow' },
  'pod_sticker': { id: 505, provider: 28, name: 'Kiss-Cut Stickers' },
};

// Pricing tiers (markup over base cost)
export const PRICING_TIERS = {
  economy: { markup: 5, description: 'Competitive pricing for volume' },
  standard: { markup: 8, description: 'Balanced profit margin' },
  premium: { markup: 12, description: 'Higher margin for quality niches' },
};

export class PrintifyConnector {
  private apiKey: string;
  private shopId: string;
  private baseUrl = 'https://api.printify.com/v1';
  private supabase: ReturnType<typeof createClient>;
  
  // Rate limiting
  private requestCount = 0;
  private requestWindowStart = Date.now();
  private readonly MAX_REQUESTS_PER_MINUTE = 60;
  
  constructor(config: { apiKey: string; shopId: string; supabaseUrl: string; supabaseKey: string }) {
    if (!config.apiKey) throw new Error('Printify API key required');
    if (!config.shopId) throw new Error('Printify Shop ID required');
    
    this.apiKey = config.apiKey;
    this.shopId = config.shopId;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
  }
  
  /**
   * Rate-limited API request
   */
  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    // Rate limiting check
    const now = Date.now();
    if (now - this.requestWindowStart > 60000) {
      this.requestCount = 0;
      this.requestWindowStart = now;
    }
    
    if (this.requestCount >= this.MAX_REQUESTS_PER_MINUTE) {
      const waitTime = 60000 - (now - this.requestWindowStart);
      console.log(`Rate limit approaching, waiting ${waitTime}ms`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
      this.requestCount = 0;
      this.requestWindowStart = Date.now();
    }
    
    this.requestCount++;
    
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Printify API error ${response.status}: ${error}`);
    }
    
    return response.json();
  }
  
  /**
   * Get all shops for this account
   */
  async getShops(): Promise<PrintifyShop[]> {
    return this.request<PrintifyShop[]>('/shops.json');
  }
  
  /**
   * Get available blueprints (product templates)
   */
  async getBlueprints(): Promise<PrintifyBlueprint[]> {
    return this.request<PrintifyBlueprint[]>('/catalog/blueprints.json');
  }
  
  /**
   * Get print providers for a blueprint
   */
  async getPrintProviders(blueprintId: number): Promise<any[]> {
    return this.request<any[]>(`/catalog/blueprints/${blueprintId}/print_providers.json`);
  }
  
  /**
   * Get variants for a blueprint/provider combination
   */
  async getVariants(blueprintId: number, providerId: number): Promise<any> {
    return this.request<any>(
      `/catalog/blueprints/${blueprintId}/print_providers/${providerId}/variants.json`
    );
  }
  
  /**
   * Upload an image to Printify
   */
  async uploadImage(imageUrl: string, fileName: string): Promise<PrintifyUploadResult> {
    const response = await this.request<PrintifyUploadResult>(
      `/uploads/images.json`,
      {
        method: 'POST',
        body: JSON.stringify({
          file_name: fileName,
          url: imageUrl,
        }),
      }
    );
    
    // Log to database
    await this.logActivity('image_upload', {
      fileName,
      imageId: response.id,
      size: response.size,
    });
    
    return response;
  }
  
  /**
   * Create a product in Printify
   */
  async createProduct(config: {
    title: string;
    description: string;
    productType: string;
    imageId: string;
    tags?: string[];
    pricingTier?: keyof typeof PRICING_TIERS;
    variants?: number[]; // Specific variant IDs to enable
  }): Promise<{ id: string; external_id: string }> {
    const blueprint = BLUEPRINT_MAP[config.productType];
    if (!blueprint) {
      throw new Error(`Unknown product type: ${config.productType}`);
    }
    
    // Get available variants
    const variantData = await this.getVariants(blueprint.id, blueprint.provider);
    const allVariants = variantData.variants || [];
    
    // Calculate pricing
    const tier = PRICING_TIERS[config.pricingTier || 'standard'];
    
    // Build variants with pricing
    const enabledVariants = allVariants
      .filter((v: any) => !config.variants || config.variants.includes(v.id))
      .slice(0, 20) // Limit variants to avoid bloat
      .map((v: any) => ({
        id: v.id,
        price: Math.round((v.cost + tier.markup) * 100), // Price in cents
        is_enabled: true,
      }));
    
    if (enabledVariants.length === 0) {
      throw new Error('No valid variants found for product');
    }
    
    // Build print areas
    const printAreas = [{
      variant_ids: enabledVariants.map((v: any) => v.id),
      placeholders: [{
        position: 'front',
        images: [{
          id: config.imageId,
          x: 0.5,
          y: 0.5,
          scale: 1,
          angle: 0,
        }],
      }],
    }];
    
    const product: PrintifyProduct = {
      title: config.title.substring(0, 140),
      description: config.description,
      blueprint_id: blueprint.id,
      print_provider_id: blueprint.provider,
      variants: enabledVariants,
      print_areas: printAreas,
      tags: config.tags?.slice(0, 13),
    };
    
    const result = await this.request<{ id: string; external_id: string }>(
      `/shops/${this.shopId}/products.json`,
      {
        method: 'POST',
        body: JSON.stringify(product),
      }
    );
    
    // Log to database
    await this.logActivity('product_create', {
      productId: result.id,
      title: config.title,
      productType: config.productType,
      variantCount: enabledVariants.length,
    });
    
    return result;
  }
  
  /**
   * Publish a product to connected sales channel
   */
  async publishProduct(productId: string, options?: {
    title?: boolean;
    description?: boolean;
    images?: boolean;
    variants?: boolean;
    tags?: boolean;
  }): Promise<void> {
    const publishOptions = {
      title: options?.title ?? true,
      description: options?.description ?? true,
      images: options?.images ?? true,
      variants: options?.variants ?? true,
      tags: options?.tags ?? true,
    };
    
    await this.request(
      `/shops/${this.shopId}/products/${productId}/publish.json`,
      {
        method: 'POST',
        body: JSON.stringify(publishOptions),
      }
    );
    
    await this.logActivity('product_publish', { productId });
  }
  
  /**
   * Get product details
   */
  async getProduct(productId: string): Promise<any> {
    return this.request<any>(`/shops/${this.shopId}/products/${productId}.json`);
  }
  
  /**
   * List all products in shop
   */
  async listProducts(page = 1, limit = 100): Promise<{ current_page: number; data: any[] }> {
    return this.request<{ current_page: number; data: any[] }>(
      `/shops/${this.shopId}/products.json?page=${page}&limit=${limit}`
    );
  }
  
  /**
   * Delete a product
   */
  async deleteProduct(productId: string): Promise<void> {
    await this.request(
      `/shops/${this.shopId}/products/${productId}.json`,
      { method: 'DELETE' }
    );
    
    await this.logActivity('product_delete', { productId });
  }
  
  /**
   * Get orders from Printify
   */
  async getOrders(page = 1, limit = 100): Promise<{ current_page: number; data: any[] }> {
    return this.request<{ current_page: number; data: any[] }>(
      `/shops/${this.shopId}/orders.json?page=${page}&limit=${limit}`
    );
  }
  
  /**
   * Get order details
   */
  async getOrder(orderId: string): Promise<any> {
    return this.request<any>(`/shops/${this.shopId}/orders/${orderId}.json`);
  }
  
  /**
   * Calculate shipping cost for an order
   */
  async calculateShipping(lineItems: { product_id: string; variant_id: number; quantity: number }[], address: {
    country: string;
    region?: string;
    zip?: string;
  }): Promise<{ standard: number; express?: number }> {
    return this.request<{ standard: number; express?: number }>(
      `/shops/${this.shopId}/orders/shipping.json`,
      {
        method: 'POST',
        body: JSON.stringify({
          line_items: lineItems,
          address_to: address,
        }),
      }
    );
  }
  
  /**
   * Complete flow: Upload image → Create product → Publish
   */
  async createAndPublishProduct(config: {
    title: string;
    description: string;
    productType: string;
    imageUrl: string;
    tags?: string[];
    pricingTier?: keyof typeof PRICING_TIERS;
    autoPublish?: boolean;
  }): Promise<{
    imageId: string;
    productId: string;
    published: boolean;
  }> {
    // Step 1: Upload image
    const fileName = `${config.productType}_${Date.now()}.png`;
    const uploadResult = await this.uploadImage(config.imageUrl, fileName);
    
    // Step 2: Create product
    const product = await this.createProduct({
      title: config.title,
      description: config.description,
      productType: config.productType,
      imageId: uploadResult.id,
      tags: config.tags,
      pricingTier: config.pricingTier,
    });
    
    // Step 3: Publish (optional)
    let published = false;
    if (config.autoPublish !== false) {
      await this.publishProduct(product.id);
      published = true;
    }
    
    return {
      imageId: uploadResult.id,
      productId: product.id,
      published,
    };
  }
  
  /**
   * Log activity to database
   */
  private async logActivity(action: string, details: Record<string, any>): Promise<void> {
    try {
      await this.supabase.from('platform_activity_log').insert({
        platform: 'printify',
        action,
        details,
        created_at: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
  
  /**
   * Health check
   */
  async healthCheck(): Promise<{ healthy: boolean; shopId: string; productCount: number }> {
    try {
      const shops = await this.getShops();
      const shop = shops.find(s => s.id.toString() === this.shopId);
      
      if (!shop) {
        return { healthy: false, shopId: this.shopId, productCount: 0 };
      }
      
      const products = await this.listProducts(1, 1);
      
      return {
        healthy: true,
        shopId: this.shopId,
        productCount: products.data.length,
      };
    } catch (error) {
      return { healthy: false, shopId: this.shopId, productCount: 0 };
    }
  }
}

export default PrintifyConnector;
