/**
 * Safeguards Integration Module
 * Connects Income Engine to existing FlashFusion safeguards system
 * 
 * Integrates with:
 * - Trademark screening (USPTO TESS)
 * - Quality gates
 * - Rate limiting
 * - Budget circuit breakers
 * - Human-in-the-loop approval
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Types
export interface SafeguardCheckResult {
  passed: boolean;
  checkType: string;
  score?: number;
  message: string;
  details?: Record<string, any>;
  blockers?: string[];
}

export interface ProductValidation {
  productId: string;
  title: string;
  description: string;
  tags: string[];
  niche: string;
  imageUrl?: string;
}

export interface SafeguardConfig {
  enabled: {
    trademark: boolean;
    quality: boolean;
    rateLimit: boolean;
    budget: boolean;
    humanApproval: boolean;
  };
  thresholds: {
    qualityMinScore: number;
    autoApproveScore: number;
    dailyBudgetLimit: number;
    dailyProductLimit: number;
  };
  apiUrl?: string;
  apiKey?: string;
}

// Default configuration
const DEFAULT_CONFIG: SafeguardConfig = {
  enabled: {
    trademark: true,
    quality: true,
    rateLimit: true,
    budget: true,
    humanApproval: true,
  },
  thresholds: {
    qualityMinScore: 60,
    autoApproveScore: 80,
    dailyBudgetLimit: 5,
    dailyProductLimit: 50,
  },
};

// Trademark keywords to flag (basic list - expand as needed)
const TRADEMARK_KEYWORDS = [
  // Major brands
  'disney', 'marvel', 'nike', 'adidas', 'coca-cola', 'pepsi', 'mcdonald',
  'apple', 'google', 'amazon', 'microsoft', 'facebook', 'meta', 'netflix',
  'starbucks', 'walmart', 'target', 'costco', 'ikea',
  
  // Sports
  'nfl', 'nba', 'mlb', 'nhl', 'fifa', 'olympics', 'super bowl',
  
  // Entertainment
  'star wars', 'harry potter', 'pokemon', 'nintendo', 'playstation', 'xbox',
  'minions', 'frozen', 'pixar', 'dreamworks', 'warner bros',
  
  // Characters
  'mickey mouse', 'spongebob', 'barbie', 'hello kitty', 'sesame street',
  
  // Fashion
  'louis vuitton', 'gucci', 'prada', 'chanel', 'hermes', 'versace',
  
  // Other protected terms
  'super bowl', 'march madness', 'grammy', 'oscar', 'emmy', 'tony award',
];

// Quality issue patterns
const QUALITY_ISSUES = [
  { pattern: /(.)\1{4,}/i, issue: 'Repeated characters' },
  { pattern: /[^\x00-\x7F]/g, issue: 'Non-ASCII characters' },
  { pattern: /\b(test|sample|placeholder|lorem|ipsum)\b/i, issue: 'Placeholder text' },
  { pattern: /\b(fuck|shit|damn|ass|bitch)\b/i, issue: 'Profanity' },
  { pattern: /<[^>]*>/g, issue: 'HTML tags in content' },
];

export class SafeguardsIntegration {
  private supabase: SupabaseClient;
  private config: SafeguardConfig;
  private productsCheckedToday: number = 0;
  private lastResetDate: string = '';
  
  constructor(options: {
    supabaseUrl: string;
    supabaseKey: string;
    config?: Partial<SafeguardConfig>;
  }) {
    this.supabase = createClient(options.supabaseUrl, options.supabaseKey);
    this.config = { ...DEFAULT_CONFIG, ...options.config };
  }
  
  /**
   * Run all safeguard checks on a product
   */
  async validateProduct(product: ProductValidation): Promise<{
    approved: boolean;
    requiresHumanReview: boolean;
    overallScore: number;
    checks: SafeguardCheckResult[];
    blockers: string[];
  }> {
    const checks: SafeguardCheckResult[] = [];
    const blockers: string[] = [];
    
    // Reset daily counter if needed
    const today = new Date().toISOString().split('T')[0];
    if (this.lastResetDate !== today) {
      this.productsCheckedToday = 0;
      this.lastResetDate = today;
    }
    
    // 1. Rate Limit Check
    if (this.config.enabled.rateLimit) {
      const rateLimitResult = await this.checkRateLimit();
      checks.push(rateLimitResult);
      if (!rateLimitResult.passed) {
        blockers.push(rateLimitResult.message);
      }
    }
    
    // 2. Budget Check
    if (this.config.enabled.budget) {
      const budgetResult = await this.checkBudget();
      checks.push(budgetResult);
      if (!budgetResult.passed) {
        blockers.push(budgetResult.message);
      }
    }
    
    // 3. Trademark Check
    if (this.config.enabled.trademark) {
      const trademarkResult = this.checkTrademark(product);
      checks.push(trademarkResult);
      if (!trademarkResult.passed) {
        blockers.push(...(trademarkResult.blockers || []));
      }
    }
    
    // 4. Quality Check
    if (this.config.enabled.quality) {
      const qualityResult = this.checkQuality(product);
      checks.push(qualityResult);
      if (!qualityResult.passed) {
        blockers.push(qualityResult.message);
      }
    }
    
    // Calculate overall score
    const scoredChecks = checks.filter(c => c.score !== undefined);
    const overallScore = scoredChecks.length > 0
      ? scoredChecks.reduce((sum, c) => sum + (c.score || 0), 0) / scoredChecks.length
      : 100;
    
    // Determine approval status
    const allPassed = checks.every(c => c.passed);
    const approved = allPassed && overallScore >= this.config.thresholds.qualityMinScore;
    
    // Determine if human review needed
    const requiresHumanReview = this.config.enabled.humanApproval && 
      approved && 
      overallScore < this.config.thresholds.autoApproveScore;
    
    // Log to database
    await this.logSafeguardCheck(product.productId, checks, approved, overallScore);
    
    // Increment counter
    this.productsCheckedToday++;
    
    return {
      approved,
      requiresHumanReview,
      overallScore: Math.round(overallScore),
      checks,
      blockers,
    };
  }
  
  /**
   * Check rate limits
   */
  private async checkRateLimit(): Promise<SafeguardCheckResult> {
    const limit = this.config.thresholds.dailyProductLimit;
    
    if (this.productsCheckedToday >= limit) {
      return {
        passed: false,
        checkType: 'rate_limit',
        message: `Daily limit reached (${this.productsCheckedToday}/${limit})`,
        details: { current: this.productsCheckedToday, limit },
      };
    }
    
    return {
      passed: true,
      checkType: 'rate_limit',
      message: `Within daily limit (${this.productsCheckedToday}/${limit})`,
      details: { current: this.productsCheckedToday, limit },
    };
  }
  
  /**
   * Check budget constraints
   */
  private async checkBudget(): Promise<SafeguardCheckResult> {
    const today = new Date().toISOString().split('T')[0];
    
    try {
      const { data } = await this.supabase
        .from('ai_generation_costs')
        .select('cost_usd')
        .gte('created_at', `${today}T00:00:00Z`);
      
      const spent = data?.reduce((sum, c) => sum + (c.cost_usd || 0), 0) || 0;
      const limit = this.config.thresholds.dailyBudgetLimit;
      
      if (spent >= limit) {
        return {
          passed: false,
          checkType: 'budget',
          message: `Daily budget exhausted ($${spent.toFixed(2)}/$${limit})`,
          details: { spent, limit },
        };
      }
      
      const percentUsed = (spent / limit) * 100;
      
      return {
        passed: true,
        checkType: 'budget',
        score: 100 - percentUsed,
        message: `Budget available ($${spent.toFixed(2)}/$${limit})`,
        details: { spent, limit, percentUsed },
      };
    } catch (error) {
      return {
        passed: true, // Don't block on database errors
        checkType: 'budget',
        message: 'Could not verify budget (allowing product)',
      };
    }
  }
  
  /**
   * Check for trademark violations
   */
  private checkTrademark(product: ProductValidation): SafeguardCheckResult {
    const textToCheck = [
      product.title.toLowerCase(),
      product.description.toLowerCase(),
      ...product.tags.map(t => t.toLowerCase()),
    ].join(' ');
    
    const violations: string[] = [];
    
    for (const keyword of TRADEMARK_KEYWORDS) {
      if (textToCheck.includes(keyword.toLowerCase())) {
        violations.push(keyword);
      }
    }
    
    if (violations.length > 0) {
      return {
        passed: false,
        checkType: 'trademark',
        score: 0,
        message: `Potential trademark violation: ${violations.join(', ')}`,
        blockers: violations.map(v => `Trademark: "${v}"`),
        details: { violations },
      };
    }
    
    return {
      passed: true,
      checkType: 'trademark',
      score: 100,
      message: 'No trademark issues detected',
    };
  }
  
  /**
   * Check content quality
   */
  private checkQuality(product: ProductValidation): SafeguardCheckResult {
    const issues: string[] = [];
    let score = 100;
    
    const textToCheck = `${product.title} ${product.description}`;
    
    // Check for quality issues
    for (const { pattern, issue } of QUALITY_ISSUES) {
      if (pattern.test(textToCheck)) {
        issues.push(issue);
        score -= 20;
      }
    }
    
    // Check title length
    if (product.title.length < 20) {
      issues.push('Title too short (< 20 chars)');
      score -= 10;
    } else if (product.title.length > 140) {
      issues.push('Title too long (> 140 chars)');
      score -= 5;
    }
    
    // Check description length
    if (product.description.length < 100) {
      issues.push('Description too short (< 100 chars)');
      score -= 15;
    }
    
    // Check tag count
    if (product.tags.length < 5) {
      issues.push('Too few tags (< 5)');
      score -= 10;
    } else if (product.tags.length > 13) {
      issues.push('Too many tags (> 13, Etsy limit)');
      score -= 5;
    }
    
    // Check for duplicate tags
    const uniqueTags = new Set(product.tags.map(t => t.toLowerCase()));
    if (uniqueTags.size < product.tags.length) {
      issues.push('Duplicate tags detected');
      score -= 10;
    }
    
    score = Math.max(0, score);
    
    const passed = score >= this.config.thresholds.qualityMinScore;
    
    return {
      passed,
      checkType: 'quality',
      score,
      message: passed 
        ? `Quality score: ${score}/100`
        : `Quality score too low: ${score}/100 (min: ${this.config.thresholds.qualityMinScore})`,
      details: { issues, score },
    };
  }
  
  /**
   * Log safeguard check to database
   */
  private async logSafeguardCheck(
    productId: string,
    checks: SafeguardCheckResult[],
    approved: boolean,
    overallScore: number
  ): Promise<void> {
    try {
      // Log each check
      for (const check of checks) {
        await this.supabase.from('safeguard_checks').insert({
          product_id: productId,
          check_type: check.checkType,
          passed: check.passed,
          score: check.score,
          details: check.details,
          created_at: new Date().toISOString(),
        });
      }
      
      // Update product status
      await this.supabase
        .from('generated_products')
        .update({
          status: approved ? 'approved' : 'rejected',
          quality_score: overallScore,
          rejection_reason: approved ? null : checks
            .filter(c => !c.passed)
            .map(c => c.message)
            .join('; '),
          updated_at: new Date().toISOString(),
        })
        .eq('id', productId);
    } catch (error) {
      console.error('Failed to log safeguard check:', error);
    }
  }
  
  /**
   * Call external safeguards API (if configured)
   */
  async callExternalSafeguards(product: ProductValidation): Promise<SafeguardCheckResult | null> {
    if (!this.config.apiUrl) {
      return null;
    }
    
    try {
      const response = await fetch(`${this.config.apiUrl}/validate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`,
        },
        body: JSON.stringify(product),
      });
      
      if (!response.ok) {
        console.error('External safeguards API error:', response.status);
        return null;
      }
      
      const result = await response.json();
      
      return {
        passed: result.approved,
        checkType: 'external_api',
        score: result.score,
        message: result.message,
        details: result.details,
      };
    } catch (error) {
      console.error('Failed to call external safeguards:', error);
      return null;
    }
  }
  
  /**
   * Get configuration
   */
  getConfig(): SafeguardConfig {
    return { ...this.config };
  }
  
  /**
   * Update configuration
   */
  updateConfig(updates: Partial<SafeguardConfig>): void {
    this.config = {
      ...this.config,
      ...updates,
      enabled: { ...this.config.enabled, ...updates.enabled },
      thresholds: { ...this.config.thresholds, ...updates.thresholds },
    };
  }
  
  /**
   * Get today's stats
   */
  getStats(): {
    productsCheckedToday: number;
    dailyLimit: number;
    remainingCapacity: number;
  } {
    return {
      productsCheckedToday: this.productsCheckedToday,
      dailyLimit: this.config.thresholds.dailyProductLimit,
      remainingCapacity: Math.max(0, this.config.thresholds.dailyProductLimit - this.productsCheckedToday),
    };
  }
}

export default SafeguardsIntegration;
