/**
 * Income Engine - Main Entry Point
 * Multi-platform passive income automation system
 * 
 * @version 1.0.0
 */

import { config as dotenvConfig } from 'dotenv';
dotenvConfig();

// Re-export all modules
export * from './connectors';
export * from './generators/product-generator';
export * from './revenue/tracker';
export * from './ai-router/router';

import { PlatformManager, PlatformConfig } from './connectors';
import { ProductGenerator, ProductConfig, GeneratedProduct } from './generators/product-generator';
import { RevenueTracker, GoalProgress, CostBreakdown } from './revenue/tracker';
import { AIRouter, TaskType } from './ai-router/router';

// Types
export interface IncomeEngineConfig {
  supabase: {
    url: string;
    key: string;
  };
  platforms: {
    printify?: {
      apiKey: string;
      shopId: string;
    };
    etsy?: {
      clientId: string;
      clientSecret: string;
      redirectUri: string;
      shopId: string;
    };
    gumroad?: {
      accessToken: string;
    };
  };
  ai: {
    replicate?: string;
    openai?: string;
    anthropic?: string;
    huggingface?: string;
  };
  budget?: {
    dailyLimit?: number;
    monthlyLimit?: number;
  };
  monthlyGoal?: number;
}

export interface EngineStatus {
  healthy: boolean;
  platforms: {
    name: string;
    status: 'connected' | 'disconnected' | 'error';
    details?: any;
  }[];
  aiProviders: {
    name: string;
    available: boolean;
  }[];
  budget: {
    dailySpent: number;
    dailyRemaining: number;
    monthlySpent: number;
    monthlyRemaining: number;
  };
  goalProgress: GoalProgress;
}

/**
 * Income Engine - Main class coordinating all modules
 */
export class IncomeEngine {
  private platformManager: PlatformManager;
  private aiRouter: AIRouter;
  private productGenerator: ProductGenerator;
  private revenueTracker: RevenueTracker;
  private config: IncomeEngineConfig;
  
  constructor(config: IncomeEngineConfig) {
    this.config = config;
    
    // Validate required config
    if (!config.supabase?.url || !config.supabase?.key) {
      throw new Error('Supabase configuration required');
    }
    
    // Initialize AI Router
    this.aiRouter = new AIRouter({
      supabaseUrl: config.supabase.url,
      supabaseKey: config.supabase.key,
      providers: {
        replicate: config.ai.replicate,
        openai: config.ai.openai,
        anthropic: config.ai.anthropic,
        huggingface: config.ai.huggingface,
      },
      dailyBudget: config.budget?.dailyLimit || 5,
    });
    
    // Initialize Platform Manager
    this.platformManager = new PlatformManager({
      printify: config.platforms.printify,
      etsy: config.platforms.etsy,
      gumroad: config.platforms.gumroad,
      supabase: config.supabase,
    });
    
    // Initialize Product Generator
    this.productGenerator = new ProductGenerator({
      supabaseUrl: config.supabase.url,
      supabaseKey: config.supabase.key,
      aiRouter: this.aiRouter,
    });
    
    // Initialize Revenue Tracker
    this.revenueTracker = new RevenueTracker({
      supabaseUrl: config.supabase.url,
      supabaseKey: config.supabase.key,
      platformManager: this.platformManager,
      monthlyGoal: config.monthlyGoal || 1000,
    });
  }
  
  /**
   * Get engine status and health
   */
  async getStatus(): Promise<EngineStatus> {
    // Check platform health
    const platformHealth = await this.platformManager.healthCheckAll();
    const platforms = platformHealth.map(p => ({
      name: p.platform,
      status: p.healthy ? 'connected' as const : 'disconnected' as const,
      details: p.details,
    }));
    
    // Check AI providers
    const budgetStatus = await this.aiRouter.getBudgetStatus();
    const aiProviders = [
      { name: 'replicate', available: !!this.config.ai.replicate },
      { name: 'openai', available: !!this.config.ai.openai },
      { name: 'anthropic', available: !!this.config.ai.anthropic },
      { name: 'huggingface', available: !!this.config.ai.huggingface },
    ];
    
    // Get goal progress
    const goalProgress = await this.revenueTracker.getGoalProgress();
    
    // Get cost breakdown for budget
    const costs = await this.revenueTracker.getCostBreakdown(1); // Today
    const monthlyCosts = await this.revenueTracker.getCostBreakdown(30);
    
    const dailyLimit = this.config.budget?.dailyLimit || 5;
    const monthlyLimit = this.config.budget?.monthlyLimit || 100;
    
    return {
      healthy: platforms.some(p => p.status === 'connected') && aiProviders.some(p => p.available),
      platforms,
      aiProviders,
      budget: {
        dailySpent: budgetStatus.spent,
        dailyRemaining: budgetStatus.remaining,
        monthlySpent: monthlyCosts.total,
        monthlyRemaining: monthlyLimit - monthlyCosts.total,
      },
      goalProgress,
    };
  }
  
  /**
   * Generate a single product
   */
  async generateProduct(config: ProductConfig): Promise<GeneratedProduct> {
    return this.productGenerator.generateProduct(config);
  }
  
  /**
   * Generate batch of products
   */
  async generateBatch(
    configs: ProductConfig[],
    options?: {
      delayMs?: number;
      onProgress?: (completed: number, total: number, product?: GeneratedProduct) => void;
    }
  ) {
    return this.productGenerator.generateBatch(configs, options);
  }
  
  /**
   * Publish product to platforms
   */
  async publishProduct(product: GeneratedProduct) {
    return this.platformManager.publishProduct({
      id: product.id,
      title: product.title,
      description: product.description,
      price: product.priceRange === 'low' ? 14.99 : product.priceRange === 'high' ? 24.99 : 19.99,
      productType: product.productType,
      imageUrl: product.imageUrl,
      tags: product.tags,
      platform: product.targetPlatform as any,
      status: 'draft',
    });
  }
  
  /**
   * Get revenue report
   */
  async getRevenueReport(days: number = 30) {
    return this.revenueTracker.generateReport(days);
  }
  
  /**
   * Get goal progress
   */
  async getGoalProgress(): Promise<GoalProgress> {
    return this.revenueTracker.getGoalProgress();
  }
  
  /**
   * Get cost breakdown
   */
  async getCostBreakdown(days: number = 30): Promise<CostBreakdown> {
    return this.revenueTracker.getCostBreakdown(days);
  }
  
  /**
   * Create daily snapshot
   */
  async createDailySnapshot() {
    return this.revenueTracker.createSnapshot('daily');
  }
  
  /**
   * Get top performing products
   */
  async getTopProducts(days: number = 30, limit: number = 10) {
    return this.revenueTracker.getTopProducts(days, limit);
  }
  
  /**
   * Estimate cost for product generation
   */
  estimateCost(config: ProductConfig) {
    return this.productGenerator.estimateCost(config);
  }
  
  /**
   * Set monthly revenue goal
   */
  setGoal(amount: number) {
    this.revenueTracker.setGoal(amount);
  }
  
  /**
   * Get platform manager for direct access
   */
  getPlatformManager(): PlatformManager {
    return this.platformManager;
  }
  
  /**
   * Get AI router for direct access
   */
  getAIRouter(): AIRouter {
    return this.aiRouter;
  }
  
  /**
   * Get revenue tracker for direct access
   */
  getRevenueTracker(): RevenueTracker {
    return this.revenueTracker;
  }
}

/**
 * Create engine from environment variables
 */
export function createEngineFromEnv(): IncomeEngine {
  return new IncomeEngine({
    supabase: {
      url: process.env.SUPABASE_URL || '',
      key: process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || '',
    },
    platforms: {
      printify: process.env.PRINTIFY_API_KEY ? {
        apiKey: process.env.PRINTIFY_API_KEY,
        shopId: process.env.PRINTIFY_SHOP_ID || '',
      } : undefined,
      etsy: process.env.ETSY_CLIENT_ID ? {
        clientId: process.env.ETSY_CLIENT_ID,
        clientSecret: process.env.ETSY_CLIENT_SECRET || '',
        redirectUri: process.env.ETSY_REDIRECT_URI || '',
        shopId: process.env.ETSY_SHOP_ID || '',
      } : undefined,
      gumroad: process.env.GUMROAD_ACCESS_TOKEN ? {
        accessToken: process.env.GUMROAD_ACCESS_TOKEN,
      } : undefined,
    },
    ai: {
      replicate: process.env.REPLICATE_API_TOKEN,
      openai: process.env.OPENAI_API_KEY,
      anthropic: process.env.ANTHROPIC_API_KEY,
      huggingface: process.env.HUGGINGFACE_API_KEY,
    },
    budget: {
      dailyLimit: parseFloat(process.env.MAX_DAILY_AI_SPEND || '5'),
      monthlyLimit: parseFloat(process.env.MAX_MONTHLY_SPEND || '100'),
    },
    monthlyGoal: parseFloat(process.env.MONTHLY_REVENUE_GOAL || '1000'),
  });
}

export default IncomeEngine;
