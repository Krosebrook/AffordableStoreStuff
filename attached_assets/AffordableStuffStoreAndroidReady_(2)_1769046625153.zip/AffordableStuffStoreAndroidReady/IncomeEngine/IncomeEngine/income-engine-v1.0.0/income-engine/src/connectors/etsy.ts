/**
 * Etsy API v3 Connector
 * OAuth2 integration for marketplace automation
 * 
 * @see https://developer.etsy.com/documentation/
 */

import { createClient } from '@supabase/supabase-js';

// Types
interface EtsyListing {
  listing_id?: number;
  title: string;
  description: string;
  price: { amount: number; divisor: number; currency_code: string };
  quantity: number;
  taxonomy_id: number;
  who_made: 'i_did' | 'someone_else' | 'collective';
  when_made: string;
  is_supply: boolean;
  shipping_profile_id?: number;
  return_policy_id?: number;
  tags?: string[];
  materials?: string[];
  is_customizable?: boolean;
  is_digital?: boolean;
  should_auto_renew?: boolean;
  state?: 'draft' | 'active' | 'inactive';
}

interface EtsyShop {
  shop_id: number;
  shop_name: string;
  user_id: number;
  title: string;
  currency_code: string;
  url: string;
  listing_active_count: number;
}

interface EtsyReceipt {
  receipt_id: number;
  receipt_type: number;
  status: string;
  name: string;
  total_price: { amount: number; divisor: number; currency_code: string };
  subtotal: { amount: number; divisor: number; currency_code: string };
  grandtotal: { amount: number; divisor: number; currency_code: string };
  transactions: EtsyTransaction[];
}

interface EtsyTransaction {
  transaction_id: number;
  listing_id: number;
  title: string;
  quantity: number;
  price: { amount: number; divisor: number; currency_code: string };
}

interface TokenSet {
  access_token: string;
  refresh_token: string;
  expires_at: number;
}

// Etsy taxonomy IDs for common categories
export const TAXONOMY_MAP: Record<string, number> = {
  // Clothing & Accessories
  'pod_tshirt': 482,           // Clothing > Shirts & Tops
  'pod_hoodie': 478,           // Clothing > Hoodies & Sweatshirts
  'pod_sweatshirt': 478,
  
  // Home & Living
  'pod_mug': 1624,             // Home & Living > Kitchen & Dining > Drinkware
  'pod_pillow': 891,           // Home & Living > Home Décor > Pillows
  'pod_poster': 702,           // Art & Collectibles > Prints
  'pod_canvas': 702,
  
  // Bags & Purses
  'pod_tote': 625,             // Bags & Purses > Tote Bags
  
  // Electronics & Accessories
  'pod_phonecase': 1762,       // Electronics & Accessories > Phone Cases
  'pod_mousepad': 1764,        // Electronics & Accessories > Computer Peripherals
  
  // Craft Supplies & Digital
  'digital_printable': 69,     // Craft Supplies & Tools > Patterns
  'digital_planner': 1773,     // Paper > Calendars & Planners
  'digital_wallart': 702,      // Art & Collectibles > Prints
  'digital_template': 69,
  
  // Stickers & Paper Goods
  'pod_sticker': 2078,         // Paper & Party Supplies > Paper > Stickers
};

export class EtsyConnector {
  private clientId: string;
  private clientSecret: string;
  private redirectUri: string;
  private shopId: string;
  private tokens: TokenSet | null = null;
  private baseUrl = 'https://openapi.etsy.com/v3';
  private supabase: ReturnType<typeof createClient>;
  
  // Rate limiting (Etsy: 10 requests/second)
  private requestQueue: Array<() => Promise<any>> = [];
  private processing = false;
  
  constructor(config: {
    clientId: string;
    clientSecret: string;
    redirectUri: string;
    shopId: string;
    supabaseUrl: string;
    supabaseKey: string;
    tokens?: TokenSet;
  }) {
    if (!config.clientId) throw new Error('Etsy Client ID required');
    if (!config.clientSecret) throw new Error('Etsy Client Secret required');
    if (!config.shopId) throw new Error('Etsy Shop ID required');
    
    this.clientId = config.clientId;
    this.clientSecret = config.clientSecret;
    this.redirectUri = config.redirectUri;
    this.shopId = config.shopId;
    this.tokens = config.tokens || null;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
  }
  
  /**
   * Generate OAuth2 authorization URL
   */
  getAuthorizationUrl(state: string, scopes: string[] = [
    'listings_r', 'listings_w', 'listings_d',
    'transactions_r', 'shops_r', 'shops_w',
  ]): string {
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: this.clientId,
      redirect_uri: this.redirectUri,
      scope: scopes.join(' '),
      state,
      code_challenge_method: 'S256',
    });
    
    return `https://www.etsy.com/oauth/connect?${params.toString()}`;
  }
  
  /**
   * Exchange authorization code for tokens
   */
  async exchangeCodeForTokens(code: string, codeVerifier: string): Promise<TokenSet> {
    const response = await fetch('https://api.etsy.com/v3/public/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        client_id: this.clientId,
        redirect_uri: this.redirectUri,
        code,
        code_verifier: codeVerifier,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`Token exchange failed: ${await response.text()}`);
    }
    
    const data = await response.json();
    this.tokens = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Date.now() + (data.expires_in * 1000),
    };
    
    // Store tokens in database
    await this.storeTokens();
    
    return this.tokens;
  }
  
  /**
   * Refresh access token
   */
  async refreshTokens(): Promise<TokenSet> {
    if (!this.tokens?.refresh_token) {
      throw new Error('No refresh token available');
    }
    
    const response = await fetch('https://api.etsy.com/v3/public/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: this.clientId,
        refresh_token: this.tokens.refresh_token,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`Token refresh failed: ${await response.text()}`);
    }
    
    const data = await response.json();
    this.tokens = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Date.now() + (data.expires_in * 1000),
    };
    
    await this.storeTokens();
    
    return this.tokens;
  }
  
  /**
   * Store tokens in database
   */
  private async storeTokens(): Promise<void> {
    if (!this.tokens) return;
    
    await this.supabase.from('platform_credentials').upsert({
      platform: 'etsy',
      shop_id: this.shopId,
      credentials: {
        access_token: this.tokens.access_token,
        refresh_token: this.tokens.refresh_token,
        expires_at: this.tokens.expires_at,
      },
      updated_at: new Date().toISOString(),
    }, { onConflict: 'platform,shop_id' });
  }
  
  /**
   * Load tokens from database
   */
  async loadTokens(): Promise<boolean> {
    const { data } = await this.supabase
      .from('platform_credentials')
      .select('credentials')
      .eq('platform', 'etsy')
      .eq('shop_id', this.shopId)
      .single();
    
    if (data?.credentials) {
      this.tokens = data.credentials as TokenSet;
      return true;
    }
    return false;
  }
  
  /**
   * Ensure valid access token
   */
  private async ensureValidToken(): Promise<string> {
    if (!this.tokens) {
      const loaded = await this.loadTokens();
      if (!loaded) throw new Error('No tokens available. Please authenticate first.');
    }
    
    // Refresh if expiring in next 5 minutes
    if (this.tokens!.expires_at < Date.now() + 300000) {
      await this.refreshTokens();
    }
    
    return this.tokens!.access_token;
  }
  
  /**
   * Rate-limited API request
   */
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = await this.ensureValidToken();
    
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${token}`,
        'x-api-key': this.clientId,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });
    
    if (response.status === 429) {
      // Rate limited - wait and retry
      const retryAfter = parseInt(response.headers.get('Retry-After') || '5');
      await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
      return this.request(endpoint, options);
    }
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Etsy API error ${response.status}: ${error}`);
    }
    
    return response.json();
  }
  
  /**
   * Get shop details
   */
  async getShop(): Promise<EtsyShop> {
    return this.request<EtsyShop>(`/application/shops/${this.shopId}`);
  }
  
  /**
   * Create a draft listing
   */
  async createListing(listing: {
    title: string;
    description: string;
    price: number;
    quantity?: number;
    productType: string;
    tags?: string[];
    materials?: string[];
    isDigital?: boolean;
    isCustomizable?: boolean;
    shippingProfileId?: number;
    returnPolicyId?: number;
  }): Promise<{ listing_id: number }> {
    const taxonomyId = TAXONOMY_MAP[listing.productType] || 482;
    
    const body: EtsyListing = {
      title: listing.title.substring(0, 140),
      description: listing.description,
      price: {
        amount: Math.round(listing.price * 100),
        divisor: 100,
        currency_code: 'USD',
      },
      quantity: listing.quantity || 999,
      taxonomy_id: taxonomyId,
      who_made: 'i_did',
      when_made: 'made_to_order',
      is_supply: false,
      is_digital: listing.isDigital || false,
      is_customizable: listing.isCustomizable ?? true,
      should_auto_renew: true,
      tags: listing.tags?.slice(0, 13),
      materials: listing.materials?.slice(0, 13),
      shipping_profile_id: listing.isDigital ? undefined : listing.shippingProfileId,
      return_policy_id: listing.returnPolicyId,
    };
    
    const result = await this.request<{ listing_id: number }>(
      `/application/shops/${this.shopId}/listings`,
      {
        method: 'POST',
        body: JSON.stringify(body),
      }
    );
    
    await this.logActivity('listing_create', {
      listingId: result.listing_id,
      title: listing.title,
      productType: listing.productType,
    });
    
    return result;
  }
  
  /**
   * Upload image to a listing
   */
  async uploadListingImage(
    listingId: number,
    imageUrl: string,
    rank: number = 1
  ): Promise<{ listing_image_id: number }> {
    // Etsy requires multipart form upload
    // First, fetch the image
    const imageResponse = await fetch(imageUrl);
    const imageBuffer = await imageResponse.arrayBuffer();
    
    const formData = new FormData();
    formData.append('image', new Blob([imageBuffer]), 'product.png');
    formData.append('rank', rank.toString());
    formData.append('overwrite', 'true');
    
    const token = await this.ensureValidToken();
    
    const response = await fetch(
      `${this.baseUrl}/application/shops/${this.shopId}/listings/${listingId}/images`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-api-key': this.clientId,
        },
        body: formData,
      }
    );
    
    if (!response.ok) {
      throw new Error(`Image upload failed: ${await response.text()}`);
    }
    
    return response.json();
  }
  
  /**
   * Update listing state (activate/deactivate)
   */
  async updateListingState(
    listingId: number,
    state: 'active' | 'inactive' | 'draft'
  ): Promise<void> {
    await this.request(
      `/application/listings/${listingId}`,
      {
        method: 'PATCH',
        body: JSON.stringify({ state }),
      }
    );
    
    await this.logActivity('listing_state_change', { listingId, state });
  }
  
  /**
   * Get listing details
   */
  async getListing(listingId: number): Promise<any> {
    return this.request<any>(`/application/listings/${listingId}`);
  }
  
  /**
   * Get all active listings
   */
  async getListings(state: 'active' | 'inactive' | 'draft' = 'active', limit = 100): Promise<{
    count: number;
    results: any[];
  }> {
    return this.request<{ count: number; results: any[] }>(
      `/application/shops/${this.shopId}/listings/${state}?limit=${limit}`
    );
  }
  
  /**
   * Delete a listing
   */
  async deleteListing(listingId: number): Promise<void> {
    await this.request(
      `/application/listings/${listingId}`,
      { method: 'DELETE' }
    );
    
    await this.logActivity('listing_delete', { listingId });
  }
  
  /**
   * Get shop receipts (orders)
   */
  async getReceipts(options?: {
    minCreated?: number;
    maxCreated?: number;
    limit?: number;
  }): Promise<{ count: number; results: EtsyReceipt[] }> {
    const params = new URLSearchParams();
    if (options?.minCreated) params.set('min_created', options.minCreated.toString());
    if (options?.maxCreated) params.set('max_created', options.maxCreated.toString());
    params.set('limit', (options?.limit || 100).toString());
    
    return this.request<{ count: number; results: EtsyReceipt[] }>(
      `/application/shops/${this.shopId}/receipts?${params.toString()}`
    );
  }
  
  /**
   * Get receipt/order details
   */
  async getReceipt(receiptId: number): Promise<EtsyReceipt> {
    return this.request<EtsyReceipt>(
      `/application/shops/${this.shopId}/receipts/${receiptId}`
    );
  }
  
  /**
   * Get shipping profiles
   */
  async getShippingProfiles(): Promise<{ count: number; results: any[] }> {
    return this.request<{ count: number; results: any[] }>(
      `/application/shops/${this.shopId}/shipping-profiles`
    );
  }
  
  /**
   * Get return policies
   */
  async getReturnPolicies(): Promise<{ count: number; results: any[] }> {
    return this.request<{ count: number; results: any[] }>(
      `/application/shops/${this.shopId}/policies/return`
    );
  }
  
  /**
   * Complete flow: Create listing → Upload image → Activate
   */
  async createAndPublishListing(config: {
    title: string;
    description: string;
    price: number;
    productType: string;
    imageUrl: string;
    tags?: string[];
    isDigital?: boolean;
    shippingProfileId?: number;
    returnPolicyId?: number;
    autoActivate?: boolean;
  }): Promise<{
    listingId: number;
    listingUrl: string;
    activated: boolean;
  }> {
    // Step 1: Create draft listing
    const { listing_id } = await this.createListing({
      title: config.title,
      description: config.description,
      price: config.price,
      productType: config.productType,
      tags: config.tags,
      isDigital: config.isDigital,
      shippingProfileId: config.shippingProfileId,
      returnPolicyId: config.returnPolicyId,
    });
    
    // Step 2: Upload image
    await this.uploadListingImage(listing_id, config.imageUrl);
    
    // Step 3: Activate listing (optional)
    let activated = false;
    if (config.autoActivate !== false) {
      await this.updateListingState(listing_id, 'active');
      activated = true;
    }
    
    return {
      listingId: listing_id,
      listingUrl: `https://www.etsy.com/listing/${listing_id}`,
      activated,
    };
  }
  
  /**
   * Calculate revenue from receipts
   */
  async calculateRevenue(days: number = 30): Promise<{
    grossRevenue: number;
    fees: number;
    netRevenue: number;
    orderCount: number;
    itemsSold: number;
  }> {
    const minCreated = Math.floor((Date.now() - days * 24 * 60 * 60 * 1000) / 1000);
    const receipts = await this.getReceipts({ minCreated, limit: 100 });
    
    let grossRevenue = 0;
    let fees = 0;
    let itemsSold = 0;
    
    for (const receipt of receipts.results) {
      const total = receipt.grandtotal.amount / receipt.grandtotal.divisor;
      grossRevenue += total;
      
      // Etsy fees: ~6.5% transaction + $0.20 listing + 3% payment processing
      fees += total * 0.095 + 0.20;
      
      itemsSold += receipt.transactions.reduce((sum, t) => sum + t.quantity, 0);
    }
    
    return {
      grossRevenue: Math.round(grossRevenue * 100) / 100,
      fees: Math.round(fees * 100) / 100,
      netRevenue: Math.round((grossRevenue - fees) * 100) / 100,
      orderCount: receipts.count,
      itemsSold,
    };
  }
  
  /**
   * Log activity to database
   */
  private async logActivity(action: string, details: Record<string, any>): Promise<void> {
    try {
      await this.supabase.from('platform_activity_log').insert({
        platform: 'etsy',
        action,
        details,
        created_at: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
  
  /**
   * Health check
   */
  async healthCheck(): Promise<{
    healthy: boolean;
    shopId: string;
    shopName: string;
    activeListings: number;
    tokenValid: boolean;
  }> {
    try {
      const shop = await this.getShop();
      
      return {
        healthy: true,
        shopId: this.shopId,
        shopName: shop.shop_name,
        activeListings: shop.listing_active_count,
        tokenValid: true,
      };
    } catch (error) {
      return {
        healthy: false,
        shopId: this.shopId,
        shopName: '',
        activeListings: 0,
        tokenValid: false,
      };
    }
  }
}

export default EtsyConnector;
