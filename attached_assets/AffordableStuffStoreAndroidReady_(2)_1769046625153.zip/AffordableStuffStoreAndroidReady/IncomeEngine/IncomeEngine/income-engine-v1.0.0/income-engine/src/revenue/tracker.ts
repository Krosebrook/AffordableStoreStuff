/**
 * Revenue Tracker
 * Multi-platform revenue aggregation and goal tracking
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { PlatformManager } from '../connectors';

// Types
export interface RevenueSnapshot {
  id?: string;
  period: 'daily' | 'weekly' | 'monthly';
  periodStart: string;
  periodEnd: string;
  platforms: PlatformRevenue[];
  totals: RevenueTotals;
  goalTracking: GoalProgress;
  createdAt: string;
}

export interface PlatformRevenue {
  platform: string;
  grossRevenue: number;
  fees: number;
  netRevenue: number;
  salesCount: number;
  refunds: number;
  averageOrderValue: number;
}

export interface RevenueTotals {
  grossRevenue: number;
  platformFees: number;
  productionCosts: number;
  aiGenerationCosts: number;
  netProfit: number;
  profitMargin: number;
}

export interface GoalProgress {
  monthlyGoal: number;
  currentMonthRevenue: number;
  percentComplete: number;
  projectedMonthly: number;
  onTrack: boolean;
  daysRemaining: number;
  requiredDailyRate: number;
}

export interface CostBreakdown {
  aiGeneration: {
    images: number;
    text: number;
    total: number;
  };
  platformFees: {
    etsy: number;
    gumroad: number;
    printify: number;
    total: number;
  };
  productionCosts: number;
  hosting: number;
  total: number;
}

export interface SalesRecord {
  id?: string;
  platform: string;
  orderId: string;
  productId?: string;
  productTitle: string;
  grossAmount: number;
  platformFees: number;
  productionCost: number;
  netProfit: number;
  saleDate: string;
  currency: string;
}

export class RevenueTracker {
  private supabase: SupabaseClient;
  private platformManager?: PlatformManager;
  private monthlyGoal: number;
  
  constructor(config: {
    supabaseUrl: string;
    supabaseKey: string;
    platformManager?: PlatformManager;
    monthlyGoal?: number;
  }) {
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
    this.platformManager = config.platformManager;
    this.monthlyGoal = config.monthlyGoal || 1000; // Default $1K/month goal
  }
  
  /**
   * Record a sale
   */
  async recordSale(sale: Omit<SalesRecord, 'id' | 'netProfit'>): Promise<SalesRecord> {
    const netProfit = sale.grossAmount - sale.platformFees - sale.productionCost;
    
    const record: SalesRecord = {
      ...sale,
      netProfit,
    };
    
    const { data, error } = await this.supabase
      .from('sales_records')
      .insert({
        platform: record.platform,
        order_id: record.orderId,
        product_id: record.productId,
        product_title: record.productTitle,
        gross_amount: record.grossAmount,
        platform_fees: record.platformFees,
        production_cost: record.productionCost,
        net_profit: record.netProfit,
        sale_date: record.saleDate,
        currency: record.currency,
      })
      .select('id')
      .single();
    
    if (data) {
      record.id = data.id;
    }
    
    return record;
  }
  
  /**
   * Get revenue for a date range
   */
  async getRevenue(options: {
    startDate: string;
    endDate: string;
    platform?: string;
  }): Promise<{
    sales: SalesRecord[];
    totals: RevenueTotals;
  }> {
    let query = this.supabase
      .from('sales_records')
      .select('*')
      .gte('sale_date', options.startDate)
      .lte('sale_date', options.endDate)
      .order('sale_date', { ascending: false });
    
    if (options.platform) {
      query = query.eq('platform', options.platform);
    }
    
    const { data: sales, error } = await query;
    
    if (error || !sales) {
      return {
        sales: [],
        totals: this.emptyTotals(),
      };
    }
    
    // Get AI generation costs for the period
    const { data: aiCosts } = await this.supabase
      .from('ai_generation_costs')
      .select('cost_usd')
      .gte('created_at', options.startDate)
      .lte('created_at', options.endDate);
    
    const aiGenerationCosts = aiCosts?.reduce((sum, c) => sum + (c.cost_usd || 0), 0) || 0;
    
    // Calculate totals
    const totals = this.calculateTotals(sales, aiGenerationCosts);
    
    return { sales, totals };
  }
  
  /**
   * Calculate revenue totals
   */
  private calculateTotals(sales: any[], aiGenerationCosts: number): RevenueTotals {
    const grossRevenue = sales.reduce((sum, s) => sum + (s.gross_amount || 0), 0);
    const platformFees = sales.reduce((sum, s) => sum + (s.platform_fees || 0), 0);
    const productionCosts = sales.reduce((sum, s) => sum + (s.production_cost || 0), 0);
    const netProfit = grossRevenue - platformFees - productionCosts - aiGenerationCosts;
    const profitMargin = grossRevenue > 0 ? (netProfit / grossRevenue) * 100 : 0;
    
    return {
      grossRevenue: Math.round(grossRevenue * 100) / 100,
      platformFees: Math.round(platformFees * 100) / 100,
      productionCosts: Math.round(productionCosts * 100) / 100,
      aiGenerationCosts: Math.round(aiGenerationCosts * 100) / 100,
      netProfit: Math.round(netProfit * 100) / 100,
      profitMargin: Math.round(profitMargin * 10) / 10,
    };
  }
  
  /**
   * Empty totals object
   */
  private emptyTotals(): RevenueTotals {
    return {
      grossRevenue: 0,
      platformFees: 0,
      productionCosts: 0,
      aiGenerationCosts: 0,
      netProfit: 0,
      profitMargin: 0,
    };
  }
  
  /**
   * Get current month's goal progress
   */
  async getGoalProgress(): Promise<GoalProgress> {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const dayOfMonth = now.getDate();
    const daysRemaining = daysInMonth - dayOfMonth;
    
    const { totals } = await this.getRevenue({
      startDate: startOfMonth,
      endDate: endOfMonth,
    });
    
    const currentMonthRevenue = totals.netProfit;
    const percentComplete = (currentMonthRevenue / this.monthlyGoal) * 100;
    const dailyRate = dayOfMonth > 0 ? currentMonthRevenue / dayOfMonth : 0;
    const projectedMonthly = dailyRate * daysInMonth;
    const onTrack = projectedMonthly >= this.monthlyGoal;
    const requiredDailyRate = daysRemaining > 0 
      ? (this.monthlyGoal - currentMonthRevenue) / daysRemaining 
      : 0;
    
    return {
      monthlyGoal: this.monthlyGoal,
      currentMonthRevenue: Math.round(currentMonthRevenue * 100) / 100,
      percentComplete: Math.round(percentComplete * 10) / 10,
      projectedMonthly: Math.round(projectedMonthly * 100) / 100,
      onTrack,
      daysRemaining,
      requiredDailyRate: Math.round(requiredDailyRate * 100) / 100,
    };
  }
  
  /**
   * Get cost breakdown for a period
   */
  async getCostBreakdown(days: number = 30): Promise<CostBreakdown> {
    const endDate = new Date().toISOString();
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    
    // AI generation costs
    const { data: aiCosts } = await this.supabase
      .from('ai_generation_costs')
      .select('operation, cost_usd')
      .gte('created_at', startDate)
      .lte('created_at', endDate);
    
    const imageCosts = aiCosts
      ?.filter(c => c.operation === 'image_generation')
      .reduce((sum, c) => sum + c.cost_usd, 0) || 0;
    
    const textCosts = aiCosts
      ?.filter(c => c.operation === 'text_generation')
      .reduce((sum, c) => sum + c.cost_usd, 0) || 0;
    
    // Sales data for platform fees and production costs
    const { data: sales } = await this.supabase
      .from('sales_records')
      .select('platform, platform_fees, production_cost')
      .gte('sale_date', startDate)
      .lte('sale_date', endDate);
    
    const platformFees = {
      etsy: 0,
      gumroad: 0,
      printify: 0,
      total: 0,
    };
    
    let productionCosts = 0;
    
    sales?.forEach(sale => {
      const fees = sale.platform_fees || 0;
      switch (sale.platform) {
        case 'etsy': platformFees.etsy += fees; break;
        case 'gumroad': platformFees.gumroad += fees; break;
        case 'printify': platformFees.printify += fees; break;
      }
      platformFees.total += fees;
      productionCosts += sale.production_cost || 0;
    });
    
    // Estimate hosting costs (configured externally)
    const hostingCost = 10; // $10/month default
    const dailyHosting = (hostingCost / 30) * days;
    
    const totalCosts = imageCosts + textCosts + platformFees.total + productionCosts + dailyHosting;
    
    return {
      aiGeneration: {
        images: Math.round(imageCosts * 100) / 100,
        text: Math.round(textCosts * 100) / 100,
        total: Math.round((imageCosts + textCosts) * 100) / 100,
      },
      platformFees: {
        etsy: Math.round(platformFees.etsy * 100) / 100,
        gumroad: Math.round(platformFees.gumroad * 100) / 100,
        printify: Math.round(platformFees.printify * 100) / 100,
        total: Math.round(platformFees.total * 100) / 100,
      },
      productionCosts: Math.round(productionCosts * 100) / 100,
      hosting: Math.round(dailyHosting * 100) / 100,
      total: Math.round(totalCosts * 100) / 100,
    };
  }
  
  /**
   * Create a revenue snapshot
   */
  async createSnapshot(period: 'daily' | 'weekly' | 'monthly'): Promise<RevenueSnapshot> {
    const now = new Date();
    let periodStart: Date;
    let periodEnd: Date;
    
    switch (period) {
      case 'daily':
        periodStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        periodEnd = new Date(periodStart.getTime() + 24 * 60 * 60 * 1000 - 1);
        break;
      case 'weekly':
        const dayOfWeek = now.getDay();
        periodStart = new Date(now.getTime() - dayOfWeek * 24 * 60 * 60 * 1000);
        periodStart.setHours(0, 0, 0, 0);
        periodEnd = new Date(periodStart.getTime() + 7 * 24 * 60 * 60 * 1000 - 1);
        break;
      case 'monthly':
        periodStart = new Date(now.getFullYear(), now.getMonth(), 1);
        periodEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
        break;
    }
    
    // Get platform-specific revenue
    const platforms: PlatformRevenue[] = [];
    
    for (const platform of ['etsy', 'gumroad', 'printify']) {
      const { sales, totals } = await this.getRevenue({
        startDate: periodStart.toISOString(),
        endDate: periodEnd.toISOString(),
        platform,
      });
      
      if (sales.length > 0 || totals.grossRevenue > 0) {
        const avgOrderValue = sales.length > 0 
          ? totals.grossRevenue / sales.length 
          : 0;
        
        platforms.push({
          platform,
          grossRevenue: totals.grossRevenue,
          fees: totals.platformFees,
          netRevenue: totals.netProfit,
          salesCount: sales.length,
          refunds: 0, // Would need to track separately
          averageOrderValue: Math.round(avgOrderValue * 100) / 100,
        });
      }
    }
    
    // Get totals
    const { totals } = await this.getRevenue({
      startDate: periodStart.toISOString(),
      endDate: periodEnd.toISOString(),
    });
    
    // Get goal progress
    const goalTracking = await this.getGoalProgress();
    
    const snapshot: RevenueSnapshot = {
      period,
      periodStart: periodStart.toISOString(),
      periodEnd: periodEnd.toISOString(),
      platforms,
      totals,
      goalTracking,
      createdAt: now.toISOString(),
    };
    
    // Save to database
    const { data, error } = await this.supabase
      .from('revenue_snapshots')
      .insert({
        period: snapshot.period,
        period_start: snapshot.periodStart,
        period_end: snapshot.periodEnd,
        platforms: snapshot.platforms,
        totals: snapshot.totals,
        goal_tracking: snapshot.goalTracking,
        created_at: snapshot.createdAt,
      })
      .select('id')
      .single();
    
    if (data) {
      snapshot.id = data.id;
    }
    
    return snapshot;
  }
  
  /**
   * Get historical snapshots
   */
  async getSnapshots(options: {
    period?: 'daily' | 'weekly' | 'monthly';
    limit?: number;
  }): Promise<RevenueSnapshot[]> {
    let query = this.supabase
      .from('revenue_snapshots')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(options.limit || 30);
    
    if (options.period) {
      query = query.eq('period', options.period);
    }
    
    const { data, error } = await query;
    
    return data || [];
  }
  
  /**
   * Get top performing products
   */
  async getTopProducts(days: number = 30, limit: number = 10): Promise<{
    productId: string;
    productTitle: string;
    salesCount: number;
    totalRevenue: number;
    avgOrderValue: number;
  }[]> {
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    
    const { data } = await this.supabase
      .from('sales_records')
      .select('product_id, product_title, gross_amount')
      .gte('sale_date', startDate);
    
    if (!data || data.length === 0) {
      return [];
    }
    
    // Aggregate by product
    const productMap = new Map<string, {
      productTitle: string;
      salesCount: number;
      totalRevenue: number;
    }>();
    
    data.forEach(sale => {
      const key = sale.product_id || sale.product_title;
      const existing = productMap.get(key);
      
      if (existing) {
        existing.salesCount++;
        existing.totalRevenue += sale.gross_amount;
      } else {
        productMap.set(key, {
          productTitle: sale.product_title,
          salesCount: 1,
          totalRevenue: sale.gross_amount,
        });
      }
    });
    
    // Sort and limit
    return Array.from(productMap.entries())
      .map(([productId, data]) => ({
        productId,
        productTitle: data.productTitle,
        salesCount: data.salesCount,
        totalRevenue: Math.round(data.totalRevenue * 100) / 100,
        avgOrderValue: Math.round((data.totalRevenue / data.salesCount) * 100) / 100,
      }))
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, limit);
  }
  
  /**
   * Generate performance report
   */
  async generateReport(days: number = 30): Promise<{
    summary: {
      period: string;
      grossRevenue: number;
      netProfit: number;
      profitMargin: number;
      totalSales: number;
      avgOrderValue: number;
    };
    goalProgress: GoalProgress;
    costs: CostBreakdown;
    topProducts: any[];
    platformBreakdown: PlatformRevenue[];
    trends: {
      revenueChange: number;
      salesChange: number;
    };
  }> {
    const endDate = new Date().toISOString();
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    const previousStartDate = new Date(Date.now() - days * 2 * 24 * 60 * 60 * 1000).toISOString();
    
    // Current period
    const { sales, totals } = await this.getRevenue({ startDate, endDate });
    
    // Previous period for comparison
    const { sales: prevSales, totals: prevTotals } = await this.getRevenue({
      startDate: previousStartDate,
      endDate: startDate,
    });
    
    // Calculate changes
    const revenueChange = prevTotals.grossRevenue > 0
      ? ((totals.grossRevenue - prevTotals.grossRevenue) / prevTotals.grossRevenue) * 100
      : 0;
    
    const salesChange = prevSales.length > 0
      ? ((sales.length - prevSales.length) / prevSales.length) * 100
      : 0;
    
    // Get other data
    const goalProgress = await this.getGoalProgress();
    const costs = await this.getCostBreakdown(days);
    const topProducts = await this.getTopProducts(days, 5);
    
    // Platform breakdown
    const platformBreakdown: PlatformRevenue[] = [];
    for (const platform of ['etsy', 'gumroad', 'printify']) {
      const { sales: platformSales, totals: platformTotals } = await this.getRevenue({
        startDate,
        endDate,
        platform,
      });
      
      if (platformSales.length > 0) {
        platformBreakdown.push({
          platform,
          grossRevenue: platformTotals.grossRevenue,
          fees: platformTotals.platformFees,
          netRevenue: platformTotals.netProfit,
          salesCount: platformSales.length,
          refunds: 0,
          averageOrderValue: platformTotals.grossRevenue / platformSales.length,
        });
      }
    }
    
    return {
      summary: {
        period: `${days} days`,
        grossRevenue: totals.grossRevenue,
        netProfit: totals.netProfit,
        profitMargin: totals.profitMargin,
        totalSales: sales.length,
        avgOrderValue: sales.length > 0 ? totals.grossRevenue / sales.length : 0,
      },
      goalProgress,
      costs,
      topProducts,
      platformBreakdown,
      trends: {
        revenueChange: Math.round(revenueChange * 10) / 10,
        salesChange: Math.round(salesChange * 10) / 10,
      },
    };
  }
  
  /**
   * Set monthly goal
   */
  setGoal(amount: number): void {
    this.monthlyGoal = amount;
  }
}

export default RevenueTracker;
