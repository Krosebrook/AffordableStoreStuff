/**
 * Gumroad API Connector
 * Digital product automation for passive income
 * 
 * @see https://gumroad.com/api
 */

import { createClient } from '@supabase/supabase-js';

// Types
interface GumroadProduct {
  id?: string;
  name: string;
  description: string;
  price: number;
  currency?: string;
  customizable_price?: boolean;
  require_shipping?: boolean;
  custom_summary?: string;
  custom_permalink?: string;
  preview_url?: string;
  tags?: string[];
  file_info?: { name: string; size: number }[];
  variants?: GumroadVariant[];
  published?: boolean;
  url?: string;
  short_url?: string;
}

interface GumroadVariant {
  title: string;
  price_difference_cents: number;
  max_purchase_count?: number;
}

interface GumroadSale {
  id: string;
  email: string;
  seller_id: string;
  timestamp: string;
  order_number: number;
  product_id: string;
  product_name: string;
  short_product_id: string;
  formatted_display_price: string;
  price: number;
  gumroad_fee: number;
  currency: string;
  quantity: number;
  refunded: boolean;
  disputed: boolean;
}

interface GumroadUser {
  user_id: string;
  email: string;
  name: string;
  url: string;
  display_name: string;
}

// Product type to pricing mapping
export const DIGITAL_PRICING: Record<string, { min: number; max: number; suggested: number }> = {
  'digital_printable': { min: 0.99, max: 4.99, suggested: 2.99 },
  'digital_planner': { min: 4.99, max: 14.99, suggested: 7.99 },
  'digital_template': { min: 2.99, max: 9.99, suggested: 4.99 },
  'digital_wallart': { min: 0.99, max: 4.99, suggested: 1.99 },
  'digital_bundle': { min: 9.99, max: 29.99, suggested: 14.99 },
  'digital_ebook': { min: 4.99, max: 19.99, suggested: 9.99 },
  'digital_course': { min: 19.99, max: 99.99, suggested: 29.99 },
  'digital_preset': { min: 4.99, max: 19.99, suggested: 9.99 },
  'digital_font': { min: 9.99, max: 49.99, suggested: 19.99 },
  'digital_mockup': { min: 4.99, max: 14.99, suggested: 7.99 },
};

export class GumroadConnector {
  private accessToken: string;
  private baseUrl = 'https://api.gumroad.com/v2';
  private supabase: ReturnType<typeof createClient>;
  
  // Rate limiting
  private lastRequestTime = 0;
  private readonly MIN_REQUEST_INTERVAL = 100; // ms between requests
  
  constructor(config: {
    accessToken: string;
    supabaseUrl: string;
    supabaseKey: string;
  }) {
    if (!config.accessToken) throw new Error('Gumroad access token required');
    
    this.accessToken = config.accessToken;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
  }
  
  /**
   * Rate-limited API request
   */
  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    // Simple rate limiting
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    if (timeSinceLastRequest < this.MIN_REQUEST_INTERVAL) {
      await new Promise(resolve => 
        setTimeout(resolve, this.MIN_REQUEST_INTERVAL - timeSinceLastRequest)
      );
    }
    this.lastRequestTime = Date.now();
    
    const url = new URL(`${this.baseUrl}${endpoint}`);
    
    // Add access token to all requests
    if (options.method === 'GET' || !options.method) {
      url.searchParams.set('access_token', this.accessToken);
    }
    
    const response = await fetch(url.toString(), {
      ...options,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        ...options.headers,
      },
    });
    
    const data = await response.json();
    
    if (!data.success) {
      throw new Error(`Gumroad API error: ${data.message || JSON.stringify(data)}`);
    }
    
    return data;
  }
  
  /**
   * Get authenticated user info
   */
  async getUser(): Promise<GumroadUser> {
    const response = await this.request<{ user: GumroadUser }>('/user');
    return response.user;
  }
  
  /**
   * Get all products
   */
  async getProducts(): Promise<GumroadProduct[]> {
    const response = await this.request<{ products: GumroadProduct[] }>('/products');
    return response.products;
  }
  
  /**
   * Get single product
   */
  async getProduct(productId: string): Promise<GumroadProduct> {
    const response = await this.request<{ product: GumroadProduct }>(
      `/products/${productId}`
    );
    return response.product;
  }
  
  /**
   * Create a new product
   */
  async createProduct(config: {
    name: string;
    description: string;
    price: number;
    productType?: string;
    customizablePrice?: boolean;
    previewUrl?: string;
    tags?: string[];
    customPermalink?: string;
  }): Promise<GumroadProduct> {
    const params = new URLSearchParams();
    params.set('access_token', this.accessToken);
    params.set('name', config.name.substring(0, 200));
    params.set('description', config.description);
    params.set('price', Math.max(0.99, config.price).toString());
    params.set('customizable_price', (config.customizablePrice || false).toString());
    
    if (config.previewUrl) {
      params.set('preview_url', config.previewUrl);
    }
    
    if (config.customPermalink) {
      params.set('custom_permalink', config.customPermalink);
    }
    
    // Tags need to be sent as separate params
    if (config.tags) {
      config.tags.slice(0, 5).forEach((tag, i) => {
        params.set(`tags[${i}]`, tag);
      });
    }
    
    const response = await this.request<{ product: GumroadProduct }>(
      '/products',
      {
        method: 'POST',
        body: params.toString(),
      }
    );
    
    await this.logActivity('product_create', {
      productId: response.product.id,
      name: config.name,
      price: config.price,
      productType: config.productType,
    });
    
    return response.product;
  }
  
  /**
   * Update a product
   */
  async updateProduct(productId: string, updates: {
    name?: string;
    description?: string;
    price?: number;
    customizablePrice?: boolean;
    previewUrl?: string;
  }): Promise<GumroadProduct> {
    const params = new URLSearchParams();
    params.set('access_token', this.accessToken);
    
    if (updates.name) params.set('name', updates.name.substring(0, 200));
    if (updates.description) params.set('description', updates.description);
    if (updates.price) params.set('price', updates.price.toString());
    if (updates.customizablePrice !== undefined) {
      params.set('customizable_price', updates.customizablePrice.toString());
    }
    if (updates.previewUrl) params.set('preview_url', updates.previewUrl);
    
    const response = await this.request<{ product: GumroadProduct }>(
      `/products/${productId}`,
      {
        method: 'PUT',
        body: params.toString(),
      }
    );
    
    await this.logActivity('product_update', { productId, updates });
    
    return response.product;
  }
  
  /**
   * Delete a product
   */
  async deleteProduct(productId: string): Promise<void> {
    const params = new URLSearchParams();
    params.set('access_token', this.accessToken);
    
    await this.request(
      `/products/${productId}`,
      {
        method: 'DELETE',
        body: params.toString(),
      }
    );
    
    await this.logActivity('product_delete', { productId });
  }
  
  /**
   * Enable/disable a product
   */
  async setProductEnabled(productId: string, enabled: boolean): Promise<GumroadProduct> {
    const endpoint = enabled 
      ? `/products/${productId}/enable`
      : `/products/${productId}/disable`;
    
    const params = new URLSearchParams();
    params.set('access_token', this.accessToken);
    
    const response = await this.request<{ product: GumroadProduct }>(
      endpoint,
      {
        method: 'PUT',
        body: params.toString(),
      }
    );
    
    await this.logActivity(enabled ? 'product_enable' : 'product_disable', { productId });
    
    return response.product;
  }
  
  /**
   * Add a variant to a product
   */
  async addVariant(productId: string, variant: {
    name: string;
    priceDifferenceCents: number;
    maxPurchaseCount?: number;
  }): Promise<GumroadProduct> {
    const params = new URLSearchParams();
    params.set('access_token', this.accessToken);
    params.set('name', variant.name);
    params.set('price_difference_cents', variant.priceDifferenceCents.toString());
    if (variant.maxPurchaseCount) {
      params.set('max_purchase_count', variant.maxPurchaseCount.toString());
    }
    
    const response = await this.request<{ product: GumroadProduct }>(
      `/products/${productId}/variant_categories`,
      {
        method: 'POST',
        body: params.toString(),
      }
    );
    
    return response.product;
  }
  
  /**
   * Get sales data
   */
  async getSales(options?: {
    after?: string;
    before?: string;
    productId?: string;
    email?: string;
    page?: number;
  }): Promise<{ sales: GumroadSale[]; next_page_key?: string }> {
    const params = new URLSearchParams();
    params.set('access_token', this.accessToken);
    
    if (options?.after) params.set('after', options.after);
    if (options?.before) params.set('before', options.before);
    if (options?.productId) params.set('product_id', options.productId);
    if (options?.email) params.set('email', options.email);
    if (options?.page) params.set('page', options.page.toString());
    
    const response = await fetch(`${this.baseUrl}/sales?${params.toString()}`);
    const data = await response.json();
    
    if (!data.success) {
      throw new Error(`Gumroad sales fetch error: ${data.message}`);
    }
    
    return {
      sales: data.sales || [],
      next_page_key: data.next_page_key,
    };
  }
  
  /**
   * Get all sales (paginated)
   */
  async getAllSales(days: number = 30): Promise<GumroadSale[]> {
    const allSales: GumroadSale[] = [];
    const afterDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
      .toISOString()
      .split('T')[0];
    
    let page = 1;
    let hasMore = true;
    
    while (hasMore && page <= 100) { // Safety limit
      const { sales, next_page_key } = await this.getSales({
        after: afterDate,
        page,
      });
      
      allSales.push(...sales);
      hasMore = !!next_page_key;
      page++;
      
      // Small delay between pages
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    return allSales;
  }
  
  /**
   * Calculate revenue
   */
  async calculateRevenue(days: number = 30): Promise<{
    grossRevenue: number;
    gumroadFees: number;
    netRevenue: number;
    salesCount: number;
    refundedCount: number;
    topProducts: { id: string; name: string; revenue: number }[];
  }> {
    const sales = await this.getAllSales(days);
    
    // Filter out refunded sales
    const validSales = sales.filter(s => !s.refunded && !s.disputed);
    const refundedSales = sales.filter(s => s.refunded);
    
    let grossRevenue = 0;
    let gumroadFees = 0;
    const productRevenue: Record<string, { name: string; revenue: number }> = {};
    
    for (const sale of validSales) {
      const amount = sale.price / 100; // Convert cents to dollars
      grossRevenue += amount;
      gumroadFees += sale.gumroad_fee / 100;
      
      if (!productRevenue[sale.product_id]) {
        productRevenue[sale.product_id] = { name: sale.product_name, revenue: 0 };
      }
      productRevenue[sale.product_id].revenue += amount;
    }
    
    // Get top products
    const topProducts = Object.entries(productRevenue)
      .map(([id, data]) => ({ id, ...data }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
    
    return {
      grossRevenue: Math.round(grossRevenue * 100) / 100,
      gumroadFees: Math.round(gumroadFees * 100) / 100,
      netRevenue: Math.round((grossRevenue - gumroadFees) * 100) / 100,
      salesCount: validSales.length,
      refundedCount: refundedSales.length,
      topProducts,
    };
  }
  
  /**
   * Create product with optimal pricing
   */
  async createOptimizedProduct(config: {
    name: string;
    description: string;
    productType: string;
    previewUrl?: string;
    tags?: string[];
    pricingTier?: 'min' | 'suggested' | 'max';
    allowCustomPrice?: boolean;
    autoEnable?: boolean;
  }): Promise<{
    product: GumroadProduct;
    price: number;
    productUrl: string;
  }> {
    // Get pricing for product type
    const pricing = DIGITAL_PRICING[config.productType] || DIGITAL_PRICING['digital_template'];
    
    // Determine price based on tier
    let price: number;
    switch (config.pricingTier) {
      case 'min': price = pricing.min; break;
      case 'max': price = pricing.max; break;
      default: price = pricing.suggested;
    }
    
    // Create product
    const product = await this.createProduct({
      name: config.name,
      description: config.description,
      price,
      productType: config.productType,
      customizablePrice: config.allowCustomPrice ?? true,
      previewUrl: config.previewUrl,
      tags: config.tags,
    });
    
    // Enable if requested
    if (config.autoEnable !== false) {
      await this.setProductEnabled(product.id!, true);
    }
    
    return {
      product,
      price,
      productUrl: product.short_url || `https://gumroad.com/l/${product.custom_permalink || product.id}`,
    };
  }
  
  /**
   * Sync products to database
   */
  async syncProductsToDatabase(): Promise<{ synced: number; errors: string[] }> {
    const products = await this.getProducts();
    const errors: string[] = [];
    let synced = 0;
    
    for (const product of products) {
      try {
        await this.supabase.from('gumroad_products').upsert({
          gumroad_id: product.id,
          name: product.name,
          description: product.description,
          price: product.price,
          url: product.url,
          short_url: product.short_url,
          published: product.published,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'gumroad_id' });
        
        synced++;
      } catch (error) {
        errors.push(`Failed to sync ${product.id}: ${error}`);
      }
    }
    
    return { synced, errors };
  }
  
  /**
   * Log activity to database
   */
  private async logActivity(action: string, details: Record<string, any>): Promise<void> {
    try {
      await this.supabase.from('platform_activity_log').insert({
        platform: 'gumroad',
        action,
        details,
        created_at: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Failed to log activity:', error);
    }
  }
  
  /**
   * Health check
   */
  async healthCheck(): Promise<{
    healthy: boolean;
    userId: string;
    email: string;
    productCount: number;
  }> {
    try {
      const user = await this.getUser();
      const products = await this.getProducts();
      
      return {
        healthy: true,
        userId: user.user_id,
        email: user.email,
        productCount: products.length,
      };
    } catch (error) {
      return {
        healthy: false,
        userId: '',
        email: '',
        productCount: 0,
      };
    }
  }
}

export default GumroadConnector;
