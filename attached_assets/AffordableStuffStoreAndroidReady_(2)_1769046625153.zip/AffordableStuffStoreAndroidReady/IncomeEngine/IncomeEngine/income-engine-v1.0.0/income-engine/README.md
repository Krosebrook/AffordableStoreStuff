# 🚀 Passive Income Engine v1.0

**Goal:** $1,000/month passive income via automated content generation and multi-platform publishing.

**Stack:** n8n (self-hosted) + AI Generation (Flux/GPT) + Safeguards + Multi-Platform Publishing

---

## TL;DR

This system automates the entire passive income pipeline:
1. **Discover** trending niches automatically
2. **Generate** AI images + SEO-optimized copy
3. **Validate** through existing safeguards (trademark, quality, budget)
4. **Publish** to Printify → Etsy/Shopify, Gumroad, and digital marketplaces
5. **Track** revenue across all platforms in real-time

---

## 📊 Cost Analysis (Lean Budget: $50-100/month)

| Component | Provider | Monthly Cost | Notes |
|-----------|----------|--------------|-------|
| **n8n Hosting** | Hostinger VPS / Hetzner | $5-10 | 2GB RAM sufficient |
| **Image Generation** | Replicate (Flux Schnell) | $15-30 | $0.003/image × 5,000-10,000 images |
| **Text Generation** | OpenAI GPT-4o-mini | $5-10 | $0.15/1M input, $0.60/1M output |
| **Printify** | Free tier | $0 | Pay per order only |
| **Etsy** | Listing fees | $5-15 | $0.20/listing + 6.5% transaction |
| **Gumroad** | Free tier | $0 | 10% per sale |
| **Supabase** | Free tier | $0 | 500MB, 50K requests |
| **Domain (optional)** | Cloudflare | $10/year | For custom storefront |
| **TOTAL** | | **$35-75/month** | Scales with volume |

### ROI Projection

| Month | Products | Est. Revenue | Profit (after costs) |
|-------|----------|--------------|----------------------|
| 1 | 100 | $50-150 | -$25 to +$75 |
| 2 | 300 | $150-400 | +$75 to +$325 |
| 3 | 500+ | $300-700 | +$225 to +$625 |
| 6 | 1,000+ | $800-1,500 | +$725 to +$1,425 |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PASSIVE INCOME ENGINE                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────┐                                                        │
│  │  NICHE SCANNER  │ ─── Etsy Trends, Pinterest, Google Trends             │
│  │  (Daily 6 AM)   │                                                        │
│  └────────┬────────┘                                                        │
│           │                                                                 │
│           ▼                                                                 │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐         │
│  │    GENERATE     │    │    SAFEGUARDS   │    │    PUBLISH      │         │
│  │                 │───▶│   (existing)    │───▶│                 │         │
│  │ • AI Images     │    │                 │    │ • Printify API  │         │
│  │ • SEO Copy      │    │ • Trademark ✓   │    │ • Etsy API      │         │
│  │ • Batch 10-50   │    │ • Quality ✓     │    │ • Gumroad API   │         │
│  │ • Multi-model   │    │ • Rate Limit ✓  │    │ • Auto-mockups  │         │
│  └─────────────────┘    │ • Budget ✓      │    └─────────────────┘         │
│                         │ • Human Review  │                                 │
│                         └─────────────────┘                                 │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       REVENUE DASHBOARD                              │   │
│  │  Etsy Stats ─┬─ Printify Orders ─┬─ Gumroad Sales ─┬─ P&L Report   │   │
│  │              │                    │                  │               │   │
│  │              └────────────────────┴──────────────────┘               │   │
│  │                              ▼                                       │   │
│  │                    Daily/Weekly/Monthly Reports                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📁 Project Structure

```
income-engine/
├── n8n-workflows/           # Ready-to-import n8n JSON workflows
│   ├── 01-niche-scanner.json
│   ├── 02-product-generator.json
│   ├── 03-printify-publisher.json
│   ├── 04-etsy-publisher.json
│   ├── 05-gumroad-publisher.json
│   ├── 06-revenue-aggregator.json
│   ├── 07-daily-report.json
│   └── 08-batch-processor.json
│
├── src/
│   ├── generators/          # Product generation logic
│   │   ├── image-generator.ts
│   │   ├── copy-generator.ts
│   │   └── product-templates.ts
│   │
│   ├── connectors/          # Platform API integrations
│   │   ├── printify.ts
│   │   ├── etsy.ts
│   │   ├── gumroad.ts
│   │   └── base-connector.ts
│   │
│   ├── revenue/             # Revenue tracking
│   │   ├── aggregator.ts
│   │   ├── dashboard-api.ts
│   │   └── reports.ts
│   │
│   ├── niche-research/      # Trend discovery
│   │   ├── etsy-trends.ts
│   │   ├── pinterest-scraper.ts
│   │   └── niche-scorer.ts
│   │
│   ├── ai-router/           # Multi-model cost optimizer
│   │   ├── router.ts
│   │   ├── providers.ts
│   │   └── cost-tracker.ts
│   │
│   └── batch-processor/     # Batch generation
│       ├── queue.ts
│       └── processor.ts
│
├── database/
│   ├── schema-extensions.sql
│   └── seed-niches.sql
│
├── templates/               # Product templates
│   ├── pod-tshirt.json
│   ├── pod-mug.json
│   ├── digital-printable.json
│   └── digital-planner.json
│
├── scripts/
│   ├── setup-n8n.sh
│   ├── import-workflows.sh
│   └── daily-cron.sh
│
└── docs/
    ├── DEPLOYMENT.md
    ├── NICHE-GUIDE.md
    └── TROUBLESHOOTING.md
```

---

## 🎯 Income Streams

### 1. Print-on-Demand (POD) - Primary
- **Platforms:** Printify → Etsy, Shopify (optional)
- **Products:** T-shirts, mugs, posters, tote bags, phone cases
- **Margin:** 30-50% ($5-15 per sale)
- **Volume needed:** ~100 sales/month for $500+

### 2. Digital Downloads - Secondary
- **Platforms:** Gumroad, Etsy Digital
- **Products:** Printables, planners, wall art, social media templates
- **Margin:** 80-90% (no production cost)
- **Volume needed:** ~50-100 sales/month for $300+

### 3. Amazon KDP - Tertiary (Semi-Manual)
- **Products:** Coloring books, journals, planners
- **Note:** Requires browser automation (HIGH RISK) or manual upload
- **Recommendation:** Start with POD/Digital, add KDP later

---

## 🔥 Top Niches for 2025 (Research-Backed)

| Niche | Competition | Demand | Recommended Products |
|-------|-------------|--------|---------------------|
| **Pet Portraits** | Medium | Very High | Mugs, posters, t-shirts |
| **Teacher Appreciation** | Medium | High | Tote bags, mugs, stickers |
| **Nurse/Healthcare** | Low-Medium | High | Tumblers, t-shirts, badges |
| **Gaming/Retro** | High | Very High | Posters, mousepads, hoodies |
| **Plant Mom/Dad** | Low | Medium-High | Mugs, tote bags, stickers |
| **Astrology/Zodiac** | Medium | High | Jewelry, posters, journals |
| **Dog Breed Specific** | Low-Medium | Very High | All products by breed |
| **Occupational Humor** | Low | Medium-High | Mugs, t-shirts by profession |
| **Minimalist Quotes** | High | Very High | Posters, printables |
| **Eco-Friendly/Activism** | Low-Medium | Growing | Tote bags, stickers |

---

## 🚀 Quick Start (30 minutes)

### Prerequisites
- [ ] Supabase account (free tier)
- [ ] Printify account (free)
- [ ] Etsy seller account ($15 setup)
- [ ] Gumroad account (free)
- [ ] Replicate account ($5 credit to start)
- [ ] OpenAI API key
- [ ] VPS for n8n ($5-10/month)

### Step 1: Deploy n8n
```bash
# On your VPS (Ubuntu 22.04)
./scripts/setup-n8n.sh
```

### Step 2: Import Workflows
```bash
# After n8n is running
./scripts/import-workflows.sh
```

### Step 3: Configure Credentials
In n8n UI, add credentials for:
- Replicate API
- OpenAI API
- Printify API
- Etsy OAuth
- Gumroad OAuth
- Supabase

### Step 4: Run First Batch
1. Go to n8n → "Niche Scanner" workflow
2. Click "Execute Workflow"
3. Check results in Supabase `trending_niches` table

### Step 5: Generate Products
1. Go to n8n → "Product Generator" workflow
2. Select niche from dropdown
3. Set batch size (start with 5)
4. Execute and monitor

---

## 📈 Scaling Strategy

### Month 1: Foundation (100 products)
- Focus on 2-3 niches
- Manual approval for all products
- Learn what converts

### Month 2: Expansion (300 products)
- Add 2-3 more niches
- Reduce manual approval (auto-approve quality scores >80%)
- Start digital products

### Month 3+: Automation (500+ products)
- Full automation with safeguards
- A/B testing titles/images
- Expand to more platforms

---

## ⚠️ Critical Warnings

1. **Trademark Screening is MANDATORY** - Never skip the USPTO TESS check
2. **Quality Gates Prevent Account Bans** - AI content must pass originality checks
3. **Rate Limits Protect Accounts** - Don't exceed platform limits
4. **Budget Caps Prevent Runaway Costs** - Set daily maximums
5. **Human Review for First 50** - Build trust before full automation

---

## 🔗 Integration with Existing Safeguards

This Income Engine integrates directly with the safeguards system from the previous conversation:

```typescript
import { SafeguardsOrchestrator } from '../passive-income-safeguards/src/orchestrator';

// Every product runs through safeguards before publishing
const result = await orchestrator.processProduct({
  title: generatedTitle,
  keywords: generatedKeywords,
  image_url: generatedImageUrl,
  platform: 'etsy',
  product_type: 'pod_tshirt'
});

if (result.status === 'approved') {
  await publishToPrintify(result.productId);
}
```

---

## 📞 Support & Resources

- **n8n Community:** https://community.n8n.io
- **Printify API Docs:** https://developers.printify.com
- **Etsy API Docs:** https://developer.etsy.com
- **Gumroad API Docs:** https://gumroad.com/api

---

## License

MIT - Use freely for your passive income empire 🏰
