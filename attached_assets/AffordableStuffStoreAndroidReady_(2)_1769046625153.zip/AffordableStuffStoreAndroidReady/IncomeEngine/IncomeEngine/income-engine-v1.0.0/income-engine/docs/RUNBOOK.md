# Income Engine Operations Runbook

## Quick Reference

| Task | Frequency | Command/Action |
|------|-----------|----------------|
| Health Check | Daily | `npm run health` |
| Daily Report | Auto 9 AM | n8n workflow #07 |
| Generate Products | As needed | POST to `/webhook/generate-products` |
| Batch Processing | Weekly | POST to `/webhook/batch-generate` |
| Revenue Sync | Every 12h | n8n workflow #06 |

---

## 1. Daily Operations

### Morning Checklist (9:00 AM)
1. ✅ Review Slack #passive-income for overnight alerts
2. ✅ Check daily report metrics
3. ✅ Verify budget status (< 50% used = healthy)
4. ✅ Review any products pending approval

### Metrics to Monitor
```
Target Metrics:
├── Daily Revenue: $30-50 (for $1K/month goal)
├── Products Generated: 5-20
├── Approval Rate: > 80%
├── AI Costs: < $2/day
└── Platform Health: All green
```

---

## 2. Workflow Operations

### 2.1 Niche Scanner (Workflow #01)
**Schedule**: Daily at 6:00 AM
**Purpose**: Discover trending niches and update scores

**Manual Trigger**:
```bash
curl -X POST "https://your-n8n.com/webhook/niche-scan"
```

**Expected Output**:
- Updated trending_niches table
- Slack notification with top 5 niches

**Troubleshooting**:
| Issue | Cause | Fix |
|-------|-------|-----|
| No niches updated | API rate limit | Wait 1 hour, retry |
| Low scores | Seasonal dip | Normal, continue |
| Workflow fails | Supabase connection | Check credentials |

### 2.2 Product Generator (Workflow #02)
**Trigger**: Webhook POST
**Purpose**: Generate AI products with safeguard checks

**Manual Trigger**:
```bash
curl -X POST "https://your-n8n.com/webhook/generate-products" \
  -H "Content-Type: application/json" \
  -d '{
    "niche": "dog-breed-specific",
    "subNiche": "golden-retriever",
    "batchSize": 5,
    "productType": "pod_tshirt",
    "targetPlatform": "etsy"
  }'
```

**Parameters**:
| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| niche | Yes | - | Main niche category |
| subNiche | No | niche | Specific sub-niche |
| batchSize | No | 1 | Products to generate (1-10) |
| productType | No | pod_tshirt | Product type |
| targetPlatform | No | etsy | Target marketplace |

**Troubleshooting**:
| Issue | Cause | Fix |
|-------|-------|-----|
| Products rejected | Trademark hit | Review title/tags |
| Low quality score | Generic content | Refine prompts |
| Image generation fails | Replicate quota | Check API limits |
| Timeout | Large batch | Reduce batch size |

### 2.3 Platform Publishers (Workflows #03-05)

#### Printify Publisher (#03)
**Schedule**: Every 4 hours
**Prerequisites**: Product approved, not yet published to Printify

**Manual Trigger**:
```bash
curl -X POST "https://your-n8n.com/webhook/publish-printify" \
  -d '{"productId": "prod_123"}'
```

#### Etsy Publisher (#04)
**Schedule**: Every 6 hours
**Prerequisites**: Product on Printify, not yet on Etsy

**Important**: Etsy charges $0.20 per listing. Budget accordingly.

#### Gumroad Publisher (#05)
**Schedule**: Every 6 hours
**Prerequisites**: Digital product, approved

### 2.4 Revenue Aggregator (Workflow #06)
**Schedule**: Every 12 hours
**Purpose**: Sync sales from all platforms

**Manual Trigger**:
```bash
curl -X POST "https://your-n8n.com/webhook/sync-revenue"
```

### 2.5 Daily Report (Workflow #07)
**Schedule**: Daily at 9:00 AM
**Output**: Slack message with full metrics

### 2.6 Batch Processor (Workflow #08)
**Trigger**: Webhook POST
**Purpose**: Large-scale product generation

**Example - Generate 50 products**:
```bash
curl -X POST "https://your-n8n.com/webhook/batch-generate" \
  -H "Content-Type: application/json" \
  -d '{
    "niche": "dog-breed-specific",
    "subNiches": ["golden-retriever", "labrador", "husky"],
    "totalProducts": 50,
    "productTypes": ["pod_tshirt", "pod_mug"],
    "qualityTier": "standard"
  }'
```

---

## 3. Troubleshooting Guide

### 3.1 Common Errors

#### "Rate limit exceeded"
```
Cause: Too many API calls in short period
Fix: 
1. Wait 60 seconds
2. Reduce batch sizes
3. Check API_RATE_LIMIT_DELAY in .env
```

#### "Budget exhausted"
```
Cause: Daily AI spend limit reached
Fix:
1. Wait until next day (resets at midnight UTC)
2. Increase MAX_DAILY_AI_SPEND in .env
3. Review cost optimization (use economy tier)
```

#### "Trademark violation detected"
```
Cause: Product contains protected terms
Fix:
1. Review flagged keywords
2. Modify title/description/tags
3. Avoid brand names, sports teams, etc.
```

#### "Quality score too low"
```
Cause: Generated content doesn't meet threshold
Fix:
1. Improve prompt specificity
2. Check for placeholder text
3. Ensure proper tag count (5-13)
4. Verify description length (>100 chars)
```

#### "OAuth token expired"
```
Cause: Etsy token needs refresh
Fix:
1. Check token expiry in platform_credentials table
2. Re-authenticate via OAuth flow
3. Update tokens in n8n credentials
```

### 3.2 Platform-Specific Issues

#### Printify
| Error | Solution |
|-------|----------|
| "Shop not found" | Verify PRINTIFY_SHOP_ID |
| "Image upload failed" | Check image URL accessibility |
| "Invalid blueprint" | Verify blueprint_id in templates |

#### Etsy
| Error | Solution |
|-------|----------|
| "Listing limit reached" | Upgrade Etsy plan or wait |
| "Invalid taxonomy" | Check TAXONOMY_MAP mapping |
| "Image too small" | Ensure min 2000x2000px |

#### Gumroad
| Error | Solution |
|-------|----------|
| "Invalid token" | Regenerate access token |
| "Product creation failed" | Check price minimum ($0.99) |

---

## 4. Scaling Operations

### 4.1 Growth Phases

#### Phase 1: Foundation (Month 1)
- **Products**: 50-100 total
- **Niches**: 2-3 focused
- **Daily Generation**: 5-10
- **Budget**: $30-50/month

#### Phase 2: Expansion (Months 2-3)
- **Products**: 200-500 total
- **Niches**: 5-7
- **Daily Generation**: 10-20
- **Budget**: $50-75/month

#### Phase 3: Optimization (Months 4-6)
- **Products**: 500-1000+
- **Niches**: 10+ with proven winners
- **Daily Generation**: 20-50
- **Budget**: $75-100/month

### 4.2 When to Scale Up

✅ Scale up when:
- Approval rate > 85%
- Conversion rate improving
- Budget < 50% utilized
- Revenue growing month-over-month

❌ Hold scaling when:
- Approval rate < 70%
- High rejection rate
- Budget consistently maxed
- Platform warnings/suspensions

### 4.3 Infrastructure Scaling

**VPS Upgrades**:
| Stage | RAM | CPU | Cost |
|-------|-----|-----|------|
| Start | 2GB | 1 vCPU | $5/mo |
| Growth | 4GB | 2 vCPU | $15/mo |
| Scale | 8GB | 4 vCPU | $30/mo |

**Database (Supabase)**:
| Stage | Plan | Cost |
|-------|------|------|
| Start | Free | $0 |
| Growth | Pro | $25/mo |
| Scale | Pro+ | $50+/mo |

---

## 5. Weekly Maintenance

### Monday: Review & Plan
- [ ] Analyze previous week's metrics
- [ ] Identify top-performing niches
- [ ] Plan new niche exploration
- [ ] Review rejected products

### Wednesday: Optimization
- [ ] Adjust AI prompts if needed
- [ ] Update niche scores
- [ ] Test new product types
- [ ] Review cost efficiency

### Friday: Cleanup
- [ ] Archive inactive products
- [ ] Clear old logs
- [ ] Backup database
- [ ] Update documentation

---

## 6. Emergency Procedures

### Platform Account Suspension
```
1. STOP all automation immediately
2. Review recent products for violations
3. Contact platform support
4. Do NOT create new accounts
5. Wait for resolution before resuming
```

### Budget Overrun
```
1. Pause all generation workflows
2. Review AI cost logs
3. Identify expensive operations
4. Reduce quality tier if needed
5. Set stricter daily limits
```

### Database Issues
```
1. Check Supabase status page
2. Verify connection credentials
3. Review RLS policies
4. Check for quota limits
5. Contact Supabase support if needed
```

---

## 7. Key Metrics Dashboard

### Revenue Targets
| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| Monthly Revenue | $1,000+ | < $500 | < $200 |
| Daily Revenue | $33+ | < $15 | < $5 |
| Net Margin | > 60% | < 40% | < 20% |

### Operations Targets
| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| Approval Rate | > 85% | < 70% | < 50% |
| Platform Uptime | 100% | < 99% | < 95% |
| AI Cost/Product | < $0.05 | > $0.08 | > $0.12 |

### Quality Targets
| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| Quality Score | > 80 | < 70 | < 60 |
| Trademark Hits | 0% | > 5% | > 10% |
| Customer Complaints | 0 | > 2/week | > 5/week |

---

## 8. Contact & Support

### Platform Support
- **Printify**: support@printify.com
- **Etsy**: developers@etsy.com
- **Gumroad**: support@gumroad.com

### API Documentation
- Printify: https://developers.printify.com
- Etsy: https://developer.etsy.com
- Gumroad: https://gumroad.com/api
- Replicate: https://replicate.com/docs
- OpenAI: https://platform.openai.com/docs

### Community
- n8n Community: https://community.n8n.io
- Supabase Discord: https://discord.supabase.com

---

*Last Updated: December 2025*
*Version: 1.0.0*
