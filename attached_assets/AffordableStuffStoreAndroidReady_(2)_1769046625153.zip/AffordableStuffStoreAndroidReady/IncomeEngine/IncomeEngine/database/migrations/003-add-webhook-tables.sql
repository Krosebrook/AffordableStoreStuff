-- ============================================================================
-- MIGRATION 003: Add Webhook Queue and Notification Tables
-- ============================================================================
-- Required for the notification/webhook utility system
-- Run after 002-add-connector-tables.sql
-- ============================================================================

-- ============================================================================
-- WEBHOOK ENDPOINTS
-- Stores configured webhook endpoints for event notifications
-- ============================================================================

CREATE TABLE IF NOT EXISTS webhook_endpoints (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID, -- Optional for multi-tenant
    url TEXT NOT NULL,
    name TEXT,
    description TEXT,
    -- Security
    secret TEXT, -- HMAC secret for signature verification
    secret_encrypted TEXT, -- Encrypted version of secret
    -- Configuration
    events TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[], -- Array of event types to receive
    enabled BOOLEAN DEFAULT TRUE,
    -- Delivery settings
    max_retries INTEGER DEFAULT 5,
    retry_delay_ms INTEGER DEFAULT 1000,
    timeout_ms INTEGER DEFAULT 10000,
    -- Health tracking
    consecutive_failures INTEGER DEFAULT 0,
    last_success_at TIMESTAMPTZ,
    last_failure_at TIMESTAMPTZ,
    last_failure_reason TEXT,
    is_healthy BOOLEAN DEFAULT TRUE,
    -- Auto-disable after too many failures
    auto_disable_threshold INTEGER DEFAULT 10,
    disabled_at TIMESTAMPTZ,
    disabled_reason TEXT,
    -- Metadata
    headers JSONB DEFAULT '{}'::JSONB, -- Custom headers to send
    metadata JSONB DEFAULT '{}'::JSONB,
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for webhook endpoints
CREATE INDEX idx_webhook_endpoints_enabled ON webhook_endpoints(enabled, is_healthy);
CREATE INDEX idx_webhook_endpoints_events ON webhook_endpoints USING GIN(events);
CREATE INDEX idx_webhook_endpoints_user ON webhook_endpoints(user_id) WHERE user_id IS NOT NULL;

-- ============================================================================
-- WEBHOOK QUEUE
-- Queue for pending webhook deliveries with retry support
-- ============================================================================

CREATE TABLE IF NOT EXISTS webhook_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_endpoint_id UUID REFERENCES webhook_endpoints(id) ON DELETE CASCADE,
    webhook_url TEXT NOT NULL, -- Denormalized for standalone deliveries
    -- Payload
    payload JSONB NOT NULL,
    event_type TEXT NOT NULL,
    -- Delivery status
    status TEXT CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')) DEFAULT 'pending',
    -- Retry tracking
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 5,
    next_retry_at TIMESTAMPTZ DEFAULT NOW(),
    last_error TEXT,
    last_status_code INTEGER,
    -- Timing
    first_attempt_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    failed_at TIMESTAMPTZ,
    -- Priority (lower = higher priority)
    priority INTEGER DEFAULT 5,
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for webhook queue
CREATE INDEX idx_webhook_queue_status ON webhook_queue(status, next_retry_at) WHERE status = 'pending';
CREATE INDEX idx_webhook_queue_endpoint ON webhook_queue(webhook_endpoint_id, status);
CREATE INDEX idx_webhook_queue_event ON webhook_queue(event_type, created_at DESC);
CREATE INDEX idx_webhook_queue_priority ON webhook_queue(priority, created_at) WHERE status = 'pending';

-- ============================================================================
-- WEBHOOK LOG
-- Detailed log of all webhook delivery attempts
-- ============================================================================

CREATE TABLE IF NOT EXISTS webhook_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_queue_id UUID REFERENCES webhook_queue(id) ON DELETE SET NULL,
    webhook_endpoint_id UUID REFERENCES webhook_endpoints(id) ON DELETE SET NULL,
    -- Request info
    event TEXT NOT NULL,
    url TEXT NOT NULL,
    method TEXT DEFAULT 'POST',
    request_headers JSONB,
    request_body_hash TEXT, -- SHA256 hash of body for dedup
    -- Response info
    success BOOLEAN NOT NULL,
    status_code INTEGER,
    response_headers JSONB,
    response_body TEXT, -- Truncated response for debugging
    error TEXT,
    -- Timing
    duration_ms INTEGER,
    attempt INTEGER DEFAULT 1,
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for webhook log
CREATE INDEX idx_webhook_log_queue ON webhook_log(webhook_queue_id);
CREATE INDEX idx_webhook_log_endpoint ON webhook_log(webhook_endpoint_id, created_at DESC);
CREATE INDEX idx_webhook_log_event ON webhook_log(event, success, created_at DESC);
CREATE INDEX idx_webhook_log_time ON webhook_log(created_at DESC);

-- Partitioning hint: For high volume, consider partitioning by created_at
-- CREATE TABLE webhook_log_2025_01 PARTITION OF webhook_log FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');

-- ============================================================================
-- WEBHOOK EVENT TYPES ENUM (Reference table)
-- ============================================================================

CREATE TABLE IF NOT EXISTS webhook_event_types (
    event_type TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    description TEXT,
    category TEXT CHECK (category IN ('inventory', 'order', 'product', 'budget', 'system')) NOT NULL,
    severity TEXT CHECK (severity IN ('info', 'warning', 'error', 'critical')) DEFAULT 'info',
    payload_schema JSONB, -- JSON Schema for expected payload
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed webhook event types
INSERT INTO webhook_event_types (event_type, display_name, description, category, severity) VALUES
('low_stock_alert', 'Low Stock Alert', 'Inventory fell below threshold', 'inventory', 'warning'),
('out_of_stock', 'Out of Stock', 'Product completely out of stock', 'inventory', 'critical'),
('order_received', 'Order Received', 'New order placed on a platform', 'order', 'info'),
('order_fulfilled', 'Order Fulfilled', 'Order has been shipped', 'order', 'info'),
('order_cancelled', 'Order Cancelled', 'Order was cancelled', 'order', 'warning'),
('product_published', 'Product Published', 'Product successfully listed on platform', 'product', 'info'),
('product_rejected', 'Product Rejected', 'Product failed quality/trademark check', 'product', 'warning'),
('budget_warning', 'Budget Warning', 'Approaching budget limit (80%)', 'budget', 'warning'),
('budget_critical', 'Budget Critical', 'Budget nearly exhausted (95%)', 'budget', 'critical'),
('platform_error', 'Platform Error', 'Error communicating with platform', 'system', 'error'),
('safeguard_triggered', 'Safeguard Triggered', 'A safeguard blocked an action', 'system', 'warning')
ON CONFLICT (event_type) DO NOTHING;

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to update webhook endpoint health status
CREATE OR REPLACE FUNCTION update_webhook_endpoint_health(
    p_endpoint_id UUID,
    p_success BOOLEAN,
    p_error TEXT DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
    IF p_success THEN
        UPDATE webhook_endpoints
        SET
            consecutive_failures = 0,
            last_success_at = NOW(),
            is_healthy = TRUE,
            updated_at = NOW()
        WHERE id = p_endpoint_id;
    ELSE
        UPDATE webhook_endpoints
        SET
            consecutive_failures = consecutive_failures + 1,
            last_failure_at = NOW(),
            last_failure_reason = p_error,
            is_healthy = CASE
                WHEN consecutive_failures + 1 >= auto_disable_threshold THEN FALSE
                ELSE is_healthy
            END,
            enabled = CASE
                WHEN consecutive_failures + 1 >= auto_disable_threshold THEN FALSE
                ELSE enabled
            END,
            disabled_at = CASE
                WHEN consecutive_failures + 1 >= auto_disable_threshold THEN NOW()
                ELSE disabled_at
            END,
            disabled_reason = CASE
                WHEN consecutive_failures + 1 >= auto_disable_threshold
                THEN 'Auto-disabled after ' || (consecutive_failures + 1) || ' consecutive failures'
                ELSE disabled_reason
            END,
            updated_at = NOW()
        WHERE id = p_endpoint_id;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to get pending webhooks for processing
CREATE OR REPLACE FUNCTION get_pending_webhooks(
    p_limit INTEGER DEFAULT 10
)
RETURNS TABLE (
    id UUID,
    webhook_url TEXT,
    payload JSONB,
    event_type TEXT,
    attempts INTEGER,
    max_attempts INTEGER
) AS $$
BEGIN
    RETURN QUERY
    WITH claimed AS (
        UPDATE webhook_queue q
        SET
            status = 'processing',
            first_attempt_at = COALESCE(first_attempt_at, NOW())
        WHERE q.id IN (
            SELECT wq.id
            FROM webhook_queue wq
            WHERE wq.status = 'pending'
              AND wq.next_retry_at <= NOW()
            ORDER BY wq.priority, wq.created_at
            LIMIT p_limit
            FOR UPDATE SKIP LOCKED
        )
        RETURNING q.id, q.webhook_url, q.payload, q.event_type, q.attempts, q.max_attempts
    )
    SELECT * FROM claimed;
END;
$$ LANGUAGE plpgsql;

-- Function to cleanup old webhook logs (retention policy)
CREATE OR REPLACE FUNCTION cleanup_webhook_logs(
    p_retention_days INTEGER DEFAULT 30
)
RETURNS INTEGER AS $$
DECLARE
    v_deleted INTEGER;
BEGIN
    WITH deleted AS (
        DELETE FROM webhook_log
        WHERE created_at < NOW() - (p_retention_days || ' days')::INTERVAL
        RETURNING 1
    )
    SELECT COUNT(*) INTO v_deleted FROM deleted;

    -- Also cleanup completed queue items older than 7 days
    DELETE FROM webhook_queue
    WHERE status IN ('completed', 'failed', 'cancelled')
      AND created_at < NOW() - INTERVAL '7 days';

    RETURN v_deleted;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update webhook endpoint updated_at on any change
CREATE OR REPLACE FUNCTION update_webhook_endpoint_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_webhook_endpoint_timestamp
    BEFORE UPDATE ON webhook_endpoints
    FOR EACH ROW
    EXECUTE FUNCTION update_webhook_endpoint_timestamp();

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE webhook_endpoints ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_event_types ENABLE ROW LEVEL SECURITY;

-- Service role policies
CREATE POLICY "Service role full access" ON webhook_endpoints FOR ALL USING (true);
CREATE POLICY "Service role full access" ON webhook_queue FOR ALL USING (true);
CREATE POLICY "Service role full access" ON webhook_log FOR ALL USING (true);
CREATE POLICY "Service role full access" ON webhook_event_types FOR ALL USING (true);

-- ============================================================================
-- VERSION TRACKING
-- ============================================================================

INSERT INTO schema_versions (version, description)
VALUES ('2.2.0', 'Added webhook queue, webhook log, webhook endpoints, and webhook event types tables')
ON CONFLICT (version) DO NOTHING;
