-- ============================================================================
-- PRICING OPTIMIZER - DATABASE MIGRATION
-- Migration 007: Intelligent Pricing Optimizer Tables
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- COMPETITOR MONITORING TABLES
-- ============================================================================

-- Competitors registry
CREATE TABLE IF NOT EXISTS pricing_competitors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    platform TEXT NOT NULL,
    url TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_scraped TIMESTAMPTZ,
    scrape_frequency TEXT CHECK (scrape_frequency IN ('hourly', 'daily', 'weekly')) DEFAULT 'daily',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Competitor products
CREATE TABLE IF NOT EXISTS pricing_competitor_products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    competitor_id UUID NOT NULL REFERENCES pricing_competitors(id) ON DELETE CASCADE,
    external_id TEXT NOT NULL,
    our_product_id UUID,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    image_url TEXT,
    current_price DECIMAL(12,2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    availability TEXT CHECK (availability IN ('in_stock', 'out_of_stock', 'limited', 'unknown')) DEFAULT 'unknown',
    rating DECIMAL(3,2),
    review_count INTEGER,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(competitor_id, external_id)
);

-- Price history
CREATE TABLE IF NOT EXISTS pricing_price_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    competitor_product_id UUID NOT NULL REFERENCES pricing_competitor_products(id) ON DELETE CASCADE,
    price DECIMAL(12,2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    availability TEXT,
    scraped_at TIMESTAMPTZ DEFAULT NOW()
);

-- Price alerts
CREATE TABLE IF NOT EXISTS pricing_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID,
    competitor_product_id UUID REFERENCES pricing_competitor_products(id) ON DELETE CASCADE,
    alert_type TEXT CHECK (alert_type IN ('price_drop', 'price_increase', 'out_of_stock', 'back_in_stock', 'new_competitor')) NOT NULL,
    previous_value TEXT NOT NULL,
    current_value TEXT NOT NULL,
    percent_change DECIMAL(8,2),
    severity TEXT CHECK (severity IN ('low', 'medium', 'high', 'critical')) DEFAULT 'medium',
    is_acknowledged BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for competitor monitoring
CREATE INDEX IF NOT EXISTS idx_pricing_competitors_active ON pricing_competitors(is_active, last_scraped);
CREATE INDEX IF NOT EXISTS idx_pricing_competitor_products_competitor ON pricing_competitor_products(competitor_id);
CREATE INDEX IF NOT EXISTS idx_pricing_competitor_products_our_product ON pricing_competitor_products(our_product_id);
CREATE INDEX IF NOT EXISTS idx_pricing_price_history_product ON pricing_price_history(competitor_product_id, scraped_at DESC);
CREATE INDEX IF NOT EXISTS idx_pricing_alerts_unacknowledged ON pricing_alerts(is_acknowledged, created_at DESC) WHERE NOT is_acknowledged;
CREATE INDEX IF NOT EXISTS idx_pricing_alerts_product ON pricing_alerts(product_id, created_at DESC);

-- ============================================================================
-- DEMAND ANALYSIS TABLES
-- ============================================================================

-- Sales data for elasticity and seasonality analysis
CREATE TABLE IF NOT EXISTS pricing_sales_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL,
    date DATE NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    revenue DECIMAL(12,2) NOT NULL DEFAULT 0,
    price DECIMAL(12,2) NOT NULL,
    platform TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(product_id, date, platform)
);

-- Conversion data for price vs conversion analysis
CREATE TABLE IF NOT EXISTS pricing_conversion_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL,
    date DATE NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    views INTEGER NOT NULL DEFAULT 0,
    add_to_cart INTEGER NOT NULL DEFAULT 0,
    purchases INTEGER NOT NULL DEFAULT 0,
    platform TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(product_id, date, platform)
);

-- Indexes for demand analysis
CREATE INDEX IF NOT EXISTS idx_pricing_sales_data_product ON pricing_sales_data(product_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_pricing_sales_data_platform ON pricing_sales_data(platform, date DESC);
CREATE INDEX IF NOT EXISTS idx_pricing_conversion_data_product ON pricing_conversion_data(product_id, date DESC);

-- ============================================================================
-- PRICING RULES TABLES
-- ============================================================================

-- Pricing rules
CREATE TABLE IF NOT EXISTS pricing_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    condition JSONB NOT NULL,
    action JSONB NOT NULL,
    priority INTEGER DEFAULT 0,
    is_enabled BOOLEAN DEFAULT TRUE,
    applies_to JSONB DEFAULT '{}'::JSONB,
    schedule JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Pricing recommendations cache
CREATE TABLE IF NOT EXISTS pricing_recommendations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL UNIQUE,
    current_price DECIMAL(12,2) NOT NULL,
    recommended_price DECIMAL(12,2) NOT NULL,
    confidence DECIMAL(4,3) NOT NULL,
    reasoning JSONB NOT NULL DEFAULT '[]'::JSONB,
    factors JSONB NOT NULL DEFAULT '[]'::JSONB,
    projected_impact JSONB NOT NULL DEFAULT '{}'::JSONB,
    applied_rules JSONB NOT NULL DEFAULT '[]'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

-- Indexes for pricing rules
CREATE INDEX IF NOT EXISTS idx_pricing_rules_enabled ON pricing_rules(is_enabled, priority DESC);
CREATE INDEX IF NOT EXISTS idx_pricing_recommendations_product ON pricing_recommendations(product_id);
CREATE INDEX IF NOT EXISTS idx_pricing_recommendations_expires ON pricing_recommendations(expires_at) WHERE expires_at > NOW();

-- ============================================================================
-- A/B TESTING TABLES
-- ============================================================================

-- Pricing experiments
CREATE TABLE IF NOT EXISTS pricing_experiments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    product_id UUID NOT NULL,
    status TEXT CHECK (status IN ('draft', 'running', 'paused', 'completed', 'cancelled')) DEFAULT 'draft',
    variants JSONB NOT NULL DEFAULT '[]'::JSONB,
    traffic_allocation JSONB NOT NULL DEFAULT '{"method": "random"}'::JSONB,
    primary_metric TEXT CHECK (primary_metric IN ('revenue', 'conversion_rate', 'profit', 'units_sold')) DEFAULT 'revenue',
    secondary_metrics JSONB DEFAULT '[]'::JSONB,
    minimum_sample_size INTEGER DEFAULT 100,
    confidence_level DECIMAL(4,3) DEFAULT 0.95,
    start_date TIMESTAMPTZ,
    end_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Experiment variant assignments
CREATE TABLE IF NOT EXISTS pricing_experiment_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    experiment_id UUID NOT NULL REFERENCES pricing_experiments(id) ON DELETE CASCADE,
    visitor_id TEXT NOT NULL,
    variant_id TEXT NOT NULL,
    assigned_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(experiment_id, visitor_id)
);

-- Experiment events
CREATE TABLE IF NOT EXISTS pricing_experiment_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    experiment_id UUID NOT NULL REFERENCES pricing_experiments(id) ON DELETE CASCADE,
    variant_id TEXT NOT NULL,
    visitor_id TEXT NOT NULL,
    event_type TEXT CHECK (event_type IN ('view', 'add_to_cart', 'purchase')) NOT NULL,
    revenue DECIMAL(12,2),
    metadata JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for A/B testing
CREATE INDEX IF NOT EXISTS idx_pricing_experiments_status ON pricing_experiments(status, product_id);
CREATE INDEX IF NOT EXISTS idx_pricing_experiments_product ON pricing_experiments(product_id);
CREATE INDEX IF NOT EXISTS idx_pricing_experiment_assignments_experiment ON pricing_experiment_assignments(experiment_id);
CREATE INDEX IF NOT EXISTS idx_pricing_experiment_assignments_visitor ON pricing_experiment_assignments(visitor_id, experiment_id);
CREATE INDEX IF NOT EXISTS idx_pricing_experiment_events_experiment ON pricing_experiment_events(experiment_id, variant_id);
CREATE INDEX IF NOT EXISTS idx_pricing_experiment_events_created ON pricing_experiment_events(created_at DESC);

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to get daily experiment metrics
CREATE OR REPLACE FUNCTION get_experiment_daily_metrics(p_experiment_id UUID)
RETURNS TABLE (
    date TEXT,
    variant_id TEXT,
    visitors BIGINT,
    conversions BIGINT,
    revenue DECIMAL,
    conversion_rate DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    WITH daily_visitors AS (
        SELECT
            DATE(assigned_at)::TEXT as date,
            pea.variant_id,
            COUNT(DISTINCT visitor_id) as visitors
        FROM pricing_experiment_assignments pea
        WHERE experiment_id = p_experiment_id
        GROUP BY DATE(assigned_at), pea.variant_id
    ),
    daily_events AS (
        SELECT
            DATE(created_at)::TEXT as date,
            pee.variant_id,
            COUNT(CASE WHEN event_type = 'purchase' THEN 1 END) as conversions,
            COALESCE(SUM(CASE WHEN event_type = 'purchase' THEN pee.revenue END), 0) as revenue
        FROM pricing_experiment_events pee
        WHERE experiment_id = p_experiment_id
        GROUP BY DATE(created_at), pee.variant_id
    )
    SELECT
        COALESCE(v.date, e.date) as date,
        COALESCE(v.variant_id, e.variant_id) as variant_id,
        COALESCE(v.visitors, 0) as visitors,
        COALESCE(e.conversions, 0) as conversions,
        COALESCE(e.revenue, 0) as revenue,
        CASE
            WHEN COALESCE(v.visitors, 0) > 0
            THEN ROUND(COALESCE(e.conversions, 0)::DECIMAL / v.visitors * 100, 2)
            ELSE 0
        END as conversion_rate
    FROM daily_visitors v
    FULL OUTER JOIN daily_events e
        ON v.date = e.date AND v.variant_id = e.variant_id
    ORDER BY date DESC, variant_id;
END;
$$ LANGUAGE plpgsql;

-- Function to calculate price elasticity data
CREATE OR REPLACE FUNCTION get_elasticity_data(
    p_product_id UUID,
    p_start_date DATE DEFAULT NOW() - INTERVAL '90 days',
    p_end_date DATE DEFAULT NOW()
)
RETURNS TABLE (
    price DECIMAL,
    quantity INTEGER,
    revenue DECIMAL,
    date DATE
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        psd.price,
        psd.quantity,
        psd.revenue,
        psd.date
    FROM pricing_sales_data psd
    WHERE psd.product_id = p_product_id
        AND psd.date >= p_start_date
        AND psd.date <= p_end_date
    ORDER BY psd.date;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE pricing_competitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_competitor_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_price_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_sales_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_conversion_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_experiments ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_experiment_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricing_experiment_events ENABLE ROW LEVEL SECURITY;

-- Service role policies
CREATE POLICY "Service role full access" ON pricing_competitors FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_competitor_products FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_price_history FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_alerts FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_sales_data FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_conversion_data FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_rules FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_recommendations FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_experiments FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_experiment_assignments FOR ALL USING (true);
CREATE POLICY "Service role full access" ON pricing_experiment_events FOR ALL USING (true);

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update updated_at timestamp trigger
CREATE OR REPLACE FUNCTION update_pricing_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER pricing_competitors_updated_at
    BEFORE UPDATE ON pricing_competitors
    FOR EACH ROW
    EXECUTE FUNCTION update_pricing_updated_at();

CREATE TRIGGER pricing_rules_updated_at
    BEFORE UPDATE ON pricing_rules
    FOR EACH ROW
    EXECUTE FUNCTION update_pricing_updated_at();

CREATE TRIGGER pricing_experiments_updated_at
    BEFORE UPDATE ON pricing_experiments
    FOR EACH ROW
    EXECUTE FUNCTION update_pricing_updated_at();

-- ============================================================================
-- SCHEMA VERSION
-- ============================================================================

INSERT INTO schema_versions (version, description)
VALUES ('2.1.0', 'Pricing optimizer: competitor monitoring, demand analysis, rule engine, A/B testing')
ON CONFLICT (version) DO NOTHING;
