-- ============================================================================
-- MIGRATION 002: Add Platform Connection & Product Mapping Tables
-- ============================================================================
-- Required for the connector workflow system
-- Run after schema-v2.sql
-- ============================================================================

-- ============================================================================
-- PLATFORM CONNECTIONS
-- Stores user-specific platform connection status and settings
-- ============================================================================

CREATE TABLE IF NOT EXISTS platform_connections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform TEXT NOT NULL REFERENCES platform_connectors(platform),
    user_id UUID, -- Optional, for multi-tenant support
    connection_status TEXT CHECK (connection_status IN ('connected', 'disconnected', 'error', 'expired', 'pending')) DEFAULT 'disconnected',
    connection_error TEXT,
    settings JSONB DEFAULT '{}'::JSONB,
    -- Platform-specific settings like shop_domain, site_url, etc.
    shop_domain TEXT, -- For Shopify
    site_url TEXT, -- For WooCommerce
    shop_id TEXT, -- For Printify, Etsy
    -- Authentication
    last_auth_at TIMESTAMPTZ,
    auth_expires_at TIMESTAMPTZ,
    refresh_token_expires_at TIMESTAMPTZ,
    -- Sync status
    last_sync_at TIMESTAMPTZ,
    last_sync_status TEXT CHECK (last_sync_status IN ('success', 'partial', 'failed')),
    last_sync_error TEXT,
    sync_enabled BOOLEAN DEFAULT TRUE,
    -- Metrics
    products_synced INTEGER DEFAULT 0,
    orders_synced INTEGER DEFAULT 0,
    errors_24h INTEGER DEFAULT 0,
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(platform, user_id)
);

-- Indexes for platform connections
CREATE INDEX idx_platform_connections_status ON platform_connections(connection_status);
CREATE INDEX idx_platform_connections_platform ON platform_connections(platform);
CREATE INDEX idx_platform_connections_user ON platform_connections(user_id) WHERE user_id IS NOT NULL;

-- ============================================================================
-- PRODUCT PLATFORM MAPPINGS
-- Maps internal products to external platform listings
-- ============================================================================

CREATE TABLE IF NOT EXISTS product_platform_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL,
    platform TEXT NOT NULL,
    external_id TEXT, -- Platform-specific product ID (ASIN, listing_id, etc.)
    external_url TEXT, -- URL to the product on the platform
    external_sku TEXT, -- Platform SKU if different
    -- Status
    publish_status TEXT CHECK (publish_status IN ('draft', 'pending', 'published', 'failed', 'archived', 'unlisted')) DEFAULT 'draft',
    publish_error TEXT,
    published_at TIMESTAMPTZ,
    -- Sync tracking
    last_sync_at TIMESTAMPTZ,
    sync_status TEXT CHECK (sync_status IN ('synced', 'pending', 'failed', 'conflict')) DEFAULT 'pending',
    sync_direction TEXT CHECK (sync_direction IN ('push', 'pull', 'bidirectional')) DEFAULT 'push',
    -- Platform-specific data
    platform_data JSONB DEFAULT '{}'::JSONB,
    -- Pricing override (if different from base product)
    platform_price DECIMAL(10,2),
    platform_compare_price DECIMAL(10,2),
    platform_currency TEXT DEFAULT 'USD',
    -- Inventory
    inventory_tracked BOOLEAN DEFAULT FALSE,
    inventory_quantity INTEGER DEFAULT 0,
    inventory_policy TEXT CHECK (inventory_policy IN ('deny', 'continue')) DEFAULT 'deny',
    -- Analytics
    views_count INTEGER DEFAULT 0,
    sales_count INTEGER DEFAULT 0,
    revenue_total DECIMAL(12,2) DEFAULT 0,
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(product_id, platform)
);

-- Indexes for product mappings
CREATE INDEX idx_product_platform_mappings_product ON product_platform_mappings(product_id);
CREATE INDEX idx_product_platform_mappings_platform ON product_platform_mappings(platform, publish_status);
CREATE INDEX idx_product_platform_mappings_external ON product_platform_mappings(platform, external_id);
CREATE INDEX idx_product_platform_mappings_sync ON product_platform_mappings(sync_status, last_sync_at);

-- ============================================================================
-- PLATFORM CREDENTIALS
-- Secure storage for platform API keys and OAuth tokens
-- ============================================================================

CREATE TABLE IF NOT EXISTS platform_credentials (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform TEXT NOT NULL REFERENCES platform_connectors(platform),
    user_id UUID, -- Optional for multi-tenant
    credential_type TEXT CHECK (credential_type IN ('api_key', 'oauth2', 'basic_auth', 'custom')) NOT NULL,
    -- API Key auth
    api_key_encrypted TEXT,
    api_secret_encrypted TEXT,
    -- OAuth2 auth
    access_token_encrypted TEXT,
    refresh_token_encrypted TEXT,
    token_type TEXT DEFAULT 'Bearer',
    scope TEXT[],
    expires_at TIMESTAMPTZ,
    -- OAuth2 client credentials (for refresh)
    client_id TEXT,
    client_secret_encrypted TEXT,
    -- Status
    is_valid BOOLEAN DEFAULT TRUE,
    last_validated_at TIMESTAMPTZ,
    validation_error TEXT,
    -- Rotation tracking
    created_at TIMESTAMPTZ DEFAULT NOW(),
    rotated_at TIMESTAMPTZ,
    rotation_count INTEGER DEFAULT 0,
    -- Encryption metadata
    encryption_version INTEGER DEFAULT 1,
    encryption_key_id TEXT,
    UNIQUE(platform, user_id)
);

-- Index for credentials
CREATE INDEX idx_platform_credentials_platform ON platform_credentials(platform);
CREATE INDEX idx_platform_credentials_valid ON platform_credentials(is_valid, expires_at);

-- ============================================================================
-- INVENTORY LOG
-- Track inventory changes across platforms
-- ============================================================================

CREATE TABLE IF NOT EXISTS inventory_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL,
    platform TEXT NOT NULL,
    external_id TEXT,
    quantity INTEGER NOT NULL,
    previous_quantity INTEGER,
    change_amount INTEGER GENERATED ALWAYS AS (quantity - COALESCE(previous_quantity, 0)) STORED,
    update_type TEXT CHECK (update_type IN ('sale', 'restock', 'adjustment', 'sync', 'return', 'damaged')) NOT NULL,
    source TEXT CHECK (source IN ('platform', 'system', 'manual', 'webhook')) DEFAULT 'system',
    order_id TEXT, -- External order ID if sale
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for inventory log
CREATE INDEX idx_inventory_log_product ON inventory_log(product_id, created_at DESC);
CREATE INDEX idx_inventory_log_platform ON inventory_log(platform, created_at DESC);
CREATE INDEX idx_inventory_log_type ON inventory_log(update_type, created_at DESC);

-- ============================================================================
-- ORDERS TABLE
-- Unified orders from all marketplace platforms
-- ============================================================================

CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_order_id TEXT NOT NULL,
    platform TEXT NOT NULL,
    -- Status
    status TEXT CHECK (status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded', 'failed')) DEFAULT 'pending',
    payment_status TEXT CHECK (payment_status IN ('pending', 'authorized', 'paid', 'partially_refunded', 'refunded', 'failed')) DEFAULT 'pending',
    fulfillment_status TEXT CHECK (fulfillment_status IN ('unfulfilled', 'partial', 'fulfilled', 'restocking')) DEFAULT 'unfulfilled',
    -- Order data
    order_data JSONB NOT NULL,
    -- Financials
    subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
    tax DECIMAL(12,2) DEFAULT 0,
    shipping DECIMAL(12,2) DEFAULT 0,
    discount DECIMAL(12,2) DEFAULT 0,
    total DECIMAL(12,2) NOT NULL DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    -- Customer
    customer_email TEXT,
    customer_name TEXT,
    -- Fulfillment
    tracking_info JSONB,
    shipped_at TIMESTAMPTZ,
    delivered_at TIMESTAMPTZ,
    fulfilled_at TIMESTAMPTZ,
    -- Timestamps
    ordered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(platform, external_order_id)
);

-- Indexes for orders
CREATE INDEX idx_orders_platform ON orders(platform, status);
CREATE INDEX idx_orders_status ON orders(status, created_at DESC);
CREATE INDEX idx_orders_customer ON orders(customer_email);
CREATE INDEX idx_orders_time ON orders(created_at DESC);

-- ============================================================================
-- ALERTS TABLE
-- System alerts for low stock, errors, etc.
-- ============================================================================

CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type TEXT CHECK (type IN ('low_stock', 'sync_failed', 'auth_expired', 'rate_limit', 'api_error', 'platform_down', 'custom')) NOT NULL,
    severity TEXT CHECK (severity IN ('info', 'warning', 'error', 'critical')) DEFAULT 'info',
    title TEXT,
    message TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::JSONB,
    -- Status
    is_read BOOLEAN DEFAULT FALSE,
    is_acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_by TEXT,
    acknowledged_at TIMESTAMPTZ,
    -- Resolution
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_by TEXT,
    resolved_at TIMESTAMPTZ,
    resolution_notes TEXT,
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ
);

-- Indexes for alerts
CREATE INDEX idx_alerts_type ON alerts(type, severity);
CREATE INDEX idx_alerts_unread ON alerts(is_read, created_at DESC) WHERE NOT is_read;
CREATE INDEX idx_alerts_unresolved ON alerts(is_resolved, severity) WHERE NOT is_resolved;

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to update product platform mapping sync status
CREATE OR REPLACE FUNCTION update_mapping_sync_status()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    IF NEW.publish_status = 'published' AND OLD.publish_status != 'published' THEN
        NEW.published_at = NOW();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_mapping_sync_status
    BEFORE UPDATE ON product_platform_mappings
    FOR EACH ROW
    EXECUTE FUNCTION update_mapping_sync_status();

-- Function to update platform connection timestamp
CREATE OR REPLACE FUNCTION update_connection_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_connection_timestamp
    BEFORE UPDATE ON platform_connections
    FOR EACH ROW
    EXECUTE FUNCTION update_connection_timestamp();

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE platform_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_platform_mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;

-- Service role policies
CREATE POLICY "Service role full access" ON platform_connections FOR ALL USING (true);
CREATE POLICY "Service role full access" ON product_platform_mappings FOR ALL USING (true);
CREATE POLICY "Service role full access" ON platform_credentials FOR ALL USING (true);
CREATE POLICY "Service role full access" ON inventory_log FOR ALL USING (true);
CREATE POLICY "Service role full access" ON orders FOR ALL USING (true);
CREATE POLICY "Service role full access" ON alerts FOR ALL USING (true);

-- ============================================================================
-- VERSION TRACKING
-- ============================================================================

INSERT INTO schema_versions (version, description)
VALUES ('2.1.0', 'Added platform connections, product mappings, credentials, inventory log, orders, and alerts tables')
ON CONFLICT (version) DO NOTHING;
