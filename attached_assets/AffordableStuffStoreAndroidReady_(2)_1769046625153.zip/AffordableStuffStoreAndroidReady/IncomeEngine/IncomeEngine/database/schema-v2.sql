-- ============================================================================
-- PASSIVE INCOME SAFEGUARDS - DATABASE SCHEMA V2
-- ============================================================================
-- Complete schema including all tables from original + new production tables
-- Database: Supabase PostgreSQL with RLS enabled
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "vector"; -- For AI embeddings

-- ============================================================================
-- NEW TABLES: WORKFLOW & AUDIT
-- ============================================================================

-- Workflow execution tracking (for n8n integration)
CREATE TABLE workflow_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id TEXT NOT NULL,
    run_id TEXT UNIQUE NOT NULL,
    workflow_name TEXT,
    status TEXT CHECK (status IN ('running', 'completed', 'failed', 'cancelled', 'waiting')) DEFAULT 'running',
    trigger_type TEXT CHECK (trigger_type IN ('scheduled', 'manual', 'webhook', 'event')),
    input_data JSONB,
    output_data JSONB,
    error_message TEXT,
    error_stack TEXT,
    retry_count INTEGER DEFAULT 0,
    parent_execution_id UUID REFERENCES workflow_executions(id),
    started_at TIMESTAMPTZ DEFAULT NOW(),
    ended_at TIMESTAMPTZ,
    duration_ms INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for workflow queries
CREATE INDEX idx_workflow_executions_status ON workflow_executions(status);
CREATE INDEX idx_workflow_executions_workflow ON workflow_executions(workflow_id, started_at DESC);
CREATE INDEX idx_workflow_executions_time ON workflow_executions(started_at DESC);

-- Safeguard audit log (decision tracking)
CREATE TABLE safeguard_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID,
    safeguard_name TEXT NOT NULL,
    safeguard_version TEXT DEFAULT '1.0',
    decision TEXT CHECK (decision IN ('pass', 'fail', 'warn', 'skip', 'error')) NOT NULL,
    reason TEXT,
    score DECIMAL(5,4),
    threshold DECIMAL(5,4),
    execution_time_ms INTEGER,
    metadata JSONB DEFAULT '{}'::JSONB,
    input_hash TEXT, -- Hash of input for deduplication
    workflow_execution_id UUID REFERENCES workflow_executions(id),
    assessed_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for audit queries
CREATE INDEX idx_safeguard_audit_product ON safeguard_audit_log(product_id, assessed_at DESC);
CREATE INDEX idx_safeguard_audit_safeguard ON safeguard_audit_log(safeguard_name, decision);
CREATE INDEX idx_safeguard_audit_time ON safeguard_audit_log(assessed_at DESC);

-- ============================================================================
-- NEW TABLES: TAX & COMPLIANCE
-- ============================================================================

-- Nexus tracking (tax compliance)
CREATE TABLE nexus_tracking (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    jurisdiction TEXT NOT NULL,
    jurisdiction_type TEXT CHECK (jurisdiction_type IN ('us_state', 'us_territory', 'eu_country', 'uk', 'canada_province', 'australia', 'other')) NOT NULL,
    year INTEGER NOT NULL,
    cumulative_sales_usd DECIMAL(12,2) DEFAULT 0,
    transaction_count INTEGER DEFAULT 0,
    threshold_usd DECIMAL(12,2) NOT NULL,
    threshold_type TEXT CHECK (threshold_type IN ('sales', 'transactions', 'both')) DEFAULT 'sales',
    threshold_exceeded BOOLEAN DEFAULT FALSE,
    threshold_exceeded_at TIMESTAMPTZ,
    registration_required BOOLEAN DEFAULT FALSE,
    registration_status TEXT CHECK (registration_status IN ('not_required', 'pending', 'registered', 'exempt')) DEFAULT 'not_required',
    registration_number TEXT,
    registration_date DATE,
    next_filing_date DATE,
    notes TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(jurisdiction, year)
);

-- Index for nexus queries
CREATE INDEX idx_nexus_jurisdiction ON nexus_tracking(jurisdiction, year);
CREATE INDEX idx_nexus_threshold ON nexus_tracking(threshold_exceeded, registration_required);

-- ============================================================================
-- NEW TABLES: SECURITY & CREDENTIALS
-- ============================================================================

-- Credential audit log
CREATE TABLE credential_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    credential_id UUID,
    credential_type TEXT CHECK (credential_type IN ('api_key', 'oauth_token', 'webhook_secret', 'encryption_key')),
    platform TEXT,
    action TEXT CHECK (action IN ('created', 'accessed', 'rotated', 'revoked', 'expired', 'failed_auth')) NOT NULL,
    actor TEXT, -- User or system that performed action
    actor_type TEXT CHECK (actor_type IN ('user', 'system', 'agent', 'webhook')) DEFAULT 'system',
    ip_address INET,
    user_agent TEXT,
    success BOOLEAN DEFAULT TRUE,
    failure_reason TEXT,
    metadata JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for credential audit queries
CREATE INDEX idx_credential_audit_credential ON credential_audit_log(credential_id, created_at DESC);
CREATE INDEX idx_credential_audit_action ON credential_audit_log(action, created_at DESC);
CREATE INDEX idx_credential_audit_platform ON credential_audit_log(platform, created_at DESC);

-- Agent identities (AI Agent IAM)
CREATE TABLE agent_identities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_name TEXT UNIQUE NOT NULL,
    agent_type TEXT CHECK (agent_type IN ('workflow', 'mcp_server', 'cli', 'api', 'scheduled')) NOT NULL,
    public_key TEXT,
    key_algorithm TEXT DEFAULT 'RSA-2048',
    trust_anchor TEXT,
    privilege_level TEXT CHECK (privilege_level IN ('read', 'write', 'admin', 'superadmin')) DEFAULT 'read',
    scopes TEXT[] DEFAULT ARRAY[]::TEXT[],
    rate_limit_per_minute INTEGER DEFAULT 60,
    rate_limit_per_hour INTEGER DEFAULT 1000,
    is_active BOOLEAN DEFAULT TRUE,
    last_attestation TIMESTAMPTZ,
    attestation_valid_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent audit log
CREATE TABLE agent_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID REFERENCES agent_identities(id),
    action TEXT NOT NULL,
    resource_type TEXT,
    resource_id TEXT,
    outcome TEXT CHECK (outcome IN ('success', 'failure', 'denied', 'rate_limited')) NOT NULL,
    risk_score DECIMAL(3,2), -- 0.00 to 1.00
    human_override BOOLEAN DEFAULT FALSE,
    override_reason TEXT,
    override_by TEXT,
    request_metadata JSONB DEFAULT '{}'::JSONB,
    response_metadata JSONB DEFAULT '{}'::JSONB,
    execution_time_ms INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for agent audit
CREATE INDEX idx_agent_audit_agent ON agent_audit_log(agent_id, created_at DESC);
CREATE INDEX idx_agent_audit_action ON agent_audit_log(action, outcome);
CREATE INDEX idx_agent_audit_risk ON agent_audit_log(risk_score DESC) WHERE risk_score > 0.5;

-- ============================================================================
-- NEW TABLES: FEEDBACK & IMPROVEMENT
-- ============================================================================

-- Rejection feedback loop
CREATE TABLE rejection_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID,
    approval_queue_id UUID,
    rejection_reason TEXT NOT NULL,
    rejection_category TEXT CHECK (rejection_category IN ('quality', 'trademark', 'policy', 'technical', 'other')),
    feedback_themes TEXT[] DEFAULT ARRAY[]::TEXT[],
    improvement_actions JSONB DEFAULT '[]'::JSONB,
    severity TEXT CHECK (severity IN ('minor', 'moderate', 'major', 'critical')) DEFAULT 'moderate',
    resubmission_allowed BOOLEAN DEFAULT TRUE,
    resubmission_guidance TEXT,
    reviewed_by TEXT,
    applied_to_training BOOLEAN DEFAULT FALSE,
    applied_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for feedback queries
CREATE INDEX idx_rejection_feedback_product ON rejection_feedback(product_id);
CREATE INDEX idx_rejection_feedback_category ON rejection_feedback(rejection_category, severity);

-- ============================================================================
-- NEW TABLES: PLATFORM CONNECTORS
-- ============================================================================

-- Ecommerce platform connectors registry
CREATE TABLE platform_connectors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    platform TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT,
    logo_url TEXT,
    connector_type TEXT CHECK (connector_type IN ('built_in', 'oauth', 'api_key', 'webhook', 'scraper')) NOT NULL,
    workflow_group TEXT CHECK (workflow_group IN ('pod_digital', 'marketplace', 'digital_only', 'custom')) DEFAULT 'custom',
    status TEXT CHECK (status IN ('active', 'beta', 'coming_soon', 'deprecated', 'maintenance')) DEFAULT 'coming_soon',
    version TEXT DEFAULT '1.0.0',
    setup_guide_url TEXT,
    api_docs_url TEXT,
    required_credentials JSONB DEFAULT '[]'::JSONB,
    required_scopes TEXT[] DEFAULT ARRAY[]::TEXT[],
    rate_limits JSONB DEFAULT '{}'::JSONB,
    capabilities JSONB DEFAULT '{}'::JSONB,
    supported_product_types TEXT[] DEFAULT ARRAY[]::TEXT[],
    webhook_endpoints JSONB DEFAULT '[]'::JSONB,
    health_check_endpoint TEXT,
    last_health_check TIMESTAMPTZ,
    health_status TEXT CHECK (health_status IN ('healthy', 'degraded', 'offline', 'unknown')) DEFAULT 'unknown',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed platform connectors
INSERT INTO platform_connectors (platform, display_name, connector_type, workflow_group, status, capabilities, supported_product_types) VALUES
('printify', 'Printify', 'api_key', 'pod_digital', 'active',
 '{"create_product": true, "update_product": true, "delete_product": true, "get_analytics": true, "bulk_operations": true}'::JSONB,
 ARRAY['tshirt', 'hoodie', 'mug', 'poster', 'sticker', 'phone_case']),
('etsy', 'Etsy', 'oauth', 'pod_digital', 'active',
 '{"create_listing": true, "update_listing": true, "get_orders": true, "get_analytics": true}'::JSONB,
 ARRAY['tshirt', 'mug', 'sticker', 'digital', 'art_print']),
('gumroad', 'Gumroad', 'api_key', 'pod_digital', 'active',
 '{"create_product": true, "update_product": true, "get_sales": true, "webhooks": true}'::JSONB,
 ARRAY['digital', 'ebook', 'template', 'course']),
('shopify', 'Shopify', 'oauth', 'marketplace', 'active',
 '{"full_store_access": true, "inventory_sync": true, "order_management": true, "analytics": true}'::JSONB,
 ARRAY['all']),
('woocommerce', 'WooCommerce', 'api_key', 'marketplace', 'active',
 '{"full_store_access": true, "inventory_sync": true, "order_management": true}'::JSONB,
 ARRAY['all']),
('amazon_kdp', 'Amazon KDP', 'scraper', 'marketplace', 'beta',
 '{"create_book": true, "update_book": true, "get_sales": false}'::JSONB,
 ARRAY['ebook', 'paperback', 'hardcover']),
('redbubble', 'Redbubble', 'api_key', 'pod_digital', 'coming_soon',
 '{"create_design": true, "get_analytics": true}'::JSONB,
 ARRAY['tshirt', 'sticker', 'poster', 'phone_case']),
('teepublic', 'TeePublic', 'api_key', 'pod_digital', 'coming_soon',
 '{"create_design": true}'::JSONB,
 ARRAY['tshirt', 'hoodie', 'sticker']),
('creative_fabrica', 'Creative Fabrica', 'api_key', 'pod_digital', 'coming_soon',
 '{"upload_design": true, "get_sales": true}'::JSONB,
 ARRAY['digital', 'font', 'graphic', 'craft']),
('tiktok_shop', 'TikTok Shop', 'oauth', 'marketplace', 'beta',
 '{"create_product": true, "get_orders": true, "live_shopping": true}'::JSONB,
 ARRAY['physical', 'digital']);

-- ============================================================================
-- NEW TABLES: USER EXPERIENCE
-- ============================================================================

-- User walkthrough progress
CREATE TABLE user_walkthrough_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID,
    session_id TEXT,
    walkthrough_id TEXT NOT NULL,
    walkthrough_name TEXT,
    current_step INTEGER DEFAULT 0,
    total_steps INTEGER NOT NULL,
    completed_steps INTEGER[] DEFAULT ARRAY[]::INTEGER[],
    skipped_steps INTEGER[] DEFAULT ARRAY[]::INTEGER[],
    status TEXT CHECK (status IN ('not_started', 'in_progress', 'completed', 'skipped', 'abandoned')) DEFAULT 'not_started',
    completion_percent INTEGER DEFAULT 0,
    time_spent_seconds INTEGER DEFAULT 0,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    last_activity_at TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, walkthrough_id)
);

-- Walkthroughs registry
CREATE TABLE walkthroughs (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT CHECK (category IN ('onboarding', 'feature', 'setup', 'tutorial')) DEFAULT 'feature',
    steps JSONB NOT NULL, -- Array of step definitions
    prerequisites TEXT[] DEFAULT ARRAY[]::TEXT[], -- Other walkthrough IDs required
    estimated_minutes INTEGER,
    difficulty TEXT CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')) DEFAULT 'beginner',
    is_required BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed walkthroughs
INSERT INTO walkthroughs (id, name, description, category, steps, estimated_minutes, is_required) VALUES
('initial-setup', 'Initial Setup', 'Configure your income engine for the first time', 'onboarding',
 '[{"step": 1, "title": "Welcome", "content": "Welcome to AffordableStuffStore!"},
   {"step": 2, "title": "Connect Supabase", "content": "Add your Supabase credentials"},
   {"step": 3, "title": "Add API Keys", "content": "Configure OpenAI and other AI providers"},
   {"step": 4, "title": "Choose Platforms", "content": "Select which platforms to publish to"},
   {"step": 5, "title": "First Product", "content": "Create your first test product"}]'::JSONB,
 10, TRUE),
('platform-printify', 'Connect Printify', 'Set up Printify integration', 'setup',
 '[{"step": 1, "title": "Create Account", "content": "Sign up for Printify if you haven''t already"},
   {"step": 2, "title": "Get API Token", "content": "Generate your API access token"},
   {"step": 3, "title": "Add to Secrets", "content": "Save the token in Replit Secrets"},
   {"step": 4, "title": "Test Connection", "content": "Verify the connection works"}]'::JSONB,
 5, FALSE);

-- ============================================================================
-- NEW TABLES: ANALYTICS & MONITORING
-- ============================================================================

-- Analytics events
CREATE TABLE analytics_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type TEXT NOT NULL CHECK (event_type IN ('page_view', 'feature_use', 'error', 'conversion', 'custom')),
    event_name TEXT NOT NULL,
    event_category TEXT,
    properties JSONB DEFAULT '{}'::JSONB,
    user_id UUID,
    session_id TEXT,
    device_info JSONB DEFAULT '{}'::JSONB,
    geo_info JSONB DEFAULT '{}'::JSONB,
    referrer TEXT,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Partitioning for analytics (by month)
CREATE INDEX idx_analytics_events_type ON analytics_events(event_type, created_at DESC);
CREATE INDEX idx_analytics_events_name ON analytics_events(event_name, created_at DESC);
CREATE INDEX idx_analytics_events_time ON analytics_events(created_at DESC);

-- Performance metrics
CREATE TABLE performance_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    metric_name TEXT NOT NULL,
    metric_type TEXT CHECK (metric_type IN ('counter', 'gauge', 'histogram', 'summary')) NOT NULL,
    value DECIMAL(20,6) NOT NULL,
    labels JSONB DEFAULT '{}'::JSONB,
    recorded_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for metrics queries
CREATE INDEX idx_performance_metrics_name ON performance_metrics(metric_name, recorded_at DESC);

-- ============================================================================
-- NEW TABLES: MCP INTEGRATION
-- ============================================================================

-- MCP server registry
CREATE TABLE mcp_servers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    server_name TEXT UNIQUE NOT NULL,
    server_type TEXT CHECK (server_type IN ('local', 'remote', 'cloud')) DEFAULT 'local',
    server_url TEXT,
    command TEXT, -- For local servers
    args TEXT[] DEFAULT ARRAY[]::TEXT[],
    env_vars JSONB DEFAULT '{}'::JSONB,
    protocol_version TEXT DEFAULT '1.0',
    capabilities JSONB DEFAULT '{}'::JSONB,
    tools JSONB DEFAULT '[]'::JSONB, -- List of exposed tools
    resources JSONB DEFAULT '[]'::JSONB, -- List of exposed resources
    health_status TEXT CHECK (health_status IN ('healthy', 'degraded', 'offline', 'starting', 'stopping')) DEFAULT 'offline',
    last_health_check TIMESTAMPTZ,
    error_count_24h INTEGER DEFAULT 0,
    avg_response_time_ms INTEGER,
    is_enabled BOOLEAN DEFAULT TRUE,
    auto_start BOOLEAN DEFAULT TRUE,
    restart_on_failure BOOLEAN DEFAULT TRUE,
    max_restarts INTEGER DEFAULT 3,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed MCP servers
INSERT INTO mcp_servers (server_name, server_type, command, args, capabilities, tools) VALUES
('income-engine', 'local', 'node', ARRAY['mcp-server/dist/index.js'],
 '{"product_management": true, "analytics": true, "safeguards": true}'::JSONB,
 '[{"name": "create_product", "description": "Create a new product"},
   {"name": "check_trademark", "description": "Screen product for trademarks"},
   {"name": "approve_product", "description": "Approve a pending product"},
   {"name": "get_analytics", "description": "Get revenue and performance data"},
   {"name": "get_budget_status", "description": "Check current budget status"}]'::JSONB),
('supabase', 'local', 'npx', ARRAY['@supabase/mcp-server'],
 '{"database": true, "auth": true}'::JSONB,
 '[{"name": "query", "description": "Execute database query"},
   {"name": "insert", "description": "Insert records"},
   {"name": "update", "description": "Update records"}]'::JSONB);

-- MCP tool executions log
CREATE TABLE mcp_tool_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    server_name TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    input_params JSONB,
    output_result JSONB,
    execution_status TEXT CHECK (execution_status IN ('success', 'error', 'timeout', 'cancelled')) NOT NULL,
    error_message TEXT,
    execution_time_ms INTEGER,
    tokens_used INTEGER,
    agent_id UUID REFERENCES agent_identities(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for MCP executions
CREATE INDEX idx_mcp_tool_executions_server ON mcp_tool_executions(server_name, created_at DESC);
CREATE INDEX idx_mcp_tool_executions_tool ON mcp_tool_executions(tool_name, execution_status);

-- ============================================================================
-- SCHEMA ENHANCEMENTS: EXISTING TABLES
-- ============================================================================

-- Add columns to approval_queue (if table exists, use ALTER)
-- These are new columns to add to the existing approval_queue table
-- Run separately if upgrading existing installation:
-- ALTER TABLE approval_queue ADD COLUMN IF NOT EXISTS external_reviewer_id TEXT;
-- ALTER TABLE approval_queue ADD COLUMN IF NOT EXISTS appeal_requested BOOLEAN DEFAULT FALSE;
-- ALTER TABLE approval_queue ADD COLUMN IF NOT EXISTS final_decision_date TIMESTAMPTZ;
-- ALTER TABLE approval_queue ADD COLUMN IF NOT EXISTS escalation_level INTEGER DEFAULT 0;

-- Add columns to cost_events
-- ALTER TABLE cost_events ADD COLUMN IF NOT EXISTS currency TEXT DEFAULT 'USD';
-- ALTER TABLE cost_events ADD COLUMN IF NOT EXISTS estimated_cost DECIMAL(10,4);
-- ALTER TABLE cost_events ADD COLUMN IF NOT EXISTS actual_cost DECIMAL(10,4);
-- ALTER TABLE cost_events ADD COLUMN IF NOT EXISTS cost_category TEXT;

-- Add columns to products
-- ALTER TABLE products ADD COLUMN IF NOT EXISTS last_sales_check TIMESTAMPTZ;
-- ALTER TABLE products ADD COLUMN IF NOT EXISTS competitor_products UUID[];
-- ALTER TABLE products ADD COLUMN IF NOT EXISTS seasonal_keywords TEXT[];
-- ALTER TABLE products ADD COLUMN IF NOT EXISTS revenue_total_usd DECIMAL(12,2) DEFAULT 0;

-- ============================================================================
-- API COSTS TABLE (Moved from hardcoded values)
-- ============================================================================

CREATE TABLE api_costs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider TEXT NOT NULL,
    model TEXT NOT NULL,
    operation TEXT NOT NULL CHECK (operation IN ('input', 'output', 'image', 'embedding', 'audio', 'video')),
    cost_per_unit DECIMAL(12,8) NOT NULL,
    unit_type TEXT NOT NULL CHECK (unit_type IN ('token', 'image', 'second', 'character', 'request')),
    unit_count INTEGER DEFAULT 1000, -- e.g., cost per 1000 tokens
    effective_date DATE NOT NULL DEFAULT CURRENT_DATE,
    expiry_date DATE,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(provider, model, operation, effective_date)
);

-- Seed current API costs (December 2025)
INSERT INTO api_costs (provider, model, operation, cost_per_unit, unit_type, unit_count, notes) VALUES
-- OpenAI
('openai', 'gpt-4o', 'input', 0.0025, 'token', 1000, 'GPT-4o input tokens'),
('openai', 'gpt-4o', 'output', 0.01, 'token', 1000, 'GPT-4o output tokens'),
('openai', 'gpt-4o-mini', 'input', 0.00015, 'token', 1000, 'GPT-4o-mini input'),
('openai', 'gpt-4o-mini', 'output', 0.0006, 'token', 1000, 'GPT-4o-mini output'),
('openai', 'dall-e-3', 'image', 0.04, 'image', 1, 'DALL-E 3 standard 1024x1024'),
('openai', 'dall-e-3-hd', 'image', 0.08, 'image', 1, 'DALL-E 3 HD 1024x1024'),
('openai', 'text-embedding-3-small', 'embedding', 0.00002, 'token', 1000, 'Small embedding model'),
('openai', 'text-embedding-3-large', 'embedding', 0.00013, 'token', 1000, 'Large embedding model'),
-- Anthropic
('anthropic', 'claude-opus-4', 'input', 0.015, 'token', 1000, 'Claude Opus 4 input'),
('anthropic', 'claude-opus-4', 'output', 0.075, 'token', 1000, 'Claude Opus 4 output'),
('anthropic', 'claude-sonnet-4', 'input', 0.003, 'token', 1000, 'Claude Sonnet 4 input'),
('anthropic', 'claude-sonnet-4', 'output', 0.015, 'token', 1000, 'Claude Sonnet 4 output'),
('anthropic', 'claude-haiku-3.5', 'input', 0.0008, 'token', 1000, 'Claude Haiku 3.5 input'),
('anthropic', 'claude-haiku-3.5', 'output', 0.004, 'token', 1000, 'Claude Haiku 3.5 output'),
-- Replicate
('replicate', 'flux-schnell', 'image', 0.003, 'image', 1, 'Flux Schnell image'),
('replicate', 'flux-dev', 'image', 0.025, 'image', 1, 'Flux Dev image'),
('replicate', 'flux-pro', 'image', 0.05, 'image', 1, 'Flux Pro image'),
('replicate', 'sdxl', 'image', 0.002, 'image', 1, 'SDXL image'),
-- Stability
('stability', 'sd3', 'image', 0.035, 'image', 1, 'Stable Diffusion 3'),
('stability', 'sd3-turbo', 'image', 0.004, 'image', 1, 'SD3 Turbo'),
('stability', 'sdxl', 'image', 0.002, 'image', 1, 'SDXL image');

-- ============================================================================
-- FEATURE FLAGS
-- ============================================================================

CREATE TABLE feature_flags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flag_key TEXT UNIQUE NOT NULL,
    flag_name TEXT NOT NULL,
    description TEXT,
    flag_type TEXT CHECK (flag_type IN ('boolean', 'percentage', 'variant')) DEFAULT 'boolean',
    is_enabled BOOLEAN DEFAULT FALSE,
    percentage INTEGER CHECK (percentage BETWEEN 0 AND 100),
    variants JSONB DEFAULT '{}'::JSONB,
    targeting_rules JSONB DEFAULT '[]'::JSONB,
    environment TEXT CHECK (environment IN ('development', 'staging', 'production', 'all')) DEFAULT 'all',
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed feature flags
INSERT INTO feature_flags (flag_key, flag_name, description, is_enabled) VALUES
('auto_approve_enabled', 'Auto-Approval', 'Enable automatic product approval after threshold', FALSE),
('ai_content_humanization', 'AI Content Humanization', 'Add variations to AI-generated content', TRUE),
('multi_platform_sync', 'Multi-Platform Sync', 'Sync products across all connected platforms', TRUE),
('advanced_analytics', 'Advanced Analytics', 'Enable advanced analytics dashboard', FALSE),
('beta_connectors', 'Beta Connectors', 'Enable beta platform connectors', FALSE);

-- ============================================================================
-- ADDITIONAL HELPER FUNCTIONS
-- ============================================================================

-- Function to get API cost
CREATE OR REPLACE FUNCTION get_api_cost(
    p_provider TEXT,
    p_model TEXT,
    p_operation TEXT,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS DECIMAL(12,8) AS $$
DECLARE
    v_cost DECIMAL(12,8);
BEGIN
    SELECT cost_per_unit INTO v_cost
    FROM api_costs
    WHERE provider = p_provider
      AND model = p_model
      AND operation = p_operation
      AND effective_date <= p_date
      AND (expiry_date IS NULL OR expiry_date > p_date)
    ORDER BY effective_date DESC
    LIMIT 1;

    RETURN COALESCE(v_cost, 0);
END;
$$ LANGUAGE plpgsql;

-- Function to reserve budget atomically
CREATE OR REPLACE FUNCTION reserve_budget(
    p_amount DECIMAL,
    p_category TEXT,
    p_product_id UUID DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_daily_status RECORD;
    v_weekly_status RECORD;
    v_monthly_status RECORD;
    v_result JSONB;
BEGIN
    -- Lock budget config for update
    PERFORM * FROM budget_config FOR UPDATE;

    -- Check daily budget
    SELECT * INTO v_daily_status FROM get_budget_status('daily');
    IF v_daily_status.current_spend + p_amount > v_daily_status.limit_amount THEN
        RETURN jsonb_build_object(
            'success', FALSE,
            'reason', 'Daily budget would be exceeded',
            'budget_type', 'daily',
            'current_spend', v_daily_status.current_spend,
            'limit', v_daily_status.limit_amount,
            'requested', p_amount
        );
    END IF;

    -- Check weekly budget
    SELECT * INTO v_weekly_status FROM get_budget_status('weekly');
    IF v_weekly_status.current_spend + p_amount > v_weekly_status.limit_amount THEN
        RETURN jsonb_build_object(
            'success', FALSE,
            'reason', 'Weekly budget would be exceeded',
            'budget_type', 'weekly',
            'current_spend', v_weekly_status.current_spend,
            'limit', v_weekly_status.limit_amount,
            'requested', p_amount
        );
    END IF;

    -- Reserve is approved - record the cost
    INSERT INTO cost_events (service_name, operation, cost_usd, product_id, metadata)
    VALUES (p_category, 'reserved', p_amount, p_product_id,
            jsonb_build_object('type', 'reservation', 'timestamp', NOW()));

    RETURN jsonb_build_object(
        'success', TRUE,
        'reservation_id', gen_random_uuid(),
        'amount', p_amount,
        'daily_remaining', v_daily_status.limit_amount - v_daily_status.current_spend - p_amount,
        'weekly_remaining', v_weekly_status.limit_amount - v_weekly_status.current_spend - p_amount
    );
END;
$$ LANGUAGE plpgsql;

-- Function for safe product state transition
CREATE OR REPLACE FUNCTION transition_product_state(
    p_product_id UUID,
    p_new_state TEXT,
    p_metadata JSONB DEFAULT '{}'::JSONB
)
RETURNS JSONB AS $$
DECLARE
    v_current_state TEXT;
    v_valid_transitions JSONB;
BEGIN
    -- Define valid state transitions
    v_valid_transitions := '{
        "generating": ["quality_check", "failed"],
        "quality_check": ["trademark_check", "rejected", "failed"],
        "trademark_check": ["pending_approval", "rejected", "failed"],
        "pending_approval": ["approved", "rejected"],
        "approved": ["publishing", "rejected"],
        "publishing": ["published", "failed"],
        "published": [],
        "rejected": ["generating"],
        "failed": ["generating"]
    }'::JSONB;

    -- Get current state
    SELECT status INTO v_current_state
    FROM products
    WHERE id = p_product_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', FALSE, 'reason', 'Product not found');
    END IF;

    -- Check if transition is valid
    IF NOT (v_valid_transitions->v_current_state) ? p_new_state THEN
        RETURN jsonb_build_object(
            'success', FALSE,
            'reason', 'Invalid state transition',
            'current_state', v_current_state,
            'requested_state', p_new_state,
            'valid_transitions', v_valid_transitions->v_current_state
        );
    END IF;

    -- Perform transition
    UPDATE products
    SET status = p_new_state,
        updated_at = NOW()
    WHERE id = p_product_id;

    -- Log the transition
    INSERT INTO safeguard_audit_log (product_id, safeguard_name, decision, reason, metadata)
    VALUES (p_product_id, 'state_machine', 'pass',
            'Transitioned from ' || v_current_state || ' to ' || p_new_state,
            p_metadata);

    RETURN jsonb_build_object(
        'success', TRUE,
        'previous_state', v_current_state,
        'new_state', p_new_state
    );
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- ROW LEVEL SECURITY FOR NEW TABLES
-- ============================================================================

ALTER TABLE workflow_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE safeguard_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE nexus_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE credential_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_identities ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE rejection_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_connectors ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_walkthrough_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE mcp_servers ENABLE ROW LEVEL SECURITY;
ALTER TABLE mcp_tool_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_flags ENABLE ROW LEVEL SECURITY;

-- Service role policies for new tables
CREATE POLICY "Service role full access" ON workflow_executions FOR ALL USING (true);
CREATE POLICY "Service role full access" ON safeguard_audit_log FOR ALL USING (true);
CREATE POLICY "Service role full access" ON nexus_tracking FOR ALL USING (true);
CREATE POLICY "Service role full access" ON credential_audit_log FOR ALL USING (true);
CREATE POLICY "Service role full access" ON agent_identities FOR ALL USING (true);
CREATE POLICY "Service role full access" ON agent_audit_log FOR ALL USING (true);
CREATE POLICY "Service role full access" ON rejection_feedback FOR ALL USING (true);
CREATE POLICY "Service role full access" ON platform_connectors FOR ALL USING (true);
CREATE POLICY "Service role full access" ON user_walkthrough_progress FOR ALL USING (true);
CREATE POLICY "Service role full access" ON analytics_events FOR ALL USING (true);
CREATE POLICY "Service role full access" ON mcp_servers FOR ALL USING (true);
CREATE POLICY "Service role full access" ON mcp_tool_executions FOR ALL USING (true);
CREATE POLICY "Service role full access" ON api_costs FOR ALL USING (true);
CREATE POLICY "Service role full access" ON feature_flags FOR ALL USING (true);

-- ============================================================================
-- SCHEMA VERSION TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS schema_versions (
    id SERIAL PRIMARY KEY,
    version TEXT NOT NULL UNIQUE,
    description TEXT,
    applied_at TIMESTAMPTZ DEFAULT NOW(),
    applied_by TEXT DEFAULT 'system'
);

INSERT INTO schema_versions (version, description) VALUES
('2.0.0', 'Complete schema v2 with workflow tracking, agent IAM, platform connectors, analytics, MCP integration, and feature flags');
