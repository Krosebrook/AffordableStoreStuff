# Amazon KDP Platform Guide

Connect Income Engine to Amazon Kindle Direct Publishing (KDP) for automated book publishing and sales tracking.

## Overview

| Property | Value |
|----------|-------|
| **Platform Type** | Digital Publishing |
| **Authentication** | Browser Automation + 2FA/TOTP |
| **API Type** | None (uses Playwright automation) |
| **Rate Limit** | 5 requests/minute (conservative) |
| **Adapter File** | `src/connectors/adapters/amazon-kdp-adapter.ts` |

> **Important**: Amazon KDP does not provide a public API. This adapter uses Playwright browser automation to interact with the KDP dashboard. Use responsibly and respect Amazon's terms of service.

## Prerequisites

1. **Amazon KDP Account** at [kdp.amazon.com](https://kdp.amazon.com)
2. **2FA Enabled** on your Amazon account (required for security)
3. **TOTP Authenticator App** (Google Authenticator, Authy, etc.)
4. **Node.js 20+** with Playwright installed

## Step 1: Enable Two-Factor Authentication

1. Go to [Amazon Account Settings](https://www.amazon.com/a/settings/approval)
2. Enable **Two-Step Verification**
3. Choose **Authenticator App** (not SMS)
4. When shown the QR code, also click "Can't scan the barcode?"
5. **Copy the secret key** (you'll need this for automation)

## Step 2: Store TOTP Secret in Database

The adapter uses TOTP to automatically generate 2FA codes. Store your secret:

```sql
-- Insert TOTP credentials
INSERT INTO totp_credentials (platform, email, secret_key, created_at)
VALUES (
  'amazon-kdp',
  'your-amazon-email@example.com',
  'YOUR_TOTP_SECRET_KEY',
  NOW()
);
```

Or via API:

```bash
POST /api/credentials/totp
Content-Type: application/json

{
  "platform": "amazon-kdp",
  "email": "your-amazon-email@example.com",
  "secretKey": "YOUR_TOTP_SECRET_KEY"
}
```

## Step 3: Store KDP Credentials

Store your Amazon login credentials securely:

```bash
POST /api/connectors/amazon-kdp/credentials
Content-Type: application/json

{
  "email": "your-amazon-email@example.com",
  "password": "your-amazon-password",
  "otpSecret": "YOUR_TOTP_SECRET_KEY"
}
```

Credentials are encrypted in the database using AES-256.

## Step 4: Environment Variables

Add to your `.env` file:

```bash
# Amazon KDP (optional - can use database credentials instead)
AMAZON_KDP_EMAIL=your-amazon-email@example.com
AMAZON_KDP_PASSWORD=your-password

# Browser automation settings
PLAYWRIGHT_HEADLESS=true
PLAYWRIGHT_TIMEOUT=30000
```

## How TOTP Authentication Works

The adapter automatically handles 2FA:

1. **Login initiated** - Browser navigates to KDP sign-in
2. **Email entered** - Types your email address
3. **Password entered** - Types your password
4. **2FA detected** - System detects OTP input field
5. **TOTP generated** - Calculates current code from secret
6. **Code freshness check** - If code expires in <5 seconds, waits for next code
7. **OTP submitted** - Enters the code automatically
8. **Session established** - Browser session authenticated

See `src/connectors/utils/totp.ts` for the TOTP implementation:

```typescript
import { generateTOTP, getTimeRemaining, waitForNextCode } from '../utils/totp';

// Generate current TOTP code
const result = generateTOTP({
  secret: 'YOUR_SECRET',
  period: 30,      // 30-second window
  digits: 6,       // 6-digit code
  algorithm: 'sha1'
});

console.log(result.code);             // "123456"
console.log(result.remainingSeconds); // 15
```

## Platform Capabilities

| Capability | Supported |
|------------|-----------|
| OAuth | No |
| Bulk Operations | No |
| Webhooks | No |
| Inventory Sync | No |
| Order Fulfillment | No |
| Analytics | Yes |
| Rate Limits | 5/min, 50/hour |

## KDP Book Requirements

### Title Requirements
- **Max length**: 200 characters
- **No special characters** that aren't supported
- **Must be unique** in your catalog

### Description Requirements
- **Min length**: 100 characters (recommended)
- **Max length**: 4,000 characters
- **No HTML** (plain text only)

### Keywords
- **Maximum**: 7 keywords
- **Each keyword**: Max 50 characters
- **No duplicates** of title words

### Pricing
- **Minimum**: $0.99
- **Maximum**: $200.00
- **Royalty options**: 35% or 70%

### Cover Requirements
- **Format**: JPG, JPEG, TIF, TIFF, PNG
- **Minimum resolution**: 1000 pixels on longest side
- **Recommended**: 2560 x 1600 pixels (for best quality)
- **Max file size**: 50 MB

### Manuscript Requirements
- **Formats**: DOC, DOCX, EPUB, PDF, HTML, TXT
- **Recommended**: EPUB or DOCX
- **Max file size**: 650 MB

## Usage Examples

### Test Connection

```bash
POST /api/connectors/amazon-kdp/test

# Success Response
{
  "success": true,
  "authenticated": true,
  "sessionValid": true
}
```

### List Books

```bash
GET /api/connectors/amazon-kdp/products

# Response
{
  "items": [
    {
      "id": "B0XXXXXXXXX",
      "title": "My Awesome Book",
      "status": "live",
      "metadata": {
        "kdpStatus": "LIVE",
        "lastModified": "Dec 15, 2025"
      }
    }
  ],
  "pagination": {
    "page": 1,
    "total": 25,
    "hasMore": false
  }
}
```

### Create a Book (Draft)

```bash
POST /api/connectors/amazon-kdp/products
Content-Type: application/json

{
  "title": "The Ultimate Guide to Passive Income",
  "description": "Learn how to build sustainable passive income streams...",
  "metadata": {
    "subtitle": "A Step-by-Step Blueprint",
    "author": "John Smith",
    "keywords": ["passive income", "financial freedom", "investing"],
    "categories": ["Business & Money", "Personal Finance"],
    "language": "en"
  },
  "pricing": {
    "basePrice": 9.99
  }
}

# Response
{
  "success": true,
  "data": {
    "id": "B0XXXXXXXXX",
    "status": "draft",
    "url": "https://kdp.amazon.com/title-setup/kindle/B0XXXXXXXXX/details"
  }
}
```

### Upload Manuscript

```bash
POST /api/connectors/amazon-kdp/products/{bookId}/manuscript
Content-Type: multipart/form-data

manuscript: [file.epub]

# Response
{
  "success": true,
  "status": "processing",
  "message": "Manuscript uploaded, conversion in progress"
}
```

### Upload Cover

```bash
POST /api/connectors/amazon-kdp/products/{bookId}/cover
Content-Type: multipart/form-data

cover: [cover.jpg]

# Response
{
  "success": true,
  "status": "uploaded"
}
```

### Publish Book

```bash
POST /api/connectors/amazon-kdp/products/{bookId}/publish

# Response
{
  "success": true,
  "data": {
    "asin": "B0XXXXXXXXX",
    "status": "in_review"
  }
}
```

### Get Sales Report

```bash
GET /api/connectors/amazon-kdp/analytics?start=2025-01-01&end=2025-01-31

# Response
{
  "platform": "amazon-kdp",
  "dateRange": {
    "start": "2025-01-01",
    "end": "2025-01-31"
  },
  "revenue": 1250.00,
  "orders": 150,
  "topProducts": [
    {
      "id": "B0XXXXXXXXX",
      "title": "My Best Seller",
      "sales": 75,
      "revenue": 675.00
    }
  ]
}
```

## Browser Automation Details

The adapter uses Playwright with anti-detection measures:

### Anti-Detection Features
- Custom user agent (Chrome on Windows)
- Disabled `navigator.webdriver` flag
- Human-like typing delays (30-130ms per character)
- Random delays between actions (500-2000ms)
- Viewport set to standard desktop (1920x1080)

### Human-Like Behavior
```typescript
// Built-in delays simulate human behavior
humanDelay(500, 2000);  // Random delay 500-2000ms
humanType(page, selector, text);  // Types with variable speed
humanScroll(page);  // Scrolls naturally
```

### Browser Cleanup
Always close the browser when done:

```typescript
const adapter = new AmazonKDPAdapter(config);
try {
  await adapter.authenticate();
  // ... do operations
} finally {
  await adapter.closeBrowser();  // Critical!
}
```

## Rate Limiting

KDP automation must be conservative to avoid detection:

| Limit | Value |
|-------|-------|
| Requests per minute | 5 |
| Requests per hour | 50 |
| Concurrent sessions | 1 |

The adapter enforces these limits automatically.

## Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `AUTH_FAILED` | Invalid credentials | Verify email/password |
| `2FA_REQUIRED` | OTP secret not configured | Add TOTP secret to database |
| `2FA_INVALID` | Wrong OTP code | Verify TOTP secret matches authenticator |
| `SESSION_EXPIRED` | Browser session timed out | Re-authenticate |
| `CAPTCHA_REQUIRED` | Amazon detected automation | Wait 24h, check account status |
| `VALIDATION_ERROR` | Book data invalid | Check title, description, price requirements |
| `UNSUPPORTED_OPERATION` | Cannot delete published books | Use unpublish instead |

## Troubleshooting

### Authentication Fails

1. **Verify credentials**: Test login manually in a browser
2. **Check 2FA**: Ensure TOTP secret is correct
3. **Account locks**: Wait 24h if account is temporarily locked
4. **Captcha**: Manual intervention may be required

### TOTP Code Invalid

```sql
-- Verify TOTP secret in database
SELECT * FROM totp_credentials WHERE platform = 'amazon-kdp';

-- Test TOTP generation
SELECT generate_totp('YOUR_SECRET');
```

Ensure your server's clock is synchronized (TOTP is time-based).

### Browser Hangs

```typescript
// Set timeout for operations
const adapter = new AmazonKDPAdapter({
  ...config,
  timeout: 60000  // 60 second timeout
});
```

### Session Not Persisting

Browser sessions are not persisted between adapter instances. Each operation may require re-authentication. For frequent operations, keep the adapter instance alive.

## Database Schema

### TOTP Credentials Table

```sql
CREATE TABLE totp_credentials (
  id SERIAL PRIMARY KEY,
  platform VARCHAR(50) NOT NULL,
  email VARCHAR(255) NOT NULL,
  secret_key TEXT NOT NULL,  -- Encrypted
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(platform, email)
);
```

### Auth Attempt Logging

```sql
CREATE TABLE auth_attempts (
  id SERIAL PRIMARY KEY,
  platform VARCHAR(50) NOT NULL,
  email VARCHAR(255) NOT NULL,
  success BOOLEAN NOT NULL,
  error_message TEXT,
  ip_address INET,
  created_at TIMESTAMP DEFAULT NOW()
);
```

## Security Considerations

1. **Credential Storage**: Credentials are encrypted using AES-256 in the database
2. **Secret Key Protection**: TOTP secrets should be treated like passwords
3. **Logging**: Auth attempts are logged but passwords are never logged
4. **Network**: Use HTTPS for all API communications
5. **Access Control**: Limit who can access KDP credentials

## Limitations

- **No real API**: All operations use browser automation
- **Rate limited**: Must respect conservative limits
- **Single session**: Only one browser session at a time
- **Detection risk**: Heavy automation may trigger account review
- **No webhooks**: Cannot receive real-time notifications

## Best Practices

1. **Space out operations**: Don't batch too many operations
2. **Monitor account**: Regularly check KDP dashboard for issues
3. **Backup manually**: Don't rely solely on automation
4. **Test thoroughly**: Use a test account before production
5. **Handle errors gracefully**: Implement retry with backoff

## Related Documentation

- [TOTP Utility](../../src/connectors/utils/totp.ts)
- [Playwright Documentation](https://playwright.dev/)
- [KDP Help Center](https://kdp.amazon.com/help)
- [Income Engine API Reference](../API.md)
- [Connector Architecture](../ARCHITECTURE.md)
