# Printify Integration Guide

## Overview

Printify is a print-on-demand platform that connects you with print providers worldwide. Products are printed and shipped directly to customers.

| Attribute | Value |
|-----------|-------|
| Platform Type | POD (Print-on-Demand) |
| Auth Method | API Key |
| Connector Type | `api_key` |
| Rate Limit | 60 requests/minute |
| API Documentation | https://developers.printify.com |

## Setup

### Step 1: Create Account

1. Go to [printify.com](https://printify.com)
2. Sign up for free account
3. Complete profile setup

### Step 2: Create Shop

1. Dashboard → Manage Shops
2. Create new shop or connect existing (Etsy, Shopify, etc.)
3. Note your **Shop ID** from the URL

### Step 3: Generate API Token

1. Go to Settings → API
2. Click "Generate Token"
3. Name your token (e.g., "Income Engine")
4. Copy and save securely

### Step 4: Configure Environment

```bash
# .env
PRINTIFY_API_KEY=your_api_token_here
PRINTIFY_SHOP_ID=your_shop_id_here
```

## Usage

### Connecting

```typescript
import { createConnector } from '@/connectors';

const printify = createConnector('printify', {
  apiKey: process.env.PRINTIFY_API_KEY,
  shopId: process.env.PRINTIFY_SHOP_ID,
});

await printify.authenticate();
```

### Creating a Product

```typescript
const result = await printify.createProduct({
  title: 'Vintage Dog Mom T-Shirt',
  description: 'Perfect gift for dog lovers...',
  images: [
    { url: 'https://your-cdn.com/design.png', position: 0, isPrimary: true }
  ],
  tags: ['dog', 'mom', 'vintage', 'gift', 'pet lover'],
  variants: [
    { size: 'S', color: 'Black', price: 24.99 },
    { size: 'M', color: 'Black', price: 24.99 },
    { size: 'L', color: 'Black', price: 24.99 },
  ]
});
```

### Listing Products

```typescript
const products = await printify.listProducts({
  page: 1,
  limit: 50,
  status: 'published'
});
```

## Blueprints & Print Providers

### Popular Blueprints

| Blueprint | ID | Type |
|-----------|-----|------|
| Unisex Staple T-Shirt | 6 | T-Shirt |
| Premium Unisex T-Shirt | 12 | T-Shirt |
| Classic Mug | 466 | Mug |
| Spiral Notebook | 442 | Stationery |
| Phone Case | 55 | Accessories |

### Recommended Print Providers

| Provider | Location | Speed | Quality |
|----------|----------|-------|---------|
| Monster Digital | USA | Fast | High |
| SwiftPOD | USA | Fast | High |
| Printful | USA/EU | Medium | High |
| The Print Bar | AU | Medium | High |

## Design Specifications

| Requirement | Value |
|-------------|-------|
| Minimum Size | 2400 x 2400 px |
| Maximum File Size | 20 MB |
| Format | PNG (transparent) |
| Color Mode | sRGB |
| DPI | 150 minimum |

## Pricing Strategy

Printify shows you the base cost. Set your retail price for profit margin.

**Example:**
- Base cost: $12.50
- Retail price: $24.99
- Your profit: $12.49 per sale

**Recommended Margins:**
- T-Shirts: 100-150% markup
- Mugs: 50-100% markup
- Premium items: 75-125% markup

## Rate Limits

| Limit | Value |
|-------|-------|
| Requests/minute | 60 |
| Products/request | 100 |
| Images/product | 10 |

## Troubleshooting

### "Shop not found"
- Verify PRINTIFY_SHOP_ID matches your shop
- Ensure API token has access to the shop

### "Image upload failed"
- Check image URL is publicly accessible
- Verify image meets size requirements
- Ensure PNG format with transparency

### "Blueprint not found"
- Blueprint IDs change - fetch latest list
- Some blueprints are region-specific

### "Print provider unavailable"
- Provider may be at capacity
- Use fallback provider
- Check provider status page

## Best Practices

1. **Use high-quality images** - 300 DPI when possible
2. **Test with one product first** - Verify design placement
3. **Set competitive prices** - Research market rates
4. **Use multiple providers** - Backup for fulfillment
5. **Monitor shipping times** - Update customers proactively
