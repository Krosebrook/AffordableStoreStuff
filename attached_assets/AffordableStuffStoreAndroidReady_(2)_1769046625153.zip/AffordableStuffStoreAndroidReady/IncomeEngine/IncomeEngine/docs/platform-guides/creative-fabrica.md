# Creative Fabrica Integration Guide

## Overview

Creative Fabrica is a marketplace for digital design assets including fonts, graphics, crafts, and more. Perfect for designers selling to other creators.

| Attribute | Value |
|-----------|-------|
| Platform Type | Digital Assets Marketplace |
| Auth Method | API Key |
| Connector Type | `api_key` |
| Rate Limit | 30 requests/minute |
| Royalty | 50% of sale price |

## Setup

### Step 1: Creator Account

1. Go to [creativefabrica.com](https://creativefabrica.com)
2. Apply for creator account
3. Submit portfolio samples
4. Wait for approval (3-7 days)

### Step 2: Generate API Key

1. Once approved, go to Creator Dashboard
2. Navigate to Settings → API
3. Generate API key
4. Copy and save securely

### Step 3: Configure Environment

```bash
# .env
CREATIVE_FABRICA_API_KEY=your_api_key_here
```

## Usage

### Connecting

```typescript
import { createConnector } from '@/connectors';

const cf = createConnector('creative-fabrica', {
  apiKey: process.env.CREATIVE_FABRICA_API_KEY,
});

await cf.authenticate();
```

### Uploading a Product

```typescript
const result = await cf.createProduct({
  title: 'Vintage Script Font Bundle',
  description: 'A collection of 5 beautiful vintage script fonts...',
  category: 'fonts',
  files: [
    { path: '/fonts/vintage-script.otf', type: 'font' },
    { path: '/preview/preview.png', type: 'preview' },
  ],
  tags: ['vintage', 'script', 'wedding', 'elegant', 'handwritten'],
  price: 12.00,
  licenseType: 'commercial',
});
```

## Product Categories

### Available Categories

| Category | Description | File Types |
|----------|-------------|------------|
| `fonts` | Typefaces and font families | OTF, TTF, WOFF |
| `graphics` | Illustrations, clipart | PNG, SVG, EPS |
| `crafts` | Cut files, crafting | SVG, DXF, PNG |
| `templates` | Design templates | PSD, AI, INDD |
| `mockups` | Product mockups | PSD, PNG |
| `patterns` | Seamless patterns | PNG, PAT, AI |
| `textures` | Background textures | JPG, PNG |
| `photos` | Stock photography | JPG, PNG |
| `3d` | 3D models and assets | OBJ, FBX, STL |
| `brushes` | Photoshop/Procreate | ABR, BRUSH |
| `actions` | Photoshop actions | ATN |
| `add-ons` | Software add-ons | Various |

## File Requirements

### General Requirements

| Requirement | Value |
|-------------|-------|
| Max File Size | 500 MB per file |
| Preview Image | Required, 1200x900 min |
| Documentation | README recommended |

### By Category

#### Fonts
- Include all weights/styles
- OTF preferred, TTF acceptable
- Font preview image required
- Character set documentation

#### Graphics/Crafts
- Include PNG with transparency
- SVG for scalable version
- Multiple color variations helpful
- Layered PSD if applicable

#### Templates
- Include all linked assets
- Editable text layers
- Print-ready version
- Web-optimized version

## Pricing Guidelines

| Category | Suggested Range |
|----------|-----------------|
| Single Font | $5 - $15 |
| Font Bundle | $15 - $50 |
| Graphics Pack | $3 - $20 |
| Template | $10 - $35 |
| Large Bundle | $25 - $100 |

**Commission Structure:**
- You receive 50% of sale price
- Bundles may have different rates
- Subscription pool payments vary

## Listing Best Practices

### Title Optimization
```
Good: "Elegant Script Font - Wedding Invitations & Logos"
Bad: "My Font v1"
```

### Description Template
```markdown
## [Product Name]

[Brief description - what it is and who it's for]

### What's Included
- File 1 description
- File 2 description
- ...

### Features
- Feature 1
- Feature 2
- ...

### Usage Ideas
- Idea 1
- Idea 2
- ...

### Technical Details
- Format: [formats]
- Size: [dimensions if applicable]
- License: Commercial use included
```

### Tags Strategy
- Use all 20 tags
- Include variations (script, cursive, handwritten)
- Add use cases (wedding, logo, invitation)
- Include style descriptors (vintage, modern, minimal)

## Rate Limits

| Limit | Value |
|-------|-------|
| Requests/minute | 30 |
| Uploads/day | 50 |
| Max concurrent | 5 |

## Analytics

```typescript
// Get product performance
const analytics = await cf.getProductAnalytics({
  productId: 'prod_123',
  period: 'last_30_days',
});

// Returns: views, downloads, revenue, conversion rate
```

## Troubleshooting

### "Upload failed"
- Check file size limits
- Verify file format is supported
- Ensure preview image is included

### "Product rejected"
- Review quality guidelines
- Check for trademark issues
- Ensure originality

### "Low visibility"
- Optimize title and tags
- Improve preview images
- Update description with keywords

## Best Practices

1. **High-quality previews** - First impression matters
2. **Complete bundles** - More value = more sales
3. **Consistent style** - Build a recognizable brand
4. **Regular uploads** - Algorithm favors active creators
5. **Respond to reviews** - Build community trust
6. **Cross-promote** - Share on social media
7. **Seasonal content** - Holiday-themed products sell well
