# Platform Integration Guides

This directory contains detailed setup and usage guides for each supported platform.

## Platform Categories

### POD (Print-on-Demand) Platforms
| Platform | Guide | Auth Type | Status |
|----------|-------|-----------|--------|
| [Printify](./printify.md) | Full API | API Key | Available |
| [Etsy](./etsy.md) | Full API | OAuth 2.0 | Available |
| [TeePublic](./teepublic.md) | Browser | Playwright | Available |
| [Society6](./society6.md) | Browser | Playwright | Available |
| [Redbubble](./redbubble.md) | Browser | Playwright | Available |

### Digital Product Platforms
| Platform | Guide | Auth Type | Status |
|----------|-------|-----------|--------|
| [Gumroad](./gumroad.md) | Full API | OAuth 2.0 | Available |
| [Creative Fabrica](./creative-fabrica.md) | Full API | API Key | Available |
| [Amazon KDP](./amazon-kdp.md) | Browser | Playwright | Available |

### Marketplace Platforms
| Platform | Guide | Auth Type | Status |
|----------|-------|-----------|--------|
| [Shopify](./shopify.md) | Full API | OAuth 2.0 | Available |
| [WooCommerce](./woocommerce.md) | Full API | API Key | Available |
| [TikTok Shop](./tiktok-shop.md) | Full API | OAuth 2.0 | Available |

## Quick Comparison

| Platform | Best For | Royalty/Commission | Ease of Setup |
|----------|----------|-------------------|---------------|
| Printify | T-shirts, mugs, apparel | You set margin | Easy |
| Etsy | Handmade/vintage market | 6.5% + $0.20/listing | Medium |
| TeePublic | Fixed-price POD | $2-6 per sale | Easy |
| Society6 | Art prints, home decor | 10% of retail | Easy |
| Redbubble | POD variety | You set markup | Easy |
| Gumroad | Digital products | 10% | Easy |
| Creative Fabrica | Fonts, graphics | 50% | Medium |
| Amazon KDP | eBooks, paperbacks | 35-70% | Medium |
| Shopify | Own store | 2.9% + $0.30 | Medium |
| WooCommerce | Self-hosted store | None (hosting costs) | Hard |
| TikTok Shop | Social commerce | 2-8% by category | Medium |

## Authentication Types

### API Key Platforms
- Generate key from platform settings
- Add to environment variables
- Immediate access

### OAuth 2.0 Platforms
- Create app in developer portal
- Configure callback URLs
- Users authorize via redirect
- Tokens auto-refresh

### Browser Automation Platforms
- Enter credentials via dashboard
- Stored encrypted in database
- Uses Playwright for automation
- Requires headless browser support

## Common Integration Patterns

All platform adapters follow the same interface:

```typescript
import { createConnector } from '@/connectors';

// Create connector instance
const printify = createConnector('printify', {
  apiKey: process.env.PRINTIFY_API_KEY,
});

// Authenticate
await printify.authenticate();

// List products
const products = await printify.listProducts();

// Create product
const result = await printify.createProduct({
  title: 'My Design',
  description: 'A great product',
  images: [{ url: 'https://...' }],
  tags: ['design', 'custom'],
});
```

## Design Specifications by Platform

| Platform | Min Size | Max Size | Format | DPI |
|----------|----------|----------|--------|-----|
| Printify | 2400x2400 | 20MB | PNG | 150 |
| TeePublic | 2400x2400 | 25MB | PNG | 150 |
| Society6 | 6500x6500 | 150MB | PNG/JPG | 300 |
| Redbubble | 2400x2400 | 20MB | PNG | 150 |
| Creative Fabrica | Varies | 500MB | Various | N/A |
