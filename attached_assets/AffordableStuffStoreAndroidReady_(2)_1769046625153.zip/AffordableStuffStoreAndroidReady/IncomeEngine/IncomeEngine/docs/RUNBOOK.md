# Income Engine Operations Runbook

## Quick Reference

| Task | Frequency | Command/Action |
|------|-----------|----------------|
| Health Check | Daily | `curl /health` or Dashboard |
| System Status | On-demand | Dashboard → Overview |
| Generate Products | As needed | Dashboard → Generate |
| Approve Products | Daily | Dashboard → Approvals |
| Budget Review | Daily | Dashboard → Budget |
| Platform Sync | Every 6h | Automatic |

---

## 1. Dashboard Operations

### 1.1 Overview Page

The Overview page shows real-time system status:

```
System Health
├── Safeguards Status (8 modules)
│   ├── Rate Limiter: Active
│   ├── Quality Gate: Active
│   ├── Trademark Screener: Active
│   ├── API Queue: 3 pending
│   ├── Provider Failover: All healthy
│   ├── Tax Compliance: Active
│   ├── Human-in-Loop: 5 pending
│   └── Budget Breaker: 35% used
├── Platform Connections (11 platforms)
│   ├── Printify: Connected
│   ├── Etsy: Connected
│   ├── TikTok Shop: Token expires in 5 days
│   └── ...
└── Revenue Today: $47.50
```

### 1.2 Connectors Page

Manage all 11 platform connections:

| Platform | Type | Auth Method | Status |
|----------|------|-------------|--------|
| Printify | POD | API Key | Connect |
| Etsy | POD | OAuth 2.0 | Reauthorize |
| Gumroad | Digital | API Key | Connected |
| Shopify | Marketplace | OAuth 2.0 | Connected |
| WooCommerce | Marketplace | API Key | Connected |
| Amazon KDP | Digital | Browser | Configure |
| Redbubble | POD | Browser | Configure |
| TeePublic | POD | Browser | Configure |
| Society6 | POD | Browser | Configure |
| Creative Fabrica | Digital | API Key | Connect |
| TikTok Shop | Marketplace | OAuth 2.0 | Connected |

#### Connecting OAuth Platforms

1. Click **Connect** next to platform
2. You'll be redirected to platform login
3. Authorize the application
4. Redirected back with success message

#### Configuring Browser Automation Platforms

1. Click **Configure** next to platform
2. Enter email and password
3. Credentials are encrypted and stored
4. Test connection to verify

### 1.3 Approvals Page

Review products pending human approval:

**Approval Workflow:**
1. First 50 products require manual review
2. After 50, only flagged products need review
3. Trademark hits always require review
4. Low quality scores (< 70) require review

**Actions:**
- **Approve**: Product proceeds to publishing
- **Reject**: Product archived with reason
- **Edit**: Modify before approval

### 1.4 Budget Page

Monitor spending and set limits:

```
Daily Budget Status
├── AI Costs Today: $1.25
├── Daily Limit: $5.00
├── Usage: 25%
└── Status: Healthy

Monthly Overview
├── Total Spend: $38.50
├── Monthly Budget: $150.00
├── Projected: $77.00
└── Revenue: $892.00

Circuit Breaker: CLOSED
```

**Budget Alerts:**
- 50% usage: Informational
- 75% usage: Warning
- 90% usage: Critical
- 100% usage: Circuit breaker OPEN

### 1.5 Analytics Page

View performance metrics across all platforms:

**Revenue by Platform (Last 30 Days)**
| Platform | Revenue | Orders | Top Product |
|----------|---------|--------|-------------|
| Etsy | $420.00 | 35 | Dog Mom T-Shirt |
| Shopify | $312.00 | 28 | Custom Mug Set |
| Gumroad | $185.00 | 74 | SVG Bundle |
| TikTok | $95.00 | 12 | Trending Tee |

**Key Metrics:**
- Conversion Rate
- Average Order Value
- Product Performance
- Niche Analysis

---

## 2. Safeguard Operations

### 2.1 Rate Limiter

**Purpose**: Prevent API abuse and account suspension

**Status Check:**
```
Rate Limits (requests/minute)
├── Printify: 45/60 (75%)
├── Etsy: 8/10 (80%)
├── Shopify: 35/40 (87%)
└── TikTok: 85/100 (85%)
```

**Manual Reset:**
```bash
curl -X POST /api/safeguards/rate-limiter/reset \
  -d '{"platform": "etsy"}'
```

### 2.2 Quality Gate

**Purpose**: Ensure content quality before publishing

**Quality Score Components:**
- Title relevance: 0-30 points
- Description quality: 0-25 points
- Tag optimization: 0-20 points
- Image quality: 0-25 points

**Thresholds:**
- `>= 80`: Auto-approve
- `70-79`: Review recommended
- `< 70`: Auto-reject

### 2.3 Trademark Screener

**Purpose**: Avoid trademark infringement

**Checked Against:**
- USPTO TESS database
- Known brand names
- Sports teams
- Entertainment properties

**When Triggered:**
1. Product flagged in queue
2. Requires human review
3. Modify or reject

### 2.4 API Queue

**Purpose**: Manage API requests with backoff

**Queue Status:**
```
Queue: 12 items
├── Priority High: 3
├── Priority Normal: 7
├── Priority Low: 2
└── Failed (retry): 2
```

**Backoff Strategy:**
- 1st retry: 1 second
- 2nd retry: 2 seconds
- 3rd retry: 4 seconds
- 4th retry: 8 seconds
- Max retries: 5

### 2.5 Provider Failover

**Purpose**: Redundancy for AI services

**Providers:**
| Service | Primary | Fallback |
|---------|---------|----------|
| Images | Replicate | DALL-E |
| Text | GPT-4o-mini | Claude |
| Quality | OpenAI | Local |

### 2.6 Tax Compliance

**Purpose**: Track sales tax nexus

**Monitored States:**
- California, Texas, New York, Florida
- Economic nexus thresholds
- Automatic alerts at 80% threshold

### 2.7 Human-in-the-Loop

**Purpose**: Manual review for edge cases

**Review Queue:**
- Dashboard → Approvals
- Batch approve/reject supported
- Audit trail maintained

### 2.8 Budget Circuit Breaker

**States:**
- **CLOSED**: Normal operation
- **HALF-OPEN**: Testing recovery
- **OPEN**: All generation paused

**Manual Override:**
```bash
curl -X POST /api/safeguards/circuit-breaker/close
```

---

## 3. Platform Operations

### 3.1 POD Platforms

#### Printify Workflow
1. Product approved
2. Design uploaded to Printify
3. Product created with variants
4. Synced to connected shops (Etsy, Shopify)

#### TeePublic/Society6/Redbubble
1. Product approved
2. Browser automation launches
3. Design uploaded
4. Products enabled across catalog
5. Status updated

### 3.2 Digital Platforms

#### Gumroad Workflow
1. Digital product approved
2. File uploaded to Gumroad
3. Product page created
4. Price and description set

#### Creative Fabrica Workflow
1. Asset approved (font, graphic, craft)
2. Uploaded via API
3. Metadata set
4. Published to marketplace

#### Amazon KDP Workflow
1. Book/content approved
2. Browser automation launches
3. Manuscript uploaded
4. Metadata entered
5. Published (review period)

### 3.3 Marketplace Platforms

#### Shopify Workflow
1. Product created locally
2. Synced to Shopify store
3. Inventory managed
4. Orders fulfilled

#### WooCommerce Workflow
1. Product created
2. Synced via REST API
3. Stock managed
4. Webhooks for orders

#### TikTok Shop Workflow
1. Product approved
2. Uploaded via API
3. Linked to videos/live
4. Orders fulfilled

---

## 4. Troubleshooting Guide

### 4.1 Common Errors

#### "Rate limit exceeded"
```
Cause: Too many API calls
Fix:
1. Wait for cooldown (60s)
2. Reduce batch sizes
3. Check concurrent operations
4. Reset rate limiter:
   curl -X POST /api/safeguards/rate-limiter/reset -d '{"platform": "etsy"}'
```

#### "Budget exhausted"
```
Cause: Daily AI spend reached
Fix:
1. Wait until midnight UTC reset
2. Or increase MAX_DAILY_AI_SPEND
3. Use economy quality tier
4. Close circuit breaker manually:
   UPDATE circuit_breaker_state SET is_open = false WHERE breaker_name = 'budget_daily';
```

#### "Trademark violation detected"
```
Cause: Protected term found
Fix:
1. Review flagged keywords
2. Remove brand names
3. Modify title/tags
4. Check rejection_feedback table for patterns
```

#### "OAuth token expired"
```
Cause: Platform token needs refresh
Fix:
1. Go to Connectors page
2. Click "Reauthorize"
3. Complete OAuth flow
4. Verify callback URL matches deployment URL
```

#### "Browser automation failed"
```
Cause: Page structure changed or timeout
Fix:
1. Check platform for UI changes
2. Increase timeout settings
3. Verify credentials
4. Clear browser cache
5. Check Playwright browser logs
```

#### "Webhook delivery failed"
```
Cause: Endpoint unreachable or error
Fix:
1. Check webhook_queue for failed items:
   SELECT * FROM webhook_queue WHERE status = 'failed';
2. Verify endpoint URL is correct
3. Check endpoint is accepting POST requests
4. Review webhook_log for error details
```

#### "2FA/TOTP code invalid"
```
Cause: TOTP secret incorrect or time sync issue
Fix:
1. Verify TOTP secret in database:
   SELECT * FROM totp_credentials WHERE platform = 'amazon-kdp';
2. Check server time is synced (within 30s of actual time)
3. Regenerate TOTP secret if necessary
4. Test code generation:
   node -e "require('./src/connectors/utils/totp').getCode('YOUR_SECRET')"
```

#### "Inventory sync conflict"
```
Cause: Stock levels don't match across platforms
Fix:
1. Check sync_conflicts table
2. Review last successful sync timestamp
3. Force full sync:
   POST /api/inventory/sync
4. Verify each platform's inventory manually
```

#### "Design generation failed"
```
Cause: AI provider error or budget exceeded
Fix:
1. Check provider health:
   GET /api/providers
2. Verify AI API keys are valid
3. Check budget status:
   GET /api/budget
4. Try failover provider if primary is down
```

#### "Quality gate rejection"
```
Cause: Product didn't meet quality threshold
Fix:
1. Check quality score in safeguard_audit_log
2. Review specific rule failures
3. Improve title, description, or tags
4. Resubmit with modifications
```

### 4.2 Platform-Specific Issues

#### Printify
| Error | Solution |
|-------|----------|
| "Shop not found" | Verify PRINTIFY_SHOP_ID |
| "Image upload failed" | Check image URL/format |
| "Blueprint invalid" | Update template mapping |

#### Etsy
| Error | Solution |
|-------|----------|
| "Listing limit" | Upgrade plan or wait |
| "Invalid taxonomy" | Check category mapping |
| "Image too small" | Min 2000x2000px |

#### TikTok Shop
| Error | Solution |
|-------|----------|
| "Product rejected" | Review content policy |
| "Category mismatch" | Update product category |
| "Image requirements" | Follow TikTok specs |

#### Amazon KDP
| Error | Solution |
|-------|----------|
| "2FA required" | Configure TOTP secret in database |
| "Login failed" | Check credentials, clear browser state |
| "Manuscript format" | Verify PDF/EPUB format |
| "Cover dimensions" | Check KDP cover requirements |

#### Shopify
| Error | Solution |
|-------|----------|
| "Rate limited" | Wait for cooldown, reduce batch size |
| "Product not found" | Verify product ID exists |
| "Inventory mismatch" | Force sync via /api/inventory/sync |

#### WooCommerce
| Error | Solution |
|-------|----------|
| "Connection refused" | Verify WOOCOMMERCE_URL is correct |
| "Invalid signature" | Regenerate API keys |
| "Stock update failed" | Check product has manage_stock enabled |

### 4.3 Workflow Engine Issues

#### POD Workflow Stuck
```
Symptoms: Products not publishing, workflow appears frozen
Fix:
1. Check active workflows:
   GET /api/workflows/status
2. Review workflow execution log in database
3. Check if any platform is rate limited
4. Restart workflow if necessary
```

#### Marketplace Sync Failing
```
Symptoms: Inventory not syncing, orders not appearing
Fix:
1. Verify platform connections are active
2. Check last sync timestamp
3. Review sync errors in logs
4. Force manual sync:
   POST /api/inventory/sync
```

### 4.4 Database Issues

#### Connection Pool Exhausted
```
Symptoms: "Too many connections" errors
Fix:
1. Reduce concurrent operations
2. Check for connection leaks in code
3. Increase pool size in Supabase settings
4. Restart application to clear stale connections
```

#### Slow Queries
```
Symptoms: API responses taking >5 seconds
Fix:
1. Check database query logs
2. Verify indexes exist on frequently queried columns
3. Add missing indexes:
   CREATE INDEX idx_products_status ON products(status);
4. Analyze query plans with EXPLAIN
```

### 4.5 Mobile App Issues

#### PWA Not Installing
```
Symptoms: Install prompt not appearing
Fix:
1. Verify HTTPS is enabled (Replit handles this)
2. Check manifest.json is served correctly
3. Verify service worker is registered
4. Check console for errors
```

#### Capacitor Build Fails
```
Symptoms: Android/iOS build errors
Fix:
1. Ensure web build is complete:
   npm run build
2. Sync Capacitor:
   npx cap sync
3. Check Android Studio/Xcode for specific errors
4. Verify JDK/SDK versions are compatible
```

---

## 5. Metrics & Targets

### Revenue Targets
| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| Monthly Revenue | $1,000+ | < $500 | < $200 |
| Daily Revenue | $33+ | < $15 | < $5 |
| Net Margin | > 60% | < 40% | < 20% |

### Operations Targets
| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| Approval Rate | > 85% | < 70% | < 50% |
| Platform Uptime | 100% | < 99% | < 95% |
| AI Cost/Product | < $0.05 | > $0.08 | > $0.12 |

### Quality Targets
| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| Quality Score | > 80 | < 70 | < 60 |
| Trademark Hits | 0% | > 5% | > 10% |
| Rejections | < 15% | > 20% | > 30% |

---

## 6. Maintenance Schedule

### Daily (Automated)
- Revenue sync (every 12h)
- Niche scanning (6 AM)
- Daily report (9 AM)
- Health checks (every 5m)

### Weekly (Manual)
- [ ] Monday: Review metrics, plan niches
- [ ] Wednesday: Optimize prompts, test products
- [ ] Friday: Cleanup, backup, documentation

### Monthly
- [ ] Full metrics review
- [ ] API key rotation check
- [ ] Platform policy review
- [ ] Infrastructure scaling assessment

---

## 7. MCP Operations (AI Assistant)

Use Claude Code or other MCP clients for automated operations:

### Quick Commands via AI

```
"Check platform status"        → list_platforms
"Show pending products"        → products://pending resource
"Get this month's revenue"     → get_analytics with period='month'
"Check safeguard health"       → check_safeguards
"Reset rate limiter"           → reset_safeguard with safeguard='rate-limiter'
"Run niche scanner"            → run_workflow with workflow='niche-scanner'
```

### Common MCP Workflows

| Task | MCP Tool | Example |
|------|----------|---------|
| Morning check | `check_safeguards` | "Check all safeguards" |
| Revenue report | `get_analytics` | "Revenue for this week" |
| Platform health | `list_platforms` | "Which platforms need attention?" |
| Approve products | `products://pending` | "Show pending approvals" |
| Budget status | `budget://current` | "How much budget is left?" |
| Generate products | `run_workflow` | "Run product generator for dog niches" |

### MCP Troubleshooting

| Issue | Solution |
|-------|----------|
| "MCP server not responding" | Run `node mcp-server/index.js --test` |
| "Tool not found" | Check tool name in MCP-INTEGRATION.md |
| "Permission denied" | Verify SUPABASE_SERVICE_KEY is set |
| "Resource unavailable" | Check database connection |
| "Timeout" | Increase MCP server timeout settings |

---

## 8. New Feature Operations

### 8.1 Inventory Sync Management

**Manual Sync**
```bash
# Sync all platforms
curl -X POST https://your-app.com/api/inventory/sync

# Check sync status
curl https://your-app.com/api/workflows/status
```

**Automatic Sync Configuration**
- Interval: Every 5 minutes for inventory
- Order sync: Every 2 minutes
- Low stock threshold: 5 units (configurable)

**Monitoring Sync Health**
```sql
-- Check recent syncs
SELECT * FROM workflow_executions
WHERE workflow_name = 'inventory_sync'
ORDER BY started_at DESC
LIMIT 10;

-- Check for sync errors
SELECT * FROM workflow_executions
WHERE status = 'failed'
AND workflow_name LIKE '%sync%'
ORDER BY started_at DESC;
```

### 8.2 Webhook Notification Management

**View Webhook Queue**
```sql
-- Pending webhooks
SELECT * FROM webhook_queue
WHERE status = 'pending'
ORDER BY created_at;

-- Failed webhooks (for retry)
SELECT * FROM webhook_queue
WHERE status = 'failed'
AND retry_count < 5
ORDER BY created_at;
```

**Manual Webhook Retry**
```sql
-- Retry failed webhooks
UPDATE webhook_queue
SET status = 'pending', retry_count = retry_count + 1
WHERE status = 'failed'
AND retry_count < 5;
```

**Configure New Webhook Endpoint**
```sql
INSERT INTO webhook_endpoints (name, url, event_types, is_active, secret)
VALUES (
  'My Alert System',
  'https://my-system.com/webhook',
  ARRAY['order_created', 'low_stock', 'budget_warning'],
  true,
  'my-webhook-secret'
);
```

### 8.3 2FA/TOTP Management

**Configure TOTP for Amazon KDP**
```sql
-- Add TOTP credentials
INSERT INTO totp_credentials (platform, email, secret_key, issuer)
VALUES ('amazon-kdp', 'your-email@example.com', 'YOUR_BASE32_SECRET', 'Amazon');

-- Verify TOTP is working
SELECT * FROM auth_attempts
WHERE platform = 'amazon-kdp'
ORDER BY attempted_at DESC
LIMIT 5;
```

**Generate Test TOTP Code**
```javascript
// In Node.js
const { getCode } = require('./src/connectors/utils/totp');
console.log(getCode('YOUR_BASE32_SECRET'));
```

### 8.4 Cross-Platform Analytics

**Revenue by Platform (Last 30 Days)**
```bash
curl "https://your-app.com/api/analytics/platforms?start=2025-11-29&end=2025-12-29"
```

**Response Format**
```json
{
  "pod": {
    "totalRevenue": 1250.00,
    "platforms": {
      "printify": { "revenue": 650.00, "orders": 45 },
      "etsy": { "revenue": 420.00, "orders": 28 }
    }
  },
  "marketplace": {
    "totalRevenue": 890.00,
    "platforms": {
      "shopify": { "revenue": 520.00, "orders": 25 }
    }
  }
}
```

### 8.5 Provider Failover Monitoring

**Check Provider Health**
```bash
curl https://your-app.com/api/providers
```

**Manual Provider Failover**
```sql
-- Disable unhealthy provider
UPDATE provider_config
SET is_available = false, health_score = 0
WHERE provider_name = 'replicate';

-- Enable backup provider
UPDATE provider_config
SET is_primary = true
WHERE provider_name = 'openai-dalle';
```

### 8.6 Feature Flags

**View Active Feature Flags**
```sql
SELECT flag_key, flag_name, is_enabled, environment
FROM feature_flags
WHERE is_enabled = true;
```

**Toggle Feature Flag**
```sql
-- Enable auto-approval
UPDATE feature_flags
SET is_enabled = true
WHERE flag_key = 'auto_approve_enabled';

-- Disable beta connectors
UPDATE feature_flags
SET is_enabled = false
WHERE flag_key = 'beta_connectors';
```

---

## 9. Emergency Procedures

### Platform Account Suspension
```
1. STOP all automation immediately
   - Set DRY_RUN=true in environment
   - Pause all n8n workflows
2. Review recent products for policy violations
3. Contact platform support immediately
4. Do NOT create new accounts (will worsen situation)
5. Wait for resolution
6. Document incident in database
```

### Budget Overrun
```
1. Circuit breaker auto-opens (verify in database)
2. Review cost_events table for expensive operations:
   SELECT * FROM cost_events ORDER BY cost_usd DESC LIMIT 20;
3. Identify which provider/operation caused overrun
4. Reduce quality tier or switch to economy model
5. Adjust MAX_DAILY_AI_SPEND if budget is truly higher
6. Close circuit breaker when ready:
   UPDATE circuit_breaker_state SET is_open = false;
```

### Data Breach Response
```
1. Revoke all API keys immediately
   - Regenerate Supabase keys
   - Rotate all platform API keys
   - Invalidate OAuth tokens
2. Change all passwords
3. Review credential_audit_log for suspicious activity
4. Notify affected platforms
5. Document timeline
6. Update security measures
7. Enable additional logging
```

### Database Corruption
```
1. Stop application immediately
2. Do not attempt writes
3. Contact Supabase support
4. Restore from latest backup
5. Verify data integrity
6. Document affected records
```

### AI Provider Outage
```
1. Check provider status pages
2. Provider failover should auto-activate
3. If not, manually switch primary provider
4. Monitor queue for stuck items
5. Resume when primary is back
```

---

## 10. Contact & Support

### Platform Support
- Printify: support@printify.com
- Etsy: developers@etsy.com
- Gumroad: support@gumroad.com
- Shopify: support@shopify.com
- TikTok Shop: seller-support@tiktok.com
- Amazon KDP: kdp-support@amazon.com
- WooCommerce: support@woocommerce.com

### API Documentation
- Printify: https://developers.printify.com
- Etsy: https://developer.etsy.com
- Shopify: https://shopify.dev
- TikTok Shop: https://partner.tiktokshop.com/doc
- WooCommerce: https://woocommerce.github.io/woocommerce-rest-api-docs/
- Gumroad: https://help.gumroad.com/article/280-api

### Internal Documentation
- API Reference: `docs/API.md`
- Architecture: `docs/ARCHITECTURE.md`
- MCP Integration: `docs/ai-tools/MCP-INTEGRATION.md`

---

*Last Updated: December 2025*
*Version: 2.0.0*
