# 🛡️ Passive Income Safeguards - Mobile PWA

A mobile-first Progressive Web App (PWA) dashboard for managing automated content generation safeguards. Built for Replit with one-click deployment.

## 📱 Mobile App Features

- **PWA Installable**: Add to home screen on iOS/Android
- **Offline Support**: Works without internet connection
- **Push Notifications**: Get alerts for approvals and budget warnings
- **Responsive Design**: Optimized for mobile devices
- **Real-time Updates**: Auto-refresh every 30 seconds

## 🚀 Quick Start on Replit

### 1. Import to Replit

1. Go to [replit.com](https://replit.com)
2. Click **Create Repl** → **Import from GitHub**
3. Or upload this folder directly

### 2. Configure Secrets

Click the 🔒 **Secrets** tab in the sidebar and add:

| Secret Name | Description | Required |
|-------------|-------------|----------|
| `SUPABASE_URL` | Your Supabase project URL | ✅ |
| `SUPABASE_SERVICE_KEY` | Supabase service role key | ✅ |
| `OPENAI_API_KEY` | OpenAI API key for quality gates | ✅ |
| `SLACK_WEBHOOK_URL` | Slack notifications (optional) | ❌ |

### 3. Run the App

Click the **▶ Run** button. The app will:
1. Install dependencies
2. Start the development server
3. Open in the Webview panel

### 4. Deploy

1. Click **Deploy** button (top right)
2. Choose **Autoscale** (recommended)
3. Configure:
   - Build: `npm run build`
   - Run: `npm run start`
4. Click **Deploy**

Your app will be live at `https://your-repl-name.replit.app`

## 📲 Install as Mobile App

### iOS (Safari)
1. Open your deployed URL in Safari
2. Tap the Share button
3. Tap "Add to Home Screen"
4. Tap "Add"

### Android (Chrome)
1. Open your deployed URL in Chrome
2. Tap the menu (⋮)
3. Tap "Install app" or "Add to Home screen"
4. Tap "Install"

## 🏗️ Project Structure

```
├── .replit              # Replit configuration
├── replit.nix           # Nix packages (Node.js, Playwright, etc.)
├── package.json         # Dependencies and scripts
├── vite.config.ts       # Vite + PWA configuration
├── src/
│   ├── client/          # React PWA frontend
│   │   ├── index.html   # PWA entry with meta tags
│   │   ├── main.tsx     # React + SW registration
│   │   ├── App.tsx      # Mobile dashboard
│   │   └── index.css    # Tailwind styles
│   ├── server/          # Express API server
│   │   └── index.ts     # API routes + static serving
│   └── safeguards/      # Safeguard modules
│       └── orchestrator.ts
└── public/
    └── icons/           # PWA app icons
```

## 🔧 Configuration Files

### .replit
```toml
entrypoint = "src/server/index.ts"
modules = ["nodejs-20"]

[deployment]
deploymentTarget = "autoscale"
run = ["npm", "run", "start"]
build = ["npm", "run", "build"]
```

### replit.nix
```nix
{ pkgs }: {
  deps = [
    pkgs.nodejs_20
    pkgs.nodePackages.typescript
    pkgs.playwright-driver.browsers
  ];
}
```

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check (required for Autoscale) |
| GET | `/api/status` | Full system status |
| POST | `/api/products/process` | Process product through safeguards |
| GET | `/api/budget` | Budget status |
| GET | `/api/approvals` | Approval queue |
| GET | `/api/providers` | Provider health |
| GET | `/api/queue` | API queue stats |

## 🛡️ 8 Safeguards Included

1. **Rate Limiter** - Anti-suspension controls
2. **Quality Gates** - AI content originality checks
3. **Trademark Screener** - TESS database lookup
4. **API Queue** - Exponential backoff
5. **Provider Failover** - Backup providers
6. **Tax Compliance** - Multi-state sales tax
7. **Human-in-the-Loop** - First 50 products require review
8. **Budget Circuit Breaker** - Daily caps

## 💰 Replit Costs

| Deployment Type | Cost |
|-----------------|------|
| **Autoscale** | $1/month base + usage |
| **Reserved VM** | $10-20/month |
| **Static** | Free (with subscription) |

Autoscale scales to zero when not in use - ideal for this dashboard.

## 🔄 Converting to Native App

### Option 1: PWABuilder (Recommended)
1. Go to [pwabuilder.com](https://pwabuilder.com)
2. Enter your Replit deployment URL
3. Download Android APK or iOS package

### Option 2: Median.co
1. Go to [median.co](https://median.co)
2. Enter your Replit URL
3. Generate native apps for both platforms

### Option 3: Progressier
1. Install Progressier integration
2. One-click publish to Google Play

## 📋 Database Setup

Before using, run the SQL schema in your Supabase project:

1. Go to Supabase SQL Editor
2. Copy `database/schema.sql` from the main project
3. Execute to create all tables and functions

## 🐛 Troubleshooting

### "Missing Secrets" Error
Ensure all required secrets are set in the Secrets tab.

### Build Fails
Run `npm install` in the Shell, then try again.

### PWA Not Installing
- Ensure you're on HTTPS (Replit deployments are)
- Check that manifest.json is being served

### API Returns 503
Supabase connection issue. Verify your SUPABASE_URL and SUPABASE_SERVICE_KEY.

## 📄 License

MIT - Use freely for your passive income automation!

---

Built with ❤️ for FlashFusion
