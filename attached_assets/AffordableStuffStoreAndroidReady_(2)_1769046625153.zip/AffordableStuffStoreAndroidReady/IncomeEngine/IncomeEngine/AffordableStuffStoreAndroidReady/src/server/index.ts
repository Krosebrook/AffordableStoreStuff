/**
 * ============================================================================
 * REPLIT EXPRESS SERVER
 * Passive Income Safeguards - API & PWA Server
 * ============================================================================
 * 
 * This server provides:
 * 1. REST API endpoints for all 8 safeguards
 * 2. Static file serving for the PWA frontend
 * 3. Health checks for Replit deployments
 * 
 * Deployment: Autoscale (scales to zero when idle)
 */

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { fileURLToPath } from 'url';

// Import safeguard modules
import { createSafeguardsOrchestrator } from '../safeguards/orchestrator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// =============================================================================
// ENVIRONMENT CONFIGURATION
// =============================================================================

// Replit uses Secrets for environment variables
// Access via process.env - no .env file needed in production
const PORT = parseInt(process.env.PORT || '3000', 10);
const NODE_ENV = process.env.NODE_ENV || 'development';
const isProduction = NODE_ENV === 'production';

// Validate required secrets
const requiredSecrets = ['SUPABASE_URL', 'SUPABASE_SERVICE_KEY', 'OPENAI_API_KEY'];
const missingSecrets = requiredSecrets.filter(key => !process.env[key]);

if (missingSecrets.length > 0 && isProduction) {
  console.error('❌ Missing required Replit Secrets:', missingSecrets.join(', '));
  console.error('Add them in the Secrets tab (lock icon in sidebar)');
  process.exit(1);
}

// =============================================================================
// EXPRESS APP SETUP
// =============================================================================

const app = express();

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://*.supabase.co", "https://api.openai.com"]
    }
  }
}));

// CORS configuration
app.use(cors({
  origin: isProduction 
    ? [/\.replit\.app$/, /\.repl\.co$/] 
    : '*',
  credentials: true
}));

// Compression for faster responses
app.use(compression());

// JSON body parser
app.use(express.json({ limit: '10mb' }));

// Rate limiting to prevent abuse
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window
  message: { error: 'Too many requests, please try again later' },
  standardHeaders: true,
  legacyHeaders: false
});

app.use('/api/', apiLimiter);

// =============================================================================
// HEALTH CHECK ENDPOINTS (Required for Replit Autoscale)
// =============================================================================

app.get('/health', (req: Request, res: Response) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    environment: NODE_ENV
  });
});

app.get('/__replit_health', (req: Request, res: Response) => {
  res.status(200).send('OK');
});

// =============================================================================
// API ROUTES
// =============================================================================

// Initialize orchestrator (lazy loading)
let orchestrator: ReturnType<typeof createSafeguardsOrchestrator> | null = null;

const getOrchestrator = () => {
  if (!orchestrator && process.env.SUPABASE_URL) {
    orchestrator = createSafeguardsOrchestrator();
  }
  return orchestrator;
};

// Get system status
app.get('/api/status', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }
    
    const status = await orch.getSystemStatus();
    res.json(status);
  } catch (error) {
    console.error('Status error:', error);
    res.status(500).json({ error: 'Failed to get system status' });
  }
});

// Process a product through safeguards
app.post('/api/products/process', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const product = req.body;
    
    // Validate required fields
    if (!product.id || !product.title || !product.type) {
      return res.status(400).json({ 
        error: 'Missing required fields: id, title, type' 
      });
    }

    const result = await orch.processProduct(product);
    res.json(result);
  } catch (error) {
    console.error('Process error:', error);
    res.status(500).json({ error: 'Failed to process product' });
  }
});

// Get budget status
app.get('/api/budget', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json({ budget: status.budget, circuitBreakers: status.circuitBreakers });
  } catch (error) {
    console.error('Budget error:', error);
    res.status(500).json({ error: 'Failed to get budget status' });
  }
});

// Get approval queue
app.get('/api/approvals', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json(status.approvalStats);
  } catch (error) {
    console.error('Approvals error:', error);
    res.status(500).json({ error: 'Failed to get approvals' });
  }
});

// Approve a product
app.post('/api/approvals/:id/approve', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) return res.status(503).json({ error: 'Safeguards not configured' });

    const reviewerId = String(req.headers['x-reviewer-id'] ?? 'unknown');
    const { notes } = req.body ?? {};
    await orch.approveApproval(req.params.id, reviewerId, notes);
    res.json({ success: true, message: 'Product approved' });
  } catch (error) {
    console.error('Approve error:', error);
    res.status(500).json({ error: 'Failed to approve product' });
  }
});

// Reject a product
app.post('/api/approvals/:id/reject', async (req: Request, res: Response) => {
  try {
    const { reason } = req.body;
    const orch = getOrchestrator();
    if (!orch) return res.status(503).json({ error: 'Safeguards not configured' });

    const reviewerId = String(req.headers['x-reviewer-id'] ?? 'unknown');
    const { notes } = req.body ?? {};
    await orch.rejectApproval(req.params.id, reviewerId, String(reason ?? 'No reason provided'), notes);
    res.json({ success: true, message: 'Product rejected', reason: String(reason ?? 'No reason provided') });
  } catch (error) {
    console.error('Reject error:', error);
    res.status(500).json({ error: 'Failed to reject product' });
  }
});

// Get provider health
app.get('/api/providers', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json(status.providers);
  } catch (error) {
    console.error('Providers error:', error);
    res.status(500).json({ error: 'Failed to get provider status' });
  }
});

// Get API queue stats
app.get('/api/queue', async (req: Request, res: Response) => {
  try {
    const orch = getOrchestrator();
    if (!orch) {
      return res.status(503).json({ error: 'Safeguards not configured' });
    }

    const status = await orch.getSystemStatus();
    res.json(status.queues);
  } catch (error) {
    console.error('Queue error:', error);
    res.status(500).json({ error: 'Failed to get queue status' });
  }
});

// =============================================================================
// STATIC FILE SERVING (PWA)
// =============================================================================

// Serve static files from the built frontend
const clientDistPath = path.join(__dirname, '../../dist/client');

if (isProduction) {
  app.use(express.static(clientDistPath, {
    maxAge: '1d',
    etag: true
  }));
  
  // Service worker should not be cached
  app.get('/sw.js', (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(path.join(clientDistPath, 'sw.js'));
  });
  
  // SPA fallback - serve index.html for all non-API routes
  app.get('*', (req: Request, res: Response) => {
    if (!req.path.startsWith('/api/')) {
      res.sendFile(path.join(clientDistPath, 'index.html'));
    }
  });
}

// =============================================================================
// ERROR HANDLING
// =============================================================================

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({ error: 'Not found' });
});

// Global error handler
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('Server error:', err);
  res.status(500).json({ 
    error: isProduction ? 'Internal server error' : err.message 
  });
});

// =============================================================================
// SERVER STARTUP
// =============================================================================

app.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔════════════════════════════════════════════════════════════════╗
║         PASSIVE INCOME SAFEGUARDS - MOBILE DASHBOARD           ║
╠════════════════════════════════════════════════════════════════╣
║  🚀 Server running on port ${PORT}                                 ║
║  📱 PWA ready for mobile installation                          ║
║  🔒 ${requiredSecrets.length - missingSecrets.length}/${requiredSecrets.length} Secrets configured                                   ║
║  🌍 Environment: ${NODE_ENV.padEnd(42)}║
╚════════════════════════════════════════════════════════════════╝

Endpoints:
  GET  /health         - Health check
  GET  /api/status     - System status
  POST /api/products/process - Process product through safeguards
  GET  /api/budget     - Budget status
  GET  /api/approvals  - Approval queue
  GET  /api/providers  - Provider health
  GET  /api/queue      - API queue stats
  `);
});

export default app;
