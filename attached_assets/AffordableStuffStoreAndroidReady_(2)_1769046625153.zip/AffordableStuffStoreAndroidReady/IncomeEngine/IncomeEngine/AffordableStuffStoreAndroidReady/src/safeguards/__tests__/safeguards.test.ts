/**
 * ============================================================================
 * SAFEGUARDS TEST SUITE
 * ============================================================================
 * 
 * Run with: npm run test:safeguards
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// =============================================================================
// MOCK SUPABASE CLIENT
// =============================================================================

const mockSupabaseClient = {
  from: vi.fn(() => ({
    select: vi.fn().mockReturnThis(),
    insert: vi.fn().mockReturnThis(),
    update: vi.fn().mockReturnThis(),
    delete: vi.fn().mockReturnThis(),
    eq: vi.fn().mockReturnThis(),
    neq: vi.fn().mockReturnThis(),
    gt: vi.fn().mockReturnThis(),
    gte: vi.fn().mockReturnThis(),
    lt: vi.fn().mockReturnThis(),
    lte: vi.fn().mockReturnThis(),
    in: vi.fn().mockReturnThis(),
    is: vi.fn().mockReturnThis(),
    or: vi.fn().mockReturnThis(),
    order: vi.fn().mockReturnThis(),
    limit: vi.fn().mockReturnThis(),
    single: vi.fn().mockResolvedValue({ data: null, error: null }),
  })),
  rpc: vi.fn().mockResolvedValue({ data: [], error: null }),
};

vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn(() => mockSupabaseClient),
}));

// =============================================================================
// SAFEGUARD #1: RATE LIMITER TESTS
// =============================================================================

describe('Safeguard #1: Rate Limiter', () => {
  it('should block uploads when daily limit exceeded', async () => {
    // Mock rate limit check response
    mockSupabaseClient.rpc.mockResolvedValueOnce({
      data: [{
        allowed: false,
        reason: 'Daily limit reached (5)',
        next_allowed_at: new Date(Date.now() + 86400000).toISOString(),
        current_hour_count: 2,
        current_day_count: 5
      }],
      error: null
    });

    // Rate limiter should return not allowed
    const result = {
      allowed: false,
      reason: 'Daily limit reached (5)',
      currentDayCount: 5
    };

    expect(result.allowed).toBe(false);
    expect(result.currentDayCount).toBe(5);
  });

  it('should add jitter to upload delays', () => {
    const minSeconds = 60;
    const maxSeconds = 300;
    
    // Calculate jitter
    const jitterMs = Math.floor(Math.random() * (maxSeconds - minSeconds + 1) * 1000) + minSeconds * 1000;
    
    expect(jitterMs).toBeGreaterThanOrEqual(minSeconds * 1000);
    expect(jitterMs).toBeLessThanOrEqual(maxSeconds * 1000);
  });

  it('should flag high-risk platforms for human review', () => {
    const platformConfigs = {
      amazon_kdp: { require_human_review: true, suspension_risk_level: 'critical' },
      printify: { require_human_review: false, suspension_risk_level: 'low' },
      redbubble: { require_human_review: true, suspension_risk_level: 'high' }
    };

    expect(platformConfigs.amazon_kdp.require_human_review).toBe(true);
    expect(platformConfigs.printify.require_human_review).toBe(false);
  });
});

// =============================================================================
// SAFEGUARD #2: QUALITY GATE TESTS
// =============================================================================

describe('Safeguard #2: Quality Gates', () => {
  it('should fail products below minimum quality score', () => {
    const qualityResult = {
      qualityScore: 0.65,
      minRequired: 0.70,
      passed: false
    };

    expect(qualityResult.qualityScore).toBeLessThan(qualityResult.minRequired);
    expect(qualityResult.passed).toBe(false);
  });

  it('should detect AI-typical language patterns', () => {
    const aiPatterns = [
      /as an ai/i,
      /certainly!/i,
      /delve into/i,
      /it's important to note/i
    ];

    const badCopy = "As an AI, I certainly find this delve into the subject fascinating.";
    const goodCopy = "Beautiful mandala patterns for relaxation and mindfulness.";

    const hasBadPatterns = aiPatterns.some(p => p.test(badCopy));
    const hasGoodPatterns = aiPatterns.some(p => p.test(goodCopy));

    expect(hasBadPatterns).toBe(true);
    expect(hasGoodPatterns).toBe(false);
  });

  it('should flag low resolution images', () => {
    const config = {
      min_resolution_width: 2400,
      min_resolution_height: 3000
    };

    const lowResImage = { width: 1000, height: 1000 };
    const highResImage = { width: 2400, height: 3000 };

    const lowResPasses = lowResImage.width >= config.min_resolution_width && 
                         lowResImage.height >= config.min_resolution_height;
    const highResPasses = highResImage.width >= config.min_resolution_width && 
                          highResImage.height >= config.min_resolution_height;

    expect(lowResPasses).toBe(false);
    expect(highResPasses).toBe(true);
  });
});

// =============================================================================
// SAFEGUARD #3: TRADEMARK SCREENING TESTS
// =============================================================================

describe('Safeguard #3: Trademark Screening', () => {
  const blockedTerms = new Set([
    'disney', 'marvel', 'pokemon', 'nike', 'star wars',
    'hello kitty', 'peppa pig', 'paw patrol'
  ]);

  it('should block known trademarked terms', () => {
    const testTitle = "Disney Princess Coloring Book";
    const words = testTitle.toLowerCase().split(' ');
    const hasBlocked = words.some(word => blockedTerms.has(word));

    expect(hasBlocked).toBe(true);
  });

  it('should allow generic terms', () => {
    const testTitle = "Mandala Patterns Coloring Book";
    const words = testTitle.toLowerCase().split(' ');
    const hasBlocked = words.some(word => blockedTerms.has(word));

    expect(hasBlocked).toBe(false);
  });

  it('should extract terms for checking', () => {
    const title = "Cute Cat Designs";
    const expectedTerms = ['cute', 'cat', 'designs', 'cute cat', 'cat designs'];
    
    const words = title.toLowerCase().split(' ');
    const terms: string[] = [...words];
    
    for (let i = 0; i < words.length - 1; i++) {
      terms.push(`${words[i]} ${words[i + 1]}`);
    }

    expect(terms).toEqual(expectedTerms);
  });
});

// =============================================================================
// SAFEGUARD #4: API QUEUE TESTS
// =============================================================================

describe('Safeguard #4: API Queue with Backoff', () => {
  it('should calculate exponential backoff correctly', () => {
    const calculateBackoff = (attemptCount: number, baseMultiplier = 1.5, maxSeconds = 3600) => {
      const baseDelay = 5;
      const exponentialDelay = baseDelay * Math.pow(baseMultiplier, attemptCount);
      return Math.min(exponentialDelay, maxSeconds);
    };

    expect(calculateBackoff(0)).toBe(5);       // 5 * 1.5^0 = 5
    expect(calculateBackoff(1)).toBe(7.5);     // 5 * 1.5^1 = 7.5
    expect(calculateBackoff(2)).toBe(11.25);   // 5 * 1.5^2 = 11.25
    expect(calculateBackoff(10)).toBeCloseTo(288.54, 1); // 5 * 1.5^10
    expect(calculateBackoff(20)).toBeLessThanOrEqual(3600); // Capped at max
  });

  it('should respect rate limits per API', () => {
    const apiLimits = {
      openai: { requestsPerMinute: 60, requestsPerHour: 3500 },
      printify: { requestsPerMinute: 120, requestsPerHour: 3600 },
      etsy: { requestsPerMinute: 20, requestsPerHour: 500 }
    };

    expect(apiLimits.openai.requestsPerMinute).toBe(60);
    expect(apiLimits.etsy.requestsPerMinute).toBe(20);
  });

  it('should move failed requests to dead letter queue after max attempts', () => {
    const request = {
      attemptCount: 5,
      maxAttempts: 5,
      status: 'failed'
    };

    const shouldDeadLetter = request.attemptCount >= request.maxAttempts;
    expect(shouldDeadLetter).toBe(true);
  });
});

// =============================================================================
// SAFEGUARD #5: PROVIDER FAILOVER TESTS
// =============================================================================

describe('Safeguard #5: Provider Failover', () => {
  it('should select primary provider when healthy', () => {
    const providers = [
      { name: 'monster_digital', isPrimary: true, isAvailable: true, healthScore: 0.95 },
      { name: 'printful', isPrimary: false, isAvailable: true, healthScore: 0.90 }
    ];

    const selected = providers
      .filter(p => p.isAvailable)
      .sort((a, b) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0))[0];

    expect(selected.name).toBe('monster_digital');
  });

  it('should failover to backup when primary unavailable', () => {
    const providers = [
      { name: 'monster_digital', isPrimary: true, isAvailable: false, healthScore: 0 },
      { name: 'printful', isPrimary: false, isAvailable: true, healthScore: 0.90 }
    ];

    const selected = providers
      .filter(p => p.isAvailable)
      .sort((a, b) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0))[0];

    expect(selected.name).toBe('printful');
  });

  it('should reduce health score on failure', () => {
    let healthScore = 1.0;
    const decreaseAmount = 0.1;

    // Simulate 3 failures
    for (let i = 0; i < 3; i++) {
      healthScore = Math.max(0, healthScore - decreaseAmount);
    }

    expect(healthScore).toBe(0.7);
  });
});

// =============================================================================
// SAFEGUARD #6: TAX COMPLIANCE TESTS
// =============================================================================

describe('Safeguard #6: Tax Compliance', () => {
  it('should calculate US sales tax correctly', () => {
    const subtotal = 29.99;
    const taxRate = 0.0725; // California
    const taxAmount = subtotal * taxRate;

    expect(taxAmount).toBeCloseTo(2.17, 2);
  });

  it('should calculate EU VAT correctly', () => {
    const subtotal = 29.99;
    const vatRate = 0.19; // Germany
    const vatAmount = subtotal * vatRate;

    expect(vatAmount).toBeCloseTo(5.70, 2);
  });

  it('should detect nexus threshold approaching', () => {
    const threshold = 100000;
    const currentRevenue = 85000;
    const percentOfThreshold = (currentRevenue / threshold) * 100;

    expect(percentOfThreshold).toBe(85);
    expect(percentOfThreshold >= 75).toBe(true); // Warning threshold
  });
});

// =============================================================================
// SAFEGUARD #7: HUMAN IN THE LOOP TESTS
// =============================================================================

describe('Safeguard #7: Human-in-the-Loop', () => {
  it('should require human review for first 50 products', () => {
    const settings = {
      minProductsBeforeAuto: 50,
      qualityScoreForAuto: 0.85
    };

    const approvedCount = 30;
    const requiresReview = approvedCount < settings.minProductsBeforeAuto;

    expect(requiresReview).toBe(true);
  });

  it('should allow auto-approval after threshold met', () => {
    const settings = {
      minProductsBeforeAuto: 50,
      qualityScoreForAuto: 0.85
    };

    const approvedCount = 55;
    const qualityScore = 0.90;

    const requiresReview = approvedCount < settings.minProductsBeforeAuto;
    const canAutoApprove = !requiresReview && qualityScore >= settings.qualityScoreForAuto;

    expect(canAutoApprove).toBe(true);
  });

  it('should still require review for low quality even after threshold', () => {
    const settings = {
      minProductsBeforeAuto: 50,
      qualityScoreForAuto: 0.85
    };

    const approvedCount = 60;
    const qualityScore = 0.70; // Below auto-approve threshold

    const canAutoApprove = approvedCount >= settings.minProductsBeforeAuto && 
                           qualityScore >= settings.qualityScoreForAuto;

    expect(canAutoApprove).toBe(false);
  });
});

// =============================================================================
// SAFEGUARD #8: BUDGET CIRCUIT BREAKER TESTS
// =============================================================================

describe('Safeguard #8: Budget Circuit Breaker', () => {
  it('should track API costs correctly', () => {
    const costs = {
      'openai/dall-e-3': 0.04,
      'openai/gpt-4o': 0.005,
      'replicate/flux-schnell': 0.003
    };

    // Simulate product generation
    const imageGenCost = costs['openai/dall-e-3'];
    const qualityCheckCost = costs['openai/gpt-4o'];
    const totalCost = imageGenCost + qualityCheckCost;

    expect(totalCost).toBe(0.045);
  });

  it('should trigger warning at 80% budget', () => {
    const budget = {
      limit: 25.00,
      warningThreshold: 80,
      currentSpend: 20.50
    };

    const percentUsed = (budget.currentSpend / budget.limit) * 100;
    const isWarning = percentUsed >= budget.warningThreshold;

    expect(percentUsed).toBe(82);
    expect(isWarning).toBe(true);
  });

  it('should open circuit breaker when budget exceeded', () => {
    const budget = {
      limit: 25.00,
      currentSpend: 26.00
    };

    const isExceeded = budget.currentSpend >= budget.limit;

    expect(isExceeded).toBe(true);
  });

  it('should enforce per-product cost limits', () => {
    const perProductLimit = 0.50;
    const productCosts = [
      { productId: 'p1', cost: 0.15 },
      { productId: 'p2', cost: 0.45 },
      { productId: 'p3', cost: 0.60 } // Exceeds limit
    ];

    const exceededProducts = productCosts.filter(p => p.cost > perProductLimit);
    expect(exceededProducts.length).toBe(1);
    expect(exceededProducts[0].productId).toBe('p3');
  });
});

// =============================================================================
// INTEGRATION TESTS
// =============================================================================

describe('Integration: Full Pipeline', () => {
  it('should process product through all safeguards', async () => {
    const product = {
      id: 'test-product-1',
      type: 'coloring_book',
      niche: 'adult_coloring',
      title: 'Mandala Patterns Coloring Book',
      description: 'Beautiful mandala designs for relaxation',
      keywords: ['mandala', 'coloring', 'relaxation'],
      imageUrl: 'https://example.com/image.png',
      targetPlatforms: ['printify', 'etsy']
    };

    // Simulate pipeline stages
    const stages = {
      budgetCheck: true,
      trademarkCheck: true,
      qualityCheck: true,
      rateLimitCheck: true,
      humanReviewCheck: true
    };

    // All stages pass
    const allPassed = Object.values(stages).every(v => v);
    expect(allPassed).toBe(true);
  });

  it('should block product with trademark violation', async () => {
    const product = {
      id: 'test-product-2',
      title: 'Disney Princess Coloring Book' // Contains blocked term
    };

    const blockedTerms = ['disney'];
    const hasViolation = blockedTerms.some(term => 
      product.title.toLowerCase().includes(term)
    );

    expect(hasViolation).toBe(true);
  });
});
