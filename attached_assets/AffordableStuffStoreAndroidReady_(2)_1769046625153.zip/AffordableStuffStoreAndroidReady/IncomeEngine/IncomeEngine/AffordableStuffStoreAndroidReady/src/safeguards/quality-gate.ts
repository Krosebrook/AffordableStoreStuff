/**
 * ============================================================================
 * SAFEGUARD #2: AI QUALITY GATES
 * ============================================================================
 * 
 * Purpose: Prevent "AI slop" from being published by enforcing quality standards
 * 
 * Features:
 * - Style consistency checking via embeddings
 * - Niche relevance scoring
 * - Originality detection (similarity to existing products)
 * - Composition quality analysis
 * - Automated rejection of low-quality content
 * - Multi-stage quality pipeline
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

// =============================================================================
// TYPES
// =============================================================================

interface QualityConfig {
  product_type: string;
  min_resolution_width: number;
  min_resolution_height: number;
  min_quality_score: number;
  banned_style_keywords: string[];
  required_style_keywords: string[];
  niche_consistency_threshold: number;
  max_similarity_to_existing: number;
  require_unique_composition: boolean;
}

interface QualityAssessment {
  productId: string;
  assessmentType: 'image' | 'copy' | 'overall';
  qualityScore: number;
  styleConsistencyScore: number;
  nicheRelevanceScore: number;
  originalityScore: number;
  compositionScore: number;
  issuesDetected: QualityIssue[];
  passed: boolean;
  assessor: 'ai' | 'human';
}

interface QualityIssue {
  type: 'resolution' | 'style' | 'originality' | 'composition' | 'niche' | 'banned_content';
  severity: 'warning' | 'error' | 'critical';
  message: string;
  field?: string;
}

interface ImageAnalysisResult {
  width: number;
  height: number;
  format: string;
  hasWatermark: boolean;
  isBlurry: boolean;
  colorPalette: string[];
  dominantColors: string[];
  detectedObjects: string[];
  styleKeywords: string[];
  aestheticScore: number;
}

interface ProductData {
  id: string;
  type: string;
  niche: string;
  title: string;
  description: string;
  keywords: string[];
  imageUrl: string;
  imageBase64?: string;
}

// =============================================================================
// QUALITY GATE CLASS
// =============================================================================

export class QualityGate {
  private supabase: SupabaseClient;
  private openai: OpenAI;
  private configCache: Map<string, QualityConfig> = new Map();

  constructor(
    supabaseUrl: string, 
    supabaseKey: string,
    openaiKey: string
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.openai = new OpenAI({ apiKey: openaiKey });
  }

  /**
   * Run full quality assessment pipeline on a product
   */
  async assessProduct(product: ProductData): Promise<QualityAssessment> {
    const config = await this.getQualityConfig(product.type);
    const issues: QualityIssue[] = [];
    
    // 1. Image Quality Analysis
    const imageAnalysis = await this.analyzeImage(product.imageUrl, product.imageBase64);
    
    // Check resolution
    if (imageAnalysis.width < config.min_resolution_width || 
        imageAnalysis.height < config.min_resolution_height) {
      issues.push({
        type: 'resolution',
        severity: 'error',
        message: `Image resolution ${imageAnalysis.width}x${imageAnalysis.height} is below minimum ${config.min_resolution_width}x${config.min_resolution_height}`
      });
    }

    // Check for watermarks/blur
    if (imageAnalysis.hasWatermark) {
      issues.push({
        type: 'composition',
        severity: 'critical',
        message: 'Watermark detected in image'
      });
    }

    if (imageAnalysis.isBlurry) {
      issues.push({
        type: 'composition',
        severity: 'error',
        message: 'Image appears blurry or low quality'
      });
    }

    // Check banned style keywords
    const bannedFound = config.banned_style_keywords.filter(
      banned => imageAnalysis.styleKeywords.some(
        keyword => keyword.toLowerCase().includes(banned.toLowerCase())
      )
    );
    
    if (bannedFound.length > 0) {
      issues.push({
        type: 'banned_content',
        severity: 'critical',
        message: `Banned style elements detected: ${bannedFound.join(', ')}`
      });
    }

    // 2. Style Consistency Check
    const styleConsistencyScore = await this.checkStyleConsistency(
      product.niche, 
      imageAnalysis.styleKeywords,
      product.imageBase64
    );

    if (styleConsistencyScore < config.niche_consistency_threshold) {
      issues.push({
        type: 'style',
        severity: 'warning',
        message: `Style consistency score ${styleConsistencyScore.toFixed(2)} is below threshold ${config.niche_consistency_threshold}`
      });
    }

    // 3. Niche Relevance Check
    const nicheRelevanceScore = await this.checkNicheRelevance(product);
    
    if (nicheRelevanceScore < 0.6) {
      issues.push({
        type: 'niche',
        severity: 'warning',
        message: `Product may not be relevant to niche "${product.niche}" (score: ${nicheRelevanceScore.toFixed(2)})`
      });
    }

    // 4. Originality Check (similarity to existing products)
    const originalityScore = await this.checkOriginality(product);
    
    if (originalityScore < (1 - config.max_similarity_to_existing)) {
      issues.push({
        type: 'originality',
        severity: 'error',
        message: `Product too similar to existing products (originality: ${originalityScore.toFixed(2)})`
      });
    }

    // 5. Copy Quality Check
    const copyQualityIssues = await this.assessCopyQuality(product);
    issues.push(...copyQualityIssues);

    // 6. Calculate overall scores
    const compositionScore = imageAnalysis.aestheticScore;
    const qualityScore = this.calculateOverallScore({
      composition: compositionScore,
      style: styleConsistencyScore,
      niche: nicheRelevanceScore,
      originality: originalityScore,
      issueCount: issues.length,
      criticalIssues: issues.filter(i => i.severity === 'critical').length
    });

    // Determine if passed
    const passed = qualityScore >= config.min_quality_score && 
                   issues.filter(i => i.severity === 'critical').length === 0;

    // Create assessment record
    const assessment: QualityAssessment = {
      productId: product.id,
      assessmentType: 'overall',
      qualityScore,
      styleConsistencyScore,
      nicheRelevanceScore,
      originalityScore,
      compositionScore,
      issuesDetected: issues,
      passed,
      assessor: 'ai'
    };

    // Save to database
    await this.saveAssessment(assessment);

    return assessment;
  }

  /**
   * Analyze image using Vision AI
   */
  private async analyzeImage(imageUrl: string, imageBase64?: string): Promise<ImageAnalysisResult> {
    // Use GPT-4 Vision for analysis
    const imageContent = imageBase64 
      ? { type: 'image_url' as const, image_url: { url: `data:image/png;base64,${imageBase64}` } }
      : { type: 'image_url' as const, image_url: { url: imageUrl } };

    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are an expert image quality analyst for print-on-demand and digital products. 
          Analyze the image and provide a JSON response with these fields:
          - hasWatermark (boolean): Does the image contain any watermarks, signatures, or attribution text?
          - isBlurry (boolean): Is the image blurry, pixelated, or low quality?
          - dominantColors (array): Top 5 hex color codes in the image
          - styleKeywords (array): 10-15 keywords describing the art style (e.g., "minimalist", "cartoon", "watercolor")
          - detectedObjects (array): Main objects/subjects in the image
          - aestheticScore (number 0-1): Overall aesthetic quality score
          - potentialIssues (array): Any issues that might cause problems for print products`
        },
        {
          role: 'user',
          content: [
            { type: 'text', text: 'Analyze this image for quality and style:' },
            imageContent
          ]
        }
      ],
      max_tokens: 1000,
      response_format: { type: 'json_object' }
    });

    const analysis = JSON.parse(response.choices[0].message.content || '{}');

    // Get actual dimensions (in production, use sharp or similar)
    // For now, assume decent resolution if no issues detected
    return {
      width: analysis.hasWatermark || analysis.isBlurry ? 1000 : 3000,
      height: analysis.hasWatermark || analysis.isBlurry ? 1000 : 3000,
      format: 'png',
      hasWatermark: analysis.hasWatermark || false,
      isBlurry: analysis.isBlurry || false,
      colorPalette: analysis.dominantColors || [],
      dominantColors: analysis.dominantColors?.slice(0, 3) || [],
      detectedObjects: analysis.detectedObjects || [],
      styleKeywords: analysis.styleKeywords || [],
      aestheticScore: analysis.aestheticScore || 0.5
    };
  }

  /**
   * Check style consistency against niche baseline
   */
  private async checkStyleConsistency(
    niche: string, 
    styleKeywords: string[],
    imageBase64?: string
  ): Promise<number> {
    // Get niche style embeddings from database
    const { data: nicheStyles } = await this.supabase
      .from('style_embeddings')
      .select('style_name, embedding')
      .eq('niche', niche);

    if (!nicheStyles || nicheStyles.length === 0) {
      // No baseline, return moderate score
      return 0.75;
    }

    // Generate embedding for current product style
    const styleDescription = styleKeywords.join(', ');
    const embeddingResponse = await this.openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: styleDescription
    });

    const currentEmbedding = embeddingResponse.data[0].embedding;

    // Calculate similarity to niche baselines
    let maxSimilarity = 0;
    for (const nicheStyle of nicheStyles) {
      if (nicheStyle.embedding) {
        const similarity = this.cosineSimilarity(currentEmbedding, nicheStyle.embedding);
        maxSimilarity = Math.max(maxSimilarity, similarity);
      }
    }

    return maxSimilarity;
  }

  /**
   * Check if product is relevant to its claimed niche
   */
  private async checkNicheRelevance(product: ProductData): Promise<number> {
    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: `You are evaluating if a product is relevant to its claimed niche/category.
          Rate the relevance from 0 to 1, where:
          0 = completely irrelevant
          0.5 = somewhat related
          1 = perfectly relevant
          
          Respond with just a JSON object: {"score": 0.X, "reason": "brief explanation"}`
        },
        {
          role: 'user',
          content: `
          Niche: ${product.niche}
          Product Type: ${product.type}
          Title: ${product.title}
          Description: ${product.description}
          Keywords: ${product.keywords.join(', ')}
          
          Is this product relevant to its claimed niche?`
        }
      ],
      max_tokens: 200,
      response_format: { type: 'json_object' }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"score": 0.5}');
    return result.score;
  }

  /**
   * Check originality against existing products
   */
  private async checkOriginality(product: ProductData): Promise<number> {
    // Generate embedding for product
    const productText = `${product.title} ${product.description} ${product.keywords.join(' ')}`;
    const embeddingResponse = await this.openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: productText
    });

    const productEmbedding = embeddingResponse.data[0].embedding;

    // Compare against recent products in same niche
    const { data: recentProducts } = await this.supabase
      .from('products')
      .select('id, title')
      .eq('niche', product.niche)
      .eq('status', 'published')
      .neq('id', product.id)
      .order('created_at', { ascending: false })
      .limit(50);

    if (!recentProducts || recentProducts.length === 0) {
      return 1.0; // No existing products to compare
    }

    // Generate embeddings for recent products and compare
    // (In production, store embeddings in vector database)
    const recentTexts = recentProducts.map(p => p.title);
    const recentEmbeddings = await this.openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: recentTexts
    });

    let maxSimilarity = 0;
    for (const embedding of recentEmbeddings.data) {
      const similarity = this.cosineSimilarity(productEmbedding, embedding.embedding);
      maxSimilarity = Math.max(maxSimilarity, similarity);
    }

    // Originality is inverse of similarity
    return 1 - maxSimilarity;
  }

  /**
   * Assess quality of product copy (title, description)
   */
  private async assessCopyQuality(product: ProductData): Promise<QualityIssue[]> {
    const issues: QualityIssue[] = [];

    // Check title length
    if (product.title.length < 10) {
      issues.push({
        type: 'composition',
        severity: 'warning',
        message: 'Title is too short (minimum 10 characters)',
        field: 'title'
      });
    }

    if (product.title.length > 200) {
      issues.push({
        type: 'composition',
        severity: 'warning',
        message: 'Title is too long (maximum 200 characters)',
        field: 'title'
      });
    }

    // Check description
    if (product.description.length < 50) {
      issues.push({
        type: 'composition',
        severity: 'warning',
        message: 'Description is too short (minimum 50 characters)',
        field: 'description'
      });
    }

    // Check for AI-typical patterns
    const aiPatterns = [
      /as an ai/i,
      /i cannot/i,
      /i'm sorry/i,
      /certainly!/i,
      /absolutely!/i,
      /delve into/i,
      /it's important to note/i,
      /in conclusion/i
    ];

    for (const pattern of aiPatterns) {
      if (pattern.test(product.description) || pattern.test(product.title)) {
        issues.push({
          type: 'style',
          severity: 'error',
          message: 'Copy contains AI-typical language patterns that should be removed'
        });
        break;
      }
    }

    // Check keyword stuffing
    const wordCounts = new Map<string, number>();
    const words = product.description.toLowerCase().split(/\s+/);
    for (const word of words) {
      if (word.length > 3) {
        wordCounts.set(word, (wordCounts.get(word) || 0) + 1);
      }
    }

    const totalWords = words.length;
    for (const [word, count] of wordCounts) {
      if (count / totalWords > 0.05) { // Word appears more than 5% of the time
        issues.push({
          type: 'style',
          severity: 'warning',
          message: `Possible keyword stuffing detected: "${word}" appears ${count} times`
        });
      }
    }

    return issues;
  }

  /**
   * Calculate overall quality score
   */
  private calculateOverallScore(factors: {
    composition: number;
    style: number;
    niche: number;
    originality: number;
    issueCount: number;
    criticalIssues: number;
  }): number {
    // Weighted average
    let score = (
      factors.composition * 0.25 +
      factors.style * 0.20 +
      factors.niche * 0.20 +
      factors.originality * 0.35
    );

    // Penalize for issues
    score -= factors.issueCount * 0.02;
    
    // Critical issues are heavily penalized
    score -= factors.criticalIssues * 0.15;

    return Math.max(0, Math.min(1, score));
  }

  /**
   * Calculate cosine similarity between two vectors
   */
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) return 0;
    
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    
    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Get quality config for product type
   */
  private async getQualityConfig(productType: string): Promise<QualityConfig> {
    if (this.configCache.has(productType)) {
      return this.configCache.get(productType)!;
    }

    const { data, error } = await this.supabase
      .from('quality_gate_configs')
      .select('*')
      .eq('product_type', productType)
      .single();

    if (error || !data) {
      // Return default config
      return {
        product_type: productType,
        min_resolution_width: 2000,
        min_resolution_height: 2000,
        min_quality_score: 0.70,
        banned_style_keywords: ['blurry', 'watermark', 'trademark'],
        required_style_keywords: [],
        niche_consistency_threshold: 0.70,
        max_similarity_to_existing: 0.85,
        require_unique_composition: true
      };
    }

    this.configCache.set(productType, data);
    return data;
  }

  /**
   * Save assessment to database
   */
  private async saveAssessment(assessment: QualityAssessment): Promise<void> {
    const { error } = await this.supabase
      .from('quality_assessments')
      .insert({
        product_id: assessment.productId,
        assessment_type: assessment.assessmentType,
        quality_score: assessment.qualityScore,
        style_consistency_score: assessment.styleConsistencyScore,
        niche_relevance_score: assessment.nicheRelevanceScore,
        originality_score: assessment.originalityScore,
        composition_score: assessment.compositionScore,
        issues_detected: assessment.issuesDetected,
        passed: assessment.passed,
        assessor: assessment.assessor
      });

    if (error) {
      console.error('Failed to save quality assessment:', error);
    }
  }

  /**
   * Store style embedding for a niche (building baseline)
   */
  async storeStyleBaseline(niche: string, styleName: string, styleDescription: string): Promise<void> {
    const embeddingResponse = await this.openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: styleDescription
    });

    const embedding = embeddingResponse.data[0].embedding;

    await this.supabase
      .from('style_embeddings')
      .upsert({
        niche,
        style_name: styleName,
        embedding,
        created_at: new Date().toISOString()
      }, {
        onConflict: 'niche,style_name'
      });
  }
}

export default QualityGate;
