/**
 * ============================================================================
 * SAFEGUARD #4: API QUEUE WITH EXPONENTIAL BACKOFF
 * ============================================================================
 * 
 * Purpose: Prevent API rate limit violations with smart queuing and backoff
 * 
 * Features:
 * - Priority-based queue (1-10, higher = more urgent)
 * - Per-API rate limit tracking (minute/hour/day)
 * - Exponential backoff with jitter
 * - Dead letter queue for failed requests
 * - Circuit breaker integration
 * - Request deduplication
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// =============================================================================
// TYPES
// =============================================================================

interface QueuedRequest {
  id: string;
  apiName: string;
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  payload: Record<string, any>;
  priority: number;
  status: 'queued' | 'processing' | 'completed' | 'failed' | 'rate_limited' | 'dead_letter';
  attemptCount: number;
  maxAttempts: number;
  lastError?: string;
  backoffUntil?: Date;
  createdAt: Date;
  processedAt?: Date;
  response?: Record<string, any>;
}

interface ApiRateLimit {
  apiName: string;
  requestsPerMinute: number;
  requestsPerHour: number;
  requestsPerDay: number;
  currentMinuteCount: number;
  currentHourCount: number;
  currentDayCount: number;
  minuteResetAt: Date;
  hourResetAt: Date;
  dayResetAt: Date;
  backoffMultiplier: number;
  maxBackoffSeconds: number;
}

interface ExecutionResult {
  success: boolean;
  response?: any;
  error?: string;
  rateLimited?: boolean;
  retryAfter?: number;
}

// =============================================================================
// API QUEUE CLASS
// =============================================================================

export class ApiQueue {
  private supabase: SupabaseClient;
  private isProcessing: boolean = false;
  private processInterval: NodeJS.Timer | null = null;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * Add a request to the queue
   */
  async enqueue(request: {
    apiName: string;
    endpoint: string;
    method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    payload?: Record<string, any>;
    priority?: number;
    maxAttempts?: number;
  }): Promise<string> {
    const { data, error } = await this.supabase
      .from('api_queue')
      .insert({
        api_name: request.apiName,
        endpoint: request.endpoint,
        method: request.method || 'POST',
        payload: request.payload || {},
        priority: Math.min(10, Math.max(1, request.priority || 5)),
        status: 'queued',
        attempt_count: 0,
        max_attempts: request.maxAttempts || 5
      })
      .select('id')
      .single();

    if (error) {
      throw new Error(`Failed to enqueue request: ${error.message}`);
    }

    return data.id;
  }

  /**
   * Process the next available request from queue
   */
  async processNext(): Promise<QueuedRequest | null> {
    // Get next request that's ready to process
    const { data: request, error } = await this.supabase
      .from('api_queue')
      .select('*')
      .in('status', ['queued', 'rate_limited'])
      .or(`backoff_until.is.null,backoff_until.lt.${new Date().toISOString()}`)
      .order('priority', { ascending: false })
      .order('created_at', { ascending: true })
      .limit(1)
      .single();

    if (error || !request) {
      return null;
    }

    // Check rate limits before processing
    const canProcess = await this.checkRateLimit(request.api_name);
    if (!canProcess.allowed) {
      // Update with backoff
      await this.setBackoff(request.id, canProcess.retryAfterSeconds || 60);
      return null;
    }

    // Mark as processing
    await this.supabase
      .from('api_queue')
      .update({ status: 'processing' })
      .eq('id', request.id);

    try {
      // Execute the request
      const result = await this.executeRequest(request);

      if (result.success) {
        await this.markCompleted(request.id, result.response);
        await this.incrementRateCount(request.api_name);
      } else if (result.rateLimited) {
        await this.handleRateLimited(request, result.retryAfter);
      } else {
        await this.handleFailure(request, result.error);
      }

      return request;

    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      await this.handleFailure(request, errorMsg);
      return request;
    }
  }

  /**
   * Execute an API request
   */
  private async executeRequest(request: QueuedRequest): Promise<ExecutionResult> {
    try {
      const response = await fetch(request.endpoint, {
        method: request.method,
        headers: {
          'Content-Type': 'application/json',
          // API keys should be added per-API in a production system
        },
        body: request.method !== 'GET' ? JSON.stringify(request.payload) : undefined
      });

      // Check for rate limiting
      if (response.status === 429) {
        const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
        return {
          success: false,
          rateLimited: true,
          retryAfter,
          error: 'Rate limited'
        };
      }

      if (!response.ok) {
        return {
          success: false,
          error: `HTTP ${response.status}: ${await response.text()}`
        };
      }

      const data = await response.json();
      return {
        success: true,
        response: data
      };

    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Request failed'
      };
    }
  }

  /**
   * Check if we can make a request to this API
   */
  async checkRateLimit(apiName: string): Promise<{
    allowed: boolean;
    retryAfterSeconds?: number;
    reason?: string;
  }> {
    // Reset counters if periods have elapsed
    await this.resetExpiredCounters(apiName);

    // Get current limits
    const { data: limits } = await this.supabase
      .from('api_rate_limits')
      .select('*')
      .eq('api_name', apiName)
      .single();

    if (!limits) {
      // No limits configured, allow
      return { allowed: true };
    }

    // Check minute limit
    if (limits.current_minute_count >= limits.requests_per_minute) {
      const retryAfter = Math.ceil((new Date(limits.minute_reset_at).getTime() - Date.now()) / 1000);
      return {
        allowed: false,
        retryAfterSeconds: Math.max(1, retryAfter),
        reason: `Minute limit reached (${limits.requests_per_minute}/min)`
      };
    }

    // Check hour limit
    if (limits.current_hour_count >= limits.requests_per_hour) {
      const retryAfter = Math.ceil((new Date(limits.hour_reset_at).getTime() - Date.now()) / 1000);
      return {
        allowed: false,
        retryAfterSeconds: Math.max(1, retryAfter),
        reason: `Hour limit reached (${limits.requests_per_hour}/hr)`
      };
    }

    // Check day limit
    if (limits.current_day_count >= limits.requests_per_day) {
      const retryAfter = Math.ceil((new Date(limits.day_reset_at).getTime() - Date.now()) / 1000);
      return {
        allowed: false,
        retryAfterSeconds: Math.max(1, retryAfter),
        reason: `Day limit reached (${limits.requests_per_day}/day)`
      };
    }

    return { allowed: true };
  }

  /**
   * Increment rate limit counters
   */
  private async incrementRateCount(apiName: string): Promise<void> {
    await this.supabase.rpc('increment_rate_count', { p_api_name: apiName });
    
    // Fallback if RPC not available
    const { data: limits } = await this.supabase
      .from('api_rate_limits')
      .select('*')
      .eq('api_name', apiName)
      .single();

    if (limits) {
      await this.supabase
        .from('api_rate_limits')
        .update({
          current_minute_count: limits.current_minute_count + 1,
          current_hour_count: limits.current_hour_count + 1,
          current_day_count: limits.current_day_count + 1,
          updated_at: new Date().toISOString()
        })
        .eq('api_name', apiName);
    }
  }

  /**
   * Reset expired counter periods
   */
  private async resetExpiredCounters(apiName: string): Promise<void> {
    const now = new Date();

    const { data: limits } = await this.supabase
      .from('api_rate_limits')
      .select('*')
      .eq('api_name', apiName)
      .single();

    if (!limits) return;

    const updates: Record<string, any> = {};

    if (new Date(limits.minute_reset_at) < now) {
      updates.current_minute_count = 0;
      updates.minute_reset_at = new Date(now.getTime() + 60000).toISOString();
    }

    if (new Date(limits.hour_reset_at) < now) {
      updates.current_hour_count = 0;
      updates.hour_reset_at = new Date(now.getTime() + 3600000).toISOString();
    }

    if (new Date(limits.day_reset_at) < now) {
      updates.current_day_count = 0;
      updates.day_reset_at = new Date(now.getTime() + 86400000).toISOString();
    }

    if (Object.keys(updates).length > 0) {
      await this.supabase
        .from('api_rate_limits')
        .update(updates)
        .eq('api_name', apiName);
    }
  }

  /**
   * Calculate exponential backoff with jitter
   */
  private calculateBackoff(attemptCount: number, baseMultiplier: number = 1.5, maxSeconds: number = 3600): number {
    // Exponential backoff: baseDelay * multiplier^attempts
    const baseDelay = 5; // 5 seconds
    const exponentialDelay = baseDelay * Math.pow(baseMultiplier, attemptCount);
    
    // Cap at max
    const cappedDelay = Math.min(exponentialDelay, maxSeconds);
    
    // Add jitter (±20%)
    const jitter = cappedDelay * 0.2 * (Math.random() * 2 - 1);
    
    return Math.max(1, Math.round(cappedDelay + jitter));
  }

  /**
   * Set backoff for a request
   */
  private async setBackoff(requestId: string, seconds: number): Promise<void> {
    const backoffUntil = new Date(Date.now() + seconds * 1000);
    
    await this.supabase
      .from('api_queue')
      .update({
        status: 'rate_limited',
        backoff_until: backoffUntil.toISOString()
      })
      .eq('id', requestId);
  }

  /**
   * Handle rate limited response
   */
  private async handleRateLimited(request: QueuedRequest, retryAfter?: number): Promise<void> {
    const backoffSeconds = retryAfter || this.calculateBackoff(request.attemptCount);
    
    await this.supabase
      .from('api_queue')
      .update({
        status: 'rate_limited',
        attempt_count: request.attemptCount + 1,
        last_error: 'Rate limited by API',
        backoff_until: new Date(Date.now() + backoffSeconds * 1000).toISOString()
      })
      .eq('id', request.id);
  }

  /**
   * Handle request failure
   */
  private async handleFailure(request: QueuedRequest, error?: string): Promise<void> {
    const newAttemptCount = request.attemptCount + 1;
    
    if (newAttemptCount >= request.maxAttempts) {
      // Move to dead letter queue
      await this.supabase
        .from('api_queue')
        .update({
          status: 'dead_letter',
          attempt_count: newAttemptCount,
          last_error: error,
          processed_at: new Date().toISOString()
        })
        .eq('id', request.id);
      
      console.error(`Request ${request.id} moved to dead letter queue after ${newAttemptCount} attempts`);
    } else {
      // Retry with backoff
      const backoffSeconds = this.calculateBackoff(newAttemptCount);
      
      await this.supabase
        .from('api_queue')
        .update({
          status: 'queued',
          attempt_count: newAttemptCount,
          last_error: error,
          backoff_until: new Date(Date.now() + backoffSeconds * 1000).toISOString()
        })
        .eq('id', request.id);
    }
  }

  /**
   * Mark request as completed
   */
  private async markCompleted(requestId: string, response?: any): Promise<void> {
    await this.supabase
      .from('api_queue')
      .update({
        status: 'completed',
        processed_at: new Date().toISOString(),
        response
      })
      .eq('id', requestId);
  }

  /**
   * Start automatic queue processing
   */
  startProcessing(intervalMs: number = 1000): void {
    if (this.processInterval) {
      return; // Already running
    }

    this.processInterval = setInterval(async () => {
      if (this.isProcessing) return;
      
      this.isProcessing = true;
      try {
        await this.processNext();
      } catch (error) {
        console.error('Queue processing error:', error);
      } finally {
        this.isProcessing = false;
      }
    }, intervalMs);
  }

  /**
   * Stop automatic processing
   */
  stopProcessing(): void {
    if (this.processInterval) {
      clearInterval(this.processInterval);
      this.processInterval = null;
    }
  }

  /**
   * Get queue statistics
   */
  async getStats(): Promise<{
    queued: number;
    processing: number;
    rateLimited: number;
    deadLetter: number;
    completedToday: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data } = await this.supabase
      .from('api_queue')
      .select('status');

    if (!data) {
      return { queued: 0, processing: 0, rateLimited: 0, deadLetter: 0, completedToday: 0 };
    }

    const stats = {
      queued: data.filter(r => r.status === 'queued').length,
      processing: data.filter(r => r.status === 'processing').length,
      rateLimited: data.filter(r => r.status === 'rate_limited').length,
      deadLetter: data.filter(r => r.status === 'dead_letter').length,
      completedToday: 0 // Would need separate query with date filter
    };

    return stats;
  }

  /**
   * Retry dead letter items
   */
  async retryDeadLetters(apiName?: string): Promise<number> {
    let query = this.supabase
      .from('api_queue')
      .update({
        status: 'queued',
        attempt_count: 0,
        backoff_until: null
      })
      .eq('status', 'dead_letter');

    if (apiName) {
      query = query.eq('api_name', apiName);
    }

    const { data } = await query.select('id');
    return data?.length || 0;
  }

  /**
   * Clear old completed/failed requests
   */
  async cleanup(olderThanDays: number = 7): Promise<number> {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - olderThanDays);

    const { data } = await this.supabase
      .from('api_queue')
      .delete()
      .in('status', ['completed', 'dead_letter'])
      .lt('processed_at', cutoff.toISOString())
      .select('id');

    return data?.length || 0;
  }
}

export default ApiQueue;
