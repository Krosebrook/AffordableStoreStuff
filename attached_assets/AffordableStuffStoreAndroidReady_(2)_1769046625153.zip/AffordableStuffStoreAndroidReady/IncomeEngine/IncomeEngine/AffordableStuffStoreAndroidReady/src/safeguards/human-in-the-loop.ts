/**
 * ============================================================================
 * SAFEGUARD #7: HUMAN-IN-THE-LOOP APPROVAL SYSTEM
 * ============================================================================
 * 
 * Purpose: Require human review for products until quality is proven
 * 
 * Features:
 * - Mandatory review for first N products (default: 50)
 * - Quality score threshold for auto-approval
 * - Slack/Discord/Email notifications for pending reviews
 * - Approval statistics tracking
 * - Progressive auto-approval as trust builds
 * - Rejection feedback loop for quality improvement
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// =============================================================================
// TYPES
// =============================================================================

interface ApprovalQueueItem {
  id: string;
  productId: string;
  productType: string;
  productData: Record<string, any>;
  previewUrls: string[];
  qualityAssessmentId?: string;
  trademarkCheckId?: string;
  status: 'pending' | 'approved' | 'rejected' | 'revision_requested';
  priority: number;
  reviewerId?: string;
  reviewerNotes?: string;
  rejectionReason?: string;
  autoApproveEligible: boolean;
  createdAt: Date;
  reviewedAt?: Date;
  targetPlatforms: string[];
}

interface ApprovalSettings {
  minProductsBeforeAuto: number;
  qualityScoreForAuto: number;
  enabled: boolean;
  autoApprovePlatforms: string[];
  autoApproveProductTypes: string[];
  maxDailyAuto: number;
}

interface ApprovalStats {
  totalApproved: number;
  totalRejected: number;
  approvalRate: number;
  avgQualityApproved: number;
  avgQualityRejected: number;
  pendingCount: number;
}

interface NotificationConfig {
  slackWebhook?: string;
  discordWebhook?: string;
  email?: string;
}

// =============================================================================
// HUMAN IN THE LOOP CLASS
// =============================================================================

export class HumanInTheLoop {
  private supabase: SupabaseClient;
  private settings: ApprovalSettings | null = null;
  private notificationConfig: NotificationConfig = {};

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * Submit a product for approval
   */
  async submitForApproval(product: {
    id: string;
    type: string;
    data: Record<string, any>;
    previewUrls: string[];
    qualityAssessmentId?: string;
    trademarkCheckId?: string;
    qualityScore?: number;
    targetPlatforms: string[];
    priority?: number;
  }): Promise<{
    queued: boolean;
    autoApproved: boolean;
    queuePosition?: number;
    reason: string;
  }> {
    const settings = await this.getSettings();

    // Check if human review is still required
    const reviewRequired = await this.isHumanReviewRequired();
    
    // Check if eligible for auto-approval
    const autoEligible = await this.checkAutoApprovalEligibility(
      product.qualityScore || 0,
      product.targetPlatforms,
      product.type
    );

    if (!reviewRequired && autoEligible) {
      // Auto-approve
      await this.recordApproval(product.id, 'auto', 'Auto-approved based on quality score and history');
      
      return {
        queued: false,
        autoApproved: true,
        reason: 'Product auto-approved based on quality score and approval history'
      };
    }

    // Queue for human review
    const { data: queueItem, error } = await this.supabase
      .from('approval_queue')
      .insert({
        product_id: product.id,
        product_type: product.type,
        product_data: product.data,
        preview_urls: product.previewUrls,
        quality_assessment_id: product.qualityAssessmentId,
        trademark_check_id: product.trademarkCheckId,
        status: 'pending',
        priority: product.priority || 5,
        auto_approve_eligible: autoEligible,
        target_platforms: product.targetPlatforms
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to queue for approval: ${error.message}`);
    }

    // Get queue position
    const { count } = await this.supabase
      .from('approval_queue')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending')
      .gte('priority', product.priority || 5);

    // Send notification
    await this.sendNotification('new_submission', {
      productId: product.id,
      productType: product.type,
      queuePosition: count || 1,
      previewUrl: product.previewUrls[0]
    });

    return {
      queued: true,
      autoApproved: false,
      queuePosition: count || 1,
      reason: reviewRequired 
        ? `Human review required (${await this.getApprovedCount()}/${settings.minProductsBeforeAuto} products approved)`
        : 'Quality score below auto-approval threshold'
    };
  }

  /**
   * Approve a product
   */
  async approve(
    queueItemId: string, 
    reviewerId: string, 
    notes?: string
  ): Promise<void> {
    const { data: item } = await this.supabase
      .from('approval_queue')
      .select('product_id')
      .eq('id', queueItemId)
      .single();

    if (!item) {
      throw new Error('Queue item not found');
    }

    await this.supabase
      .from('approval_queue')
      .update({
        status: 'approved',
        reviewer_id: reviewerId,
        reviewer_notes: notes,
        reviewed_at: new Date().toISOString()
      })
      .eq('id', queueItemId);

    // Update product status
    await this.supabase
      .from('products')
      .update({ status: 'approved' })
      .eq('id', item.product_id);

    // Update stats
    await this.updateStats('approved', reviewerId);

    // Notify
    await this.sendNotification('approved', { productId: item.product_id });
  }

  /**
   * Reject a product
   */
  async reject(
    queueItemId: string, 
    reviewerId: string, 
    reason: string,
    notes?: string
  ): Promise<void> {
    const { data: item } = await this.supabase
      .from('approval_queue')
      .select('product_id')
      .eq('id', queueItemId)
      .single();

    if (!item) {
      throw new Error('Queue item not found');
    }

    await this.supabase
      .from('approval_queue')
      .update({
        status: 'rejected',
        reviewer_id: reviewerId,
        rejection_reason: reason,
        reviewer_notes: notes,
        reviewed_at: new Date().toISOString()
      })
      .eq('id', queueItemId);

    // Update product status
    await this.supabase
      .from('products')
      .update({ status: 'rejected' })
      .eq('id', item.product_id);

    // Update stats
    await this.updateStats('rejected', reviewerId);

    // Notify
    await this.sendNotification('rejected', { 
      productId: item.product_id, 
      reason 
    });
  }

  /**
   * Request revision
   */
  async requestRevision(
    queueItemId: string,
    reviewerId: string,
    feedback: string
  ): Promise<void> {
    const { data: item } = await this.supabase
      .from('approval_queue')
      .select('product_id')
      .eq('id', queueItemId)
      .single();

    if (!item) {
      throw new Error('Queue item not found');
    }

    await this.supabase
      .from('approval_queue')
      .update({
        status: 'revision_requested',
        reviewer_id: reviewerId,
        reviewer_notes: feedback,
        reviewed_at: new Date().toISOString()
      })
      .eq('id', queueItemId);

    // Update stats
    await this.updateStats('revision_requested', reviewerId);

    // Notify
    await this.sendNotification('revision_requested', {
      productId: item.product_id,
      feedback
    });
  }

  /**
   * Get pending items for review
   */
  async getPendingItems(limit: number = 20): Promise<ApprovalQueueItem[]> {
    const { data } = await this.supabase
      .from('approval_queue')
      .select('*')
      .eq('status', 'pending')
      .order('priority', { ascending: false })
      .order('created_at', { ascending: true })
      .limit(limit);

    return data || [];
  }

  /**
   * Get a specific queue item with full details
   */
  async getQueueItem(queueItemId: string): Promise<ApprovalQueueItem | null> {
    const { data } = await this.supabase
      .from('approval_queue')
      .select(`
        *,
        quality_assessment:quality_assessments(*),
        trademark_check:trademark_checks(*)
      `)
      .eq('id', queueItemId)
      .single();

    return data;
  }

  /**
   * Check if human review is still required
   */
  async isHumanReviewRequired(): Promise<boolean> {
    const settings = await this.getSettings();
    
    if (!settings.enabled) {
      return false;
    }

    const approvedCount = await this.getApprovedCount();
    return approvedCount < settings.minProductsBeforeAuto;
  }

  /**
   * Get number of approved products
   */
  async getApprovedCount(): Promise<number> {
    const { count } = await this.supabase
      .from('approval_queue')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'approved');

    return count || 0;
  }

  /**
   * Check auto-approval eligibility
   */
  private async checkAutoApprovalEligibility(
    qualityScore: number,
    targetPlatforms: string[],
    productType: string
  ): Promise<boolean> {
    const settings = await this.getSettings();

    // Quality score check
    if (qualityScore < settings.qualityScoreForAuto) {
      return false;
    }

    // Check daily auto-approval limit
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { count: todayAutoApprovals } = await this.supabase
      .from('approval_queue')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'approved')
      .eq('reviewer_id', 'auto')
      .gte('reviewed_at', today.toISOString());

    if ((todayAutoApprovals || 0) >= settings.maxDailyAuto) {
      return false;
    }

    // Platform check (only auto-approve for low-risk platforms)
    const riskyPlatforms = targetPlatforms.filter(
      p => !settings.autoApprovePlatforms.includes(p)
    );
    if (riskyPlatforms.length > 0) {
      return false;
    }

    return true;
  }

  /**
   * Get approval settings
   */
  private async getSettings(): Promise<ApprovalSettings> {
    if (this.settings) {
      return this.settings;
    }

    const { data: thresholdSetting } = await this.supabase
      .from('approval_settings')
      .select('setting_value')
      .eq('setting_key', 'human_review_threshold')
      .single();

    const { data: autoApproveSetting } = await this.supabase
      .from('approval_settings')
      .select('setting_value')
      .eq('setting_key', 'auto_approve_rules')
      .single();

    const threshold = thresholdSetting?.setting_value || {};
    const autoApprove = autoApproveSetting?.setting_value || {};

    this.settings = {
      minProductsBeforeAuto: threshold.min_products_before_auto || 50,
      qualityScoreForAuto: threshold.quality_score_for_auto || 0.85,
      enabled: threshold.enabled !== false,
      autoApprovePlatforms: autoApprove.platforms || ['shopify', 'woocommerce'],
      autoApproveProductTypes: autoApprove.product_types || [],
      maxDailyAuto: autoApprove.max_daily_auto || 10
    };

    return this.settings;
  }

  /**
   * Record an approval (for stats)
   */
  private async recordApproval(
    productId: string, 
    reviewerId: string, 
    notes: string
  ): Promise<void> {
    await this.supabase
      .from('approval_queue')
      .update({
        status: 'approved',
        reviewer_id: reviewerId,
        reviewer_notes: notes,
        reviewed_at: new Date().toISOString()
      })
      .eq('product_id', productId);

    await this.supabase
      .from('products')
      .update({ status: 'approved' })
      .eq('id', productId);

    await this.updateStats('approved', reviewerId);
  }

  /**
   * Update approval statistics
   */
  private async updateStats(
    action: 'approved' | 'rejected' | 'revision_requested',
    reviewerId: string
  ): Promise<void> {
    const today = new Date().toISOString().split('T')[0];

    // Get or create today's stats
    const { data: existing } = await this.supabase
      .from('approval_stats')
      .select('*')
      .eq('stat_date', today)
      .eq('reviewer_id', reviewerId)
      .single();

    if (existing) {
      const updates: Record<string, any> = {
        total_submitted: existing.total_submitted + 1
      };

      if (action === 'approved') {
        updates.total_approved = existing.total_approved + 1;
      } else if (action === 'rejected') {
        updates.total_rejected = existing.total_rejected + 1;
      } else {
        updates.total_revision_requested = existing.total_revision_requested + 1;
      }

      await this.supabase
        .from('approval_stats')
        .update(updates)
        .eq('id', existing.id);
    } else {
      await this.supabase
        .from('approval_stats')
        .insert({
          stat_date: today,
          reviewer_id: reviewerId,
          total_submitted: 1,
          total_approved: action === 'approved' ? 1 : 0,
          total_rejected: action === 'rejected' ? 1 : 0,
          total_revision_requested: action === 'revision_requested' ? 1 : 0
        });
    }
  }

  /**
   * Get approval statistics
   */
  async getStats(): Promise<ApprovalStats> {
    const { data: allItems } = await this.supabase
      .from('approval_queue')
      .select('status');

    const { data: qualityStats } = await this.supabase
      .from('approval_queue')
      .select(`
        status,
        quality_assessment:quality_assessments(quality_score)
      `)
      .in('status', ['approved', 'rejected']);

    const items = allItems || [];
    const approved = items.filter(i => i.status === 'approved').length;
    const rejected = items.filter(i => i.status === 'rejected').length;
    const pending = items.filter(i => i.status === 'pending').length;

    // Calculate average quality scores
    let avgApproved = 0;
    let avgRejected = 0;

    if (qualityStats) {
      const approvedScores = qualityStats
        .filter(i => i.status === 'approved' && i.quality_assessment?.quality_score)
        .map(i => i.quality_assessment.quality_score);
      
      const rejectedScores = qualityStats
        .filter(i => i.status === 'rejected' && i.quality_assessment?.quality_score)
        .map(i => i.quality_assessment.quality_score);

      avgApproved = approvedScores.length > 0 
        ? approvedScores.reduce((a, b) => a + b, 0) / approvedScores.length 
        : 0;
      
      avgRejected = rejectedScores.length > 0 
        ? rejectedScores.reduce((a, b) => a + b, 0) / rejectedScores.length 
        : 0;
    }

    return {
      totalApproved: approved,
      totalRejected: rejected,
      approvalRate: (approved + rejected) > 0 ? approved / (approved + rejected) : 0,
      avgQualityApproved: avgApproved,
      avgQualityRejected: avgRejected,
      pendingCount: pending
    };
  }

  /**
   * Configure notifications
   */
  setNotificationConfig(config: NotificationConfig): void {
    this.notificationConfig = config;
  }

  /**
   * Send notification
   */
  private async sendNotification(
    type: 'new_submission' | 'approved' | 'rejected' | 'revision_requested',
    data: Record<string, any>
  ): Promise<void> {
    const messages: Record<string, string> = {
      new_submission: `🆕 New product awaiting review (Queue position: ${data.queuePosition})\nProduct: ${data.productType}\nPreview: ${data.previewUrl}`,
      approved: `✅ Product approved: ${data.productId}`,
      rejected: `❌ Product rejected: ${data.productId}\nReason: ${data.reason}`,
      revision_requested: `🔄 Revision requested: ${data.productId}\nFeedback: ${data.feedback}`
    };

    const message = messages[type];

    // Slack
    if (this.notificationConfig.slackWebhook) {
      try {
        await fetch(this.notificationConfig.slackWebhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: message })
        });
      } catch (e) {
        console.error('Slack notification failed:', e);
      }
    }

    // Discord
    if (this.notificationConfig.discordWebhook) {
      try {
        await fetch(this.notificationConfig.discordWebhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ content: message })
        });
      } catch (e) {
        console.error('Discord notification failed:', e);
      }
    }
  }
}

export default HumanInTheLoop;
