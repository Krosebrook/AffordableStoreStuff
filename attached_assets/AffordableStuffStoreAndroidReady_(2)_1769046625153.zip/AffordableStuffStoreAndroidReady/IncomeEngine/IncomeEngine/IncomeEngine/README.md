# Income Engine

A production-ready passive income automation platform for ecommerce and digital products. Supports 11 platforms with 8 safeguard systems, MCP integration for AI assistants, and cross-platform analytics.

## Features

- **11 Platform Connectors**: Unified interface for major ecommerce platforms
- **8 Safeguard Systems**: Rate limiting, quality gates, trademark screening, and more
- **MCP Server Integration**: AI assistant tools via Model Context Protocol
- **PWA Mobile App**: Install on iOS/Android, works offline
- **Capacitor Native Apps**: Build native Android/iOS apps
- **Real-time Dashboard**: Monitor revenue, approvals, and system health
- **n8n Workflows**: 8 automated workflows for product generation and publishing
- **Browser Automation**: Playwright-based adapters for platforms without APIs
- **Cross-platform Analytics**: Unified revenue and performance metrics
- **Inventory Sync**: Automatic inventory synchronization across marketplaces
- **Webhook Notifications**: Queue-based alerts for orders, low stock, and budget

## Platform Support

| Platform | Type | Status | Auth | Features |
|----------|------|--------|------|----------|
| Printify | POD | Available | API Key | Products, Variants, Analytics |
| Etsy | POD | Available | OAuth 2.0 | Listings, Orders, Analytics |
| TeePublic | POD | Available | Browser | Designs, Products |
| Society6 | POD | Available | Browser | Art Prints, Products |
| Redbubble | POD | Available | Browser | Designs, Analytics |
| Gumroad | Digital | Available | OAuth 2.0 | Products, Sales, Webhooks |
| Creative Fabrica | Digital | Available | API Key | Fonts, Graphics, Crafts |
| Amazon KDP | Digital | Available | Browser + 2FA | Books, Reports |
| Shopify | Marketplace | Available | OAuth 2.0 | Full Store Access |
| WooCommerce | Marketplace | Available | API Key | Products, Orders, Inventory |
| TikTok Shop | Marketplace | Available | OAuth 2.0 | Products, Live Shopping |

## Quick Start on Replit

### 1. Import to Replit

1. Go to [replit.com](https://replit.com)
2. Click **Create Repl** -> **Import from GitHub**
3. Or upload this folder directly

### 2. Configure Secrets

Click the **Secrets** tab in the sidebar and add:

| Secret Name | Description | Required |
|-------------|-------------|----------|
| `SUPABASE_URL` | Your Supabase project URL | Yes |
| `SUPABASE_SERVICE_KEY` | Supabase service role key | Yes |
| `SUPABASE_ANON_KEY` | Supabase anonymous key | Yes |
| `OPENAI_API_KEY` | OpenAI API key for quality gates | Yes |
| `REPLICATE_API_TOKEN` | Replicate for image generation | No |
| `SLACK_WEBHOOK_URL` | Slack notifications | No |

### 3. Run the App

Click the **Run** button. The app will:
1. Install dependencies
2. Start the development server
3. Open in the Webview panel

### 4. Deploy

1. Click **Deploy** button (top right)
2. Choose **Autoscale** (recommended)
3. Configure:
   - Build: `npm run build`
   - Run: `npm run start`
4. Click **Deploy**

Your app will be live at `https://your-repl-name.replit.app`

## Install as Mobile App

### iOS (Safari)
1. Open your deployed URL in Safari
2. Tap the Share button
3. Tap "Add to Home Screen"
4. Tap "Add"

### Android (Chrome)
1. Open your deployed URL in Chrome
2. Tap the menu
3. Tap "Install app" or "Add to Home screen"
4. Tap "Install"

### Native App (Capacitor)
```bash
# Build web assets
npm run build

# Android
npx cap sync android
npx cap open android

# iOS
npx cap sync ios
npx cap open ios
```

## Architecture

```
                                  +------------------+
                                  |   React PWA      |
                                  |   Dashboard      |
                                  +--------+---------+
                                           |
                    +----------------------+----------------------+
                    |                      |                      |
           +--------v--------+    +--------v--------+    +--------v--------+
           |  Express API    |    |   MCP Server    |    |   n8n Workflows |
           |  /api/*         |    |   AI Tools      |    |   Automation    |
           +--------+--------+    +--------+--------+    +--------+--------+
                    |                      |                      |
           +--------v---------------------------------------------|--------+
           |                    Safeguards Orchestrator                    |
           |  [Rate Limiter] [Quality Gate] [Trademark] [Budget Breaker]   |
           |  [API Queue] [Provider Failover] [Tax] [Human-in-Loop]        |
           +---------------------------------------------------------------+
                    |
           +--------v---------------------------------------------|--------+
           |                    Connector Layer                            |
           |  [POD Workflow]                [Marketplace Workflow]         |
           |   - Printify, Etsy             - Shopify, WooCommerce         |
           |   - TeePublic, Society6        - TikTok Shop, Amazon KDP      |
           |   - Redbubble, Gumroad                                        |
           |   - Creative Fabrica                                          |
           +---------------------------------------------------------------+
                    |
           +--------v--------+
           |    Supabase     |
           |   PostgreSQL    |
           +-----------------+
```

## Project Structure

```
IncomeEngine/
|-- src/
|   |-- client/          # React PWA frontend
|   |   |-- components/  # Reusable UI components
|   |   |-- pages/       # Route-level pages
|   |   |-- hooks/       # Custom React hooks
|   |   |-- lib/         # Utilities, query client
|   |   +-- types/       # TypeScript definitions
|   |-- server/          # Express API server
|   |-- safeguards/      # 8 Safeguard modules
|   +-- connectors/      # Platform connector system
|       |-- adapters/    # 11 Platform adapters
|       |-- core/        # Base connector, types
|       |-- utils/       # Retry, TOTP, webhooks
|       +-- workflows/   # POD and Marketplace workflows
|-- mcp-server/          # MCP server for AI integration
|   |-- tools/           # 9 MCP tools
|   +-- resources/       # 4 MCP resources
|-- database/            # SQL schemas
|   |-- schema-v2.sql    # Current schema
|   +-- migrations/      # Incremental migrations
|-- docs/                # Documentation
|   |-- platform-guides/ # Per-platform setup
|   |-- ai-tools/        # MCP documentation
|   |-- API.md           # API reference
|   +-- ARCHITECTURE.md  # System design
|-- public/              # Static assets + PWA icons
+-- *.json               # n8n workflow files (01-08)
```

## 8 Safeguards

1. **Rate Limiter** - Anti-suspension controls per platform
2. **Quality Gates** - AI content originality checks
3. **Trademark Screener** - USPTO TESS database lookup
4. **API Queue** - Priority queue with exponential backoff
5. **Provider Failover** - Backup AI providers
6. **Tax Compliance** - Multi-state sales tax nexus tracking
7. **Human-in-the-Loop** - First 50 products require review
8. **Budget Circuit Breaker** - Daily/weekly/monthly caps

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check (required for Autoscale) |
| GET | `/api/status` | Full system status |
| POST | `/api/products/process` | Process product through safeguards |
| GET | `/api/budget` | Budget status |
| GET | `/api/approvals` | Approval queue |
| POST | `/api/approvals/:id/approve` | Approve product |
| POST | `/api/approvals/:id/reject` | Reject product |
| GET | `/api/providers` | Provider health |
| GET | `/api/queue` | API queue stats |
| GET | `/api/connectors` | List available connectors |
| POST | `/api/connectors/:platform/connect` | Connect platform |
| GET | `/api/connectors/:platform/products` | List platform products |
| POST | `/api/products/:id/publish/pod` | Publish to POD platforms |
| POST | `/api/products/:id/publish/marketplace` | Publish to marketplaces |
| POST | `/api/inventory/sync` | Sync inventory |
| GET | `/api/analytics/platforms` | Cross-platform analytics |
| GET | `/api/workflows/status` | Active workflow status |

## MCP Server (AI Integration)

Use Claude Code or other MCP-compatible AI assistants to manage Income Engine:

```bash
# Setup
cd mcp-server && npm install

# Test
node index.js --test
```

**Available Tools:**
- `list_platforms` / `connect_platform` - Platform management
- `create_product` / `list_products` - Product operations
- `get_analytics` - Revenue and performance metrics
- `check_safeguards` / `reset_safeguard` - Safeguard status
- `run_workflow` / `get_workflow_status` - n8n workflow control

**Resources:**
- `platforms://status` - Platform connection status
- `products://pending` - Products awaiting approval
- `analytics://dashboard` - Dashboard summary
- `budget://current` - Budget utilization

See [docs/ai-tools/MCP-INTEGRATION.md](docs/ai-tools/MCP-INTEGRATION.md) for full documentation.

## n8n Workflows

| # | Workflow | Description |
|---|----------|-------------|
| 01 | Niche Scanner | Scan for trending niches |
| 02 | Product Generator | Generate product designs |
| 03 | Printify Publisher | Publish to Printify |
| 04 | Etsy Publisher | Publish to Etsy |
| 05 | Gumroad Publisher | Publish to Gumroad |
| 06 | Revenue Aggregator | Aggregate revenue data |
| 07 | Daily Report | Generate daily reports |
| 08 | Batch Processor | Process batch operations |

## Configuration

### Environment Variables

Create `.env` from `.env.example`:

```bash
# Database
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...
SUPABASE_ANON_KEY=eyJhbGc...

# AI Services
OPENAI_API_KEY=sk-...
REPLICATE_API_TOKEN=r8_...

# Budget Limits
MAX_DAILY_AI_SPEND=5.00
MAX_MONTHLY_BUDGET=150.00

# Platform Credentials (optional)
PRINTIFY_API_KEY=
ETSY_API_KEY=
GUMROAD_ACCESS_TOKEN=
SHOPIFY_API_KEY=
```

### .replit Configuration
```toml
entrypoint = "src/server/index.ts"
modules = ["nodejs-20"]

[deployment]
deploymentTarget = "autoscale"
run = ["npm", "run", "start"]
build = ["npm", "run", "build"]
```

## Database Setup

1. Go to Supabase SQL Editor
2. Run `database/schema-v2.sql` to create all tables
3. Run migrations in `database/migrations/` in order

Expected tables (30+):
- Products, orders, revenue tracking
- Platform credentials and tokens
- Rate limits, circuit breaker state
- Approval queue and decisions
- Webhook queue and logs
- Agent identities and audit logs

## Replit Costs

| Deployment Type | Cost |
|-----------------|------|
| **Autoscale** | $1/month base + usage |
| **Reserved VM** | $10-20/month |
| **Static** | Free (with subscription) |

Autoscale scales to zero when not in use - ideal for this dashboard.

## Troubleshooting

### "Missing Secrets" Error
Ensure all required secrets are set in the Secrets tab.

### Build Fails
Run `npm install` in the Shell, then try again.

### PWA Not Installing
- Ensure you're on HTTPS (Replit deployments are)
- Check that manifest.json is being served

### API Returns 503
Supabase connection issue. Verify your SUPABASE_URL and SUPABASE_SERVICE_KEY.

### Platform OAuth Fails
Verify callback URL matches: `https://your-app.replit.app/auth/{platform}/callback`

### Amazon KDP 2FA Issues
Configure TOTP secret in database:
```sql
INSERT INTO totp_credentials (platform, email, secret_key)
VALUES ('amazon-kdp', 'your-email', 'YOUR_TOTP_SECRET');
```

## Documentation

- [API Reference](docs/API.md)
- [Architecture Guide](docs/ARCHITECTURE.md)
- [Deployment Guide](docs/DEPLOYMENT.md)
- [Operations Runbook](docs/RUNBOOK.md)
- [MCP Integration](docs/ai-tools/MCP-INTEGRATION.md)
- [Platform Guides](docs/platform-guides/)

## License

MIT - Use freely for your passive income automation!

---

Built for passive income automation
