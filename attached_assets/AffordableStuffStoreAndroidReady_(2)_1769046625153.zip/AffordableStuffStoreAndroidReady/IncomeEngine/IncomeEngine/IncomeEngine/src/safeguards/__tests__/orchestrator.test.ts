/**
 * ============================================================================
 * ORCHESTRATOR TEST SUITE
 * ============================================================================
 *
 * Tests for the Safeguards Orchestrator
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { SafeguardsOrchestrator, createSafeguardsOrchestrator } from '../orchestrator';
import { createMockSupabaseClient, MockSupabaseClient } from './test-utils';

// Mock modules
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn()
}));

describe('Safeguards Orchestrator', () => {
  let orchestrator: SafeguardsOrchestrator;
  let mockSupabase: MockSupabaseClient;

  // Set up environment variables
  const originalEnv = process.env;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();

    process.env = {
      ...originalEnv,
      SUPABASE_URL: 'https://test.supabase.co',
      SUPABASE_SERVICE_KEY: 'test-key'
    };

    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    orchestrator = createSafeguardsOrchestrator();
  });

  afterEach(() => {
    process.env = originalEnv;
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // Constructor Tests
  // ===========================================================================

  describe('Constructor', () => {
    it('should throw error when SUPABASE_URL missing', () => {
      delete process.env.SUPABASE_URL;

      expect(() => {
        new SafeguardsOrchestrator();
      }).toThrow('Missing SUPABASE_URL');
    });

    it('should throw error when SUPABASE_SERVICE_KEY missing', () => {
      delete process.env.SUPABASE_SERVICE_KEY;

      expect(() => {
        new SafeguardsOrchestrator();
      }).toThrow('Missing SUPABASE_URL or SUPABASE_SERVICE_KEY');
    });

    it('should create orchestrator with valid env vars', () => {
      process.env.SUPABASE_URL = 'https://test.supabase.co';
      process.env.SUPABASE_SERVICE_KEY = 'test-key';

      const orch = createSafeguardsOrchestrator();

      expect(orch).toBeInstanceOf(SafeguardsOrchestrator);
    });
  });

  // ===========================================================================
  // processProduct Tests
  // ===========================================================================

  describe('processProduct', () => {
    const testProduct = {
      id: 'test-product-123',
      type: 'coloring_book',
      niche: 'adult_coloring',
      title: 'Beautiful Mandala Patterns',
      description: 'Intricate designs for relaxation',
      keywords: ['mandala', 'coloring', 'relaxation'],
      imageUrl: 'https://example.com/image.png',
      targetPlatforms: ['printify', 'etsy']
    };

    it('should block product when daily budget exceeded', async () => {
      // Mock budget check - exceeded
      mockSupabase._setRpcResponse([{
        current_spend: 30,
        limit_amount: 25,
        percent_used: 120,
        is_warning: true,
        is_exceeded: true
      }]);

      const result = await orchestrator.processProduct(testProduct);

      expect(result.status).toBe('blocked');
      expect(result.errors).toContain('Daily budget exceeded');
    });

    it('should reject product with blocked trademark terms', async () => {
      // Mock budget check - OK
      mockSupabase._setRpcResponse([{
        current_spend: 10,
        limit_amount: 25,
        percent_used: 40,
        is_warning: false,
        is_exceeded: false
      }]);

      // Mock blocked terms found
      mockSupabase._setResponse([
        { term: 'disney' }
      ]);

      const productWithTrademark = {
        ...testProduct,
        title: 'Disney Style Coloring Book',
        keywords: ['disney', 'princess']
      };

      const result = await orchestrator.processProduct(productWithTrademark);

      expect(result.status).toBe('rejected');
      expect(result.errors[0]).toContain('Blocked terms');
    });

    it('should queue product for human review when required', async () => {
      // Mock budget check - OK
      mockSupabase._setRpcResponse([{
        current_spend: 10,
        limit_amount: 25,
        percent_used: 40,
        is_warning: false,
        is_exceeded: false
      }]);

      // Mock no blocked terms
      mockSupabase._setResponse([]);

      // Mock rate limit check for platforms
      mockSupabase._setRpcResponse([{ allowed: true }]);
      mockSupabase._setRpcResponse([{ allowed: true }]);

      // Mock human review required
      mockSupabase._setRpcResponse(true);

      // Mock queue insert
      mockSupabase._setResponse({ id: 'queue-123' });

      const result = await orchestrator.processProduct(testProduct);

      expect(result.status).toBe('queued');
      expect(result.nextSteps).toContain('Awaiting human review');
    });

    it('should auto-approve when review not required', async () => {
      // Mock budget check - OK
      mockSupabase._setRpcResponse([{
        current_spend: 10,
        limit_amount: 25,
        percent_used: 40,
        is_warning: false,
        is_exceeded: false
      }]);

      // Mock no blocked terms
      mockSupabase._setResponse([]);

      // Mock rate limit checks
      mockSupabase._setRpcResponse([{ allowed: true }]);
      mockSupabase._setRpcResponse([{ allowed: true }]);

      // Mock human review not required
      mockSupabase._setRpcResponse(false);

      const result = await orchestrator.processProduct(testProduct);

      expect(result.status).toBe('approved');
      expect(result.nextSteps).toContain('Auto-approved - ready for publishing');
    });

    it('should add warnings for rate-limited platforms', async () => {
      // Mock budget check - OK
      mockSupabase._setRpcResponse([{
        current_spend: 10,
        limit_amount: 25,
        is_exceeded: false
      }]);

      // Mock no blocked terms
      mockSupabase._setResponse([]);

      // Mock rate limit - first platform OK, second rate limited
      mockSupabase._setRpcResponse([{ allowed: true }]);
      mockSupabase._setRpcResponse([{ allowed: false }]);

      // Mock human review not required
      mockSupabase._setRpcResponse(false);

      const result = await orchestrator.processProduct(testProduct);

      expect(result.warnings.some(w => w.includes('Rate limited'))).toBe(true);
    });

    it('should handle errors gracefully', async () => {
      // Mock budget check - throws error
      mockSupabase._setRpcResponse(null, { message: 'Database error' });

      const result = await orchestrator.processProduct(testProduct);

      expect(result.status).toBe('blocked');
      expect(result.errors[0]).toContain('Error at');
    });

    it('should track processing stages', async () => {
      mockSupabase._setRpcResponse([{ is_exceeded: false }]);
      mockSupabase._setResponse([]);
      mockSupabase._setRpcResponse([{ allowed: true }]);
      mockSupabase._setRpcResponse([{ allowed: true }]);
      mockSupabase._setRpcResponse(false);

      const result = await orchestrator.processProduct(testProduct);

      expect(result.stage).toBe('complete');
    });
  });

  // ===========================================================================
  // getSystemStatus Tests
  // ===========================================================================

  describe('getSystemStatus', () => {
    it('should return complete system status', async () => {
      // Mock budget status for all periods
      mockSupabase._setRpcResponse([{
        current_spend: 10,
        limit_amount: 25,
        percent_used: 40,
        is_warning: false,
        is_exceeded: false
      }]);
      mockSupabase._setRpcResponse([{
        current_spend: 50,
        limit_amount: 150,
        percent_used: 33,
        is_warning: false,
        is_exceeded: false
      }]);
      mockSupabase._setRpcResponse([{
        current_spend: 200,
        limit_amount: 500,
        percent_used: 40,
        is_warning: false,
        is_exceeded: false
      }]);

      // Mock queue stats
      mockSupabase._setResponse([
        { status: 'queued' },
        { status: 'queued' },
        { status: 'processing' },
        { status: 'rate_limited' },
        { status: 'dead_letter' },
        { status: 'completed' }
      ]);

      // Mock approval stats
      mockSupabase._setResponse([
        { status: 'approved' },
        { status: 'approved' },
        { status: 'rejected' },
        { status: 'pending' }
      ]);

      // Mock circuit breaker states
      mockSupabase._setResponse([
        { breaker_name: 'budget_daily', is_open: false },
        { breaker_name: 'budget_weekly', is_open: false }
      ]);

      // Mock provider health
      mockSupabase._setResponse([
        { provider_name: 'openai', is_available: true }
      ]);

      const status = await orchestrator.getSystemStatus();

      expect(status.budget.length).toBe(3);
      expect(status.queues.queued).toBe(2);
      expect(status.approvalStats.totalApproved).toBe(2);
    });

    it('should calculate approval rate correctly', () => {
      const approved = 45;
      const rejected = 5;
      const approvalRate = approved + rejected > 0 ? approved / (approved + rejected) : 0;

      expect(approvalRate).toBe(0.9);
    });

    it('should handle empty data', async () => {
      mockSupabase._setRpcResponse([]);
      mockSupabase._setRpcResponse([]);
      mockSupabase._setRpcResponse([]);
      mockSupabase._setResponse([]);
      mockSupabase._setResponse([]);
      mockSupabase._setResponse([]);
      mockSupabase._setResponse([]);

      const status = await orchestrator.getSystemStatus();

      expect(status.queues.queued).toBe(0);
      expect(status.approvalStats.pendingCount).toBe(0);
    });
  });

  // ===========================================================================
  // approveApproval Tests
  // ===========================================================================

  describe('approveApproval', () => {
    it('should approve a pending item', async () => {
      mockSupabase._setResponse({ id: 'updated' });

      await orchestrator.approveApproval('queue-123', 'reviewer-456', 'Looks good');

      expect(mockSupabase.from).toHaveBeenCalledWith('approval_queue');
    });

    it('should throw error on database failure', async () => {
      mockSupabase._setResponse(null, { message: 'Update failed' });

      await expect(
        orchestrator.approveApproval('queue-123', 'reviewer-456')
      ).rejects.toThrow('Failed to approve item');
    });

    it('should handle optional notes', async () => {
      mockSupabase._setResponse({ id: 'updated' });

      await orchestrator.approveApproval('queue-123', 'reviewer-456');

      // Should not throw
      expect(true).toBe(true);
    });
  });

  // ===========================================================================
  // rejectApproval Tests
  // ===========================================================================

  describe('rejectApproval', () => {
    it('should reject a pending item', async () => {
      mockSupabase._setResponse({ id: 'updated' });

      await orchestrator.rejectApproval(
        'queue-123',
        'reviewer-456',
        'Low quality image',
        'Please improve resolution'
      );

      expect(mockSupabase.from).toHaveBeenCalledWith('approval_queue');
    });

    it('should throw error on database failure', async () => {
      mockSupabase._setResponse(null, { message: 'Update failed' });

      await expect(
        orchestrator.rejectApproval('queue-123', 'reviewer-456', 'Reason')
      ).rejects.toThrow('Failed to reject item');
    });
  });

  // ===========================================================================
  // getBudgetStatus Tests (Private method tested through processProduct)
  // ===========================================================================

  describe('Budget Status', () => {
    it('should use default limits when RPC returns empty', async () => {
      mockSupabase._setRpcResponse([]);

      // The default limits should be used
      const defaults = {
        daily: 25,
        weekly: 150,
        monthly: 500
      };

      expect(defaults.daily).toBe(25);
      expect(defaults.weekly).toBe(150);
      expect(defaults.monthly).toBe(500);
    });

    it('should calculate remaining budget correctly', () => {
      const limitAmount = 25;
      const currentSpend = 18;
      const remaining = Math.max(0, limitAmount - currentSpend);

      expect(remaining).toBe(7);
    });
  });

  // ===========================================================================
  // checkBlockedTerms Tests (Private method tested through processProduct)
  // ===========================================================================

  describe('Blocked Terms Checking', () => {
    it('should extract words from title', () => {
      const title = 'Disney Princess Coloring Book';
      const words = title.toLowerCase().split(' ').filter(t => t.length > 2);

      expect(words).toContain('disney');
      expect(words).toContain('princess');
      expect(words).toContain('coloring');
      expect(words).toContain('book');
    });

    it('should combine title and keywords', () => {
      const title = 'Mandala Art';
      const keywords = ['relaxation', 'stress relief'];

      const allTerms = [
        ...title.toLowerCase().split(' '),
        ...keywords.map(k => k.toLowerCase())
      ].filter(t => t.length > 2);

      expect(allTerms).toContain('mandala');
      expect(allTerms).toContain('relaxation');
      expect(allTerms).toContain('stress');
    });
  });

  // ===========================================================================
  // Processing Stage Tests
  // ===========================================================================

  describe('Processing Stages', () => {
    it('should track stage progression', () => {
      const stages = [
        'init',
        'budget_check',
        'trademark_check',
        'rate_limit_check',
        'human_review',
        'complete'
      ];

      expect(stages.indexOf('budget_check')).toBe(1);
      expect(stages.indexOf('trademark_check')).toBe(2);
      expect(stages.indexOf('complete')).toBe(5);
    });

    it('should capture stage in error messages', () => {
      const stage = 'trademark_check';
      const error = 'Database connection lost';

      const message = `Error at ${stage}: ${error}`;

      expect(message).toContain('trademark_check');
      expect(message).toContain('Database connection');
    });
  });

  // ===========================================================================
  // Result Structure Tests
  // ===========================================================================

  describe('Result Structure', () => {
    it('should have correct structure for approved result', () => {
      const result = {
        productId: 'product-123',
        status: 'approved',
        stage: 'complete',
        details: { budget: { percentUsed: 40 } },
        errors: [],
        warnings: [],
        nextSteps: ['Auto-approved - ready for publishing']
      };

      expect(result.status).toBe('approved');
      expect(result.errors.length).toBe(0);
      expect(result.nextSteps.length).toBeGreaterThan(0);
    });

    it('should have correct structure for blocked result', () => {
      const result = {
        productId: 'product-123',
        status: 'blocked',
        stage: 'budget_check',
        details: {},
        errors: ['Daily budget exceeded'],
        warnings: [],
        nextSteps: []
      };

      expect(result.status).toBe('blocked');
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it('should have correct structure for queued result', () => {
      const result = {
        productId: 'product-123',
        status: 'queued',
        stage: 'complete',
        details: {},
        errors: [],
        warnings: [],
        nextSteps: ['Awaiting human review']
      };

      expect(result.status).toBe('queued');
      expect(result.nextSteps).toContain('Awaiting human review');
    });
  });

  // ===========================================================================
  // Factory Function Tests
  // ===========================================================================

  describe('createSafeguardsOrchestrator', () => {
    it('should create orchestrator instance', () => {
      process.env.SUPABASE_URL = 'https://test.supabase.co';
      process.env.SUPABASE_SERVICE_KEY = 'test-key';

      const orch = createSafeguardsOrchestrator();

      expect(orch).toBeInstanceOf(SafeguardsOrchestrator);
    });
  });

  // ===========================================================================
  // Circuit Breaker Integration Tests
  // ===========================================================================

  describe('Circuit Breaker Integration', () => {
    it('should include circuit breaker states in status', async () => {
      mockSupabase._setRpcResponse([{ is_exceeded: false }]);
      mockSupabase._setRpcResponse([{ is_exceeded: false }]);
      mockSupabase._setRpcResponse([{ is_exceeded: false }]);
      mockSupabase._setResponse([]);
      mockSupabase._setResponse([]);

      mockSupabase._setResponse([
        { breaker_name: 'budget_daily', is_open: true, opened_reason: 'Budget exceeded' }
      ]);

      mockSupabase._setResponse([]);

      const status = await orchestrator.getSystemStatus();

      expect(status.circuitBreakers['budget_daily'].isOpen).toBe(true);
    });
  });

  // ===========================================================================
  // Provider Status Integration Tests
  // ===========================================================================

  describe('Provider Status Integration', () => {
    it('should include provider health in status', async () => {
      mockSupabase._setRpcResponse([{ is_exceeded: false }]);
      mockSupabase._setRpcResponse([{ is_exceeded: false }]);
      mockSupabase._setRpcResponse([{ is_exceeded: false }]);
      mockSupabase._setResponse([]);
      mockSupabase._setResponse([]);
      mockSupabase._setResponse([]);

      mockSupabase._setResponse([
        { provider_name: 'openai', provider_type: 'ai_generation', is_available: true, health_score: 0.95 }
      ]);

      const status = await orchestrator.getSystemStatus();

      expect(status.providers.length).toBe(1);
      expect(status.providers[0].provider_name).toBe('openai');
    });
  });
});
