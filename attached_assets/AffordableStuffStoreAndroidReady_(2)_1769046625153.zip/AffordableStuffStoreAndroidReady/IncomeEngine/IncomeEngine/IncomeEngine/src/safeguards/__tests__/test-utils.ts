/**
 * ============================================================================
 * TEST UTILITIES FOR SAFEGUARDS
 * ============================================================================
 *
 * Shared mocks and utilities for safeguard unit tests
 */

import { vi, Mock, MockInstance } from 'vitest';

// =============================================================================
// TYPES
// =============================================================================

export interface MockQueryBuilder {
  select: Mock;
  insert: Mock;
  update: Mock;
  delete: Mock;
  upsert: Mock;
  eq: Mock;
  neq: Mock;
  gt: Mock;
  gte: Mock;
  lt: Mock;
  lte: Mock;
  in: Mock;
  is: Mock;
  or: Mock;
  order: Mock;
  limit: Mock;
  single: Mock;
  maybeSingle: Mock;
}

export interface MockSupabaseClient {
  from: Mock;
  rpc: Mock;
  _queryBuilder: MockQueryBuilder;
  _resolvedData: any;
  _resolvedError: any;
  _setResponse: (data: any, error?: any) => void;
  _setRpcResponse: (data: any, error?: any) => void;
  _reset: () => void;
}

// =============================================================================
// MOCK SUPABASE CLIENT FACTORY
// =============================================================================

/**
 * Creates a fully mocked Supabase client for testing
 */
export function createMockSupabaseClient(): MockSupabaseClient {
  let resolvedData: any = null;
  let resolvedError: any = null;
  let rpcData: any = null;
  let rpcError: any = null;

  const createQueryBuilder = (): MockQueryBuilder => {
    const builder: Partial<MockQueryBuilder> = {};

    // Create chainable methods
    const chainMethods = [
      'select', 'insert', 'update', 'delete', 'upsert',
      'eq', 'neq', 'gt', 'gte', 'lt', 'lte',
      'in', 'is', 'or', 'order', 'limit'
    ];

    chainMethods.forEach(method => {
      builder[method as keyof MockQueryBuilder] = vi.fn().mockReturnThis();
    });

    // Terminal methods that return promises
    builder.single = vi.fn().mockImplementation(() =>
      Promise.resolve({ data: resolvedData, error: resolvedError })
    );

    builder.maybeSingle = vi.fn().mockImplementation(() =>
      Promise.resolve({ data: resolvedData, error: resolvedError })
    );

    // Make chainable methods also return promise when awaited
    const originalSelect = builder.select!;
    builder.select = vi.fn().mockImplementation((...args: any[]) => {
      const result = {
        ...builder,
        then: (resolve: any) => resolve({ data: resolvedData, error: resolvedError, count: Array.isArray(resolvedData) ? resolvedData.length : 0 })
      };
      return result;
    });

    const originalInsert = builder.insert!;
    builder.insert = vi.fn().mockImplementation((...args: any[]) => {
      const result = {
        ...builder,
        then: (resolve: any) => resolve({ data: resolvedData, error: resolvedError })
      };
      return result;
    });

    const originalUpdate = builder.update!;
    builder.update = vi.fn().mockImplementation((...args: any[]) => {
      const result = {
        ...builder,
        then: (resolve: any) => resolve({ data: resolvedData, error: resolvedError })
      };
      return result;
    });

    const originalDelete = builder.delete!;
    builder.delete = vi.fn().mockImplementation((...args: any[]) => {
      const result = {
        ...builder,
        then: (resolve: any) => resolve({ data: resolvedData, error: resolvedError })
      };
      return result;
    });

    return builder as MockQueryBuilder;
  };

  const queryBuilder = createQueryBuilder();

  const mockClient: MockSupabaseClient = {
    from: vi.fn().mockReturnValue(queryBuilder),
    rpc: vi.fn().mockImplementation(() =>
      Promise.resolve({ data: rpcData, error: rpcError })
    ),
    _queryBuilder: queryBuilder,
    _resolvedData: resolvedData,
    _resolvedError: resolvedError,
    _setResponse: (data: any, error: any = null) => {
      resolvedData = data;
      resolvedError = error;
    },
    _setRpcResponse: (data: any, error: any = null) => {
      rpcData = data;
      rpcError = error;
    },
    _reset: () => {
      resolvedData = null;
      resolvedError = null;
      rpcData = null;
      rpcError = null;
      vi.clearAllMocks();
    }
  };

  return mockClient;
}

// =============================================================================
// MOCK OPENAI CLIENT
// =============================================================================

export interface MockOpenAIClient {
  chat: {
    completions: {
      create: Mock;
    };
  };
  embeddings: {
    create: Mock;
  };
  _setCompletionResponse: (response: any) => void;
  _setEmbeddingResponse: (response: any) => void;
}

export function createMockOpenAIClient(): MockOpenAIClient {
  let completionResponse: any = {
    choices: [{ message: { content: '{}' } }]
  };
  let embeddingResponse: any = {
    data: [{ embedding: new Array(1536).fill(0) }]
  };

  return {
    chat: {
      completions: {
        create: vi.fn().mockImplementation(() => Promise.resolve(completionResponse))
      }
    },
    embeddings: {
      create: vi.fn().mockImplementation(() => Promise.resolve(embeddingResponse))
    },
    _setCompletionResponse: (response: any) => {
      completionResponse = response;
    },
    _setEmbeddingResponse: (response: any) => {
      embeddingResponse = response;
    }
  };
}

// =============================================================================
// MOCK PLAYWRIGHT BROWSER
// =============================================================================

export interface MockPage {
  goto: Mock;
  click: Mock;
  fill: Mock;
  $: Mock;
  $$: Mock;
  waitForLoadState: Mock;
  close: Mock;
  textContent: Mock;
}

export interface MockBrowser {
  newPage: Mock;
  close: Mock;
  _page: MockPage;
}

export function createMockBrowser(): MockBrowser {
  const page: MockPage = {
    goto: vi.fn().mockResolvedValue(undefined),
    click: vi.fn().mockResolvedValue(undefined),
    fill: vi.fn().mockResolvedValue(undefined),
    $: vi.fn().mockResolvedValue(null),
    $$: vi.fn().mockResolvedValue([]),
    waitForLoadState: vi.fn().mockResolvedValue(undefined),
    close: vi.fn().mockResolvedValue(undefined),
    textContent: vi.fn().mockResolvedValue('')
  };

  return {
    newPage: vi.fn().mockResolvedValue(page),
    close: vi.fn().mockResolvedValue(undefined),
    _page: page
  };
}

// =============================================================================
// TEST DATA FACTORIES
// =============================================================================

export function createMockPlatformConfig(overrides: Partial<{
  platform: string;
  max_uploads_per_day: number;
  max_uploads_per_hour: number;
  cooldown_minutes: number;
  jitter_min_seconds: number;
  jitter_max_seconds: number;
  require_human_review: boolean;
  suspension_risk_level: 'low' | 'medium' | 'high' | 'critical';
}> = {}) {
  return {
    platform: 'printify',
    max_uploads_per_day: 10,
    max_uploads_per_hour: 5,
    cooldown_minutes: 30,
    jitter_min_seconds: 60,
    jitter_max_seconds: 300,
    require_human_review: false,
    suspension_risk_level: 'low' as const,
    ...overrides
  };
}

export function createMockProduct(overrides: Partial<{
  id: string;
  type: string;
  niche: string;
  title: string;
  description: string;
  keywords: string[];
  imageUrl: string;
  imageBase64: string;
  targetPlatforms: string[];
}> = {}) {
  return {
    id: 'test-product-123',
    type: 'coloring_book',
    niche: 'adult_coloring',
    title: 'Beautiful Mandala Coloring Book',
    description: 'A collection of intricate mandala patterns for relaxation and mindfulness. Perfect for adults who want to unwind.',
    keywords: ['mandala', 'coloring', 'relaxation', 'adult'],
    imageUrl: 'https://example.com/image.png',
    targetPlatforms: ['printify', 'etsy'],
    ...overrides
  };
}

export function createMockQualityConfig(overrides: Partial<{
  product_type: string;
  min_resolution_width: number;
  min_resolution_height: number;
  min_quality_score: number;
  banned_style_keywords: string[];
  required_style_keywords: string[];
  niche_consistency_threshold: number;
  max_similarity_to_existing: number;
  require_unique_composition: boolean;
}> = {}) {
  return {
    product_type: 'coloring_book',
    min_resolution_width: 2400,
    min_resolution_height: 3000,
    min_quality_score: 0.70,
    banned_style_keywords: ['blurry', 'watermark', 'trademark'],
    required_style_keywords: [],
    niche_consistency_threshold: 0.70,
    max_similarity_to_existing: 0.85,
    require_unique_composition: true,
    ...overrides
  };
}

export function createMockApiRateLimit(overrides: Partial<{
  api_name: string;
  requests_per_minute: number;
  requests_per_hour: number;
  requests_per_day: number;
  current_minute_count: number;
  current_hour_count: number;
  current_day_count: number;
  minute_reset_at: string;
  hour_reset_at: string;
  day_reset_at: string;
}> = {}) {
  const now = new Date();
  return {
    api_name: 'openai',
    requests_per_minute: 60,
    requests_per_hour: 3500,
    requests_per_day: 10000,
    current_minute_count: 0,
    current_hour_count: 0,
    current_day_count: 0,
    minute_reset_at: new Date(now.getTime() + 60000).toISOString(),
    hour_reset_at: new Date(now.getTime() + 3600000).toISOString(),
    day_reset_at: new Date(now.getTime() + 86400000).toISOString(),
    ...overrides
  };
}

export function createMockProvider(overrides: Partial<{
  id: string;
  provider_type: string;
  provider_name: string;
  is_primary: boolean;
  is_available: boolean;
  health_score: number;
  last_check_at: string;
  failure_count_24h: number;
  avg_response_time_ms: number;
  capabilities: Record<string, any>;
  priority_order: number;
}> = {}) {
  return {
    id: 'provider-123',
    provider_type: 'ai_generation',
    provider_name: 'openai',
    is_primary: true,
    is_available: true,
    health_score: 0.95,
    last_check_at: new Date().toISOString(),
    failure_count_24h: 0,
    avg_response_time_ms: 500,
    capabilities: { models: ['gpt-4o', 'dall-e-3'] },
    priority_order: 1,
    ...overrides
  };
}

export function createMockBudgetConfig(overrides: Partial<{
  budget_type: string;
  limit_usd: number;
  warning_threshold_percent: number;
}> = {}) {
  return {
    budget_type: 'daily',
    limit_usd: 25.00,
    warning_threshold_percent: 80,
    ...overrides
  };
}

export function createMockApprovalQueueItem(overrides: Partial<{
  id: string;
  product_id: string;
  product_type: string;
  product_data: Record<string, any>;
  preview_urls: string[];
  status: 'pending' | 'approved' | 'rejected' | 'revision_requested';
  priority: number;
  auto_approve_eligible: boolean;
  target_platforms: string[];
  created_at: string;
}> = {}) {
  return {
    id: 'queue-item-123',
    product_id: 'product-123',
    product_type: 'coloring_book',
    product_data: {},
    preview_urls: ['https://example.com/preview.png'],
    status: 'pending' as const,
    priority: 5,
    auto_approve_eligible: false,
    target_platforms: ['printify'],
    created_at: new Date().toISOString(),
    ...overrides
  };
}

export function createMockTaxConfig(overrides: Partial<{
  region_code: string;
  region_name: string;
  tax_type: string;
  default_rate: string;
  requires_registration: boolean;
  registration_threshold_usd: string;
  tax_provider: string;
}> = {}) {
  return {
    region_code: 'US-CA',
    region_name: 'California',
    tax_type: 'sales_tax',
    default_rate: '0.0725',
    requires_registration: true,
    registration_threshold_usd: '100000',
    tax_provider: 'shopify_tax',
    ...overrides
  };
}

// =============================================================================
// TEST HELPERS
// =============================================================================

/**
 * Wait for all promises to resolve
 */
export function flushPromises(): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, 0));
}

/**
 * Create a mock fetch response
 */
export function createMockFetchResponse(data: any, options: {
  ok?: boolean;
  status?: number;
  headers?: Record<string, string>;
} = {}) {
  const { ok = true, status = 200, headers = {} } = options;

  return {
    ok,
    status,
    headers: {
      get: (name: string) => headers[name] || null
    },
    json: () => Promise.resolve(data),
    text: () => Promise.resolve(JSON.stringify(data))
  };
}

/**
 * Mock global fetch
 */
export function mockFetch(implementation?: (url: string, init?: RequestInit) => Promise<any>) {
  const mockFn = vi.fn().mockImplementation(implementation || (() =>
    Promise.resolve(createMockFetchResponse({}))
  ));

  global.fetch = mockFn as any;
  return mockFn;
}

/**
 * Restore global fetch
 */
export function restoreFetch() {
  vi.restoreAllMocks();
}

// =============================================================================
// MODULE MOCKING UTILITIES
// =============================================================================

/**
 * Setup Supabase module mock
 * Call this in your test file's vi.mock() setup
 */
export const mockSupabaseModule = () => {
  const mockClient = createMockSupabaseClient();

  vi.mock('@supabase/supabase-js', () => ({
    createClient: vi.fn(() => mockClient)
  }));

  return mockClient;
};

/**
 * Setup OpenAI module mock
 */
export const mockOpenAIModule = () => {
  const mockClient = createMockOpenAIClient();

  vi.mock('openai', () => ({
    default: vi.fn(() => mockClient)
  }));

  return mockClient;
};

/**
 * Setup Playwright module mock
 */
export const mockPlaywrightModule = () => {
  const mockBrowser = createMockBrowser();

  vi.mock('playwright', () => ({
    chromium: {
      launch: vi.fn(() => Promise.resolve(mockBrowser))
    }
  }));

  return mockBrowser;
};
