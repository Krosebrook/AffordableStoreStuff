/**
 * ============================================================================
 * BUDGET CIRCUIT BREAKER TEST SUITE
 * ============================================================================
 *
 * Tests for Safeguard #8: Budget Circuit Breaker
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { BudgetCircuitBreaker } from '../budget-circuit-breaker';
import {
  createMockSupabaseClient,
  createMockBudgetConfig,
  createMockFetchResponse,
  mockFetch,
  MockSupabaseClient
} from './test-utils';

// Mock modules
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn()
}));

describe('Safeguard #8: Budget Circuit Breaker', () => {
  let breaker: BudgetCircuitBreaker;
  let mockSupabase: MockSupabaseClient;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();

    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    breaker = new BudgetCircuitBreaker('https://test.supabase.co', 'test-key', {
      slackWebhook: 'https://hooks.slack.com/test'
    });
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // canSpend Tests
  // ===========================================================================

  describe('canSpend', () => {
    it('should allow spending when under budget', async () => {
      // Mock circuit breaker states - all closed
      mockSupabase._setResponse({ is_open: false });
      mockSupabase._setResponse({ is_open: false });
      mockSupabase._setResponse({ is_open: false });

      // Mock budget configs and costs
      mockSupabase._setResponse(createMockBudgetConfig({ limit_usd: 25, warning_threshold_percent: 80 }));
      mockSupabase._setResponse([{ cost_usd: 10 }]);

      const result = await breaker.canSpend(1.00);

      expect(result.allowed).toBe(true);
    });

    it('should block spending when circuit breaker is open', async () => {
      mockSupabase._setResponse({
        breaker_name: 'budget_daily',
        is_open: true,
        opened_reason: 'Daily budget exceeded'
      });

      // Mock budget status
      mockSupabase._setResponse(createMockBudgetConfig());
      mockSupabase._setResponse([]);

      const result = await breaker.canSpend();

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('OPEN');
    });

    it('should block when budget would be exceeded', async () => {
      mockSupabase._setResponse({ is_open: false });
      mockSupabase._setResponse({ is_open: false });
      mockSupabase._setResponse({ is_open: false });

      // Budget nearly depleted
      mockSupabase._setResponse(createMockBudgetConfig({ limit_usd: 25 }));
      mockSupabase._setResponse([{ cost_usd: 24.50 }]);

      const result = await breaker.canSpend(1.00);

      // Current spend (24.50) + estimated (1.00) > limit (25)
      expect(result.allowed).toBe(false);
    });
  });

  // ===========================================================================
  // recordCost Tests
  // ===========================================================================

  describe('recordCost', () => {
    it('should record cost event', async () => {
      mockSupabase._setResponse({ id: 'cost-event-123' });

      // Mock alert checking
      mockSupabase._setResponse(createMockBudgetConfig());
      mockSupabase._setResponse([]);

      await breaker.recordCost({
        serviceName: 'openai',
        operation: 'dall-e-3',
        costUsd: 0.04,
        unitsConsumed: 1,
        productId: 'product-123'
      });

      expect(mockSupabase.from).toHaveBeenCalledWith('cost_events');
    });

    it('should trigger alert when warning threshold reached', async () => {
      mockSupabase._setResponse({ id: 'cost-event-123' });

      // Mock budget at warning level
      mockSupabase._setResponse(createMockBudgetConfig({
        limit_usd: 25,
        warning_threshold_percent: 80
      }));
      mockSupabase._setResponse([{ cost_usd: 21 }]); // 84% of budget

      await breaker.recordCost({
        serviceName: 'openai',
        operation: 'gpt-4o',
        costUsd: 0.005,
        unitsConsumed: 1
      });

      expect(mockSupabase.from).toHaveBeenCalledWith('cost_events');
    });
  });

  // ===========================================================================
  // recordApiCost Tests
  // ===========================================================================

  describe('recordApiCost', () => {
    it('should record cost using database-driven rates', async () => {
      // Mock API costs from database
      mockSupabase._setResponse([
        { provider: 'openai', model: 'dall-e-3', cost_per_unit: 0.04 }
      ]);

      mockSupabase._setResponse({ id: 'cost-event-123' });
      mockSupabase._setResponse(createMockBudgetConfig());
      mockSupabase._setResponse([]);

      await breaker.recordApiCost('openai', 'dall-e-3', 1, 'product-123');

      expect(mockSupabase.from).toHaveBeenCalledWith('cost_events');
    });

    it('should warn for unknown API operations', async () => {
      mockSupabase._setResponse([]); // No costs found

      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

      await breaker.recordApiCost('unknown', 'unknown-operation', 1);

      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('Unknown API cost')
      );

      consoleSpy.mockRestore();
    });
  });

  // ===========================================================================
  // getBudgetStatus Tests
  // ===========================================================================

  describe('getBudgetStatus', () => {
    it('should return daily budget status', async () => {
      mockSupabase._setResponse(createMockBudgetConfig({
        budget_type: 'daily',
        limit_usd: 25,
        warning_threshold_percent: 80
      }));

      mockSupabase._setResponse([
        { cost_usd: 10 },
        { cost_usd: 5 }
      ]);

      const status = await breaker.getBudgetStatus('daily');

      expect(status.period).toBe('daily');
      expect(status.currentSpend).toBe(15);
      expect(status.limit).toBe(25);
      expect(status.percentUsed).toBe(60);
      expect(status.isWarning).toBe(false);
      expect(status.isExceeded).toBe(false);
    });

    it('should flag warning when at threshold', async () => {
      mockSupabase._setResponse(createMockBudgetConfig({
        limit_usd: 25,
        warning_threshold_percent: 80
      }));

      mockSupabase._setResponse([{ cost_usd: 20 }]); // 80%

      const status = await breaker.getBudgetStatus('daily');

      expect(status.isWarning).toBe(true);
    });

    it('should flag exceeded when over limit', async () => {
      mockSupabase._setResponse(createMockBudgetConfig({
        limit_usd: 25
      }));

      mockSupabase._setResponse([{ cost_usd: 26 }]);

      const status = await breaker.getBudgetStatus('daily');

      expect(status.isExceeded).toBe(true);
    });

    it('should calculate correct reset times', () => {
      const now = new Date();

      // Daily reset
      const dailyReset = new Date(now);
      dailyReset.setHours(0, 0, 0, 0);
      dailyReset.setDate(dailyReset.getDate() + 1);

      // Weekly reset
      const weeklyReset = new Date(now);
      weeklyReset.setDate(weeklyReset.getDate() - weeklyReset.getDay());
      weeklyReset.setHours(0, 0, 0, 0);
      weeklyReset.setDate(weeklyReset.getDate() + 7);

      // Monthly reset
      const monthlyReset = new Date(now.getFullYear(), now.getMonth() + 1, 1);

      expect(dailyReset > now).toBe(true);
      expect(weeklyReset > now).toBe(true);
      expect(monthlyReset > now).toBe(true);
    });
  });

  // ===========================================================================
  // getProductCost Tests
  // ===========================================================================

  describe('getProductCost', () => {
    it('should return total cost for a product', async () => {
      mockSupabase._setResponse([
        { cost_usd: 0.04 },
        { cost_usd: 0.005 },
        { cost_usd: 0.003 }
      ]);

      const cost = await breaker.getProductCost('product-123');

      expect(cost).toBeCloseTo(0.048, 3);
    });

    it('should return 0 for product with no costs', async () => {
      mockSupabase._setResponse([]);

      const cost = await breaker.getProductCost('new-product');

      expect(cost).toBe(0);
    });
  });

  // ===========================================================================
  // checkProductCostLimit Tests
  // ===========================================================================

  describe('checkProductCostLimit', () => {
    it('should allow when under per-product limit', async () => {
      mockSupabase._setResponse({ limit_usd: 0.50 });
      mockSupabase._setResponse([{ cost_usd: 0.30 }]);

      const result = await breaker.checkProductCostLimit('product-123', 0.10);

      expect(result.allowed).toBe(true);
      expect(result.currentCost).toBe(0.30);
    });

    it('should block when would exceed per-product limit', async () => {
      mockSupabase._setResponse({ limit_usd: 0.50 });
      mockSupabase._setResponse([{ cost_usd: 0.45 }]);

      const result = await breaker.checkProductCostLimit('product-123', 0.10);

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('would exceed limit');
    });

    it('should use default limit if not configured', async () => {
      mockSupabase._setResponse(null); // No config

      const defaultLimit = 0.50;
      expect(defaultLimit).toBe(0.50);
    });
  });

  // ===========================================================================
  // Circuit Breaker Control Tests
  // ===========================================================================

  describe('openCircuitBreaker', () => {
    it('should open circuit breaker and log alert', async () => {
      mockSupabase._setResponse({ id: 'updated' });
      mockSupabase._setResponse({ id: 'alert-logged' });

      const fetchMock = mockFetch(() =>
        Promise.resolve(createMockFetchResponse({ ok: true }))
      );

      await breaker.openCircuitBreaker('budget_daily', 'Daily budget exceeded');

      expect(mockSupabase.from).toHaveBeenCalledWith('circuit_breaker_state');

      vi.restoreAllMocks();
    });

    it('should send notification on circuit breaker open', async () => {
      mockSupabase._setResponse({ id: 'updated' });
      mockSupabase._setResponse({ id: 'alert-logged' });

      const fetchMock = mockFetch(() =>
        Promise.resolve(createMockFetchResponse({ ok: true }))
      );

      await breaker.openCircuitBreaker('budget_daily', 'Test reason');

      expect(fetchMock).toHaveBeenCalled();

      vi.restoreAllMocks();
    });
  });

  describe('closeCircuitBreaker', () => {
    it('should close circuit breaker and reset state', async () => {
      mockSupabase._setResponse({ id: 'updated' });

      const fetchMock = mockFetch(() =>
        Promise.resolve(createMockFetchResponse({ ok: true }))
      );

      await breaker.closeCircuitBreaker('budget_daily');

      expect(mockSupabase.from).toHaveBeenCalledWith('circuit_breaker_state');

      vi.restoreAllMocks();
    });
  });

  // ===========================================================================
  // getCircuitBreakerState Tests
  // ===========================================================================

  describe('getCircuitBreakerState', () => {
    it('should return open state', async () => {
      mockSupabase._setResponse({
        breaker_name: 'budget_daily',
        is_open: true,
        opened_at: new Date().toISOString(),
        opened_reason: 'Budget exceeded',
        consecutive_failures: 0
      });

      const state = await breaker.getCircuitBreakerState('budget_daily');

      expect(state.isOpen).toBe(true);
      expect(state.openedReason).toBe('Budget exceeded');
    });

    it('should return closed state', async () => {
      mockSupabase._setResponse({
        breaker_name: 'budget_daily',
        is_open: false,
        consecutive_failures: 0
      });

      const state = await breaker.getCircuitBreakerState('budget_daily');

      expect(state.isOpen).toBe(false);
    });

    it('should return default state when not found', async () => {
      mockSupabase._setResponse(null);

      const state = await breaker.getCircuitBreakerState('unknown');

      expect(state.isOpen).toBe(false);
      expect(state.consecutiveFailures).toBe(0);
    });
  });

  // ===========================================================================
  // getCostBreakdown Tests
  // ===========================================================================

  describe('getCostBreakdown', () => {
    it('should return costs aggregated by service', async () => {
      mockSupabase._setResponse([
        { service_name: 'openai', operation: 'dall-e-3', cost_usd: 0.04, units_consumed: 1 },
        { service_name: 'openai', operation: 'dall-e-3', cost_usd: 0.04, units_consumed: 1 },
        { service_name: 'openai', operation: 'gpt-4o', cost_usd: 0.005, units_consumed: 1 },
        { service_name: 'replicate', operation: 'flux-schnell', cost_usd: 0.003, units_consumed: 1 }
      ]);

      const breakdown = await breaker.getCostBreakdown('daily');

      expect(breakdown.length).toBe(3);
      expect(breakdown[0].totalCost).toBeGreaterThan(0);
    });

    it('should sort by total cost descending', async () => {
      mockSupabase._setResponse([
        { service_name: 'a', operation: 'op1', cost_usd: 1, units_consumed: 1 },
        { service_name: 'b', operation: 'op2', cost_usd: 5, units_consumed: 1 },
        { service_name: 'c', operation: 'op3', cost_usd: 3, units_consumed: 1 }
      ]);

      const breakdown = await breaker.getCostBreakdown('daily');

      expect(breakdown[0].totalCost).toBe(5);
      expect(breakdown[1].totalCost).toBe(3);
      expect(breakdown[2].totalCost).toBe(1);
    });
  });

  // ===========================================================================
  // estimateCost Tests
  // ===========================================================================

  describe('estimateCost', () => {
    it('should estimate cost using database rates', async () => {
      mockSupabase._setResponse([
        { provider: 'openai', model: 'dall-e-3', cost_per_unit: 0.04 }
      ]);

      const cost = await breaker.estimateCost('openai', 'dall-e-3', 3);

      expect(cost).toBe(0.12);
    });

    it('should return 0 for unknown service', async () => {
      mockSupabase._setResponse([]);

      const cost = await breaker.estimateCost('unknown', 'unknown', 1);

      expect(cost).toBe(0);
    });
  });

  describe('estimateCostSync', () => {
    it('should use cached values for sync estimate', () => {
      // After cache loaded, can use sync method
      const cost = breaker.estimateCostSync('openai', 'gpt-4o', 10);

      // Uses fallback values if cache not loaded
      expect(cost).toBeGreaterThanOrEqual(0);
    });

    it('should use fallback for unknown operations', () => {
      const cost = breaker.estimateCostSync('unknown', 'unknown', 1);

      expect(cost).toBe(0);
    });
  });

  // ===========================================================================
  // updateBudgetLimit Tests
  // ===========================================================================

  describe('updateBudgetLimit', () => {
    it('should update budget limit in database', async () => {
      mockSupabase._setResponse({ id: 'updated' });

      await breaker.updateBudgetLimit('daily', 50.00);

      expect(mockSupabase.from).toHaveBeenCalledWith('budget_config');
    });
  });

  // ===========================================================================
  // Cache Management Tests
  // ===========================================================================

  describe('Cache Management', () => {
    it('should invalidate costs cache', () => {
      breaker.invalidateCostsCache();

      // Should not throw
      expect(true).toBe(true);
    });

    it('should load fallback costs when database unavailable', () => {
      // Fallback costs should be available
      const fallbackCosts = {
        openai: {
          'gpt-4o': 0.005,
          'dall-e-3': 0.04
        },
        replicate: {
          'flux-schnell': 0.003
        }
      };

      expect(fallbackCosts.openai['dall-e-3']).toBe(0.04);
      expect(fallbackCosts.replicate['flux-schnell']).toBe(0.003);
    });
  });

  // ===========================================================================
  // Alert Deduplication Tests
  // ===========================================================================

  describe('Alert Deduplication', () => {
    it('should not send duplicate warnings within hour', async () => {
      // First warning should send
      // Second warning within hour should be skipped
      const recentAlertExists = true;

      expect(recentAlertExists).toBe(true);
    });

    it('should calculate threshold key correctly', () => {
      const percentUsed = 85;
      const thresholdKey = `daily_${Math.floor(percentUsed / 10) * 10}`;

      expect(thresholdKey).toBe('daily_80');
    });
  });

  // ===========================================================================
  // Budget Period Calculation Tests
  // ===========================================================================

  describe('Budget Period Calculations', () => {
    it('should calculate daily window correctly', () => {
      const now = new Date();
      const startTime = new Date(now);
      startTime.setHours(0, 0, 0, 0);

      expect(startTime.getHours()).toBe(0);
      expect(startTime.getMinutes()).toBe(0);
    });

    it('should calculate weekly window correctly', () => {
      const now = new Date();
      const startTime = new Date(now);
      startTime.setDate(startTime.getDate() - startTime.getDay());
      startTime.setHours(0, 0, 0, 0);

      // Should be Sunday
      expect(startTime.getDay()).toBe(0);
    });

    it('should calculate monthly window correctly', () => {
      const now = new Date();
      const startTime = new Date(now.getFullYear(), now.getMonth(), 1);

      expect(startTime.getDate()).toBe(1);
    });
  });

  // ===========================================================================
  // API Cost Constants Tests
  // ===========================================================================

  describe('API Cost Constants', () => {
    const FALLBACK_API_COSTS = {
      openai: {
        'gpt-4o': 0.005,
        'gpt-4o-mini': 0.00015,
        'dall-e-3': 0.04,
        'dall-e-3-hd': 0.08,
        'embedding': 0.00002
      },
      anthropic: {
        'claude-sonnet': 0.003,
        'claude-haiku': 0.00025
      },
      replicate: {
        'flux-schnell': 0.003,
        'flux-dev': 0.025,
        'sdxl': 0.002
      }
    };

    it('should have correct OpenAI costs', () => {
      expect(FALLBACK_API_COSTS.openai['gpt-4o']).toBe(0.005);
      expect(FALLBACK_API_COSTS.openai['dall-e-3']).toBe(0.04);
    });

    it('should have correct Anthropic costs', () => {
      expect(FALLBACK_API_COSTS.anthropic['claude-sonnet']).toBe(0.003);
    });

    it('should have correct Replicate costs', () => {
      expect(FALLBACK_API_COSTS.replicate['flux-schnell']).toBe(0.003);
      expect(FALLBACK_API_COSTS.replicate['flux-dev']).toBe(0.025);
    });
  });

  // ===========================================================================
  // Spending Warning Tests
  // ===========================================================================

  describe('Spending Warnings', () => {
    it('should format warning message correctly', () => {
      const status = {
        period: 'daily',
        percentUsed: 85,
        currentSpend: 21.25,
        limit: 25,
        remainingBudget: 3.75
      };

      const message = `BUDGET WARNING\n\n${status.period.toUpperCase()} budget at ${status.percentUsed}%\nSpent: $${status.currentSpend}\nLimit: $${status.limit}\nRemaining: $${status.remainingBudget}`;

      expect(message).toContain('DAILY');
      expect(message).toContain('85%');
      expect(message).toContain('$21.25');
    });

    it('should format circuit breaker message correctly', () => {
      const breakerName = 'budget_daily';
      const reason = 'Daily budget exceeded: $26.50/$25.00';

      const message = `CIRCUIT BREAKER TRIGGERED\n\nBreaker: ${breakerName}\nReason: ${reason}\n\nAll spending is now BLOCKED until manually reset.`;

      expect(message).toContain('TRIGGERED');
      expect(message).toContain('BLOCKED');
    });
  });
});
