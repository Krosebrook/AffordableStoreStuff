/**
 * ============================================================================
 * TAX COMPLIANCE TEST SUITE
 * ============================================================================
 *
 * Tests for Safeguard #6: Tax Compliance
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { TaxCompliance } from '../tax-compliance';
import {
  createMockSupabaseClient,
  createMockTaxConfig,
  createMockFetchResponse,
  mockFetch,
  MockSupabaseClient
} from './test-utils';

// Mock modules
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn()
}));

describe('Safeguard #6: Tax Compliance', () => {
  let taxCompliance: TaxCompliance;
  let mockSupabase: MockSupabaseClient;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();

    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    taxCompliance = new TaxCompliance(
      'https://test.supabase.co',
      'test-key',
      'shopify_tax'
    );
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // calculateTax Tests
  // ===========================================================================

  describe('calculateTax', () => {
    it('should calculate US sales tax correctly', async () => {
      const taxConfig = createMockTaxConfig({
        region_code: 'US-CA',
        region_name: 'California',
        tax_type: 'sales_tax',
        default_rate: '0.0725'
      });

      mockSupabase._setResponse(taxConfig);
      mockSupabase._setResponse({ id: 'transaction-123' });

      const order = {
        orderId: 'order-123',
        platform: 'shopify',
        subtotalUsd: 29.99,
        customerAddress: {
          country: 'US',
          state: 'CA',
          city: 'Los Angeles',
          postalCode: '90001'
        }
      };

      const result = await taxCompliance.calculateTax(order);

      expect(result.orderId).toBe('order-123');
      expect(result.customerRegion).toBe('US-CA');
      expect(result.taxAmountUsd).toBeCloseTo(2.17, 2);
      expect(result.taxRate).toBe(0.0725);
    });

    it('should calculate EU VAT correctly', async () => {
      const taxConfig = createMockTaxConfig({
        region_code: 'EU-DE',
        region_name: 'Germany',
        tax_type: 'vat',
        default_rate: '0.19'
      });

      mockSupabase._setResponse(taxConfig);
      mockSupabase._setResponse({ id: 'transaction-123' });

      const order = {
        orderId: 'order-456',
        platform: 'shopify',
        subtotalUsd: 29.99,
        customerAddress: {
          country: 'DE'
        }
      };

      const result = await taxCompliance.calculateTax(order);

      expect(result.taxAmountUsd).toBeCloseTo(5.70, 2);
      expect(result.taxRate).toBe(0.19);
    });

    it('should return zero tax for regions with no tax', async () => {
      mockSupabase._setResponse(null); // No tax config found

      const order = {
        orderId: 'order-789',
        platform: 'shopify',
        subtotalUsd: 29.99,
        customerAddress: {
          country: 'XX' // Unknown country
        }
      };

      const result = await taxCompliance.calculateTax(order);

      expect(result.taxAmountUsd).toBe(0);
      expect(result.taxRate).toBe(0);
    });

    it('should log transaction to database', async () => {
      const taxConfig = createMockTaxConfig();
      mockSupabase._setResponse(taxConfig);
      mockSupabase._setResponse({ id: 'transaction-123' });

      const order = {
        orderId: 'order-123',
        platform: 'shopify',
        subtotalUsd: 100.00,
        customerAddress: {
          country: 'US',
          state: 'CA'
        }
      };

      await taxCompliance.calculateTax(order);

      expect(mockSupabase.from).toHaveBeenCalledWith('tax_transactions');
    });
  });

  // ===========================================================================
  // TaxJar Integration Tests
  // ===========================================================================

  describe('TaxJar Integration', () => {
    it('should call TaxJar API when configured', async () => {
      const taxJarCompliance = new TaxCompliance(
        'https://test.supabase.co',
        'test-key',
        'taxjar',
        { taxjarApiKey: 'test-taxjar-key' }
      );

      const taxConfig = createMockTaxConfig();
      mockSupabase._setResponse(taxConfig);

      const fetchMock = mockFetch(() =>
        Promise.resolve(createMockFetchResponse({
          tax: {
            amount_to_collect: 2.17,
            rate: 0.0725,
            breakdown: {
              line_items: [{
                state: 'CA',
                combined_tax_rate: 0.0725,
                tax_collectable: 2.17
              }]
            }
          }
        }))
      );

      mockSupabase._setResponse({ id: 'transaction-123' });

      const order = {
        orderId: 'order-123',
        platform: 'shopify',
        subtotalUsd: 29.99,
        customerAddress: {
          country: 'US',
          state: 'CA',
          city: 'Los Angeles',
          postalCode: '90001'
        }
      };

      const result = await taxJarCompliance.calculateTax(order);

      expect(result.taxProvider).toBe('taxjar');
      expect(result.taxAmountUsd).toBe(2.17);

      vi.restoreAllMocks();
    });

    it('should fallback to manual calculation if TaxJar fails', async () => {
      const taxJarCompliance = new TaxCompliance(
        'https://test.supabase.co',
        'test-key',
        'taxjar',
        { taxjarApiKey: 'test-taxjar-key' }
      );

      const taxConfig = createMockTaxConfig();
      mockSupabase._setResponse(taxConfig);

      const fetchMock = mockFetch(() =>
        Promise.resolve(createMockFetchResponse({}, { ok: false, status: 500 }))
      );

      mockSupabase._setResponse({ id: 'transaction-123' });

      const order = {
        orderId: 'order-123',
        platform: 'shopify',
        subtotalUsd: 29.99,
        customerAddress: {
          country: 'US',
          state: 'CA'
        }
      };

      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      const result = await taxJarCompliance.calculateTax(order);

      expect(result.taxProvider).toBe('manual');

      consoleSpy.mockRestore();
      vi.restoreAllMocks();
    });
  });

  // ===========================================================================
  // Avalara Integration Tests
  // ===========================================================================

  describe('Avalara Integration', () => {
    it('should call Avalara API when configured', async () => {
      const avalaraCompliance = new TaxCompliance(
        'https://test.supabase.co',
        'test-key',
        'avalara',
        {
          avalaraAccountId: 'test-account',
          avalaraLicenseKey: 'test-license',
          avalaraEnvironment: 'sandbox'
        }
      );

      const taxConfig = createMockTaxConfig();
      mockSupabase._setResponse(taxConfig);

      const fetchMock = mockFetch(() =>
        Promise.resolve(createMockFetchResponse({
          totalTax: 2.17,
          lines: [{
            tax: 2.17,
            details: [{
              jurisName: 'California',
              rate: 0.0725
            }]
          }]
        }))
      );

      mockSupabase._setResponse({ id: 'transaction-123' });

      const order = {
        orderId: 'order-123',
        platform: 'shopify',
        subtotalUsd: 29.99,
        customerAddress: {
          country: 'US',
          state: 'CA',
          city: 'Los Angeles',
          postalCode: '90001'
        }
      };

      const result = await avalaraCompliance.calculateTax(order);

      expect(result.taxProvider).toBe('avalara');

      vi.restoreAllMocks();
    });
  });

  // ===========================================================================
  // getNexusStatus Tests
  // ===========================================================================

  describe('getNexusStatus', () => {
    it('should return nexus status for all tracked regions', async () => {
      const configs = [
        createMockTaxConfig({
          region_code: 'US-CA',
          requires_registration: true,
          registration_threshold_usd: '100000'
        }),
        createMockTaxConfig({
          region_code: 'US-TX',
          requires_registration: true,
          registration_threshold_usd: '500000'
        })
      ];

      mockSupabase._setResponse(configs);

      // Mock sales data
      mockSupabase._setResponse([
        { subtotal_usd: 40000 },
        { subtotal_usd: 45000 }
      ]);

      const statuses = await taxCompliance.getNexusStatus();

      expect(statuses.length).toBe(2);
    });

    it('should calculate percentage of threshold', () => {
      const threshold = 100000;
      const currentRevenue = 85000;
      const percentOfThreshold = (currentRevenue / threshold) * 100;

      expect(percentOfThreshold).toBe(85);
    });

    it('should flag action required when threshold exceeded', () => {
      const threshold = 100000;
      const currentRevenue = 105000;
      const percent = (currentRevenue / threshold) * 100;

      let alertLevel: 'ok' | 'warning' | 'action_required' = 'ok';
      if (percent >= 100) {
        alertLevel = 'action_required';
      } else if (percent >= 80) {
        alertLevel = 'warning';
      }

      expect(alertLevel).toBe('action_required');
    });

    it('should flag warning when approaching threshold', () => {
      const threshold = 100000;
      const currentRevenue = 85000;
      const percent = (currentRevenue / threshold) * 100;

      let alertLevel: 'ok' | 'warning' | 'action_required' = 'ok';
      if (percent >= 100) {
        alertLevel = 'action_required';
      } else if (percent >= 80) {
        alertLevel = 'warning';
      }

      expect(alertLevel).toBe('warning');
    });

    it('should return ok when well under threshold', () => {
      const threshold = 100000;
      const currentRevenue = 50000;
      const percent = (currentRevenue / threshold) * 100;

      let alertLevel: 'ok' | 'warning' | 'action_required' = 'ok';
      if (percent >= 100) {
        alertLevel = 'action_required';
      } else if (percent >= 80) {
        alertLevel = 'warning';
      }

      expect(alertLevel).toBe('ok');
    });
  });

  // ===========================================================================
  // generateReport Tests
  // ===========================================================================

  describe('generateReport', () => {
    it('should generate report with correct totals', async () => {
      mockSupabase._setResponse([
        { subtotal_usd: '100.00', tax_amount_usd: '7.25', customer_region: 'US-CA', platform: 'shopify' },
        { subtotal_usd: '50.00', tax_amount_usd: '3.63', customer_region: 'US-CA', platform: 'shopify' },
        { subtotal_usd: '75.00', tax_amount_usd: '0', customer_region: 'US-OR', platform: 'etsy' }
      ]);

      const startDate = new Date('2024-01-01');
      const endDate = new Date('2024-01-31');

      const report = await taxCompliance.generateReport(startDate, endDate);

      expect(report.totalSales).toBe(225);
      expect(report.totalTaxCollected).toBe(10.88);
    });

    it('should group by region correctly', async () => {
      mockSupabase._setResponse([
        { subtotal_usd: '100.00', tax_amount_usd: '7.25', customer_region: 'US-CA', platform: 'shopify' },
        { subtotal_usd: '50.00', tax_amount_usd: '3.63', customer_region: 'US-CA', platform: 'shopify' },
        { subtotal_usd: '75.00', tax_amount_usd: '5.44', customer_region: 'US-TX', platform: 'shopify' }
      ]);

      const report = await taxCompliance.generateReport(new Date(), new Date());

      expect(report.byRegion['US-CA'].sales).toBe(150);
      expect(report.byRegion['US-CA'].transactions).toBe(2);
      expect(report.byRegion['US-TX'].sales).toBe(75);
    });

    it('should group by platform correctly', async () => {
      mockSupabase._setResponse([
        { subtotal_usd: '100.00', tax_amount_usd: '7.25', customer_region: 'US-CA', platform: 'shopify' },
        { subtotal_usd: '50.00', tax_amount_usd: '3.63', customer_region: 'US-CA', platform: 'etsy' }
      ]);

      const report = await taxCompliance.generateReport(new Date(), new Date());

      expect(report.byPlatform['shopify'].sales).toBe(100);
      expect(report.byPlatform['etsy'].sales).toBe(50);
    });

    it('should handle empty report period', async () => {
      mockSupabase._setResponse([]);

      const report = await taxCompliance.generateReport(new Date(), new Date());

      expect(report.totalSales).toBe(0);
      expect(report.totalTaxCollected).toBe(0);
    });
  });

  // ===========================================================================
  // Region Code Generation Tests
  // ===========================================================================

  describe('Region Code Generation', () => {
    it('should generate US state code', () => {
      const getRegionCode = (country: string, state?: string): string => {
        const countryUpper = country.toUpperCase();

        if (countryUpper === 'US' && state) {
          return `US-${state.toUpperCase()}`;
        }

        if (['DE', 'FR', 'UK', 'GB', 'NL', 'IT', 'ES'].includes(countryUpper)) {
          return `EU-${countryUpper}`;
        }

        return countryUpper;
      };

      expect(getRegionCode('US', 'CA')).toBe('US-CA');
      expect(getRegionCode('US', 'tx')).toBe('US-TX');
    });

    it('should generate EU country code', () => {
      const getRegionCode = (country: string, state?: string): string => {
        const countryUpper = country.toUpperCase();

        if (countryUpper === 'US' && state) {
          return `US-${state.toUpperCase()}`;
        }

        if (['DE', 'FR', 'UK', 'GB', 'NL', 'IT', 'ES'].includes(countryUpper)) {
          return `EU-${countryUpper}`;
        }

        return countryUpper;
      };

      expect(getRegionCode('DE')).toBe('EU-DE');
      expect(getRegionCode('FR')).toBe('EU-FR');
      expect(getRegionCode('UK')).toBe('EU-UK');
    });

    it('should return country code for other countries', () => {
      const getRegionCode = (country: string, state?: string): string => {
        const countryUpper = country.toUpperCase();

        if (countryUpper === 'US' && state) {
          return `US-${state.toUpperCase()}`;
        }

        if (['DE', 'FR', 'UK', 'GB', 'NL', 'IT', 'ES'].includes(countryUpper)) {
          return `EU-${countryUpper}`;
        }

        return countryUpper;
      };

      expect(getRegionCode('CA')).toBe('CA'); // Canada
      expect(getRegionCode('AU')).toBe('AU'); // Australia
    });
  });

  // ===========================================================================
  // Product Tax Code Tests
  // ===========================================================================

  describe('Product Tax Codes', () => {
    describe('TaxJar codes', () => {
      const taxjarCodes: Record<string, string> = {
        'tshirt': '20010',
        'mug': '40030',
        'coloring_book': '81100',
        'digital': '31000'
      };

      it('should return correct code for clothing', () => {
        expect(taxjarCodes['tshirt']).toBe('20010');
      });

      it('should return correct code for books', () => {
        expect(taxjarCodes['coloring_book']).toBe('81100');
      });

      it('should return correct code for digital goods', () => {
        expect(taxjarCodes['digital']).toBe('31000');
      });
    });

    describe('Avalara codes', () => {
      const avalaraCodes: Record<string, string> = {
        'tshirt': 'PC040100',
        'mug': 'PF050001',
        'coloring_book': 'PB100000',
        'digital': 'D0000000'
      };

      it('should return correct code for clothing', () => {
        expect(avalaraCodes['tshirt']).toBe('PC040100');
      });

      it('should return correct code for books', () => {
        expect(avalaraCodes['coloring_book']).toBe('PB100000');
      });

      it('should return correct code for digital goods', () => {
        expect(avalaraCodes['digital']).toBe('D0000000');
      });
    });
  });

  // ===========================================================================
  // Tax Rounding Tests
  // ===========================================================================

  describe('Tax Rounding', () => {
    it('should round to 2 decimal places', () => {
      const subtotal = 29.99;
      const rate = 0.0725;
      const taxAmount = subtotal * rate;
      const rounded = Math.round(taxAmount * 100) / 100;

      expect(rounded).toBe(2.17);
    });

    it('should handle small amounts', () => {
      const subtotal = 1.99;
      const rate = 0.0725;
      const taxAmount = subtotal * rate;
      const rounded = Math.round(taxAmount * 100) / 100;

      expect(rounded).toBe(0.14);
    });

    it('should handle large amounts', () => {
      const subtotal = 9999.99;
      const rate = 0.0725;
      const taxAmount = subtotal * rate;
      const rounded = Math.round(taxAmount * 100) / 100;

      expect(rounded).toBe(725.00);
    });
  });
});
