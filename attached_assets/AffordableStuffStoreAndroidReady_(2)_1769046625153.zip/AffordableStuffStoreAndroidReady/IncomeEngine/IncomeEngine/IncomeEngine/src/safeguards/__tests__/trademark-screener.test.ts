/**
 * ============================================================================
 * TRADEMARK SCREENER TEST SUITE
 * ============================================================================
 *
 * Tests for Safeguard #3: Trademark Screening
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { TrademarkScreener, quickTrademarkCheck } from '../trademark-screener';
import {
  createMockSupabaseClient,
  createMockBrowser,
  createMockProduct,
  MockSupabaseClient,
  MockBrowser
} from './test-utils';

// Mock modules
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn()
}));

vi.mock('playwright', () => ({
  chromium: {
    launch: vi.fn()
  }
}));

describe('Safeguard #3: Trademark Screener', () => {
  let screener: TrademarkScreener;
  let mockSupabase: MockSupabaseClient;
  let mockBrowser: MockBrowser;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();
    mockBrowser = createMockBrowser();

    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    const playwrightModule = require('playwright');
    playwrightModule.chromium.launch.mockResolvedValue(mockBrowser);

    screener = new TrademarkScreener(
      'https://test.supabase.co',
      'test-key',
      10 // Higher rate limit for tests
    );
  });

  afterEach(async () => {
    await screener.cleanup();
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // screenProduct Tests
  // ===========================================================================

  describe('screenProduct', () => {
    it('should screen product and return clear status for safe terms', async () => {
      const product = createMockProduct({
        title: 'Beautiful Mandala Patterns',
        description: 'Intricate designs for relaxation',
        keywords: ['mandala', 'coloring', 'relaxation']
      });

      // Mock blocked terms - empty
      mockSupabase._setResponse([]);

      // Mock cached results - none
      mockSupabase._setResponse(null);

      const result = await screener.screenProduct(product);

      expect(result.productId).toBe(product.id);
      expect(result.blockedTerms.length).toBe(0);
    });

    it('should detect blocked trademarked terms', async () => {
      const product = createMockProduct({
        title: 'Disney Princess Coloring Book',
        description: 'Beautiful princess designs',
        keywords: ['disney', 'princess', 'coloring']
      });

      // Mock blocked terms cache
      mockSupabase._setResponse([
        { term: 'disney', reason: 'Trademarked by The Walt Disney Company', category: 'trademark' }
      ]);

      const result = await screener.screenProduct(product);

      expect(result.overallRisk).toBe('blocked');
      expect(result.blockedTerms).toContain('disney');
    });

    it('should handle products with no keywords', async () => {
      const product = createMockProduct({
        title: 'Simple Design',
        description: 'A basic pattern',
        keywords: []
      });

      mockSupabase._setResponse([]);

      const result = await screener.screenProduct(product);

      expect(result.productId).toBe(product.id);
    });
  });

  // ===========================================================================
  // checkTerm Tests
  // ===========================================================================

  describe('checkTerm', () => {
    it('should return blocked for known blocked terms', async () => {
      // Load blocked terms cache
      mockSupabase._setResponse([
        { term: 'marvel', reason: 'Trademarked', category: 'trademark' }
      ]);

      // Force cache load
      await screener.screenProduct(createMockProduct({ title: 'test', keywords: [] }));

      const result = await screener.checkTerm('marvel');

      expect(result.riskLevel).toBe('blocked');
      expect(result.blockedReason).toBeDefined();
      expect(result.fromCache).toBe(true);
    });

    it('should return cached result if available', async () => {
      mockSupabase._setResponse([]);

      // Mock cached trademark check
      mockSupabase._setResponse({
        search_term: 'mandala',
        risk_level: 'clear',
        matching_marks: [],
        checked_at: new Date().toISOString()
      });

      const result = await screener.checkTerm('mandala');

      expect(result.fromCache).toBe(true);
    });

    it('should handle partial matches for blocked terms', async () => {
      mockSupabase._setResponse([
        { term: 'pokemon', reason: 'Trademarked by Nintendo', category: 'trademark' }
      ]);

      await screener.screenProduct(createMockProduct({ title: 'test', keywords: [] }));

      // Check a term that contains the blocked word
      const result = await screener.checkTerm('pokemonlike');

      expect(result.riskLevel).toBe('blocked');
    });
  });

  // ===========================================================================
  // Term Extraction Tests
  // ===========================================================================

  describe('Term Extraction', () => {
    it('should extract single words from title', () => {
      const title = 'Beautiful Mandala Designs';
      const words = title
        .replace(/[^a-zA-Z0-9\s]/g, '')
        .split(/\s+/)
        .filter(w => w.length >= 2);

      expect(words).toContain('Beautiful');
      expect(words).toContain('Mandala');
      expect(words).toContain('Designs');
    });

    it('should extract two-word phrases', () => {
      const titleWords = ['cute', 'cat', 'designs'];
      const phrases: string[] = [];

      for (let i = 0; i < titleWords.length - 1; i++) {
        phrases.push(`${titleWords[i]} ${titleWords[i + 1]}`);
      }

      expect(phrases).toContain('cute cat');
      expect(phrases).toContain('cat designs');
    });

    it('should extract three-word phrases', () => {
      const titleWords = ['cute', 'cat', 'coloring', 'book'];
      const phrases: string[] = [];

      for (let i = 0; i < titleWords.length - 2; i++) {
        phrases.push(`${titleWords[i]} ${titleWords[i + 1]} ${titleWords[i + 2]}`);
      }

      expect(phrases).toContain('cute cat coloring');
      expect(phrases).toContain('cat coloring book');
    });

    it('should filter out common words', () => {
      const commonWords = new Set([
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'by', 'from', 'as', 'is', 'are', 'was', 'were', 'be'
      ]);

      const terms = ['the', 'beautiful', 'mandala', 'in', 'coloring', 'book'];
      const filtered = terms.filter(t => !commonWords.has(t) && t.length >= 3);

      expect(filtered).not.toContain('the');
      expect(filtered).not.toContain('in');
      expect(filtered).toContain('beautiful');
      expect(filtered).toContain('mandala');
    });
  });

  // ===========================================================================
  // Risk Level Analysis Tests
  // ===========================================================================

  describe('Risk Level Analysis', () => {
    it('should return clear when no matches', () => {
      const matches: any[] = [];

      const analyzeRiskLevel = (matches: any[]): 'clear' | 'caution' | 'blocked' => {
        if (matches.length === 0) return 'clear';
        const liveMatches = matches.filter(m => m.status === 'live');
        if (liveMatches.length === 0) return 'caution';
        const highSimilarityLive = liveMatches.filter(m => m.similarity >= 0.9);
        if (highSimilarityLive.length > 0) return 'blocked';
        return 'caution';
      };

      expect(analyzeRiskLevel(matches)).toBe('clear');
    });

    it('should return caution when only dead trademarks exist', () => {
      const matches = [
        { serialNumber: '123', status: 'dead', similarity: 1.0 },
        { serialNumber: '456', status: 'dead', similarity: 0.95 }
      ];

      const analyzeRiskLevel = (matches: any[]): 'clear' | 'caution' | 'blocked' => {
        if (matches.length === 0) return 'clear';
        const liveMatches = matches.filter(m => m.status === 'live');
        if (liveMatches.length === 0) return 'caution';
        const highSimilarityLive = liveMatches.filter(m => m.similarity >= 0.9);
        if (highSimilarityLive.length > 0) return 'blocked';
        return 'caution';
      };

      expect(analyzeRiskLevel(matches)).toBe('caution');
    });

    it('should return blocked for high similarity live trademarks', () => {
      const matches = [
        { serialNumber: '123', status: 'live', similarity: 0.95 }
      ];

      const analyzeRiskLevel = (matches: any[]): 'clear' | 'caution' | 'blocked' => {
        if (matches.length === 0) return 'clear';
        const liveMatches = matches.filter(m => m.status === 'live');
        if (liveMatches.length === 0) return 'caution';
        const highSimilarityLive = liveMatches.filter(m => m.similarity >= 0.9);
        if (highSimilarityLive.length > 0) return 'blocked';
        return 'caution';
      };

      expect(analyzeRiskLevel(matches)).toBe('blocked');
    });

    it('should return caution for low similarity live trademarks', () => {
      const matches = [
        { serialNumber: '123', status: 'live', similarity: 0.7 }
      ];

      const analyzeRiskLevel = (matches: any[]): 'clear' | 'caution' | 'blocked' => {
        if (matches.length === 0) return 'clear';
        const liveMatches = matches.filter(m => m.status === 'live');
        if (liveMatches.length === 0) return 'caution';
        const highSimilarityLive = liveMatches.filter(m => m.similarity >= 0.9);
        if (highSimilarityLive.length > 0) return 'blocked';
        return 'caution';
      };

      expect(analyzeRiskLevel(matches)).toBe('caution');
    });
  });

  // ===========================================================================
  // Blocked Terms Database Tests
  // ===========================================================================

  describe('Blocked Terms', () => {
    const knownBlockedTerms = [
      'disney', 'marvel', 'pokemon', 'nike', 'star wars',
      'hello kitty', 'peppa pig', 'paw patrol', 'cocomelon',
      'mickey mouse', 'minnie mouse', 'frozen', 'elsa'
    ];

    it('should recognize major entertainment trademarks', () => {
      const testTerm = 'disney';
      expect(knownBlockedTerms.includes(testTerm)).toBe(true);
    });

    it('should recognize sports brand trademarks', () => {
      const testTerm = 'nike';
      expect(knownBlockedTerms.includes(testTerm)).toBe(true);
    });

    it('should recognize children content trademarks', () => {
      const childTerms = ['peppa pig', 'paw patrol', 'cocomelon'];
      childTerms.forEach(term => {
        expect(knownBlockedTerms.includes(term)).toBe(true);
      });
    });

    it('should not block generic terms', () => {
      const genericTerms = ['mandala', 'floral', 'geometric', 'abstract'];
      genericTerms.forEach(term => {
        expect(knownBlockedTerms.includes(term)).toBe(false);
      });
    });
  });

  // ===========================================================================
  // addBlockedTerm Tests
  // ===========================================================================

  describe('addBlockedTerm', () => {
    it('should add new blocked term to database', async () => {
      mockSupabase._setResponse({ id: 'new-term-123' });

      await screener.addBlockedTerm('newbrand', 'New trademark', 'trademark');

      expect(mockSupabase.from).toHaveBeenCalledWith('blocked_terms');
    });

    it('should update local cache after adding term', async () => {
      mockSupabase._setResponse([]);
      mockSupabase._setResponse({ id: 'new-term-123' });

      await screener.addBlockedTerm('newbrand', 'New trademark', 'trademark');

      // The term should now be in cache
      const result = await screener.checkTerm('newbrand');
      expect(result.riskLevel).toBe('blocked');
    });

    it('should support different blocked term categories', async () => {
      mockSupabase._setResponse({ id: 'term-123' });

      const categories: Array<'trademark' | 'copyright' | 'celebrity' | 'brand' | 'offensive'> = [
        'trademark', 'copyright', 'celebrity', 'brand', 'offensive'
      ];

      for (const category of categories) {
        await screener.addBlockedTerm(`term_${category}`, `Reason for ${category}`, category);
      }

      expect(mockSupabase.from).toHaveBeenCalledWith('blocked_terms');
    });
  });

  // ===========================================================================
  // quickTrademarkCheck Tests
  // ===========================================================================

  describe('quickTrademarkCheck', () => {
    it('should return blocked true for blocked terms', async () => {
      mockSupabase._setResponse([
        { term: 'disney', reason: 'Trademarked', category: 'trademark' }
      ]);

      const result = await quickTrademarkCheck(
        'disney',
        'https://test.supabase.co',
        'test-key'
      );

      expect(result.blocked).toBe(true);
      expect(result.reason).toBeDefined();
    });

    it('should return blocked false for clear terms', async () => {
      mockSupabase._setResponse([]);
      mockSupabase._setResponse(null); // No cached result

      const result = await quickTrademarkCheck(
        'mandala',
        'https://test.supabase.co',
        'test-key'
      );

      expect(result.blocked).toBe(false);
    });
  });

  // ===========================================================================
  // Browser Cleanup Tests
  // ===========================================================================

  describe('Browser Cleanup', () => {
    it('should close browser on cleanup', async () => {
      await screener.cleanup();

      // Browser close should be callable without error
      expect(true).toBe(true);
    });

    it('should handle cleanup when browser not initialized', async () => {
      const freshScreener = new TrademarkScreener(
        'https://test.supabase.co',
        'test-key'
      );

      // Should not throw
      await freshScreener.cleanup();
    });
  });

  // ===========================================================================
  // Rate Limiting Tests
  // ===========================================================================

  describe('Rate Limiting', () => {
    it('should respect rate limit between TESS queries', async () => {
      const rateLimit = 5; // 5 requests per minute
      const expectedDelayMs = (60 / rateLimit) * 1000;

      expect(expectedDelayMs).toBe(12000);
    });

    it('should calculate correct delay for different rate limits', () => {
      const testCases = [
        { rateLimit: 5, expectedDelay: 12000 },
        { rateLimit: 10, expectedDelay: 6000 },
        { rateLimit: 20, expectedDelay: 3000 },
        { rateLimit: 1, expectedDelay: 60000 }
      ];

      testCases.forEach(({ rateLimit, expectedDelay }) => {
        const delayMs = (60 / rateLimit) * 1000;
        expect(delayMs).toBe(expectedDelay);
      });
    });
  });

  // ===========================================================================
  // Caching Tests
  // ===========================================================================

  describe('Result Caching', () => {
    it('should cache trademark check results for 30 days', () => {
      const cacheExpiryDays = 30;
      const now = new Date();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + cacheExpiryDays);

      const differenceMs = expiresAt.getTime() - now.getTime();
      const differenceDays = differenceMs / (1000 * 60 * 60 * 24);

      expect(differenceDays).toBeCloseTo(30, 0);
    });

    it('should return cached result when not expired', async () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 15);

      mockSupabase._setResponse([]);
      mockSupabase._setResponse({
        search_term: 'testterm',
        risk_level: 'clear',
        matching_marks: [],
        checked_at: new Date().toISOString(),
        expires_at: futureDate.toISOString()
      });

      const result = await screener.checkTerm('testterm');

      expect(result.fromCache).toBe(true);
    });
  });

  // ===========================================================================
  // Product Screening Result Tests
  // ===========================================================================

  describe('Screening Result Generation', () => {
    it('should generate recommended actions for blocked products', () => {
      const blockedTerms = ['disney', 'marvel'];
      const recommendedActions: string[] = [];

      if (blockedTerms.length > 0) {
        recommendedActions.push(`Remove blocked terms: ${blockedTerms.join(', ')}`);
        recommendedActions.push('Do NOT proceed with this product as-is');
      }

      expect(recommendedActions.length).toBe(2);
      expect(recommendedActions[0]).toContain('disney');
      expect(recommendedActions[1]).toContain('Do NOT proceed');
    });

    it('should generate recommended actions for caution products', () => {
      const cautionTerms = ['prince', 'magic'];
      const blockedTerms: string[] = [];
      const recommendedActions: string[] = [];

      if (blockedTerms.length > 0) {
        recommendedActions.push(`Remove blocked terms: ${blockedTerms.join(', ')}`);
      } else if (cautionTerms.length > 0) {
        recommendedActions.push(`Review potentially problematic terms: ${cautionTerms.join(', ')}`);
        recommendedActions.push('Consider alternative wording or manual trademark search');
      }

      expect(recommendedActions.length).toBe(2);
      expect(recommendedActions[0]).toContain('Review');
    });

    it('should generate no actions for clear products', () => {
      const cautionTerms: string[] = [];
      const blockedTerms: string[] = [];
      const recommendedActions: string[] = [];

      if (blockedTerms.length > 0) {
        recommendedActions.push(`Remove blocked terms: ${blockedTerms.join(', ')}`);
      } else if (cautionTerms.length > 0) {
        recommendedActions.push(`Review potentially problematic terms: ${cautionTerms.join(', ')}`);
      }

      expect(recommendedActions.length).toBe(0);
    });
  });
});
