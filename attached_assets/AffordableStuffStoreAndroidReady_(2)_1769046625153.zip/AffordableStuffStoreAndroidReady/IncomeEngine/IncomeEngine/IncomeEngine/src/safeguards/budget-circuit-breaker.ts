/**
 * ============================================================================
 * SAFEGUARD #8: BUDGET CIRCUIT BREAKER
 * ============================================================================
 * 
 * Purpose: Prevent runaway workflows from burning through budget
 * 
 * Features:
 * - Daily/Weekly/Monthly spending caps
 * - Per-product cost limits
 * - Real-time cost tracking
 * - Warning thresholds with notifications
 * - Hard stop circuit breaker
 * - Cost attribution by service
 * - Budget recovery/reset
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// =============================================================================
// TYPES
// =============================================================================

type BudgetPeriod = 'daily' | 'weekly' | 'monthly' | 'per_product';

interface BudgetStatus {
  period: BudgetPeriod;
  currentSpend: number;
  limit: number;
  percentUsed: number;
  isWarning: boolean;
  isExceeded: boolean;
  remainingBudget: number;
  resetAt?: Date;
}

interface CostEvent {
  serviceName: string;
  operation: string;
  costUsd: number;
  unitsConsumed: number;
  productId?: string;
  workflowRunId?: string;
  metadata?: Record<string, any>;
}

interface CircuitBreakerState {
  name: string;
  isOpen: boolean;
  openedAt?: Date;
  openedReason?: string;
  willRetryAt?: Date;
  consecutiveFailures: number;
}

interface BudgetAlert {
  type: 'warning' | 'critical' | 'circuit_breaker_triggered';
  period: BudgetPeriod;
  currentSpend: number;
  limit: number;
  percentUsed: number;
  message: string;
}

interface ApiCostEntry {
  provider: string;
  model: string;
  costPerUnit: number;
  unitType: string;
}

// Fallback costs (only used if database unavailable)
const FALLBACK_API_COSTS: Record<string, Record<string, number>> = {
  openai: {
    'gpt-4o': 0.005,
    'gpt-4o-mini': 0.00015,
    'dall-e-3': 0.04,
    'dall-e-3-hd': 0.08,
    'embedding': 0.00002
  },
  anthropic: {
    'claude-sonnet': 0.003,
    'claude-haiku': 0.00025
  },
  replicate: {
    'flux-schnell': 0.003,
    'flux-dev': 0.025,
    'sdxl': 0.002
  },
  stability: {
    'sd3': 0.035,
    'sdxl': 0.002
  }
};

// =============================================================================
// BUDGET CIRCUIT BREAKER CLASS
// =============================================================================

export class BudgetCircuitBreaker {
  private supabase: SupabaseClient;
  private notificationWebhook?: string;
  private alertEmail?: string;
  private apiCostsCache: Map<string, number> = new Map();
  private apiCostsCacheLoaded: boolean = false;
  private apiCostsCacheExpiry: Date | null = null;
  private readonly COST_CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    config?: {
      slackWebhook?: string;
      alertEmail?: string;
    }
  ) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.notificationWebhook = config?.slackWebhook;
    this.alertEmail = config?.alertEmail;
  }

  /**
   * Load API costs from database into cache
   */
  private async loadApiCostsCache(): Promise<void> {
    // Check if cache is still valid
    if (this.apiCostsCacheLoaded &&
        this.apiCostsCacheExpiry &&
        this.apiCostsCacheExpiry > new Date()) {
      return;
    }

    try {
      const { data, error } = await this.supabase
        .from('api_costs')
        .select('provider, model, cost_per_unit')
        .eq('is_active', true);

      if (error || !data || data.length === 0) {
        // Fall back to hardcoded values
        console.warn('Failed to load API costs from database, using fallback values');
        this.loadFallbackCosts();
        return;
      }

      // Clear and reload cache
      this.apiCostsCache.clear();

      for (const row of data) {
        const key = `${row.provider}:${row.model}`;
        this.apiCostsCache.set(key, row.cost_per_unit);
      }

      this.apiCostsCacheLoaded = true;
      this.apiCostsCacheExpiry = new Date(Date.now() + this.COST_CACHE_TTL_MS);

    } catch (e) {
      console.error('Error loading API costs:', e);
      this.loadFallbackCosts();
    }
  }

  /**
   * Load fallback costs into cache
   */
  private loadFallbackCosts(): void {
    this.apiCostsCache.clear();

    for (const [provider, operations] of Object.entries(FALLBACK_API_COSTS)) {
      for (const [model, cost] of Object.entries(operations)) {
        const key = `${provider}:${model}`;
        this.apiCostsCache.set(key, cost);
      }
    }

    this.apiCostsCacheLoaded = true;
    this.apiCostsCacheExpiry = new Date(Date.now() + this.COST_CACHE_TTL_MS);
  }

  /**
   * Get cost for a specific API operation
   */
  private async getApiCost(provider: string, model: string): Promise<number | undefined> {
    await this.loadApiCostsCache();

    const key = `${provider}:${model}`;
    return this.apiCostsCache.get(key);
  }

  /**
   * Invalidate API costs cache (call after updating costs in database)
   */
  invalidateCostsCache(): void {
    this.apiCostsCacheLoaded = false;
    this.apiCostsCacheExpiry = null;
    this.apiCostsCache.clear();
  }

  /**
   * Check if spending is allowed (circuit breaker closed)
   */
  async canSpend(estimatedCost: number = 0): Promise<{
    allowed: boolean;
    reason?: string;
    budgetStatus: BudgetStatus[];
  }> {
    // Check all circuit breakers
    const breakers = ['budget_daily', 'budget_weekly', 'budget_monthly'];
    
    for (const breakerName of breakers) {
      const state = await this.getCircuitBreakerState(breakerName);
      if (state.isOpen) {
        return {
          allowed: false,
          reason: `Circuit breaker ${breakerName} is OPEN: ${state.openedReason}`,
          budgetStatus: await this.getAllBudgetStatus()
        };
      }
    }

    // Check budget limits
    const statuses = await this.getAllBudgetStatus();
    
    for (const status of statuses) {
      // Check if adding this cost would exceed limit
      if (status.currentSpend + estimatedCost > status.limit) {
        return {
          allowed: false,
          reason: `Would exceed ${status.period} budget limit ($${status.limit})`,
          budgetStatus: statuses
        };
      }

      // Check if already exceeded
      if (status.isExceeded) {
        return {
          allowed: false,
          reason: `${status.period} budget exceeded ($${status.currentSpend}/$${status.limit})`,
          budgetStatus: statuses
        };
      }
    }

    return {
      allowed: true,
      budgetStatus: statuses
    };
  }

  /**
   * Record a cost event
   */
  async recordCost(event: CostEvent): Promise<void> {
    // Insert cost event
    await this.supabase
      .from('cost_events')
      .insert({
        service_name: event.serviceName,
        operation: event.operation,
        cost_usd: event.costUsd,
        units_consumed: event.unitsConsumed,
        product_id: event.productId,
        workflow_run_id: event.workflowRunId,
        metadata: event.metadata || {}
      });

    // Check if we need to trigger alerts
    await this.checkAndTriggerAlerts();
  }

  /**
   * Record cost from known API operation (uses database-driven costs)
   */
  async recordApiCost(
    service: string,
    operation: string,
    units: number = 1,
    productId?: string,
    workflowRunId?: string
  ): Promise<void> {
    const unitCost = await this.getApiCost(service, operation);

    if (unitCost === undefined) {
      console.warn(`Unknown API cost: ${service}/${operation}`);
      return;
    }

    const totalCost = unitCost * units;

    await this.recordCost({
      serviceName: service,
      operation,
      costUsd: totalCost,
      unitsConsumed: units,
      productId,
      workflowRunId
    });
  }

  /**
   * Get status for all budget periods
   */
  async getAllBudgetStatus(): Promise<BudgetStatus[]> {
    const periods: BudgetPeriod[] = ['daily', 'weekly', 'monthly'];
    const statuses: BudgetStatus[] = [];

    for (const period of periods) {
      statuses.push(await this.getBudgetStatus(period));
    }

    return statuses;
  }

  /**
   * Get status for a specific budget period
   */
  async getBudgetStatus(period: BudgetPeriod): Promise<BudgetStatus> {
    // Get budget config
    const { data: config } = await this.supabase
      .from('budget_config')
      .select('*')
      .eq('budget_type', period)
      .single();

    if (!config) {
      return {
        period,
        currentSpend: 0,
        limit: 0,
        percentUsed: 0,
        isWarning: false,
        isExceeded: false,
        remainingBudget: 0
      };
    }

    // Calculate time window
    const now = new Date();
    let startTime: Date;
    let resetAt: Date;

    switch (period) {
      case 'daily':
        startTime = new Date(now);
        startTime.setHours(0, 0, 0, 0);
        resetAt = new Date(startTime);
        resetAt.setDate(resetAt.getDate() + 1);
        break;
      case 'weekly':
        startTime = new Date(now);
        startTime.setDate(startTime.getDate() - startTime.getDay());
        startTime.setHours(0, 0, 0, 0);
        resetAt = new Date(startTime);
        resetAt.setDate(resetAt.getDate() + 7);
        break;
      case 'monthly':
        startTime = new Date(now.getFullYear(), now.getMonth(), 1);
        resetAt = new Date(now.getFullYear(), now.getMonth() + 1, 1);
        break;
      default:
        startTime = new Date(now);
        startTime.setHours(0, 0, 0, 0);
        resetAt = new Date(startTime);
        resetAt.setDate(resetAt.getDate() + 1);
    }

    // Sum costs in window
    const { data: costs } = await this.supabase
      .from('cost_events')
      .select('cost_usd')
      .gte('recorded_at', startTime.toISOString());

    const currentSpend = costs?.reduce((sum, c) => sum + c.cost_usd, 0) || 0;
    const percentUsed = (currentSpend / config.limit_usd) * 100;

    return {
      period,
      currentSpend: Math.round(currentSpend * 100) / 100,
      limit: config.limit_usd,
      percentUsed: Math.round(percentUsed),
      isWarning: percentUsed >= config.warning_threshold_percent,
      isExceeded: currentSpend >= config.limit_usd,
      remainingBudget: Math.max(0, config.limit_usd - currentSpend),
      resetAt
    };
  }

  /**
   * Get cost for a specific product
   */
  async getProductCost(productId: string): Promise<number> {
    const { data } = await this.supabase
      .from('cost_events')
      .select('cost_usd')
      .eq('product_id', productId);

    return data?.reduce((sum, c) => sum + c.cost_usd, 0) || 0;
  }

  /**
   * Check if product cost is within limits
   */
  async checkProductCostLimit(productId: string, additionalCost: number = 0): Promise<{
    allowed: boolean;
    currentCost: number;
    limit: number;
    reason?: string;
  }> {
    const { data: config } = await this.supabase
      .from('budget_config')
      .select('limit_usd')
      .eq('budget_type', 'per_product')
      .single();

    const limit = config?.limit_usd || 0.50;
    const currentCost = await this.getProductCost(productId);

    if (currentCost + additionalCost > limit) {
      return {
        allowed: false,
        currentCost,
        limit,
        reason: `Product cost ($${currentCost + additionalCost}) would exceed limit ($${limit})`
      };
    }

    return {
      allowed: true,
      currentCost,
      limit
    };
  }

  /**
   * Open circuit breaker (stop all spending)
   */
  async openCircuitBreaker(breakerName: string, reason: string): Promise<void> {
    await this.supabase
      .from('circuit_breaker_state')
      .update({
        is_open: true,
        opened_at: new Date().toISOString(),
        opened_reason: reason,
        updated_at: new Date().toISOString()
      })
      .eq('breaker_name', breakerName);

    // Log alert
    await this.logAlert({
      type: 'circuit_breaker_triggered',
      period: breakerName.replace('budget_', '') as BudgetPeriod,
      currentSpend: 0,
      limit: 0,
      percentUsed: 100,
      message: `Circuit breaker ${breakerName} OPENED: ${reason}`
    });

    // Send notification
    await this.sendNotification(
      `🚨 CIRCUIT BREAKER TRIGGERED\n\nBreaker: ${breakerName}\nReason: ${reason}\n\nAll spending is now BLOCKED until manually reset.`
    );
  }

  /**
   * Close circuit breaker (resume spending)
   */
  async closeCircuitBreaker(breakerName: string): Promise<void> {
    await this.supabase
      .from('circuit_breaker_state')
      .update({
        is_open: false,
        opened_at: null,
        opened_reason: null,
        will_retry_at: null,
        consecutive_failures: 0,
        last_success_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('breaker_name', breakerName);

    await this.sendNotification(
      `✅ Circuit breaker ${breakerName} has been CLOSED. Spending is now allowed.`
    );
  }

  /**
   * Get circuit breaker state
   */
  async getCircuitBreakerState(breakerName: string): Promise<CircuitBreakerState> {
    const { data } = await this.supabase
      .from('circuit_breaker_state')
      .select('*')
      .eq('breaker_name', breakerName)
      .single();

    if (!data) {
      return {
        name: breakerName,
        isOpen: false,
        consecutiveFailures: 0
      };
    }

    return {
      name: data.breaker_name,
      isOpen: data.is_open,
      openedAt: data.opened_at ? new Date(data.opened_at) : undefined,
      openedReason: data.opened_reason,
      willRetryAt: data.will_retry_at ? new Date(data.will_retry_at) : undefined,
      consecutiveFailures: data.consecutive_failures
    };
  }

  /**
   * Check budgets and trigger alerts if needed
   */
  private async checkAndTriggerAlerts(): Promise<void> {
    const statuses = await this.getAllBudgetStatus();

    for (const status of statuses) {
      // Check for exceeded budget
      if (status.isExceeded) {
        const breakerName = `budget_${status.period}`;
        const state = await this.getCircuitBreakerState(breakerName);
        
        if (!state.isOpen) {
          await this.openCircuitBreaker(
            breakerName,
            `${status.period} budget exceeded: $${status.currentSpend}/$${status.limit}`
          );
        }
      }
      // Check for warning threshold
      else if (status.isWarning) {
        await this.logAlert({
          type: 'warning',
          period: status.period,
          currentSpend: status.currentSpend,
          limit: status.limit,
          percentUsed: status.percentUsed,
          message: `${status.period} budget at ${status.percentUsed}% ($${status.currentSpend}/$${status.limit})`
        });

        // Send warning notification (only once per threshold crossing)
        await this.sendWarningNotification(status);
      }
    }
  }

  /**
   * Log a budget alert
   */
  private async logAlert(alert: BudgetAlert): Promise<void> {
    await this.supabase
      .from('budget_alerts')
      .insert({
        alert_type: alert.type,
        budget_type: alert.period,
        current_spend_usd: alert.currentSpend,
        limit_usd: alert.limit,
        percent_used: alert.percentUsed,
        message: alert.message
      });
  }

  /**
   * Send warning notification (deduplicated)
   */
  private async sendWarningNotification(status: BudgetStatus): Promise<void> {
    // Check if we already sent a warning for this threshold
    const thresholdKey = `${status.period}_${Math.floor(status.percentUsed / 10) * 10}`;
    
    const { data: recentAlert } = await this.supabase
      .from('budget_alerts')
      .select('id')
      .eq('alert_type', 'warning')
      .eq('budget_type', status.period)
      .gte('triggered_at', new Date(Date.now() - 60 * 60 * 1000).toISOString()) // Last hour
      .limit(1)
      .single();

    if (recentAlert) {
      return; // Already sent warning recently
    }

    await this.sendNotification(
      `⚠️ BUDGET WARNING\n\n${status.period.toUpperCase()} budget at ${status.percentUsed}%\nSpent: $${status.currentSpend}\nLimit: $${status.limit}\nRemaining: $${status.remainingBudget}`
    );
  }

  /**
   * Send notification via webhook
   */
  private async sendNotification(message: string): Promise<void> {
    if (this.notificationWebhook) {
      try {
        await fetch(this.notificationWebhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: message })
        });
      } catch (e) {
        console.error('Failed to send notification:', e);
      }
    }

    console.log('[BUDGET ALERT]', message);
  }

  /**
   * Get cost breakdown by service
   */
  async getCostBreakdown(period: BudgetPeriod = 'daily'): Promise<Array<{
    service: string;
    operation: string;
    totalCost: number;
    unitCount: number;
  }>> {
    const now = new Date();
    let startTime: Date;

    switch (period) {
      case 'daily':
        startTime = new Date(now);
        startTime.setHours(0, 0, 0, 0);
        break;
      case 'weekly':
        startTime = new Date(now);
        startTime.setDate(startTime.getDate() - startTime.getDay());
        startTime.setHours(0, 0, 0, 0);
        break;
      case 'monthly':
        startTime = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      default:
        startTime = new Date(now);
        startTime.setHours(0, 0, 0, 0);
    }

    const { data } = await this.supabase
      .from('cost_events')
      .select('service_name, operation, cost_usd, units_consumed')
      .gte('recorded_at', startTime.toISOString());

    if (!data) return [];

    // Aggregate by service and operation
    const breakdown = new Map<string, { totalCost: number; unitCount: number }>();

    for (const event of data) {
      const key = `${event.service_name}:${event.operation}`;
      const current = breakdown.get(key) || { totalCost: 0, unitCount: 0 };
      current.totalCost += event.cost_usd;
      current.unitCount += event.units_consumed;
      breakdown.set(key, current);
    }

    return Array.from(breakdown.entries())
      .map(([key, data]) => {
        const [service, operation] = key.split(':');
        return { service, operation, ...data };
      })
      .sort((a, b) => b.totalCost - a.totalCost);
  }

  /**
   * Estimate cost before running operation (uses database-driven costs)
   */
  async estimateCost(service: string, operation: string, units: number = 1): Promise<number> {
    const unitCost = await this.getApiCost(service, operation);
    if (unitCost === undefined) return 0;

    return unitCost * units;
  }

  /**
   * Synchronous cost estimate using cached values (for quick checks)
   * Note: Call loadApiCostsCache() first if cache may be stale
   */
  estimateCostSync(service: string, operation: string, units: number = 1): number {
    const key = `${service}:${operation}`;
    const unitCost = this.apiCostsCache.get(key);
    if (unitCost === undefined) {
      // Try fallback
      const fallbackCost = FALLBACK_API_COSTS[service]?.[operation];
      if (fallbackCost === undefined) return 0;
      return fallbackCost * units;
    }
    return unitCost * units;
  }

  /**
   * Update budget limits
   */
  async updateBudgetLimit(period: BudgetPeriod, newLimit: number): Promise<void> {
    await this.supabase
      .from('budget_config')
      .update({
        limit_usd: newLimit,
        updated_at: new Date().toISOString()
      })
      .eq('budget_type', period);
  }
}

export default BudgetCircuitBreaker;
