/**
 * ============================================================================
 * API QUEUE TEST SUITE
 * ============================================================================
 *
 * Tests for Safeguard #4: API Queue with Exponential Backoff
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { ApiQueue } from '../api-queue';
import {
  createMockSupabaseClient,
  createMockApiRateLimit,
  createMockFetchResponse,
  mockFetch,
  MockSupabaseClient
} from './test-utils';

// Mock modules
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn()
}));

describe('Safeguard #4: API Queue', () => {
  let apiQueue: ApiQueue;
  let mockSupabase: MockSupabaseClient;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();

    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    apiQueue = new ApiQueue('https://test.supabase.co', 'test-key');
  });

  afterEach(() => {
    apiQueue.stopProcessing();
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // enqueue Tests
  // ===========================================================================

  describe('enqueue', () => {
    it('should add request to queue with default values', async () => {
      mockSupabase._setResponse({ id: 'request-123' });

      const requestId = await apiQueue.enqueue({
        apiName: 'openai',
        endpoint: 'https://api.openai.com/v1/chat/completions'
      });

      expect(requestId).toBe('request-123');
      expect(mockSupabase.from).toHaveBeenCalledWith('api_queue');
    });

    it('should add request with custom priority', async () => {
      mockSupabase._setResponse({ id: 'request-123' });

      await apiQueue.enqueue({
        apiName: 'openai',
        endpoint: 'https://api.openai.com/v1/chat/completions',
        priority: 10
      });

      expect(mockSupabase.from).toHaveBeenCalledWith('api_queue');
    });

    it('should clamp priority to valid range (1-10)', async () => {
      mockSupabase._setResponse({ id: 'request-123' });

      // Priority above 10 should be clamped to 10
      await apiQueue.enqueue({
        apiName: 'openai',
        endpoint: 'https://api.openai.com/v1/chat/completions',
        priority: 15
      });

      // Priority below 1 should be clamped to 1
      await apiQueue.enqueue({
        apiName: 'openai',
        endpoint: 'https://api.openai.com/v1/chat/completions',
        priority: -5
      });

      expect(mockSupabase.from).toHaveBeenCalledWith('api_queue');
    });

    it('should throw error on database failure', async () => {
      mockSupabase._setResponse(null, { message: 'Insert failed' });

      await expect(
        apiQueue.enqueue({
          apiName: 'openai',
          endpoint: 'https://api.openai.com/v1/chat/completions'
        })
      ).rejects.toThrow('Failed to enqueue request');
    });

    it('should accept different HTTP methods', async () => {
      const methods: Array<'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'> = [
        'GET', 'POST', 'PUT', 'DELETE', 'PATCH'
      ];

      for (const method of methods) {
        mockSupabase._setResponse({ id: `request-${method}` });

        const id = await apiQueue.enqueue({
          apiName: 'api',
          endpoint: 'https://api.example.com/resource',
          method
        });

        expect(id).toBe(`request-${method}`);
      }
    });
  });

  // ===========================================================================
  // processNext Tests
  // ===========================================================================

  describe('processNext', () => {
    it('should return null when queue is empty', async () => {
      mockSupabase._setResponse(null);

      const result = await apiQueue.processNext();

      expect(result).toBeNull();
    });

    it('should process next available request', async () => {
      const queuedRequest = {
        id: 'request-123',
        api_name: 'openai',
        endpoint: 'https://api.openai.com/v1/test',
        method: 'POST',
        payload: { test: true },
        priority: 5,
        status: 'queued',
        attemptCount: 0,
        maxAttempts: 5
      };

      mockSupabase._setResponse(queuedRequest);
      mockSupabase._setResponse(null); // Rate limit check - no limits configured

      // Mock fetch
      const fetchMock = mockFetch(() =>
        Promise.resolve(createMockFetchResponse({ success: true }))
      );

      const result = await apiQueue.processNext();

      expect(result).toBeDefined();
    });

    it('should skip requests in backoff period', async () => {
      const futureTime = new Date(Date.now() + 60000).toISOString();

      mockSupabase._setResponse({
        id: 'request-123',
        api_name: 'openai',
        backoff_until: futureTime,
        status: 'rate_limited'
      });

      // This should check backoff and skip
      const result = await apiQueue.processNext();

      // The query filters out requests in backoff, so should return null
      expect(result).toBeNull();
    });
  });

  // ===========================================================================
  // checkRateLimit Tests
  // ===========================================================================

  describe('checkRateLimit', () => {
    it('should allow when no limits configured', async () => {
      mockSupabase._setResponse(null);

      const result = await apiQueue.checkRateLimit('unknown_api');

      expect(result.allowed).toBe(true);
    });

    it('should block when minute limit exceeded', async () => {
      const limits = createMockApiRateLimit({
        requests_per_minute: 60,
        current_minute_count: 60,
        minute_reset_at: new Date(Date.now() + 30000).toISOString()
      });

      mockSupabase._setResponse(limits);

      const result = await apiQueue.checkRateLimit('openai');

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('Minute limit');
      expect(result.retryAfterSeconds).toBeDefined();
    });

    it('should block when hour limit exceeded', async () => {
      const limits = createMockApiRateLimit({
        requests_per_minute: 60,
        current_minute_count: 50,
        requests_per_hour: 100,
        current_hour_count: 100,
        hour_reset_at: new Date(Date.now() + 1800000).toISOString()
      });

      mockSupabase._setResponse(limits);

      const result = await apiQueue.checkRateLimit('openai');

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('Hour limit');
    });

    it('should block when day limit exceeded', async () => {
      const limits = createMockApiRateLimit({
        requests_per_minute: 60,
        current_minute_count: 50,
        requests_per_hour: 1000,
        current_hour_count: 500,
        requests_per_day: 5000,
        current_day_count: 5000,
        day_reset_at: new Date(Date.now() + 43200000).toISOString()
      });

      mockSupabase._setResponse(limits);

      const result = await apiQueue.checkRateLimit('openai');

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('Day limit');
    });

    it('should allow when under all limits', async () => {
      const limits = createMockApiRateLimit({
        requests_per_minute: 60,
        current_minute_count: 30,
        requests_per_hour: 1000,
        current_hour_count: 500,
        requests_per_day: 5000,
        current_day_count: 2500
      });

      mockSupabase._setResponse(limits);

      const result = await apiQueue.checkRateLimit('openai');

      expect(result.allowed).toBe(true);
    });
  });

  // ===========================================================================
  // Exponential Backoff Tests
  // ===========================================================================

  describe('Exponential Backoff', () => {
    const calculateBackoff = (attemptCount: number, baseMultiplier = 1.5, maxSeconds = 3600): number => {
      const baseDelay = 5;
      const exponentialDelay = baseDelay * Math.pow(baseMultiplier, attemptCount);
      const cappedDelay = Math.min(exponentialDelay, maxSeconds);
      const jitter = cappedDelay * 0.2 * (Math.random() * 2 - 1);
      return Math.max(1, Math.round(cappedDelay + jitter));
    };

    it('should start with base delay for first attempt', () => {
      const delay = calculateBackoff(0);
      // Base delay is 5, with +/- 20% jitter
      expect(delay).toBeGreaterThanOrEqual(4);
      expect(delay).toBeLessThanOrEqual(6);
    });

    it('should increase exponentially with attempts', () => {
      const delays = [];
      for (let i = 0; i < 5; i++) {
        // Calculate without jitter for consistent testing
        const baseDelay = 5;
        delays.push(baseDelay * Math.pow(1.5, i));
      }

      expect(delays[1]).toBeGreaterThan(delays[0]);
      expect(delays[2]).toBeGreaterThan(delays[1]);
      expect(delays[3]).toBeGreaterThan(delays[2]);
      expect(delays[4]).toBeGreaterThan(delays[3]);
    });

    it('should cap at maximum delay', () => {
      const maxSeconds = 3600;
      const delay = calculateBackoff(20, 1.5, maxSeconds);

      expect(delay).toBeLessThanOrEqual(maxSeconds * 1.2); // Including jitter
    });

    it('should add jitter to delays', () => {
      const delays = new Set<number>();

      // Run multiple times to verify jitter adds randomness
      for (let i = 0; i < 10; i++) {
        delays.add(calculateBackoff(5));
      }

      // Should have multiple different values due to jitter
      // (very unlikely to be all the same)
      expect(delays.size).toBeGreaterThanOrEqual(1);
    });
  });

  // ===========================================================================
  // Dead Letter Queue Tests
  // ===========================================================================

  describe('Dead Letter Queue', () => {
    it('should move request to dead letter after max attempts', () => {
      const request = {
        attemptCount: 5,
        maxAttempts: 5
      };

      const shouldDeadLetter = request.attemptCount >= request.maxAttempts;

      expect(shouldDeadLetter).toBe(true);
    });

    it('should not dead letter before max attempts', () => {
      const request = {
        attemptCount: 3,
        maxAttempts: 5
      };

      const shouldDeadLetter = request.attemptCount >= request.maxAttempts;

      expect(shouldDeadLetter).toBe(false);
    });

    it('should retry dead letter items', async () => {
      mockSupabase._setResponse([{ id: 'dead-1' }, { id: 'dead-2' }]);

      const count = await apiQueue.retryDeadLetters();

      expect(count).toBe(2);
    });

    it('should retry dead letters for specific API', async () => {
      mockSupabase._setResponse([{ id: 'dead-1' }]);

      const count = await apiQueue.retryDeadLetters('openai');

      expect(count).toBe(1);
    });
  });

  // ===========================================================================
  // Authentication Tests
  // ===========================================================================

  describe('Authentication Header Building', () => {
    it('should build API key auth header', () => {
      const buildAuthHeaders = (credentials: any): Record<string, string> => {
        const headers: Record<string, string> = {};

        switch (credentials.authType) {
          case 'api_key':
            const headerName = credentials.headerName || 'Authorization';
            const prefix = credentials.headerPrefix || '';
            headers[headerName] = `${prefix}${credentials.apiKey}`;
            break;
          case 'bearer':
            headers['Authorization'] = `Bearer ${credentials.accessToken || credentials.apiKey}`;
            break;
        }

        return headers;
      };

      const headers = buildAuthHeaders({
        authType: 'api_key',
        apiKey: 'test-key',
        headerName: 'X-API-Key'
      });

      expect(headers['X-API-Key']).toBe('test-key');
    });

    it('should build bearer auth header', () => {
      const buildAuthHeaders = (credentials: any): Record<string, string> => {
        const headers: Record<string, string> = {};

        if (credentials.authType === 'bearer') {
          headers['Authorization'] = `Bearer ${credentials.accessToken || credentials.apiKey}`;
        }

        return headers;
      };

      const headers = buildAuthHeaders({
        authType: 'bearer',
        accessToken: 'token-123'
      });

      expect(headers['Authorization']).toBe('Bearer token-123');
    });

    it('should build basic auth header', () => {
      const buildAuthHeaders = (credentials: any): Record<string, string> => {
        const headers: Record<string, string> = {};

        if (credentials.authType === 'basic' && credentials.apiKey && credentials.apiSecret) {
          const encoded = Buffer.from(`${credentials.apiKey}:${credentials.apiSecret}`).toString('base64');
          headers['Authorization'] = `Basic ${encoded}`;
        }

        return headers;
      };

      const headers = buildAuthHeaders({
        authType: 'basic',
        apiKey: 'user',
        apiSecret: 'pass'
      });

      expect(headers['Authorization']).toBe(`Basic ${Buffer.from('user:pass').toString('base64')}`);
    });

    it('should support custom header names and prefixes', () => {
      const buildAuthHeaders = (credentials: any): Record<string, string> => {
        const headers: Record<string, string> = {};

        if (credentials.authType === 'custom' && credentials.headerName && credentials.apiKey) {
          const prefix = credentials.headerPrefix || '';
          headers[credentials.headerName] = `${prefix}${credentials.apiKey}`;
        }

        return headers;
      };

      const headers = buildAuthHeaders({
        authType: 'custom',
        apiKey: 'my-token',
        headerName: 'X-Printify-Token',
        headerPrefix: ''
      });

      expect(headers['X-Printify-Token']).toBe('my-token');
    });
  });

  // ===========================================================================
  // getStats Tests
  // ===========================================================================

  describe('getStats', () => {
    it('should return queue statistics', async () => {
      mockSupabase._setResponse([
        { status: 'queued' },
        { status: 'queued' },
        { status: 'processing' },
        { status: 'rate_limited' },
        { status: 'dead_letter' },
        { status: 'completed' }
      ]);

      const stats = await apiQueue.getStats();

      expect(stats.queued).toBe(2);
      expect(stats.processing).toBe(1);
      expect(stats.rateLimited).toBe(1);
      expect(stats.deadLetter).toBe(1);
    });

    it('should handle empty queue', async () => {
      mockSupabase._setResponse([]);

      const stats = await apiQueue.getStats();

      expect(stats.queued).toBe(0);
      expect(stats.processing).toBe(0);
      expect(stats.rateLimited).toBe(0);
      expect(stats.deadLetter).toBe(0);
    });
  });

  // ===========================================================================
  // cleanup Tests
  // ===========================================================================

  describe('cleanup', () => {
    it('should delete old completed requests', async () => {
      mockSupabase._setResponse([
        { id: 'old-1' },
        { id: 'old-2' },
        { id: 'old-3' }
      ]);

      const count = await apiQueue.cleanup(7);

      expect(count).toBe(3);
    });

    it('should use default 7 day retention', async () => {
      mockSupabase._setResponse([]);

      const count = await apiQueue.cleanup();

      expect(count).toBe(0);
    });
  });

  // ===========================================================================
  // Processing Control Tests
  // ===========================================================================

  describe('Processing Control', () => {
    it('should start processing interval', () => {
      apiQueue.startProcessing(1000);

      // Should not throw when called multiple times
      apiQueue.startProcessing(1000);

      apiQueue.stopProcessing();
    });

    it('should stop processing interval', () => {
      apiQueue.startProcessing(1000);
      apiQueue.stopProcessing();

      // Should not throw when stopped multiple times
      apiQueue.stopProcessing();
    });
  });

  // ===========================================================================
  // Credential Caching Tests
  // ===========================================================================

  describe('Credential Caching', () => {
    it('should invalidate credentials', () => {
      // This tests the public method
      apiQueue.invalidateCredentials('openai');

      // Should not throw
      expect(true).toBe(true);
    });
  });

  // ===========================================================================
  // Rate Limit Counter Reset Tests
  // ===========================================================================

  describe('Rate Limit Counter Reset', () => {
    it('should reset minute counter when period elapsed', () => {
      const now = new Date();
      const pastResetTime = new Date(now.getTime() - 60000); // 1 minute ago

      const shouldReset = new Date(pastResetTime) < now;

      expect(shouldReset).toBe(true);
    });

    it('should not reset counter before period elapsed', () => {
      const now = new Date();
      const futureResetTime = new Date(now.getTime() + 30000); // 30 seconds from now

      const shouldReset = new Date(futureResetTime) < now;

      expect(shouldReset).toBe(false);
    });

    it('should reset all expired counters', () => {
      const now = new Date();

      const counters = {
        minute: {
          resetAt: new Date(now.getTime() - 60000),
          count: 50
        },
        hour: {
          resetAt: new Date(now.getTime() + 1800000), // Not expired
          count: 500
        },
        day: {
          resetAt: new Date(now.getTime() - 86400000), // Expired
          count: 5000
        }
      };

      const updates: Record<string, number> = {};

      if (counters.minute.resetAt < now) {
        updates.minute = 0;
      }
      if (counters.hour.resetAt < now) {
        updates.hour = 0;
      }
      if (counters.day.resetAt < now) {
        updates.day = 0;
      }

      expect(updates.minute).toBe(0);
      expect(updates.hour).toBeUndefined();
      expect(updates.day).toBe(0);
    });
  });

  // ===========================================================================
  // HTTP Response Handling Tests
  // ===========================================================================

  describe('HTTP Response Handling', () => {
    it('should detect rate limiting from 429 response', () => {
      const response = { status: 429, ok: false };
      const isRateLimited = response.status === 429;

      expect(isRateLimited).toBe(true);
    });

    it('should detect auth errors from 401 response', () => {
      const response = { status: 401, ok: false };
      const isAuthError = response.status === 401 || response.status === 403;

      expect(isAuthError).toBe(true);
    });

    it('should parse Retry-After header', () => {
      const headers = {
        'Retry-After': '60'
      };

      const retryAfter = parseInt(headers['Retry-After'] || '60');

      expect(retryAfter).toBe(60);
    });
  });
});
