/**
 * ============================================================================
 * RATE LIMITER TEST SUITE
 * ============================================================================
 *
 * Tests for Safeguard #1: Rate Limiter with Anti-Suspension Controls
 */

import { describe, it, expect, beforeEach, vi, afterEach, Mock } from 'vitest';
import { RateLimiter } from '../rate-limiter';
import { createMockSupabaseClient, createMockPlatformConfig, MockSupabaseClient } from './test-utils';

// Mock Supabase module
vi.mock('@supabase/supabase-js', () => {
  const mockClient = createMockSupabaseClient();
  return {
    createClient: vi.fn(() => mockClient),
    _getMockClient: () => mockClient
  };
});

describe('Safeguard #1: Rate Limiter', () => {
  let rateLimiter: RateLimiter;
  let mockSupabase: MockSupabaseClient;

  beforeEach(() => {
    vi.clearAllMocks();
    mockSupabase = createMockSupabaseClient();

    // Re-mock createClient to return our mock
    const supabaseModule = require('@supabase/supabase-js');
    supabaseModule.createClient.mockReturnValue(mockSupabase);

    rateLimiter = new RateLimiter('https://test.supabase.co', 'test-key');
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // checkUploadAllowed Tests
  // ===========================================================================

  describe('checkUploadAllowed', () => {
    it('should return not allowed when platform is not configured', async () => {
      mockSupabase._setResponse(null, { message: 'Not found' });

      const result = await rateLimiter.checkUploadAllowed('unknown_platform', 'product-123');

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('not configured');
      expect(result.requiresHumanReview).toBe(true);
    });

    it('should return allowed when within rate limits', async () => {
      const platformConfig = createMockPlatformConfig({
        platform: 'printify',
        max_uploads_per_day: 10,
        max_uploads_per_hour: 5,
        require_human_review: false
      });

      // First call returns platform config
      mockSupabase._setResponse(platformConfig);

      // Mock RPC call for rate limit check
      mockSupabase._setRpcResponse([{
        allowed: true,
        reason: 'OK',
        next_allowed_at: null,
        current_hour_count: 2,
        current_day_count: 3
      }]);

      const result = await rateLimiter.checkUploadAllowed('printify', 'product-123');

      expect(result.allowed).toBe(true);
      expect(result.reason).toBe('OK');
      expect(result.currentHourCount).toBe(2);
      expect(result.currentDayCount).toBe(3);
      expect(result.requiresHumanReview).toBe(false);
    });

    it('should return not allowed when daily limit exceeded', async () => {
      const platformConfig = createMockPlatformConfig({
        platform: 'printify',
        max_uploads_per_day: 5,
        require_human_review: false
      });

      mockSupabase._setResponse(platformConfig);

      const nextAllowedAt = new Date(Date.now() + 86400000).toISOString();
      mockSupabase._setRpcResponse([{
        allowed: false,
        reason: 'Daily limit reached (5)',
        next_allowed_at: nextAllowedAt,
        current_hour_count: 5,
        current_day_count: 5
      }]);

      const result = await rateLimiter.checkUploadAllowed('printify', 'product-123');

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('Daily limit');
      expect(result.currentDayCount).toBe(5);
      expect(result.nextAllowedAt).toBeDefined();
    });

    it('should return not allowed when hourly limit exceeded', async () => {
      const platformConfig = createMockPlatformConfig({
        platform: 'printify',
        max_uploads_per_hour: 3,
        require_human_review: false
      });

      mockSupabase._setResponse(platformConfig);

      const nextAllowedAt = new Date(Date.now() + 3600000).toISOString();
      mockSupabase._setRpcResponse([{
        allowed: false,
        reason: 'Hourly limit reached (3)',
        next_allowed_at: nextAllowedAt,
        current_hour_count: 3,
        current_day_count: 3
      }]);

      const result = await rateLimiter.checkUploadAllowed('printify', 'product-123');

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('Hourly limit');
      expect(result.currentHourCount).toBe(3);
    });

    it('should fail closed on database error', async () => {
      const platformConfig = createMockPlatformConfig();
      mockSupabase._setResponse(platformConfig);
      mockSupabase._setRpcResponse(null, { message: 'Database connection error' });

      const result = await rateLimiter.checkUploadAllowed('printify', 'product-123');

      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('Database error');
      expect(result.requiresHumanReview).toBe(true);
    });

    it('should add jitter delay to allowed uploads', async () => {
      const platformConfig = createMockPlatformConfig({
        jitter_min_seconds: 60,
        jitter_max_seconds: 300
      });

      mockSupabase._setResponse(platformConfig);
      mockSupabase._setRpcResponse([{
        allowed: true,
        reason: 'OK',
        next_allowed_at: null,
        current_hour_count: 0,
        current_day_count: 0
      }]);

      const result = await rateLimiter.checkUploadAllowed('printify', 'product-123');

      expect(result.allowed).toBe(true);
      expect(result.waitMs).toBeGreaterThanOrEqual(60 * 1000);
      expect(result.waitMs).toBeLessThanOrEqual(300 * 1000);
    });

    it('should flag high-risk platforms for human review', async () => {
      const platformConfig = createMockPlatformConfig({
        platform: 'amazon_kdp',
        require_human_review: true,
        suspension_risk_level: 'critical'
      });

      mockSupabase._setResponse(platformConfig);
      mockSupabase._setRpcResponse([{
        allowed: true,
        reason: 'OK',
        next_allowed_at: null,
        current_hour_count: 0,
        current_day_count: 0
      }]);

      const result = await rateLimiter.checkUploadAllowed('amazon_kdp', 'product-123');

      expect(result.requiresHumanReview).toBe(true);
    });
  });

  // ===========================================================================
  // recordUploadStart Tests
  // ===========================================================================

  describe('recordUploadStart', () => {
    it('should record upload start event', async () => {
      const uploadEvent = {
        id: 'upload-123',
        platform: 'printify',
        product_id: 'product-123',
        upload_status: 'in_progress',
        started_at: new Date().toISOString()
      };

      mockSupabase._setResponse(uploadEvent);

      const result = await rateLimiter.recordUploadStart('printify', 'product-123');

      expect(result.id).toBe('upload-123');
      expect(result.platform).toBe('printify');
      expect(result.upload_status).toBe('in_progress');
      expect(mockSupabase.from).toHaveBeenCalledWith('upload_events');
    });

    it('should throw error on database failure', async () => {
      mockSupabase._setResponse(null, { message: 'Insert failed' });

      await expect(
        rateLimiter.recordUploadStart('printify', 'product-123')
      ).rejects.toThrow('Failed to record upload start');
    });
  });

  // ===========================================================================
  // recordUploadComplete Tests
  // ===========================================================================

  describe('recordUploadComplete', () => {
    it('should record successful upload completion', async () => {
      // Mock getting upload event to find platform
      mockSupabase._setResponse({ platform: 'printify' });

      await rateLimiter.recordUploadComplete('upload-123', 'success');

      expect(mockSupabase.from).toHaveBeenCalledWith('upload_events');
    });

    it('should record failed upload completion', async () => {
      mockSupabase._setResponse({ platform: 'printify' });

      await rateLimiter.recordUploadComplete('upload-123', 'failed', 'API error');

      expect(mockSupabase.from).toHaveBeenCalledWith('upload_events');
    });

    it('should trigger suspension alert when status is suspended', async () => {
      mockSupabase._setResponse({ platform: 'printify', product_id: 'product-123' });

      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      await rateLimiter.recordUploadComplete('upload-123', 'suspended', 'Account blocked');

      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('SUSPENSION ALERT')
      );

      consoleSpy.mockRestore();
    });
  });

  // ===========================================================================
  // getDelayBeforeUpload Tests
  // ===========================================================================

  describe('getDelayBeforeUpload', () => {
    it('should return default delay when platform not configured', async () => {
      mockSupabase._setResponse(null);

      const delay = await rateLimiter.getDelayBeforeUpload('unknown_platform');

      expect(delay).toBe(60000); // Default 1 minute
    });

    it('should calculate delay based on last upload', async () => {
      const platformConfig = createMockPlatformConfig({
        jitter_min_seconds: 30,
        jitter_max_seconds: 60
      });

      // Mock platform config fetch
      mockSupabase._setResponse(platformConfig);

      // Mock last upload event - next allowed in 10 seconds
      const nextAllowed = new Date(Date.now() + 10000).toISOString();
      mockSupabase._setResponse({ next_allowed_upload_at: nextAllowed });

      const delay = await rateLimiter.getDelayBeforeUpload('printify');

      // Should be at least 10 seconds + jitter
      expect(delay).toBeGreaterThanOrEqual(10000);
    });

    it('should return only jitter when no recent uploads', async () => {
      const platformConfig = createMockPlatformConfig({
        jitter_min_seconds: 30,
        jitter_max_seconds: 60
      });

      mockSupabase._setResponse(platformConfig);

      // No recent uploads
      mockSupabase._setResponse(null);

      const delay = await rateLimiter.getDelayBeforeUpload('printify');

      expect(delay).toBeGreaterThanOrEqual(30000);
      expect(delay).toBeLessThanOrEqual(60000);
    });
  });

  // ===========================================================================
  // requiresHumanReview Tests
  // ===========================================================================

  describe('requiresHumanReview', () => {
    it('should return true for platforms requiring review', async () => {
      mockSupabase._setResponse(createMockPlatformConfig({
        require_human_review: true
      }));

      const result = await rateLimiter.requiresHumanReview('amazon_kdp');

      expect(result).toBe(true);
    });

    it('should return false for platforms not requiring review', async () => {
      mockSupabase._setResponse(createMockPlatformConfig({
        require_human_review: false
      }));

      const result = await rateLimiter.requiresHumanReview('printify');

      expect(result).toBe(false);
    });

    it('should default to true when platform not found', async () => {
      mockSupabase._setResponse(null);

      const result = await rateLimiter.requiresHumanReview('unknown');

      expect(result).toBe(true);
    });
  });

  // ===========================================================================
  // getSuspensionRiskLevel Tests
  // ===========================================================================

  describe('getSuspensionRiskLevel', () => {
    it('should return correct risk level for platform', async () => {
      mockSupabase._setResponse(createMockPlatformConfig({
        suspension_risk_level: 'critical'
      }));

      const result = await rateLimiter.getSuspensionRiskLevel('amazon_kdp');

      expect(result).toBe('critical');
    });

    it('should default to high when platform not found', async () => {
      mockSupabase._setResponse(null);

      const result = await rateLimiter.getSuspensionRiskLevel('unknown');

      expect(result).toBe('high');
    });
  });

  // ===========================================================================
  // getDailyStats Tests
  // ===========================================================================

  describe('getDailyStats', () => {
    it('should return correct daily statistics', async () => {
      const platformConfig = createMockPlatformConfig({
        max_uploads_per_day: 10
      });

      mockSupabase._setResponse(platformConfig);

      // Mock upload events for today
      mockSupabase._setResponse([
        { upload_status: 'success' },
        { upload_status: 'success' },
        { upload_status: 'failed' },
        { upload_status: 'success' }
      ]);

      const stats = await rateLimiter.getDailyStats('printify');

      expect(stats.uploadsToday).toBe(4);
      expect(stats.successRate).toBe(0.75);
      expect(stats.remainingDaily).toBe(6);
    });

    it('should handle empty stats', async () => {
      mockSupabase._setResponse(createMockPlatformConfig({ max_uploads_per_day: 10 }));
      mockSupabase._setResponse([]);

      const stats = await rateLimiter.getDailyStats('printify');

      expect(stats.uploadsToday).toBe(0);
      expect(stats.successRate).toBe(0);
      expect(stats.remainingDaily).toBe(10);
    });
  });

  // ===========================================================================
  // Caching Tests
  // ===========================================================================

  describe('Config Caching', () => {
    it('should cache platform config', async () => {
      const platformConfig = createMockPlatformConfig();
      mockSupabase._setResponse(platformConfig);
      mockSupabase._setRpcResponse([{
        allowed: true,
        reason: 'OK',
        next_allowed_at: null,
        current_hour_count: 0,
        current_day_count: 0
      }]);

      // First call - should fetch from database
      await rateLimiter.checkUploadAllowed('printify', 'product-1');

      // Second call - should use cache
      await rateLimiter.checkUploadAllowed('printify', 'product-2');

      // from() should be called for initial config fetch
      // The cache prevents additional calls to platform_rate_limits
      expect(mockSupabase.from).toHaveBeenCalled();
    });
  });

  // ===========================================================================
  // Jitter Calculation Tests
  // ===========================================================================

  describe('Jitter Calculation', () => {
    it('should calculate jitter within specified bounds', () => {
      // Test the jitter calculation logic directly
      const minSeconds = 60;
      const maxSeconds = 300;

      // Run multiple times to verify randomness
      for (let i = 0; i < 100; i++) {
        const minMs = minSeconds * 1000;
        const maxMs = maxSeconds * 1000;
        const jitterMs = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;

        expect(jitterMs).toBeGreaterThanOrEqual(minMs);
        expect(jitterMs).toBeLessThanOrEqual(maxMs);
      }
    });
  });

  // ===========================================================================
  // Wait Time Calculation Tests
  // ===========================================================================

  describe('Wait Time Calculation', () => {
    it('should calculate wait time correctly', () => {
      const futureTime = new Date(Date.now() + 30000).toISOString();
      const nextTime = new Date(futureTime).getTime();
      const waitMs = Math.max(0, nextTime - Date.now());

      expect(waitMs).toBeGreaterThan(0);
      expect(waitMs).toBeLessThanOrEqual(30000);
    });

    it('should return 0 for past times', () => {
      const pastTime = new Date(Date.now() - 30000).toISOString();
      const nextTime = new Date(pastTime).getTime();
      const waitMs = Math.max(0, nextTime - Date.now());

      expect(waitMs).toBe(0);
    });

    it('should return 0 for null time', () => {
      const calculateWaitMs = (nextAllowedAt: string | null): number => {
        if (!nextAllowedAt) return 0;
        const nextTime = new Date(nextAllowedAt).getTime();
        return Math.max(0, nextTime - Date.now());
      };

      expect(calculateWaitMs(null)).toBe(0);
    });
  });
});
