/**
 * ============================================================================
 * PRODUCT PERFORMANCE COMPONENT
 * Table showing top/bottom performing products
 * ============================================================================
 */

import React, { memo, useState } from 'react';
import type { ProductPerformance as ProductPerformanceData } from '../../hooks/useAnalytics';
import { PLATFORM_COLORS, formatChartValue } from '../../hooks/useChartData';

interface ProductPerformanceProps {
  products: ProductPerformanceData[];
  title?: string;
  showRank?: boolean;
  maxItems?: number;
  sortBy?: 'revenue' | 'unitsSold' | 'views' | 'conversionRate';
  className?: string;
}

type SortKey = 'revenue' | 'unitsSold' | 'views' | 'conversionRate';

/**
 * Product performance table with sorting and trend indicators
 */
export const ProductPerformance = memo(function ProductPerformance({
  products,
  title = 'Top Products',
  showRank = true,
  maxItems = 10,
  sortBy: initialSortBy = 'revenue',
  className = '',
}: ProductPerformanceProps) {
  const [sortKey, setSortKey] = useState<SortKey>(initialSortBy);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const sortedProducts = [...products]
    .sort((a, b) => {
      const aVal = a[sortKey];
      const bVal = b[sortKey];
      return sortDirection === 'desc' ? bVal - aVal : aVal - bVal;
    })
    .slice(0, maxItems);

  const handleSort = (key: SortKey) => {
    if (key === sortKey) {
      setSortDirection(prev => (prev === 'desc' ? 'asc' : 'desc'));
    } else {
      setSortKey(key);
      setSortDirection('desc');
    }
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return (
          <span className="text-green-400 text-lg" title="Trending up">
            &#9650;
          </span>
        );
      case 'down':
        return (
          <span className="text-red-400 text-lg" title="Trending down">
            &#9660;
          </span>
        );
      default:
        return (
          <span className="text-gray-400 text-lg" title="Stable">
            &#9644;
          </span>
        );
    }
  };

  const getSortIndicator = (key: SortKey) => {
    if (sortKey !== key) return null;
    return (
      <span className="ml-1 text-xs">
        {sortDirection === 'desc' ? '▼' : '▲'}
      </span>
    );
  };

  const columnHeaders: { key: SortKey; label: string }[] = [
    { key: 'revenue', label: 'Revenue' },
    { key: 'unitsSold', label: 'Units' },
    { key: 'views', label: 'Views' },
    { key: 'conversionRate', label: 'Conv. Rate' },
  ];

  if (!products || products.length === 0) {
    return (
      <div className={`flex items-center justify-center py-8 ${className}`}>
        <p className="text-gray-400">No product data available</p>
      </div>
    );
  }

  return (
    <div className={`overflow-hidden ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        <span className="text-sm text-gray-400">
          Showing {sortedProducts.length} of {products.length}
        </span>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {sortedProducts.map((product, index) => (
          <div
            key={product.id}
            className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                {showRank && (
                  <span
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      index < 3
                        ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white'
                        : 'bg-slate-700 text-gray-300'
                    }`}
                  >
                    {index + 1}
                  </span>
                )}
                <div>
                  <p className="font-medium text-white line-clamp-1">{product.title}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className="text-xs px-2 py-0.5 rounded-full"
                      style={{
                        backgroundColor: `${PLATFORM_COLORS[product.platform] || '#6b7280'}20`,
                        color: PLATFORM_COLORS[product.platform] || '#6b7280',
                      }}
                    >
                      {product.platform}
                    </span>
                    {getTrendIcon(product.trend)}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-gray-400">Revenue</p>
                <p className="font-semibold text-white">
                  {formatChartValue(product.revenue, 'currency')}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Units Sold</p>
                <p className="font-semibold text-white">{product.unitsSold}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Views</p>
                <p className="font-semibold text-white">
                  {product.views.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Conversion</p>
                <p className="font-semibold text-white">
                  {product.conversionRate.toFixed(2)}%
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-700">
              {showRank && (
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-400 w-12">
                  #
                </th>
              )}
              <th className="text-left py-3 px-4 text-sm font-medium text-gray-400">
                Product
              </th>
              <th className="text-left py-3 px-4 text-sm font-medium text-gray-400 w-24">
                Platform
              </th>
              {columnHeaders.map(col => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key)}
                  className="text-right py-3 px-4 text-sm font-medium text-gray-400 cursor-pointer hover:text-white transition-colors"
                >
                  {col.label}
                  {getSortIndicator(col.key)}
                </th>
              ))}
              <th className="text-center py-3 px-4 text-sm font-medium text-gray-400 w-16">
                Trend
              </th>
            </tr>
          </thead>
          <tbody>
            {sortedProducts.map((product, index) => (
              <tr
                key={product.id}
                className="border-b border-slate-700/50 hover:bg-slate-800/50 transition-colors"
              >
                {showRank && (
                  <td className="py-4 px-4">
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        index < 3
                          ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white'
                          : 'bg-slate-700 text-gray-300'
                      }`}
                    >
                      {index + 1}
                    </span>
                  </td>
                )}
                <td className="py-4 px-4">
                  <p
                    className="font-medium text-white truncate max-w-[200px]"
                    title={product.title}
                  >
                    {product.title}
                  </p>
                </td>
                <td className="py-4 px-4">
                  <span
                    className="text-xs px-2 py-1 rounded-full"
                    style={{
                      backgroundColor: `${PLATFORM_COLORS[product.platform] || '#6b7280'}20`,
                      color: PLATFORM_COLORS[product.platform] || '#6b7280',
                    }}
                  >
                    {product.platform}
                  </span>
                </td>
                <td className="py-4 px-4 text-right text-white font-medium">
                  {formatChartValue(product.revenue, 'currency')}
                </td>
                <td className="py-4 px-4 text-right text-gray-300">
                  {product.unitsSold}
                </td>
                <td className="py-4 px-4 text-right text-gray-300">
                  {product.views.toLocaleString()}
                </td>
                <td className="py-4 px-4 text-right text-gray-300">
                  {product.conversionRate.toFixed(2)}%
                </td>
                <td className="py-4 px-4 text-center">
                  {getTrendIcon(product.trend)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Row */}
      <div className="mt-4 pt-4 border-t border-slate-700 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center">
          <p className="text-xs text-gray-400">Total Revenue</p>
          <p className="text-lg font-semibold text-white">
            {formatChartValue(
              sortedProducts.reduce((sum, p) => sum + p.revenue, 0),
              'currency'
            )}
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400">Total Units</p>
          <p className="text-lg font-semibold text-white">
            {sortedProducts.reduce((sum, p) => sum + p.unitsSold, 0)}
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400">Total Views</p>
          <p className="text-lg font-semibold text-white">
            {sortedProducts.reduce((sum, p) => sum + p.views, 0).toLocaleString()}
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400">Avg Conversion</p>
          <p className="text-lg font-semibold text-white">
            {(
              sortedProducts.reduce((sum, p) => sum + p.conversionRate, 0) /
              sortedProducts.length
            ).toFixed(2)}
            %
          </p>
        </div>
      </div>
    </div>
  );
});

export default ProductPerformance;
