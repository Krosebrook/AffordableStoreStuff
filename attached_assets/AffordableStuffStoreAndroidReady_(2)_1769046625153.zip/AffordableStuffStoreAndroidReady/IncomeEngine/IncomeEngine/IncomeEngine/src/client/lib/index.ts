/**
 * ============================================================================
 * CLIENT LIBRARY INDEX
 * Re-exports all client utilities for convenient importing
 * ============================================================================
 *
 * Usage:
 * ```typescript
 * import { queryClient, LazyRoutes, useDebounce } from './lib';
 * ```
 */

// Query client exports
export { queryClient, QUERY_KEYS, apiFetcher, apiMutate } from './queryClient';

// Lazy routes exports
export {
  LazyRoutes,
  preloadRoute,
  preloadAllRoutes,
  preloadRoutesWhenIdle,
  PageLoadingFallback,
  DashboardSkeleton,
  ApprovalsSkeleton,
  BudgetSkeleton,
  SettingsSkeleton,
  RouteErrorFallback,
} from './lazy-routes';

// Performance exports
export {
  usePerformance,
  useRenderCount,
  useDebounce,
  useDebouncedCallback,
  useThrottle,
  useIntersectionObserver,
  reportWebVitals,
  logBundleSize,
  useWhyDidYouRender,
  getMemoryUsage,
  useMemoryMonitor,
  useDeepMemo,
  mark,
  measure,
  useLifecycleTiming,
  type PerformanceMetrics,
  type WebVitalsMetric,
  type WebVitalsReporter,
} from './performance';

// Responsive utilities
export {
  BREAKPOINTS,
  isBreakpoint,
  getCurrentBreakpoint,
  isMobileViewport,
  isTabletViewport,
  isDesktopViewport,
  DeviceDetection,
  createMediaQueryListener,
  createBreakpointListener,
  type Breakpoint,
} from './responsive';

// Safe area utilities
export {
  getSafeAreaInsets,
  applySafeAreaProperties,
  getStatusBarHeight,
  getHomeIndicatorHeight,
  SafeAreaClasses,
  initializeSafeArea,
  type SafeAreaInsets,
} from './safe-area';
