import React, { memo } from 'react';

type StatusType = 'ok' | 'warning' | 'error';

interface StatusBadgeProps {
  status: StatusType;
  pulse?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const sizeClasses = {
  sm: 'w-2 h-2',
  md: 'w-3 h-3',
  lg: 'w-4 h-4'
};

const colorClasses = {
  ok: 'bg-green-500',
  warning: 'bg-yellow-500',
  error: 'bg-red-500'
};

/**
 * Status indicator badge with configurable size and color
 */
export const StatusBadge = memo(function StatusBadge({
  status,
  pulse = true,
  size = 'md'
}: StatusBadgeProps) {
  return (
    <span
      className={`
        inline-block rounded-full
        ${sizeClasses[size]}
        ${colorClasses[status]}
        ${pulse ? 'animate-pulse' : ''}
      `}
      role="status"
      aria-label={`Status: ${status}`}
    />
  );
});

export default StatusBadge;
