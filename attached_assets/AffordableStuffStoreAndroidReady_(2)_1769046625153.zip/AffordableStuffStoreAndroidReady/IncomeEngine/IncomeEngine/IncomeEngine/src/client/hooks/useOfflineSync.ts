import { useState, useEffect, useCallback, useRef } from 'react';
import { useQueryClient } from '@tanstack/react-query';

import { useNetworkStatus } from './useNetworkStatus';

/**
 * Queued action for offline sync
 */
interface QueuedAction {
  id: string;
  type: 'approve' | 'reject' | 'custom';
  endpoint: string;
  method: 'POST' | 'PUT' | 'DELETE';
  payload?: Record<string, unknown>;
  createdAt: number;
  retryCount: number;
}

/**
 * Offline sync state
 */
interface OfflineSyncState {
  /** Whether there are pending actions to sync */
  hasPendingActions: boolean;
  /** Number of pending actions */
  pendingCount: number;
  /** Whether currently syncing */
  isSyncing: boolean;
  /** Last sync error if any */
  lastError: string | null;
  /** Queue an action for offline sync */
  queueAction: (action: Omit<QueuedAction, 'id' | 'createdAt' | 'retryCount'>) => void;
  /** Manually trigger sync */
  syncNow: () => Promise<void>;
  /** Clear all pending actions */
  clearQueue: () => void;
}

const STORAGE_KEY = 'income_engine_offline_queue';
const MAX_RETRIES = 3;

/**
 * Load queue from localStorage
 */
function loadQueue(): QueuedAction[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

/**
 * Save queue to localStorage
 */
function saveQueue(queue: QueuedAction[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(queue));
  } catch (e) {
    console.error('Failed to save offline queue:', e);
  }
}

/**
 * Generate unique ID for queue items
 */
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Hook for offline data synchronization
 * Queues actions when offline and syncs when back online
 */
export function useOfflineSync(): OfflineSyncState {
  const { isOnline } = useNetworkStatus();
  const queryClient = useQueryClient();

  const [queue, setQueue] = useState<QueuedAction[]>(() => loadQueue());
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);

  const isSyncingRef = useRef(false);

  // Save queue to localStorage whenever it changes
  useEffect(() => {
    saveQueue(queue);
  }, [queue]);

  /**
   * Queue an action for later sync
   */
  const queueAction = useCallback(
    (action: Omit<QueuedAction, 'id' | 'createdAt' | 'retryCount'>) => {
      const newAction: QueuedAction = {
        ...action,
        id: generateId(),
        createdAt: Date.now(),
        retryCount: 0,
      };

      setQueue((prev) => [...prev, newAction]);
    },
    []
  );

  /**
   * Process a single queued action
   */
  const processAction = async (action: QueuedAction): Promise<boolean> => {
    try {
      const response = await fetch(action.endpoint, {
        method: action.method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: action.payload ? JSON.stringify(action.payload) : undefined,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return true;
    } catch (error) {
      console.error('Failed to sync action:', action.id, error);
      return false;
    }
  };

  /**
   * Sync all pending actions
   */
  const syncNow = useCallback(async () => {
    if (isSyncingRef.current || queue.length === 0 || !isOnline) {
      return;
    }

    isSyncingRef.current = true;
    setIsSyncing(true);
    setLastError(null);

    const failedActions: QueuedAction[] = [];
    const successfulIds: string[] = [];

    for (const action of queue) {
      const success = await processAction(action);

      if (success) {
        successfulIds.push(action.id);
      } else {
        // Increment retry count and keep in queue if under max retries
        if (action.retryCount < MAX_RETRIES) {
          failedActions.push({
            ...action,
            retryCount: action.retryCount + 1,
          });
        } else {
          console.warn('Max retries reached for action:', action.id);
          setLastError(`Action ${action.type} failed after ${MAX_RETRIES} retries`);
        }
      }
    }

    // Update queue with remaining failed actions
    setQueue(failedActions);

    // Invalidate queries to refresh data after sync
    if (successfulIds.length > 0) {
      queryClient.invalidateQueries({ queryKey: ['approvals'] });
      queryClient.invalidateQueries({ queryKey: ['systemStatus'] });
    }

    isSyncingRef.current = false;
    setIsSyncing(false);
  }, [queue, isOnline, queryClient]);

  /**
   * Clear all pending actions
   */
  const clearQueue = useCallback(() => {
    setQueue([]);
    setLastError(null);
  }, []);

  // Auto-sync when coming back online
  useEffect(() => {
    if (isOnline && queue.length > 0 && !isSyncingRef.current) {
      // Small delay to allow network to stabilize
      const timeout = setTimeout(syncNow, 1000);
      return () => clearTimeout(timeout);
    }
  }, [isOnline, queue.length, syncNow]);

  return {
    hasPendingActions: queue.length > 0,
    pendingCount: queue.length,
    isSyncing,
    lastError,
    queueAction,
    syncNow,
    clearQueue,
  };
}

/**
 * Helper hook for approval actions with offline support
 */
export function useOfflineApproval() {
  const { isOnline } = useNetworkStatus();
  const { queueAction } = useOfflineSync();

  const approve = useCallback(
    async (id: string, notes?: string) => {
      if (isOnline) {
        // Direct API call when online
        const response = await fetch(`/api/approvals/${id}/approve`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ notes }),
        });
        return response.ok;
      } else {
        // Queue for later when offline
        queueAction({
          type: 'approve',
          endpoint: `/api/approvals/${id}/approve`,
          method: 'POST',
          payload: { notes },
        });
        return true; // Optimistic success
      }
    },
    [isOnline, queueAction]
  );

  const reject = useCallback(
    async (id: string, reason: string) => {
      if (isOnline) {
        const response = await fetch(`/api/approvals/${id}/reject`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reason }),
        });
        return response.ok;
      } else {
        queueAction({
          type: 'reject',
          endpoint: `/api/approvals/${id}/reject`,
          method: 'POST',
          payload: { reason },
        });
        return true;
      }
    },
    [isOnline, queueAction]
  );

  return { approve, reject, isOnline };
}

export default useOfflineSync;
