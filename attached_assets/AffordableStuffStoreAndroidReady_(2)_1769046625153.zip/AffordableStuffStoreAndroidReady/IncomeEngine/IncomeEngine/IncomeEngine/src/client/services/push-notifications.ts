/**
 * Push notification service
 * Handles FCM/APNs setup and notification delivery
 */

import { DeviceDetection } from '../lib/responsive';

/**
 * Notification types for the app
 */
export type NotificationType =
  | 'approval_needed'
  | 'budget_warning'
  | 'budget_exceeded'
  | 'circuit_breaker_open'
  | 'sync_complete'
  | 'error'
  | 'info';

/**
 * Notification configuration
 */
interface NotificationConfig {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  tag?: string;
  data?: Record<string, unknown>;
  silent?: boolean;
  vibrate?: number[];
  requireInteraction?: boolean;
}

/**
 * Default notification icons
 */
const DEFAULT_ICONS: Record<NotificationType, string> = {
  approval_needed: '/icons/approval.png',
  budget_warning: '/icons/warning.png',
  budget_exceeded: '/icons/alert.png',
  circuit_breaker_open: '/icons/circuit.png',
  sync_complete: '/icons/sync.png',
  error: '/icons/error.png',
  info: '/icons/info.png',
};

/**
 * Default vibration patterns
 */
const VIBRATION_PATTERNS: Record<NotificationType, number[]> = {
  approval_needed: [100, 50, 100],
  budget_warning: [200, 100, 200],
  budget_exceeded: [300, 100, 300, 100, 300],
  circuit_breaker_open: [500, 200, 500],
  sync_complete: [50],
  error: [200, 100, 200],
  info: [100],
};

/**
 * Push notification service class
 */
class PushNotificationService {
  private swRegistration: ServiceWorkerRegistration | null = null;
  private vapidPublicKey: string;

  constructor() {
    this.vapidPublicKey = import.meta.env.VITE_VAPID_PUBLIC_KEY || '';
  }

  /**
   * Initialize the push notification service
   */
  async initialize(): Promise<void> {
    if (!this.isSupported()) {
      console.warn('Push notifications not supported');
      return;
    }

    try {
      // Wait for service worker to be ready
      this.swRegistration = await navigator.serviceWorker.ready;
      console.log('Push notification service initialized');
    } catch (error) {
      console.error('Failed to initialize push notifications:', error);
    }
  }

  /**
   * Check if push notifications are supported
   */
  isSupported(): boolean {
    return (
      'serviceWorker' in navigator &&
      'PushManager' in window &&
      'Notification' in window
    );
  }

  /**
   * Check if permission is granted
   */
  isPermissionGranted(): boolean {
    return Notification.permission === 'granted';
  }

  /**
   * Request notification permission
   */
  async requestPermission(): Promise<NotificationPermission> {
    if (!this.isSupported()) {
      return 'denied';
    }

    return Notification.requestPermission();
  }

  /**
   * Get current push subscription
   */
  async getSubscription(): Promise<PushSubscription | null> {
    if (!this.swRegistration) {
      await this.initialize();
    }

    if (!this.swRegistration) return null;

    return this.swRegistration.pushManager.getSubscription();
  }

  /**
   * Subscribe to push notifications
   */
  async subscribe(): Promise<PushSubscription | null> {
    if (!this.swRegistration || !this.vapidPublicKey) {
      console.warn('Service worker or VAPID key not available');
      return null;
    }

    try {
      const subscription = await this.swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(this.vapidPublicKey),
      });

      // Send subscription to backend
      await this.sendSubscriptionToServer(subscription);

      return subscription;
    } catch (error) {
      console.error('Failed to subscribe to push:', error);
      return null;
    }
  }

  /**
   * Unsubscribe from push notifications
   */
  async unsubscribe(): Promise<boolean> {
    const subscription = await this.getSubscription();
    if (!subscription) return true;

    try {
      const success = await subscription.unsubscribe();
      if (success) {
        await this.removeSubscriptionFromServer(subscription);
      }
      return success;
    } catch (error) {
      console.error('Failed to unsubscribe:', error);
      return false;
    }
  }

  /**
   * Show a local notification
   */
  async showNotification(
    type: NotificationType,
    config: Partial<NotificationConfig>
  ): Promise<void> {
    if (!this.isPermissionGranted()) {
      console.warn('Notification permission not granted');
      return;
    }

    const fullConfig: NotificationConfig = {
      title: config.title || 'Income Engine',
      body: config.body || '',
      icon: config.icon || DEFAULT_ICONS[type] || '/icons/icon-192.png',
      badge: config.badge || '/icons/badge-72.png',
      tag: config.tag || type,
      data: { type, ...config.data },
      silent: config.silent ?? false,
      vibrate: config.vibrate || VIBRATION_PATTERNS[type],
      requireInteraction: config.requireInteraction ?? type.includes('exceeded'),
    };

    if (this.swRegistration) {
      await this.swRegistration.showNotification(fullConfig.title, {
        body: fullConfig.body,
        icon: fullConfig.icon,
        badge: fullConfig.badge,
        tag: fullConfig.tag,
        data: fullConfig.data,
        silent: fullConfig.silent,
        vibrate: fullConfig.vibrate,
        requireInteraction: fullConfig.requireInteraction,
      });
    } else {
      // Fallback for when service worker isn't available
      new Notification(fullConfig.title, {
        body: fullConfig.body,
        icon: fullConfig.icon,
        tag: fullConfig.tag,
        data: fullConfig.data,
        silent: fullConfig.silent,
      });
    }
  }

  /**
   * Show approval needed notification
   */
  async notifyApprovalNeeded(count: number): Promise<void> {
    await this.showNotification('approval_needed', {
      title: 'Approvals Needed',
      body: `You have ${count} product${count === 1 ? '' : 's'} waiting for approval`,
      data: { count },
    });
  }

  /**
   * Show budget warning notification
   */
  async notifyBudgetWarning(period: string, percentUsed: number): Promise<void> {
    await this.showNotification('budget_warning', {
      title: 'Budget Warning',
      body: `Your ${period} budget is at ${percentUsed.toFixed(0)}%`,
      data: { period, percentUsed },
    });
  }

  /**
   * Show budget exceeded notification
   */
  async notifyBudgetExceeded(period: string): Promise<void> {
    await this.showNotification('budget_exceeded', {
      title: 'Budget Exceeded',
      body: `Your ${period} budget limit has been reached. Publishing paused.`,
      data: { period },
      requireInteraction: true,
    });
  }

  /**
   * Show circuit breaker notification
   */
  async notifyCircuitBreakerOpen(breakerName: string, reason: string): Promise<void> {
    await this.showNotification('circuit_breaker_open', {
      title: 'Circuit Breaker Triggered',
      body: `${breakerName}: ${reason}`,
      data: { breakerName, reason },
      requireInteraction: true,
    });
  }

  /**
   * Send subscription to server
   */
  private async sendSubscriptionToServer(
    subscription: PushSubscription
  ): Promise<void> {
    try {
      await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subscription: subscription.toJSON(),
          platform: DeviceDetection.getPlatform(),
          userAgent: navigator.userAgent,
        }),
      });
    } catch (error) {
      console.error('Failed to send subscription to server:', error);
    }
  }

  /**
   * Remove subscription from server
   */
  private async removeSubscriptionFromServer(
    subscription: PushSubscription
  ): Promise<void> {
    try {
      await fetch('/api/push/unsubscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint: subscription.endpoint }),
      });
    } catch (error) {
      console.error('Failed to remove subscription from server:', error);
    }
  }

  /**
   * Convert VAPID key to Uint8Array
   */
  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }
}

// Export singleton instance
export const pushNotificationService = new PushNotificationService();
export default pushNotificationService;
