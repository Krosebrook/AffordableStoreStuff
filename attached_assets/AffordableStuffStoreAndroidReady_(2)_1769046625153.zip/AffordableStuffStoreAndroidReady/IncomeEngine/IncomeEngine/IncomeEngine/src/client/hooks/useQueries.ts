import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { QUERY_KEYS, apiFetcher, apiMutate } from '../lib/queryClient';
import type { SystemStatus, PendingApproval } from '../types';

/**
 * Hook for fetching system status with caching
 */
export function useSystemStatusQuery() {
  return useQuery({
    queryKey: QUERY_KEYS.systemStatus,
    queryFn: () => apiFetcher<SystemStatus>('/api/status'),
    staleTime: 30 * 1000, // 30 seconds for real-time dashboard
    refetchInterval: 30 * 1000, // Auto-refresh every 30s
  });
}

/**
 * Hook for fetching pending approvals
 */
export function useApprovalsQuery() {
  return useQuery({
    queryKey: QUERY_KEYS.approvalsQueue,
    queryFn: async () => {
      const data = await apiFetcher<{ pending: PendingApproval[] }>('/api/approvals');
      return data.pending || [];
    },
    staleTime: 60 * 1000, // 1 minute
  });
}

/**
 * Hook for approving a product (with optimistic update)
 */
export function useApproveProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, notes }: { id: string; notes?: string }) => {
      return apiMutate(`/api/approvals/${id}/approve`, 'POST', { notes });
    },

    // Optimistic update
    onMutate: async ({ id }) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey: QUERY_KEYS.approvalsQueue });

      // Snapshot the previous value
      const previousApprovals = queryClient.getQueryData<PendingApproval[]>(
        QUERY_KEYS.approvalsQueue
      );

      // Optimistically remove the item
      queryClient.setQueryData<PendingApproval[]>(QUERY_KEYS.approvalsQueue, (old) =>
        old?.filter((item) => item.id !== id) ?? []
      );

      return { previousApprovals };
    },

    // Rollback on error
    onError: (err, variables, context) => {
      if (context?.previousApprovals) {
        queryClient.setQueryData(QUERY_KEYS.approvalsQueue, context.previousApprovals);
      }
    },

    // Refetch on success
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.approvalsQueue });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.systemStatus });
    },
  });
}

/**
 * Hook for rejecting a product (with optimistic update)
 */
export function useRejectProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      return apiMutate(`/api/approvals/${id}/reject`, 'POST', { reason });
    },

    // Optimistic update
    onMutate: async ({ id }) => {
      await queryClient.cancelQueries({ queryKey: QUERY_KEYS.approvalsQueue });

      const previousApprovals = queryClient.getQueryData<PendingApproval[]>(
        QUERY_KEYS.approvalsQueue
      );

      queryClient.setQueryData<PendingApproval[]>(QUERY_KEYS.approvalsQueue, (old) =>
        old?.filter((item) => item.id !== id) ?? []
      );

      return { previousApprovals };
    },

    onError: (err, variables, context) => {
      if (context?.previousApprovals) {
        queryClient.setQueryData(QUERY_KEYS.approvalsQueue, context.previousApprovals);
      }
    },

    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.approvalsQueue });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.systemStatus });
    },
  });
}

/**
 * Hook for fetching providers status
 */
export function useProvidersQuery() {
  return useQuery({
    queryKey: QUERY_KEYS.providers,
    queryFn: () => apiFetcher('/api/providers'),
    staleTime: 60 * 1000,
  });
}

/**
 * Hook for fetching queue stats
 */
export function useQueueQuery() {
  return useQuery({
    queryKey: QUERY_KEYS.queue,
    queryFn: () => apiFetcher('/api/queue'),
    staleTime: 30 * 1000,
  });
}
