/**
 * ============================================================================
 * LAZY ROUTES
 * Code-split route components with React.lazy() and Suspense
 * ============================================================================
 *
 * Features:
 * - Code splitting for each route
 * - Loading states with skeleton UI
 * - Error boundaries per route
 * - Preloading for anticipated navigation
 * - Named exports for tree shaking
 *
 * Usage:
 * ```typescript
 * import { LazyRoutes, preloadRoute } from './lib/lazy-routes';
 *
 * // In your App component:
 * <Routes>
 *   <Route path="/" element={<LazyRoutes.Dashboard />} />
 *   <Route path="/approvals" element={<LazyRoutes.Approvals />} />
 * </Routes>
 *
 * // Preload on hover:
 * <NavLink
 *   to="/settings"
 *   onMouseEnter={() => preloadRoute('settings')}
 * >
 *   Settings
 * </NavLink>
 * ```
 */

import React, { Suspense, lazy, ComponentType, ReactNode } from 'react';
import { LoadingSpinner } from '../components/LoadingSpinner';

// =============================================================================
// TYPES
// =============================================================================

type RouteLoaderResult = Promise<{ default: ComponentType<unknown> }>;

interface RouteConfig {
  loader: () => RouteLoaderResult;
  fallback?: ReactNode;
  preloaded?: boolean;
}

// =============================================================================
// LOADING FALLBACKS
// =============================================================================

/**
 * Full-page loading spinner
 */
export function PageLoadingFallback(): JSX.Element {
  return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <LoadingSpinner centered />
    </div>
  );
}

/**
 * Skeleton loading for dashboard cards
 */
export function DashboardSkeleton(): JSX.Element {
  return (
    <div className="p-4 space-y-4 animate-pulse">
      {/* Budget cards skeleton */}
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-slate-800/50 rounded-xl p-3 h-24">
            <div className="w-12 h-12 mx-auto bg-slate-700 rounded-full" />
            <div className="w-16 h-3 mx-auto mt-2 bg-slate-700 rounded" />
          </div>
        ))}
      </div>

      {/* Stats skeleton */}
      <div className="grid grid-cols-2 gap-3">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-slate-800/50 rounded-xl p-4 h-28">
            <div className="w-8 h-8 bg-slate-700 rounded" />
            <div className="w-20 h-6 mt-3 bg-slate-700 rounded" />
            <div className="w-24 h-3 mt-2 bg-slate-700 rounded" />
          </div>
        ))}
      </div>

      {/* Queue status skeleton */}
      <div className="bg-slate-800/50 rounded-xl p-4 h-40">
        <div className="w-32 h-4 bg-slate-700 rounded" />
        <div className="space-y-3 mt-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex justify-between">
              <div className="w-20 h-3 bg-slate-700 rounded" />
              <div className="w-8 h-3 bg-slate-700 rounded" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/**
 * Skeleton loading for approvals list
 */
export function ApprovalsSkeleton(): JSX.Element {
  return (
    <div className="p-4 space-y-4 animate-pulse">
      <div className="w-32 h-6 bg-slate-700 rounded" />
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="w-48 h-4 bg-slate-700 rounded" />
              <div className="w-32 h-3 mt-2 bg-slate-700 rounded" />
            </div>
            <div className="w-16 h-6 bg-slate-700 rounded" />
          </div>
          <div className="flex gap-2 mt-4">
            <div className="flex-1 h-10 bg-slate-700 rounded-lg" />
            <div className="flex-1 h-10 bg-slate-700 rounded-lg" />
          </div>
        </div>
      ))}
    </div>
  );
}

/**
 * Skeleton loading for budget page
 */
export function BudgetSkeleton(): JSX.Element {
  return (
    <div className="p-4 space-y-4 animate-pulse">
      <div className="w-40 h-6 bg-slate-700 rounded" />

      {/* Budget periods */}
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex justify-between items-center">
            <div className="w-20 h-5 bg-slate-700 rounded" />
            <div className="w-24 h-5 bg-slate-700 rounded" />
          </div>
          <div className="w-full h-2 mt-4 bg-slate-700 rounded-full" />
          <div className="flex justify-between mt-2">
            <div className="w-16 h-3 bg-slate-700 rounded" />
            <div className="w-16 h-3 bg-slate-700 rounded" />
          </div>
        </div>
      ))}

      {/* Circuit breakers */}
      <div className="w-32 h-5 mt-6 bg-slate-700 rounded" />
      <div className="grid grid-cols-2 gap-3">
        {[1, 2].map((i) => (
          <div key={i} className="bg-slate-800/50 rounded-xl p-4 h-20">
            <div className="w-24 h-4 bg-slate-700 rounded" />
            <div className="w-16 h-5 mt-2 bg-slate-700 rounded" />
          </div>
        ))}
      </div>
    </div>
  );
}

/**
 * Skeleton loading for settings page
 */
export function SettingsSkeleton(): JSX.Element {
  return (
    <div className="p-4 space-y-4 animate-pulse">
      <div className="w-28 h-6 bg-slate-700 rounded" />

      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex justify-between items-center">
            <div>
              <div className="w-32 h-4 bg-slate-700 rounded" />
              <div className="w-48 h-3 mt-2 bg-slate-700 rounded" />
            </div>
            <div className="w-12 h-6 bg-slate-700 rounded-full" />
          </div>
        </div>
      ))}
    </div>
  );
}

/**
 * Skeleton loading for analytics page
 */
export function AnalyticsSkeleton(): JSX.Element {
  return (
    <div className="p-4 space-y-4 animate-pulse">
      {/* Header skeleton */}
      <div className="flex justify-between items-center">
        <div>
          <div className="w-28 h-6 bg-slate-700 rounded" />
          <div className="w-40 h-3 mt-2 bg-slate-700 rounded" />
        </div>
        <div className="w-24 h-10 bg-slate-700 rounded-lg" />
      </div>

      {/* Time period selector skeleton */}
      <div className="flex gap-2">
        {[1, 2, 3].map((i) => (
          <div key={i} className="w-20 h-10 bg-slate-700 rounded-lg" />
        ))}
      </div>

      {/* KPI cards skeleton */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-slate-700 rounded-xl p-4 h-24">
            <div className="w-20 h-3 bg-slate-600 rounded" />
            <div className="w-24 h-6 mt-3 bg-slate-600 rounded" />
          </div>
        ))}
      </div>

      {/* Chart skeleton */}
      <div className="bg-slate-800/50 rounded-xl p-4 h-80">
        <div className="w-40 h-5 bg-slate-700 rounded mb-4" />
        <div className="h-60 bg-slate-700 rounded" />
      </div>

      {/* Table skeleton */}
      <div className="bg-slate-800/50 rounded-xl p-4">
        <div className="w-32 h-5 bg-slate-700 rounded mb-4" />
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="flex gap-4 py-3 border-b border-slate-700">
            <div className="w-6 h-6 bg-slate-700 rounded-full" />
            <div className="flex-1 h-4 bg-slate-700 rounded" />
            <div className="w-20 h-4 bg-slate-700 rounded" />
            <div className="w-16 h-4 bg-slate-700 rounded" />
          </div>
        ))}
      </div>
    </div>
  );
}

// =============================================================================
// ROUTE CONFIGURATION
// =============================================================================

const routes: Record<string, RouteConfig> = {
  dashboard: {
    loader: () => import('../pages/DashboardPage'),
    fallback: <DashboardSkeleton />,
  },
  approvals: {
    loader: () => import('../pages/ApprovalsPage'),
    fallback: <ApprovalsSkeleton />,
  },
  budget: {
    loader: () => import('../pages/BudgetPage'),
    fallback: <BudgetSkeleton />,
  },
  settings: {
    loader: () => import('../pages/SettingsPage'),
    fallback: <SettingsSkeleton />,
  },
  analytics: {
    loader: () => import('../pages/AnalyticsPage'),
    fallback: <AnalyticsSkeleton />,
  },
};

// =============================================================================
// LAZY COMPONENT FACTORY
// =============================================================================

/**
 * Creates a lazy-loaded component with custom fallback
 */
function createLazyComponent(
  routeKey: string,
  config: RouteConfig
): React.FC {
  const LazyComponent = lazy(config.loader);

  // Return a wrapper component
  const WrappedComponent: React.FC = () => (
    <Suspense fallback={config.fallback || <PageLoadingFallback />}>
      <LazyComponent />
    </Suspense>
  );

  WrappedComponent.displayName = `Lazy${routeKey.charAt(0).toUpperCase() + routeKey.slice(1)}`;

  return WrappedComponent;
}

// =============================================================================
// LAZY ROUTES OBJECT
// =============================================================================

/**
 * Object containing all lazy-loaded route components
 */
export const LazyRoutes = {
  Dashboard: createLazyComponent('dashboard', routes.dashboard),
  Approvals: createLazyComponent('approvals', routes.approvals),
  Budget: createLazyComponent('budget', routes.budget),
  Settings: createLazyComponent('settings', routes.settings),
  Analytics: createLazyComponent('analytics', routes.analytics),
};

// =============================================================================
// PRELOADING
// =============================================================================

/**
 * Preload a route's component
 * Useful for preloading on hover or when user shows intent
 */
export function preloadRoute(routeKey: keyof typeof routes): void {
  const config = routes[routeKey];
  if (config && !config.preloaded) {
    config.loader().then(() => {
      config.preloaded = true;
    });
  }
}

/**
 * Preload all routes
 * Useful after initial page load when idle
 */
export function preloadAllRoutes(): void {
  Object.keys(routes).forEach((key) => {
    preloadRoute(key as keyof typeof routes);
  });
}

/**
 * Preload routes when browser is idle
 * Uses requestIdleCallback for non-blocking preload
 */
export function preloadRoutesWhenIdle(): void {
  if ('requestIdleCallback' in window) {
    window.requestIdleCallback(() => {
      preloadAllRoutes();
    }, { timeout: 5000 });
  } else {
    // Fallback for Safari
    setTimeout(preloadAllRoutes, 2000);
  }
}

// =============================================================================
// ROUTE ERROR BOUNDARY
// =============================================================================

interface RouteErrorFallbackProps {
  error: Error;
  resetError: () => void;
}

/**
 * Error fallback for route-level errors
 */
export function RouteErrorFallback({
  error,
  resetError,
}: RouteErrorFallbackProps): JSX.Element {
  return (
    <div className="p-8 text-center">
      <div className="text-4xl mb-4">:(</div>
      <h2 className="text-xl font-bold text-red-400 mb-2">Page Failed to Load</h2>
      <p className="text-gray-400 mb-4">
        {error.message || 'An error occurred while loading this page'}
      </p>
      <div className="flex gap-3 justify-center">
        <button
          onClick={resetError}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
        >
          Try Again
        </button>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
        >
          Reload Page
        </button>
      </div>
    </div>
  );
}

// =============================================================================
// EXPORTS
// =============================================================================

export default LazyRoutes;
