import React, { memo } from 'react';
import { NavLink, useLocation } from 'react-router-dom';

import { getTabRoutes, ICONS } from '../../mobile/navigation/routes';
import { useSystemStatusQuery } from '../../hooks/useQueries';

interface TabItemProps {
  to: string;
  icon: string;
  label: string;
  badgeCount?: number;
}

/**
 * Individual tab item component
 */
const TabItem = memo(function TabItem({
  to,
  icon,
  label,
  badgeCount,
}: TabItemProps): React.ReactElement {
  const iconPath = ICONS[icon];

  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex flex-col items-center justify-center py-2 px-3 rounded-lg transition-all relative ${
          isActive
            ? 'text-indigo-400'
            : 'text-gray-400 hover:text-gray-300 active:text-gray-200'
        }`
      }
    >
      {({ isActive }) => (
        <>
          {/* Badge */}
          {badgeCount !== undefined && badgeCount > 0 && (
            <span className="absolute -top-0.5 right-0.5 min-w-[18px] h-[18px] bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center px-1">
              {badgeCount > 99 ? '99+' : badgeCount}
            </span>
          )}

          {/* Icon */}
          <div className="relative">
            {isActive && (
              <div className="absolute inset-0 bg-indigo-500/20 rounded-lg blur-lg" />
            )}
            <svg
              className="w-6 h-6 relative"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={isActive ? 2.5 : 2}
                d={iconPath}
              />
            </svg>
          </div>

          {/* Label */}
          <span className={`text-xs mt-1 ${isActive ? 'font-medium' : ''}`}>
            {label}
          </span>
        </>
      )}
    </NavLink>
  );
});

/**
 * Bottom tab bar navigation component
 */
export const TabBar = memo(function TabBar(): React.ReactElement {
  const { data: status } = useSystemStatusQuery();
  const tabRoutes = getTabRoutes();

  // Get badge counts from system status
  const getBadgeCount = (badgeKey?: string): number | undefined => {
    if (!badgeKey || !status) return undefined;

    switch (badgeKey) {
      case 'pendingApprovals':
        return status.approvalStats?.pendingCount;
      case 'alerts':
        // Count open circuit breakers + dead letter queue items as alerts
        const openBreakers = status.circuitBreakers
          ? Object.values(status.circuitBreakers).filter((cb) => cb.isOpen).length
          : 0;
        const deadLetter = status.queues?.deadLetter ?? 0;
        const total = openBreakers + deadLetter;
        return total > 0 ? total : undefined;
      default:
        return undefined;
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-800/95 backdrop-blur-sm border-t border-slate-700 z-30 safe-area-pb">
      <div className="flex justify-around items-center px-2 py-1">
        {tabRoutes.map((route) => (
          <TabItem
            key={route.path}
            to={route.path}
            icon={route.icon}
            label={route.label}
            badgeCount={getBadgeCount(route.badgeKey)}
          />
        ))}
      </div>
    </nav>
  );
});

export default TabBar;
