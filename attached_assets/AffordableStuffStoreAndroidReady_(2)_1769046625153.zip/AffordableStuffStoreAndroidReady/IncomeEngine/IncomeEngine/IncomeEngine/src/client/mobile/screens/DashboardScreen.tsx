import React, { useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

import { useSystemStatusQuery } from '../../hooks/useQueries';
import { PullToRefresh } from '../../components/mobile/PullToRefresh';
import { ProgressRing } from '../../components/ProgressRing';
import { LoadingSpinner } from '../../components/LoadingSpinner';

/**
 * Mobile dashboard screen
 * Shows revenue overview and quick stats
 */
export function DashboardScreen(): React.ReactElement {
  const navigate = useNavigate();
  const { data: status, isLoading, error, refetch, isFetching } = useSystemStatusQuery();

  // Handle pull-to-refresh
  const handleRefresh = useCallback(async () => {
    await refetch();
  }, [refetch]);

  // Memoize open circuit breakers
  const openBreakers = useMemo(() => {
    if (!status?.circuitBreakers) return [];
    return Object.entries(status.circuitBreakers).filter(([_, state]) => state.isOpen);
  }, [status?.circuitBreakers]);

  // Calculate total daily spend
  const dailyBudget = useMemo(() => {
    return status?.budget?.find((b) => b.period === 'daily');
  }, [status?.budget]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4">
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <h3 className="font-semibold text-red-400">Connection Error</h3>
          <p className="text-sm text-gray-400 mt-1">
            {error instanceof Error ? error.message : 'Failed to load status'}
          </p>
          <button
            onClick={() => refetch()}
            className="mt-3 px-4 py-2 bg-red-500 rounded-lg text-sm font-medium"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!status) return <div />;

  return (
    <PullToRefresh onRefresh={handleRefresh} isRefreshing={isFetching} className="h-full">
      <div className="p-4 space-y-4">
        {/* Alert Banner */}
        {openBreakers.length > 0 && (
          <button
            onClick={() => navigate('/alerts')}
            className="w-full bg-red-500/20 border border-red-500 rounded-xl p-4 text-left card-hover"
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-red-500/30 rounded-full flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-red-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                  />
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <span className="font-semibold text-red-400">Circuit Breaker Active</span>
                <p className="text-sm text-gray-300 truncate">
                  {openBreakers[0][1].openedReason || 'Budget limit exceeded'}
                </p>
              </div>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </button>
        )}

        {/* Budget Overview Card */}
        <div className="bg-slate-800/50 rounded-xl p-4">
          <h2 className="font-semibold mb-4">Budget Status</h2>
          <div className="grid grid-cols-3 gap-4">
            {status.budget.map((b) => (
              <div key={b.period} className="text-center">
                <div className="flex justify-center mb-2">
                  <ProgressRing
                    percent={b.percentUsed}
                    size={56}
                    showLabel
                    strokeWidth={4}
                  />
                </div>
                <p className="text-xs text-gray-400 capitalize">{b.period}</p>
                <p className="text-sm font-semibold">${b.currentSpend.toFixed(2)}</p>
                <p className="text-xs text-gray-500">/ ${b.limit.toFixed(0)}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => navigate('/approvals')}
            className="bg-slate-800/50 rounded-xl p-4 text-left card-hover"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-10 h-10 bg-indigo-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                </svg>
              </div>
              {status.approvalStats.pendingCount > 0 && (
                <span className="bg-indigo-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {status.approvalStats.pendingCount}
                </span>
              )}
            </div>
            <p className="text-2xl font-bold">{status.approvalStats.pendingCount}</p>
            <p className="text-sm text-gray-400">Pending Approvals</p>
          </button>

          <button
            onClick={() => navigate('/alerts')}
            className="bg-slate-800/50 rounded-xl p-4 text-left card-hover"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
              </div>
              {status.queues.deadLetter > 0 && (
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {status.queues.deadLetter}
                </span>
              )}
            </div>
            <p className="text-2xl font-bold">{status.queues.queued}</p>
            <p className="text-sm text-gray-400">Queued Tasks</p>
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-800/50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
            <p className="text-2xl font-bold">{status.approvalStats.totalApproved}</p>
            <p className="text-sm text-gray-400">Total Approved</p>
          </div>

          <div className="bg-slate-800/50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
            </div>
            <p className="text-2xl font-bold">
              {(status.approvalStats.approvalRate * 100).toFixed(0)}%
            </p>
            <p className="text-sm text-gray-400">Approval Rate</p>
          </div>
        </div>

        {/* Queue Status */}
        <div className="bg-slate-800/50 rounded-xl p-4">
          <h3 className="font-semibold mb-3">API Queue</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-gray-400 rounded-full" />
                <span className="text-sm text-gray-400">Queued</span>
              </div>
              <span className="font-medium">{status.queues.queued}</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                <span className="text-sm text-gray-400">Processing</span>
              </div>
              <span className="font-medium text-blue-400">{status.queues.processing}</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-yellow-400 rounded-full" />
                <span className="text-sm text-gray-400">Rate Limited</span>
              </div>
              <span className="font-medium text-yellow-400">{status.queues.rateLimited}</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-400 rounded-full" />
                <span className="text-sm text-gray-400">Dead Letter</span>
              </div>
              <span className={`font-medium ${status.queues.deadLetter > 0 ? 'text-red-400' : ''}`}>
                {status.queues.deadLetter}
              </span>
            </div>
          </div>
        </div>

        {/* Today's Activity */}
        <div className="bg-slate-800/50 rounded-xl p-4">
          <h3 className="font-semibold mb-2">Today's Activity</h3>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <p className="text-3xl font-bold text-indigo-400">
                {status.queues.completedToday}
              </p>
              <p className="text-sm text-gray-400">Tasks Completed</p>
            </div>
            {dailyBudget && (
              <div className="text-right">
                <p className="text-lg font-semibold">
                  ${dailyBudget.currentSpend.toFixed(2)}
                </p>
                <p className="text-sm text-gray-400">Spent Today</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </PullToRefresh>
  );
}

export default DashboardScreen;
