import React, { useMemo } from 'react';
import { useSystemStatus } from '../hooks/useSystemStatus';
import { StatusBadge } from '../components/StatusBadge';
import { ProgressRing } from '../components/ProgressRing';
import { LoadingSpinner } from '../components/LoadingSpinner';

/**
 * Main dashboard page showing system status overview
 */
export function DashboardPage() {
  const { status, loading, error, refresh } = useSystemStatus();

  // Memoize open circuit breakers
  const openBreakers = useMemo(() => {
    if (!status?.circuitBreakers) return [];
    return Object.entries(status.circuitBreakers)
      .filter(([_, state]) => state.isOpen);
  }, [status?.circuitBreakers]);

  if (loading) {
    return <LoadingSpinner centered />;
  }

  if (error) {
    return (
      <div className="p-4">
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <h3 className="font-semibold text-red-400">Connection Error</h3>
          <p className="text-sm text-gray-400 mt-1">{error}</p>
          <button
            onClick={refresh}
            className="mt-3 px-4 py-2 bg-red-500 rounded-lg text-sm font-medium"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!status) return null;

  return (
    <div className="p-4 space-y-4">
      {/* Alert Banner */}
      {openBreakers.length > 0 && (
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">🚨</span>
            <span className="font-semibold">Circuit Breaker Active</span>
          </div>
          <p className="text-sm text-gray-300 mt-1">
            {openBreakers[0][1].openedReason || 'Budget limit exceeded'}
          </p>
        </div>
      )}

      {/* Budget Cards */}
      <div className="grid grid-cols-3 gap-3">
        {status.budget.map((b) => (
          <div key={b.period} className="bg-slate-800/50 rounded-xl p-3 text-center">
            <div className="flex justify-center mb-2">
              <ProgressRing percent={b.percentUsed} size={60} showLabel />
            </div>
            <p className="text-xs text-gray-400 capitalize">{b.period}</p>
            <p className="text-sm font-semibold">${b.currentSpend.toFixed(2)}</p>
          </div>
        ))}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl">📋</span>
            <StatusBadge
              status={status.approvalStats.pendingCount > 10 ? 'warning' : 'ok'}
            />
          </div>
          <p className="text-2xl font-bold mt-2">{status.approvalStats.pendingCount}</p>
          <p className="text-sm text-gray-400">Pending Approvals</p>
        </div>

        <div className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl">📊</span>
            <StatusBadge status={status.queues.deadLetter > 0 ? 'error' : 'ok'} />
          </div>
          <p className="text-2xl font-bold mt-2">{status.queues.queued}</p>
          <p className="text-sm text-gray-400">Queued Tasks</p>
        </div>

        <div className="bg-slate-800/50 rounded-xl p-4">
          <span className="text-2xl">✅</span>
          <p className="text-2xl font-bold mt-2">{status.approvalStats.totalApproved}</p>
          <p className="text-sm text-gray-400">Total Approved</p>
        </div>

        <div className="bg-slate-800/50 rounded-xl p-4">
          <span className="text-2xl">📈</span>
          <p className="text-2xl font-bold mt-2">
            {(status.approvalStats.approvalRate * 100).toFixed(0)}%
          </p>
          <p className="text-sm text-gray-400">Approval Rate</p>
        </div>
      </div>

      {/* Queue Status */}
      <div className="bg-slate-800/50 rounded-xl p-4">
        <h3 className="font-semibold mb-3">API Queue Status</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Queued</span>
            <span className="font-medium">{status.queues.queued}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Processing</span>
            <span className="font-medium text-blue-400">{status.queues.processing}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Rate Limited</span>
            <span className="font-medium text-yellow-400">{status.queues.rateLimited}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Dead Letter</span>
            <span
              className={`font-medium ${status.queues.deadLetter > 0 ? 'text-red-400' : ''}`}
            >
              {status.queues.deadLetter}
            </span>
          </div>
        </div>
      </div>

      {/* Refresh Button */}
      <button
        onClick={refresh}
        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 rounded-xl font-medium transition-colors"
      >
        Refresh Status
      </button>
    </div>
  );
}

export default DashboardPage;
