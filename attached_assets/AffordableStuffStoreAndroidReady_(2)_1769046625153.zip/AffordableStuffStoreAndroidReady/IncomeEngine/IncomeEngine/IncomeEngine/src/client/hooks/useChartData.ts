/**
 * ============================================================================
 * CHART DATA TRANSFORMATION HOOK
 * Transforms analytics data into chart-ready formats
 * ============================================================================
 */

import { useMemo } from 'react';
import type {
  RevenueDataPoint,
  PlatformStats,
  ProductPerformance,
  TrendItem,
} from './useAnalytics';

// =============================================================================
// TYPES
// =============================================================================

export interface ChartDataset {
  label: string;
  data: number[];
  backgroundColor?: string | string[];
  borderColor?: string;
  borderWidth?: number;
  fill?: boolean;
  tension?: number;
}

export interface LineChartData {
  labels: string[];
  datasets: ChartDataset[];
}

export interface BarChartData {
  labels: string[];
  datasets: ChartDataset[];
}

export interface PieChartData {
  labels: string[];
  datasets: Array<{
    data: number[];
    backgroundColor: string[];
    borderColor?: string[];
    borderWidth?: number;
  }>;
}

// =============================================================================
// COLOR PALETTE
// =============================================================================

export const CHART_COLORS = {
  primary: '#6366f1',
  primaryLight: 'rgba(99, 102, 241, 0.2)',
  secondary: '#8b5cf6',
  secondaryLight: 'rgba(139, 92, 246, 0.2)',
  success: '#22c55e',
  successLight: 'rgba(34, 197, 94, 0.2)',
  warning: '#f59e0b',
  warningLight: 'rgba(245, 158, 11, 0.2)',
  danger: '#ef4444',
  dangerLight: 'rgba(239, 68, 68, 0.2)',
  info: '#06b6d4',
  infoLight: 'rgba(6, 182, 212, 0.2)',
  gray: '#6b7280',
  grayLight: 'rgba(107, 114, 128, 0.2)',
};

export const PLATFORM_COLORS: Record<string, string> = {
  'Printify': '#00b8a9',
  'Etsy': '#f56040',
  'Gumroad': '#ff90e8',
  'TeePublic': '#00b2ff',
  'Redbubble': '#e41321',
  'Creative Fabrica': '#7c3aed',
  'Society6': '#2d3748',
  'Amazon KDP': '#ff9900',
  'Shopify': '#96bf48',
  'WooCommerce': '#9b5c8f',
  'TikTok Shop': '#ff0050',
};

const GRADIENT_COLORS = [
  ['#667eea', '#764ba2'],
  ['#11998e', '#38ef7d'],
  ['#ee0979', '#ff6a00'],
  ['#4776E6', '#8E54E9'],
  ['#00b4db', '#0083b0'],
  ['#f953c6', '#b91d73'],
  ['#c94b4b', '#4b134f'],
  ['#56ab2f', '#a8e063'],
];

// =============================================================================
// HOOKS
// =============================================================================

/**
 * Transform revenue time series data for line charts
 */
export function useRevenueChartData(
  data: RevenueDataPoint[] | undefined,
  options: {
    showProfit?: boolean;
    showOrders?: boolean;
  } = {}
): LineChartData | null {
  const { showProfit = true, showOrders = false } = options;

  return useMemo(() => {
    if (!data || data.length === 0) return null;

    const labels = data.map(d => {
      const date = new Date(d.date);
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    });

    const datasets: ChartDataset[] = [
      {
        label: 'Revenue',
        data: data.map(d => d.revenue),
        borderColor: CHART_COLORS.primary,
        backgroundColor: CHART_COLORS.primaryLight,
        borderWidth: 2,
        fill: true,
        tension: 0.4,
      },
    ];

    if (showProfit) {
      datasets.push({
        label: 'Profit',
        data: data.map(d => d.profit),
        borderColor: CHART_COLORS.success,
        backgroundColor: CHART_COLORS.successLight,
        borderWidth: 2,
        fill: true,
        tension: 0.4,
      });
    }

    if (showOrders) {
      datasets.push({
        label: 'Orders',
        data: data.map(d => d.orders),
        borderColor: CHART_COLORS.info,
        backgroundColor: CHART_COLORS.infoLight,
        borderWidth: 2,
        fill: false,
        tension: 0.4,
      });
    }

    return { labels, datasets };
  }, [data, showProfit, showOrders]);
}

/**
 * Transform platform data for bar/pie charts
 */
export function usePlatformChartData(
  platforms: PlatformStats[] | undefined,
  options: {
    metric?: 'revenue' | 'orders' | 'products';
    chartType?: 'bar' | 'pie' | 'doughnut';
    limit?: number;
  } = {}
): BarChartData | PieChartData | null {
  const { metric = 'revenue', chartType = 'bar', limit = 8 } = options;

  return useMemo(() => {
    if (!platforms || platforms.length === 0) return null;

    // Sort by metric and limit
    const sortedPlatforms = [...platforms]
      .sort((a, b) => b[metric] - a[metric])
      .slice(0, limit);

    const labels = sortedPlatforms.map(p => p.platform);
    const values = sortedPlatforms.map(p => p[metric]);
    const colors = sortedPlatforms.map(
      p => PLATFORM_COLORS[p.platform] || CHART_COLORS.gray
    );

    if (chartType === 'bar') {
      return {
        labels,
        datasets: [
          {
            label: metric.charAt(0).toUpperCase() + metric.slice(1),
            data: values,
            backgroundColor: colors,
            borderColor: colors,
            borderWidth: 1,
          },
        ],
      } as BarChartData;
    }

    // Pie/Doughnut chart
    return {
      labels,
      datasets: [
        {
          data: values,
          backgroundColor: colors,
          borderColor: colors.map(() => '#ffffff'),
          borderWidth: 2,
        },
      ],
    } as PieChartData;
  }, [platforms, metric, chartType, limit]);
}

/**
 * Transform product data for horizontal bar charts
 */
export function useProductChartData(
  products: ProductPerformance[] | undefined,
  options: {
    metric?: 'revenue' | 'unitsSold' | 'views' | 'conversionRate';
    limit?: number;
  } = {}
): BarChartData | null {
  const { metric = 'revenue', limit = 10 } = options;

  return useMemo(() => {
    if (!products || products.length === 0) return null;

    const topProducts = products.slice(0, limit);

    return {
      labels: topProducts.map(p =>
        p.title.length > 25 ? p.title.substring(0, 25) + '...' : p.title
      ),
      datasets: [
        {
          label: metric === 'conversionRate' ? 'Conversion Rate (%)' : metric.charAt(0).toUpperCase() + metric.slice(1),
          data: topProducts.map(p => p[metric]),
          backgroundColor: topProducts.map((_, i) => {
            const gradient = GRADIENT_COLORS[i % GRADIENT_COLORS.length];
            return gradient[0];
          }),
          borderWidth: 0,
        },
      ],
    };
  }, [products, metric, limit]);
}

/**
 * Transform trend data for comparison visualization
 */
export function useTrendChartData(
  trends: TrendItem[] | undefined
): BarChartData | null {
  return useMemo(() => {
    if (!trends || trends.length === 0) return null;

    return {
      labels: trends.map(t => t.metric),
      datasets: [
        {
          label: 'Current Period',
          data: trends.map(t => t.current),
          backgroundColor: CHART_COLORS.primary,
          borderWidth: 0,
        },
        {
          label: 'Previous Period',
          data: trends.map(t => t.previous),
          backgroundColor: CHART_COLORS.gray,
          borderWidth: 0,
        },
      ],
    };
  }, [trends]);
}

/**
 * Calculate chart statistics from data
 */
export function useChartStats<T>(
  data: T[] | undefined,
  valueAccessor: (item: T) => number
): {
  min: number;
  max: number;
  avg: number;
  sum: number;
  count: number;
} | null {
  return useMemo(() => {
    if (!data || data.length === 0) return null;

    const values = data.map(valueAccessor);
    const sum = values.reduce((a, b) => a + b, 0);

    return {
      min: Math.min(...values),
      max: Math.max(...values),
      avg: sum / values.length,
      sum,
      count: values.length,
    };
  }, [data, valueAccessor]);
}

/**
 * Generate gradient colors for charts
 */
export function useGradientColors(count: number): string[] {
  return useMemo(() => {
    return Array.from({ length: count }, (_, i) => {
      const gradient = GRADIENT_COLORS[i % GRADIENT_COLORS.length];
      return gradient[0];
    });
  }, [count]);
}

/**
 * Format number for chart display
 */
export function formatChartValue(
  value: number,
  type: 'currency' | 'number' | 'percent'
): string {
  switch (type) {
    case 'currency':
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(value);
    case 'percent':
      return `${value.toFixed(1)}%`;
    default:
      return new Intl.NumberFormat('en-US').format(value);
  }
}

/**
 * Format large numbers with abbreviations (1K, 1M, etc.)
 */
export function formatCompactNumber(value: number): string {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    compactDisplay: 'short',
  }).format(value);
}

export default {
  useRevenueChartData,
  usePlatformChartData,
  useProductChartData,
  useTrendChartData,
  useChartStats,
  useGradientColors,
  formatChartValue,
  formatCompactNumber,
  CHART_COLORS,
  PLATFORM_COLORS,
};
