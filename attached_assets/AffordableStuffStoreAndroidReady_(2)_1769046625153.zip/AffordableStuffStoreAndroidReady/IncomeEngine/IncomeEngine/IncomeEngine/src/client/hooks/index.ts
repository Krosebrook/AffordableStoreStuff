/**
 * Hooks module exports
 */

// System and data hooks
export { useSystemStatus } from './useSystemStatus';
export {
  useSystemStatusQuery,
  useApprovalsQuery,
  useApproveProduct,
  useRejectProduct,
  useProvidersQuery,
  useQueueQuery,
} from './useQueries';

// Mobile hooks
export { useNetworkStatus, isSlowNetwork, shouldReduceData } from './useNetworkStatus';
export { useOfflineSync, useOfflineApproval } from './useOfflineSync';
export { usePushNotifications } from './usePushNotifications';

// Responsive hooks
export {
  useResponsive,
  useBreakpoint,
  useOrientation,
  useReducedMotion,
} from './useResponsive';
