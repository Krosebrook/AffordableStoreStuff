import { QueryClient } from '@tanstack/react-query';

/**
 * Query keys for consistent cache management
 */
export const QUERY_KEYS = {
  systemStatus: ['system', 'status'] as const,
  budget: ['budget'] as const,
  approvals: ['approvals'] as const,
  approvalsQueue: ['approvals', 'queue'] as const,
  providers: ['providers'] as const,
  queue: ['queue'] as const,
  analytics: (range: string) => ['analytics', range] as const,
  analyticsRevenue: (params?: unknown) => ['analytics', 'revenue', params] as const,
  analyticsPlatforms: (params?: unknown) => ['analytics', 'platforms', params] as const,
  analyticsProducts: (params?: unknown) => ['analytics', 'products', params] as const,
  analyticsTrends: (params?: unknown) => ['analytics', 'trends', params] as const,
  analyticsSummary: (params?: unknown) => ['analytics', 'summary', params] as const,
};

/**
 * Configure the QueryClient with optimal settings for the dashboard
 */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Data is fresh for 30 seconds (dashboard updates frequently)
      staleTime: 30 * 1000,

      // Keep cached data for 5 minutes
      gcTime: 5 * 60 * 1000,

      // Refetch on window focus for real-time data
      refetchOnWindowFocus: true,

      // Refetch when reconnecting
      refetchOnReconnect: true,

      // Retry failed queries up to 3 times
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),

      // Don't throw on error, handle in component
      throwOnError: false,
    },
    mutations: {
      // Retry mutations once
      retry: 1,
      retryDelay: 1000,
    },
  },
});

/**
 * API fetcher with error handling
 */
export async function apiFetcher<T>(url: string): Promise<T> {
  const response = await fetch(url);

  if (!response.ok) {
    const error = new Error('API request failed');
    (error as any).status = response.status;
    (error as any).statusText = response.statusText;
    throw error;
  }

  return response.json();
}

/**
 * API mutation helper
 */
export async function apiMutate<T, D = unknown>(
  url: string,
  method: 'POST' | 'PUT' | 'PATCH' | 'DELETE',
  data?: D
): Promise<T> {
  const response = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
    body: data ? JSON.stringify(data) : undefined,
  });

  if (!response.ok) {
    const error = new Error('API mutation failed');
    (error as any).status = response.status;
    (error as any).statusText = response.statusText;
    throw error;
  }

  return response.json();
}

export default queryClient;
