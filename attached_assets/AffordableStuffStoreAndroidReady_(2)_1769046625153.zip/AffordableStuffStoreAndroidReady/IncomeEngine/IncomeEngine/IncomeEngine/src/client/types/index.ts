/**
 * Shared TypeScript types for the client application
 */

export interface BudgetStatus {
  period: string;
  currentSpend: number;
  limit: number;
  percentUsed: number;
  isWarning: boolean;
  isExceeded: boolean;
  remainingBudget: number;
  resetAt?: string;
}

export interface QueueStats {
  queued: number;
  processing: number;
  rateLimited: number;
  deadLetter: number;
  completedToday: number;
}

export interface ApprovalStats {
  totalApproved: number;
  totalRejected: number;
  approvalRate: number;
  pendingCount: number;
}

export interface CircuitBreakerState {
  isOpen: boolean;
  openedReason?: string;
  openedAt?: string;
  willRetryAt?: string;
}

export interface SystemStatus {
  budget: BudgetStatus[];
  queues: QueueStats;
  approvalStats: ApprovalStats;
  circuitBreakers: Record<string, CircuitBreakerState>;
  providers?: Record<string, ProviderStatus[]>;
}

export interface ProviderStatus {
  id: string;
  providerType: string;
  providerName: string;
  isPrimary: boolean;
  isAvailable: boolean;
  healthScore: number;
  lastCheckAt: string;
  avgResponseTimeMs?: number;
}

export interface PendingApproval {
  id: string;
  productId: string;
  title: string;
  type: string;
  reason: string;
  riskLevel: 'low' | 'medium' | 'high';
  createdAt: string;
  metadata?: Record<string, any>;
}

export interface ApprovalAction {
  id: string;
  action: 'approve' | 'reject';
  notes?: string;
}

// =============================================================================
// ANALYTICS TYPES
// =============================================================================

export interface RevenueDataPoint {
  date: string;
  revenue: number;
  orders: number;
  profit: number;
}

export interface RevenueSummary {
  totalRevenue: number;
  totalOrders: number;
  totalProfit: number;
  avgDailyRevenue: number;
  profitMargin: number;
}

export interface PlatformStats {
  platform: string;
  revenue: number;
  orders: number;
  products: number;
  avgOrderValue: number;
  growth: number;
}

export interface ProductPerformance {
  id: string;
  title: string;
  platform: string;
  revenue: number;
  unitsSold: number;
  views: number;
  conversionRate: number;
  trend: 'up' | 'down' | 'stable';
}

export interface TrendItem {
  metric: string;
  current: number;
  previous: number;
  change: number;
  changePercent: number;
  trend: 'up' | 'down' | 'stable';
}

export interface AnalyticsSummary {
  overview: {
    totalRevenue: number;
    totalOrders: number;
    totalProfit: number;
    profitMargin: number;
    avgOrderValue: number;
  };
  revenueTimeSeries: RevenueDataPoint[];
  platformBreakdown: PlatformStats[];
  topProducts: ProductPerformance[];
  trends: TrendItem[];
  dateRange: {
    start: string;
    end: string;
  };
}
