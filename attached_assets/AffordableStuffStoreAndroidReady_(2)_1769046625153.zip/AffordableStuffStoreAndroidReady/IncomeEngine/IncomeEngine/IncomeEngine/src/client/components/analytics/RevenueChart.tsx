/**
 * ============================================================================
 * REVENUE CHART COMPONENT
 * Line chart showing revenue over time with optional profit overlay
 * ============================================================================
 */

import React, { memo, useMemo } from 'react';
import type { RevenueDataPoint } from '../../hooks/useAnalytics';
import { CHART_COLORS, formatChartValue, formatCompactNumber } from '../../hooks/useChartData';

interface RevenueChartProps {
  data: RevenueDataPoint[];
  showProfit?: boolean;
  showOrders?: boolean;
  height?: number;
  className?: string;
}

/**
 * SVG-based revenue line chart
 * Uses pure React/SVG for lightweight rendering without external chart libraries
 */
export const RevenueChart = memo(function RevenueChart({
  data,
  showProfit = true,
  showOrders = false,
  height = 300,
  className = '',
}: RevenueChartProps) {
  const chartData = useMemo(() => {
    if (!data || data.length === 0) return null;

    const padding = { top: 20, right: 20, bottom: 40, left: 60 };
    const width = 800;
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // Calculate data ranges
    const revenues = data.map(d => d.revenue);
    const profits = data.map(d => d.profit);
    const allValues = showProfit ? [...revenues, ...profits] : revenues;

    const maxValue = Math.max(...allValues) * 1.1;
    const minValue = 0;

    // Generate points for each line
    const generatePath = (values: number[]): string => {
      const points = values.map((value, index) => {
        const x = padding.left + (index / (values.length - 1)) * chartWidth;
        const y = padding.top + chartHeight - ((value - minValue) / (maxValue - minValue)) * chartHeight;
        return `${x},${y}`;
      });
      return `M ${points.join(' L ')}`;
    };

    const generateArea = (values: number[]): string => {
      const path = generatePath(values);
      const firstX = padding.left;
      const lastX = padding.left + chartWidth;
      const bottomY = padding.top + chartHeight;
      return `${path} L ${lastX},${bottomY} L ${firstX},${bottomY} Z`;
    };

    // Generate grid lines
    const gridLines = Array.from({ length: 5 }, (_, i) => {
      const value = minValue + ((maxValue - minValue) * (4 - i)) / 4;
      const y = padding.top + (i / 4) * chartHeight;
      return { y, value };
    });

    // Generate x-axis labels
    const xLabels = data.map((d, index) => {
      const date = new Date(d.date);
      const x = padding.left + (index / (data.length - 1)) * chartWidth;
      return {
        x,
        label: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        showLabel: data.length <= 14 || index % Math.ceil(data.length / 7) === 0,
      };
    });

    return {
      width,
      chartHeight,
      padding,
      revenuePath: generatePath(revenues),
      revenueArea: generateArea(revenues),
      profitPath: showProfit ? generatePath(profits) : null,
      profitArea: showProfit ? generateArea(profits) : null,
      gridLines,
      xLabels,
      maxValue,
    };
  }, [data, showProfit, height]);

  if (!chartData) {
    return (
      <div className={`flex items-center justify-center ${className}`} style={{ height }}>
        <p className="text-gray-400">No revenue data available</p>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      {/* Legend */}
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.primary }} />
          <span className="text-sm text-gray-400">Revenue</span>
        </div>
        {showProfit && (
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.success }} />
            <span className="text-sm text-gray-400">Profit</span>
          </div>
        )}
      </div>

      {/* Chart */}
      <svg
        viewBox={`0 0 ${chartData.width} ${height}`}
        className="w-full"
        style={{ height }}
        preserveAspectRatio="xMidYMid meet"
      >
        {/* Background gradient definitions */}
        <defs>
          <linearGradient id="revenueGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={CHART_COLORS.primary} stopOpacity="0.3" />
            <stop offset="100%" stopColor={CHART_COLORS.primary} stopOpacity="0" />
          </linearGradient>
          <linearGradient id="profitGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={CHART_COLORS.success} stopOpacity="0.3" />
            <stop offset="100%" stopColor={CHART_COLORS.success} stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Grid lines */}
        {chartData.gridLines.map((line, i) => (
          <g key={i}>
            <line
              x1={chartData.padding.left}
              y1={line.y}
              x2={chartData.width - chartData.padding.right}
              y2={line.y}
              stroke="#334155"
              strokeDasharray="4,4"
              strokeWidth="1"
            />
            <text
              x={chartData.padding.left - 10}
              y={line.y + 4}
              textAnchor="end"
              className="fill-gray-400 text-xs"
            >
              {formatCompactNumber(line.value)}
            </text>
          </g>
        ))}

        {/* X-axis labels */}
        {chartData.xLabels.map((label, i) => (
          label.showLabel && (
            <text
              key={i}
              x={label.x}
              y={height - 10}
              textAnchor="middle"
              className="fill-gray-400 text-xs"
            >
              {label.label}
            </text>
          )
        ))}

        {/* Revenue area */}
        <path
          d={chartData.revenueArea}
          fill="url(#revenueGradient)"
        />

        {/* Revenue line */}
        <path
          d={chartData.revenuePath}
          fill="none"
          stroke={CHART_COLORS.primary}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Profit area */}
        {chartData.profitArea && (
          <path
            d={chartData.profitArea}
            fill="url(#profitGradient)"
          />
        )}

        {/* Profit line */}
        {chartData.profitPath && (
          <path
            d={chartData.profitPath}
            fill="none"
            stroke={CHART_COLORS.success}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {/* Data points */}
        {data.map((d, i) => {
          const x = chartData.padding.left + (i / (data.length - 1)) * (chartData.width - chartData.padding.left - chartData.padding.right);
          const yRevenue = chartData.padding.top + chartData.chartHeight -
            (d.revenue / chartData.maxValue) * chartData.chartHeight;
          const yProfit = chartData.padding.top + chartData.chartHeight -
            (d.profit / chartData.maxValue) * chartData.chartHeight;

          return (
            <g key={i} className="opacity-0 hover:opacity-100 transition-opacity">
              {/* Revenue point */}
              <circle
                cx={x}
                cy={yRevenue}
                r="5"
                fill={CHART_COLORS.primary}
                stroke="white"
                strokeWidth="2"
              />
              {/* Tooltip background */}
              <rect
                x={x - 40}
                y={yRevenue - 40}
                width="80"
                height="30"
                rx="4"
                fill="#1e293b"
                stroke="#334155"
              />
              <text
                x={x}
                y={yRevenue - 20}
                textAnchor="middle"
                className="fill-white text-xs font-medium"
              >
                {formatChartValue(d.revenue, 'currency')}
              </text>

              {/* Profit point */}
              {showProfit && (
                <circle
                  cx={x}
                  cy={yProfit}
                  r="4"
                  fill={CHART_COLORS.success}
                  stroke="white"
                  strokeWidth="2"
                />
              )}
            </g>
          );
        })}
      </svg>

      {/* Summary stats */}
      <div className="flex justify-between mt-4 px-2">
        <div className="text-center">
          <p className="text-xs text-gray-400">Total Revenue</p>
          <p className="text-lg font-semibold text-white">
            {formatChartValue(data.reduce((sum, d) => sum + d.revenue, 0), 'currency')}
          </p>
        </div>
        {showProfit && (
          <div className="text-center">
            <p className="text-xs text-gray-400">Total Profit</p>
            <p className="text-lg font-semibold text-green-400">
              {formatChartValue(data.reduce((sum, d) => sum + d.profit, 0), 'currency')}
            </p>
          </div>
        )}
        <div className="text-center">
          <p className="text-xs text-gray-400">Total Orders</p>
          <p className="text-lg font-semibold text-white">
            {data.reduce((sum, d) => sum + d.orders, 0)}
          </p>
        </div>
      </div>
    </div>
  );
});

export default RevenueChart;
