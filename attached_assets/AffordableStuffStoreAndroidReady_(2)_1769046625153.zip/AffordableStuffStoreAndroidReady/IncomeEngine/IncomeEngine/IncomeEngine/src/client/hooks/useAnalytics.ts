/**
 * ============================================================================
 * ANALYTICS DATA HOOK
 * Fetches analytics data using TanStack Query
 * ============================================================================
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiFetcher, apiMutate } from '../lib/queryClient';

// =============================================================================
// TYPES
// =============================================================================

export interface DateRange {
  start: Date;
  end: Date;
}

export interface RevenueDataPoint {
  date: string;
  revenue: number;
  orders: number;
  profit: number;
}

export interface RevenueSummary {
  totalRevenue: number;
  totalOrders: number;
  totalProfit: number;
  avgDailyRevenue: number;
  profitMargin: number;
}

export interface RevenueData {
  timeSeries: RevenueDataPoint[];
  summary: RevenueSummary;
  dateRange: {
    start: string;
    end: string;
    granularity: 'day' | 'week' | 'month';
  };
}

export interface PlatformStats {
  platform: string;
  revenue: number;
  orders: number;
  products: number;
  avgOrderValue: number;
  growth: number;
}

export interface PlatformData {
  platforms: PlatformStats[];
  totals: {
    revenue: number;
    orders: number;
    products: number;
    avgOrderValue: number;
  };
  dateRange: {
    start: string;
    end: string;
  };
}

export interface ProductPerformance {
  id: string;
  title: string;
  platform: string;
  revenue: number;
  unitsSold: number;
  views: number;
  conversionRate: number;
  trend: 'up' | 'down' | 'stable';
}

export interface ProductData {
  products: ProductPerformance[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
  };
  dateRange: {
    start: string;
    end: string;
  };
}

export interface TrendItem {
  metric: string;
  current: number;
  previous: number;
  change: number;
  changePercent: number;
  trend: 'up' | 'down' | 'stable';
}

export interface TrendData {
  trends: TrendItem[];
  comparison: string;
  dateRange: {
    start: string;
    end: string;
  };
}

export interface AnalyticsSummary {
  overview: {
    totalRevenue: number;
    totalOrders: number;
    totalProfit: number;
    profitMargin: number;
    avgOrderValue: number;
  };
  revenueTimeSeries: RevenueDataPoint[];
  platformBreakdown: PlatformStats[];
  topProducts: ProductPerformance[];
  trends: TrendItem[];
  dateRange: {
    start: string;
    end: string;
  };
}

export interface ExportOptions {
  format: 'csv' | 'pdf' | 'json';
  dataTypes?: ('revenue' | 'platforms' | 'products' | 'trends')[];
  dateRange?: DateRange;
}

// =============================================================================
// QUERY KEYS
// =============================================================================

export const ANALYTICS_KEYS = {
  all: ['analytics'] as const,
  revenue: (params?: { start?: string; end?: string; granularity?: string }) =>
    ['analytics', 'revenue', params] as const,
  platforms: (params?: { start?: string; end?: string }) =>
    ['analytics', 'platforms', params] as const,
  products: (params?: { start?: string; end?: string; sortBy?: string; limit?: number; platform?: string }) =>
    ['analytics', 'products', params] as const,
  trends: (params?: { start?: string; end?: string; compareWith?: string }) =>
    ['analytics', 'trends', params] as const,
  summary: (params?: { start?: string; end?: string }) =>
    ['analytics', 'summary', params] as const,
};

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function formatDateParam(date: Date): string {
  return date.toISOString();
}

function buildQueryString(params: Record<string, string | number | undefined>): string {
  const entries = Object.entries(params)
    .filter(([, value]) => value !== undefined)
    .map(([key, value]) => `${key}=${encodeURIComponent(String(value))}`);

  return entries.length > 0 ? `?${entries.join('&')}` : '';
}

// =============================================================================
// HOOKS
// =============================================================================

/**
 * Hook for fetching revenue analytics
 */
export function useRevenueAnalytics(options: {
  dateRange?: DateRange;
  granularity?: 'day' | 'week' | 'month';
  enabled?: boolean;
} = {}) {
  const { dateRange, granularity = 'day', enabled = true } = options;

  const params = {
    start: dateRange?.start ? formatDateParam(dateRange.start) : undefined,
    end: dateRange?.end ? formatDateParam(dateRange.end) : undefined,
    granularity,
  };

  return useQuery({
    queryKey: ANALYTICS_KEYS.revenue(params),
    queryFn: async () => {
      const queryString = buildQueryString(params);
      const response = await apiFetcher<{ success: boolean; data: RevenueData }>(
        `/api/analytics/revenue${queryString}`
      );
      return response.data;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    enabled,
  });
}

/**
 * Hook for fetching platform analytics
 */
export function usePlatformAnalytics(options: {
  dateRange?: DateRange;
  enabled?: boolean;
} = {}) {
  const { dateRange, enabled = true } = options;

  const params = {
    start: dateRange?.start ? formatDateParam(dateRange.start) : undefined,
    end: dateRange?.end ? formatDateParam(dateRange.end) : undefined,
  };

  return useQuery({
    queryKey: ANALYTICS_KEYS.platforms(params),
    queryFn: async () => {
      const queryString = buildQueryString(params);
      const response = await apiFetcher<{ success: boolean; data: PlatformData }>(
        `/api/analytics/platforms${queryString}`
      );
      return response.data;
    },
    staleTime: 5 * 60 * 1000,
    enabled,
  });
}

/**
 * Hook for fetching product performance analytics
 */
export function useProductAnalytics(options: {
  dateRange?: DateRange;
  sortBy?: 'revenue' | 'unitsSold' | 'views' | 'conversionRate';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  platform?: string;
  enabled?: boolean;
} = {}) {
  const {
    dateRange,
    sortBy = 'revenue',
    sortOrder = 'desc',
    limit = 20,
    platform,
    enabled = true,
  } = options;

  const params = {
    start: dateRange?.start ? formatDateParam(dateRange.start) : undefined,
    end: dateRange?.end ? formatDateParam(dateRange.end) : undefined,
    sortBy,
    sortOrder,
    limit,
    platform,
  };

  return useQuery({
    queryKey: ANALYTICS_KEYS.products(params),
    queryFn: async () => {
      const queryString = buildQueryString(params as Record<string, string | number | undefined>);
      const response = await apiFetcher<{ success: boolean; data: ProductData }>(
        `/api/analytics/products${queryString}`
      );
      return response.data;
    },
    staleTime: 5 * 60 * 1000,
    enabled,
  });
}

/**
 * Hook for fetching trend analytics
 */
export function useTrendAnalytics(options: {
  dateRange?: DateRange;
  compareWith?: 'previous_period' | 'last_year';
  enabled?: boolean;
} = {}) {
  const { dateRange, compareWith = 'previous_period', enabled = true } = options;

  const params = {
    start: dateRange?.start ? formatDateParam(dateRange.start) : undefined,
    end: dateRange?.end ? formatDateParam(dateRange.end) : undefined,
    compareWith,
  };

  return useQuery({
    queryKey: ANALYTICS_KEYS.trends(params),
    queryFn: async () => {
      const queryString = buildQueryString(params);
      const response = await apiFetcher<{ success: boolean; data: TrendData }>(
        `/api/analytics/trends${queryString}`
      );
      return response.data;
    },
    staleTime: 5 * 60 * 1000,
    enabled,
  });
}

/**
 * Hook for fetching complete analytics summary
 */
export function useAnalyticsSummary(options: {
  dateRange?: DateRange;
  enabled?: boolean;
} = {}) {
  const { dateRange, enabled = true } = options;

  const params = {
    start: dateRange?.start ? formatDateParam(dateRange.start) : undefined,
    end: dateRange?.end ? formatDateParam(dateRange.end) : undefined,
  };

  return useQuery({
    queryKey: ANALYTICS_KEYS.summary(params),
    queryFn: async () => {
      const queryString = buildQueryString(params);
      const response = await apiFetcher<{ success: boolean; data: AnalyticsSummary }>(
        `/api/analytics/summary${queryString}`
      );
      return response.data;
    },
    staleTime: 5 * 60 * 1000,
    enabled,
  });
}

/**
 * Hook for exporting analytics data
 */
export function useExportAnalytics() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (options: ExportOptions) => {
      const response = await apiMutate<{ success: boolean; downloadUrl?: string; message?: string }>(
        '/api/analytics/export',
        'POST',
        {
          format: options.format,
          dataTypes: options.dataTypes,
          dateRange: options.dateRange ? {
            start: formatDateParam(options.dateRange.start),
            end: formatDateParam(options.dateRange.end),
          } : undefined,
        }
      );
      return response;
    },
    onSuccess: () => {
      // Optionally invalidate queries after export
      queryClient.invalidateQueries({ queryKey: ANALYTICS_KEYS.all });
    },
  });
}

/**
 * Combined hook for all analytics with shared date range
 */
export function useAnalytics(dateRange?: DateRange) {
  const revenue = useRevenueAnalytics({ dateRange });
  const platforms = usePlatformAnalytics({ dateRange });
  const products = useProductAnalytics({ dateRange, limit: 10 });
  const trends = useTrendAnalytics({ dateRange });
  const summary = useAnalyticsSummary({ dateRange });

  const isLoading =
    revenue.isLoading ||
    platforms.isLoading ||
    products.isLoading ||
    trends.isLoading ||
    summary.isLoading;

  const isError =
    revenue.isError ||
    platforms.isError ||
    products.isError ||
    trends.isError ||
    summary.isError;

  const error =
    revenue.error ||
    platforms.error ||
    products.error ||
    trends.error ||
    summary.error;

  const refetchAll = async () => {
    await Promise.all([
      revenue.refetch(),
      platforms.refetch(),
      products.refetch(),
      trends.refetch(),
      summary.refetch(),
    ]);
  };

  return {
    revenue: revenue.data,
    platforms: platforms.data,
    products: products.data,
    trends: trends.data,
    summary: summary.data,
    isLoading,
    isError,
    error,
    refetchAll,
  };
}

export default {
  useRevenueAnalytics,
  usePlatformAnalytics,
  useProductAnalytics,
  useTrendAnalytics,
  useAnalyticsSummary,
  useExportAnalytics,
  useAnalytics,
};
