/**
 * ============================================================================
 * FRONTEND PERFORMANCE UTILITIES
 * Hooks and utilities for performance monitoring and optimization
 * ============================================================================
 *
 * Features:
 * - Performance timing hooks
 * - Component render profiling
 * - Bundle size awareness
 * - Web Vitals tracking
 * - Memory monitoring
 *
 * Usage:
 * ```typescript
 * import { usePerformance, useRenderCount, reportWebVitals } from './lib/performance';
 *
 * // Track component mount time
 * function MyComponent() {
 *   usePerformance('MyComponent');
 *   return <div>...</div>;
 * }
 *
 * // Track render count (debugging)
 * function ExpensiveComponent() {
 *   const renderCount = useRenderCount('ExpensiveComponent');
 *   return <div>Rendered {renderCount} times</div>;
 * }
 *
 * // Report Web Vitals
 * reportWebVitals(console.log);
 * ```
 */

import { useEffect, useRef, useCallback, useState, useMemo } from 'react';

// =============================================================================
// TYPES
// =============================================================================

export interface PerformanceMetrics {
  componentName: string;
  mountTime: number;
  renderCount: number;
  lastRenderTime: number;
  averageRenderTime: number;
}

export interface WebVitalsMetric {
  name: 'CLS' | 'FCP' | 'FID' | 'INP' | 'LCP' | 'TTFB';
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  delta: number;
  id: string;
}

export type WebVitalsReporter = (metric: WebVitalsMetric) => void;

// =============================================================================
// PERFORMANCE TRACKING
// =============================================================================

const performanceData = new Map<string, PerformanceMetrics>();

/**
 * Hook to track component performance
 * Measures mount time and tracks render count
 */
export function usePerformance(componentName: string): PerformanceMetrics {
  const mountTimeRef = useRef<number>(0);
  const renderStartRef = useRef<number>(performance.now());
  const renderCountRef = useRef<number>(0);
  const totalRenderTimeRef = useRef<number>(0);

  // Track mount time
  useEffect(() => {
    mountTimeRef.current = performance.now();

    // Cleanup: log metrics on unmount if in development
    return () => {
      if (import.meta.env.DEV) {
        const metrics = performanceData.get(componentName);
        if (metrics && metrics.renderCount > 5) {
          console.debug(`[Performance] ${componentName} unmounted:`, {
            totalRenders: metrics.renderCount,
            avgRenderTime: `${metrics.averageRenderTime.toFixed(2)}ms`,
          });
        }
      }
    };
  }, [componentName]);

  // Track each render
  useEffect(() => {
    const renderTime = performance.now() - renderStartRef.current;
    renderCountRef.current++;
    totalRenderTimeRef.current += renderTime;

    const metrics: PerformanceMetrics = {
      componentName,
      mountTime: mountTimeRef.current,
      renderCount: renderCountRef.current,
      lastRenderTime: renderTime,
      averageRenderTime: totalRenderTimeRef.current / renderCountRef.current,
    };

    performanceData.set(componentName, metrics);

    // Warn about slow renders in development
    if (import.meta.env.DEV && renderTime > 16) {
      console.warn(
        `[Performance] Slow render detected in ${componentName}: ${renderTime.toFixed(2)}ms`
      );
    }
  });

  // Reset render start time for next render
  renderStartRef.current = performance.now();

  return performanceData.get(componentName) || {
    componentName,
    mountTime: 0,
    renderCount: 0,
    lastRenderTime: 0,
    averageRenderTime: 0,
  };
}

/**
 * Simple hook to track render count (debugging)
 */
export function useRenderCount(label?: string): number {
  const renderCount = useRef(0);
  renderCount.current++;

  useEffect(() => {
    if (import.meta.env.DEV && label) {
      console.debug(`[RenderCount] ${label}: ${renderCount.current}`);
    }
  });

  return renderCount.current;
}

// =============================================================================
// DEBOUNCE & THROTTLE
// =============================================================================

/**
 * Debounce hook for expensive operations
 */
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(timer);
    };
  }, [value, delay]);

  return debouncedValue;
}

/**
 * Debounced callback hook
 */
export function useDebouncedCallback<T extends (...args: unknown[]) => unknown>(
  callback: T,
  delay: number
): T {
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>();
  const callbackRef = useRef(callback);

  // Update ref when callback changes
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  return useCallback(
    ((...args: unknown[]) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      timeoutRef.current = setTimeout(() => {
        callbackRef.current(...args);
      }, delay);
    }) as T,
    [delay]
  );
}

/**
 * Throttle hook for rate-limiting operations
 */
export function useThrottle<T>(value: T, interval: number): T {
  const [throttledValue, setThrottledValue] = useState<T>(value);
  const lastUpdated = useRef<number>(Date.now());

  useEffect(() => {
    const now = Date.now();
    const timeSinceLastUpdate = now - lastUpdated.current;

    if (timeSinceLastUpdate >= interval) {
      lastUpdated.current = now;
      setThrottledValue(value);
    } else {
      const timeout = setTimeout(() => {
        lastUpdated.current = Date.now();
        setThrottledValue(value);
      }, interval - timeSinceLastUpdate);

      return () => clearTimeout(timeout);
    }
  }, [value, interval]);

  return throttledValue;
}

// =============================================================================
// INTERSECTION OBSERVER (LAZY LOADING)
// =============================================================================

/**
 * Hook for lazy loading elements when they enter viewport
 */
export function useIntersectionObserver(
  options?: IntersectionObserverInit
): [React.RefObject<HTMLDivElement | null>, boolean] {
  const elementRef = useRef<HTMLDivElement>(null);
  const [isIntersecting, setIsIntersecting] = useState(false);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsIntersecting(true);
        // Once visible, stop observing
        observer.unobserve(element);
      }
    }, options);

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [options]);

  return [elementRef, isIntersecting];
}

// =============================================================================
// WEB VITALS
// =============================================================================

/**
 * Report Core Web Vitals
 * Requires the 'web-vitals' package for full support
 */
export async function reportWebVitals(
  onReport: WebVitalsReporter
): Promise<void> {
  // Use Performance Observer API for basic metrics
  if ('PerformanceObserver' in window) {
    // First Contentful Paint (FCP)
    try {
      const fcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        for (const entry of entries) {
          if (entry.name === 'first-contentful-paint') {
            const value = entry.startTime;
            onReport({
              name: 'FCP',
              value,
              rating: value < 1800 ? 'good' : value < 3000 ? 'needs-improvement' : 'poor',
              delta: value,
              id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`,
            });
          }
        }
      });
      fcpObserver.observe({ type: 'paint', buffered: true });
    } catch {
      // Observer not supported for this entry type
    }

    // Largest Contentful Paint (LCP)
    try {
      const lcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        if (lastEntry) {
          const value = lastEntry.startTime;
          onReport({
            name: 'LCP',
            value,
            rating: value < 2500 ? 'good' : value < 4000 ? 'needs-improvement' : 'poor',
            delta: value,
            id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`,
          });
        }
      });
      lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });
    } catch {
      // Observer not supported for this entry type
    }

    // Cumulative Layout Shift (CLS)
    try {
      let clsValue = 0;
      const clsObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries() as (PerformanceEntry & { hadRecentInput?: boolean; value?: number })[]) {
          if (!entry.hadRecentInput && entry.value) {
            clsValue += entry.value;
          }
        }
      });
      clsObserver.observe({ type: 'layout-shift', buffered: true });

      // Report CLS on page hide
      window.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden' && clsValue > 0) {
          onReport({
            name: 'CLS',
            value: clsValue,
            rating: clsValue < 0.1 ? 'good' : clsValue < 0.25 ? 'needs-improvement' : 'poor',
            delta: clsValue,
            id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`,
          });
        }
      }, { once: true });
    } catch {
      // Observer not supported for this entry type
    }
  }

  // Time to First Byte (TTFB)
  if (performance.getEntriesByType) {
    const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
    if (navigation) {
      const value = navigation.responseStart;
      onReport({
        name: 'TTFB',
        value,
        rating: value < 800 ? 'good' : value < 1800 ? 'needs-improvement' : 'poor',
        delta: value,
        id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`,
      });
    }
  }
}

// =============================================================================
// BUNDLE SIZE AWARENESS
// =============================================================================

/**
 * Log estimated bundle contribution (development only)
 * Helps identify large dependencies
 */
export function logBundleSize(
  moduleName: string,
  estimatedKB: number
): void {
  if (import.meta.env.DEV) {
    const color = estimatedKB > 100 ? 'color: red' : estimatedKB > 50 ? 'color: orange' : 'color: green';
    console.debug(
      `%c[Bundle] ${moduleName}: ~${estimatedKB}KB`,
      color
    );
  }
}

/**
 * Hook to warn about expensive re-renders
 */
export function useWhyDidYouRender<T extends Record<string, unknown>>(
  componentName: string,
  props: T
): void {
  const previousProps = useRef<T>();

  useEffect(() => {
    if (previousProps.current && import.meta.env.DEV) {
      const changedProps: string[] = [];

      Object.keys(props).forEach((key) => {
        if (previousProps.current![key] !== props[key]) {
          changedProps.push(key);
        }
      });

      if (changedProps.length > 0) {
        console.debug(`[WhyDidYouRender] ${componentName} re-rendered due to:`, changedProps);
      }
    }

    previousProps.current = props;
  });
}

// =============================================================================
// MEMORY MONITORING
// =============================================================================

interface MemoryInfo {
  usedJSHeapSize?: number;
  totalJSHeapSize?: number;
  jsHeapSizeLimit?: number;
}

/**
 * Get current memory usage (Chrome only)
 */
export function getMemoryUsage(): MemoryInfo | null {
  const perf = performance as Performance & { memory?: MemoryInfo };
  if (perf.memory) {
    return {
      usedJSHeapSize: perf.memory.usedJSHeapSize,
      totalJSHeapSize: perf.memory.totalJSHeapSize,
      jsHeapSizeLimit: perf.memory.jsHeapSizeLimit,
    };
  }
  return null;
}

/**
 * Hook to monitor memory usage
 */
export function useMemoryMonitor(
  intervalMs: number = 10000
): MemoryInfo | null {
  const [memory, setMemory] = useState<MemoryInfo | null>(null);

  useEffect(() => {
    const checkMemory = () => {
      const usage = getMemoryUsage();
      if (usage) {
        setMemory(usage);

        // Warn if memory is getting high
        if (import.meta.env.DEV && usage.usedJSHeapSize && usage.jsHeapSizeLimit) {
          const usagePercent = (usage.usedJSHeapSize / usage.jsHeapSizeLimit) * 100;
          if (usagePercent > 75) {
            console.warn(
              `[Memory] High usage: ${Math.round(usage.usedJSHeapSize / 1024 / 1024)}MB / ${Math.round(usage.jsHeapSizeLimit / 1024 / 1024)}MB (${usagePercent.toFixed(1)}%)`
            );
          }
        }
      }
    };

    checkMemory();
    const interval = setInterval(checkMemory, intervalMs);

    return () => clearInterval(interval);
  }, [intervalMs]);

  return memory;
}

// =============================================================================
// COMPUTED VALUES WITH MEMOIZATION
// =============================================================================

/**
 * Memoize expensive computations with custom equality check
 */
export function useDeepMemo<T>(
  factory: () => T,
  deps: unknown[]
): T {
  const ref = useRef<{ deps: unknown[]; value: T }>();

  if (!ref.current || !shallowEqual(ref.current.deps, deps)) {
    ref.current = { deps, value: factory() };
  }

  return ref.current.value;
}

function shallowEqual(a: unknown[], b: unknown[]): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (!Object.is(a[i], b[i])) return false;
  }
  return true;
}

// =============================================================================
// PERFORMANCE MARKS & MEASURES
// =============================================================================

/**
 * Create a performance marker
 */
export function mark(name: string): void {
  if (performance.mark) {
    performance.mark(name);
  }
}

/**
 * Measure between two marks
 */
export function measure(
  name: string,
  startMark: string,
  endMark?: string
): PerformanceMeasure | undefined {
  if (performance.measure) {
    try {
      const measureOptions: PerformanceMeasureOptions = {
        start: startMark,
      };
      if (endMark) {
        measureOptions.end = endMark;
      }
      return performance.measure(name, measureOptions);
    } catch {
      // Marks may not exist
      return undefined;
    }
  }
  return undefined;
}

/**
 * Hook for timing a component's lifecycle
 */
export function useLifecycleTiming(componentName: string): void {
  useEffect(() => {
    mark(`${componentName}:mount`);

    return () => {
      mark(`${componentName}:unmount`);
      const duration = measure(
        `${componentName}:lifecycle`,
        `${componentName}:mount`,
        `${componentName}:unmount`
      );

      if (import.meta.env.DEV && duration) {
        console.debug(
          `[Lifecycle] ${componentName} was mounted for ${duration.duration.toFixed(0)}ms`
        );
      }
    };
  }, [componentName]);
}

// =============================================================================
// EXPORTS
// =============================================================================

export default {
  usePerformance,
  useRenderCount,
  useDebounce,
  useDebouncedCallback,
  useThrottle,
  useIntersectionObserver,
  reportWebVitals,
  logBundleSize,
  useWhyDidYouRender,
  getMemoryUsage,
  useMemoryMonitor,
  useDeepMemo,
  mark,
  measure,
  useLifecycleTiming,
};
