/**
 * ============================================================================
 * PLATFORM COMPARISON COMPONENT
 * Bar chart comparing revenue/performance across platforms
 * ============================================================================
 */

import React, { memo, useMemo } from 'react';
import type { PlatformStats } from '../../hooks/useAnalytics';
import { PLATFORM_COLORS, formatChartValue, formatCompactNumber } from '../../hooks/useChartData';

interface PlatformComparisonProps {
  platforms: PlatformStats[];
  metric?: 'revenue' | 'orders' | 'products';
  chartType?: 'bar' | 'horizontal' | 'donut';
  showGrowth?: boolean;
  limit?: number;
  height?: number;
  className?: string;
}

/**
 * Platform comparison chart with multiple visualization options
 */
export const PlatformComparison = memo(function PlatformComparison({
  platforms,
  metric = 'revenue',
  chartType = 'horizontal',
  showGrowth = true,
  limit = 8,
  height = 400,
  className = '',
}: PlatformComparisonProps) {
  const chartData = useMemo(() => {
    if (!platforms || platforms.length === 0) return null;

    const sortedPlatforms = [...platforms]
      .sort((a, b) => b[metric] - a[metric])
      .slice(0, limit);

    const maxValue = Math.max(...sortedPlatforms.map(p => p[metric]));
    const totalValue = sortedPlatforms.reduce((sum, p) => sum + p[metric], 0);

    return {
      platforms: sortedPlatforms,
      maxValue,
      totalValue,
    };
  }, [platforms, metric, limit]);

  if (!chartData) {
    return (
      <div className={`flex items-center justify-center ${className}`} style={{ height }}>
        <p className="text-gray-400">No platform data available</p>
      </div>
    );
  }

  const getColor = (platform: string) =>
    PLATFORM_COLORS[platform] || '#6b7280';

  const formatMetricValue = (value: number) => {
    if (metric === 'revenue') return formatChartValue(value, 'currency');
    return formatCompactNumber(value);
  };

  const renderHorizontalBar = () => (
    <div className="space-y-4">
      {chartData.platforms.map((platform, index) => {
        const percentage = (platform[metric] / chartData.maxValue) * 100;
        const color = getColor(platform.platform);

        return (
          <div key={platform.platform} className="group">
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-white">{platform.platform}</span>
                {showGrowth && (
                  <span
                    className={`text-xs ${
                      platform.growth >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    {platform.growth >= 0 ? '+' : ''}{platform.growth.toFixed(1)}%
                  </span>
                )}
              </div>
              <span className="text-sm text-gray-400">
                {formatMetricValue(platform[metric])}
              </span>
            </div>
            <div className="relative h-8 bg-slate-700/50 rounded-lg overflow-hidden">
              <div
                className="absolute h-full rounded-lg transition-all duration-500 ease-out"
                style={{
                  width: `${percentage}%`,
                  background: `linear-gradient(90deg, ${color} 0%, ${color}cc 100%)`,
                }}
              />
              <div className="absolute inset-0 flex items-center px-3">
                <span className="text-xs text-white font-medium opacity-80">
                  {((platform[metric] / chartData.totalValue) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  const renderDonut = () => {
    const radius = 100;
    const strokeWidth = 30;
    const normalizedRadius = radius - strokeWidth / 2;
    const circumference = 2 * Math.PI * normalizedRadius;

    let currentAngle = 0;

    return (
      <div className="flex flex-col items-center">
        <svg width={radius * 2} height={radius * 2} className="transform -rotate-90">
          {chartData.platforms.map((platform) => {
            const percentage = platform[metric] / chartData.totalValue;
            const strokeDasharray = `${percentage * circumference} ${circumference}`;
            const strokeDashoffset = -currentAngle * circumference;
            currentAngle += percentage;

            return (
              <circle
                key={platform.platform}
                stroke={getColor(platform.platform)}
                fill="none"
                strokeWidth={strokeWidth}
                r={normalizedRadius}
                cx={radius}
                cy={radius}
                style={{
                  strokeDasharray,
                  strokeDashoffset,
                }}
              />
            );
          })}
        </svg>

        {/* Center text */}
        <div className="absolute flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-white">
            {formatMetricValue(chartData.totalValue)}
          </span>
          <span className="text-xs text-gray-400">Total {metric}</span>
        </div>

        {/* Legend */}
        <div className="mt-6 grid grid-cols-2 gap-x-8 gap-y-2">
          {chartData.platforms.map((platform) => (
            <div key={platform.platform} className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: getColor(platform.platform) }}
              />
              <span className="text-sm text-gray-400">{platform.platform}</span>
              <span className="text-sm text-white ml-auto">
                {((platform[metric] / chartData.totalValue) * 100).toFixed(0)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderVerticalBar = () => {
    const barWidth = Math.min(60, 600 / chartData.platforms.length - 10);

    return (
      <div className="flex flex-col h-full">
        <div className="flex-1 flex items-end justify-center gap-3 px-4">
          {chartData.platforms.map((platform) => {
            const percentage = (platform[metric] / chartData.maxValue) * 100;
            const color = getColor(platform.platform);

            return (
              <div
                key={platform.platform}
                className="flex flex-col items-center group"
                style={{ width: barWidth }}
              >
                {/* Value label */}
                <span className="text-xs text-gray-400 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {formatMetricValue(platform[metric])}
                </span>

                {/* Bar */}
                <div
                  className="w-full rounded-t-lg transition-all duration-500 relative"
                  style={{
                    height: `${Math.max(percentage, 5)}%`,
                    maxHeight: '90%',
                    background: `linear-gradient(180deg, ${color} 0%, ${color}99 100%)`,
                  }}
                >
                  {/* Growth indicator */}
                  {showGrowth && (
                    <div
                      className={`absolute -top-6 left-1/2 -translate-x-1/2 text-xs ${
                        platform.growth >= 0 ? 'text-green-400' : 'text-red-400'
                      }`}
                    >
                      {platform.growth >= 0 ? '+' : ''}{platform.growth.toFixed(0)}%
                    </div>
                  )}
                </div>

                {/* Label */}
                <span
                  className="text-xs text-gray-400 mt-2 text-center truncate w-full"
                  title={platform.platform}
                >
                  {platform.platform.length > 8
                    ? platform.platform.substring(0, 8) + '...'
                    : platform.platform}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className={`${className}`} style={{ minHeight: height }}>
      {/* Metric selector could be added here */}
      <div className="mb-4 flex items-center justify-between">
        <h4 className="text-sm text-gray-400">
          By {metric.charAt(0).toUpperCase() + metric.slice(1)}
        </h4>
        <div className="text-right">
          <p className="text-lg font-semibold text-white">
            {formatMetricValue(chartData.totalValue)}
          </p>
          <p className="text-xs text-gray-400">Total across all platforms</p>
        </div>
      </div>

      {/* Chart */}
      <div style={{ height: height - 60 }}>
        {chartType === 'horizontal' && renderHorizontalBar()}
        {chartType === 'donut' && renderDonut()}
        {chartType === 'bar' && renderVerticalBar()}
      </div>
    </div>
  );
});

export default PlatformComparison;
