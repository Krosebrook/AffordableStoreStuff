import React, { useState } from 'react';

interface ToggleProps {
  enabled: boolean;
  onChange: (enabled: boolean) => void;
}

function Toggle({ enabled, onChange }: ToggleProps) {
  return (
    <button
      onClick={() => onChange(!enabled)}
      className={`w-12 h-6 rounded-full relative transition-colors ${
        enabled ? 'bg-indigo-600' : 'bg-slate-600'
      }`}
      role="switch"
      aria-checked={enabled}
    >
      <span
        className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
          enabled ? 'right-1' : 'left-1'
        }`}
      />
    </button>
  );
}

/**
 * Settings page for app configuration
 */
export function SettingsPage() {
  const [pushNotifications, setPushNotifications] = useState(true);
  const [autoApprove, setAutoApprove] = useState(false);
  const [dailyLimit, setDailyLimit] = useState(25);
  const [saving, setSaving] = useState(false);

  const handleSaveLimit = async () => {
    setSaving(true);
    try {
      // API call would go here
      await new Promise((resolve) => setTimeout(resolve, 500));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold">Settings</h2>

      <div className="bg-slate-800/50 rounded-xl divide-y divide-slate-700">
        <div className="p-4 flex justify-between items-center">
          <div>
            <p className="font-medium">Push Notifications</p>
            <p className="text-sm text-gray-400">Get alerts on your phone</p>
          </div>
          <Toggle enabled={pushNotifications} onChange={setPushNotifications} />
        </div>

        <div className="p-4 flex justify-between items-center">
          <div>
            <p className="font-medium">Auto-Approve</p>
            <p className="text-sm text-gray-400">After 50 approved products</p>
          </div>
          <Toggle enabled={autoApprove} onChange={setAutoApprove} />
        </div>

        <div className="p-4">
          <p className="font-medium">Daily Budget Limit</p>
          <div className="flex gap-2 mt-2">
            <input
              type="number"
              value={dailyLimit}
              onChange={(e) => setDailyLimit(Number(e.target.value))}
              className="flex-1 bg-slate-700 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              onClick={handleSaveLimit}
              disabled={saving}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg disabled:opacity-50 transition-colors"
            >
              {saving ? '...' : 'Save'}
            </button>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-slate-800/50 rounded-xl p-4">
        <h3 className="font-semibold text-red-400 mb-3">Danger Zone</h3>
        <button className="w-full py-2 border border-red-500 text-red-400 rounded-lg hover:bg-red-500/10 transition-colors">
          Reset All Circuit Breakers
        </button>
      </div>

      {/* App Info */}
      <div className="bg-slate-800/50 rounded-xl p-4">
        <div className="flex justify-between mb-2">
          <span className="text-sm text-gray-400">App Version</span>
          <span className="font-medium">1.0.0</span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm text-gray-400">Environment</span>
          <span className="font-medium">
            {import.meta.env.MODE || 'development'}
          </span>
        </div>
      </div>
    </div>
  );
}

export default SettingsPage;
