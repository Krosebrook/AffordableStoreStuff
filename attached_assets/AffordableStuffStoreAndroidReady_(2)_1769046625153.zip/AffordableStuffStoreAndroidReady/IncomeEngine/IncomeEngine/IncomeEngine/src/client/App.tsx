import React, { lazy, Suspense } from 'react';
import { Routes, Route, NavLink } from 'react-router-dom';

// Components
import { StatusBadge } from './components/StatusBadge';
import { LoadingSpinner } from './components/LoadingSpinner';

// Hooks
import { useResponsive } from './hooks/useResponsive';

// Lazy-loaded pages for code splitting
import { LazyRoutes, preloadRoute } from './lib/lazy-routes';

// Mobile App (lazy loaded)
const MobileApp = lazy(() => import('./mobile/App'));

// Route key mapping for preloading
const routeKeyMap: Record<string, 'dashboard' | 'approvals' | 'budget' | 'settings' | 'analytics'> = {
  '/': 'dashboard',
  '/approvals': 'approvals',
  '/budget': 'budget',
  '/settings': 'settings',
  '/analytics': 'analytics',
};

// Navigation item component with preloading on hover
function NavItem({ to, icon, label }: { to: string; icon: string; label: string }) {
  const handleMouseEnter = () => {
    const routeKey = routeKeyMap[to];
    if (routeKey) {
      preloadRoute(routeKey);
    }
  };

  return (
    <NavLink
      to={to}
      onMouseEnter={handleMouseEnter}
      className={({ isActive }) =>
        `flex flex-col items-center py-2 px-4 rounded-lg transition-colors ${
          isActive ? 'text-indigo-400' : 'text-gray-400'
        }`
      }
    >
      <span className="text-xl mb-1">{icon}</span>
      <span className="text-xs">{label}</span>
    </NavLink>
  );
}

/**
 * Desktop layout component
 * Renders the standard web layout with header and bottom navigation
 */
function DesktopLayout(): React.ReactElement {
  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col">
      {/* Header */}
      <header className="bg-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
            <svg
              className="w-5 h-5 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
              />
            </svg>
          </div>
          <h1 className="font-bold">Income Engine</h1>
        </div>
        <StatusBadge status="ok" />
      </header>

      {/* Main Content - Uses lazy-loaded routes for code splitting */}
      <main className="flex-1 pb-20">
        <Routes>
          <Route path="/" element={<LazyRoutes.Dashboard />} />
          <Route path="/approvals" element={<LazyRoutes.Approvals />} />
          <Route path="/budget" element={<LazyRoutes.Budget />} />
          <Route path="/settings" element={<LazyRoutes.Settings />} />
          <Route path="/analytics" element={<LazyRoutes.Analytics />} />
          <Route path="/alerts" element={<LazyRoutes.Dashboard />} />
        </Routes>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 px-4 py-2 safe-area-pb">
        <div className="flex justify-around items-center">
          <NavItem to="/" icon="home" label="Dashboard" />
          <NavItem to="/analytics" icon="chart" label="Analytics" />
          <NavItem to="/approvals" icon="clipboard" label="Approvals" />
          <NavItem to="/budget" icon="wallet" label="Budget" />
          <NavItem to="/settings" icon="cog" label="Settings" />
        </div>
      </nav>
    </div>
  );
}

/**
 * Main application component
 * Renders mobile or desktop layout based on viewport and platform
 */
function App(): React.ReactElement {
  const { isMobile, isCapacitor } = useResponsive();

  // Use mobile layout for mobile viewport or when running in Capacitor
  const useMobileLayout = isMobile || isCapacitor;

  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-900 flex items-center justify-center">
          <LoadingSpinner />
        </div>
      }
    >
      {useMobileLayout ? <MobileApp /> : <DesktopLayout />}
    </Suspense>
  );
}

export default App;
