import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  resetKey?: string | number;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * Global Error Boundary component
 * Catches JavaScript errors anywhere in the child component tree
 */
export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log error to console
    console.error('ErrorBoundary caught an error:', error, errorInfo);

    // Call custom error handler if provided
    this.props.onError?.(error, errorInfo);

    // In production, you would send to error tracking service
    // e.g., Sentry.captureException(error, { extra: { componentStack: errorInfo.componentStack } });
  }

  componentDidUpdate(prevProps: Props) {
    // Reset error state when resetKey changes
    if (this.state.hasError && prevProps.resetKey !== this.props.resetKey) {
      this.setState({ hasError: false, error: null });
    }
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      // Custom fallback UI
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Default error UI
      return (
        <div className="p-8 text-center">
          <div className="text-4xl mb-4">⚠️</div>
          <h2 className="text-xl font-bold text-red-400 mb-2">Something went wrong</h2>
          <p className="text-gray-400 mb-4">
            {this.state.error?.message || 'An unexpected error occurred'}
          </p>
          <button
            onClick={this.handleRetry}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
          >
            Try Again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

/**
 * Feature-specific error fallback component
 */
export function FeatureErrorFallback({
  title,
  message,
  onRetry,
}: {
  title: string;
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="bg-slate-800/50 rounded-xl p-6 text-center">
      <div className="text-3xl mb-3">😕</div>
      <h3 className="font-semibold text-red-400 mb-2">{title}</h3>
      <p className="text-sm text-gray-400 mb-4">
        {message || 'This feature is temporarily unavailable'}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm transition-colors"
        >
          Retry
        </button>
      )}
    </div>
  );
}

/**
 * Dashboard-specific error fallback
 */
export function DashboardErrorFallback() {
  return (
    <FeatureErrorFallback
      title="Dashboard Unavailable"
      message="Unable to load the dashboard. Please check your connection and try again."
      onRetry={() => window.location.reload()}
    />
  );
}

/**
 * Approvals-specific error fallback
 */
export function ApprovalsErrorFallback() {
  return (
    <FeatureErrorFallback
      title="Approvals Unavailable"
      message="Unable to load pending approvals. Please try again later."
      onRetry={() => window.location.reload()}
    />
  );
}

/**
 * Budget-specific error fallback
 */
export function BudgetErrorFallback() {
  return (
    <FeatureErrorFallback
      title="Budget Data Unavailable"
      message="Unable to load budget information. Please try again later."
      onRetry={() => window.location.reload()}
    />
  );
}

export default ErrorBoundary;
