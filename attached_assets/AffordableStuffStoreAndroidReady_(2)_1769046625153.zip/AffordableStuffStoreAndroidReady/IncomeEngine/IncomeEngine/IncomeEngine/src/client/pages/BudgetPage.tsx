import React from 'react';
import { useSystemStatus } from '../hooks/useSystemStatus';
import { LoadingSpinner } from '../components/LoadingSpinner';

/**
 * Budget overview page showing spending limits and usage
 */
export function BudgetPage() {
  const { status, loading } = useSystemStatus();

  if (loading || !status) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold">Budget Overview</h2>

      {status.budget.map((b) => (
        <div key={b.period} className="bg-slate-800/50 rounded-xl p-4">
          <div className="flex justify-between items-center mb-3">
            <span className="font-medium capitalize">{b.period} Budget</span>
            <span
              className={`text-sm px-2 py-0.5 rounded ${
                b.isExceeded
                  ? 'bg-red-500/20 text-red-400'
                  : b.isWarning
                  ? 'bg-yellow-500/20 text-yellow-400'
                  : 'bg-green-500/20 text-green-400'
              }`}
            >
              {b.isExceeded ? 'Exceeded' : b.isWarning ? 'Warning' : 'OK'}
            </span>
          </div>

          <div className="flex justify-between text-2xl font-bold mb-2">
            <span>${b.currentSpend.toFixed(2)}</span>
            <span className="text-gray-500">/ ${b.limit.toFixed(2)}</span>
          </div>

          <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                b.percentUsed >= 100
                  ? 'bg-red-500'
                  : b.percentUsed >= 80
                  ? 'bg-yellow-500'
                  : 'bg-green-500'
              }`}
              style={{ width: `${Math.min(b.percentUsed, 100)}%` }}
            />
          </div>

          <p className="text-sm text-gray-400 mt-2">
            ${b.remainingBudget.toFixed(2)} remaining
          </p>
        </div>
      ))}

      {/* Circuit Breaker Status */}
      {status.circuitBreakers && Object.keys(status.circuitBreakers).length > 0 && (
        <div className="bg-slate-800/50 rounded-xl p-4">
          <h3 className="font-semibold mb-3">Circuit Breakers</h3>
          <div className="space-y-2">
            {Object.entries(status.circuitBreakers).map(([name, state]) => (
              <div key={name} className="flex justify-between items-center">
                <span className="text-sm text-gray-400 capitalize">
                  {name.replace(/_/g, ' ')}
                </span>
                <span
                  className={`text-sm px-2 py-0.5 rounded ${
                    state.isOpen
                      ? 'bg-red-500/20 text-red-400'
                      : 'bg-green-500/20 text-green-400'
                  }`}
                >
                  {state.isOpen ? 'OPEN' : 'CLOSED'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default BudgetPage;
