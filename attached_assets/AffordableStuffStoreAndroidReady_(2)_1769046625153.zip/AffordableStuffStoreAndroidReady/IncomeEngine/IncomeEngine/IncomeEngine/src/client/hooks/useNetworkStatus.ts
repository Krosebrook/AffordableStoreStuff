import { useState, useEffect, useCallback, useRef } from 'react';

interface NetworkStatus {
  /** Whether the device is currently online */
  isOnline: boolean;
  /** Whether the device was previously offline (for showing reconnected message) */
  wasOffline: boolean;
  /** Network connection type if available */
  connectionType: string | null;
  /** Effective network type (e.g., '4g', '3g', 'slow-2g') */
  effectiveType: string | null;
  /** Whether the connection is metered (limited data) */
  saveData: boolean;
  /** Estimated downlink speed in Mbps */
  downlink: number | null;
  /** Estimated round-trip time in ms */
  rtt: number | null;
}

/**
 * Hook for monitoring network status
 * Provides online/offline detection and connection quality info
 */
export function useNetworkStatus(): NetworkStatus {
  const [isOnline, setIsOnline] = useState(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [wasOffline, setWasOffline] = useState(false);
  const [connectionInfo, setConnectionInfo] = useState<Omit<NetworkStatus, 'isOnline' | 'wasOffline'>>({
    connectionType: null,
    effectiveType: null,
    saveData: false,
    downlink: null,
    rtt: null,
  });

  const wasOfflineTimeout = useRef<NodeJS.Timeout | null>(null);

  const updateConnectionInfo = useCallback(() => {
    const connection = (navigator as any).connection ||
                       (navigator as any).mozConnection ||
                       (navigator as any).webkitConnection;

    if (connection) {
      setConnectionInfo({
        connectionType: connection.type || null,
        effectiveType: connection.effectiveType || null,
        saveData: connection.saveData || false,
        downlink: connection.downlink || null,
        rtt: connection.rtt || null,
      });
    }
  }, []);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setWasOffline(true);

      // Clear the "was offline" flag after showing reconnected message
      wasOfflineTimeout.current = setTimeout(() => {
        setWasOffline(false);
      }, 3000);

      updateConnectionInfo();
    };

    const handleOffline = () => {
      setIsOnline(false);
      // Clear any pending timeout
      if (wasOfflineTimeout.current) {
        clearTimeout(wasOfflineTimeout.current);
      }
    };

    // Initial connection info
    updateConnectionInfo();

    // Add event listeners
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Listen for connection changes
    const connection = (navigator as any).connection;
    if (connection) {
      connection.addEventListener('change', updateConnectionInfo);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);

      if (connection) {
        connection.removeEventListener('change', updateConnectionInfo);
      }

      if (wasOfflineTimeout.current) {
        clearTimeout(wasOfflineTimeout.current);
      }
    };
  }, [updateConnectionInfo]);

  return {
    isOnline,
    wasOffline,
    ...connectionInfo,
  };
}

/**
 * Check if network is slow (2G or slow-2g)
 */
export function isSlowNetwork(effectiveType: string | null): boolean {
  return effectiveType === '2g' || effectiveType === 'slow-2g';
}

/**
 * Check if we should reduce data usage
 */
export function shouldReduceData(status: NetworkStatus): boolean {
  return status.saveData || isSlowNetwork(status.effectiveType);
}

export default useNetworkStatus;
