import React, { useCallback, useState } from 'react';

import { useApprovalsQuery, useApproveProduct, useRejectProduct } from '../../hooks/useQueries';
import { useOfflineApproval } from '../../hooks/useOfflineSync';
import { useNetworkStatus } from '../../hooks/useNetworkStatus';
import { PullToRefresh } from '../../components/mobile/PullToRefresh';
import { SwipeableCard } from '../../components/mobile/SwipeableCard';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import type { PendingApproval } from '../../types';

/**
 * Risk level badge component
 */
function RiskBadge({ level }: { level: 'low' | 'medium' | 'high' }): React.ReactElement {
  const colors = {
    low: 'bg-green-500/20 text-green-400',
    medium: 'bg-yellow-500/20 text-yellow-400',
    high: 'bg-red-500/20 text-red-400',
  };

  return (
    <span className={`text-xs px-2 py-0.5 rounded-full ${colors[level]}`}>
      {level}
    </span>
  );
}

/**
 * Approval card component
 */
function ApprovalCard({
  item,
  onApprove,
  onReject,
  isLoading,
}: {
  item: PendingApproval;
  onApprove: () => void;
  onReject: () => void;
  isLoading: boolean;
}): React.ReactElement {
  return (
    <SwipeableCard
      onSwipeRight={onApprove}
      onSwipeLeft={onReject}
      rightLabel="Approve"
      leftLabel="Reject"
      disabled={isLoading}
      className="mb-3"
    >
      <div className="p-4">
        <div className="flex gap-3">
          {/* Thumbnail */}
          <div className="w-16 h-16 bg-slate-700 rounded-lg flex-shrink-0 flex items-center justify-center overflow-hidden">
            {item.metadata?.thumbnailUrl ? (
              <img
                src={item.metadata.thumbnailUrl as string}
                alt={item.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <svg
                className="w-8 h-8 text-gray-500"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
                />
              </svg>
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-medium truncate">{item.title || 'Untitled Product'}</h3>
              <RiskBadge level={item.riskLevel} />
            </div>
            <p className="text-sm text-gray-400">{item.type}</p>
            <p className="text-xs text-gray-500 mt-1 line-clamp-2">{item.reason}</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 mt-3">
          <button
            onClick={onApprove}
            disabled={isLoading}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 active:bg-green-800 rounded-lg text-sm font-medium disabled:opacity-50 transition-colors"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Approve
              </>
            )}
          </button>
          <button
            onClick={onReject}
            disabled={isLoading}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-lg text-sm font-medium disabled:opacity-50 transition-colors"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
                Reject
              </>
            )}
          </button>
        </div>
      </div>
    </SwipeableCard>
  );
}

/**
 * Mobile approvals screen
 * Shows pending products with swipe-to-approve functionality
 */
export function ApprovalsScreen(): React.ReactElement {
  const { data: approvals, isLoading, error, refetch, isFetching } = useApprovalsQuery();
  const approveProduct = useApproveProduct();
  const rejectProduct = useRejectProduct();
  const { isOnline } = useNetworkStatus();
  const { approve: offlineApprove, reject: offlineReject } = useOfflineApproval();

  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  const handleRefresh = useCallback(async () => {
    await refetch();
  }, [refetch]);

  const handleApprove = useCallback(
    async (id: string) => {
      setActionLoadingId(id);
      try {
        if (isOnline) {
          await approveProduct.mutateAsync({ id });
        } else {
          await offlineApprove(id);
        }
      } catch (err) {
        console.error('Approve failed:', err);
      } finally {
        setActionLoadingId(null);
      }
    },
    [isOnline, approveProduct, offlineApprove]
  );

  const handleReject = useCallback(
    async (id: string) => {
      setActionLoadingId(id);
      try {
        if (isOnline) {
          await rejectProduct.mutateAsync({ id, reason: 'Rejected via mobile dashboard' });
        } else {
          await offlineReject(id, 'Rejected via mobile dashboard');
        }
      } catch (err) {
        console.error('Reject failed:', err);
      } finally {
        setActionLoadingId(null);
      }
    },
    [isOnline, rejectProduct, offlineReject]
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4">
        <div className="bg-red-500/20 border border-red-500 rounded-xl p-4">
          <h3 className="font-semibold text-red-400">Error Loading Approvals</h3>
          <p className="text-sm text-gray-400 mt-1">
            {error instanceof Error ? error.message : 'Failed to load'}
          </p>
          <button
            onClick={() => refetch()}
            className="mt-3 px-4 py-2 bg-red-500 rounded-lg text-sm font-medium"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh} isRefreshing={isFetching} className="h-full">
      <div className="p-4">
        {/* Header Info */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-gray-400">
              {approvals?.length ?? 0} pending approval{(approvals?.length ?? 0) !== 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Swipe to approve/reject</span>
          </div>
        </div>

        {/* Empty State */}
        {(!approvals || approvals.length === 0) && (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                className="w-10 h-10 text-green-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <h3 className="font-semibold text-lg mb-1">All Caught Up!</h3>
            <p className="text-gray-400 text-sm">No products waiting for approval</p>
          </div>
        )}

        {/* Approval List */}
        {approvals && approvals.length > 0 && (
          <div>
            {approvals.map((item) => (
              <ApprovalCard
                key={item.id}
                item={item}
                onApprove={() => handleApprove(item.id)}
                onReject={() => handleReject(item.id)}
                isLoading={actionLoadingId === item.id}
              />
            ))}
          </div>
        )}

        {/* Offline Note */}
        {!isOnline && approvals && approvals.length > 0 && (
          <div className="mt-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
            <p className="text-sm text-amber-400">
              You are offline. Actions will sync when you reconnect.
            </p>
          </div>
        )}
      </div>
    </PullToRefresh>
  );
}

export default ApprovalsScreen;
