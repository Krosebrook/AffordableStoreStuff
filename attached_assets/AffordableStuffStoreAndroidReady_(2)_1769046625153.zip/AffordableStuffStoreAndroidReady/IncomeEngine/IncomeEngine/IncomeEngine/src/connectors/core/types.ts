/**
 * Core types for the unified connector system
 * All platform adapters implement these shared interfaces
 */

// ============================================================================
// Product Types
// ============================================================================

export type ProductType =
  | 't-shirt'
  | 'hoodie'
  | 'mug'
  | 'poster'
  | 'sticker'
  | 'phone-case'
  | 'tote-bag'
  | 'book'
  | 'ebook'
  | 'digital-download'
  | 'font'
  | 'graphic'
  | 'template'
  | 'other';

export type ProductStatus = 'draft' | 'active' | 'archived' | 'pending';

export interface ProductImage {
  id: string;
  url: string;
  alt?: string;
  position: number;
  width?: number;
  height?: number;
  isPrimary: boolean;
}

export interface ProductVariant {
  id: string;
  sku?: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  inventoryQuantity?: number;
  options: Record<string, string>;
  weight?: number;
  weightUnit?: 'g' | 'kg' | 'oz' | 'lb';
}

export interface PricingInfo {
  price: number;
  compareAtPrice?: number;
  currency: string;
  costPerItem?: number;
  taxable: boolean;
}

export interface NormalizedProduct {
  id: string;
  externalId?: string;
  title: string;
  description: string;
  productType: ProductType;
  images: ProductImage[];
  variants: ProductVariant[];
  pricing: PricingInfo;
  tags: string[];
  metadata: Record<string, unknown>;
  platformData: Record<string, unknown>;
  status: ProductStatus;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProductInput {
  title: string;
  description: string;
  productType: ProductType;
  images: Omit<ProductImage, 'id'>[];
  variants?: Omit<ProductVariant, 'id'>[];
  pricing: Omit<PricingInfo, 'currency'> & { currency?: string };
  tags?: string[];
  metadata?: Record<string, unknown>;
}

// ============================================================================
// Connector Types
// ============================================================================

export type WorkflowGroup = 'pod_digital' | 'marketplace';
export type ConnectorType = 'api_key' | 'oauth2' | 'playwright';
export type ConnectionStatus = 'connected' | 'disconnected' | 'error' | 'expired';

export interface RateLimitConfig {
  requestsPerSecond?: number;
  requestsPerMinute?: number;
  requestsPerHour?: number;
  requestsPer10Seconds?: number;
  bucketSize?: number;
}

export interface ConnectorCapabilities {
  supportsOAuth: boolean;
  supportsBulkOperations: boolean;
  supportsWebhooks: boolean;
  supportsInventorySync: boolean;
  supportsOrderFulfillment: boolean;
  supportsAnalytics: boolean;
  maxProductsPerRequest: number;
  rateLimits: RateLimitConfig;
}

export interface PlatformLimits {
  maxTitleLength: number;
  maxDescriptionLength: number;
  maxImages: number;
  maxTags: number;
  maxVariants: number;
  allowedImageFormats: string[];
  maxImageSizeMB: number;
}

export interface PlatformRequirements {
  requiredFields: string[];
  requiredImageDimensions?: { width: number; height: number };
  requiredCategories?: boolean;
  requiredShippingProfile?: boolean;
}

// ============================================================================
// Authentication Types
// ============================================================================

export interface AuthToken {
  accessToken: string;
  refreshToken?: string;
  expiresAt?: Date;
  tokenType: 'Bearer' | 'Basic';
  scopes?: string[];
}

export interface OAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  scopes: string[];
  authUrl: string;
  tokenUrl: string;
}

export interface ApiKeyConfig {
  apiKey: string;
  headerName?: string;
  queryParamName?: string;
}

export interface CredentialConfig {
  type: ConnectorType;
  oauth?: OAuthConfig;
  apiKey?: ApiKeyConfig;
  customHeaders?: Record<string, string>;
}

// ============================================================================
// Result Types
// ============================================================================

export interface ConnectorError {
  code: string;
  message: string;
  platformCode?: string;
  platformMessage?: string;
  retryable: boolean;
  details?: Record<string, unknown>;
}

export interface RateLimitInfo {
  limit: number;
  remaining: number;
  resetAt: Date;
  retryAfter?: number;
}

export interface ConnectorResult<T> {
  success: boolean;
  data?: T;
  error?: ConnectorError;
  rateLimitInfo?: RateLimitInfo;
  retryAfter?: number;
  requestId?: string;
}

export interface CreateResult {
  id: string;
  externalId: string;
  externalUrl?: string;
  status: ProductStatus;
}

export interface UpdateResult {
  id: string;
  externalId: string;
  updatedFields: string[];
}

export interface DeleteResult {
  id: string;
  deleted: boolean;
}

export interface BulkResult {
  total: number;
  successful: number;
  failed: number;
  results: Array<{
    id: string;
    success: boolean;
    error?: ConnectorError;
  }>;
}

// ============================================================================
// Pagination Types
// ============================================================================

export interface ListOptions {
  page?: number;
  limit?: number;
  cursor?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  filters?: Record<string, unknown>;
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
  nextCursor?: string;
}

export type PaginatedProducts = PaginatedResult<NormalizedProduct>;

// ============================================================================
// Order Types (for marketplace connectors)
// ============================================================================

export type OrderStatus =
  | 'pending'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'refunded';

export interface OrderItem {
  id: string;
  productId: string;
  variantId?: string;
  title: string;
  quantity: number;
  price: number;
  sku?: string;
}

export interface ShippingAddress {
  name: string;
  address1: string;
  address2?: string;
  city: string;
  state?: string;
  postalCode: string;
  country: string;
  phone?: string;
}

export interface Order {
  id: string;
  externalId: string;
  status: OrderStatus;
  items: OrderItem[];
  shippingAddress: ShippingAddress;
  subtotal: number;
  shippingCost: number;
  tax: number;
  total: number;
  currency: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TrackingInfo {
  carrier: string;
  trackingNumber: string;
  trackingUrl?: string;
  shippedAt?: Date;
}

export interface Fulfillment {
  id: string;
  orderId: string;
  tracking: TrackingInfo;
  items: OrderItem[];
  fulfilledAt: Date;
}

export type PaginatedOrders = PaginatedResult<Order>;

// ============================================================================
// Analytics Types
// ============================================================================

export interface DateRange {
  start: Date;
  end: Date;
}

export interface RevenueData {
  total: number;
  currency: string;
  byDay: Array<{ date: string; amount: number }>;
  byProduct: Array<{ productId: string; title: string; amount: number }>;
}

export interface PlatformAnalytics {
  platform: string;
  dateRange: DateRange;
  revenue: RevenueData;
  orderCount: number;
  productCount: number;
  viewCount?: number;
  conversionRate?: number;
  topProducts: Array<{
    id: string;
    title: string;
    sales: number;
    revenue: number;
  }>;
}

export interface UnifiedAnalytics {
  totalRevenue: number;
  totalOrders: number;
  totalProducts: number;
  currency: string;
  byPlatform: Record<string, PlatformAnalytics>;
  byProductType: Record<string, { count: number; revenue: number }>;
  timeSeries: Array<{ date: string; revenue: number; orders: number }>;
}

// ============================================================================
// Validation Types
// ============================================================================

export interface ValidationIssue {
  field: string;
  message: string;
  severity: 'error' | 'warning';
  suggestion?: string;
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
  sanitizedProduct?: ProductInput;
}

// ============================================================================
// Workflow Types
// ============================================================================

export interface WorkflowResult {
  success: boolean;
  productId: string;
  platforms: Record<string, {
    success: boolean;
    externalId?: string;
    externalUrl?: string;
    error?: ConnectorError;
  }>;
  safeguardsPassed: boolean;
  safeguardResults?: Record<string, {
    passed: boolean;
    score?: number;
    reason?: string;
  }>;
}

export interface WorkflowConfig {
  targetPlatforms: string[];
  skipSafeguards?: boolean;
  dryRun?: boolean;
  priority?: 'low' | 'normal' | 'high';
  scheduledFor?: Date;
}

// ============================================================================
// Platform-Specific Types
// ============================================================================

// Printify
export interface PrintifyShop {
  id: number;
  title: string;
  sales_channel: string;
}

export interface PrintProvider {
  id: number;
  title: string;
  location: { address1: string; city: string; country: string };
}

// Etsy
export interface EtsyShop {
  shop_id: number;
  shop_name: string;
  user_id: number;
  currency_code: string;
  listing_active_count: number;
}

export interface ShippingProfile {
  shipping_profile_id: number;
  title: string;
  origin_country_iso: string;
  processing_days_display_label: string;
}

// Shopify
export interface Collection {
  id: string;
  title: string;
  handle: string;
  productsCount: number;
}

// Amazon KDP
export interface BookInput {
  title: string;
  subtitle?: string;
  author: string;
  description: string;
  keywords: string[];
  categories: string[];
  isbn?: string;
  manuscriptFile: Buffer | string;
  coverFile: Buffer | string;
  pricing: {
    listPrice: number;
    currency: string;
    territories: string[];
  };
}

export interface BookMetadata {
  title?: string;
  subtitle?: string;
  description?: string;
  keywords?: string[];
  categories?: string[];
}

export interface SalesReport {
  dateRange: DateRange;
  totalUnits: number;
  totalRoyalties: number;
  byTitle: Array<{
    asin: string;
    title: string;
    units: number;
    royalties: number;
  }>;
}

// Generic Design Input (Redbubble, TeePublic)
export interface DesignInput {
  title: string;
  description?: string;
  tags: string[];
  imageFile: Buffer | string;
  backgroundColor?: string;
}

export interface Design {
  id: string;
  title: string;
  status: 'pending' | 'approved' | 'rejected';
  thumbnailUrl?: string;
  createdAt: Date;
}

// Asset Input (Creative Fabrica)
export interface AssetInput {
  title: string;
  description: string;
  category: string;
  tags: string[];
  files: Array<{
    name: string;
    data: Buffer | string;
    format: string;
  }>;
  licenseType: 'personal' | 'commercial' | 'extended';
}

export interface Asset {
  id: string;
  title: string;
  status: 'pending' | 'approved' | 'rejected';
  previewUrl?: string;
  downloadCount?: number;
  createdAt: Date;
}

export type LicenseType = 'personal' | 'commercial' | 'extended';

// TikTok Shop
export interface TikTokCategory {
  id: string;
  name: string;
  parentId?: string;
  isLeaf: boolean;
}

export interface TikTokAttribute {
  id: string;
  name: string;
  required: boolean;
  type: 'text' | 'number' | 'enum';
  values?: string[];
}

export interface ImageUploadResult {
  imageId: string;
  imageUrl: string;
}
