/**
 * Redbubble Adapter
 *
 * POD platform connector for Redbubble Partner API.
 * Supports design uploads, product enablement, and analytics.
 *
 * Auth: Partner API Key
 * Base URL: https://api.redbubble.com/v1
 * Rate Limit: 100 requests/minute
 *
 * Features:
 * - Design/artwork uploads
 * - Product type management
 * - Bulk product enablement
 * - Sales analytics
 * - Tag and title management
 */

import {
  BaseConnector,
  ConnectorConfig,
  RequestOptions,
} from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  NormalizedProduct,
  ProductInput,
  PaginatedProducts,
  CreateResult,
  UpdateResult,
  DeleteResult,
  AuthToken,
  ListOptions,
  ValidationResult,
  PlatformAnalytics,
  DateRange,
  ProductType,
  ProductStatus,
} from '../core/types';
import { mapPlatformError, ErrorCode } from '../utils/error-mapper';

// ============================================================================
// Redbubble Types
// ============================================================================

interface RedbubbleWork {
  id: string;
  title: string;
  description: string;
  tags: string[];
  artistId: string;
  imageUrl: string;
  thumbnailUrl: string;
  enabledProducts: string[];
  status: 'draft' | 'pending' | 'live' | 'removed';
  createdAt: string;
  updatedAt: string;
  defaultMarkup: number;
  matureContent: boolean;
}

interface RedbubbleProduct {
  code: string;
  name: string;
  category: string;
  basePrice: number;
  available: boolean;
  minImageWidth: number;
  minImageHeight: number;
}

interface RedbubbleArtist {
  id: string;
  username: string;
  displayName: string;
  shopUrl: string;
  avatarUrl: string;
  totalWorks: number;
  totalSales: number;
  joinedAt: string;
}

interface RedbubbleSales {
  totalRevenue: number;
  totalUnits: number;
  totalOrders: number;
  byProduct: RedbubbleProductSales[];
  byWork: RedbubbleWorkSales[];
}

interface RedbubbleProductSales {
  productCode: string;
  productName: string;
  units: number;
  revenue: number;
}

interface RedbubbleWorkSales {
  workId: string;
  title: string;
  units: number;
  revenue: number;
}

interface RedbubbleUploadResult {
  workId: string;
  status: 'processing' | 'complete' | 'failed';
  imageUrl: string;
  errors?: string[];
}

// ============================================================================
// Redbubble Adapter Implementation
// ============================================================================

export class RedbubbleAdapter extends BaseConnector {
  readonly name = 'redbubble';
  readonly workflowGroup = 'pod_digital' as const;
  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: false,
    supportsBulkOperations: true,
    supportsWebhooks: false,
    supportsInventorySync: false,
    supportsOrderFulfillment: false,
    supportsAnalytics: true,
    maxProductsPerRequest: 50,
    rateLimits: {
      requestsPerMinute: 100,
    },
  };

  private readonly baseUrl = 'https://api.redbubble.com/v1';
  private artistId: string | null = null;

  constructor(config: ConnectorConfig) {
    super(config);
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    try {
      const credentials = await this.getCredentials<{ apiKey: string }>();
      if (!credentials?.apiKey) {
        return {
          success: false,
          error: {
            code: ErrorCode.AUTH_FAILED,
            message: 'Redbubble API key not configured',
            retryable: false,
          },
        };
      }

      // Verify credentials by fetching artist profile
      const response = await this.makeRequest<RedbubbleArtist>('/me', {
        headers: {
          'Authorization': `Bearer ${credentials.apiKey}`,
        },
      });

      if (!response.success || !response.data) {
        return {
          success: false,
          error: response.error || {
            code: ErrorCode.AUTH_FAILED,
            message: 'Failed to authenticate with Redbubble',
            retryable: false,
          },
        };
      }

      this.artistId = response.data.id;

      return {
        success: true,
        data: {
          accessToken: credentials.apiKey,
          tokenType: 'Bearer',
          expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // API keys don't expire
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    // API keys don't need refresh
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    const result = await this.authenticate();
    return result.success;
  }

  // ============================================================================
  // Product (Work) Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    try {
      const page = options?.page || 1;
      const limit = options?.limit || 20;

      const response = await this.makeRequest<{ works: RedbubbleWork[]; total: number }>(
        `/artists/${this.artistId}/works`,
        {
          params: {
            page: page.toString(),
            limit: limit.toString(),
            status: options?.status || 'live',
          },
        }
      );

      if (!response.success || !response.data) {
        return {
          success: false,
          error: response.error,
        };
      }

      const normalizedProducts = response.data.works.map(work =>
        this.normalizeProduct(work)
      );

      return {
        success: true,
        data: {
          items: normalizedProducts,
          pagination: {
            page,
            limit,
            total: response.data.total,
            hasMore: page * limit < response.data.total,
          },
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    try {
      const response = await this.makeRequest<RedbubbleWork>(`/works/${id}`);

      if (!response.success || !response.data) {
        return {
          success: false,
          error: response.error,
        };
      }

      return {
        success: true,
        data: this.normalizeProduct(response.data),
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    try {
      // Validate product
      const validation = this.validateProductForPlatform(product);
      if (!validation.valid) {
        return {
          success: false,
          error: {
            code: ErrorCode.VALIDATION_ERROR,
            message: validation.errors.join(', '),
            retryable: false,
          },
        };
      }

      // Upload the design/artwork
      const uploadResult = await this.uploadDesign({
        title: product.title,
        description: product.description,
        tags: (product.metadata?.tags as string[]) || [],
        imageUrl: product.images[0]?.url || '',
        matureContent: (product.metadata?.matureContent as boolean) || false,
      });

      if (!uploadResult.success || !uploadResult.data) {
        return {
          success: false,
          error: uploadResult.error,
        };
      }

      // Enable default products
      const defaultProducts = this.getDefaultProductTypes(product.productType);
      await this.enableProducts(uploadResult.data.workId, defaultProducts);

      return {
        success: true,
        data: {
          id: uploadResult.data.workId,
          externalId: uploadResult.data.workId,
          status: 'pending',
          url: `https://www.redbubble.com/people/${this.artistId}/works/${uploadResult.data.workId}`,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  async updateProduct(id: string, updates: Partial<ProductInput>): Promise<ConnectorResult<UpdateResult>> {
    try {
      const updateData: Record<string, unknown> = {};

      if (updates.title) updateData.title = updates.title;
      if (updates.description) updateData.description = updates.description;
      if (updates.metadata?.tags) updateData.tags = updates.metadata.tags;
      if (updates.metadata?.defaultMarkup !== undefined) {
        updateData.defaultMarkup = updates.metadata.defaultMarkup;
      }

      const response = await this.makeRequest<RedbubbleWork>(`/works/${id}`, {
        method: 'PATCH',
        body: updateData,
      });

      if (!response.success) {
        return {
          success: false,
          error: response.error,
        };
      }

      return {
        success: true,
        data: {
          id,
          externalId: id,
          updated: true,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    try {
      // Redbubble doesn't allow deletion, only removal from store
      const response = await this.makeRequest<void>(`/works/${id}`, {
        method: 'PATCH',
        body: { status: 'removed' },
      });

      if (!response.success) {
        return {
          success: false,
          error: response.error,
        };
      }

      return {
        success: true,
        data: {
          id,
          deleted: true,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  // ============================================================================
  // Redbubble-Specific Methods
  // ============================================================================

  /**
   * Upload a new design/artwork
   */
  async uploadDesign(design: {
    title: string;
    description: string;
    tags: string[];
    imageUrl: string;
    matureContent?: boolean;
  }): Promise<ConnectorResult<RedbubbleUploadResult>> {
    try {
      const response = await this.makeRequest<RedbubbleUploadResult>('/works', {
        method: 'POST',
        body: {
          title: design.title,
          description: design.description,
          tags: design.tags.slice(0, 15), // Redbubble allows max 15 tags
          imageUrl: design.imageUrl,
          matureContent: design.matureContent || false,
          artistId: this.artistId,
        },
      });

      return response;
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  /**
   * Enable products for a work
   */
  async enableProducts(workId: string, productCodes: string[]): Promise<ConnectorResult<void>> {
    try {
      const response = await this.makeRequest<void>(`/works/${workId}/products`, {
        method: 'PUT',
        body: {
          enabledProducts: productCodes,
        },
      });

      return response;
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  /**
   * Get all available product types
   */
  async getAvailableProducts(): Promise<ConnectorResult<RedbubbleProduct[]>> {
    try {
      const response = await this.makeRequest<{ products: RedbubbleProduct[] }>('/products');

      if (!response.success || !response.data) {
        return {
          success: false,
          error: response.error,
        };
      }

      return {
        success: true,
        data: response.data.products,
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  /**
   * Get artist profile
   */
  async getArtistProfile(): Promise<ConnectorResult<RedbubbleArtist>> {
    try {
      const response = await this.makeRequest<RedbubbleArtist>('/me');
      return response;
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  /**
   * Set product markup percentage
   */
  async setMarkup(workId: string, markup: number): Promise<ConnectorResult<void>> {
    try {
      if (markup < 0 || markup > 100) {
        return {
          success: false,
          error: {
            code: ErrorCode.VALIDATION_ERROR,
            message: 'Markup must be between 0 and 100',
            retryable: false,
          },
        };
      }

      const response = await this.makeRequest<void>(`/works/${workId}`, {
        method: 'PATCH',
        body: { defaultMarkup: markup },
      });

      return response;
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    try {
      const response = await this.makeRequest<RedbubbleSales>(
        `/artists/${this.artistId}/sales`,
        {
          params: {
            startDate: dateRange.start.toISOString().split('T')[0],
            endDate: dateRange.end.toISOString().split('T')[0],
          },
        }
      );

      if (!response.success || !response.data) {
        return {
          success: false,
          error: response.error,
        };
      }

      const sales = response.data;

      return {
        success: true,
        data: {
          platform: 'redbubble',
          dateRange,
          revenue: sales.totalRevenue,
          orders: sales.totalOrders,
          views: 0, // Redbubble doesn't expose view data via API
          conversion: 0,
          topProducts: sales.byWork.slice(0, 10).map(work => ({
            id: work.workId,
            title: work.title,
            sales: work.units,
            revenue: work.revenue,
          })),
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('redbubble', error),
      };
    }
  }

  // ============================================================================
  // Product Normalization
  // ============================================================================

  normalizeProduct(work: RedbubbleWork): NormalizedProduct {
    return {
      id: work.id,
      externalId: work.id,
      title: work.title,
      description: work.description,
      productType: 'design' as ProductType,
      images: [
        { url: work.imageUrl, position: 0 },
        { url: work.thumbnailUrl, position: 1, altText: 'thumbnail' },
      ],
      variants: work.enabledProducts.map(code => ({
        id: `${work.id}-${code}`,
        title: code,
        sku: `RB-${work.id}-${code}`,
        price: 0, // Price determined by Redbubble base + markup
        available: true,
      })),
      pricing: {
        basePrice: 0,
        currency: 'USD',
        compareAtPrice: undefined,
        costPerItem: undefined,
      },
      metadata: {
        tags: work.tags,
        artistId: work.artistId,
        defaultMarkup: work.defaultMarkup,
        matureContent: work.matureContent,
        enabledProducts: work.enabledProducts,
      },
      platformData: work,
      status: this.mapRedbubbleStatus(work.status),
      createdAt: new Date(work.createdAt),
      updatedAt: new Date(work.updatedAt),
    };
  }

  denormalizeProduct(product: NormalizedProduct): Partial<RedbubbleWork> {
    return {
      title: product.title,
      description: product.description,
      tags: (product.metadata?.tags as string[]) || [],
      defaultMarkup: (product.metadata?.defaultMarkup as number) || 20,
      matureContent: (product.metadata?.matureContent as boolean) || false,
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Title validation
    if (!product.title || product.title.length === 0) {
      errors.push('Title is required');
    } else if (product.title.length > 50) {
      errors.push('Title must be 50 characters or less');
    }

    // Description validation
    if (product.description && product.description.length > 1000) {
      errors.push('Description must be 1000 characters or less');
    }

    // Tags validation
    const tags = (product.metadata?.tags as string[]) || [];
    if (tags.length > 15) {
      warnings.push('Maximum 15 tags allowed, extras will be truncated');
    }

    // Image validation
    if (!product.images || product.images.length === 0) {
      errors.push('At least one image is required');
    } else {
      const image = product.images[0];
      if (image.width && image.width < 2400) {
        warnings.push('Image width should be at least 2400px for best quality');
      }
      if (image.height && image.height < 2400) {
        warnings.push('Image height should be at least 2400px for best quality');
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private mapRedbubbleStatus(status: string): ProductStatus {
    const statusMap: Record<string, ProductStatus> = {
      'live': 'active',
      'pending': 'pending',
      'draft': 'draft',
      'removed': 'archived',
    };
    return statusMap[status] || 'draft';
  }

  private getDefaultProductTypes(productType: ProductType): string[] {
    // Return default product codes based on design type
    const defaults: Record<string, string[]> = {
      't-shirt': ['MENS_T', 'WOMENS_T', 'KIDS_T', 'HOODIE'],
      'poster': ['POSTER', 'ART_PRINT', 'CANVAS'],
      'sticker': ['STICKER', 'TRANSPARENT_STICKER', 'KISS_CUT'],
      'phone-case': ['IPHONE_CASE', 'SAMSUNG_CASE'],
      'default': ['MENS_T', 'STICKER', 'POSTER', 'MUG'],
    };

    return defaults[productType] || defaults['default'];
  }
}

export default RedbubbleAdapter;
