/**
 * Retry Handler
 * Provides exponential backoff and retry logic for API calls
 */

import { ConnectorError, ConnectorResult } from '../core/types';

export interface RetryConfig {
  maxRetries: number;
  initialDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
  retryableErrors: string[];
  retryableStatusCodes: number[];
  onRetry?: (attempt: number, error: ConnectorError, delay: number) => void;
}

const DEFAULT_CONFIG: RetryConfig = {
  maxRetries: 3,
  initialDelayMs: 1000,
  maxDelayMs: 30000,
  backoffMultiplier: 2,
  retryableErrors: [
    'NETWORK_ERROR',
    'TIMEOUT_ERROR',
    'CONNECTION_ERROR',
    'ECONNRESET',
    'ECONNREFUSED',
    'ETIMEDOUT',
  ],
  retryableStatusCodes: [429, 500, 502, 503, 504],
};

/**
 * Retry handler with exponential backoff
 */
export class RetryHandler {
  private config: RetryConfig;

  constructor(config: Partial<RetryConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Execute a function with retry logic
   */
  async execute<T>(
    fn: () => Promise<ConnectorResult<T>>,
    overrideConfig?: Partial<RetryConfig>
  ): Promise<ConnectorResult<T>> {
    const config = { ...this.config, ...overrideConfig };
    let lastError: ConnectorError | undefined;

    for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
      try {
        const result = await fn();

        if (result.success) {
          return result;
        }

        lastError = result.error;

        // Check if error is retryable
        if (!this.isRetryable(result.error, config)) {
          return result;
        }

        // Don't retry on last attempt
        if (attempt >= config.maxRetries) {
          return result;
        }

        // Calculate delay
        const delay = this.calculateDelay(attempt, result.retryAfter, config);

        // Call retry callback if provided
        if (config.onRetry && result.error) {
          config.onRetry(attempt + 1, result.error, delay);
        }

        // Wait before retrying
        await this.sleep(delay);
      } catch (error) {
        // Handle thrown errors (network failures, etc.)
        lastError = this.mapError(error);

        if (!this.isRetryable(lastError, config) || attempt >= config.maxRetries) {
          return {
            success: false,
            error: lastError,
          };
        }

        const delay = this.calculateDelay(attempt, undefined, config);

        if (config.onRetry) {
          config.onRetry(attempt + 1, lastError, delay);
        }

        await this.sleep(delay);
      }
    }

    return {
      success: false,
      error: lastError ?? {
        code: 'MAX_RETRIES_EXCEEDED',
        message: 'Maximum retry attempts exceeded',
        retryable: false,
      },
    };
  }

  /**
   * Execute with timeout
   */
  async executeWithTimeout<T>(
    fn: () => Promise<ConnectorResult<T>>,
    timeoutMs: number,
    overrideConfig?: Partial<RetryConfig>
  ): Promise<ConnectorResult<T>> {
    const wrappedFn = async (): Promise<ConnectorResult<T>> => {
      const timeoutPromise = new Promise<ConnectorResult<T>>((resolve) =>
        setTimeout(
          () =>
            resolve({
              success: false,
              error: {
                code: 'TIMEOUT_ERROR',
                message: `Request timed out after ${timeoutMs}ms`,
                retryable: true,
              },
            }),
          timeoutMs
        )
      );

      return Promise.race([fn(), timeoutPromise]);
    };

    return this.execute(wrappedFn, overrideConfig);
  }

  /**
   * Check if an error is retryable
   */
  private isRetryable(
    error: ConnectorError | undefined,
    config: RetryConfig
  ): boolean {
    if (!error) return false;

    // Explicitly marked as retryable
    if (error.retryable) return true;

    // Check error code
    if (config.retryableErrors.includes(error.code)) return true;

    // Check HTTP status code
    if (error.platformCode) {
      const statusCode = parseInt(error.platformCode, 10);
      if (!isNaN(statusCode) && config.retryableStatusCodes.includes(statusCode)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Calculate delay with exponential backoff and jitter
   */
  private calculateDelay(
    attempt: number,
    retryAfterSeconds: number | undefined,
    config: RetryConfig
  ): number {
    // If server specified retry-after, use that
    if (retryAfterSeconds !== undefined) {
      return retryAfterSeconds * 1000;
    }

    // Exponential backoff: initialDelay * (multiplier ^ attempt)
    const baseDelay = config.initialDelayMs * Math.pow(config.backoffMultiplier, attempt);

    // Add jitter (±25% randomization)
    const jitter = baseDelay * 0.25 * (Math.random() * 2 - 1);

    // Cap at max delay
    return Math.min(baseDelay + jitter, config.maxDelayMs);
  }

  /**
   * Map unknown error to ConnectorError
   */
  private mapError(error: unknown): ConnectorError {
    if (error instanceof Error) {
      return {
        code: error.name || 'UNKNOWN_ERROR',
        message: error.message,
        retryable: true,
        details: { stack: error.stack },
      };
    }

    return {
      code: 'UNKNOWN_ERROR',
      message: String(error),
      retryable: false,
    };
  }

  /**
   * Sleep for specified milliseconds
   */
  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

/**
 * Retry with immediate configuration
 */
export async function retry<T>(
  fn: () => Promise<ConnectorResult<T>>,
  config: Partial<RetryConfig> = {}
): Promise<ConnectorResult<T>> {
  const handler = new RetryHandler(config);
  return handler.execute(fn);
}

/**
 * Retry with timeout
 */
export async function retryWithTimeout<T>(
  fn: () => Promise<ConnectorResult<T>>,
  timeoutMs: number,
  config: Partial<RetryConfig> = {}
): Promise<ConnectorResult<T>> {
  const handler = new RetryHandler(config);
  return handler.executeWithTimeout(fn, timeoutMs);
}

/**
 * Create a retry decorator for class methods
 */
export function withRetry(config: Partial<RetryConfig> = {}) {
  return function (
    _target: unknown,
    _propertyKey: string,
    descriptor: PropertyDescriptor
  ) {
    const originalMethod = descriptor.value;

    descriptor.value = async function (...args: unknown[]) {
      const handler = new RetryHandler(config);
      return handler.execute(() => originalMethod.apply(this, args));
    };

    return descriptor;
  };
}

/**
 * Circuit breaker states
 */
export type CircuitState = 'closed' | 'open' | 'half-open';

/**
 * Simple circuit breaker for preventing cascade failures
 */
export class CircuitBreaker {
  private state: CircuitState = 'closed';
  private failures: number = 0;
  private lastFailure: number = 0;
  private successCount: number = 0;

  constructor(
    private readonly failureThreshold: number = 5,
    private readonly resetTimeoutMs: number = 30000,
    private readonly halfOpenRequests: number = 3
  ) {}

  /**
   * Check if circuit allows request
   */
  canRequest(): boolean {
    if (this.state === 'closed') {
      return true;
    }

    if (this.state === 'open') {
      // Check if reset timeout has passed
      if (Date.now() - this.lastFailure >= this.resetTimeoutMs) {
        this.state = 'half-open';
        this.successCount = 0;
        return true;
      }
      return false;
    }

    // Half-open: allow limited requests
    return true;
  }

  /**
   * Record a successful request
   */
  recordSuccess(): void {
    if (this.state === 'half-open') {
      this.successCount++;
      if (this.successCount >= this.halfOpenRequests) {
        this.reset();
      }
    } else {
      this.failures = 0;
    }
  }

  /**
   * Record a failed request
   */
  recordFailure(): void {
    this.failures++;
    this.lastFailure = Date.now();

    if (this.state === 'half-open') {
      // Immediately open on failure in half-open state
      this.state = 'open';
      this.successCount = 0;
    } else if (this.failures >= this.failureThreshold) {
      this.state = 'open';
    }
  }

  /**
   * Reset the circuit breaker
   */
  reset(): void {
    this.state = 'closed';
    this.failures = 0;
    this.successCount = 0;
    this.lastFailure = 0;
  }

  /**
   * Get current state
   */
  getState(): CircuitState {
    return this.state;
  }

  /**
   * Get failure count
   */
  getFailureCount(): number {
    return this.failures;
  }

  /**
   * Execute with circuit breaker protection
   */
  async execute<T>(
    fn: () => Promise<ConnectorResult<T>>
  ): Promise<ConnectorResult<T>> {
    if (!this.canRequest()) {
      return {
        success: false,
        error: {
          code: 'CIRCUIT_OPEN',
          message: 'Circuit breaker is open, request blocked',
          retryable: true,
        },
      };
    }

    try {
      const result = await fn();

      if (result.success) {
        this.recordSuccess();
      } else {
        this.recordFailure();
      }

      return result;
    } catch (error) {
      this.recordFailure();
      throw error;
    }
  }
}

export default RetryHandler;
