/**
 * Etsy Adapter
 * Marketplace connector for Etsy Open API v3
 *
 * API Docs: https://developers.etsy.com/documentation/
 * Auth: OAuth 2.0 with PKCE
 * Rate Limit: 10 requests/second
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  EtsyShop,
  ShippingProfile,
  ProductType,
  OAuthConfig,
  DateRange,
  PlatformAnalytics,
  RevenueData,
} from '../core/types';
import { mapPlatformError } from '../utils/error-mapper';
import { CredentialManager } from '../core/credential-manager';

// Etsy-specific types
interface EtsyListing {
  listing_id: number;
  user_id: number;
  shop_id: number;
  title: string;
  description: string;
  state: 'active' | 'inactive' | 'draft' | 'expired' | 'sold_out';
  creation_timestamp: number;
  last_modified_timestamp: number;
  state_timestamp: number;
  quantity: number;
  shop_section_id: number | null;
  featured_rank: number;
  url: string;
  num_favorers: number;
  non_taxable: boolean;
  is_taxable: boolean;
  is_customizable: boolean;
  is_personalizable: boolean;
  personalization_is_required: boolean;
  personalization_char_count_max: number | null;
  personalization_instructions: string | null;
  listing_type: 'physical' | 'download' | 'both';
  tags: string[];
  materials: string[];
  shipping_profile_id: number | null;
  return_policy_id: number | null;
  processing_min: number | null;
  processing_max: number | null;
  who_made: 'i_did' | 'someone_else' | 'collective';
  when_made: string;
  is_supply: boolean;
  item_weight: number | null;
  item_weight_unit: 'oz' | 'lb' | 'g' | 'kg' | null;
  item_length: number | null;
  item_width: number | null;
  item_height: number | null;
  item_dimensions_unit: 'in' | 'ft' | 'mm' | 'cm' | 'm' | null;
  is_private: boolean;
  style: string[];
  file_data: string;
  has_variations: boolean;
  should_auto_renew: boolean;
  language: string;
  price: { amount: number; divisor: number; currency_code: string };
  taxonomy_id: number;
  images?: EtsyImage[];
  shop?: EtsyShop;
  inventory?: EtsyInventory;
}

interface EtsyImage {
  listing_image_id: number;
  listing_id: number;
  hex_code: string;
  red: number;
  green: number;
  blue: number;
  hue: number;
  saturation: number;
  brightness: number;
  is_black_and_white: boolean;
  creation_timestamp: number;
  rank: number;
  url_75x75: string;
  url_170x135: string;
  url_570xN: string;
  url_fullxfull: string;
  full_height: number;
  full_width: number;
}

interface EtsyInventory {
  products: EtsyInventoryProduct[];
  price_on_property: number[];
  quantity_on_property: number[];
  sku_on_property: number[];
}

interface EtsyInventoryProduct {
  product_id: number;
  sku: string;
  is_deleted: boolean;
  offerings: EtsyOffering[];
  property_values: EtsyPropertyValue[];
}

interface EtsyOffering {
  offering_id: number;
  quantity: number;
  is_enabled: boolean;
  is_deleted: boolean;
  price: { amount: number; divisor: number; currency_code: string };
}

interface EtsyPropertyValue {
  property_id: number;
  property_name: string;
  scale_id: number | null;
  scale_name: string | null;
  value_ids: number[];
  values: string[];
}

interface EtsyTaxonomy {
  id: number;
  level: number;
  name: string;
  parent_id: number | null;
  children?: EtsyTaxonomy[];
}

/**
 * Etsy platform adapter
 */
export class EtsyAdapter extends BaseConnector {
  readonly name = 'etsy';
  readonly displayName = 'Etsy';
  readonly workflowGroup = 'pod_digital' as const;
  readonly connectorType = 'oauth2' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: true,
    supportsBulkOperations: true,
    supportsWebhooks: false, // Etsy uses polling
    supportsInventorySync: true,
    supportsOrderFulfillment: true,
    supportsAnalytics: true,
    maxProductsPerRequest: 100,
    rateLimits: {
      requestsPerSecond: 10,
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 140,
    maxDescriptionLength: 65535,
    maxImages: 10,
    maxTags: 13,
    maxVariants: 70,
    allowedImageFormats: ['jpg', 'jpeg', 'png', 'gif'],
    maxImageSizeMB: 10,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['title', 'description', 'price', 'who_made', 'when_made', 'taxonomy_id'],
    requiredImageDimensions: { width: 2000, height: 2000 }, // Recommended
    requiredCategories: true,
    requiredShippingProfile: true,
  };

  private shopId: number | null = null;
  private credentialManager: CredentialManager | null = null;

  readonly oauthConfig: OAuthConfig = {
    clientId: process.env.ETSY_CLIENT_ID || '',
    clientSecret: process.env.ETSY_CLIENT_SECRET || '',
    redirectUri: process.env.ETSY_REDIRECT_URI || '',
    scopes: [
      'listings_r',
      'listings_w',
      'listings_d',
      'shops_r',
      'shops_w',
      'transactions_r',
      'profile_r',
    ],
    authUrl: 'https://www.etsy.com/oauth/connect',
    tokenUrl: 'https://api.etsy.com/v3/public/oauth/token',
  };

  constructor(config: ConnectorConfig) {
    super({
      ...config,
      baseUrl: 'https://openapi.etsy.com/v3',
    });
  }

  setCredentialManager(manager: CredentialManager): void {
    this.credentialManager = manager;
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    if (!this.credentialManager) {
      return {
        success: false,
        error: this.createError('CONFIG_ERROR', 'Credential manager not set'),
      };
    }

    const result = await this.credentialManager.getOAuthTokens('etsy');
    if (!result.success) {
      return result;
    }

    this.authToken = result.data!;

    // Validate by fetching user info
    const userResult = await this.getMe();
    if (!userResult.success) {
      this.authToken = null;
      return {
        success: false,
        error: userResult.error,
      };
    }

    return { success: true, data: this.authToken };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    if (!this.credentialManager) {
      return {
        success: false,
        error: this.createError('CONFIG_ERROR', 'Credential manager not set'),
      };
    }

    const result = await this.credentialManager.refreshTokens('etsy', this.oauthConfig);
    if (!result.success) {
      return result;
    }

    this.authToken = result.data!;
    return { success: true, data: this.authToken };
  }

  async validateCredentials(): Promise<boolean> {
    const result = await this.getMe();
    return result.success;
  }

  /**
   * Get OAuth authorization URL
   */
  getAuthorizationUrl(): string {
    if (!this.credentialManager) {
      throw new Error('Credential manager not set');
    }
    return this.credentialManager.generateAuthUrl('etsy', this.oauthConfig);
  }

  /**
   * Handle OAuth callback
   */
  async handleOAuthCallback(
    code: string,
    state: string
  ): Promise<ConnectorResult<AuthToken>> {
    if (!this.credentialManager) {
      return {
        success: false,
        error: this.createError('CONFIG_ERROR', 'Credential manager not set'),
      };
    }

    return this.credentialManager.exchangeCodeForTokens(code, state, this.oauthConfig);
  }

  // ============================================================================
  // User & Shop
  // ============================================================================

  private async getMe(): Promise<ConnectorResult<{ user_id: number }>> {
    return this.request<{ user_id: number }>({
      method: 'GET',
      path: '/application/users/me',
    });
  }

  async getShop(): Promise<ConnectorResult<EtsyShop>> {
    const meResult = await this.getMe();
    if (!meResult.success) {
      return meResult as ConnectorResult<EtsyShop>;
    }

    const result = await this.request<EtsyShop>({
      method: 'GET',
      path: `/application/users/${meResult.data!.user_id}/shops`,
    });

    if (result.success && result.data) {
      this.shopId = result.data.shop_id;
    }

    return result;
  }

  async getShippingProfiles(): Promise<ConnectorResult<ShippingProfile[]>> {
    if (!this.shopId) {
      const shopResult = await this.getShop();
      if (!shopResult.success) {
        return shopResult as ConnectorResult<ShippingProfile[]>;
      }
    }

    const result = await this.request<{ results: ShippingProfile[] }>({
      method: 'GET',
      path: `/application/shops/${this.shopId}/shipping-profiles`,
    });

    if (!result.success) {
      return result as ConnectorResult<ShippingProfile[]>;
    }

    return { success: true, data: result.data!.results };
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    if (!this.shopId) {
      const shopResult = await this.getShop();
      if (!shopResult.success) {
        return shopResult as ConnectorResult<PaginatedProducts>;
      }
    }

    const limit = options?.limit || 25;
    const offset = ((options?.page || 1) - 1) * limit;

    const result = await this.request<{ count: number; results: EtsyListing[] }>({
      method: 'GET',
      path: `/application/shops/${this.shopId}/listings`,
      query: {
        limit,
        offset,
        includes: 'images,inventory',
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedProducts>;
    }

    return {
      success: true,
      data: {
        items: result.data!.results.map((l) => this.normalizeProduct(l)),
        total: result.data!.count,
        page: options?.page || 1,
        limit,
        hasMore: offset + result.data!.results.length < result.data!.count,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    const result = await this.request<EtsyListing>({
      method: 'GET',
      path: `/application/listings/${id}`,
      query: { includes: 'images,inventory,shop' },
    });

    if (!result.success) {
      return result as ConnectorResult<NormalizedProduct>;
    }

    return {
      success: true,
      data: this.normalizeProduct(result.data!),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    if (!this.shopId) {
      const shopResult = await this.getShop();
      if (!shopResult.success) {
        return shopResult as ConnectorResult<CreateResult>;
      }
    }

    // Validate product
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_ERROR',
          validation.issues.map((i) => i.message).join('; ')
        ),
      };
    }

    // Create listing
    const listingData = this.denormalizeProduct({
      ...product,
      id: '',
      status: 'draft',
      createdAt: new Date(),
      updatedAt: new Date(),
      platformData: {},
      metadata: product.metadata || {},
      tags: product.tags || [],
      images: product.images.map((img, idx) => ({
        ...img,
        id: `img-${idx}`,
      })),
      variants: product.variants?.map((v, idx) => ({
        ...v,
        id: `var-${idx}`,
      })) || [],
      pricing: {
        ...product.pricing,
        currency: product.pricing.currency || 'USD',
      },
    } as NormalizedProduct);

    const result = await this.request<EtsyListing>({
      method: 'POST',
      path: `/application/shops/${this.shopId}/listings`,
      body: listingData,
    });

    if (!result.success) {
      return result as ConnectorResult<CreateResult>;
    }

    const listingId = result.data!.listing_id;

    // Upload images
    if (product.images.length > 0) {
      for (let i = 0; i < product.images.length; i++) {
        await this.uploadImage(String(listingId), product.images[i].url, i + 1);
      }
    }

    return {
      success: true,
      data: {
        id: String(listingId),
        externalId: String(listingId),
        externalUrl: result.data!.url,
        status: result.data!.state === 'active' ? 'active' : 'draft',
      },
    };
  }

  async updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>> {
    const updatePayload: Record<string, unknown> = {};
    const updatedFields: string[] = [];

    if (updates.title) {
      updatePayload.title = updates.title;
      updatedFields.push('title');
    }
    if (updates.description) {
      updatePayload.description = updates.description;
      updatedFields.push('description');
    }
    if (updates.tags) {
      updatePayload.tags = updates.tags;
      updatedFields.push('tags');
    }
    if (updates.pricing?.price) {
      updatePayload.price = updates.pricing.price;
      updatedFields.push('price');
    }

    const result = await this.request<EtsyListing>({
      method: 'PATCH',
      path: `/application/listings/${id}`,
      body: updatePayload,
    });

    if (!result.success) {
      return result as ConnectorResult<UpdateResult>;
    }

    return {
      success: true,
      data: {
        id,
        externalId: id,
        updatedFields,
      },
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    const result = await this.request<void>({
      method: 'DELETE',
      path: `/application/listings/${id}`,
    });

    return {
      success: result.success,
      data: { id, deleted: result.success },
      error: result.error,
    };
  }

  // ============================================================================
  // Images
  // ============================================================================

  private async uploadImage(
    listingId: string,
    imageUrl: string,
    rank: number
  ): Promise<ConnectorResult<EtsyImage>> {
    // Etsy requires multipart form data for image uploads
    // This is a simplified version - in production, fetch the image and upload as form data
    return this.request<EtsyImage>({
      method: 'POST',
      path: `/application/shops/${this.shopId}/listings/${listingId}/images`,
      body: {
        image: imageUrl,
        rank,
      },
    });
  }

  // ============================================================================
  // Inventory
  // ============================================================================

  async updateInventory(
    listingId: string,
    inventory: { sku: string; quantity: number; price: number }[]
  ): Promise<ConnectorResult<void>> {
    const products = inventory.map((item) => ({
      sku: item.sku,
      offerings: [
        {
          quantity: item.quantity,
          is_enabled: true,
          price: {
            amount: Math.round(item.price * 100),
            divisor: 100,
            currency_code: 'USD',
          },
        },
      ],
    }));

    return this.request<void>({
      method: 'PUT',
      path: `/application/listings/${listingId}/inventory`,
      body: { products },
    });
  }

  // ============================================================================
  // Taxonomy
  // ============================================================================

  async getTaxonomies(): Promise<ConnectorResult<EtsyTaxonomy[]>> {
    const result = await this.request<{ results: EtsyTaxonomy[] }>({
      method: 'GET',
      path: '/application/seller-taxonomy/nodes',
    });

    if (!result.success) {
      return result as ConnectorResult<EtsyTaxonomy[]>;
    }

    return { success: true, data: result.data!.results };
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    if (!this.shopId) {
      const shopResult = await this.getShop();
      if (!shopResult.success) {
        return shopResult as ConnectorResult<PlatformAnalytics>;
      }
    }

    // Etsy analytics are limited - we can get transactions and calculate revenue
    const transactionsResult = await this.request<{
      count: number;
      results: Array<{
        transaction_id: number;
        price: { amount: number; divisor: number };
        quantity: number;
        listing_id: number;
        paid_timestamp: number;
      }>;
    }>({
      method: 'GET',
      path: `/application/shops/${this.shopId}/transactions`,
      query: {
        min_created: Math.floor(dateRange.start.getTime() / 1000),
        max_created: Math.floor(dateRange.end.getTime() / 1000),
        limit: 100,
      },
    });

    if (!transactionsResult.success) {
      return transactionsResult as ConnectorResult<PlatformAnalytics>;
    }

    const transactions = transactionsResult.data!.results;
    const totalRevenue = transactions.reduce(
      (sum, t) => sum + (t.price.amount / t.price.divisor) * t.quantity,
      0
    );

    // Group by day
    const byDay = new Map<string, number>();
    transactions.forEach((t) => {
      const date = new Date(t.paid_timestamp * 1000).toISOString().split('T')[0];
      byDay.set(date, (byDay.get(date) || 0) + (t.price.amount / t.price.divisor) * t.quantity);
    });

    // Group by product
    const byProduct = new Map<string, { title: string; sales: number; revenue: number }>();
    transactions.forEach((t) => {
      const key = String(t.listing_id);
      const existing = byProduct.get(key) || { title: key, sales: 0, revenue: 0 };
      existing.sales += t.quantity;
      existing.revenue += (t.price.amount / t.price.divisor) * t.quantity;
      byProduct.set(key, existing);
    });

    return {
      success: true,
      data: {
        platform: 'etsy',
        dateRange,
        revenue: {
          total: totalRevenue,
          currency: 'USD',
          byDay: Array.from(byDay.entries()).map(([date, amount]) => ({ date, amount })),
          byProduct: Array.from(byProduct.entries()).map(([productId, data]) => ({
            productId,
            title: data.title,
            amount: data.revenue,
          })),
        },
        orderCount: transactions.length,
        productCount: byProduct.size,
        topProducts: Array.from(byProduct.entries())
          .map(([id, data]) => ({ id, ...data }))
          .sort((a, b) => b.revenue - a.revenue)
          .slice(0, 10),
      },
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const l = platformProduct as EtsyListing;

    const price = l.price ? l.price.amount / l.price.divisor : 0;

    return {
      id: String(l.listing_id),
      externalId: String(l.listing_id),
      title: l.title,
      description: l.description,
      productType: this.mapTaxonomyToProductType(l.taxonomy_id),
      images: (l.images || []).map((img) => ({
        id: String(img.listing_image_id),
        url: img.url_fullxfull,
        alt: l.title,
        position: img.rank,
        width: img.full_width,
        height: img.full_height,
        isPrimary: img.rank === 1,
      })),
      variants: this.extractVariants(l),
      pricing: {
        price,
        currency: l.price?.currency_code || 'USD',
        taxable: l.is_taxable,
      },
      tags: l.tags,
      metadata: {
        taxonomy_id: l.taxonomy_id,
        who_made: l.who_made,
        when_made: l.when_made,
        is_supply: l.is_supply,
        shop_section_id: l.shop_section_id,
      },
      platformData: {
        url: l.url,
        num_favorers: l.num_favorers,
        listing_type: l.listing_type,
        is_customizable: l.is_customizable,
        shipping_profile_id: l.shipping_profile_id,
      },
      status: this.mapEtsyState(l.state),
      createdAt: new Date(l.creation_timestamp * 1000),
      updatedAt: new Date(l.last_modified_timestamp * 1000),
    };
  }

  private extractVariants(listing: EtsyListing): NormalizedProduct['variants'] {
    if (!listing.inventory?.products) {
      return [{
        id: '0',
        title: 'Default',
        price: listing.price ? listing.price.amount / listing.price.divisor : 0,
        inventoryQuantity: listing.quantity,
        options: {},
      }];
    }

    return listing.inventory.products
      .filter((p) => !p.is_deleted)
      .map((p) => ({
        id: String(p.product_id),
        sku: p.sku,
        title: p.property_values.map((pv) => pv.values.join(', ')).join(' / ') || 'Default',
        price: p.offerings[0]?.price
          ? p.offerings[0].price.amount / p.offerings[0].price.divisor
          : 0,
        inventoryQuantity: p.offerings.reduce((sum, o) => sum + o.quantity, 0),
        options: Object.fromEntries(
          p.property_values.map((pv) => [pv.property_name, pv.values.join(', ')])
        ),
      }));
  }

  denormalizeProduct(product: NormalizedProduct): unknown {
    return {
      title: product.title,
      description: product.description,
      price: product.pricing.price,
      quantity: product.variants.reduce((sum, v) => sum + (v.inventoryQuantity || 0), 1),
      tags: product.tags?.slice(0, this.platformLimits.maxTags) || [],
      taxonomy_id: product.metadata?.taxonomy_id,
      who_made: product.metadata?.who_made || 'i_did',
      when_made: product.metadata?.when_made || 'made_to_order',
      is_supply: product.metadata?.is_supply || false,
      shipping_profile_id: product.platformData?.shipping_profile_id,
      shop_section_id: product.metadata?.shop_section_id,
      type: product.productType === 'digital-download' ? 'download' : 'physical',
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    // Title
    if (!product.title) {
      issues.push(this.createValidationIssue('title', 'Title is required', 'error'));
    } else if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title exceeds ${this.platformLimits.maxTitleLength} characters`,
          'error'
        )
      );
    }

    // Description
    if (!product.description) {
      issues.push(this.createValidationIssue('description', 'Description is required', 'error'));
    }

    // Taxonomy (category)
    if (!product.metadata?.taxonomy_id) {
      issues.push(
        this.createValidationIssue(
          'metadata.taxonomy_id',
          'Category (taxonomy) is required for Etsy',
          'error',
          'Select a category for your listing'
        )
      );
    }

    // Shipping profile
    if (!product.platformData?.shipping_profile_id) {
      issues.push(
        this.createValidationIssue(
          'platformData.shipping_profile_id',
          'Shipping profile is required for Etsy',
          'error',
          'Create a shipping profile in your Etsy shop settings'
        )
      );
    }

    // Tags
    if (product.tags && product.tags.length > this.platformLimits.maxTags) {
      issues.push(
        this.createValidationIssue(
          'tags',
          `Too many tags (max ${this.platformLimits.maxTags})`,
          'warning'
        )
      );
    }

    // Images
    if (!product.images || product.images.length === 0) {
      issues.push(
        this.createValidationIssue('images', 'At least one image is required', 'error')
      );
    }

    // Price
    if (!product.pricing?.price || product.pricing.price < 0.2) {
      issues.push(
        this.createValidationIssue(
          'pricing.price',
          'Price must be at least $0.20',
          'error'
        )
      );
    }

    return {
      valid: issues.filter((i) => i.severity === 'error').length === 0,
      issues,
    };
  }

  // ============================================================================
  // Helpers
  // ============================================================================

  private mapTaxonomyToProductType(taxonomyId: number): ProductType {
    // Map common Etsy taxonomy IDs to product types
    // These are approximate - Etsy has thousands of categories
    const mapping: Record<number, ProductType> = {
      1: 't-shirt', // Clothing > Shirts
      69150433: 'mug', // Home & Living > Mugs
      69150537: 'poster', // Art & Collectibles > Prints
      66: 'sticker', // Paper & Party Supplies > Stickers
    };

    return mapping[taxonomyId] || 'other';
  }

  private mapEtsyState(state: EtsyListing['state']): ProductStatus {
    switch (state) {
      case 'active':
        return 'active';
      case 'draft':
        return 'draft';
      case 'inactive':
      case 'expired':
      case 'sold_out':
        return 'archived';
      default:
        return 'draft';
    }
  }

  protected override mapPlatformError(status: number, data: unknown) {
    return mapPlatformError('etsy', status, data);
  }
}

export default EtsyAdapter;
