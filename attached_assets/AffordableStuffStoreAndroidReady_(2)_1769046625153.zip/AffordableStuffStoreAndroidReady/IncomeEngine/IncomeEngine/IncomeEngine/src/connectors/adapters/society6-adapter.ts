/**
 * Society6 Adapter
 * Premium POD platform connector for Society6
 *
 * NOTE: Society6 has no public API. Uses browser automation via Playwright.
 * Higher-end marketplace focused on artists and home decor.
 *
 * Design Specs: Min 6500x6500px, Max 150MB, PNG/JPG, 300 DPI, sRGB color mode
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  ProductType,
  ProductStatus,
} from '../core/types';

// Society6 art categories
export type Society6Category =
  | 'abstract'
  | 'animals'
  | 'architecture'
  | 'botanical'
  | 'fashion'
  | 'geometric'
  | 'illustration'
  | 'landscape'
  | 'minimalism'
  | 'nature'
  | 'pattern'
  | 'photography'
  | 'pop-art'
  | 'portrait'
  | 'typography';

// Society6 product types (35+ products)
export type Society6ProductType =
  // Wall Art
  | 'art-print'
  | 'canvas-print'
  | 'framed-print'
  | 'metal-print'
  | 'poster'
  | 'acrylic-block'
  | 'wood-wall-art'
  // Apparel
  | 't-shirt'
  | 'tank-top'
  | 'hoodie'
  | 'all-over-print'
  // Home Decor
  | 'throw-pillow'
  | 'floor-pillow'
  | 'throw-blanket'
  | 'duvet-cover'
  | 'shower-curtain'
  | 'bath-mat'
  | 'rug'
  | 'comforter'
  | 'tapestry'
  // Drinkware
  | 'mug'
  | 'travel-mug'
  | 'water-bottle'
  | 'coaster'
  // Bags & Accessories
  | 'tote-bag'
  | 'weekender-bag'
  | 'backpack'
  | 'zipper-pouch'
  | 'phone-case'
  | 'laptop-sleeve'
  | 'tablet-case'
  // Stationery
  | 'notebook'
  | 'spiral-notebook'
  | 'hardcover-journal'
  // Other
  | 'clock'
  | 'desk-mat'
  | 'sticker'
  | 'magnet'
  // Furniture
  | 'credenza'
  | 'side-table';

// Society6 base margins by product category (artist sets markup on top)
const SOCIETY6_BASE_MARGINS: Record<string, number> = {
  prints: 10, // $10 base for wall art
  apparel: 8, // $8 base for clothing
  home: 12, // $12 base for home decor
  accessories: 6, // $6 base for bags, cases
  stationery: 5, // $5 base for notebooks
  furniture: 25, // $25 base for furniture items
};

// Map products to categories for margin calculation
const PRODUCT_CATEGORY_MAP: Record<Society6ProductType, keyof typeof SOCIETY6_BASE_MARGINS> = {
  'art-print': 'prints',
  'canvas-print': 'prints',
  'framed-print': 'prints',
  'metal-print': 'prints',
  'poster': 'prints',
  'acrylic-block': 'prints',
  'wood-wall-art': 'prints',
  't-shirt': 'apparel',
  'tank-top': 'apparel',
  'hoodie': 'apparel',
  'all-over-print': 'apparel',
  'throw-pillow': 'home',
  'floor-pillow': 'home',
  'throw-blanket': 'home',
  'duvet-cover': 'home',
  'shower-curtain': 'home',
  'bath-mat': 'home',
  'rug': 'home',
  'comforter': 'home',
  'tapestry': 'home',
  'mug': 'home',
  'travel-mug': 'home',
  'water-bottle': 'home',
  'coaster': 'home',
  'tote-bag': 'accessories',
  'weekender-bag': 'accessories',
  'backpack': 'accessories',
  'zipper-pouch': 'accessories',
  'phone-case': 'accessories',
  'laptop-sleeve': 'accessories',
  'tablet-case': 'accessories',
  'notebook': 'stationery',
  'spiral-notebook': 'stationery',
  'hardcover-journal': 'stationery',
  'clock': 'home',
  'desk-mat': 'accessories',
  'sticker': 'accessories',
  'magnet': 'accessories',
  'credenza': 'furniture',
  'side-table': 'furniture',
};

// Category to product recommendations
const CATEGORY_RECOMMENDATIONS: Record<Society6Category, Society6ProductType[]> = {
  abstract: ['art-print', 'canvas-print', 'throw-pillow', 'rug', 'duvet-cover', 'tapestry'],
  animals: ['art-print', 'throw-pillow', 'throw-blanket', 'mug', 'tote-bag', 'phone-case'],
  architecture: ['art-print', 'poster', 'canvas-print', 'framed-print'],
  botanical: ['art-print', 'throw-pillow', 'shower-curtain', 'duvet-cover', 'notebook'],
  fashion: ['tote-bag', 'phone-case', 't-shirt', 'zipper-pouch', 'backpack'],
  geometric: ['throw-pillow', 'rug', 'throw-blanket', 'clock', 'art-print'],
  illustration: ['art-print', 't-shirt', 'sticker', 'mug', 'tote-bag', 'notebook'],
  landscape: ['art-print', 'canvas-print', 'framed-print', 'metal-print', 'tapestry'],
  minimalism: ['art-print', 'poster', 'notebook', 'mug', 'clock'],
  nature: ['art-print', 'throw-blanket', 'shower-curtain', 'bath-mat', 'tapestry'],
  pattern: ['duvet-cover', 'throw-pillow', 'rug', 'shower-curtain', 'all-over-print'],
  photography: ['art-print', 'canvas-print', 'framed-print', 'metal-print', 'poster'],
  'pop-art': ['art-print', 'poster', 't-shirt', 'mug', 'phone-case'],
  portrait: ['art-print', 'canvas-print', 'framed-print', 'poster'],
  typography: ['art-print', 'poster', 't-shirt', 'mug', 'notebook', 'tote-bag'],
};

export interface Society6Credentials {
  email: string;
  password: string;
  artistName?: string;
}

export interface Society6Artwork {
  title: string;
  description: string;
  tags: string[];
  category: Society6Category;
  imageUrl: string;
  products: Society6ProductType[];
  pricingTier: 'standard' | 'premium';
}

/**
 * Society6 platform adapter
 * Uses Playwright for browser automation (no public API available)
 */
export class Society6Adapter extends BaseConnector {
  readonly name = 'society6';
  readonly displayName = 'Society6';
  readonly workflowGroup = 'pod_digital' as const;
  readonly connectorType = 'playwright' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: false,
    supportsBulkOperations: false,
    supportsWebhooks: false,
    supportsInventorySync: false,
    supportsOrderFulfillment: false,
    supportsAnalytics: false,
    maxProductsPerRequest: 1,
    rateLimits: {
      requestsPerMinute: 5, // Very conservative for browser automation
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 100,
    maxDescriptionLength: 1000,
    maxImages: 1, // Single artwork upload
    maxTags: 20,
    maxVariants: 40, // Many product types available
    allowedImageFormats: ['png', 'jpg', 'jpeg'],
    maxImageSizeMB: 150,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['title', 'description', 'tags', 'category', 'imageUrl'],
    requiredImageDimensions: { width: 6500, height: 6500 },
    requiredCategories: true,
    requiredShippingProfile: false,
  };

  private credentials: Society6Credentials | null = null;

  constructor(config: ConnectorConfig) {
    super(config);
    if (config.credentials) {
      this.credentials = {
        email: config.credentials.email,
        password: config.credentials.password,
        artistName: config.credentials.artistName,
      };
    }
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    if (!this.credentials?.email || !this.credentials?.password) {
      return {
        success: false,
        error: this.createError('AUTH_MISSING', 'Society6 email and password are required'),
      };
    }

    this.log('info', 'Society6 authentication requires browser automation');

    this.authToken = {
      accessToken: Buffer.from(`${this.credentials.email}:authenticated`).toString('base64'),
      tokenType: 'Basic',
    };

    return {
      success: true,
      data: this.authToken,
    };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    if (this.authToken) {
      return { success: true, data: this.authToken };
    }
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    if (!this.credentials?.email || !this.credentials?.password) {
      return false;
    }
    return true;
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    this.log('info', 'Listing Society6 artworks via browser automation');

    return {
      success: true,
      data: {
        items: [],
        total: 0,
        page: options?.page ?? 1,
        limit: options?.limit ?? 20,
        hasMore: false,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    this.log('info', `Getting Society6 artwork ${id}`);

    return {
      success: false,
      error: this.createError(
        'NOT_IMPLEMENTED',
        'Society6 product retrieval requires browser automation',
        false
      ),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_FAILED',
          `Product validation failed: ${validation.issues.map((i) => i.message).join(', ')}`,
          false
        ),
      };
    }

    this.log('info', `Creating Society6 artwork: ${product.title}`);

    return {
      success: true,
      data: {
        id: `society6_${Date.now()}`,
        externalId: `society6_pending_${Date.now()}`,
        externalUrl: 'https://society6.com/studio',
        status: 'pending' as ProductStatus,
      },
    };
  }

  async updateProduct(id: string, updates: Partial<ProductInput>): Promise<ConnectorResult<UpdateResult>> {
    this.log('info', `Updating Society6 artwork ${id}`);

    return {
      success: false,
      error: this.createError(
        'NOT_IMPLEMENTED',
        'Society6 product updates require browser automation',
        false
      ),
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    this.log('info', `Deleting Society6 artwork ${id}`);

    return {
      success: false,
      error: this.createError(
        'NOT_IMPLEMENTED',
        'Society6 product deletion requires browser automation',
        false
      ),
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const artwork = platformProduct as Society6Artwork;

    return {
      id: `society6_${Date.now()}`,
      externalId: undefined,
      title: artwork.title,
      description: artwork.description,
      productType: 'poster' as ProductType,
      images: [
        {
          id: '1',
          url: artwork.imageUrl,
          position: 0,
          isPrimary: true,
        },
      ],
      variants: [],
      pricing: {
        price: 0, // Society6 sets base price, artist adds markup
        currency: 'USD',
        taxable: true,
      },
      tags: artwork.tags,
      metadata: {
        category: artwork.category,
        products: artwork.products,
        pricingTier: artwork.pricingTier,
      },
      platformData: {},
      status: 'draft' as ProductStatus,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }

  denormalizeProduct(product: NormalizedProduct): Society6Artwork {
    return {
      title: product.title,
      description: product.description,
      tags: product.tags,
      category: (product.metadata?.category as Society6Category) ?? 'illustration',
      imageUrl: product.images[0]?.url ?? '',
      products: (product.metadata?.products as Society6ProductType[]) ?? ['art-print'],
      pricingTier: (product.metadata?.pricingTier as 'standard' | 'premium') ?? 'standard',
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    // Title validation
    if (product.title.length < 3) {
      issues.push(
        this.createValidationIssue('title', 'Title must be at least 3 characters', 'error')
      );
    }
    if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title must be ${this.platformLimits.maxTitleLength} characters or less`,
          'error'
        )
      );
    }

    // Description validation
    if (product.description.length < 20) {
      issues.push(
        this.createValidationIssue(
          'description',
          'Description should be at least 20 characters for better discoverability',
          'warning'
        )
      );
    }

    // Tags validation
    if (!product.tags || product.tags.length < 5) {
      issues.push(
        this.createValidationIssue('tags', 'At least 5 tags are required', 'error')
      );
    }
    if (product.tags && product.tags.length > this.platformLimits.maxTags) {
      issues.push(
        this.createValidationIssue(
          'tags',
          `Maximum ${this.platformLimits.maxTags} tags allowed`,
          'warning'
        )
      );
    }

    // Image validation
    if (!product.images || product.images.length === 0) {
      issues.push(
        this.createValidationIssue('images', 'At least one image is required', 'error')
      );
    }

    return {
      valid: !issues.some((i) => i.severity === 'error'),
      issues,
    };
  }

  // ============================================================================
  // Society6-Specific Methods
  // ============================================================================

  /**
   * Get base margin for a product type
   */
  getBaseMargin(productType: Society6ProductType): number {
    const category = PRODUCT_CATEGORY_MAP[productType];
    return SOCIETY6_BASE_MARGINS[category] || 10;
  }

  /**
   * Calculate artist earnings
   */
  calculateEarnings(
    productType: Society6ProductType,
    artistMarkup: number = 10
  ): { baseMargin: number; artistEarnings: number; totalMargin: number } {
    const baseMargin = this.getBaseMargin(productType);
    const artistEarnings = artistMarkup;
    const totalMargin = baseMargin + artistMarkup;

    return { baseMargin, artistEarnings, totalMargin };
  }

  /**
   * Get design upload specifications
   */
  getDesignSpecs(): {
    minWidth: number;
    minHeight: number;
    maxFileSize: string;
    formats: string[];
    colorMode: string;
    dpi: number;
  } {
    return {
      minWidth: 6500,
      minHeight: 6500,
      maxFileSize: '150MB',
      formats: ['PNG', 'JPG'],
      colorMode: 'sRGB',
      dpi: 300,
    };
  }

  /**
   * Get all available categories
   */
  getAllCategories(): Society6Category[] {
    return Object.keys(CATEGORY_RECOMMENDATIONS) as Society6Category[];
  }

  /**
   * Get products recommended for a category
   */
  getProductsForCategory(category: Society6Category): Society6ProductType[] {
    return CATEGORY_RECOMMENDATIONS[category] || CATEGORY_RECOMMENDATIONS['illustration'];
  }

  /**
   * Get all product types grouped by category
   */
  getProductTypesByCategory(): Record<string, Society6ProductType[]> {
    const result: Record<string, Society6ProductType[]> = {};

    for (const [product, category] of Object.entries(PRODUCT_CATEGORY_MAP)) {
      if (!result[category]) {
        result[category] = [];
      }
      result[category].push(product as Society6ProductType);
    }

    return result;
  }

  /**
   * Validate artwork before upload
   */
  validateArtwork(artwork: Society6Artwork): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (artwork.title.length < 3) {
      errors.push('Title must be at least 3 characters');
    }
    if (artwork.title.length > 100) {
      errors.push('Title must be 100 characters or less');
    }
    if (artwork.tags.length < 5) {
      errors.push('At least 5 tags required');
    }
    if (artwork.tags.length > 20) {
      errors.push('Maximum 20 tags allowed');
    }
    if (artwork.description.length < 20) {
      errors.push('Description should be at least 20 characters');
    }
    if (!artwork.imageUrl) {
      errors.push('Image URL is required');
    }
    if (!artwork.category) {
      errors.push('Category is required');
    }
    if (!artwork.products || artwork.products.length === 0) {
      errors.push('At least one product type must be selected');
    }

    return { valid: errors.length === 0, errors };
  }

  /**
   * Get best-selling categories on Society6
   */
  static getBestSellingCategories(): Society6Category[] {
    return ['botanical', 'abstract', 'minimalism', 'illustration', 'pattern', 'typography'];
  }
}

export default Society6Adapter;
