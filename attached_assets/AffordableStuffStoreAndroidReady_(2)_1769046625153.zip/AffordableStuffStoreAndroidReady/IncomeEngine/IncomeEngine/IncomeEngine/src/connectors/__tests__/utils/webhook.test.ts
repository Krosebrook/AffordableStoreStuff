/**
 * ============================================================================
 * WEBHOOK UTILITY TEST SUITE
 * ============================================================================
 *
 * Tests for the Webhook notification utility.
 * Covers webhook sending, queue management, and notification service.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  sendWebhook,
  WebhookQueueManager,
  NotificationService,
  WebhookConfig,
  WebhookPayload,
  WebhookEventType,
} from '../../utils/webhook';

// Mock Supabase
vi.mock('@supabase/supabase-js', () => ({
  createClient: vi.fn(() => mockSupabase),
}));

// Create mock Supabase client
const mockSupabase = {
  from: vi.fn().mockReturnThis(),
  select: vi.fn().mockReturnThis(),
  insert: vi.fn().mockReturnThis(),
  update: vi.fn().mockReturnThis(),
  eq: vi.fn().mockReturnThis(),
  lte: vi.fn().mockReturnThis(),
  order: vi.fn().mockReturnThis(),
  limit: vi.fn().mockReturnThis(),
  single: vi.fn().mockReturnThis(),
  contains: vi.fn().mockReturnThis(),
};

// Mock fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

describe('Webhook Utility', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockFetch.mockReset();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // ===========================================================================
  // sendWebhook Tests
  // ===========================================================================

  describe('sendWebhook', () => {
    const defaultConfig: WebhookConfig = {
      url: 'https://example.com/webhook',
      retryAttempts: 3,
      retryDelayMs: 100,
      timeoutMs: 5000,
    };

    const defaultPayload: WebhookPayload = {
      event: 'product_published',
      timestamp: new Date().toISOString(),
      data: { productId: 'prod-123' },
    };

    describe('Success Cases', () => {
      it('should send webhook successfully', async () => {
        mockFetch.mockResolvedValueOnce({
          ok: true,
          status: 200,
        });

        const result = await sendWebhook(defaultConfig, defaultPayload);

        expect(result.success).toBe(true);
        expect(result.statusCode).toBe(200);
        expect(result.attempts).toBe(1);
      });

      it('should include correct headers', async () => {
        mockFetch.mockResolvedValueOnce({
          ok: true,
          status: 200,
        });

        await sendWebhook(defaultConfig, defaultPayload);

        expect(mockFetch).toHaveBeenCalledWith(
          defaultConfig.url,
          expect.objectContaining({
            method: 'POST',
            headers: expect.objectContaining({
              'Content-Type': 'application/json',
              'X-Webhook-Event': defaultPayload.event,
              'X-Webhook-Timestamp': defaultPayload.timestamp,
            }),
          })
        );
      });

      it('should include signature when secret provided', async () => {
        mockFetch.mockResolvedValueOnce({
          ok: true,
          status: 200,
        });

        const configWithSecret: WebhookConfig = {
          ...defaultConfig,
          secret: 'my-webhook-secret',
        };

        await sendWebhook(configWithSecret, defaultPayload);

        expect(mockFetch).toHaveBeenCalledWith(
          defaultConfig.url,
          expect.objectContaining({
            headers: expect.objectContaining({
              'X-Webhook-Signature': expect.stringMatching(/^sha256=/),
            }),
          })
        );
      });

      it('should include idempotency key when provided', async () => {
        mockFetch.mockResolvedValueOnce({
          ok: true,
          status: 200,
        });

        const payloadWithIdempotency: WebhookPayload = {
          ...defaultPayload,
          metadata: {
            source: 'income-engine',
            version: '2.0.0',
            idempotencyKey: 'idem-123',
          },
        };

        await sendWebhook(defaultConfig, payloadWithIdempotency);

        expect(mockFetch).toHaveBeenCalledWith(
          defaultConfig.url,
          expect.objectContaining({
            headers: expect.objectContaining({
              'X-Idempotency-Key': 'idem-123',
            }),
          })
        );
      });

      it('should record duration', async () => {
        mockFetch.mockImplementation(async () => {
          await new Promise(resolve => setTimeout(resolve, 50));
          return { ok: true, status: 200 };
        });

        const result = await sendWebhook(defaultConfig, defaultPayload);

        expect(result.duration).toBeGreaterThanOrEqual(0);
      });
    });

    describe('Retry Behavior', () => {
      it('should retry on server error (5xx)', async () => {
        mockFetch
          .mockResolvedValueOnce({ ok: false, status: 500 })
          .mockResolvedValueOnce({ ok: false, status: 502 })
          .mockResolvedValueOnce({ ok: true, status: 200 });

        const result = await sendWebhook(defaultConfig, defaultPayload);

        expect(result.success).toBe(true);
        expect(result.attempts).toBe(3);
      });

      it('should retry on rate limit (429)', async () => {
        mockFetch
          .mockResolvedValueOnce({ ok: false, status: 429 })
          .mockResolvedValueOnce({ ok: true, status: 200 });

        const result = await sendWebhook(defaultConfig, defaultPayload);

        expect(result.success).toBe(true);
        expect(result.attempts).toBe(2);
      });

      it('should not retry on client error (4xx except 429)', async () => {
        mockFetch.mockResolvedValueOnce({
          ok: false,
          status: 400,
          text: () => Promise.resolve('Bad Request'),
        });

        const result = await sendWebhook(defaultConfig, defaultPayload);

        expect(result.success).toBe(false);
        expect(result.attempts).toBe(1);
        expect(result.error).toContain('HTTP 400');
      });

      it('should fail after max retries', async () => {
        mockFetch.mockResolvedValue({ ok: false, status: 500 });

        const result = await sendWebhook(defaultConfig, defaultPayload);

        expect(result.success).toBe(false);
        expect(result.attempts).toBe(3);
      });

      it('should use exponential backoff', async () => {
        const startTime = Date.now();
        mockFetch
          .mockResolvedValueOnce({ ok: false, status: 500 })
          .mockResolvedValueOnce({ ok: false, status: 500 })
          .mockResolvedValueOnce({ ok: true, status: 200 });

        await sendWebhook({
          ...defaultConfig,
          retryDelayMs: 100,
        }, defaultPayload);

        const elapsed = Date.now() - startTime;
        // Should wait at least 100ms + 200ms = 300ms for 2 retries
        expect(elapsed).toBeGreaterThanOrEqual(200);
      });
    });

    describe('Timeout Handling', () => {
      it('should timeout after specified duration', async () => {
        mockFetch.mockImplementation(() =>
          new Promise(resolve => setTimeout(resolve, 10000))
        );

        const result = await sendWebhook({
          ...defaultConfig,
          timeoutMs: 100,
          retryAttempts: 1,
        }, defaultPayload);

        expect(result.success).toBe(false);
        expect(result.error).toContain('Timeout');
      });

      it('should use default timeout of 10000ms', () => {
        const config: WebhookConfig = { url: 'https://example.com/webhook' };
        expect(config.timeoutMs).toBeUndefined();
        // Default is applied in sendWebhook function
      });
    });

    describe('Error Handling', () => {
      it('should handle network errors', async () => {
        mockFetch.mockRejectedValue(new Error('Network error'));

        const result = await sendWebhook({
          ...defaultConfig,
          retryAttempts: 1,
        }, defaultPayload);

        expect(result.success).toBe(false);
        expect(result.error).toBe('Network error');
      });

      it('should handle abort errors', async () => {
        const abortError = new Error('The operation was aborted');
        abortError.name = 'AbortError';
        mockFetch.mockRejectedValue(abortError);

        const result = await sendWebhook({
          ...defaultConfig,
          retryAttempts: 1,
          timeoutMs: 100,
        }, defaultPayload);

        expect(result.success).toBe(false);
        expect(result.error).toContain('Timeout');
      });

      it('should handle unknown error types', async () => {
        mockFetch.mockRejectedValue('Unknown error');

        const result = await sendWebhook({
          ...defaultConfig,
          retryAttempts: 1,
        }, defaultPayload);

        expect(result.success).toBe(false);
        expect(result.error).toBe('Unknown error');
      });
    });

    describe('Payload Serialization', () => {
      it('should serialize payload to JSON', async () => {
        mockFetch.mockResolvedValueOnce({ ok: true, status: 200 });

        const payload: WebhookPayload = {
          event: 'order_received',
          timestamp: '2024-01-01T00:00:00.000Z',
          data: { orderId: 'order-123', amount: 99.99 },
        };

        await sendWebhook(defaultConfig, payload);

        const callArgs = mockFetch.mock.calls[0];
        const body = callArgs[1].body;
        const parsed = JSON.parse(body);

        expect(parsed.event).toBe('order_received');
        expect(parsed.data.orderId).toBe('order-123');
      });
    });
  });

  // ===========================================================================
  // WebhookQueueManager Tests
  // ===========================================================================

  describe('WebhookQueueManager', () => {
    let queueManager: WebhookQueueManager;

    beforeEach(() => {
      queueManager = new WebhookQueueManager(
        'https://test.supabase.co',
        'test-key'
      );
    });

    afterEach(() => {
      queueManager.stopProcessing();
    });

    describe('enqueue', () => {
      it('should queue webhook for delivery', async () => {
        mockSupabase.single.mockResolvedValueOnce({
          data: { id: 'queue-123' },
          error: null,
        });

        const payload: WebhookPayload = {
          event: 'product_published',
          timestamp: new Date().toISOString(),
          data: { productId: 'prod-123' },
        };

        const id = await queueManager.enqueue(
          'https://example.com/webhook',
          payload
        );

        expect(id).toBe('queue-123');
        expect(mockSupabase.from).toHaveBeenCalledWith('webhook_queue');
      });

      it('should use default max attempts of 5', async () => {
        mockSupabase.single.mockResolvedValueOnce({
          data: { id: 'queue-123' },
          error: null,
        });

        const payload: WebhookPayload = {
          event: 'product_published',
          timestamp: new Date().toISOString(),
          data: {},
        };

        await queueManager.enqueue('https://example.com/webhook', payload);

        expect(mockSupabase.insert).toHaveBeenCalledWith(
          expect.objectContaining({
            max_attempts: 5,
          })
        );
      });

      it('should use custom max attempts', async () => {
        mockSupabase.single.mockResolvedValueOnce({
          data: { id: 'queue-123' },
          error: null,
        });

        const payload: WebhookPayload = {
          event: 'product_published',
          timestamp: new Date().toISOString(),
          data: {},
        };

        await queueManager.enqueue('https://example.com/webhook', payload, {
          maxAttempts: 10,
        });

        expect(mockSupabase.insert).toHaveBeenCalledWith(
          expect.objectContaining({
            max_attempts: 10,
          })
        );
      });

      it('should support delayed delivery', async () => {
        mockSupabase.single.mockResolvedValueOnce({
          data: { id: 'queue-123' },
          error: null,
        });

        const payload: WebhookPayload = {
          event: 'product_published',
          timestamp: new Date().toISOString(),
          data: {},
        };

        const beforeEnqueue = Date.now();
        await queueManager.enqueue('https://example.com/webhook', payload, {
          delayMs: 5000,
        });

        expect(mockSupabase.insert).toHaveBeenCalledWith(
          expect.objectContaining({
            next_retry_at: expect.any(String),
          })
        );

        const insertCall = mockSupabase.insert.mock.calls[0][0];
        const nextRetryAt = new Date(insertCall.next_retry_at).getTime();
        expect(nextRetryAt).toBeGreaterThanOrEqual(beforeEnqueue + 5000);
      });

      it('should throw error on database failure', async () => {
        mockSupabase.single.mockResolvedValueOnce({
          data: null,
          error: { message: 'Insert failed' },
        });

        const payload: WebhookPayload = {
          event: 'product_published',
          timestamp: new Date().toISOString(),
          data: {},
        };

        await expect(
          queueManager.enqueue('https://example.com/webhook', payload)
        ).rejects.toThrow('Failed to queue webhook');
      });
    });

    describe('startProcessing', () => {
      it('should start processing interval', () => {
        const setIntervalSpy = vi.spyOn(global, 'setInterval');

        queueManager.startProcessing(1000);

        expect(setIntervalSpy).toHaveBeenCalledWith(
          expect.any(Function),
          1000
        );
      });

      it('should clear existing interval when restarted', () => {
        const clearIntervalSpy = vi.spyOn(global, 'clearInterval');

        queueManager.startProcessing(1000);
        queueManager.startProcessing(2000);

        expect(clearIntervalSpy).toHaveBeenCalled();
      });

      it('should process queue immediately on start', async () => {
        mockSupabase.limit.mockResolvedValueOnce({
          data: [],
          error: null,
        });

        queueManager.startProcessing(10000);

        // Wait for initial processing
        await new Promise(resolve => setTimeout(resolve, 10));

        expect(mockSupabase.from).toHaveBeenCalledWith('webhook_queue');
      });
    });

    describe('stopProcessing', () => {
      it('should stop processing interval', () => {
        const clearIntervalSpy = vi.spyOn(global, 'clearInterval');

        queueManager.startProcessing(1000);
        queueManager.stopProcessing();

        expect(clearIntervalSpy).toHaveBeenCalled();
      });

      it('should handle stop when not started', () => {
        expect(() => queueManager.stopProcessing()).not.toThrow();
      });
    });
  });

  // ===========================================================================
  // NotificationService Tests
  // ===========================================================================

  describe('NotificationService', () => {
    let notificationService: NotificationService;

    beforeEach(() => {
      notificationService = new NotificationService(
        'https://test.supabase.co',
        'test-key'
      );
    });

    afterEach(() => {
      notificationService.stop();
    });

    describe('notify', () => {
      it('should send notification to configured endpoints', async () => {
        mockSupabase.eq.mockResolvedValueOnce({
          data: [
            { url: 'https://example.com/webhook1', secret: null, events: ['product_published'] },
            { url: 'https://example.com/webhook2', secret: null, events: ['product_published'] },
          ],
          error: null,
        });

        mockSupabase.single.mockResolvedValue({ data: { id: 'queue-123' }, error: null });

        await notificationService.notify('product_published', {
          productId: 'prod-123',
        });

        // Should have queued for both endpoints
        expect(mockSupabase.from).toHaveBeenCalledWith('webhook_endpoints');
      });

      it('should not send when no endpoints configured', async () => {
        mockSupabase.eq.mockResolvedValueOnce({
          data: [],
          error: null,
        });

        await notificationService.notify('product_published', {
          productId: 'prod-123',
        });

        // Should only query endpoints, not insert to queue
        expect(mockSupabase.insert).not.toHaveBeenCalled();
      });

      it('should include correct metadata', async () => {
        mockSupabase.eq.mockResolvedValueOnce({
          data: [
            { url: 'https://example.com/webhook', events: ['budget_warning'] },
          ],
          error: null,
        });

        mockSupabase.single.mockResolvedValueOnce({
          data: { id: 'queue-123' },
          error: null,
        });

        await notificationService.notify('budget_warning', {
          currentSpend: 20,
          limit: 25,
        });

        // Verify metadata was included
        const insertCall = mockSupabase.insert.mock.calls[0];
        // The insert should contain payload with metadata
        expect(mockSupabase.insert).toHaveBeenCalled();
      });

      it('should generate idempotency key', async () => {
        mockSupabase.eq.mockResolvedValueOnce({
          data: [{ url: 'https://example.com/webhook', events: ['order_received'] }],
          error: null,
        });

        mockSupabase.single.mockResolvedValueOnce({
          data: { id: 'queue-123' },
          error: null,
        });

        await notificationService.notify('order_received', { orderId: 'order-123' });

        // Idempotency key should be in the payload metadata
        expect(mockSupabase.insert).toHaveBeenCalled();
      });
    });

    describe('start', () => {
      it('should start queue processing', () => {
        const startSpy = vi.spyOn(notificationService, 'start');
        notificationService.start();
        expect(startSpy).toHaveBeenCalled();
      });
    });

    describe('stop', () => {
      it('should stop queue processing', () => {
        const stopSpy = vi.spyOn(notificationService, 'stop');
        notificationService.stop();
        expect(stopSpy).toHaveBeenCalled();
      });
    });
  });

  // ===========================================================================
  // Webhook Event Types Tests
  // ===========================================================================

  describe('Webhook Event Types', () => {
    const allEventTypes: WebhookEventType[] = [
      'low_stock_alert',
      'out_of_stock',
      'order_received',
      'order_fulfilled',
      'order_cancelled',
      'product_published',
      'product_rejected',
      'budget_warning',
      'budget_critical',
      'platform_error',
      'safeguard_triggered',
    ];

    it('should support all defined event types', () => {
      expect(allEventTypes).toHaveLength(11);
    });

    it('should include stock events', () => {
      expect(allEventTypes).toContain('low_stock_alert');
      expect(allEventTypes).toContain('out_of_stock');
    });

    it('should include order events', () => {
      expect(allEventTypes).toContain('order_received');
      expect(allEventTypes).toContain('order_fulfilled');
      expect(allEventTypes).toContain('order_cancelled');
    });

    it('should include product events', () => {
      expect(allEventTypes).toContain('product_published');
      expect(allEventTypes).toContain('product_rejected');
    });

    it('should include budget events', () => {
      expect(allEventTypes).toContain('budget_warning');
      expect(allEventTypes).toContain('budget_critical');
    });

    it('should include system events', () => {
      expect(allEventTypes).toContain('platform_error');
      expect(allEventTypes).toContain('safeguard_triggered');
    });
  });

  // ===========================================================================
  // Webhook Signature Tests
  // ===========================================================================

  describe('Webhook Signature', () => {
    it('should generate HMAC-SHA256 signature', async () => {
      mockFetch.mockResolvedValueOnce({ ok: true, status: 200 });

      await sendWebhook(
        {
          url: 'https://example.com/webhook',
          secret: 'test-secret',
        },
        {
          event: 'product_published',
          timestamp: new Date().toISOString(),
          data: {},
        }
      );

      const headers = mockFetch.mock.calls[0][1].headers;
      expect(headers['X-Webhook-Signature']).toMatch(/^sha256=[a-f0-9]{64}$/);
    });

    it('should produce consistent signatures for same payload', async () => {
      const signatures: string[] = [];

      mockFetch.mockResolvedValue({ ok: true, status: 200 });

      const config: WebhookConfig = {
        url: 'https://example.com/webhook',
        secret: 'test-secret',
      };

      const payload: WebhookPayload = {
        event: 'product_published',
        timestamp: '2024-01-01T00:00:00.000Z', // Fixed timestamp
        data: { id: 'fixed-id' },
      };

      await sendWebhook(config, payload);
      signatures.push(mockFetch.mock.calls[0][1].headers['X-Webhook-Signature']);

      await sendWebhook(config, payload);
      signatures.push(mockFetch.mock.calls[1][1].headers['X-Webhook-Signature']);

      expect(signatures[0]).toBe(signatures[1]);
    });

    it('should produce different signatures for different secrets', async () => {
      const signatures: string[] = [];

      mockFetch.mockResolvedValue({ ok: true, status: 200 });

      const payload: WebhookPayload = {
        event: 'product_published',
        timestamp: '2024-01-01T00:00:00.000Z',
        data: {},
      };

      await sendWebhook(
        { url: 'https://example.com/webhook', secret: 'secret-1' },
        payload
      );
      signatures.push(mockFetch.mock.calls[0][1].headers['X-Webhook-Signature']);

      await sendWebhook(
        { url: 'https://example.com/webhook', secret: 'secret-2' },
        payload
      );
      signatures.push(mockFetch.mock.calls[1][1].headers['X-Webhook-Signature']);

      expect(signatures[0]).not.toBe(signatures[1]);
    });
  });

  // ===========================================================================
  // Webhook Result Structure Tests
  // ===========================================================================

  describe('Webhook Result Structure', () => {
    it('should include all fields on success', async () => {
      mockFetch.mockResolvedValueOnce({ ok: true, status: 200 });

      const result = await sendWebhook(
        { url: 'https://example.com/webhook' },
        { event: 'product_published', timestamp: new Date().toISOString(), data: {} }
      );

      expect(result).toHaveProperty('success', true);
      expect(result).toHaveProperty('statusCode', 200);
      expect(result).toHaveProperty('attempts');
      expect(result).toHaveProperty('duration');
      expect(result.error).toBeUndefined();
    });

    it('should include error on failure', async () => {
      mockFetch.mockResolvedValueOnce({
        ok: false,
        status: 400,
        text: () => Promise.resolve('Bad Request'),
      });

      const result = await sendWebhook(
        { url: 'https://example.com/webhook', retryAttempts: 1 },
        { event: 'product_published', timestamp: new Date().toISOString(), data: {} }
      );

      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });
  });

  // ===========================================================================
  // Edge Cases
  // ===========================================================================

  describe('Edge Cases', () => {
    it('should handle empty data payload', async () => {
      mockFetch.mockResolvedValueOnce({ ok: true, status: 200 });

      const result = await sendWebhook(
        { url: 'https://example.com/webhook' },
        { event: 'safeguard_triggered', timestamp: new Date().toISOString(), data: {} }
      );

      expect(result.success).toBe(true);
    });

    it('should handle large data payload', async () => {
      mockFetch.mockResolvedValueOnce({ ok: true, status: 200 });

      const largeData: Record<string, unknown> = {};
      for (let i = 0; i < 1000; i++) {
        largeData[`key${i}`] = `value${i}`.repeat(100);
      }

      const result = await sendWebhook(
        { url: 'https://example.com/webhook' },
        { event: 'product_published', timestamp: new Date().toISOString(), data: largeData }
      );

      expect(result.success).toBe(true);
    });

    it('should handle special characters in data', async () => {
      mockFetch.mockResolvedValueOnce({ ok: true, status: 200 });

      const result = await sendWebhook(
        { url: 'https://example.com/webhook' },
        {
          event: 'product_published',
          timestamp: new Date().toISOString(),
          data: {
            title: 'Test "Product" with <special> & characters',
            emoji: 'emoji test here',
            unicode: 'Unicode test',
          },
        }
      );

      expect(result.success).toBe(true);
    });

    it('should handle URL with query parameters', async () => {
      mockFetch.mockResolvedValueOnce({ ok: true, status: 200 });

      const result = await sendWebhook(
        { url: 'https://example.com/webhook?token=abc&version=2' },
        { event: 'product_published', timestamp: new Date().toISOString(), data: {} }
      );

      expect(result.success).toBe(true);
      expect(mockFetch).toHaveBeenCalledWith(
        'https://example.com/webhook?token=abc&version=2',
        expect.any(Object)
      );
    });
  });

  // ===========================================================================
  // Default Export Tests
  // ===========================================================================

  describe('Default Export', () => {
    it('should export all components', async () => {
      const webhookModule = await import('../../utils/webhook');

      expect(webhookModule.default.sendWebhook).toBeDefined();
      expect(webhookModule.default.WebhookQueueManager).toBeDefined();
      expect(webhookModule.default.NotificationService).toBeDefined();
    });
  });

  // ===========================================================================
  // Concurrent Processing Tests
  // ===========================================================================

  describe('Concurrent Processing', () => {
    it('should handle multiple concurrent webhook sends', async () => {
      mockFetch.mockResolvedValue({ ok: true, status: 200 });

      const promises = Array(10)
        .fill(null)
        .map((_, i) =>
          sendWebhook(
            { url: 'https://example.com/webhook' },
            {
              event: 'product_published',
              timestamp: new Date().toISOString(),
              data: { index: i },
            }
          )
        );

      const results = await Promise.all(promises);

      expect(results.every(r => r.success)).toBe(true);
      expect(mockFetch).toHaveBeenCalledTimes(10);
    });
  });

  // ===========================================================================
  // Queue Status Tests
  // ===========================================================================

  describe('Queue Item Status', () => {
    const statuses = ['pending', 'processing', 'completed', 'failed'] as const;

    it('should define all queue statuses', () => {
      expect(statuses).toHaveLength(4);
    });

    it('should include pending status for new items', () => {
      expect(statuses).toContain('pending');
    });

    it('should include processing status for active items', () => {
      expect(statuses).toContain('processing');
    });

    it('should include completed status for successful items', () => {
      expect(statuses).toContain('completed');
    });

    it('should include failed status for exhausted retries', () => {
      expect(statuses).toContain('failed');
    });
  });
});
