/**
 * TeePublic Adapter
 * POD platform connector for TeePublic
 *
 * NOTE: TeePublic has no public API. Uses browser automation via Playwright.
 * Similar to Redbubble but with different product catalog and fixed royalty structure.
 *
 * Design Specs: Min 2400x2400px, Max 25MB, PNG only, sRGB color mode
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  ProductType,
  ProductStatus,
  DesignInput,
  Design,
} from '../core/types';

// TeePublic product types with fixed royalty structure
export type TeePublicProductType =
  | 't-shirt'
  | 'hoodie'
  | 'tank-top'
  | 'long-sleeve'
  | 'pullover'
  | 'mug'
  | 'notebook'
  | 'sticker'
  | 'phone-case'
  | 'tote-bag'
  | 'poster'
  | 'tapestry'
  | 'throw-pillow'
  | 'throw-blanket'
  | 'pin'
  | 'magnet'
  | 'mask';

// TeePublic royalty structure (they set prices, you get fixed royalty)
const TEEPUBLIC_ROYALTIES: Record<TeePublicProductType, { salePrice: number; royalty: number }> = {
  't-shirt': { salePrice: 20.0, royalty: 4.0 },
  'hoodie': { salePrice: 39.0, royalty: 6.0 },
  'tank-top': { salePrice: 20.0, royalty: 3.0 },
  'long-sleeve': { salePrice: 25.0, royalty: 4.0 },
  'pullover': { salePrice: 44.0, royalty: 6.0 },
  'mug': { salePrice: 14.0, royalty: 2.5 },
  'notebook': { salePrice: 14.0, royalty: 2.0 },
  'sticker': { salePrice: 2.5, royalty: 0.5 },
  'phone-case': { salePrice: 19.0, royalty: 3.0 },
  'tote-bag': { salePrice: 16.0, royalty: 3.0 },
  'poster': { salePrice: 13.0, royalty: 2.0 },
  'tapestry': { salePrice: 29.0, royalty: 4.0 },
  'throw-pillow': { salePrice: 24.0, royalty: 3.0 },
  'throw-blanket': { salePrice: 44.0, royalty: 5.0 },
  'pin': { salePrice: 9.0, royalty: 1.5 },
  'magnet': { salePrice: 7.0, royalty: 1.0 },
  'mask': { salePrice: 12.0, royalty: 2.0 },
};

// Design style to product recommendations
const DESIGN_STYLE_RECOMMENDATIONS: Record<string, TeePublicProductType[]> = {
  text: ['t-shirt', 'mug', 'sticker', 'notebook', 'tote-bag'],
  illustration: ['t-shirt', 'hoodie', 'poster', 'sticker', 'phone-case', 'throw-pillow'],
  photo: ['poster', 'tapestry', 'throw-blanket', 'phone-case'],
  pattern: ['throw-pillow', 'throw-blanket', 'tapestry', 'tote-bag', 'phone-case'],
};

export interface TeePublicCredentials {
  email: string;
  password: string;
}

export interface TeePublicDesign {
  title: string;
  description: string;
  tags: string[];
  imageUrl: string;
  primaryColor: string;
  secondaryColor?: string;
}

/**
 * TeePublic platform adapter
 * Uses Playwright for browser automation (no public API available)
 */
export class TeePublicAdapter extends BaseConnector {
  readonly name = 'teepublic';
  readonly displayName = 'TeePublic';
  readonly workflowGroup = 'pod_digital' as const;
  readonly connectorType = 'playwright' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: false,
    supportsBulkOperations: false,
    supportsWebhooks: false,
    supportsInventorySync: false,
    supportsOrderFulfillment: false,
    supportsAnalytics: false,
    maxProductsPerRequest: 1,
    rateLimits: {
      requestsPerMinute: 10, // Conservative for browser automation
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 50,
    maxDescriptionLength: 500,
    maxImages: 1, // Single design upload
    maxTags: 20,
    maxVariants: 17, // Fixed product types
    allowedImageFormats: ['png'],
    maxImageSizeMB: 25,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['title', 'tags', 'imageUrl'],
    requiredImageDimensions: { width: 2400, height: 2400 },
    requiredCategories: false,
    requiredShippingProfile: false,
  };

  private credentials: TeePublicCredentials | null = null;

  constructor(config: ConnectorConfig) {
    super(config);
    if (config.credentials) {
      this.credentials = {
        email: config.credentials.email,
        password: config.credentials.password,
      };
    }
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    if (!this.credentials?.email || !this.credentials?.password) {
      return {
        success: false,
        error: this.createError('AUTH_MISSING', 'TeePublic email and password are required'),
      };
    }

    // For Playwright-based connectors, we validate by attempting login
    // In production, this would launch a browser and verify credentials
    this.log('info', 'TeePublic authentication requires browser automation');

    // Store credentials as "token" for tracking
    this.authToken = {
      accessToken: Buffer.from(`${this.credentials.email}:authenticated`).toString('base64'),
      tokenType: 'Basic',
    };

    return {
      success: true,
      data: this.authToken,
    };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    // Session-based auth doesn't need refreshing in the traditional sense
    if (this.authToken) {
      return { success: true, data: this.authToken };
    }
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    if (!this.credentials?.email || !this.credentials?.password) {
      return false;
    }
    // In production, would perform actual browser login test
    return true;
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    this.log('info', 'Listing TeePublic designs via browser automation');

    // Browser automation would scrape the user's design page
    return {
      success: true,
      data: {
        items: [],
        total: 0,
        page: options?.page ?? 1,
        limit: options?.limit ?? 20,
        hasMore: false,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    this.log('info', `Getting TeePublic design ${id}`);

    return {
      success: false,
      error: this.createError(
        'NOT_IMPLEMENTED',
        'TeePublic product retrieval requires browser automation',
        false
      ),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_FAILED',
          `Product validation failed: ${validation.issues.map((i) => i.message).join(', ')}`,
          false
        ),
      };
    }

    this.log('info', `Creating TeePublic design: ${product.title}`);

    // In production, this would:
    // 1. Launch Playwright browser
    // 2. Navigate to TeePublic upload page
    // 3. Fill in design details
    // 4. Upload image
    // 5. Submit and get design ID

    return {
      success: true,
      data: {
        id: `teepublic_${Date.now()}`,
        externalId: `teepublic_pending_${Date.now()}`,
        externalUrl: 'https://www.teepublic.com/user/designs',
        status: 'pending' as ProductStatus,
      },
    };
  }

  async updateProduct(id: string, updates: Partial<ProductInput>): Promise<ConnectorResult<UpdateResult>> {
    this.log('info', `Updating TeePublic design ${id}`);

    return {
      success: false,
      error: this.createError(
        'NOT_IMPLEMENTED',
        'TeePublic product updates require browser automation',
        false
      ),
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    this.log('info', `Deleting TeePublic design ${id}`);

    return {
      success: false,
      error: this.createError(
        'NOT_IMPLEMENTED',
        'TeePublic product deletion requires browser automation',
        false
      ),
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const design = platformProduct as TeePublicDesign;

    return {
      id: `teepublic_${Date.now()}`,
      externalId: undefined,
      title: design.title,
      description: design.description,
      productType: 't-shirt' as ProductType,
      images: [
        {
          id: '1',
          url: design.imageUrl,
          position: 0,
          isPrimary: true,
        },
      ],
      variants: [],
      pricing: {
        price: TEEPUBLIC_ROYALTIES['t-shirt'].salePrice,
        currency: 'USD',
        taxable: true,
      },
      tags: design.tags,
      metadata: {
        primaryColor: design.primaryColor,
        secondaryColor: design.secondaryColor,
      },
      platformData: {},
      status: 'draft' as ProductStatus,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }

  denormalizeProduct(product: NormalizedProduct): TeePublicDesign {
    return {
      title: product.title,
      description: product.description,
      tags: product.tags,
      imageUrl: product.images[0]?.url ?? '',
      primaryColor: (product.metadata?.primaryColor as string) ?? '#000000',
      secondaryColor: product.metadata?.secondaryColor as string | undefined,
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    // Title validation
    if (product.title.length < 3) {
      issues.push(
        this.createValidationIssue('title', 'Title must be at least 3 characters', 'error')
      );
    }
    if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title must be ${this.platformLimits.maxTitleLength} characters or less`,
          'error',
          `Shorten to ${this.platformLimits.maxTitleLength} characters`
        )
      );
    }

    // Tags validation
    if (!product.tags || product.tags.length < 5) {
      issues.push(
        this.createValidationIssue('tags', 'At least 5 tags are required', 'error')
      );
    }
    if (product.tags && product.tags.length > this.platformLimits.maxTags) {
      issues.push(
        this.createValidationIssue(
          'tags',
          `Maximum ${this.platformLimits.maxTags} tags allowed`,
          'warning'
        )
      );
    }

    // Image validation
    if (!product.images || product.images.length === 0) {
      issues.push(
        this.createValidationIssue('images', 'At least one image is required', 'error')
      );
    }

    return {
      valid: !issues.some((i) => i.severity === 'error'),
      issues,
    };
  }

  // ============================================================================
  // TeePublic-Specific Methods
  // ============================================================================

  /**
   * Get royalty info for a product type
   */
  getRoyaltyInfo(productType: TeePublicProductType): { salePrice: number; royalty: number } {
    return TEEPUBLIC_ROYALTIES[productType];
  }

  /**
   * Calculate potential earnings for a design
   */
  calculatePotentialEarnings(
    estimatedMonthlySales: Partial<Record<TeePublicProductType, number>>
  ): { totalRevenue: number; totalRoyalty: number; breakdown: Record<string, number> } {
    let totalRevenue = 0;
    let totalRoyalty = 0;
    const breakdown: Record<string, number> = {};

    for (const [product, sales] of Object.entries(estimatedMonthlySales)) {
      const info = TEEPUBLIC_ROYALTIES[product as TeePublicProductType];
      if (info && sales) {
        const revenue = info.salePrice * sales;
        const royalty = info.royalty * sales;
        totalRevenue += revenue;
        totalRoyalty += royalty;
        breakdown[product] = royalty;
      }
    }

    return { totalRevenue, totalRoyalty, breakdown };
  }

  /**
   * Get design upload specifications
   */
  getDesignSpecs(): {
    minWidth: number;
    minHeight: number;
    maxFileSize: string;
    formats: string[];
    colorMode: string;
  } {
    return {
      minWidth: 2400,
      minHeight: 2400,
      maxFileSize: '25MB',
      formats: ['PNG'],
      colorMode: 'sRGB',
    };
  }

  /**
   * Get all available product types with royalties
   */
  getAllProductTypes(): Array<{
    type: TeePublicProductType;
    salePrice: number;
    royalty: number;
  }> {
    return Object.entries(TEEPUBLIC_ROYALTIES).map(([type, info]) => ({
      type: type as TeePublicProductType,
      salePrice: info.salePrice,
      royalty: info.royalty,
    }));
  }

  /**
   * Get recommended products based on design style
   */
  getRecommendedProducts(
    designStyle: 'text' | 'illustration' | 'photo' | 'pattern'
  ): TeePublicProductType[] {
    return DESIGN_STYLE_RECOMMENDATIONS[designStyle] || DESIGN_STYLE_RECOMMENDATIONS['illustration'];
  }

  /**
   * Validate design before upload
   */
  validateDesign(design: TeePublicDesign): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (design.title.length < 3) {
      errors.push('Title must be at least 3 characters');
    }
    if (design.title.length > 50) {
      errors.push('Title must be 50 characters or less');
    }
    if (design.tags.length < 5) {
      errors.push('At least 5 tags required');
    }
    if (design.tags.length > 20) {
      errors.push('Maximum 20 tags allowed');
    }
    if (!design.imageUrl) {
      errors.push('Image URL is required');
    }

    return { valid: errors.length === 0, errors };
  }
}

export default TeePublicAdapter;
