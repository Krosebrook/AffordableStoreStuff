/**
 * Shopify Adapter
 * Major marketplace connector for Shopify Admin API
 *
 * API Docs: https://shopify.dev/docs/api/admin-rest
 * Auth: OAuth 2.0 or Private App API Key
 * Rate Limit: 2 requests/second (bucket: 40)
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PaginatedOrders,
  Order,
  TrackingInfo,
  Fulfillment,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  Collection,
  ProductType,
  OrderStatus,
  DateRange,
  PlatformAnalytics,
  OAuthConfig,
} from '../core/types';
import { mapPlatformError } from '../utils/error-mapper';
import { CredentialManager } from '../core/credential-manager';

// Shopify-specific types
interface ShopifyProduct {
  id: number;
  title: string;
  body_html: string;
  vendor: string;
  product_type: string;
  created_at: string;
  handle: string;
  updated_at: string;
  published_at: string | null;
  template_suffix: string | null;
  published_scope: string;
  tags: string;
  status: 'active' | 'archived' | 'draft';
  admin_graphql_api_id: string;
  variants: ShopifyVariant[];
  options: ShopifyOption[];
  images: ShopifyImage[];
  image: ShopifyImage | null;
}

interface ShopifyVariant {
  id: number;
  product_id: number;
  title: string;
  price: string;
  sku: string;
  position: number;
  inventory_policy: string;
  compare_at_price: string | null;
  fulfillment_service: string;
  inventory_management: string | null;
  option1: string | null;
  option2: string | null;
  option3: string | null;
  created_at: string;
  updated_at: string;
  taxable: boolean;
  barcode: string | null;
  grams: number;
  image_id: number | null;
  weight: number;
  weight_unit: string;
  inventory_item_id: number;
  inventory_quantity: number;
  old_inventory_quantity: number;
  requires_shipping: boolean;
}

interface ShopifyOption {
  id: number;
  product_id: number;
  name: string;
  position: number;
  values: string[];
}

interface ShopifyImage {
  id: number;
  product_id: number;
  position: number;
  created_at: string;
  updated_at: string;
  alt: string | null;
  width: number;
  height: number;
  src: string;
  variant_ids: number[];
}

interface ShopifyOrder {
  id: number;
  admin_graphql_api_id: string;
  app_id: number;
  browser_ip: string;
  buyer_accepts_marketing: boolean;
  cancel_reason: string | null;
  cancelled_at: string | null;
  cart_token: string;
  checkout_id: number;
  checkout_token: string;
  client_details: Record<string, unknown>;
  closed_at: string | null;
  confirmed: boolean;
  contact_email: string;
  created_at: string;
  currency: string;
  current_subtotal_price: string;
  current_total_discounts: string;
  current_total_price: string;
  current_total_tax: string;
  customer: ShopifyCustomer;
  discount_codes: ShopifyDiscountCode[];
  email: string;
  financial_status: string;
  fulfillment_status: string | null;
  fulfillments: ShopifyFulfillment[];
  line_items: ShopifyLineItem[];
  name: string;
  note: string | null;
  number: number;
  order_number: number;
  payment_gateway_names: string[];
  phone: string | null;
  presentment_currency: string;
  processed_at: string;
  processing_method: string;
  shipping_address: ShopifyAddress;
  billing_address: ShopifyAddress;
  shipping_lines: ShopifyShippingLine[];
  subtotal_price: string;
  tags: string;
  tax_lines: ShopifyTaxLine[];
  taxes_included: boolean;
  total_discounts: string;
  total_line_items_price: string;
  total_price: string;
  total_tax: string;
  total_weight: number;
  updated_at: string;
}

interface ShopifyCustomer {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
}

interface ShopifyDiscountCode {
  code: string;
  amount: string;
  type: string;
}

interface ShopifyFulfillment {
  id: number;
  order_id: number;
  status: string;
  created_at: string;
  service: string;
  updated_at: string;
  tracking_company: string;
  shipment_status: string | null;
  tracking_number: string;
  tracking_numbers: string[];
  tracking_url: string;
  tracking_urls: string[];
  line_items: ShopifyLineItem[];
}

interface ShopifyLineItem {
  id: number;
  variant_id: number;
  title: string;
  quantity: number;
  price: string;
  sku: string;
  variant_title: string;
  product_id: number;
  fulfillment_status: string | null;
}

interface ShopifyAddress {
  first_name: string;
  last_name: string;
  address1: string;
  address2: string | null;
  city: string;
  province: string;
  country: string;
  zip: string;
  phone: string | null;
  name: string;
  province_code: string;
  country_code: string;
}

interface ShopifyShippingLine {
  id: number;
  title: string;
  price: string;
  code: string;
  source: string;
}

interface ShopifyTaxLine {
  title: string;
  price: string;
  rate: number;
}

interface ShopifyCollection {
  id: number;
  handle: string;
  title: string;
  updated_at: string;
  body_html: string;
  published_at: string | null;
  sort_order: string;
  template_suffix: string | null;
  products_count: number;
  admin_graphql_api_id: string;
}

/**
 * Shopify platform adapter
 */
export class ShopifyAdapter extends BaseConnector {
  readonly name = 'shopify';
  readonly displayName = 'Shopify';
  readonly workflowGroup = 'marketplace' as const;
  readonly connectorType = 'oauth2' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: true,
    supportsBulkOperations: true,
    supportsWebhooks: true,
    supportsInventorySync: true,
    supportsOrderFulfillment: true,
    supportsAnalytics: true,
    maxProductsPerRequest: 250,
    rateLimits: {
      requestsPerSecond: 2,
      bucketSize: 40,
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 255,
    maxDescriptionLength: 65535,
    maxImages: 250,
    maxTags: 250,
    maxVariants: 100,
    allowedImageFormats: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    maxImageSizeMB: 20,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['title'],
    requiredCategories: false,
    requiredShippingProfile: false,
  };

  private shopDomain: string = '';
  private apiVersion = '2024-01';
  private credentialManager: CredentialManager | null = null;

  constructor(config: ConnectorConfig & { shopDomain?: string }) {
    super(config);
    this.shopDomain = config.shopDomain || config.credentials?.shopDomain || '';
  }

  setCredentialManager(manager: CredentialManager): void {
    this.credentialManager = manager;
  }

  get oauthConfig(): OAuthConfig {
    return {
      clientId: process.env.SHOPIFY_CLIENT_ID || '',
      clientSecret: process.env.SHOPIFY_CLIENT_SECRET || '',
      redirectUri: process.env.SHOPIFY_REDIRECT_URI || '',
      scopes: [
        'read_products',
        'write_products',
        'read_orders',
        'write_orders',
        'read_inventory',
        'write_inventory',
        'read_fulfillments',
        'write_fulfillments',
      ],
      authUrl: `https://${this.shopDomain}/admin/oauth/authorize`,
      tokenUrl: `https://${this.shopDomain}/admin/oauth/access_token`,
    };
  }

  private get baseApiUrl(): string {
    return `https://${this.shopDomain}/admin/api/${this.apiVersion}`;
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    // Check for API key auth first
    const apiKey = this.config.credentials?.apiKey;
    const apiPassword = this.config.credentials?.apiPassword;

    if (apiKey && apiPassword) {
      this.authToken = {
        accessToken: Buffer.from(`${apiKey}:${apiPassword}`).toString('base64'),
        tokenType: 'Basic',
      };

      const shopResult = await this.getShop();
      if (!shopResult.success) {
        this.authToken = null;
        return { success: false, error: shopResult.error };
      }

      return { success: true, data: this.authToken };
    }

    // OAuth flow
    if (!this.credentialManager) {
      return {
        success: false,
        error: this.createError('CONFIG_ERROR', 'Credential manager not set for OAuth'),
      };
    }

    const result = await this.credentialManager.getOAuthTokens('shopify');
    if (!result.success) {
      return result;
    }

    this.authToken = result.data!;
    return { success: true, data: this.authToken };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    // Shopify access tokens don't expire
    if (this.authToken) {
      return { success: true, data: this.authToken };
    }
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    const result = await this.getShop();
    return result.success;
  }

  private async getShop(): Promise<ConnectorResult<{ shop: { name: string } }>> {
    return this.request<{ shop: { name: string } }>({
      method: 'GET',
      path: '/shop.json',
    });
  }

  // Override request to use correct base URL
  protected override async executeRequest<T>(
    options: import('../core/base-connector').RequestOptions
  ): Promise<ConnectorResult<T>> {
    const url = `${this.baseApiUrl}${options.path}`;
    const headers = this.buildHeaders(options.headers);

    const fetchOptions: RequestInit = {
      method: options.method,
      headers,
    };

    if (options.body) {
      fetchOptions.body = JSON.stringify(options.body);
    }

    try {
      const response = await fetch(url, fetchOptions);
      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: this.mapPlatformError(response.status, data),
          rateLimitInfo: this.extractRateLimitInfo(response),
        };
      }

      return {
        success: true,
        data: data as T,
        rateLimitInfo: this.extractRateLimitInfo(response),
      };
    } catch (error) {
      return {
        success: false,
        error: this.mapError(error),
      };
    }
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    const limit = options?.limit || 50;

    const result = await this.request<{ products: ShopifyProduct[] }>({
      method: 'GET',
      path: '/products.json',
      query: {
        limit,
        ...(options?.cursor && { page_info: options.cursor }),
      },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedProducts>;
    }

    return {
      success: true,
      data: {
        items: result.data!.products.map((p) => this.normalizeProduct(p)),
        total: result.data!.products.length, // Shopify doesn't return total in REST
        page: options?.page || 1,
        limit,
        hasMore: result.data!.products.length === limit,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    const result = await this.request<{ product: ShopifyProduct }>({
      method: 'GET',
      path: `/products/${id}.json`,
    });

    if (!result.success) {
      return result as ConnectorResult<NormalizedProduct>;
    }

    return {
      success: true,
      data: this.normalizeProduct(result.data!.product),
    };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_ERROR',
          validation.issues.map((i) => i.message).join('; ')
        ),
      };
    }

    const shopifyProduct = this.denormalizeProduct({
      ...product,
      id: '',
      status: 'draft',
      createdAt: new Date(),
      updatedAt: new Date(),
      platformData: {},
      metadata: product.metadata || {},
      tags: product.tags || [],
      images: product.images.map((img, idx) => ({ ...img, id: `img-${idx}` })),
      variants: product.variants?.map((v, idx) => ({ ...v, id: `var-${idx}` })) || [],
      pricing: { ...product.pricing, currency: product.pricing.currency || 'USD' },
    } as NormalizedProduct);

    const result = await this.request<{ product: ShopifyProduct }>({
      method: 'POST',
      path: '/products.json',
      body: { product: shopifyProduct },
    });

    if (!result.success) {
      return result as ConnectorResult<CreateResult>;
    }

    return {
      success: true,
      data: {
        id: String(result.data!.product.id),
        externalId: String(result.data!.product.id),
        externalUrl: `https://${this.shopDomain}/products/${result.data!.product.handle}`,
        status: result.data!.product.status,
      },
    };
  }

  async updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>> {
    const updatePayload: Record<string, unknown> = { id: parseInt(id, 10) };
    const updatedFields: string[] = [];

    if (updates.title) {
      updatePayload.title = updates.title;
      updatedFields.push('title');
    }
    if (updates.description) {
      updatePayload.body_html = updates.description;
      updatedFields.push('body_html');
    }
    if (updates.tags) {
      updatePayload.tags = updates.tags.join(', ');
      updatedFields.push('tags');
    }

    const result = await this.request<{ product: ShopifyProduct }>({
      method: 'PUT',
      path: `/products/${id}.json`,
      body: { product: updatePayload },
    });

    if (!result.success) {
      return result as ConnectorResult<UpdateResult>;
    }

    return {
      success: true,
      data: { id, externalId: id, updatedFields },
    };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    const result = await this.request<void>({
      method: 'DELETE',
      path: `/products/${id}.json`,
    });

    return {
      success: result.success,
      data: { id, deleted: result.success },
      error: result.error,
    };
  }

  // ============================================================================
  // Collections
  // ============================================================================

  async getCollections(): Promise<ConnectorResult<Collection[]>> {
    const result = await this.request<{ custom_collections: ShopifyCollection[] }>({
      method: 'GET',
      path: '/custom_collections.json',
    });

    if (!result.success) {
      return result as ConnectorResult<Collection[]>;
    }

    return {
      success: true,
      data: result.data!.custom_collections.map((c) => ({
        id: String(c.id),
        title: c.title,
        handle: c.handle,
        productsCount: c.products_count,
      })),
    };
  }

  async addToCollection(
    productId: string,
    collectionId: string
  ): Promise<ConnectorResult<void>> {
    const result = await this.request<void>({
      method: 'POST',
      path: '/collects.json',
      body: {
        collect: {
          product_id: parseInt(productId, 10),
          collection_id: parseInt(collectionId, 10),
        },
      },
    });

    return result;
  }

  // ============================================================================
  // Orders
  // ============================================================================

  async listOrders(options?: ListOptions): Promise<ConnectorResult<PaginatedOrders>> {
    const limit = options?.limit || 50;

    const result = await this.request<{ orders: ShopifyOrder[] }>({
      method: 'GET',
      path: '/orders.json',
      query: { limit, status: 'any' },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedOrders>;
    }

    return {
      success: true,
      data: {
        items: result.data!.orders.map((o) => this.normalizeOrder(o)),
        total: result.data!.orders.length,
        page: options?.page || 1,
        limit,
        hasMore: result.data!.orders.length === limit,
      },
    };
  }

  async getOrder(orderId: string): Promise<ConnectorResult<Order>> {
    const result = await this.request<{ order: ShopifyOrder }>({
      method: 'GET',
      path: `/orders/${orderId}.json`,
    });

    if (!result.success) {
      return result as ConnectorResult<Order>;
    }

    return {
      success: true,
      data: this.normalizeOrder(result.data!.order),
    };
  }

  async fulfillOrder(
    orderId: string,
    tracking: TrackingInfo
  ): Promise<ConnectorResult<Fulfillment>> {
    const result = await this.request<{ fulfillment: ShopifyFulfillment }>({
      method: 'POST',
      path: `/orders/${orderId}/fulfillments.json`,
      body: {
        fulfillment: {
          tracking_number: tracking.trackingNumber,
          tracking_company: tracking.carrier,
          tracking_url: tracking.trackingUrl,
          notify_customer: true,
        },
      },
    });

    if (!result.success) {
      return result as ConnectorResult<Fulfillment>;
    }

    const f = result.data!.fulfillment;
    return {
      success: true,
      data: {
        id: String(f.id),
        orderId: String(f.order_id),
        tracking: {
          carrier: f.tracking_company,
          trackingNumber: f.tracking_number,
          trackingUrl: f.tracking_url,
        },
        items: f.line_items.map((li) => ({
          id: String(li.id),
          productId: String(li.product_id),
          variantId: String(li.variant_id),
          title: li.title,
          quantity: li.quantity,
          price: parseFloat(li.price),
          sku: li.sku,
        })),
        fulfilledAt: new Date(f.created_at),
      },
    };
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    const ordersResult = await this.request<{ orders: ShopifyOrder[] }>({
      method: 'GET',
      path: '/orders.json',
      query: {
        created_at_min: dateRange.start.toISOString(),
        created_at_max: dateRange.end.toISOString(),
        status: 'any',
        limit: 250,
      },
    });

    if (!ordersResult.success) {
      return ordersResult as ConnectorResult<PlatformAnalytics>;
    }

    const orders = ordersResult.data!.orders;
    const totalRevenue = orders.reduce((sum, o) => sum + parseFloat(o.total_price), 0);

    const byDay = new Map<string, number>();
    orders.forEach((o) => {
      const date = new Date(o.created_at).toISOString().split('T')[0];
      byDay.set(date, (byDay.get(date) || 0) + parseFloat(o.total_price));
    });

    const byProduct = new Map<string, { title: string; sales: number; revenue: number }>();
    orders.forEach((o) => {
      o.line_items.forEach((li) => {
        const key = String(li.product_id);
        const existing = byProduct.get(key) || { title: li.title, sales: 0, revenue: 0 };
        existing.sales += li.quantity;
        existing.revenue += parseFloat(li.price) * li.quantity;
        byProduct.set(key, existing);
      });
    });

    return {
      success: true,
      data: {
        platform: 'shopify',
        dateRange,
        revenue: {
          total: totalRevenue,
          currency: orders[0]?.currency || 'USD',
          byDay: Array.from(byDay.entries()).map(([date, amount]) => ({ date, amount })),
          byProduct: Array.from(byProduct.entries()).map(([productId, data]) => ({
            productId,
            title: data.title,
            amount: data.revenue,
          })),
        },
        orderCount: orders.length,
        productCount: byProduct.size,
        topProducts: Array.from(byProduct.entries())
          .map(([id, data]) => ({ id, ...data }))
          .sort((a, b) => b.revenue - a.revenue)
          .slice(0, 10),
      },
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const p = platformProduct as ShopifyProduct;

    return {
      id: String(p.id),
      externalId: String(p.id),
      title: p.title,
      description: p.body_html || '',
      productType: (p.product_type?.toLowerCase() as ProductType) || 'other',
      images: p.images.map((img) => ({
        id: String(img.id),
        url: img.src,
        alt: img.alt || undefined,
        position: img.position,
        width: img.width,
        height: img.height,
        isPrimary: img.position === 1,
      })),
      variants: p.variants.map((v) => ({
        id: String(v.id),
        sku: v.sku,
        title: v.title,
        price: parseFloat(v.price),
        compareAtPrice: v.compare_at_price ? parseFloat(v.compare_at_price) : undefined,
        inventoryQuantity: v.inventory_quantity,
        options: {
          option1: v.option1 || undefined,
          option2: v.option2 || undefined,
          option3: v.option3 || undefined,
        },
        weight: v.weight,
        weightUnit: v.weight_unit as 'g' | 'kg' | 'oz' | 'lb',
      })),
      pricing: {
        price: parseFloat(p.variants[0]?.price || '0'),
        compareAtPrice: p.variants[0]?.compare_at_price
          ? parseFloat(p.variants[0].compare_at_price)
          : undefined,
        currency: 'USD',
        taxable: p.variants[0]?.taxable ?? true,
      },
      tags: p.tags ? p.tags.split(', ') : [],
      metadata: {
        vendor: p.vendor,
        handle: p.handle,
        template_suffix: p.template_suffix,
      },
      platformData: {
        admin_graphql_api_id: p.admin_graphql_api_id,
        published_scope: p.published_scope,
      },
      status: p.status,
      createdAt: new Date(p.created_at),
      updatedAt: new Date(p.updated_at),
    };
  }

  private normalizeOrder(order: ShopifyOrder): Order {
    return {
      id: String(order.id),
      externalId: String(order.order_number),
      status: this.mapShopifyFulfillmentStatus(order.fulfillment_status),
      items: order.line_items.map((li) => ({
        id: String(li.id),
        productId: String(li.product_id),
        variantId: String(li.variant_id),
        title: li.title,
        quantity: li.quantity,
        price: parseFloat(li.price),
        sku: li.sku,
      })),
      shippingAddress: {
        name: order.shipping_address?.name || '',
        address1: order.shipping_address?.address1 || '',
        address2: order.shipping_address?.address2 || undefined,
        city: order.shipping_address?.city || '',
        state: order.shipping_address?.province || undefined,
        postalCode: order.shipping_address?.zip || '',
        country: order.shipping_address?.country || '',
        phone: order.shipping_address?.phone || undefined,
      },
      subtotal: parseFloat(order.subtotal_price),
      shippingCost: order.shipping_lines.reduce((sum, sl) => sum + parseFloat(sl.price), 0),
      tax: parseFloat(order.total_tax),
      total: parseFloat(order.total_price),
      currency: order.currency,
      createdAt: new Date(order.created_at),
      updatedAt: new Date(order.updated_at),
    };
  }

  denormalizeProduct(product: NormalizedProduct): unknown {
    return {
      title: product.title,
      body_html: product.description,
      vendor: product.metadata?.vendor,
      product_type: product.productType,
      tags: product.tags?.join(', '),
      status: product.status,
      variants: product.variants.map((v) => ({
        price: String(v.price),
        sku: v.sku,
        compare_at_price: v.compareAtPrice ? String(v.compareAtPrice) : null,
        inventory_quantity: v.inventoryQuantity,
        option1: v.options?.option1,
        option2: v.options?.option2,
        option3: v.options?.option3,
        weight: v.weight,
        weight_unit: v.weightUnit,
      })),
      images: product.images.map((img) => ({
        src: img.url,
        alt: img.alt,
        position: img.position,
      })),
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    if (!product.title) {
      issues.push(this.createValidationIssue('title', 'Title is required', 'error'));
    } else if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Title exceeds ${this.platformLimits.maxTitleLength} characters`,
          'error'
        )
      );
    }

    if (product.variants && product.variants.length > this.platformLimits.maxVariants) {
      issues.push(
        this.createValidationIssue(
          'variants',
          `Too many variants (max ${this.platformLimits.maxVariants})`,
          'error'
        )
      );
    }

    if (product.images && product.images.length > this.platformLimits.maxImages) {
      issues.push(
        this.createValidationIssue(
          'images',
          `Too many images (max ${this.platformLimits.maxImages})`,
          'warning'
        )
      );
    }

    return {
      valid: issues.filter((i) => i.severity === 'error').length === 0,
      issues,
    };
  }

  private mapShopifyFulfillmentStatus(status: string | null): OrderStatus {
    switch (status) {
      case 'fulfilled':
        return 'shipped';
      case 'partial':
        return 'processing';
      case null:
        return 'pending';
      default:
        return 'pending';
    }
  }

  protected override mapPlatformError(status: number, data: unknown) {
    return mapPlatformError('shopify', status, data);
  }
}

export default ShopifyAdapter;
