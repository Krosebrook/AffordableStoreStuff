/**
 * Rate Limit Manager
 * Per-platform request throttling with token bucket algorithm
 */

import { RateLimitConfig, RateLimitInfo } from './types';

interface TokenBucket {
  tokens: number;
  lastRefill: number;
  maxTokens: number;
  refillRate: number; // tokens per millisecond
}

interface QueuedRequest {
  id: string;
  platform: string;
  resolve: (canProceed: boolean) => void;
  priority: number;
  addedAt: number;
}

/**
 * Manages rate limiting for all platform connectors
 * Uses token bucket algorithm with request queuing
 */
export class RateLimitManager {
  private buckets: Map<string, TokenBucket> = new Map();
  private requestQueues: Map<string, QueuedRequest[]> = new Map();
  private platformConfigs: Map<string, RateLimitConfig> = new Map();
  private rateLimitInfo: Map<string, RateLimitInfo> = new Map();
  private isProcessing: Map<string, boolean> = new Map();

  // Default rate limits if platform doesn't specify
  private static DEFAULT_LIMITS: RateLimitConfig = {
    requestsPerMinute: 60,
  };

  /**
   * Register a platform with its rate limit configuration
   */
  registerPlatform(platform: string, config: RateLimitConfig): void {
    this.platformConfigs.set(platform, config);
    this.initializeBucket(platform, config);
    this.requestQueues.set(platform, []);
    this.isProcessing.set(platform, false);
  }

  /**
   * Initialize token bucket for a platform
   */
  private initializeBucket(platform: string, config: RateLimitConfig): void {
    const { maxTokens, refillRate } = this.calculateBucketParams(config);

    this.buckets.set(platform, {
      tokens: maxTokens,
      lastRefill: Date.now(),
      maxTokens,
      refillRate,
    });
  }

  /**
   * Calculate bucket parameters from rate limit config
   */
  private calculateBucketParams(config: RateLimitConfig): {
    maxTokens: number;
    refillRate: number;
  } {
    // Determine the most restrictive rate limit
    let requestsPerMs = Infinity;

    if (config.requestsPerSecond) {
      requestsPerMs = Math.min(requestsPerMs, config.requestsPerSecond / 1000);
    }
    if (config.requestsPerMinute) {
      requestsPerMs = Math.min(requestsPerMs, config.requestsPerMinute / 60000);
    }
    if (config.requestsPerHour) {
      requestsPerMs = Math.min(requestsPerMs, config.requestsPerHour / 3600000);
    }
    if (config.requestsPer10Seconds) {
      requestsPerMs = Math.min(requestsPerMs, config.requestsPer10Seconds / 10000);
    }

    // Default if no limits specified
    if (requestsPerMs === Infinity) {
      requestsPerMs = 1; // 1 request per ms = 1000/sec
    }

    // Bucket size is either specified or defaults to 1 second worth of requests
    const maxTokens = config.bucketSize || Math.max(1, Math.ceil(requestsPerMs * 1000));

    return {
      maxTokens,
      refillRate: requestsPerMs,
    };
  }

  /**
   * Acquire permission to make a request
   * Returns a promise that resolves when the request can proceed
   */
  async acquire(
    platform: string,
    priority: number = 0
  ): Promise<boolean> {
    // Ensure platform is registered
    if (!this.buckets.has(platform)) {
      this.registerPlatform(platform, RateLimitManager.DEFAULT_LIMITS);
    }

    // Try to get a token immediately
    if (this.tryConsume(platform)) {
      return true;
    }

    // Queue the request
    return new Promise((resolve) => {
      const request: QueuedRequest = {
        id: this.generateId(),
        platform,
        resolve,
        priority,
        addedAt: Date.now(),
      };

      const queue = this.requestQueues.get(platform)!;
      queue.push(request);

      // Sort by priority (higher first) then by time (older first)
      queue.sort((a, b) => {
        if (a.priority !== b.priority) return b.priority - a.priority;
        return a.addedAt - b.addedAt;
      });

      // Start processing queue if not already
      this.processQueue(platform);
    });
  }

  /**
   * Try to consume a token from the bucket
   */
  private tryConsume(platform: string): boolean {
    const bucket = this.buckets.get(platform);
    if (!bucket) return false;

    // Refill tokens based on elapsed time
    this.refillBucket(bucket);

    // Check if we have tokens available
    if (bucket.tokens >= 1) {
      bucket.tokens -= 1;
      return true;
    }

    return false;
  }

  /**
   * Refill bucket tokens based on elapsed time
   */
  private refillBucket(bucket: TokenBucket): void {
    const now = Date.now();
    const elapsed = now - bucket.lastRefill;
    const tokensToAdd = elapsed * bucket.refillRate;

    bucket.tokens = Math.min(bucket.maxTokens, bucket.tokens + tokensToAdd);
    bucket.lastRefill = now;
  }

  /**
   * Process queued requests for a platform
   */
  private async processQueue(platform: string): Promise<void> {
    if (this.isProcessing.get(platform)) return;
    this.isProcessing.set(platform, true);

    const queue = this.requestQueues.get(platform)!;

    while (queue.length > 0) {
      // Wait for a token to become available
      const waitTime = this.getWaitTime(platform);
      if (waitTime > 0) {
        await this.sleep(waitTime);
      }

      // Try to consume a token
      if (this.tryConsume(platform)) {
        const request = queue.shift();
        if (request) {
          request.resolve(true);
        }
      }
    }

    this.isProcessing.set(platform, false);
  }

  /**
   * Calculate wait time until next token is available
   */
  private getWaitTime(platform: string): number {
    const bucket = this.buckets.get(platform);
    if (!bucket) return 0;

    // Refill first to get accurate count
    this.refillBucket(bucket);

    if (bucket.tokens >= 1) return 0;

    // Calculate time until we have 1 token
    const tokensNeeded = 1 - bucket.tokens;
    return Math.ceil(tokensNeeded / bucket.refillRate);
  }

  /**
   * Update rate limit info from API response headers
   */
  updateFromResponse(platform: string, info: RateLimitInfo): void {
    this.rateLimitInfo.set(platform, info);

    // If we're being rate limited, pause the bucket
    if (info.remaining === 0 && info.retryAfter) {
      const bucket = this.buckets.get(platform);
      if (bucket) {
        bucket.tokens = 0;
        // Don't refill until retry time has passed
        bucket.lastRefill = Date.now() + (info.retryAfter * 1000);
      }
    }
  }

  /**
   * Handle 429 Too Many Requests response
   */
  handleRateLimited(platform: string, retryAfterSeconds: number): void {
    const bucket = this.buckets.get(platform);
    if (!bucket) return;

    // Drain bucket completely
    bucket.tokens = 0;

    // Set lastRefill to future so we don't refill until retry time passes
    bucket.lastRefill = Date.now() + (retryAfterSeconds * 1000);

    // Update rate limit info
    this.rateLimitInfo.set(platform, {
      limit: bucket.maxTokens,
      remaining: 0,
      resetAt: new Date(Date.now() + retryAfterSeconds * 1000),
      retryAfter: retryAfterSeconds,
    });
  }

  /**
   * Get current rate limit status for a platform
   */
  getStatus(platform: string): RateLimitInfo | null {
    const info = this.rateLimitInfo.get(platform);
    if (info) return info;

    const bucket = this.buckets.get(platform);
    if (!bucket) return null;

    this.refillBucket(bucket);

    return {
      limit: bucket.maxTokens,
      remaining: Math.floor(bucket.tokens),
      resetAt: new Date(Date.now() + (bucket.maxTokens - bucket.tokens) / bucket.refillRate),
    };
  }

  /**
   * Get queue length for a platform
   */
  getQueueLength(platform: string): number {
    return this.requestQueues.get(platform)?.length || 0;
  }

  /**
   * Check if a platform is currently rate limited
   */
  isRateLimited(platform: string): boolean {
    const bucket = this.buckets.get(platform);
    if (!bucket) return false;

    this.refillBucket(bucket);
    return bucket.tokens < 1;
  }

  /**
   * Get estimated wait time for next request
   */
  getEstimatedWaitTime(platform: string): number {
    const waitTime = this.getWaitTime(platform);
    const queueLength = this.getQueueLength(platform);

    // Add time for queued requests ahead
    const bucket = this.buckets.get(platform);
    if (!bucket) return waitTime;

    const timePerRequest = 1 / bucket.refillRate;
    return waitTime + (queueLength * timePerRequest);
  }

  /**
   * Clear rate limit state for a platform (useful for testing)
   */
  reset(platform: string): void {
    const config = this.platformConfigs.get(platform);
    if (config) {
      this.initializeBucket(platform, config);
    }
    this.requestQueues.set(platform, []);
    this.rateLimitInfo.delete(platform);
  }

  /**
   * Reset all platforms
   */
  resetAll(): void {
    for (const platform of this.platformConfigs.keys()) {
      this.reset(platform);
    }
  }

  // ============================================================================
  // Helpers
  // ============================================================================

  private generateId(): string {
    return Math.random().toString(36).substring(2, 15);
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

// Singleton instance
let instance: RateLimitManager | null = null;

/**
 * Get the global RateLimitManager instance
 */
export function getRateLimitManager(): RateLimitManager {
  if (!instance) {
    instance = new RateLimitManager();
  }
  return instance;
}

/**
 * Create a new RateLimitManager instance (for testing)
 */
export function createRateLimitManager(): RateLimitManager {
  return new RateLimitManager();
}

export default RateLimitManager;
