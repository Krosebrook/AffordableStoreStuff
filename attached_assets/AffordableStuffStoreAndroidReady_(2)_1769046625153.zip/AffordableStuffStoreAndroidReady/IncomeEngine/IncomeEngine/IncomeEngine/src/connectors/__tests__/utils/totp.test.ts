/**
 * ============================================================================
 * TOTP UTILITY TEST SUITE
 * ============================================================================
 *
 * Tests for the Time-based One-Time Password (TOTP) utility.
 * Covers base32 encoding/decoding, TOTP generation, verification, and helpers.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  generateTOTP,
  verifyTOTP,
  generateSecret,
  generateProvisioningURI,
  getCode,
  getTimeRemaining,
  waitForNextCode,
  base32Decode,
  base32Encode,
  TOTPConfig,
} from '../../utils/totp';

describe('TOTP Utility', () => {
  // ===========================================================================
  // Base32 Encoding Tests
  // ===========================================================================

  describe('base32Encode', () => {
    it('should encode empty buffer', () => {
      const result = base32Encode(Buffer.from([]));
      expect(result).toBe('');
    });

    it('should encode single byte', () => {
      const result = base32Encode(Buffer.from([0x48])); // 'H'
      expect(result).toMatch(/^[A-Z2-7]+=*$/);
    });

    it('should encode "Hello!" to base32', () => {
      const result = base32Encode(Buffer.from('Hello!'));
      expect(result).toBe('JBSWY3DPEE======');
    });

    it('should encode binary data correctly', () => {
      const data = Buffer.from([0xde, 0xad, 0xbe, 0xef]);
      const encoded = base32Encode(data);
      expect(encoded).toMatch(/^[A-Z2-7]+=*$/);
    });

    it('should add padding to make length multiple of 8', () => {
      const result = base32Encode(Buffer.from([0x00]));
      expect(result.length % 8).toBe(0);
    });
  });

  // ===========================================================================
  // Base32 Decoding Tests
  // ===========================================================================

  describe('base32Decode', () => {
    it('should throw error for empty string', () => {
      expect(() => base32Decode('')).toThrow('Empty Base32 string');
    });

    it('should throw error for invalid characters', () => {
      expect(() => base32Decode('ABC123!@#')).toThrow('Invalid Base32 character');
    });

    it('should decode valid base32 string', () => {
      const decoded = base32Decode('JBSWY3DPEHPK3PXP');
      expect(decoded).toBeInstanceOf(Buffer);
      expect(decoded.length).toBeGreaterThan(0);
    });

    it('should handle lowercase input', () => {
      const decoded = base32Decode('jbswy3dpehpk3pxp');
      expect(decoded).toBeInstanceOf(Buffer);
    });

    it('should handle padding characters', () => {
      const withPadding = base32Decode('JBSWY3DPEE======');
      const withoutPadding = base32Decode('JBSWY3DPEE');
      expect(withPadding).toEqual(withoutPadding);
    });

    it('should handle spaces in input', () => {
      const decoded = base32Decode('JBSW Y3DP EHPK 3PXP');
      expect(decoded).toBeInstanceOf(Buffer);
    });

    it('should round-trip encode/decode', () => {
      const original = 'Test string for round trip';
      const encoded = base32Encode(Buffer.from(original));
      const decoded = base32Decode(encoded);
      expect(decoded.toString()).toBe(original);
    });
  });

  // ===========================================================================
  // generateTOTP Tests
  // ===========================================================================

  describe('generateTOTP', () => {
    const testSecret = 'JBSWY3DPEHPK3PXP'; // Base32 encoded "Hello!World"

    it('should generate 6-digit code by default', () => {
      const result = generateTOTP({ secret: testSecret });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should generate code with specified digit count', () => {
      const result = generateTOTP({ secret: testSecret, digits: 8 });
      expect(result.code).toMatch(/^\d{8}$/);
    });

    it('should return remaining seconds', () => {
      const result = generateTOTP({ secret: testSecret, period: 30 });
      expect(result.remainingSeconds).toBeGreaterThan(0);
      expect(result.remainingSeconds).toBeLessThanOrEqual(30);
    });

    it('should return counter value', () => {
      const result = generateTOTP({ secret: testSecret });
      expect(result.counter).toBeGreaterThan(0);
    });

    it('should use custom period', () => {
      const result60 = generateTOTP({ secret: testSecret, period: 60 });
      expect(result60.remainingSeconds).toBeLessThanOrEqual(60);
    });

    it('should generate different codes for different secrets', () => {
      const code1 = generateTOTP({ secret: 'JBSWY3DPEHPK3PXP' }).code;
      const code2 = generateTOTP({ secret: 'ORSXG5BRGIZTINJW' }).code;
      // Note: Codes could theoretically match by chance, but very unlikely
      expect(code1).not.toBe(code2);
    });

    it('should support SHA256 algorithm', () => {
      const result = generateTOTP({
        secret: testSecret,
        algorithm: 'sha256',
      });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should support SHA512 algorithm', () => {
      const result = generateTOTP({
        secret: testSecret,
        algorithm: 'sha512',
      });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should pad codes with leading zeros', () => {
      // Test that codes shorter than digits are zero-padded
      const result = generateTOTP({ secret: testSecret, digits: 6 });
      expect(result.code.length).toBe(6);
    });

    it('should throw for invalid secret', () => {
      expect(() => generateTOTP({ secret: '' })).toThrow();
    });
  });

  // ===========================================================================
  // verifyTOTP Tests
  // ===========================================================================

  describe('verifyTOTP', () => {
    const testSecret = 'JBSWY3DPEHPK3PXP';

    it('should verify current code', () => {
      const { code } = generateTOTP({ secret: testSecret });
      const isValid = verifyTOTP(code, { secret: testSecret });
      expect(isValid).toBe(true);
    });

    it('should reject invalid code', () => {
      const isValid = verifyTOTP('000000', { secret: testSecret });
      // Could be valid by chance, but very unlikely
      const currentCode = generateTOTP({ secret: testSecret }).code;
      if (currentCode !== '000000') {
        expect(isValid).toBe(false);
      }
    });

    it('should accept code within time window', () => {
      const { code } = generateTOTP({ secret: testSecret });
      const isValid = verifyTOTP(code, { secret: testSecret, window: 1 });
      expect(isValid).toBe(true);
    });

    it('should use default window of 1', () => {
      const { code } = generateTOTP({ secret: testSecret });
      const isValid = verifyTOTP(code, { secret: testSecret });
      expect(isValid).toBe(true);
    });

    it('should verify with matching algorithm', () => {
      const config: TOTPConfig = { secret: testSecret, algorithm: 'sha256' };
      const { code } = generateTOTP(config);
      const isValid = verifyTOTP(code, config);
      expect(isValid).toBe(true);
    });

    it('should fail with mismatched algorithm', () => {
      const code = generateTOTP({ secret: testSecret, algorithm: 'sha1' }).code;
      const isValid = verifyTOTP(code, { secret: testSecret, algorithm: 'sha512' });
      // Codes from different algorithms should generally not match
      expect(typeof isValid).toBe('boolean');
    });

    it('should handle wrong length codes', () => {
      const isValid = verifyTOTP('12345', { secret: testSecret }); // 5 digits
      expect(isValid).toBe(false);
    });

    it('should handle non-numeric codes', () => {
      const isValid = verifyTOTP('abcdef', { secret: testSecret });
      expect(isValid).toBe(false);
    });
  });

  // ===========================================================================
  // generateSecret Tests
  // ===========================================================================

  describe('generateSecret', () => {
    it('should generate base32 encoded secret', () => {
      const secret = generateSecret();
      expect(secret).toMatch(/^[A-Z2-7]+=*$/);
    });

    it('should generate secrets of default length (20 bytes)', () => {
      const secret = generateSecret();
      // 20 bytes = 160 bits, in base32 = 32 characters (before padding)
      expect(secret.replace(/=/g, '').length).toBeGreaterThanOrEqual(32);
    });

    it('should generate secrets of specified length', () => {
      const secret10 = generateSecret(10);
      const secret30 = generateSecret(30);
      // Longer input = longer output
      expect(secret30.length).toBeGreaterThan(secret10.length);
    });

    it('should generate unique secrets', () => {
      const secrets = new Set<string>();
      for (let i = 0; i < 100; i++) {
        secrets.add(generateSecret());
      }
      expect(secrets.size).toBe(100);
    });

    it('should generate decodable secrets', () => {
      const secret = generateSecret();
      expect(() => base32Decode(secret)).not.toThrow();
    });
  });

  // ===========================================================================
  // generateProvisioningURI Tests
  // ===========================================================================

  describe('generateProvisioningURI', () => {
    const baseOptions = {
      secret: 'JBSWY3DPEHPK3PXP',
      accountName: 'user@example.com',
      issuer: 'IncomeEngine',
    };

    it('should generate valid otpauth URI', () => {
      const uri = generateProvisioningURI(baseOptions);
      expect(uri).toMatch(/^otpauth:\/\/totp\//);
    });

    it('should include secret in URI', () => {
      const uri = generateProvisioningURI(baseOptions);
      expect(uri).toContain('secret=JBSWY3DPEHPK3PXP');
    });

    it('should include issuer in URI', () => {
      const uri = generateProvisioningURI(baseOptions);
      expect(uri).toContain('issuer=IncomeEngine');
    });

    it('should encode account name in label', () => {
      const uri = generateProvisioningURI(baseOptions);
      expect(uri).toContain('IncomeEngine%3Auser%40example.com');
    });

    it('should include period parameter', () => {
      const uri = generateProvisioningURI({ ...baseOptions, period: 60 });
      expect(uri).toContain('period=60');
    });

    it('should include digits parameter', () => {
      const uri = generateProvisioningURI({ ...baseOptions, digits: 8 });
      expect(uri).toContain('digits=8');
    });

    it('should include algorithm parameter', () => {
      const uri = generateProvisioningURI({ ...baseOptions, algorithm: 'sha256' });
      expect(uri).toContain('algorithm=SHA256');
    });

    it('should use defaults for optional parameters', () => {
      const uri = generateProvisioningURI(baseOptions);
      expect(uri).toContain('period=30');
      expect(uri).toContain('digits=6');
      expect(uri).toContain('algorithm=SHA1');
    });

    it('should remove spaces from secret', () => {
      const uri = generateProvisioningURI({
        ...baseOptions,
        secret: 'JBSW Y3DP EHPK 3PXP',
      });
      expect(uri).not.toContain(' ');
    });

    it('should handle special characters in issuer', () => {
      const uri = generateProvisioningURI({
        ...baseOptions,
        issuer: 'My App & Service',
      });
      expect(uri).toContain(encodeURIComponent('My App & Service'));
    });
  });

  // ===========================================================================
  // getCode Tests
  // ===========================================================================

  describe('getCode', () => {
    it('should return 6-digit code', () => {
      const code = getCode('JBSWY3DPEHPK3PXP');
      expect(code).toMatch(/^\d{6}$/);
    });

    it('should be consistent with generateTOTP', () => {
      const secret = 'JBSWY3DPEHPK3PXP';
      const simpleCode = getCode(secret);
      const fullResult = generateTOTP({ secret });
      expect(simpleCode).toBe(fullResult.code);
    });
  });

  // ===========================================================================
  // getTimeRemaining Tests
  // ===========================================================================

  describe('getTimeRemaining', () => {
    it('should return value between 1 and period', () => {
      const remaining = getTimeRemaining(30);
      expect(remaining).toBeGreaterThan(0);
      expect(remaining).toBeLessThanOrEqual(30);
    });

    it('should use default period of 30', () => {
      const remaining = getTimeRemaining();
      expect(remaining).toBeGreaterThan(0);
      expect(remaining).toBeLessThanOrEqual(30);
    });

    it('should work with custom periods', () => {
      const remaining60 = getTimeRemaining(60);
      expect(remaining60).toBeLessThanOrEqual(60);

      const remaining10 = getTimeRemaining(10);
      expect(remaining10).toBeLessThanOrEqual(10);
    });
  });

  // ===========================================================================
  // waitForNextCode Tests
  // ===========================================================================

  describe('waitForNextCode', () => {
    beforeEach(() => {
      vi.useFakeTimers();
    });

    afterEach(() => {
      vi.useRealTimers();
    });

    it('should return a promise', () => {
      const promise = waitForNextCode(30);
      expect(promise).toBeInstanceOf(Promise);
      vi.runAllTimers();
    });

    it('should resolve after waiting', async () => {
      const promise = waitForNextCode(30);

      // Fast-forward time
      vi.advanceTimersByTime(31000);

      await expect(promise).resolves.toBeUndefined();
    });

    it('should wait for remaining time plus 1 second', async () => {
      // Mock Date.now to return a consistent value
      const baseTime = 1704067200000; // 2024-01-01 00:00:00 UTC
      vi.setSystemTime(baseTime);

      const promise = waitForNextCode(30);

      // Should wait remaining seconds + 1
      const remaining = getTimeRemaining(30);
      vi.advanceTimersByTime((remaining + 1) * 1000);

      await expect(promise).resolves.toBeUndefined();
    });
  });

  // ===========================================================================
  // Algorithm Tests
  // ===========================================================================

  describe('Algorithm Support', () => {
    const secret = 'JBSWY3DPEHPK3PXP';

    it('should support sha1', () => {
      const result = generateTOTP({ secret, algorithm: 'sha1' });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should support sha256', () => {
      const result = generateTOTP({ secret, algorithm: 'sha256' });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should support sha512', () => {
      const result = generateTOTP({ secret, algorithm: 'sha512' });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should generate different codes with different algorithms', () => {
      const sha1Code = generateTOTP({ secret, algorithm: 'sha1' }).code;
      const sha256Code = generateTOTP({ secret, algorithm: 'sha256' }).code;
      const sha512Code = generateTOTP({ secret, algorithm: 'sha512' }).code;

      // At least 2 should be different (all 3 matching would be extremely unlikely)
      const uniqueCodes = new Set([sha1Code, sha256Code, sha512Code]);
      expect(uniqueCodes.size).toBeGreaterThanOrEqual(2);
    });
  });

  // ===========================================================================
  // Edge Cases
  // ===========================================================================

  describe('Edge Cases', () => {
    it('should handle minimum valid secret length', () => {
      // Minimum valid base32 string
      const result = generateTOTP({ secret: 'AA' });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should handle very long secrets', () => {
      const longSecret = 'A'.repeat(1000);
      const result = generateTOTP({ secret: longSecret });
      expect(result.code).toMatch(/^\d{6}$/);
    });

    it('should handle digits from 4 to 10', () => {
      const secret = 'JBSWY3DPEHPK3PXP';

      for (let digits = 4; digits <= 10; digits++) {
        const result = generateTOTP({ secret, digits });
        expect(result.code.length).toBe(digits);
      }
    });

    it('should handle period of 1 second', () => {
      const result = generateTOTP({ secret: 'JBSWY3DPEHPK3PXP', period: 1 });
      expect(result.remainingSeconds).toBeLessThanOrEqual(1);
    });

    it('should handle period of 60 seconds', () => {
      const result = generateTOTP({ secret: 'JBSWY3DPEHPK3PXP', period: 60 });
      expect(result.remainingSeconds).toBeLessThanOrEqual(60);
    });
  });

  // ===========================================================================
  // Timing Attack Prevention Tests
  // ===========================================================================

  describe('Timing Safe Comparison', () => {
    const secret = 'JBSWY3DPEHPK3PXP';

    it('should reject codes of different lengths', () => {
      const isValid = verifyTOTP('12345', { secret }); // 5 digits vs expected 6
      expect(isValid).toBe(false);
    });

    it('should reject empty code', () => {
      const isValid = verifyTOTP('', { secret });
      expect(isValid).toBe(false);
    });

    it('should handle null-like values gracefully', () => {
      // @ts-ignore - Testing runtime behavior
      expect(verifyTOTP(null, { secret })).toBe(false);
      // @ts-ignore - Testing runtime behavior
      expect(verifyTOTP(undefined, { secret })).toBe(false);
    });
  });

  // ===========================================================================
  // RFC 6238 Test Vectors
  // ===========================================================================

  describe('RFC 6238 Test Vectors', () => {
    // Note: These are simplified tests. Full RFC compliance would require
    // testing with exact timestamps and expected values from the RFC.

    it('should use correct counter calculation', () => {
      const period = 30;
      const now = Math.floor(Date.now() / 1000);
      const expectedCounter = Math.floor(now / period);

      const result = generateTOTP({ secret: 'JBSWY3DPEHPK3PXP', period });
      expect(result.counter).toBe(expectedCounter);
    });

    it('should calculate correct time remaining', () => {
      const period = 30;
      const now = Math.floor(Date.now() / 1000);
      const expectedRemaining = period - (now % period);

      const result = generateTOTP({ secret: 'JBSWY3DPEHPK3PXP', period });
      // Allow 1 second variance for test timing
      expect(Math.abs(result.remainingSeconds - expectedRemaining)).toBeLessThanOrEqual(1);
    });
  });

  // ===========================================================================
  // Integration Tests
  // ===========================================================================

  describe('Integration', () => {
    it('should complete full generate-verify cycle', () => {
      const secret = generateSecret();
      const { code } = generateTOTP({ secret });
      const isValid = verifyTOTP(code, { secret });
      expect(isValid).toBe(true);
    });

    it('should work with provisioning URI secret', () => {
      const secret = 'JBSWY3DPEHPK3PXP';
      const uri = generateProvisioningURI({
        secret,
        accountName: 'test@example.com',
        issuer: 'Test',
      });

      // Extract secret from URI
      const match = uri.match(/secret=([A-Z2-7]+)/);
      expect(match).not.toBeNull();

      const extractedSecret = match![1];
      const { code } = generateTOTP({ secret: extractedSecret });
      const isValid = verifyTOTP(code, { secret: extractedSecret });
      expect(isValid).toBe(true);
    });
  });

  // ===========================================================================
  // Default Export Tests
  // ===========================================================================

  describe('Default Export', () => {
    it('should export all functions', async () => {
      const totpModule = await import('../../utils/totp');

      expect(totpModule.default.generateTOTP).toBeDefined();
      expect(totpModule.default.verifyTOTP).toBeDefined();
      expect(totpModule.default.generateSecret).toBeDefined();
      expect(totpModule.default.generateProvisioningURI).toBeDefined();
      expect(totpModule.default.getCode).toBeDefined();
      expect(totpModule.default.getTimeRemaining).toBeDefined();
      expect(totpModule.default.waitForNextCode).toBeDefined();
      expect(totpModule.default.base32Decode).toBeDefined();
      expect(totpModule.default.base32Encode).toBeDefined();
    });
  });
});
