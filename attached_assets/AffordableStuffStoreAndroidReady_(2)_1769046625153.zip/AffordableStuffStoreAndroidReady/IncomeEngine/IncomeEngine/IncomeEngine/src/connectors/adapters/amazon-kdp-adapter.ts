/**
 * Amazon KDP Adapter
 *
 * Playwright-based browser automation connector for Amazon Kindle Direct Publishing.
 * Amazon KDP does not provide a public API, so this adapter uses browser automation
 * to interact with the KDP dashboard.
 *
 * Features:
 * - Book manuscript uploads
 * - Cover image management
 * - Metadata updates (title, description, categories, keywords)
 * - Pricing configuration
 * - Sales report retrieval
 *
 * IMPORTANT: This adapter requires careful rate limiting to avoid detection.
 * Human-like delays are built into all operations.
 */

import { Browser, Page, chromium, BrowserContext } from 'playwright';
import {
  BaseConnector,
  ConnectorConfig,
  RequestOptions,
} from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  NormalizedProduct,
  ProductInput,
  PaginatedProducts,
  CreateResult,
  UpdateResult,
  DeleteResult,
  AuthToken,
  ListOptions,
  ValidationResult,
  PlatformAnalytics,
  DateRange,
  ProductType,
  ProductStatus,
} from '../core/types';
import { mapPlatformError, ErrorCode } from '../utils/error-mapper';
import { generateTOTP, getTimeRemaining, waitForNextCode } from '../utils/totp';

// ============================================================================
// Amazon KDP Types
// ============================================================================

interface KDPCredentials {
  email: string;
  password: string;
  otpSecret?: string; // For 2FA
}

interface KDPBook {
  asin?: string;
  title: string;
  subtitle?: string;
  author: string;
  contributors?: KDPContributor[];
  description: string;
  keywords: string[];
  categories: string[];
  publishingRights: 'public_domain' | 'own_copyright';
  adultContent: boolean;
  language: string;
  manuscriptFile?: Buffer | string;
  coverFile?: Buffer | string;
  pricing: KDPPricing;
  isbn?: string;
  publicationDate?: Date;
  seriesInfo?: KDPSeriesInfo;
}

interface KDPContributor {
  name: string;
  role: 'author' | 'editor' | 'illustrator' | 'translator' | 'foreword' | 'narrator';
}

interface KDPPricing {
  listPriceUSD: number;
  kdpSelectEnrolled: boolean;
  territories: 'worldwide' | 'specific';
  specificTerritories?: string[];
  royaltyOption: '35' | '70';
}

interface KDPSeriesInfo {
  seriesName: string;
  volumeNumber: number;
}

interface KDPSalesReport {
  dateRange: DateRange;
  totalUnits: number;
  totalRevenue: number;
  totalRoyalties: number;
  byBook: KDPBookSales[];
  byMarketplace: KDPMarketplaceSales[];
}

interface KDPBookSales {
  asin: string;
  title: string;
  units: number;
  revenue: number;
  royalties: number;
  kenpcRead?: number; // Kindle Unlimited page reads
}

interface KDPMarketplaceSales {
  marketplace: string;
  units: number;
  revenue: number;
  royalties: number;
}

interface KDPUploadResult {
  success: boolean;
  asin?: string;
  bookId?: string;
  status: 'draft' | 'in_review' | 'live' | 'blocked';
  warnings?: string[];
  errors?: string[];
}

// ============================================================================
// Browser Automation Helpers
// ============================================================================

/**
 * Human-like delay between actions
 */
function humanDelay(minMs: number = 500, maxMs: number = 2000): Promise<void> {
  const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
  return new Promise(resolve => setTimeout(resolve, delay));
}

/**
 * Type text with human-like speed variation
 */
async function humanType(page: Page, selector: string, text: string): Promise<void> {
  await page.click(selector);
  await humanDelay(100, 300);

  for (const char of text) {
    await page.keyboard.type(char, { delay: Math.random() * 100 + 30 });
  }
}

/**
 * Scroll page like a human
 */
async function humanScroll(page: Page): Promise<void> {
  const scrollAmount = Math.floor(Math.random() * 300) + 100;
  await page.evaluate((amount) => {
    window.scrollBy(0, amount);
  }, scrollAmount);
  await humanDelay(200, 500);
}

// ============================================================================
// Amazon KDP Adapter Implementation
// ============================================================================

export class AmazonKDPAdapter extends BaseConnector {
  readonly name = 'amazon-kdp';
  readonly workflowGroup = 'marketplace' as const;
  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: false,
    supportsBulkOperations: false,
    supportsWebhooks: false,
    supportsInventorySync: false,
    supportsOrderFulfillment: false,
    supportsAnalytics: true,
    maxProductsPerRequest: 1,
    rateLimits: {
      requestsPerMinute: 5, // Very conservative for browser automation
      requestsPerHour: 50,
    },
  };

  private browser: Browser | null = null;
  private context: BrowserContext | null = null;
  private page: Page | null = null;
  private isAuthenticated: boolean = false;
  private credentials: KDPCredentials | null = null;

  // KDP Dashboard URLs
  private readonly URLS = {
    login: 'https://kdp.amazon.com/signin',
    dashboard: 'https://kdp.amazon.com/bookshelf',
    createBook: 'https://kdp.amazon.com/title-setup/kindle/new/details',
    reports: 'https://kdp.amazon.com/reports',
  };

  constructor(config: ConnectorConfig) {
    super(config);
  }

  // ============================================================================
  // Browser Lifecycle
  // ============================================================================

  /**
   * Initialize Playwright browser
   */
  async initBrowser(): Promise<void> {
    if (this.browser) {
      return;
    }

    try {
      this.browser = await chromium.launch({
        headless: true, // Set to false for debugging
        args: [
          '--disable-blink-features=AutomationControlled',
          '--disable-features=IsolateOrigins,site-per-process',
        ],
      });

      this.context = await this.browser.newContext({
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        viewport: { width: 1920, height: 1080 },
        locale: 'en-US',
        timezoneId: 'America/Los_Angeles',
      });

      // Block unnecessary resources to speed up automation
      await this.context.route('**/*.{png,jpg,jpeg,gif,webp,svg}', route => {
        // Allow images on KDP (needed for cover uploads)
        if (route.request().url().includes('kdp.amazon.com')) {
          route.continue();
        } else {
          route.abort();
        }
      });

      this.page = await this.context.newPage();

      // Add anti-detection measures
      await this.page.addInitScript(() => {
        // Override navigator.webdriver
        Object.defineProperty(navigator, 'webdriver', { get: () => false });

        // Add missing properties
        (window as any).chrome = { runtime: {} };

        // Override permissions
        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters: any) =>
          parameters.name === 'notifications'
            ? Promise.resolve({ state: 'denied' } as PermissionStatus)
            : originalQuery(parameters);
      });

    } catch (error) {
      throw new Error(`Failed to initialize browser: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Close browser and clean up
   */
  async closeBrowser(): Promise<void> {
    try {
      if (this.page) {
        await this.page.close();
        this.page = null;
      }
      if (this.context) {
        await this.context.close();
        this.context = null;
      }
      if (this.browser) {
        await this.browser.close();
        this.browser = null;
      }
      this.isAuthenticated = false;
    } catch (error) {
      console.error('Error closing browser:', error);
    }
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    try {
      // Get credentials from credential manager
      const creds = await this.getCredentials<KDPCredentials>();
      if (!creds) {
        return {
          success: false,
          error: {
            code: ErrorCode.AUTH_FAILED,
            message: 'KDP credentials not configured',
            retryable: false,
          },
        };
      }

      this.credentials = creds;
      await this.initBrowser();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to login page
      await this.page.goto(this.URLS.login, { waitUntil: 'networkidle' });
      await humanDelay(1000, 2000);

      // Enter email
      await humanType(this.page, '#ap_email', creds.email);
      await humanDelay(500, 1000);

      // Click continue (Amazon's two-step login)
      const continueButton = await this.page.$('#continue');
      if (continueButton) {
        await continueButton.click();
        await humanDelay(1500, 3000);
      }

      // Enter password
      await humanType(this.page, '#ap_password', creds.password);
      await humanDelay(500, 1000);

      // Click sign in
      await this.page.click('#signInSubmit');
      await humanDelay(2000, 4000);

      // Check for 2FA
      const otpInput = await this.page.$('#auth-mfa-otpcode');
      if (otpInput) {
        if (!creds.otpSecret) {
          return {
            success: false,
            error: {
              code: ErrorCode.AUTH_FAILED,
              message: '2FA required but OTP secret not configured. Add otpSecret to KDP credentials.',
              retryable: false,
            },
          };
        }

        // Generate TOTP code from secret
        const totpResult = generateTOTP({
          secret: creds.otpSecret,
          period: 30,
          digits: 6,
          algorithm: 'sha1',
        });

        // If less than 5 seconds remaining, wait for next code to avoid expiration during auth
        if (totpResult.remainingSeconds < 5) {
          await waitForNextCode(30);
          const freshResult = generateTOTP({
            secret: creds.otpSecret,
            period: 30,
            digits: 6,
          });
          await humanType(this.page, '#auth-mfa-otpcode', freshResult.code);
        } else {
          await humanType(this.page, '#auth-mfa-otpcode', totpResult.code);
        }

        await humanDelay(500, 1000);

        // Submit OTP
        const otpSubmitButton = await this.page.$('#auth-signin-button');
        if (otpSubmitButton) {
          await otpSubmitButton.click();
          await humanDelay(3000, 5000);
        }

        // Check for OTP error
        const otpError = await this.page.$('.auth-error-message');
        if (otpError) {
          const errorText = await otpError.textContent();
          return {
            success: false,
            error: {
              code: ErrorCode.AUTH_FAILED,
              message: `2FA verification failed: ${errorText || 'Invalid OTP code'}`,
              retryable: true,
            },
          };
        }
      }

      // Wait for dashboard to load
      await this.page.waitForURL('**/bookshelf**', { timeout: 30000 });
      this.isAuthenticated = true;

      return {
        success: true,
        data: {
          accessToken: 'browser_session',
          tokenType: 'browser',
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        },
      };
    } catch (error) {
      const mappedError = mapPlatformError('amazon-kdp', error);
      return {
        success: false,
        error: mappedError,
      };
    }
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    // For browser automation, we just re-authenticate
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    const result = await this.authenticate();
    return result.success;
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to bookshelf
      await this.page.goto(this.URLS.dashboard, { waitUntil: 'networkidle' });
      await humanDelay(2000, 3000);

      // Extract book data from the page
      const books = await this.page.evaluate(() => {
        const bookElements = document.querySelectorAll('[data-action="bookshelf-row"]');
        const results: any[] = [];

        bookElements.forEach((el) => {
          const titleEl = el.querySelector('.title-cell a');
          const statusEl = el.querySelector('.status-cell');
          const dateEl = el.querySelector('.date-cell');

          if (titleEl) {
            results.push({
              id: el.getAttribute('data-asin') || '',
              title: titleEl.textContent?.trim() || '',
              status: statusEl?.textContent?.trim() || 'unknown',
              lastModified: dateEl?.textContent?.trim() || '',
            });
          }
        });

        return results;
      });

      const normalizedProducts: NormalizedProduct[] = books.map(book => ({
        id: book.id,
        externalId: book.id,
        title: book.title,
        description: '',
        productType: 'book' as ProductType,
        images: [],
        variants: [],
        pricing: {
          basePrice: 0,
          currency: 'USD',
          compareAtPrice: undefined,
          costPerItem: undefined,
        },
        metadata: {
          kdpStatus: book.status,
          lastModified: book.lastModified,
        },
        platformData: book,
        status: this.mapKDPStatus(book.status),
        createdAt: new Date(),
        updatedAt: new Date(),
      }));

      return {
        success: true,
        data: {
          items: normalizedProducts,
          pagination: {
            page: 1,
            limit: normalizedProducts.length,
            total: normalizedProducts.length,
            hasMore: false,
          },
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to book details
      await this.page.goto(`https://kdp.amazon.com/title-setup/kindle/${id}/details`, {
        waitUntil: 'networkidle',
      });
      await humanDelay(2000, 3000);

      // Extract book details
      const bookData = await this.page.evaluate(() => {
        const title = (document.querySelector('#data-print-book-title') as HTMLInputElement)?.value || '';
        const subtitle = (document.querySelector('#data-print-book-subtitle') as HTMLInputElement)?.value || '';
        const description = (document.querySelector('#data-print-book-description') as HTMLTextAreaElement)?.value || '';
        const author = (document.querySelector('#data-print-book-primary-author-first') as HTMLInputElement)?.value || '';

        return { title, subtitle, description, author };
      });

      return {
        success: true,
        data: {
          id,
          externalId: id,
          title: bookData.title,
          description: bookData.description,
          productType: 'book' as ProductType,
          images: [],
          variants: [],
          pricing: {
            basePrice: 0,
            currency: 'USD',
          },
          metadata: {
            subtitle: bookData.subtitle,
            author: bookData.author,
          },
          platformData: bookData,
          status: 'active' as ProductStatus,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Validate product for KDP
      const validation = this.validateProductForPlatform(product);
      if (!validation.valid) {
        return {
          success: false,
          error: {
            code: ErrorCode.VALIDATION_ERROR,
            message: validation.errors.join(', '),
            retryable: false,
          },
        };
      }

      // Navigate to create book page
      await this.page.goto(this.URLS.createBook, { waitUntil: 'networkidle' });
      await humanDelay(2000, 3000);

      // Fill in book details
      await this.fillBookDetails(product);
      await humanDelay(1000, 2000);

      // Save as draft
      await this.page.click('[data-action="save-draft"]');
      await humanDelay(3000, 5000);

      // Check for success message or errors
      const successMessage = await this.page.$('.success-message');
      if (successMessage) {
        // Get the new book ID from URL
        const url = this.page.url();
        const asinMatch = url.match(/\/([A-Z0-9]{10})\//);
        const asin = asinMatch ? asinMatch[1] : '';

        return {
          success: true,
          data: {
            id: asin,
            externalId: asin,
            status: 'draft',
            url: `https://kdp.amazon.com/title-setup/kindle/${asin}/details`,
          },
        };
      }

      // Check for errors
      const errors = await this.page.$$eval('.error-message', els =>
        els.map(el => el.textContent?.trim() || '')
      );

      if (errors.length > 0) {
        return {
          success: false,
          error: {
            code: ErrorCode.VALIDATION_ERROR,
            message: errors.join(', '),
            retryable: false,
          },
        };
      }

      return {
        success: true,
        data: {
          id: 'pending',
          externalId: 'pending',
          status: 'draft',
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  async updateProduct(id: string, updates: Partial<ProductInput>): Promise<ConnectorResult<UpdateResult>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to book edit page
      await this.page.goto(`https://kdp.amazon.com/title-setup/kindle/${id}/details`, {
        waitUntil: 'networkidle',
      });
      await humanDelay(2000, 3000);

      // Update book details
      if (updates.title) {
        await this.clearAndType('#data-print-book-title', updates.title);
      }
      if (updates.description) {
        await this.clearAndType('#data-print-book-description', updates.description);
      }

      // Save changes
      await this.page.click('[data-action="save-draft"]');
      await humanDelay(3000, 5000);

      return {
        success: true,
        data: {
          id,
          externalId: id,
          updated: true,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    // KDP doesn't allow deletion of published books
    // You can only unpublish or archive them
    return {
      success: false,
      error: {
        code: ErrorCode.UNSUPPORTED_OPERATION,
        message: 'KDP does not support book deletion. Use unpublish instead.',
        retryable: false,
      },
    };
  }

  // ============================================================================
  // KDP-Specific Methods
  // ============================================================================

  /**
   * Upload a book manuscript
   */
  async uploadManuscript(bookId: string, manuscriptPath: string): Promise<ConnectorResult<KDPUploadResult>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to content page
      await this.page.goto(`https://kdp.amazon.com/title-setup/kindle/${bookId}/content`, {
        waitUntil: 'networkidle',
      });
      await humanDelay(2000, 3000);

      // Upload manuscript
      const manuscriptInput = await this.page.$('input[type="file"][accept=".doc,.docx,.epub,.pdf"]');
      if (manuscriptInput) {
        await manuscriptInput.setInputFiles(manuscriptPath);
        await humanDelay(5000, 10000); // Wait for upload and processing
      }

      // Wait for conversion
      await this.page.waitForSelector('.manuscript-status-success', { timeout: 120000 });

      return {
        success: true,
        data: {
          success: true,
          asin: bookId,
          status: 'draft',
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  /**
   * Upload a book cover
   */
  async uploadCover(bookId: string, coverPath: string): Promise<ConnectorResult<KDPUploadResult>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to content page
      await this.page.goto(`https://kdp.amazon.com/title-setup/kindle/${bookId}/content`, {
        waitUntil: 'networkidle',
      });
      await humanDelay(2000, 3000);

      // Select "Upload a cover you already have"
      await this.page.click('[data-action="upload-cover"]');
      await humanDelay(1000, 2000);

      // Upload cover
      const coverInput = await this.page.$('input[type="file"][accept=".jpg,.jpeg,.tif,.tiff,.png"]');
      if (coverInput) {
        await coverInput.setInputFiles(coverPath);
        await humanDelay(5000, 10000); // Wait for upload
      }

      // Wait for success
      await this.page.waitForSelector('.cover-upload-success', { timeout: 60000 });

      return {
        success: true,
        data: {
          success: true,
          asin: bookId,
          status: 'draft',
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  /**
   * Submit book for publishing
   */
  async publishBook(bookId: string): Promise<ConnectorResult<KDPUploadResult>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to pricing page (final step)
      await this.page.goto(`https://kdp.amazon.com/title-setup/kindle/${bookId}/pricing`, {
        waitUntil: 'networkidle',
      });
      await humanDelay(2000, 3000);

      // Click publish button
      await this.page.click('#publish-button');
      await humanDelay(2000, 3000);

      // Confirm publish
      const confirmButton = await this.page.$('#confirm-publish-button');
      if (confirmButton) {
        await confirmButton.click();
        await humanDelay(5000, 10000);
      }

      // Check for success
      const successMessage = await this.page.$('.publish-success-message');
      if (successMessage) {
        return {
          success: true,
          data: {
            success: true,
            asin: bookId,
            status: 'in_review',
          },
        };
      }

      return {
        success: true,
        data: {
          success: true,
          asin: bookId,
          status: 'in_review',
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  /**
   * Get sales report
   */
  async getSalesReport(dateRange: DateRange): Promise<ConnectorResult<KDPSalesReport>> {
    try {
      await this.ensureAuthenticated();

      if (!this.page) {
        throw new Error('Browser page not initialized');
      }

      // Navigate to reports
      await this.page.goto(this.URLS.reports, { waitUntil: 'networkidle' });
      await humanDelay(2000, 3000);

      // Select date range
      await this.page.click('#date-range-selector');
      await humanDelay(500, 1000);

      // For now, just get the current data displayed
      const salesData = await this.page.evaluate(() => {
        const rows = document.querySelectorAll('.sales-table tbody tr');
        const results: any[] = [];

        rows.forEach((row) => {
          const cells = row.querySelectorAll('td');
          if (cells.length >= 4) {
            results.push({
              title: cells[0].textContent?.trim() || '',
              units: parseInt(cells[1].textContent?.replace(/,/g, '') || '0', 10),
              royalties: parseFloat(cells[2].textContent?.replace(/[$,]/g, '') || '0'),
              kenpcRead: parseInt(cells[3].textContent?.replace(/,/g, '') || '0', 10),
            });
          }
        });

        return results;
      });

      const totalUnits = salesData.reduce((sum, book) => sum + book.units, 0);
      const totalRoyalties = salesData.reduce((sum, book) => sum + book.royalties, 0);

      return {
        success: true,
        data: {
          dateRange,
          totalUnits,
          totalRevenue: totalRoyalties * 1.5, // Estimate revenue from royalties
          totalRoyalties,
          byBook: salesData.map((book, index) => ({
            asin: `ASIN${index}`,
            title: book.title,
            units: book.units,
            revenue: book.royalties * 1.5,
            royalties: book.royalties,
            kenpcRead: book.kenpcRead,
          })),
          byMarketplace: [],
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapPlatformError('amazon-kdp', error),
      };
    }
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    const salesResult = await this.getSalesReport(dateRange);

    if (!salesResult.success || !salesResult.data) {
      return {
        success: false,
        error: salesResult.error,
      };
    }

    return {
      success: true,
      data: {
        platform: 'amazon-kdp',
        dateRange,
        revenue: salesResult.data.totalRevenue,
        orders: salesResult.data.totalUnits,
        views: 0, // KDP doesn't expose view data
        conversion: 0,
        topProducts: salesResult.data.byBook.slice(0, 10).map(book => ({
          id: book.asin,
          title: book.title,
          sales: book.units,
          revenue: book.revenue,
        })),
      },
    };
  }

  // ============================================================================
  // Product Normalization
  // ============================================================================

  normalizeProduct(kdpBook: any): NormalizedProduct {
    return {
      id: kdpBook.asin || kdpBook.id || '',
      externalId: kdpBook.asin,
      title: kdpBook.title,
      description: kdpBook.description || '',
      productType: 'book' as ProductType,
      images: kdpBook.coverUrl ? [{ url: kdpBook.coverUrl, position: 0 }] : [],
      variants: [],
      pricing: {
        basePrice: kdpBook.pricing?.listPriceUSD || 0,
        currency: 'USD',
      },
      metadata: {
        subtitle: kdpBook.subtitle,
        author: kdpBook.author,
        contributors: kdpBook.contributors,
        keywords: kdpBook.keywords,
        categories: kdpBook.categories,
        language: kdpBook.language,
        isbn: kdpBook.isbn,
        kdpSelectEnrolled: kdpBook.pricing?.kdpSelectEnrolled,
        royaltyOption: kdpBook.pricing?.royaltyOption,
      },
      platformData: kdpBook,
      status: this.mapKDPStatus(kdpBook.status),
      createdAt: kdpBook.createdAt ? new Date(kdpBook.createdAt) : new Date(),
      updatedAt: kdpBook.updatedAt ? new Date(kdpBook.updatedAt) : new Date(),
    };
  }

  denormalizeProduct(product: NormalizedProduct): KDPBook {
    return {
      asin: product.externalId,
      title: product.title,
      subtitle: product.metadata?.subtitle as string,
      author: product.metadata?.author as string || 'Unknown Author',
      contributors: product.metadata?.contributors as KDPContributor[],
      description: product.description,
      keywords: (product.metadata?.keywords as string[]) || [],
      categories: (product.metadata?.categories as string[]) || [],
      publishingRights: 'own_copyright',
      adultContent: false,
      language: (product.metadata?.language as string) || 'en',
      pricing: {
        listPriceUSD: product.pricing.basePrice,
        kdpSelectEnrolled: (product.metadata?.kdpSelectEnrolled as boolean) || false,
        territories: 'worldwide',
        royaltyOption: (product.metadata?.royaltyOption as '35' | '70') || '70',
      },
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Title validation
    if (!product.title || product.title.length === 0) {
      errors.push('Title is required');
    } else if (product.title.length > 200) {
      errors.push('Title must be 200 characters or less');
    }

    // Description validation
    if (!product.description || product.description.length < 100) {
      warnings.push('Description should be at least 100 characters for better discoverability');
    } else if (product.description.length > 4000) {
      errors.push('Description must be 4000 characters or less');
    }

    // Keywords validation (KDP allows 7 keywords)
    const keywords = (product.metadata?.keywords as string[]) || [];
    if (keywords.length > 7) {
      errors.push('Maximum of 7 keywords allowed');
    }

    // Price validation (KDP minimum is $0.99, max is $200)
    if (product.pricing?.basePrice && product.pricing.basePrice < 0.99) {
      errors.push('Minimum price is $0.99');
    }
    if (product.pricing?.basePrice && product.pricing.basePrice > 200) {
      errors.push('Maximum price is $200.00');
    }

    // Author required
    if (!product.metadata?.author) {
      errors.push('Author name is required');
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  private async ensureAuthenticated(): Promise<void> {
    if (!this.isAuthenticated) {
      const result = await this.authenticate();
      if (!result.success) {
        throw new Error(result.error?.message || 'Authentication failed');
      }
    }
  }

  private mapKDPStatus(status: string): ProductStatus {
    const statusMap: Record<string, ProductStatus> = {
      'live': 'active',
      'in_review': 'pending',
      'draft': 'draft',
      'blocked': 'archived',
      'suppressed': 'archived',
    };
    return statusMap[status.toLowerCase()] || 'draft';
  }

  private async fillBookDetails(product: ProductInput): Promise<void> {
    if (!this.page) return;

    // Title
    if (product.title) {
      await this.clearAndType('#data-print-book-title', product.title);
    }

    // Subtitle
    if (product.metadata?.subtitle) {
      await this.clearAndType('#data-print-book-subtitle', product.metadata.subtitle as string);
    }

    // Author
    if (product.metadata?.author) {
      await this.clearAndType('#data-print-book-primary-author-first', product.metadata.author as string);
    }

    // Description
    if (product.description) {
      await this.clearAndType('#data-print-book-description', product.description);
    }

    // Keywords
    const keywords = (product.metadata?.keywords as string[]) || [];
    for (let i = 0; i < Math.min(keywords.length, 7); i++) {
      await this.clearAndType(`#data-print-book-keywords-${i}`, keywords[i]);
      await humanDelay(200, 500);
    }
  }

  private async clearAndType(selector: string, text: string): Promise<void> {
    if (!this.page) return;

    await this.page.click(selector, { clickCount: 3 }); // Select all
    await this.page.keyboard.press('Backspace');
    await humanType(this.page, selector, text);
  }

  // ============================================================================
  // Cleanup
  // ============================================================================

  async disconnect(): Promise<void> {
    await this.closeBrowser();
  }
}

export default AmazonKDPAdapter;
