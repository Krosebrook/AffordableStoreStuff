/**
 * Webhook Notification Utility
 *
 * Handles outbound webhook notifications with retry logic and queue management.
 * Used for real-time notifications (low stock alerts, order updates, etc.)
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// ============================================================================
// Types
// ============================================================================

export interface WebhookConfig {
  url: string;
  secret?: string;
  retryAttempts?: number;
  retryDelayMs?: number;
  timeoutMs?: number;
}

export interface WebhookPayload {
  event: WebhookEventType;
  timestamp: string;
  data: Record<string, unknown>;
  metadata?: {
    source: string;
    version: string;
    idempotencyKey?: string;
  };
}

export type WebhookEventType =
  | 'low_stock_alert'
  | 'out_of_stock'
  | 'order_received'
  | 'order_fulfilled'
  | 'order_cancelled'
  | 'product_published'
  | 'product_rejected'
  | 'budget_warning'
  | 'budget_critical'
  | 'platform_error'
  | 'safeguard_triggered';

export interface WebhookResult {
  success: boolean;
  statusCode?: number;
  error?: string;
  attempts: number;
  duration: number;
}

export interface WebhookQueueItem {
  id: string;
  webhookUrl: string;
  payload: WebhookPayload;
  attempts: number;
  maxAttempts: number;
  nextRetryAt: Date;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  lastError?: string;
  createdAt: Date;
}

// ============================================================================
// Webhook Sender
// ============================================================================

/**
 * Send a webhook notification with retry support
 */
export async function sendWebhook(
  config: WebhookConfig,
  payload: WebhookPayload
): Promise<WebhookResult> {
  const {
    url,
    secret,
    retryAttempts = 3,
    retryDelayMs = 1000,
    timeoutMs = 10000,
  } = config;

  const startTime = Date.now();
  let lastError: string | undefined;
  let lastStatusCode: number | undefined;

  for (let attempt = 1; attempt <= retryAttempts; attempt++) {
    try {
      const body = JSON.stringify(payload);
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'X-Webhook-Event': payload.event,
        'X-Webhook-Timestamp': payload.timestamp,
      };

      // Add signature if secret is provided
      if (secret) {
        const signature = await computeSignature(body, secret);
        headers['X-Webhook-Signature'] = signature;
      }

      // Add idempotency key if available
      if (payload.metadata?.idempotencyKey) {
        headers['X-Idempotency-Key'] = payload.metadata.idempotencyKey;
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers,
          body,
          signal: controller.signal,
        });

        clearTimeout(timeoutId);
        lastStatusCode = response.status;

        if (response.ok) {
          return {
            success: true,
            statusCode: response.status,
            attempts: attempt,
            duration: Date.now() - startTime,
          };
        }

        // Non-retryable status codes
        if (response.status >= 400 && response.status < 500 && response.status !== 429) {
          const errorBody = await response.text().catch(() => 'Unknown error');
          return {
            success: false,
            statusCode: response.status,
            error: `HTTP ${response.status}: ${errorBody}`,
            attempts: attempt,
            duration: Date.now() - startTime,
          };
        }

        lastError = `HTTP ${response.status}`;
      } catch (fetchError) {
        clearTimeout(timeoutId);
        throw fetchError;
      }
    } catch (error) {
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          lastError = `Timeout after ${timeoutMs}ms`;
        } else {
          lastError = error.message;
        }
      } else {
        lastError = 'Unknown error';
      }
    }

    // Wait before retry (exponential backoff)
    if (attempt < retryAttempts) {
      const delay = retryDelayMs * Math.pow(2, attempt - 1);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  return {
    success: false,
    statusCode: lastStatusCode,
    error: lastError,
    attempts: retryAttempts,
    duration: Date.now() - startTime,
  };
}

/**
 * Compute HMAC-SHA256 signature for webhook payload
 */
async function computeSignature(payload: string, secret: string): Promise<string> {
  const { createHmac } = await import('crypto');
  const hmac = createHmac('sha256', secret);
  hmac.update(payload);
  return `sha256=${hmac.digest('hex')}`;
}

// ============================================================================
// Webhook Queue Manager
// ============================================================================

export class WebhookQueueManager {
  private supabase: SupabaseClient;
  private processing: boolean = false;
  private processInterval: NodeJS.Timeout | null = null;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * Queue a webhook for delivery
   */
  async enqueue(
    webhookUrl: string,
    payload: WebhookPayload,
    options?: { maxAttempts?: number; delayMs?: number }
  ): Promise<string> {
    const { maxAttempts = 5, delayMs = 0 } = options || {};

    const { data, error } = await this.supabase
      .from('webhook_queue')
      .insert({
        webhook_url: webhookUrl,
        payload,
        attempts: 0,
        max_attempts: maxAttempts,
        next_retry_at: new Date(Date.now() + delayMs).toISOString(),
        status: 'pending',
        created_at: new Date().toISOString(),
      })
      .select('id')
      .single();

    if (error) {
      throw new Error(`Failed to queue webhook: ${error.message}`);
    }

    return data.id;
  }

  /**
   * Start processing the webhook queue
   */
  startProcessing(intervalMs: number = 5000): void {
    if (this.processInterval) {
      clearInterval(this.processInterval);
    }

    this.processInterval = setInterval(() => {
      this.processQueue();
    }, intervalMs);

    // Process immediately
    this.processQueue();
  }

  /**
   * Stop processing the queue
   */
  stopProcessing(): void {
    if (this.processInterval) {
      clearInterval(this.processInterval);
      this.processInterval = null;
    }
  }

  /**
   * Process pending webhooks in the queue
   */
  private async processQueue(): Promise<void> {
    if (this.processing) return;
    this.processing = true;

    try {
      // Get pending webhooks ready for delivery
      const { data: webhooks, error } = await this.supabase
        .from('webhook_queue')
        .select('*')
        .eq('status', 'pending')
        .lte('next_retry_at', new Date().toISOString())
        .order('created_at', { ascending: true })
        .limit(10);

      if (error || !webhooks) {
        console.error('Failed to fetch webhook queue:', error);
        return;
      }

      for (const webhook of webhooks) {
        await this.processWebhook(webhook);
      }
    } finally {
      this.processing = false;
    }
  }

  /**
   * Process a single webhook
   */
  private async processWebhook(webhook: any): Promise<void> {
    // Mark as processing
    await this.supabase
      .from('webhook_queue')
      .update({ status: 'processing' })
      .eq('id', webhook.id);

    const result = await sendWebhook(
      { url: webhook.webhook_url },
      webhook.payload
    );

    const newAttempts = webhook.attempts + 1;

    if (result.success) {
      // Success - mark as completed
      await this.supabase
        .from('webhook_queue')
        .update({
          status: 'completed',
          attempts: newAttempts,
          completed_at: new Date().toISOString(),
        })
        .eq('id', webhook.id);
    } else if (newAttempts >= webhook.max_attempts) {
      // Max attempts reached - mark as failed
      await this.supabase
        .from('webhook_queue')
        .update({
          status: 'failed',
          attempts: newAttempts,
          last_error: result.error,
          failed_at: new Date().toISOString(),
        })
        .eq('id', webhook.id);
    } else {
      // Schedule retry with exponential backoff
      const retryDelay = 1000 * Math.pow(2, newAttempts);
      await this.supabase
        .from('webhook_queue')
        .update({
          status: 'pending',
          attempts: newAttempts,
          last_error: result.error,
          next_retry_at: new Date(Date.now() + retryDelay).toISOString(),
        })
        .eq('id', webhook.id);
    }

    // Log the attempt
    await this.supabase.from('webhook_log').insert({
      webhook_queue_id: webhook.id,
      event: webhook.payload.event,
      url: webhook.webhook_url,
      success: result.success,
      status_code: result.statusCode,
      error: result.error,
      duration_ms: result.duration,
      attempt: newAttempts,
      created_at: new Date().toISOString(),
    });
  }
}

// ============================================================================
// Notification Helper
// ============================================================================

/**
 * High-level notification sender that uses configured webhooks
 */
export class NotificationService {
  private supabase: SupabaseClient;
  private queueManager: WebhookQueueManager;

  constructor(supabaseUrl: string, supabaseKey: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.queueManager = new WebhookQueueManager(supabaseUrl, supabaseKey);
  }

  /**
   * Send notification to all configured webhooks for an event type
   */
  async notify(
    event: WebhookEventType,
    data: Record<string, unknown>
  ): Promise<void> {
    // Get configured webhook endpoints for this event
    const { data: endpoints } = await this.supabase
      .from('webhook_endpoints')
      .select('url, secret, events')
      .contains('events', [event])
      .eq('enabled', true);

    if (!endpoints || endpoints.length === 0) {
      return;
    }

    const payload: WebhookPayload = {
      event,
      timestamp: new Date().toISOString(),
      data,
      metadata: {
        source: 'income-engine',
        version: '2.0.0',
        idempotencyKey: `${event}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      },
    };

    // Queue webhooks for delivery
    for (const endpoint of endpoints) {
      await this.queueManager.enqueue(endpoint.url, payload);
    }
  }

  /**
   * Start the notification service
   */
  start(): void {
    this.queueManager.startProcessing();
  }

  /**
   * Stop the notification service
   */
  stop(): void {
    this.queueManager.stopProcessing();
  }
}

export default {
  sendWebhook,
  WebhookQueueManager,
  NotificationService,
};
