/**
 * Credential Manager
 * Handles OAuth flows, API key storage, and token refresh
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  AuthToken,
  OAuthConfig,
  ApiKeyConfig,
  CredentialConfig,
  ConnectorType,
  ConnectorResult,
  ConnectorError,
} from './types';

interface StoredCredential {
  id: string;
  platform: string;
  credential_type: ConnectorType;
  encrypted_data: string;
  access_token?: string;
  refresh_token?: string;
  expires_at?: string;
  scopes?: string[];
  created_at: string;
  updated_at: string;
}

interface OAuthState {
  platform: string;
  state: string;
  codeVerifier?: string;
  redirectUri: string;
  expiresAt: Date;
}

/**
 * Manages credentials for all platform connectors
 */
export class CredentialManager {
  private supabase: SupabaseClient;
  private credentialCache: Map<string, AuthToken> = new Map();
  private oauthStates: Map<string, OAuthState> = new Map();
  private encryptionKey: string;

  constructor(supabaseUrl: string, supabaseKey: string, encryptionKey?: string) {
    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.encryptionKey = encryptionKey || process.env.CREDENTIAL_ENCRYPTION_KEY || '';
  }

  // ============================================================================
  // API Key Management
  // ============================================================================

  /**
   * Store an API key for a platform
   */
  async storeApiKey(
    platform: string,
    config: ApiKeyConfig
  ): Promise<ConnectorResult<void>> {
    try {
      const encrypted = this.encrypt(JSON.stringify(config));

      const { error } = await this.supabase
        .from('platform_credentials')
        .upsert({
          platform,
          credential_type: 'api_key',
          encrypted_data: encrypted,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'platform',
        });

      if (error) {
        return {
          success: false,
          error: this.createError('STORAGE_ERROR', error.message),
        };
      }

      // Update cache
      this.credentialCache.set(platform, {
        accessToken: config.apiKey,
        tokenType: 'Bearer',
      });

      // Log audit event
      await this.logAuditEvent(platform, 'created');

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: this.createError('ENCRYPTION_ERROR', String(error)),
      };
    }
  }

  /**
   * Retrieve an API key for a platform
   */
  async getApiKey(platform: string): Promise<ConnectorResult<ApiKeyConfig>> {
    try {
      // Check cache first
      const cached = this.credentialCache.get(platform);
      if (cached) {
        return {
          success: true,
          data: { apiKey: cached.accessToken },
        };
      }

      const { data, error } = await this.supabase
        .from('platform_credentials')
        .select('encrypted_data')
        .eq('platform', platform)
        .eq('credential_type', 'api_key')
        .single();

      if (error || !data) {
        return {
          success: false,
          error: this.createError('NOT_FOUND', `No API key found for ${platform}`),
        };
      }

      const decrypted = this.decrypt(data.encrypted_data);
      const config: ApiKeyConfig = JSON.parse(decrypted);

      // Update cache
      this.credentialCache.set(platform, {
        accessToken: config.apiKey,
        tokenType: 'Bearer',
      });

      // Log audit event
      await this.logAuditEvent(platform, 'accessed');

      return { success: true, data: config };
    } catch (error) {
      return {
        success: false,
        error: this.createError('DECRYPTION_ERROR', String(error)),
      };
    }
  }

  // ============================================================================
  // OAuth Management
  // ============================================================================

  /**
   * Generate OAuth authorization URL
   */
  generateAuthUrl(platform: string, config: OAuthConfig): string {
    // Generate state for CSRF protection
    const state = this.generateState();
    const codeVerifier = this.generateCodeVerifier();
    const codeChallenge = this.generateCodeChallenge(codeVerifier);

    // Store state for verification
    this.oauthStates.set(state, {
      platform,
      state,
      codeVerifier,
      redirectUri: config.redirectUri,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
    });

    const params = new URLSearchParams({
      client_id: config.clientId,
      redirect_uri: config.redirectUri,
      response_type: 'code',
      scope: config.scopes.join(' '),
      state,
      code_challenge: codeChallenge,
      code_challenge_method: 'S256',
    });

    return `${config.authUrl}?${params.toString()}`;
  }

  /**
   * Exchange authorization code for tokens
   */
  async exchangeCodeForTokens(
    code: string,
    state: string,
    config: OAuthConfig
  ): Promise<ConnectorResult<AuthToken>> {
    // Verify state
    const storedState = this.oauthStates.get(state);
    if (!storedState || storedState.expiresAt < new Date()) {
      return {
        success: false,
        error: this.createError('INVALID_STATE', 'OAuth state is invalid or expired'),
      };
    }

    try {
      const response = await fetch(config.tokenUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          code,
          redirect_uri: storedState.redirectUri,
          client_id: config.clientId,
          client_secret: config.clientSecret,
          code_verifier: storedState.codeVerifier || '',
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: this.createError('TOKEN_ERROR', data.error_description || data.error),
        };
      }

      const token: AuthToken = {
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
        expiresAt: data.expires_in
          ? new Date(Date.now() + data.expires_in * 1000)
          : undefined,
        tokenType: data.token_type || 'Bearer',
        scopes: data.scope?.split(' ') || config.scopes,
      };

      // Store tokens
      await this.storeOAuthTokens(storedState.platform, token);

      // Clean up state
      this.oauthStates.delete(state);

      return { success: true, data: token };
    } catch (error) {
      return {
        success: false,
        error: this.createError('NETWORK_ERROR', String(error)),
      };
    }
  }

  /**
   * Refresh OAuth tokens
   */
  async refreshTokens(
    platform: string,
    config: OAuthConfig
  ): Promise<ConnectorResult<AuthToken>> {
    const storedResult = await this.getOAuthTokens(platform);
    if (!storedResult.success || !storedResult.data?.refreshToken) {
      return {
        success: false,
        error: this.createError('NO_REFRESH_TOKEN', 'No refresh token available'),
      };
    }

    try {
      const response = await fetch(config.tokenUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          grant_type: 'refresh_token',
          refresh_token: storedResult.data.refreshToken,
          client_id: config.clientId,
          client_secret: config.clientSecret,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: this.createError('REFRESH_ERROR', data.error_description || data.error),
        };
      }

      const token: AuthToken = {
        accessToken: data.access_token,
        refreshToken: data.refresh_token || storedResult.data.refreshToken,
        expiresAt: data.expires_in
          ? new Date(Date.now() + data.expires_in * 1000)
          : undefined,
        tokenType: data.token_type || 'Bearer',
        scopes: data.scope?.split(' ') || storedResult.data.scopes,
      };

      // Store updated tokens
      await this.storeOAuthTokens(platform, token);

      // Log audit event
      await this.logAuditEvent(platform, 'rotated');

      return { success: true, data: token };
    } catch (error) {
      return {
        success: false,
        error: this.createError('NETWORK_ERROR', String(error)),
      };
    }
  }

  /**
   * Store OAuth tokens
   */
  private async storeOAuthTokens(
    platform: string,
    token: AuthToken
  ): Promise<ConnectorResult<void>> {
    try {
      const { error } = await this.supabase
        .from('platform_credentials')
        .upsert({
          platform,
          credential_type: 'oauth2',
          access_token: this.encrypt(token.accessToken),
          refresh_token: token.refreshToken ? this.encrypt(token.refreshToken) : null,
          expires_at: token.expiresAt?.toISOString(),
          scopes: token.scopes,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'platform',
        });

      if (error) {
        return {
          success: false,
          error: this.createError('STORAGE_ERROR', error.message),
        };
      }

      // Update cache
      this.credentialCache.set(platform, token);

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: this.createError('ENCRYPTION_ERROR', String(error)),
      };
    }
  }

  /**
   * Retrieve OAuth tokens
   */
  async getOAuthTokens(platform: string): Promise<ConnectorResult<AuthToken>> {
    try {
      // Check cache first
      const cached = this.credentialCache.get(platform);
      if (cached && (!cached.expiresAt || cached.expiresAt > new Date())) {
        return { success: true, data: cached };
      }

      const { data, error } = await this.supabase
        .from('platform_credentials')
        .select('access_token, refresh_token, expires_at, scopes')
        .eq('platform', platform)
        .eq('credential_type', 'oauth2')
        .single();

      if (error || !data) {
        return {
          success: false,
          error: this.createError('NOT_FOUND', `No OAuth tokens found for ${platform}`),
        };
      }

      const token: AuthToken = {
        accessToken: this.decrypt(data.access_token),
        refreshToken: data.refresh_token ? this.decrypt(data.refresh_token) : undefined,
        expiresAt: data.expires_at ? new Date(data.expires_at) : undefined,
        tokenType: 'Bearer',
        scopes: data.scopes,
      };

      // Update cache
      this.credentialCache.set(platform, token);

      // Log audit event
      await this.logAuditEvent(platform, 'accessed');

      return { success: true, data: token };
    } catch (error) {
      return {
        success: false,
        error: this.createError('DECRYPTION_ERROR', String(error)),
      };
    }
  }

  // ============================================================================
  // Credential Validation
  // ============================================================================

  /**
   * Check if credentials exist for a platform
   */
  async hasCredentials(platform: string): Promise<boolean> {
    const { data } = await this.supabase
      .from('platform_credentials')
      .select('id')
      .eq('platform', platform)
      .single();

    return !!data;
  }

  /**
   * Check if OAuth token needs refresh
   */
  async needsRefresh(platform: string): Promise<boolean> {
    const result = await this.getOAuthTokens(platform);
    if (!result.success || !result.data) return true;

    const token = result.data;
    if (!token.expiresAt) return false;

    // Refresh if expires within 5 minutes
    const expiresInMs = token.expiresAt.getTime() - Date.now();
    return expiresInMs < 5 * 60 * 1000;
  }

  /**
   * Revoke credentials for a platform
   */
  async revokeCredentials(platform: string): Promise<ConnectorResult<void>> {
    try {
      const { error } = await this.supabase
        .from('platform_credentials')
        .delete()
        .eq('platform', platform);

      if (error) {
        return {
          success: false,
          error: this.createError('REVOKE_ERROR', error.message),
        };
      }

      // Clear cache
      this.credentialCache.delete(platform);

      // Log audit event
      await this.logAuditEvent(platform, 'revoked');

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: this.createError('REVOKE_ERROR', String(error)),
      };
    }
  }

  // ============================================================================
  // Encryption Helpers
  // ============================================================================

  /**
   * Encrypt sensitive data
   * In production, use a proper encryption library like crypto-js or node:crypto
   */
  private encrypt(data: string): string {
    if (!this.encryptionKey) {
      // Simple base64 encoding as fallback (NOT secure for production)
      return Buffer.from(data).toString('base64');
    }

    // Use proper encryption in production
    // This is a placeholder - implement with crypto library
    const key = this.encryptionKey;
    const encrypted = Buffer.from(data).toString('base64');
    return `enc:${encrypted}`;
  }

  /**
   * Decrypt sensitive data
   */
  private decrypt(encrypted: string): string {
    if (encrypted.startsWith('enc:')) {
      const data = encrypted.slice(4);
      return Buffer.from(data, 'base64').toString('utf-8');
    }

    // Fallback for unencrypted data
    return Buffer.from(encrypted, 'base64').toString('utf-8');
  }

  // ============================================================================
  // OAuth Helpers
  // ============================================================================

  /**
   * Generate random state for CSRF protection
   */
  private generateState(): string {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Generate code verifier for PKCE
   */
  private generateCodeVerifier(): string {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return this.base64UrlEncode(array);
  }

  /**
   * Generate code challenge from verifier
   */
  private generateCodeChallenge(verifier: string): string {
    // In a real implementation, use crypto.subtle.digest
    // This is a simplified version
    const encoder = new TextEncoder();
    const data = encoder.encode(verifier);
    // Should use SHA-256 hash here
    return this.base64UrlEncode(data);
  }

  /**
   * Base64 URL encode
   */
  private base64UrlEncode(buffer: Uint8Array): string {
    return Buffer.from(buffer)
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=/g, '');
  }

  // ============================================================================
  // Audit Logging
  // ============================================================================

  /**
   * Log credential access/modification events
   */
  private async logAuditEvent(
    platform: string,
    action: 'created' | 'accessed' | 'rotated' | 'revoked'
  ): Promise<void> {
    try {
      await this.supabase.from('credential_audit_log').insert({
        platform,
        action,
        created_at: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Failed to log audit event:', error);
    }
  }

  // ============================================================================
  // Helpers
  // ============================================================================

  /**
   * Create a ConnectorError
   */
  private createError(code: string, message: string): ConnectorError {
    return { code, message, retryable: false };
  }

  /**
   * Clear credential cache (useful for testing)
   */
  clearCache(): void {
    this.credentialCache.clear();
  }
}

export default CredentialManager;
