/**
 * Marketplace Workflow Engine
 *
 * Unified workflow orchestration for major marketplace platforms:
 * - Shopify (ecommerce platform)
 * - WooCommerce (WordPress ecommerce)
 * - Amazon KDP (books/ebooks)
 * - TikTok Shop (social commerce) [planned]
 *
 * This workflow handles:
 * - Inventory synchronization across platforms
 * - Order fulfillment coordination
 * - Price management and updates
 * - Multi-channel product listings
 * - Real-time stock tracking
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  NormalizedProduct,
  ProductInput,
  ConnectorResult,
  CreateResult,
  UpdateResult,
  ValidationResult,
  DateRange,
  ProductStatus,
} from '../core/types';
import { BaseConnector } from '../core/base-connector';
import { ShopifyAdapter } from '../adapters/shopify-adapter';
import { WooCommerceAdapter } from '../adapters/woocommerce-adapter';
import { AmazonKDPAdapter } from '../adapters/amazon-kdp-adapter';
import { ErrorCode } from '../utils/error-mapper';
import { NotificationService, WebhookEventType } from '../utils/webhook';

// ============================================================================
// Marketplace Types
// ============================================================================

export type MarketplacePlatform = 'shopify' | 'woocommerce' | 'amazon-kdp' | 'tiktok-shop';

export interface MarketplaceConfig {
  supabaseUrl: string;
  supabaseKey: string;
  enableInventorySync: boolean;
  enableOrderSync: boolean;
  inventorySyncIntervalMs: number;
  orderSyncIntervalMs: number;
  lowStockThreshold: number;
}

export interface MarketplaceListing {
  platform: MarketplacePlatform;
  enabled: boolean;
  pricingStrategy: PricingStrategy;
  inventoryAllocation: InventoryAllocation;
  fulfillmentConfig?: FulfillmentConfig;
}

export interface PricingStrategy {
  type: 'fixed' | 'margin' | 'competitive';
  basePrice?: number;
  marginPercent?: number;
  competitorAdjustment?: number;
  minPrice?: number;
  maxPrice?: number;
}

export interface InventoryAllocation {
  type: 'shared' | 'dedicated' | 'percentage';
  quantity?: number;
  percentage?: number;
  reserveQuantity?: number;
}

export interface FulfillmentConfig {
  provider: 'self' | 'platform' | 'third_party';
  thirdPartyName?: string;
  processingDays: number;
  shippingMethods: string[];
}

export interface InventoryUpdate {
  productId: string;
  platform: MarketplacePlatform;
  externalId: string;
  quantity: number;
  previousQuantity: number;
  updateType: 'sale' | 'restock' | 'adjustment' | 'sync';
  timestamp: Date;
}

export interface Order {
  id: string;
  platform: MarketplacePlatform;
  externalOrderId: string;
  status: OrderStatus;
  items: OrderItem[];
  customer: CustomerInfo;
  shippingAddress: Address;
  billingAddress?: Address;
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
  currency: string;
  paymentStatus: PaymentStatus;
  fulfillmentStatus: FulfillmentStatus;
  createdAt: Date;
  updatedAt: Date;
}

export interface OrderItem {
  productId: string;
  externalProductId: string;
  title: string;
  quantity: number;
  price: number;
  sku?: string;
  variantId?: string;
}

export interface CustomerInfo {
  id?: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
}

export interface Address {
  line1: string;
  line2?: string;
  city: string;
  state?: string;
  postalCode: string;
  country: string;
}

type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
type PaymentStatus = 'pending' | 'authorized' | 'paid' | 'partially_refunded' | 'refunded' | 'failed';
type FulfillmentStatus = 'unfulfilled' | 'partial' | 'fulfilled';

export interface WorkflowResult {
  success: boolean;
  productId: string;
  platforms: MarketplacePublishResult[];
  errors: WorkflowError[];
  totalTime: number;
}

export interface MarketplacePublishResult {
  platform: MarketplacePlatform;
  success: boolean;
  externalId?: string;
  externalUrl?: string;
  status: 'listed' | 'pending' | 'failed' | 'skipped';
  error?: string;
  inventoryLevel?: number;
}

export interface WorkflowError {
  platform?: MarketplacePlatform;
  code: string;
  message: string;
  recoverable: boolean;
  timestamp: Date;
}

export interface InventorySyncResult {
  success: boolean;
  platforms: PlatformSyncResult[];
  totalUpdated: number;
  errors: string[];
  duration: number;
}

export interface PlatformSyncResult {
  platform: MarketplacePlatform;
  success: boolean;
  productsUpdated: number;
  errors: string[];
}

export interface MarketplaceAnalytics {
  dateRange: DateRange;
  totalRevenue: number;
  totalOrders: number;
  totalProducts: number;
  byPlatform: Record<MarketplacePlatform, PlatformMetrics>;
  ordersByStatus: Record<OrderStatus, number>;
  revenueByDay: DailyRevenue[];
}

interface PlatformMetrics {
  revenue: number;
  orders: number;
  products: number;
  avgOrderValue: number;
  conversionRate: number;
  returnRate: number;
}

interface DailyRevenue {
  date: string;
  revenue: number;
  orders: number;
}

// ============================================================================
// Marketplace Workflow Engine
// ============================================================================

export class MarketplaceWorkflow {
  private connectors: Map<MarketplacePlatform, BaseConnector> = new Map();
  private supabase: SupabaseClient;
  private config: MarketplaceConfig;
  private inventorySyncTimer: NodeJS.Timeout | null = null;
  private orderSyncTimer: NodeJS.Timeout | null = null;
  private inventoryCache: Map<string, Map<MarketplacePlatform, number>> = new Map();
  private notificationService: NotificationService;

  constructor(config: MarketplaceConfig) {
    this.config = config;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
    this.notificationService = new NotificationService(config.supabaseUrl, config.supabaseKey);
  }

  // ============================================================================
  // Initialization
  // ============================================================================

  /**
   * Initialize connectors for specified platforms
   */
  async initialize(platforms: MarketplacePlatform[]): Promise<void> {
    for (const platform of platforms) {
      try {
        const connector = await this.createConnector(platform);
        if (connector) {
          this.connectors.set(platform, connector);
        }
      } catch (error) {
        console.error(`Failed to initialize ${platform} connector:`, error);
      }
    }

    // Start background sync if enabled
    if (this.config.enableInventorySync) {
      this.startInventorySync();
    }
    if (this.config.enableOrderSync) {
      this.startOrderSync();
    }

    // Start notification service
    this.notificationService.start();
  }

  /**
   * Create a connector instance with credentials from database
   */
  private async createConnector(platform: MarketplacePlatform): Promise<BaseConnector | null> {
    // Get credentials and settings from database
    const { data: connection, error } = await this.supabase
      .from('platform_connections')
      .select('*, platform_credentials(*)')
      .eq('platform', platform)
      .single();

    if (error || !connection) {
      console.warn(`No connection found for ${platform}`);
      return null;
    }

    const baseConfig = {
      supabaseUrl: this.config.supabaseUrl,
      supabaseKey: this.config.supabaseKey,
    };

    switch (platform) {
      case 'shopify':
        return new ShopifyAdapter({
          ...baseConfig,
          shopDomain: connection.settings?.shopDomain,
        });
      case 'woocommerce':
        return new WooCommerceAdapter({
          ...baseConfig,
          siteUrl: connection.settings?.siteUrl,
        });
      case 'amazon-kdp':
        return new AmazonKDPAdapter(baseConfig);
      default:
        console.warn(`Connector for ${platform} not yet implemented`);
        return null;
    }
  }

  // ============================================================================
  // Product Listing Workflow
  // ============================================================================

  /**
   * List a product across multiple marketplaces
   */
  async listProduct(
    product: ProductInput,
    listings: MarketplaceListing[]
  ): Promise<WorkflowResult> {
    const startTime = Date.now();
    const errors: WorkflowError[] = [];
    const platformResults: MarketplacePublishResult[] = [];

    for (const listing of listings) {
      if (!listing.enabled) {
        platformResults.push({
          platform: listing.platform,
          success: false,
          status: 'skipped',
          error: 'Platform disabled',
        });
        continue;
      }

      const connector = this.connectors.get(listing.platform);
      if (!connector) {
        platformResults.push({
          platform: listing.platform,
          success: false,
          status: 'skipped',
          error: 'Connector not initialized',
        });
        continue;
      }

      try {
        // Apply pricing strategy
        const pricedProduct = this.applyPricingStrategy(product, listing.pricingStrategy);

        // Validate for platform
        const validation = connector.validateProductForPlatform(pricedProduct);
        if (!validation.valid) {
          platformResults.push({
            platform: listing.platform,
            success: false,
            status: 'failed',
            error: validation.errors.join(', '),
          });
          continue;
        }

        // Create listing
        const result = await connector.createProduct(pricedProduct);

        if (result.success && result.data) {
          // Set initial inventory
          const inventoryLevel = this.calculateInventoryAllocation(
            product.metadata?.totalStock as number || 0,
            listing.inventoryAllocation
          );

          // Update inventory if supported
          if ('updateInventory' in connector) {
            await (connector as any).updateInventory(result.data.id, inventoryLevel);
          }

          // Cache inventory level
          this.updateInventoryCache(product.id!, listing.platform, inventoryLevel);

          platformResults.push({
            platform: listing.platform,
            success: true,
            externalId: result.data.externalId,
            externalUrl: result.data.url,
            status: 'listed',
            inventoryLevel,
          });
        } else {
          platformResults.push({
            platform: listing.platform,
            success: false,
            status: 'failed',
            error: result.error?.message || 'Unknown error',
          });
        }
      } catch (error) {
        errors.push({
          platform: listing.platform,
          code: ErrorCode.UNKNOWN,
          message: error instanceof Error ? error.message : 'Unknown error',
          recoverable: true,
          timestamp: new Date(),
        });

        platformResults.push({
          platform: listing.platform,
          success: false,
          status: 'failed',
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    // Store mappings
    await this.storeProductMappings(product.id!, platformResults);

    return {
      success: platformResults.some(r => r.success),
      productId: product.id!,
      platforms: platformResults,
      errors,
      totalTime: Date.now() - startTime,
    };
  }

  /**
   * Update product across all listed marketplaces
   */
  async updateProduct(
    productId: string,
    updates: Partial<ProductInput>
  ): Promise<WorkflowResult> {
    const startTime = Date.now();
    const errors: WorkflowError[] = [];
    const platformResults: MarketplacePublishResult[] = [];

    // Get existing mappings
    const { data: mappings } = await this.supabase
      .from('product_platform_mappings')
      .select('*')
      .eq('product_id', productId);

    if (!mappings || mappings.length === 0) {
      return {
        success: false,
        productId,
        platforms: [],
        errors: [{
          code: 'NO_MAPPINGS',
          message: 'Product not listed on any platform',
          recoverable: false,
          timestamp: new Date(),
        }],
        totalTime: Date.now() - startTime,
      };
    }

    for (const mapping of mappings) {
      const platform = mapping.platform as MarketplacePlatform;
      const connector = this.connectors.get(platform);

      if (!connector) {
        platformResults.push({
          platform,
          success: false,
          status: 'skipped',
          error: 'Connector not initialized',
        });
        continue;
      }

      try {
        const result = await connector.updateProduct(mapping.external_id, updates);

        platformResults.push({
          platform,
          success: result.success,
          externalId: mapping.external_id,
          status: result.success ? 'listed' : 'failed',
          error: result.error?.message,
        });
      } catch (error) {
        errors.push({
          platform,
          code: ErrorCode.UNKNOWN,
          message: error instanceof Error ? error.message : 'Unknown error',
          recoverable: true,
          timestamp: new Date(),
        });

        platformResults.push({
          platform,
          success: false,
          status: 'failed',
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    return {
      success: platformResults.some(r => r.success),
      productId,
      platforms: platformResults,
      errors,
      totalTime: Date.now() - startTime,
    };
  }

  // ============================================================================
  // Inventory Management
  // ============================================================================

  /**
   * Start periodic inventory synchronization
   */
  private startInventorySync(): void {
    if (this.inventorySyncTimer) {
      clearInterval(this.inventorySyncTimer);
    }

    this.inventorySyncTimer = setInterval(
      () => this.syncAllInventory(),
      this.config.inventorySyncIntervalMs
    );

    // Run initial sync
    this.syncAllInventory();
  }

  /**
   * Synchronize inventory across all platforms
   */
  async syncAllInventory(): Promise<InventorySyncResult> {
    const startTime = Date.now();
    const platformResults: PlatformSyncResult[] = [];
    const errors: string[] = [];
    let totalUpdated = 0;

    // Get all products with inventory tracking
    const { data: products } = await this.supabase
      .from('products')
      .select('id, inventory_quantity')
      .eq('track_inventory', true);

    if (!products) {
      return {
        success: false,
        platforms: [],
        totalUpdated: 0,
        errors: ['Failed to fetch products'],
        duration: Date.now() - startTime,
      };
    }

    for (const [platform, connector] of this.connectors.entries()) {
      const platformErrors: string[] = [];
      let updated = 0;

      // Get mappings for this platform
      const { data: mappings } = await this.supabase
        .from('product_platform_mappings')
        .select('product_id, external_id')
        .eq('platform', platform)
        .eq('publish_status', 'published');

      if (!mappings) continue;

      for (const mapping of mappings) {
        const product = products.find(p => p.id === mapping.product_id);
        if (!product) continue;

        try {
          // Check if inventory has changed
          const cachedInventory = this.getInventoryFromCache(mapping.product_id, platform);

          if (cachedInventory !== product.inventory_quantity) {
            // Update inventory on platform
            if ('updateInventory' in connector) {
              await (connector as any).updateInventory(
                mapping.external_id,
                product.inventory_quantity
              );

              // Update cache
              this.updateInventoryCache(
                mapping.product_id,
                platform,
                product.inventory_quantity
              );

              // Log update
              await this.logInventoryUpdate({
                productId: mapping.product_id,
                platform,
                externalId: mapping.external_id,
                quantity: product.inventory_quantity,
                previousQuantity: cachedInventory,
                updateType: 'sync',
                timestamp: new Date(),
              });

              updated++;
            }
          }
        } catch (error) {
          platformErrors.push(
            `Failed to sync ${mapping.product_id}: ${error instanceof Error ? error.message : 'Unknown'}`
          );
        }
      }

      platformResults.push({
        platform,
        success: platformErrors.length === 0,
        productsUpdated: updated,
        errors: platformErrors,
      });

      totalUpdated += updated;
      errors.push(...platformErrors);
    }

    return {
      success: errors.length === 0,
      platforms: platformResults,
      totalUpdated,
      errors,
      duration: Date.now() - startTime,
    };
  }

  /**
   * Handle inventory change from a sale or restock
   */
  async handleInventoryChange(
    productId: string,
    quantityChange: number,
    changeType: 'sale' | 'restock' | 'adjustment'
  ): Promise<void> {
    // Get current inventory from primary source
    const { data: product } = await this.supabase
      .from('products')
      .select('inventory_quantity')
      .eq('id', productId)
      .single();

    if (!product) return;

    const newQuantity = product.inventory_quantity + quantityChange;

    // Update primary inventory
    await this.supabase
      .from('products')
      .update({ inventory_quantity: newQuantity })
      .eq('id', productId);

    // Check low stock alert
    if (newQuantity <= this.config.lowStockThreshold && quantityChange < 0) {
      await this.triggerLowStockAlert(productId, newQuantity);
    }

    // Sync to all platforms
    const { data: mappings } = await this.supabase
      .from('product_platform_mappings')
      .select('platform, external_id')
      .eq('product_id', productId);

    if (!mappings) return;

    for (const mapping of mappings) {
      const platform = mapping.platform as MarketplacePlatform;
      const connector = this.connectors.get(platform);

      if (connector && 'updateInventory' in connector) {
        try {
          await (connector as any).updateInventory(mapping.external_id, newQuantity);
          this.updateInventoryCache(productId, platform, newQuantity);
        } catch (error) {
          console.error(`Failed to update inventory on ${platform}:`, error);
        }
      }
    }
  }

  // ============================================================================
  // Order Management
  // ============================================================================

  /**
   * Start periodic order synchronization
   */
  private startOrderSync(): void {
    if (this.orderSyncTimer) {
      clearInterval(this.orderSyncTimer);
    }

    this.orderSyncTimer = setInterval(
      () => this.syncAllOrders(),
      this.config.orderSyncIntervalMs
    );

    // Run initial sync
    this.syncAllOrders();
  }

  /**
   * Fetch and sync orders from all platforms
   */
  async syncAllOrders(): Promise<{ synced: number; errors: string[] }> {
    let synced = 0;
    const errors: string[] = [];

    for (const [platform, connector] of this.connectors.entries()) {
      try {
        if ('listOrders' in connector) {
          const result = await (connector as any).listOrders({ status: 'pending' });

          if (result.success && result.data?.items) {
            for (const order of result.data.items) {
              await this.processIncomingOrder(platform, order);
              synced++;
            }
          }
        }
      } catch (error) {
        errors.push(`${platform}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    return { synced, errors };
  }

  /**
   * Process an incoming order from a marketplace
   */
  private async processIncomingOrder(
    platform: MarketplacePlatform,
    order: any
  ): Promise<void> {
    // Check if order already exists
    const { data: existing } = await this.supabase
      .from('orders')
      .select('id')
      .eq('external_order_id', order.id)
      .eq('platform', platform)
      .single();

    if (existing) {
      // Update existing order status
      await this.supabase
        .from('orders')
        .update({
          status: order.status,
          payment_status: order.paymentStatus,
          fulfillment_status: order.fulfillmentStatus,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existing.id);
    } else {
      // Insert new order
      await this.supabase
        .from('orders')
        .insert({
          external_order_id: order.id,
          platform,
          status: order.status || 'pending',
          order_data: order,
          subtotal: order.subtotal,
          tax: order.tax,
          shipping: order.shipping,
          total: order.total,
          currency: order.currency || 'USD',
          customer_email: order.customer?.email,
          created_at: order.createdAt || new Date().toISOString(),
        });

      // Deduct inventory for sold items
      for (const item of order.items || []) {
        await this.handleInventoryChange(item.productId, -item.quantity, 'sale');
      }
    }
  }

  /**
   * Fulfill an order
   */
  async fulfillOrder(
    orderId: string,
    trackingInfo: {
      carrier: string;
      trackingNumber: string;
      trackingUrl?: string;
    }
  ): Promise<{ success: boolean; error?: string }> {
    // Get order details
    const { data: order } = await this.supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (!order) {
      return { success: false, error: 'Order not found' };
    }

    const platform = order.platform as MarketplacePlatform;
    const connector = this.connectors.get(platform);

    if (!connector || !('fulfillOrder' in connector)) {
      return { success: false, error: 'Platform does not support fulfillment' };
    }

    try {
      await (connector as any).fulfillOrder(order.external_order_id, trackingInfo);

      // Update order status
      await this.supabase
        .from('orders')
        .update({
          fulfillment_status: 'fulfilled',
          tracking_info: trackingInfo,
          fulfilled_at: new Date().toISOString(),
        })
        .eq('id', orderId);

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  // ============================================================================
  // Pricing
  // ============================================================================

  /**
   * Apply pricing strategy to a product
   */
  private applyPricingStrategy(
    product: ProductInput,
    strategy: PricingStrategy
  ): ProductInput {
    let finalPrice: number;

    switch (strategy.type) {
      case 'fixed':
        finalPrice = strategy.basePrice || product.pricing?.basePrice || 0;
        break;

      case 'margin':
        const cost = product.pricing?.costPerItem || 0;
        const marginMultiplier = 1 + (strategy.marginPercent || 30) / 100;
        finalPrice = cost * marginMultiplier;
        break;

      case 'competitive':
        const basePrice = product.pricing?.basePrice || 0;
        const adjustment = strategy.competitorAdjustment || 0;
        finalPrice = basePrice + adjustment;
        break;

      default:
        finalPrice = product.pricing?.basePrice || 0;
    }

    // Apply min/max constraints
    if (strategy.minPrice && finalPrice < strategy.minPrice) {
      finalPrice = strategy.minPrice;
    }
    if (strategy.maxPrice && finalPrice > strategy.maxPrice) {
      finalPrice = strategy.maxPrice;
    }

    return {
      ...product,
      pricing: {
        ...product.pricing,
        basePrice: Math.round(finalPrice * 100) / 100,
      },
    };
  }

  // ============================================================================
  // Inventory Helpers
  // ============================================================================

  private calculateInventoryAllocation(
    totalStock: number,
    allocation: InventoryAllocation
  ): number {
    switch (allocation.type) {
      case 'dedicated':
        return allocation.quantity || 0;

      case 'percentage':
        const percent = allocation.percentage || 100;
        return Math.floor((totalStock * percent) / 100);

      case 'shared':
      default:
        const reserve = allocation.reserveQuantity || 0;
        return Math.max(0, totalStock - reserve);
    }
  }

  private updateInventoryCache(
    productId: string,
    platform: MarketplacePlatform,
    quantity: number
  ): void {
    if (!this.inventoryCache.has(productId)) {
      this.inventoryCache.set(productId, new Map());
    }
    this.inventoryCache.get(productId)!.set(platform, quantity);
  }

  private getInventoryFromCache(
    productId: string,
    platform: MarketplacePlatform
  ): number {
    return this.inventoryCache.get(productId)?.get(platform) ?? -1;
  }

  private async logInventoryUpdate(update: InventoryUpdate): Promise<void> {
    await this.supabase.from('inventory_log').insert({
      product_id: update.productId,
      platform: update.platform,
      external_id: update.externalId,
      quantity: update.quantity,
      previous_quantity: update.previousQuantity,
      update_type: update.updateType,
      created_at: update.timestamp.toISOString(),
    });
  }

  private async triggerLowStockAlert(
    productId: string,
    currentStock: number
  ): Promise<void> {
    const severity = currentStock === 0 ? 'critical' : 'warning';
    const eventType: WebhookEventType = currentStock === 0 ? 'out_of_stock' : 'low_stock_alert';

    // Log alert
    await this.supabase.from('alerts').insert({
      type: 'low_stock',
      severity,
      message: `Low stock alert: Product ${productId} has ${currentStock} units remaining`,
      metadata: { productId, currentStock, threshold: this.config.lowStockThreshold },
      created_at: new Date().toISOString(),
    });

    // Get product details for notification
    const { data: product } = await this.supabase
      .from('products')
      .select('title, sku')
      .eq('id', productId)
      .single();

    // Send webhook notification
    await this.notificationService.notify(eventType, {
      productId,
      productTitle: product?.title || 'Unknown Product',
      sku: product?.sku,
      currentStock,
      threshold: this.config.lowStockThreshold,
      severity,
      recommendedAction: currentStock === 0
        ? 'Immediately restock or pause listings'
        : 'Consider restocking soon',
    });
  }

  // ============================================================================
  // Database Operations
  // ============================================================================

  private async storeProductMappings(
    productId: string,
    results: MarketplacePublishResult[]
  ): Promise<void> {
    const mappings = results
      .filter(r => r.success && r.externalId)
      .map(r => ({
        product_id: productId,
        platform: r.platform,
        external_id: r.externalId,
        external_url: r.externalUrl,
        publish_status: r.status,
        last_sync_at: new Date().toISOString(),
      }));

    if (mappings.length > 0) {
      await this.supabase
        .from('product_platform_mappings')
        .upsert(mappings, { onConflict: 'product_id,platform' });
    }
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  /**
   * Get aggregated analytics across all marketplaces
   */
  async getMarketplaceAnalytics(dateRange: DateRange): Promise<MarketplaceAnalytics> {
    const platformMetrics: Record<MarketplacePlatform, PlatformMetrics> = {} as any;
    const ordersByStatus: Record<OrderStatus, number> = {} as any;
    let totalRevenue = 0;
    let totalOrders = 0;
    let totalProducts = 0;

    // Get return rates for each platform
    const returnRates = await this.calculateReturnRates(dateRange);

    // Gather analytics from each platform
    for (const [platform, connector] of this.connectors.entries()) {
      try {
        const result = await connector.getAnalytics(dateRange);

        if (result.success && result.data) {
          totalRevenue += result.data.revenue;
          totalOrders += result.data.orders;

          platformMetrics[platform] = {
            revenue: result.data.revenue,
            orders: result.data.orders,
            products: result.data.topProducts.length,
            avgOrderValue: result.data.orders > 0 ? result.data.revenue / result.data.orders : 0,
            conversionRate: result.data.conversion,
            returnRate: returnRates[platform] || 0,
          };

          totalProducts += result.data.topProducts.length;
        }
      } catch (error) {
        console.error(`Failed to get analytics for ${platform}:`, error);
      }
    }

    // Get order breakdown from database
    const { data: orders } = await this.supabase
      .from('orders')
      .select('status, total, created_at, platform')
      .gte('created_at', dateRange.start.toISOString())
      .lte('created_at', dateRange.end.toISOString());

    if (orders) {
      for (const order of orders) {
        ordersByStatus[order.status as OrderStatus] =
          (ordersByStatus[order.status as OrderStatus] || 0) + 1;
      }
    }

    // Calculate daily revenue
    const revenueByDay = await this.calculateDailyRevenue(dateRange, orders || []);

    return {
      dateRange,
      totalRevenue,
      totalOrders,
      totalProducts,
      byPlatform: platformMetrics,
      ordersByStatus,
      revenueByDay,
    };
  }

  /**
   * Calculate return rates for each platform
   */
  private async calculateReturnRates(
    dateRange: DateRange
  ): Promise<Record<MarketplacePlatform, number>> {
    const rates: Record<MarketplacePlatform, number> = {} as any;

    // Get orders and returns for the date range
    const { data: orders } = await this.supabase
      .from('orders')
      .select('platform, status')
      .gte('created_at', dateRange.start.toISOString())
      .lte('created_at', dateRange.end.toISOString());

    if (!orders || orders.length === 0) {
      return rates;
    }

    // Group by platform
    const platformStats: Record<string, { total: number; returned: number }> = {};

    for (const order of orders) {
      const platform = order.platform as MarketplacePlatform;
      if (!platformStats[platform]) {
        platformStats[platform] = { total: 0, returned: 0 };
      }

      platformStats[platform].total++;

      // Count refunded orders as returns
      if (order.status === 'refunded' || order.status === 'cancelled') {
        platformStats[platform].returned++;
      }
    }

    // Calculate rates
    for (const [platform, stats] of Object.entries(platformStats)) {
      rates[platform as MarketplacePlatform] =
        stats.total > 0 ? Math.round((stats.returned / stats.total) * 10000) / 100 : 0;
    }

    return rates;
  }

  /**
   * Calculate daily revenue aggregation
   */
  private async calculateDailyRevenue(
    dateRange: DateRange,
    orders: Array<{ total: number; created_at: string; platform: string }>
  ): Promise<DailyRevenue[]> {
    // Create a map for all days in the range
    const dailyMap: Map<string, { revenue: number; orders: number }> = new Map();

    // Initialize all days in range with zero values
    const currentDate = new Date(dateRange.start);
    const endDate = new Date(dateRange.end);

    while (currentDate <= endDate) {
      const dateKey = currentDate.toISOString().split('T')[0];
      dailyMap.set(dateKey, { revenue: 0, orders: 0 });
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Aggregate orders by day
    for (const order of orders) {
      const dateKey = new Date(order.created_at).toISOString().split('T')[0];
      const existing = dailyMap.get(dateKey);

      if (existing) {
        existing.revenue += order.total || 0;
        existing.orders += 1;
      }
    }

    // Convert to array and sort by date
    const result: DailyRevenue[] = [];
    for (const [date, data] of dailyMap.entries()) {
      result.push({
        date,
        revenue: Math.round(data.revenue * 100) / 100,
        orders: data.orders,
      });
    }

    return result.sort((a, b) => a.date.localeCompare(b.date));
  }

  // ============================================================================
  // Cleanup
  // ============================================================================

  /**
   * Stop sync timers, notification service, and disconnect connectors
   */
  async shutdown(): Promise<void> {
    // Stop sync timers
    if (this.inventorySyncTimer) {
      clearInterval(this.inventorySyncTimer);
      this.inventorySyncTimer = null;
    }

    if (this.orderSyncTimer) {
      clearInterval(this.orderSyncTimer);
      this.orderSyncTimer = null;
    }

    // Stop notification service
    this.notificationService.stop();

    // Disconnect all platform connectors
    for (const [platform, connector] of this.connectors.entries()) {
      try {
        if ('disconnect' in connector && typeof connector.disconnect === 'function') {
          await connector.disconnect();
        }
      } catch (error) {
        console.error(`Error disconnecting ${platform}:`, error);
      }
    }

    this.connectors.clear();
    this.inventoryCache.clear();
  }
}

export default MarketplaceWorkflow;
