/**
 * WooCommerce Adapter
 * WordPress ecommerce platform connector
 *
 * API Docs: https://woocommerce.github.io/woocommerce-rest-api-docs/
 * Auth: Consumer Key + Consumer Secret (OAuth 1.0a style)
 * Rate Limit: Depends on hosting (typically 60-120 requests/minute)
 */

import { BaseConnector, ConnectorConfig } from '../core/base-connector';
import {
  ConnectorCapabilities,
  ConnectorResult,
  AuthToken,
  NormalizedProduct,
  ProductInput,
  CreateResult,
  UpdateResult,
  DeleteResult,
  ListOptions,
  PaginatedProducts,
  PaginatedOrders,
  Order,
  TrackingInfo,
  Fulfillment,
  PlatformLimits,
  PlatformRequirements,
  ValidationResult,
  ValidationIssue,
  ProductType,
  OrderStatus,
  DateRange,
  PlatformAnalytics,
} from '../core/types';
import { mapPlatformError } from '../utils/error-mapper';

// WooCommerce-specific types
interface WooProduct {
  id: number;
  name: string;
  slug: string;
  permalink: string;
  date_created: string;
  date_created_gmt: string;
  date_modified: string;
  date_modified_gmt: string;
  type: 'simple' | 'grouped' | 'external' | 'variable';
  status: 'draft' | 'pending' | 'private' | 'publish';
  featured: boolean;
  catalog_visibility: 'visible' | 'catalog' | 'search' | 'hidden';
  description: string;
  short_description: string;
  sku: string;
  price: string;
  regular_price: string;
  sale_price: string;
  date_on_sale_from: string | null;
  date_on_sale_to: string | null;
  price_html: string;
  on_sale: boolean;
  purchasable: boolean;
  total_sales: number;
  virtual: boolean;
  downloadable: boolean;
  downloads: WooDownload[];
  download_limit: number;
  download_expiry: number;
  external_url: string;
  button_text: string;
  tax_status: 'taxable' | 'shipping' | 'none';
  tax_class: string;
  manage_stock: boolean;
  stock_quantity: number | null;
  stock_status: 'instock' | 'outofstock' | 'onbackorder';
  backorders: 'no' | 'notify' | 'yes';
  backorders_allowed: boolean;
  backordered: boolean;
  sold_individually: boolean;
  weight: string;
  dimensions: { length: string; width: string; height: string };
  shipping_required: boolean;
  shipping_taxable: boolean;
  shipping_class: string;
  shipping_class_id: number;
  reviews_allowed: boolean;
  average_rating: string;
  rating_count: number;
  related_ids: number[];
  upsell_ids: number[];
  cross_sell_ids: number[];
  parent_id: number;
  purchase_note: string;
  categories: WooCategory[];
  tags: WooTag[];
  images: WooImage[];
  attributes: WooAttribute[];
  default_attributes: WooDefaultAttribute[];
  variations: number[];
  grouped_products: number[];
  menu_order: number;
  meta_data: WooMeta[];
}

interface WooDownload {
  id: string;
  name: string;
  file: string;
}

interface WooCategory {
  id: number;
  name: string;
  slug: string;
}

interface WooTag {
  id: number;
  name: string;
  slug: string;
}

interface WooImage {
  id: number;
  date_created: string;
  date_created_gmt: string;
  date_modified: string;
  date_modified_gmt: string;
  src: string;
  name: string;
  alt: string;
}

interface WooAttribute {
  id: number;
  name: string;
  position: number;
  visible: boolean;
  variation: boolean;
  options: string[];
}

interface WooDefaultAttribute {
  id: number;
  name: string;
  option: string;
}

interface WooMeta {
  id: number;
  key: string;
  value: string;
}

interface WooOrder {
  id: number;
  parent_id: number;
  number: string;
  order_key: string;
  created_via: string;
  version: string;
  status: string;
  currency: string;
  date_created: string;
  date_created_gmt: string;
  date_modified: string;
  date_modified_gmt: string;
  discount_total: string;
  discount_tax: string;
  shipping_total: string;
  shipping_tax: string;
  cart_tax: string;
  total: string;
  total_tax: string;
  prices_include_tax: boolean;
  customer_id: number;
  customer_ip_address: string;
  customer_user_agent: string;
  customer_note: string;
  billing: WooAddress;
  shipping: WooAddress;
  payment_method: string;
  payment_method_title: string;
  transaction_id: string;
  date_paid: string | null;
  date_paid_gmt: string | null;
  date_completed: string | null;
  date_completed_gmt: string | null;
  cart_hash: string;
  meta_data: WooMeta[];
  line_items: WooLineItem[];
  tax_lines: WooTaxLine[];
  shipping_lines: WooShippingLine[];
  fee_lines: WooFeeLine[];
  coupon_lines: WooCouponLine[];
  refunds: WooRefund[];
}

interface WooAddress {
  first_name: string;
  last_name: string;
  company: string;
  address_1: string;
  address_2: string;
  city: string;
  state: string;
  postcode: string;
  country: string;
  email?: string;
  phone?: string;
}

interface WooLineItem {
  id: number;
  name: string;
  product_id: number;
  variation_id: number;
  quantity: number;
  tax_class: string;
  subtotal: string;
  subtotal_tax: string;
  total: string;
  total_tax: string;
  taxes: { id: number; total: string; subtotal: string }[];
  meta_data: WooMeta[];
  sku: string;
  price: number;
}

interface WooTaxLine {
  id: number;
  rate_code: string;
  rate_id: number;
  label: string;
  compound: boolean;
  tax_total: string;
  shipping_tax_total: string;
  meta_data: WooMeta[];
}

interface WooShippingLine {
  id: number;
  method_title: string;
  method_id: string;
  total: string;
  total_tax: string;
  taxes: { id: number; total: string }[];
  meta_data: WooMeta[];
}

interface WooFeeLine {
  id: number;
  name: string;
  tax_class: string;
  tax_status: string;
  total: string;
  total_tax: string;
  taxes: { id: number; total: string; subtotal: string }[];
  meta_data: WooMeta[];
}

interface WooCouponLine {
  id: number;
  code: string;
  discount: string;
  discount_tax: string;
  meta_data: WooMeta[];
}

interface WooRefund {
  id: number;
  reason: string;
  total: string;
}

/**
 * WooCommerce platform adapter
 */
export class WooCommerceAdapter extends BaseConnector {
  readonly name = 'woocommerce';
  readonly displayName = 'WooCommerce';
  readonly workflowGroup = 'marketplace' as const;
  readonly connectorType = 'api_key' as const;

  readonly capabilities: ConnectorCapabilities = {
    supportsOAuth: false,
    supportsBulkOperations: true,
    supportsWebhooks: true,
    supportsInventorySync: true,
    supportsOrderFulfillment: true,
    supportsAnalytics: true,
    maxProductsPerRequest: 100,
    rateLimits: {
      requestsPerMinute: 60, // Conservative default
    },
  };

  readonly platformLimits: PlatformLimits = {
    maxTitleLength: 255,
    maxDescriptionLength: 65535,
    maxImages: 100,
    maxTags: 500,
    maxVariants: 100,
    allowedImageFormats: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    maxImageSizeMB: 32,
  };

  readonly platformRequirements: PlatformRequirements = {
    requiredFields: ['name'],
    requiredCategories: false,
    requiredShippingProfile: false,
  };

  private siteUrl: string = '';

  constructor(config: ConnectorConfig & { siteUrl?: string }) {
    super(config);
    this.siteUrl = config.siteUrl || config.credentials?.siteUrl || '';
  }

  private get baseApiUrl(): string {
    return `${this.siteUrl}/wp-json/wc/v3`;
  }

  // ============================================================================
  // Authentication
  // ============================================================================

  async authenticate(): Promise<ConnectorResult<AuthToken>> {
    const consumerKey = this.config.credentials?.consumerKey;
    const consumerSecret = this.config.credentials?.consumerSecret;

    if (!consumerKey || !consumerSecret) {
      return {
        success: false,
        error: this.createError(
          'AUTH_MISSING',
          'WooCommerce consumer key and secret are required'
        ),
      };
    }

    this.authToken = {
      accessToken: Buffer.from(`${consumerKey}:${consumerSecret}`).toString('base64'),
      tokenType: 'Basic',
    };

    // Validate by fetching system status
    const result = await this.request<{ environment: { version: string } }>({
      method: 'GET',
      path: '/system_status',
    });

    if (!result.success) {
      this.authToken = null;
      return { success: false, error: result.error };
    }

    return { success: true, data: this.authToken };
  }

  async refreshAuth(): Promise<ConnectorResult<AuthToken>> {
    // Consumer keys don't expire
    if (this.authToken) {
      return { success: true, data: this.authToken };
    }
    return this.authenticate();
  }

  async validateCredentials(): Promise<boolean> {
    const result = await this.request<unknown>({
      method: 'GET',
      path: '/system_status',
    });
    return result.success;
  }

  // Override request to use correct base URL
  protected override async executeRequest<T>(
    options: import('../core/base-connector').RequestOptions
  ): Promise<ConnectorResult<T>> {
    const url = `${this.baseApiUrl}${options.path}`;
    const headers = this.buildHeaders(options.headers);

    const fetchOptions: RequestInit = {
      method: options.method,
      headers,
    };

    if (options.body) {
      fetchOptions.body = JSON.stringify(options.body);
    }

    try {
      const response = await fetch(url, fetchOptions);
      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: this.mapPlatformError(response.status, data),
        };
      }

      return { success: true, data: data as T };
    } catch (error) {
      return { success: false, error: this.mapError(error) };
    }
  }

  // ============================================================================
  // Product Operations
  // ============================================================================

  async listProducts(options?: ListOptions): Promise<ConnectorResult<PaginatedProducts>> {
    const page = options?.page || 1;
    const limit = options?.limit || 20;

    const result = await this.request<WooProduct[]>({
      method: 'GET',
      path: '/products',
      query: { page, per_page: limit },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedProducts>;
    }

    return {
      success: true,
      data: {
        items: result.data!.map((p) => this.normalizeProduct(p)),
        total: result.data!.length, // WooCommerce returns total in headers
        page,
        limit,
        hasMore: result.data!.length === limit,
      },
    };
  }

  async getProduct(id: string): Promise<ConnectorResult<NormalizedProduct>> {
    const result = await this.request<WooProduct>({
      method: 'GET',
      path: `/products/${id}`,
    });

    if (!result.success) {
      return result as ConnectorResult<NormalizedProduct>;
    }

    return { success: true, data: this.normalizeProduct(result.data!) };
  }

  async createProduct(product: ProductInput): Promise<ConnectorResult<CreateResult>> {
    const validation = this.validateProductForPlatform(product);
    if (!validation.valid) {
      return {
        success: false,
        error: this.createError(
          'VALIDATION_ERROR',
          validation.issues.map((i) => i.message).join('; ')
        ),
      };
    }

    const wooProduct = this.denormalizeProduct({
      ...product,
      id: '',
      status: 'draft',
      createdAt: new Date(),
      updatedAt: new Date(),
      platformData: {},
      metadata: product.metadata || {},
      tags: product.tags || [],
      images: product.images.map((img, idx) => ({ ...img, id: `img-${idx}` })),
      variants: product.variants?.map((v, idx) => ({ ...v, id: `var-${idx}` })) || [],
      pricing: { ...product.pricing, currency: product.pricing.currency || 'USD' },
    } as NormalizedProduct);

    const result = await this.request<WooProduct>({
      method: 'POST',
      path: '/products',
      body: wooProduct,
    });

    if (!result.success) {
      return result as ConnectorResult<CreateResult>;
    }

    return {
      success: true,
      data: {
        id: String(result.data!.id),
        externalId: String(result.data!.id),
        externalUrl: result.data!.permalink,
        status: result.data!.status === 'publish' ? 'active' : 'draft',
      },
    };
  }

  async updateProduct(
    id: string,
    updates: Partial<ProductInput>
  ): Promise<ConnectorResult<UpdateResult>> {
    const updatePayload: Record<string, unknown> = {};
    const updatedFields: string[] = [];

    if (updates.title) {
      updatePayload.name = updates.title;
      updatedFields.push('name');
    }
    if (updates.description) {
      updatePayload.description = updates.description;
      updatedFields.push('description');
    }
    if (updates.tags) {
      updatePayload.tags = updates.tags.map((t) => ({ name: t }));
      updatedFields.push('tags');
    }
    if (updates.pricing?.price) {
      updatePayload.regular_price = String(updates.pricing.price);
      updatedFields.push('regular_price');
    }

    const result = await this.request<WooProduct>({
      method: 'PUT',
      path: `/products/${id}`,
      body: updatePayload,
    });

    if (!result.success) {
      return result as ConnectorResult<UpdateResult>;
    }

    return { success: true, data: { id, externalId: id, updatedFields } };
  }

  async deleteProduct(id: string): Promise<ConnectorResult<DeleteResult>> {
    const result = await this.request<WooProduct>({
      method: 'DELETE',
      path: `/products/${id}`,
      query: { force: true },
    });

    return {
      success: result.success,
      data: { id, deleted: result.success },
      error: result.error,
    };
  }

  // ============================================================================
  // Categories
  // ============================================================================

  async getCategories(): Promise<ConnectorResult<WooCategory[]>> {
    return this.request<WooCategory[]>({
      method: 'GET',
      path: '/products/categories',
      query: { per_page: 100 },
    });
  }

  // ============================================================================
  // Inventory
  // ============================================================================

  async updateStock(productId: string, quantity: number): Promise<ConnectorResult<void>> {
    const result = await this.request<WooProduct>({
      method: 'PUT',
      path: `/products/${productId}`,
      body: {
        manage_stock: true,
        stock_quantity: quantity,
      },
    });

    return { success: result.success, error: result.error };
  }

  // ============================================================================
  // Orders
  // ============================================================================

  async listOrders(options?: ListOptions): Promise<ConnectorResult<PaginatedOrders>> {
    const page = options?.page || 1;
    const limit = options?.limit || 20;

    const result = await this.request<WooOrder[]>({
      method: 'GET',
      path: '/orders',
      query: { page, per_page: limit },
    });

    if (!result.success) {
      return result as ConnectorResult<PaginatedOrders>;
    }

    return {
      success: true,
      data: {
        items: result.data!.map((o) => this.normalizeOrder(o)),
        total: result.data!.length,
        page,
        limit,
        hasMore: result.data!.length === limit,
      },
    };
  }

  async getOrder(orderId: string): Promise<ConnectorResult<Order>> {
    const result = await this.request<WooOrder>({
      method: 'GET',
      path: `/orders/${orderId}`,
    });

    if (!result.success) {
      return result as ConnectorResult<Order>;
    }

    return { success: true, data: this.normalizeOrder(result.data!) };
  }

  async fulfillOrder(
    orderId: string,
    tracking: TrackingInfo
  ): Promise<ConnectorResult<Fulfillment>> {
    // WooCommerce uses order notes for tracking
    const noteResult = await this.request<{ id: number }>({
      method: 'POST',
      path: `/orders/${orderId}/notes`,
      body: {
        note: `Shipped via ${tracking.carrier}. Tracking: ${tracking.trackingNumber}. ${tracking.trackingUrl || ''}`,
        customer_note: true,
      },
    });

    if (!noteResult.success) {
      return noteResult as ConnectorResult<Fulfillment>;
    }

    // Update order status to completed
    const updateResult = await this.request<WooOrder>({
      method: 'PUT',
      path: `/orders/${orderId}`,
      body: { status: 'completed' },
    });

    if (!updateResult.success) {
      return updateResult as ConnectorResult<Fulfillment>;
    }

    const order = updateResult.data!;
    return {
      success: true,
      data: {
        id: String(noteResult.data!.id),
        orderId,
        tracking,
        items: order.line_items.map((li) => ({
          id: String(li.id),
          productId: String(li.product_id),
          variantId: li.variation_id ? String(li.variation_id) : undefined,
          title: li.name,
          quantity: li.quantity,
          price: li.price,
          sku: li.sku,
        })),
        fulfilledAt: new Date(),
      },
    };
  }

  // ============================================================================
  // Analytics
  // ============================================================================

  async getAnalytics(dateRange: DateRange): Promise<ConnectorResult<PlatformAnalytics>> {
    const ordersResult = await this.request<WooOrder[]>({
      method: 'GET',
      path: '/orders',
      query: {
        after: dateRange.start.toISOString(),
        before: dateRange.end.toISOString(),
        per_page: 100,
      },
    });

    if (!ordersResult.success) {
      return ordersResult as ConnectorResult<PlatformAnalytics>;
    }

    const orders = ordersResult.data!;
    const totalRevenue = orders.reduce((sum, o) => sum + parseFloat(o.total), 0);

    const byDay = new Map<string, number>();
    orders.forEach((o) => {
      const date = new Date(o.date_created).toISOString().split('T')[0];
      byDay.set(date, (byDay.get(date) || 0) + parseFloat(o.total));
    });

    const byProduct = new Map<string, { title: string; sales: number; revenue: number }>();
    orders.forEach((o) => {
      o.line_items.forEach((li) => {
        const key = String(li.product_id);
        const existing = byProduct.get(key) || { title: li.name, sales: 0, revenue: 0 };
        existing.sales += li.quantity;
        existing.revenue += parseFloat(li.total);
        byProduct.set(key, existing);
      });
    });

    return {
      success: true,
      data: {
        platform: 'woocommerce',
        dateRange,
        revenue: {
          total: totalRevenue,
          currency: orders[0]?.currency || 'USD',
          byDay: Array.from(byDay.entries()).map(([date, amount]) => ({ date, amount })),
          byProduct: Array.from(byProduct.entries()).map(([productId, data]) => ({
            productId,
            title: data.title,
            amount: data.revenue,
          })),
        },
        orderCount: orders.length,
        productCount: byProduct.size,
        topProducts: Array.from(byProduct.entries())
          .map(([id, data]) => ({ id, ...data }))
          .sort((a, b) => b.revenue - a.revenue)
          .slice(0, 10),
      },
    };
  }

  // ============================================================================
  // Normalization
  // ============================================================================

  normalizeProduct(platformProduct: unknown): NormalizedProduct {
    const p = platformProduct as WooProduct;

    return {
      id: String(p.id),
      externalId: String(p.id),
      title: p.name,
      description: p.description,
      productType: this.mapWooProductType(p.type, p.virtual, p.downloadable),
      images: p.images.map((img, idx) => ({
        id: String(img.id),
        url: img.src,
        alt: img.alt || undefined,
        position: idx,
        isPrimary: idx === 0,
      })),
      variants: [
        {
          id: String(p.id),
          sku: p.sku,
          title: 'Default',
          price: parseFloat(p.price) || 0,
          compareAtPrice: p.regular_price !== p.price ? parseFloat(p.regular_price) : undefined,
          inventoryQuantity: p.stock_quantity || 0,
          options: {},
          weight: parseFloat(p.weight) || undefined,
        },
      ],
      pricing: {
        price: parseFloat(p.price) || 0,
        compareAtPrice: p.sale_price ? parseFloat(p.regular_price) : undefined,
        currency: 'USD',
        taxable: p.tax_status === 'taxable',
      },
      tags: p.tags.map((t) => t.name),
      metadata: {
        categories: p.categories,
        sku: p.sku,
        slug: p.slug,
      },
      platformData: {
        type: p.type,
        permalink: p.permalink,
        total_sales: p.total_sales,
        average_rating: p.average_rating,
        rating_count: p.rating_count,
      },
      status: p.status === 'publish' ? 'active' : 'draft',
      createdAt: new Date(p.date_created),
      updatedAt: new Date(p.date_modified),
    };
  }

  private normalizeOrder(order: WooOrder): Order {
    return {
      id: String(order.id),
      externalId: order.number,
      status: this.mapWooOrderStatus(order.status),
      items: order.line_items.map((li) => ({
        id: String(li.id),
        productId: String(li.product_id),
        variantId: li.variation_id ? String(li.variation_id) : undefined,
        title: li.name,
        quantity: li.quantity,
        price: li.price,
        sku: li.sku,
      })),
      shippingAddress: {
        name: `${order.shipping.first_name} ${order.shipping.last_name}`,
        address1: order.shipping.address_1,
        address2: order.shipping.address_2 || undefined,
        city: order.shipping.city,
        state: order.shipping.state || undefined,
        postalCode: order.shipping.postcode,
        country: order.shipping.country,
        phone: order.shipping.phone || undefined,
      },
      subtotal: parseFloat(order.total) - parseFloat(order.shipping_total) - parseFloat(order.total_tax),
      shippingCost: parseFloat(order.shipping_total),
      tax: parseFloat(order.total_tax),
      total: parseFloat(order.total),
      currency: order.currency,
      createdAt: new Date(order.date_created),
      updatedAt: new Date(order.date_modified),
    };
  }

  denormalizeProduct(product: NormalizedProduct): unknown {
    return {
      name: product.title,
      description: product.description,
      short_description: product.description.slice(0, 200),
      regular_price: String(product.pricing.price),
      sale_price: product.pricing.compareAtPrice
        ? String(product.pricing.price)
        : undefined,
      sku: product.variants[0]?.sku,
      manage_stock: true,
      stock_quantity: product.variants[0]?.inventoryQuantity || 0,
      status: product.status === 'active' ? 'publish' : 'draft',
      tags: product.tags?.map((t) => ({ name: t })) || [],
      images: product.images.map((img) => ({
        src: img.url,
        alt: img.alt,
      })),
    };
  }

  validateProductForPlatform(product: ProductInput): ValidationResult {
    const issues: ValidationIssue[] = [];

    if (!product.title) {
      issues.push(this.createValidationIssue('title', 'Name is required', 'error'));
    } else if (product.title.length > this.platformLimits.maxTitleLength) {
      issues.push(
        this.createValidationIssue(
          'title',
          `Name exceeds ${this.platformLimits.maxTitleLength} characters`,
          'error'
        )
      );
    }

    if (product.pricing?.price && product.pricing.price < 0) {
      issues.push(
        this.createValidationIssue('pricing.price', 'Price cannot be negative', 'error')
      );
    }

    return {
      valid: issues.filter((i) => i.severity === 'error').length === 0,
      issues,
    };
  }

  private mapWooProductType(
    type: WooProduct['type'],
    virtual: boolean,
    downloadable: boolean
  ): ProductType {
    if (downloadable) return 'digital-download';
    if (virtual) return 'digital-download';
    return 'other';
  }

  private mapWooOrderStatus(status: string): OrderStatus {
    const mapping: Record<string, OrderStatus> = {
      pending: 'pending',
      processing: 'processing',
      'on-hold': 'pending',
      completed: 'delivered',
      cancelled: 'cancelled',
      refunded: 'refunded',
      failed: 'cancelled',
    };
    return mapping[status] || 'pending';
  }

  protected override mapPlatformError(status: number, data: unknown) {
    return mapPlatformError('woocommerce', status, data);
  }
}

export default WooCommerceAdapter;
