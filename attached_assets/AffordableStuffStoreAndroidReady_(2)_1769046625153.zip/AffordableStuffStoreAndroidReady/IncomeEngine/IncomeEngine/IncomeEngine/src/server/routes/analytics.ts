/**
 * ============================================================================
 * ANALYTICS API ROUTES
 * Revenue, platform, product, and trend analytics endpoints
 * ============================================================================
 */

import { Router, Request, Response } from 'express';

const router = Router();

// =============================================================================
// TYPES
// =============================================================================

interface DateRange {
  start: Date;
  end: Date;
}

interface RevenueDataPoint {
  date: string;
  revenue: number;
  orders: number;
  profit: number;
}

interface PlatformStats {
  platform: string;
  revenue: number;
  orders: number;
  products: number;
  avgOrderValue: number;
  growth: number; // percentage
}

interface ProductPerformance {
  id: string;
  title: string;
  platform: string;
  revenue: number;
  unitsSold: number;
  views: number;
  conversionRate: number;
  trend: 'up' | 'down' | 'stable';
}

interface TrendData {
  metric: string;
  current: number;
  previous: number;
  change: number;
  changePercent: number;
  trend: 'up' | 'down' | 'stable';
}

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function parseDateRange(req: Request): DateRange {
  const now = new Date();
  const defaultStart = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  return {
    start: req.query.start ? new Date(req.query.start as string) : defaultStart,
    end: req.query.end ? new Date(req.query.end as string) : now,
  };
}

function generateDateLabels(start: Date, end: Date, granularity: 'day' | 'week' | 'month' = 'day'): string[] {
  const labels: string[] = [];
  const current = new Date(start);

  while (current <= end) {
    if (granularity === 'day') {
      labels.push(current.toISOString().split('T')[0]);
      current.setDate(current.getDate() + 1);
    } else if (granularity === 'week') {
      labels.push(`Week ${Math.ceil(current.getDate() / 7)} - ${current.toLocaleDateString('en-US', { month: 'short' })}`);
      current.setDate(current.getDate() + 7);
    } else {
      labels.push(current.toLocaleDateString('en-US', { month: 'short', year: '2-digit' }));
      current.setMonth(current.getMonth() + 1);
    }
  }

  return labels;
}

function calculateTrend(current: number, previous: number): 'up' | 'down' | 'stable' {
  const change = ((current - previous) / (previous || 1)) * 100;
  if (change > 5) return 'up';
  if (change < -5) return 'down';
  return 'stable';
}

// =============================================================================
// MOCK DATA GENERATORS (Replace with Supabase queries in production)
// =============================================================================

function generateMockRevenueData(dateRange: DateRange): RevenueDataPoint[] {
  const labels = generateDateLabels(dateRange.start, dateRange.end);
  const baseRevenue = 150;
  const variance = 100;

  return labels.map((date, index) => {
    // Add some realistic patterns (weekends lower, gradual growth)
    const dayOfWeek = new Date(date).getDay();
    const weekendFactor = (dayOfWeek === 0 || dayOfWeek === 6) ? 0.7 : 1;
    const growthFactor = 1 + (index * 0.01);
    const randomFactor = 0.8 + Math.random() * 0.4;

    const revenue = Math.round(baseRevenue * weekendFactor * growthFactor * randomFactor * 100) / 100;
    const orders = Math.floor(revenue / 25);
    const profit = Math.round(revenue * 0.35 * 100) / 100;

    return { date, revenue, orders, profit };
  });
}

function generateMockPlatformStats(): PlatformStats[] {
  const platforms = [
    { name: 'Printify', baseRevenue: 2500, baseOrders: 120, baseProducts: 45 },
    { name: 'Etsy', baseRevenue: 1800, baseOrders: 95, baseProducts: 38 },
    { name: 'Gumroad', baseRevenue: 950, baseOrders: 42, baseProducts: 15 },
    { name: 'TeePublic', baseRevenue: 680, baseOrders: 35, baseProducts: 28 },
    { name: 'Redbubble', baseRevenue: 520, baseOrders: 28, baseProducts: 32 },
    { name: 'Creative Fabrica', baseRevenue: 380, baseOrders: 18, baseProducts: 12 },
    { name: 'Society6', baseRevenue: 290, baseOrders: 14, baseProducts: 22 },
    { name: 'Amazon KDP', baseRevenue: 420, baseOrders: 25, baseProducts: 8 },
  ];

  return platforms.map(p => ({
    platform: p.name,
    revenue: Math.round(p.baseRevenue * (0.9 + Math.random() * 0.2) * 100) / 100,
    orders: Math.floor(p.baseOrders * (0.9 + Math.random() * 0.2)),
    products: p.baseProducts,
    avgOrderValue: Math.round((p.baseRevenue / p.baseOrders) * 100) / 100,
    growth: Math.round((Math.random() * 40 - 10) * 10) / 10,
  }));
}

function generateMockProductPerformance(): ProductPerformance[] {
  const products = [
    { title: 'Motivational Quote T-Shirt', platform: 'Printify' },
    { title: 'Digital Planner 2024', platform: 'Gumroad' },
    { title: 'Vintage Cat Design Mug', platform: 'Etsy' },
    { title: 'Minimalist Wall Art Set', platform: 'Society6' },
    { title: 'Coding Humor Stickers', platform: 'Redbubble' },
    { title: 'Productivity Notion Template', platform: 'Gumroad' },
    { title: 'Pet Portrait Phone Case', platform: 'Printify' },
    { title: 'Workout Tracker Spreadsheet', platform: 'Gumroad' },
    { title: 'Nature Photography Prints', platform: 'TeePublic' },
    { title: 'SVG Font Bundle', platform: 'Creative Fabrica' },
  ];

  return products.map((p, index) => {
    const revenue = Math.round((500 - index * 40 + Math.random() * 100) * 100) / 100;
    const unitsSold = Math.floor(revenue / (15 + Math.random() * 10));
    const views = unitsSold * (50 + Math.floor(Math.random() * 100));

    return {
      id: `prod_${index + 1}`,
      title: p.title,
      platform: p.platform,
      revenue,
      unitsSold,
      views,
      conversionRate: Math.round((unitsSold / views) * 10000) / 100,
      trend: ['up', 'down', 'stable'][Math.floor(Math.random() * 3)] as 'up' | 'down' | 'stable',
    };
  }).sort((a, b) => b.revenue - a.revenue);
}

function generateMockTrendData(): TrendData[] {
  const metrics = [
    { metric: 'Total Revenue', current: 7540, previous: 6890 },
    { metric: 'Total Orders', current: 377, previous: 342 },
    { metric: 'Average Order Value', current: 20.0, previous: 20.15 },
    { metric: 'Conversion Rate', current: 3.2, previous: 2.9 },
    { metric: 'Active Products', current: 200, previous: 185 },
    { metric: 'New Customers', current: 156, previous: 142 },
  ];

  return metrics.map(m => {
    const change = m.current - m.previous;
    const changePercent = Math.round((change / (m.previous || 1)) * 10000) / 100;

    return {
      ...m,
      change: Math.round(change * 100) / 100,
      changePercent,
      trend: calculateTrend(m.current, m.previous),
    };
  });
}

// =============================================================================
// ROUTES
// =============================================================================

/**
 * GET /api/analytics/revenue
 * Get revenue data over time
 */
router.get('/revenue', async (req: Request, res: Response) => {
  try {
    const dateRange = parseDateRange(req);
    const granularity = (req.query.granularity as 'day' | 'week' | 'month') || 'day';

    // In production, query Supabase for real revenue data
    // const { data, error } = await supabase
    //   .from('revenue_events')
    //   .select('*')
    //   .gte('created_at', dateRange.start.toISOString())
    //   .lte('created_at', dateRange.end.toISOString())
    //   .order('created_at', { ascending: true });

    const data = generateMockRevenueData(dateRange);

    // Calculate summary statistics
    const totalRevenue = data.reduce((sum, d) => sum + d.revenue, 0);
    const totalOrders = data.reduce((sum, d) => sum + d.orders, 0);
    const totalProfit = data.reduce((sum, d) => sum + d.profit, 0);
    const avgDailyRevenue = totalRevenue / data.length;

    res.json({
      success: true,
      data: {
        timeSeries: data,
        summary: {
          totalRevenue: Math.round(totalRevenue * 100) / 100,
          totalOrders,
          totalProfit: Math.round(totalProfit * 100) / 100,
          avgDailyRevenue: Math.round(avgDailyRevenue * 100) / 100,
          profitMargin: Math.round((totalProfit / totalRevenue) * 10000) / 100,
        },
        dateRange: {
          start: dateRange.start.toISOString(),
          end: dateRange.end.toISOString(),
          granularity,
        },
      },
    });
  } catch (error) {
    console.error('Revenue analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch revenue analytics'
    });
  }
});

/**
 * GET /api/analytics/platforms
 * Get platform-by-platform breakdown
 */
router.get('/platforms', async (req: Request, res: Response) => {
  try {
    const dateRange = parseDateRange(req);

    // In production, aggregate data from platform_revenue table
    const platforms = generateMockPlatformStats();

    // Calculate totals
    const totals = platforms.reduce(
      (acc, p) => ({
        revenue: acc.revenue + p.revenue,
        orders: acc.orders + p.orders,
        products: acc.products + p.products,
      }),
      { revenue: 0, orders: 0, products: 0 }
    );

    res.json({
      success: true,
      data: {
        platforms: platforms.sort((a, b) => b.revenue - a.revenue),
        totals: {
          ...totals,
          revenue: Math.round(totals.revenue * 100) / 100,
          avgOrderValue: Math.round((totals.revenue / totals.orders) * 100) / 100,
        },
        dateRange: {
          start: dateRange.start.toISOString(),
          end: dateRange.end.toISOString(),
        },
      },
    });
  } catch (error) {
    console.error('Platform analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch platform analytics'
    });
  }
});

/**
 * GET /api/analytics/products
 * Get product performance data
 */
router.get('/products', async (req: Request, res: Response) => {
  try {
    const dateRange = parseDateRange(req);
    const sortBy = (req.query.sortBy as string) || 'revenue';
    const sortOrder = (req.query.sortOrder as string) || 'desc';
    const limit = parseInt(req.query.limit as string) || 20;
    const platform = req.query.platform as string;

    let products = generateMockProductPerformance();

    // Filter by platform if specified
    if (platform) {
      products = products.filter(p =>
        p.platform.toLowerCase() === platform.toLowerCase()
      );
    }

    // Sort products
    products.sort((a, b) => {
      const aVal = a[sortBy as keyof ProductPerformance] as number;
      const bVal = b[sortBy as keyof ProductPerformance] as number;
      return sortOrder === 'desc' ? bVal - aVal : aVal - bVal;
    });

    // Apply limit
    products = products.slice(0, limit);

    res.json({
      success: true,
      data: {
        products,
        pagination: {
          total: products.length,
          limit,
          offset: 0,
        },
        dateRange: {
          start: dateRange.start.toISOString(),
          end: dateRange.end.toISOString(),
        },
      },
    });
  } catch (error) {
    console.error('Product analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch product analytics'
    });
  }
});

/**
 * GET /api/analytics/trends
 * Get trend data and KPIs
 */
router.get('/trends', async (req: Request, res: Response) => {
  try {
    const dateRange = parseDateRange(req);
    const compareWith = (req.query.compareWith as string) || 'previous_period';

    const trends = generateMockTrendData();

    res.json({
      success: true,
      data: {
        trends,
        comparison: compareWith,
        dateRange: {
          start: dateRange.start.toISOString(),
          end: dateRange.end.toISOString(),
        },
      },
    });
  } catch (error) {
    console.error('Trends analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch trend analytics'
    });
  }
});

/**
 * GET /api/analytics/summary
 * Get a complete analytics summary for the dashboard
 */
router.get('/summary', async (req: Request, res: Response) => {
  try {
    const dateRange = parseDateRange(req);

    const revenueData = generateMockRevenueData(dateRange);
    const platformStats = generateMockPlatformStats();
    const topProducts = generateMockProductPerformance().slice(0, 5);
    const trends = generateMockTrendData();

    const totalRevenue = revenueData.reduce((sum, d) => sum + d.revenue, 0);
    const totalOrders = revenueData.reduce((sum, d) => sum + d.orders, 0);
    const totalProfit = revenueData.reduce((sum, d) => sum + d.profit, 0);

    res.json({
      success: true,
      data: {
        overview: {
          totalRevenue: Math.round(totalRevenue * 100) / 100,
          totalOrders,
          totalProfit: Math.round(totalProfit * 100) / 100,
          profitMargin: Math.round((totalProfit / totalRevenue) * 10000) / 100,
          avgOrderValue: Math.round((totalRevenue / totalOrders) * 100) / 100,
        },
        revenueTimeSeries: revenueData,
        platformBreakdown: platformStats.slice(0, 5),
        topProducts,
        trends,
        dateRange: {
          start: dateRange.start.toISOString(),
          end: dateRange.end.toISOString(),
        },
      },
    });
  } catch (error) {
    console.error('Summary analytics error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch analytics summary'
    });
  }
});

/**
 * POST /api/analytics/export
 * Export analytics data
 */
router.post('/export', async (req: Request, res: Response) => {
  try {
    const { format, dataTypes, dateRange: reqDateRange } = req.body;

    if (!format || !['csv', 'pdf', 'json'].includes(format)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid export format. Use csv, pdf, or json.'
      });
    }

    const dateRange: DateRange = {
      start: reqDateRange?.start ? new Date(reqDateRange.start) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      end: reqDateRange?.end ? new Date(reqDateRange.end) : new Date(),
    };

    // Gather requested data
    const exportData: Record<string, unknown> = {
      generatedAt: new Date().toISOString(),
      dateRange: {
        start: dateRange.start.toISOString(),
        end: dateRange.end.toISOString(),
      },
    };

    const types = dataTypes || ['revenue', 'platforms', 'products', 'trends'];

    if (types.includes('revenue')) {
      exportData.revenue = generateMockRevenueData(dateRange);
    }
    if (types.includes('platforms')) {
      exportData.platforms = generateMockPlatformStats();
    }
    if (types.includes('products')) {
      exportData.products = generateMockProductPerformance();
    }
    if (types.includes('trends')) {
      exportData.trends = generateMockTrendData();
    }

    // For now, return JSON. In production, use the export services
    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="analytics-export-${Date.now()}.json"`);
      return res.json(exportData);
    }

    // CSV and PDF would use the export services
    res.json({
      success: true,
      message: `Export queued in ${format} format`,
      downloadUrl: `/api/analytics/export/download/${Date.now()}`,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    });
  } catch (error) {
    console.error('Export error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to export analytics'
    });
  }
});

export default router;
