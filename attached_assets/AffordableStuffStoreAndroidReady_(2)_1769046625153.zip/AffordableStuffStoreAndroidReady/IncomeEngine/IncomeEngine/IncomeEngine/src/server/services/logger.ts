/**
 * ============================================================================
 * STRUCTURED LOGGING SERVICE
 * Production-grade Winston-based logging with request tracking
 * ============================================================================
 *
 * Features:
 * - Log levels: error, warn, info, debug
 * - JSON format for production (structured logs)
 * - Pretty format for development (human-readable)
 * - Request ID tracking for distributed tracing
 * - Performance timing utilities
 * - Child loggers with context
 *
 * Usage:
 * ```typescript
 * import { logger, createRequestLogger, timer } from './services/logger';
 *
 * // Basic logging
 * logger.info('Server started', { port: 3000 });
 * logger.error('Database connection failed', { error: err.message });
 *
 * // Request-scoped logging (in middleware)
 * const reqLogger = createRequestLogger(req);
 * reqLogger.info('Processing request', { path: req.path });
 *
 * // Performance timing
 * const stopTimer = timer('database-query');
 * await db.query(...);
 * stopTimer(); // Logs: "database-query completed in 45ms"
 * ```
 */

import winston from 'winston';
import { Request, Response, NextFunction } from 'express';
import { randomUUID } from 'crypto';

// =============================================================================
// TYPES
// =============================================================================

export interface LogContext {
  requestId?: string;
  userId?: string;
  path?: string;
  method?: string;
  duration?: number;
  [key: string]: unknown;
}

export interface RequestWithLogger extends Request {
  requestId: string;
  logger: winston.Logger;
  startTime: number;
}

export type LogLevel = 'error' | 'warn' | 'info' | 'debug';

// =============================================================================
// CONFIGURATION
// =============================================================================

const NODE_ENV = process.env.NODE_ENV || 'development';
const LOG_LEVEL = (process.env.LOG_LEVEL as LogLevel) || (NODE_ENV === 'production' ? 'info' : 'debug');
const isProduction = NODE_ENV === 'production';

// =============================================================================
// FORMATTERS
// =============================================================================

/**
 * Production format: JSON for structured logging (ELK, CloudWatch, etc.)
 */
const productionFormat = winston.format.combine(
  winston.format.timestamp({ format: 'ISO' }),
  winston.format.errors({ stack: true }),
  winston.format.json()
);

/**
 * Development format: Pretty, colorized console output
 */
const developmentFormat = winston.format.combine(
  winston.format.timestamp({ format: 'HH:mm:ss.SSS' }),
  winston.format.errors({ stack: true }),
  winston.format.colorize({ all: true }),
  winston.format.printf((info: winston.Logform.TransformableInfo) => {
    const { level, message, timestamp, requestId, duration, ...meta } = info;
    const reqIdStr = requestId ? `[${String(requestId).slice(0, 8)}]` : '';
    const durationStr = duration !== undefined ? ` (${duration}ms)` : '';
    const metaStr = Object.keys(meta).length > 0 ? ` ${JSON.stringify(meta)}` : '';

    return `${timestamp} ${level} ${reqIdStr}${message}${durationStr}${metaStr}`;
  })
);

// =============================================================================
// LOGGER INSTANCE
// =============================================================================

/**
 * Main logger instance
 * Use this for application-wide logging outside of request context
 */
export const logger = winston.createLogger({
  level: LOG_LEVEL,
  format: isProduction ? productionFormat : developmentFormat,
  defaultMeta: {
    service: 'income-engine',
    version: process.env.npm_package_version || '1.0.0',
  },
  transports: [
    new winston.transports.Console({
      handleExceptions: true,
      handleRejections: true,
    }),
  ],
  exitOnError: false,
});

// =============================================================================
// REQUEST LOGGING
// =============================================================================

/**
 * Generates a unique request ID
 * Format: 8 character UUID prefix for brevity in logs
 */
export function generateRequestId(): string {
  return randomUUID();
}

/**
 * Creates a child logger with request context
 * All logs from this logger will include the requestId
 */
export function createRequestLogger(requestId: string, context?: LogContext): winston.Logger {
  return logger.child({
    requestId,
    ...context,
  });
}

/**
 * Express middleware that adds request ID and logger to request object
 * Also logs request start/end with timing
 *
 * Usage:
 * ```typescript
 * app.use(requestLoggerMiddleware);
 * ```
 */
export function requestLoggerMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const request = req as RequestWithLogger;

  // Get or generate request ID (support for distributed tracing)
  const requestId =
    (req.headers['x-request-id'] as string) ||
    (req.headers['x-correlation-id'] as string) ||
    generateRequestId();

  // Attach to request object
  request.requestId = requestId;
  request.startTime = Date.now();
  request.logger = createRequestLogger(requestId, {
    method: req.method,
    path: req.path,
    userAgent: req.headers['user-agent'],
    ip: req.ip || req.socket.remoteAddress,
  });

  // Set response header for tracing
  res.setHeader('X-Request-ID', requestId);

  // Log request start (debug level to reduce noise)
  request.logger.debug('Request started', {
    query: Object.keys(req.query).length > 0 ? req.query : undefined,
  });

  // Log request completion on response finish
  res.on('finish', () => {
    const duration = Date.now() - request.startTime;
    const logData = {
      statusCode: res.statusCode,
      duration,
      contentLength: res.get('content-length'),
    };

    // Log level based on status code
    if (res.statusCode >= 500) {
      request.logger.error('Request failed', logData);
    } else if (res.statusCode >= 400) {
      request.logger.warn('Request client error', logData);
    } else if (duration > 1000) {
      // Slow request warning
      request.logger.warn('Request slow', logData);
    } else {
      request.logger.info('Request completed', logData);
    }
  });

  // Log if request is closed before response
  res.on('close', () => {
    if (!res.writableEnded) {
      request.logger.warn('Request connection closed before response', {
        duration: Date.now() - request.startTime,
      });
    }
  });

  next();
}

// =============================================================================
// PERFORMANCE TIMING
// =============================================================================

export interface TimerResult {
  duration: number;
  label: string;
}

/**
 * Creates a timer for measuring operation duration
 *
 * Usage:
 * ```typescript
 * const stopTimer = timer('database-query');
 * await database.query(...);
 * const result = stopTimer(); // Logs and returns { duration: 45, label: 'database-query' }
 *
 * // With custom logger
 * const stopTimer = timer('api-call', requestLogger);
 * ```
 */
export function timer(
  label: string,
  customLogger: winston.Logger = logger
): () => TimerResult {
  const start = performance.now();

  return (): TimerResult => {
    const duration = Math.round(performance.now() - start);

    customLogger.debug(`${label} completed`, { duration, label });

    return { duration, label };
  };
}

/**
 * Async wrapper that automatically times function execution
 *
 * Usage:
 * ```typescript
 * const result = await timed('fetch-users', async () => {
 *   return await userService.getAll();
 * });
 * ```
 */
export async function timed<T>(
  label: string,
  fn: () => Promise<T>,
  customLogger: winston.Logger = logger
): Promise<T> {
  const stopTimer = timer(label, customLogger);
  try {
    const result = await fn();
    stopTimer();
    return result;
  } catch (error) {
    const { duration } = stopTimer();
    customLogger.error(`${label} failed`, {
      duration,
      error: error instanceof Error ? error.message : String(error),
    });
    throw error;
  }
}

// =============================================================================
// SPECIALIZED LOGGERS
// =============================================================================

/**
 * Safeguard logger - for safeguard module operations
 */
export const safeguardLogger = logger.child({ module: 'safeguards' });

/**
 * Connector logger - for platform connector operations
 */
export const connectorLogger = logger.child({ module: 'connectors' });

/**
 * Database logger - for database operations
 */
export const dbLogger = logger.child({ module: 'database' });

/**
 * Cache logger - for caching operations
 */
export const cacheLogger = logger.child({ module: 'cache' });

// =============================================================================
// STRUCTURED ERROR LOGGING
// =============================================================================

export interface ErrorLogData {
  code?: string;
  stack?: string;
  context?: Record<string, unknown>;
  requestId?: string;
}

/**
 * Logs an error with structured data
 * Automatically extracts stack trace and error code
 */
export function logError(
  error: Error,
  message: string,
  data?: Partial<ErrorLogData>,
  customLogger: winston.Logger = logger
): void {
  const errorData: ErrorLogData = {
    code: (error as Error & { code?: string }).code,
    stack: error.stack,
    context: data?.context,
    requestId: data?.requestId,
  };

  customLogger.error(message, {
    error: error.message,
    ...errorData,
  });
}

// =============================================================================
// LOG LEVEL UTILITIES
// =============================================================================

/**
 * Temporarily change log level (useful for debugging)
 */
export function setLogLevel(level: LogLevel): void {
  logger.level = level;
  logger.info('Log level changed', { level });
}

/**
 * Get current log level
 */
export function getLogLevel(): string {
  return logger.level;
}

// =============================================================================
// AUDIT LOGGING
// =============================================================================

/**
 * Audit log for security-sensitive operations
 * Always logged at info level regardless of LOG_LEVEL
 */
export function auditLog(
  action: string,
  details: Record<string, unknown>,
  userId?: string
): void {
  logger.info('AUDIT', {
    audit: true,
    action,
    userId: userId || 'system',
    timestamp: new Date().toISOString(),
    ...details,
  });
}

// =============================================================================
// EXPORTS
// =============================================================================

export default logger;
