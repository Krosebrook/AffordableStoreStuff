/**
 * ============================================================================
 * MONITORING SERVICE
 * Health checks, metrics, and error aggregation
 * ============================================================================
 *
 * Features:
 * - Health check endpoints (/health, /ready)
 * - Metrics collection and exposure
 * - Error aggregation and categorization
 * - Uptime and performance tracking
 * - Memory and resource monitoring
 *
 * Usage:
 * ```typescript
 * import { healthCheckHandler, readinessHandler, metricsHandler, errorMonitor } from './services/monitoring';
 *
 * // Health endpoints
 * app.get('/health', healthCheckHandler);
 * app.get('/ready', readinessHandler);
 * app.get('/metrics', metricsHandler);
 *
 * // Track errors
 * errorMonitor.trackError(error, { path: '/api/users' });
 *
 * // Get metrics
 * const metrics = getMetrics();
 * ```
 */

import { Request, Response } from 'express';
import { logger } from './logger.js';

// =============================================================================
// TYPES
// =============================================================================

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  uptime: number;
  version: string;
  environment: string;
  checks: {
    [key: string]: {
      status: 'pass' | 'fail' | 'warn';
      message?: string;
      latency?: number;
    };
  };
}

export interface ReadinessStatus {
  ready: boolean;
  timestamp: string;
  checks: {
    [key: string]: boolean;
  };
}

export interface ErrorMetric {
  code: string;
  count: number;
  lastOccurred: Date;
  paths: Map<string, number>;
}

export interface PerformanceMetric {
  count: number;
  totalDuration: number;
  minDuration: number;
  maxDuration: number;
  avgDuration: number;
}

export interface Metrics {
  requests: {
    total: number;
    byStatus: Map<number, number>;
    byPath: Map<string, PerformanceMetric>;
  };
  errors: {
    total: number;
    byCode: Map<string, ErrorMetric>;
  };
  memory: {
    heapUsed: number;
    heapTotal: number;
    external: number;
    rss: number;
  };
  uptime: number;
  startTime: Date;
}

// =============================================================================
// STATE
// =============================================================================

const startTime = new Date();
const metrics: Metrics = {
  requests: {
    total: 0,
    byStatus: new Map(),
    byPath: new Map(),
  },
  errors: {
    total: 0,
    byCode: new Map(),
  },
  memory: {
    heapUsed: 0,
    heapTotal: 0,
    external: 0,
    rss: 0,
  },
  uptime: 0,
  startTime,
};

// Health check functions registry
const healthChecks: Map<string, () => Promise<{ status: 'pass' | 'fail' | 'warn'; message?: string; latency?: number }>> = new Map();

// Readiness check functions registry
const readinessChecks: Map<string, () => Promise<boolean>> = new Map();

// =============================================================================
// ERROR MONITOR
// =============================================================================

export interface ErrorContext {
  path?: string;
  method?: string;
  requestId?: string;
  statusCode?: number;
  userId?: string;
  [key: string]: unknown;
}

/**
 * Error monitoring and aggregation
 */
export const errorMonitor = {
  /**
   * Track an error occurrence
   */
  trackError(error: Error & { code?: string }, context: ErrorContext = {}): void {
    const code = (error as Error & { code?: string }).code || 'UNKNOWN';
    const path = context.path || 'unknown';

    metrics.errors.total++;

    // Get or create error metric
    let errorMetric = metrics.errors.byCode.get(code);
    if (!errorMetric) {
      errorMetric = {
        code,
        count: 0,
        lastOccurred: new Date(),
        paths: new Map(),
      };
      metrics.errors.byCode.set(code, errorMetric);
    }

    // Update error metric
    errorMetric.count++;
    errorMetric.lastOccurred = new Date();
    errorMetric.paths.set(path, (errorMetric.paths.get(path) || 0) + 1);

    // Log high-frequency errors
    if (errorMetric.count % 100 === 0) {
      logger.warn('High error frequency detected', {
        code,
        count: errorMetric.count,
        recentPaths: Array.from(errorMetric.paths.entries())
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5),
      });
    }
  },

  /**
   * Get error statistics
   */
  getStats(): { total: number; byCode: Record<string, { count: number; lastOccurred: string }> } {
    const byCode: Record<string, { count: number; lastOccurred: string }> = {};

    metrics.errors.byCode.forEach((metric, code) => {
      byCode[code] = {
        count: metric.count,
        lastOccurred: metric.lastOccurred.toISOString(),
      };
    });

    return {
      total: metrics.errors.total,
      byCode,
    };
  },

  /**
   * Reset error counters (useful for testing or after alerts)
   */
  reset(): void {
    metrics.errors.total = 0;
    metrics.errors.byCode.clear();
    logger.info('Error counters reset');
  },
};

// =============================================================================
// REQUEST TRACKING
// =============================================================================

/**
 * Track a request for metrics
 */
export function trackRequest(
  path: string,
  statusCode: number,
  duration: number
): void {
  metrics.requests.total++;

  // Track by status code
  metrics.requests.byStatus.set(
    statusCode,
    (metrics.requests.byStatus.get(statusCode) || 0) + 1
  );

  // Track by path (normalize path to avoid explosion of metrics)
  const normalizedPath = normalizePath(path);
  let pathMetric = metrics.requests.byPath.get(normalizedPath);

  if (!pathMetric) {
    pathMetric = {
      count: 0,
      totalDuration: 0,
      minDuration: Infinity,
      maxDuration: 0,
      avgDuration: 0,
    };
    metrics.requests.byPath.set(normalizedPath, pathMetric);
  }

  pathMetric.count++;
  pathMetric.totalDuration += duration;
  pathMetric.minDuration = Math.min(pathMetric.minDuration, duration);
  pathMetric.maxDuration = Math.max(pathMetric.maxDuration, duration);
  pathMetric.avgDuration = pathMetric.totalDuration / pathMetric.count;
}

/**
 * Normalize path to prevent metric explosion
 * Replaces dynamic segments with placeholders
 */
function normalizePath(path: string): string {
  return path
    // Replace UUIDs
    .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, ':id')
    // Replace numeric IDs
    .replace(/\/\d+/g, '/:id')
    // Remove query strings
    .split('?')[0];
}

// =============================================================================
// HEALTH CHECKS
// =============================================================================

/**
 * Register a health check function
 */
export function registerHealthCheck(
  name: string,
  check: () => Promise<{ status: 'pass' | 'fail' | 'warn'; message?: string; latency?: number }>
): void {
  healthChecks.set(name, check);
  logger.debug('Health check registered', { name });
}

/**
 * Register a readiness check function
 */
export function registerReadinessCheck(
  name: string,
  check: () => Promise<boolean>
): void {
  readinessChecks.set(name, check);
  logger.debug('Readiness check registered', { name });
}

/**
 * Run all health checks
 */
async function runHealthChecks(): Promise<HealthStatus> {
  const checks: HealthStatus['checks'] = {};
  let overallStatus: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';

  // Run all registered checks
  for (const [name, checkFn] of healthChecks) {
    try {
      const start = performance.now();
      const result = await Promise.race([
        checkFn(),
        new Promise<{ status: 'fail'; message: string }>((resolve) =>
          setTimeout(() => resolve({ status: 'fail', message: 'Timeout' }), 5000)
        ),
      ]);
      const latency = Math.round(performance.now() - start);

      checks[name] = { ...result, latency };

      if (result.status === 'fail') {
        overallStatus = 'unhealthy';
      } else if (result.status === 'warn' && overallStatus !== 'unhealthy') {
        overallStatus = 'degraded';
      }
    } catch (error) {
      checks[name] = {
        status: 'fail',
        message: error instanceof Error ? error.message : 'Check failed',
      };
      overallStatus = 'unhealthy';
    }
  }

  // Add default checks
  checks.memory = await checkMemory();
  if (checks.memory.status === 'warn' && overallStatus === 'healthy') {
    overallStatus = 'degraded';
  }

  return {
    status: overallStatus,
    timestamp: new Date().toISOString(),
    uptime: Math.floor((Date.now() - startTime.getTime()) / 1000),
    version: process.env.npm_package_version || '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    checks,
  };
}

/**
 * Memory check
 */
async function checkMemory(): Promise<{ status: 'pass' | 'fail' | 'warn'; message?: string }> {
  const memUsage = process.memoryUsage();
  const heapUsedMB = Math.round(memUsage.heapUsed / 1024 / 1024);
  const heapTotalMB = Math.round(memUsage.heapTotal / 1024 / 1024);
  const usagePercent = (memUsage.heapUsed / memUsage.heapTotal) * 100;

  // Update metrics
  metrics.memory = {
    heapUsed: memUsage.heapUsed,
    heapTotal: memUsage.heapTotal,
    external: memUsage.external,
    rss: memUsage.rss,
  };

  if (usagePercent > 90) {
    return {
      status: 'fail',
      message: `High memory usage: ${heapUsedMB}MB / ${heapTotalMB}MB (${usagePercent.toFixed(1)}%)`,
    };
  }

  if (usagePercent > 75) {
    return {
      status: 'warn',
      message: `Elevated memory usage: ${heapUsedMB}MB / ${heapTotalMB}MB (${usagePercent.toFixed(1)}%)`,
    };
  }

  return {
    status: 'pass',
    message: `${heapUsedMB}MB / ${heapTotalMB}MB (${usagePercent.toFixed(1)}%)`,
  };
}

/**
 * Run all readiness checks
 */
async function runReadinessChecks(): Promise<ReadinessStatus> {
  const checks: { [key: string]: boolean } = {};
  let allReady = true;

  for (const [name, checkFn] of readinessChecks) {
    try {
      const ready = await Promise.race([
        checkFn(),
        new Promise<boolean>((resolve) => setTimeout(() => resolve(false), 5000)),
      ]);
      checks[name] = ready;
      if (!ready) allReady = false;
    } catch {
      checks[name] = false;
      allReady = false;
    }
  }

  return {
    ready: allReady,
    timestamp: new Date().toISOString(),
    checks,
  };
}

// =============================================================================
// HANDLERS
// =============================================================================

/**
 * Health check endpoint handler
 * Returns 200 if healthy, 503 if unhealthy
 */
export async function healthCheckHandler(
  _req: Request,
  res: Response
): Promise<void> {
  try {
    const health = await runHealthChecks();
    const statusCode = health.status === 'unhealthy' ? 503 : 200;
    res.status(statusCode).json(health);
  } catch (error) {
    logger.error('Health check failed', { error: (error as Error).message });
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: 'Health check execution failed',
    });
  }
}

/**
 * Readiness check endpoint handler
 * Returns 200 if ready, 503 if not ready
 */
export async function readinessHandler(
  _req: Request,
  res: Response
): Promise<void> {
  try {
    const readiness = await runReadinessChecks();
    const statusCode = readiness.ready ? 200 : 503;
    res.status(statusCode).json(readiness);
  } catch (error) {
    logger.error('Readiness check failed', { error: (error as Error).message });
    res.status(503).json({
      ready: false,
      timestamp: new Date().toISOString(),
      error: 'Readiness check execution failed',
    });
  }
}

/**
 * Metrics endpoint handler
 * Returns current metrics for monitoring systems
 */
export function metricsHandler(_req: Request, res: Response): void {
  // Update uptime
  metrics.uptime = Math.floor((Date.now() - startTime.getTime()) / 1000);

  // Update memory stats
  const memUsage = process.memoryUsage();
  metrics.memory = {
    heapUsed: memUsage.heapUsed,
    heapTotal: memUsage.heapTotal,
    external: memUsage.external,
    rss: memUsage.rss,
  };

  // Convert Maps to objects for JSON serialization
  const response = {
    requests: {
      total: metrics.requests.total,
      byStatus: Object.fromEntries(metrics.requests.byStatus),
      byPath: Object.fromEntries(
        Array.from(metrics.requests.byPath.entries()).map(([path, metric]) => [
          path,
          {
            count: metric.count,
            avgDuration: Math.round(metric.avgDuration),
            minDuration: metric.minDuration === Infinity ? 0 : metric.minDuration,
            maxDuration: metric.maxDuration,
          },
        ])
      ),
    },
    errors: errorMonitor.getStats(),
    memory: {
      heapUsedMB: Math.round(metrics.memory.heapUsed / 1024 / 1024),
      heapTotalMB: Math.round(metrics.memory.heapTotal / 1024 / 1024),
      rssMB: Math.round(metrics.memory.rss / 1024 / 1024),
    },
    uptime: metrics.uptime,
    uptimeFormatted: formatUptime(metrics.uptime),
    startTime: startTime.toISOString(),
  };

  res.json(response);
}

/**
 * Format uptime in human-readable format
 */
function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  const parts: string[] = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0) parts.push(`${minutes}m`);
  if (secs > 0 || parts.length === 0) parts.push(`${secs}s`);

  return parts.join(' ');
}

// =============================================================================
// METRICS ACCESS
// =============================================================================

/**
 * Get current metrics snapshot
 */
export function getMetrics(): Metrics {
  return { ...metrics };
}

/**
 * Reset all metrics (useful for testing)
 */
export function resetMetrics(): void {
  metrics.requests.total = 0;
  metrics.requests.byStatus.clear();
  metrics.requests.byPath.clear();
  metrics.errors.total = 0;
  metrics.errors.byCode.clear();
  logger.info('All metrics reset');
}

// =============================================================================
// REQUEST METRICS MIDDLEWARE
// =============================================================================

/**
 * Middleware to track request metrics
 * Should be used early in the middleware chain
 */
export function metricsMiddleware(
  req: Request,
  res: Response,
  next: () => void
): void {
  const startTime = performance.now();

  res.on('finish', () => {
    const duration = Math.round(performance.now() - startTime);
    trackRequest(req.path, res.statusCode, duration);
  });

  next();
}

// =============================================================================
// DEFAULT HEALTH CHECKS
// =============================================================================

// Register default memory check
registerHealthCheck('memory', async () => checkMemory());

// Register event loop check (detects event loop blocking)
registerHealthCheck('eventLoop', async () => {
  return new Promise((resolve) => {
    const start = Date.now();
    setImmediate(() => {
      const lag = Date.now() - start;
      if (lag > 100) {
        resolve({
          status: 'warn',
          message: `Event loop lag: ${lag}ms`,
        });
      } else if (lag > 500) {
        resolve({
          status: 'fail',
          message: `Critical event loop lag: ${lag}ms`,
        });
      } else {
        resolve({
          status: 'pass',
          message: `Event loop lag: ${lag}ms`,
        });
      }
    });
  });
});

// =============================================================================
// EXPORTS
// =============================================================================

export default {
  errorMonitor,
  trackRequest,
  getMetrics,
  resetMetrics,
  registerHealthCheck,
  registerReadinessCheck,
  healthCheckHandler,
  readinessHandler,
  metricsHandler,
  metricsMiddleware,
};
