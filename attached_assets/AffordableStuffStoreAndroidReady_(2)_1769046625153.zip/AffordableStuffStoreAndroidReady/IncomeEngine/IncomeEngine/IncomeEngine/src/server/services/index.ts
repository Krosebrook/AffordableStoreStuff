/**
 * ============================================================================
 * INFRASTRUCTURE SERVICES INDEX
 * Re-exports all infrastructure services for convenient importing
 * ============================================================================
 *
 * Usage:
 * ```typescript
 * import { logger, cache, errorMonitor } from './services';
 * ```
 */

// Logger exports
export {
  logger,
  createRequestLogger,
  requestLoggerMiddleware,
  timer,
  timed,
  safeguardLogger,
  connectorLogger,
  dbLogger,
  cacheLogger,
  logError,
  setLogLevel,
  getLogLevel,
  auditLog,
  generateRequestId,
  type LogContext,
  type RequestWithLogger,
  type LogLevel,
} from './logger.js';

// Monitoring exports
export {
  errorMonitor,
  trackRequest,
  getMetrics,
  resetMetrics,
  registerHealthCheck,
  registerReadinessCheck,
  healthCheckHandler,
  readinessHandler,
  metricsHandler,
  metricsMiddleware,
  type HealthStatus,
  type ReadinessStatus,
  type Metrics,
  type ErrorContext,
} from './monitoring.js';

// Cache exports
export {
  cache,
  cachedQuery,
  invalidateCachedQuery,
  invalidateCachedQueries,
  createNamespacedCache,
  memoize,
  warmupCache,
  Cached,
  type CacheEntry,
  type CacheStats,
  type CacheOptions,
} from './cache.js';
