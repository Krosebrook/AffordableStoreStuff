/**
 * ============================================================================
 * PROMPT TEMPLATE ENGINE
 * ============================================================================
 *
 * Dynamic prompt construction for AI image generation.
 * Supports variable interpolation, niche-specific templates, and prompt enhancement.
 */

import {
  PromptTemplate,
  TemplateVariable,
  NicheTemplates,
  DesignPrompt,
  GenerationOptions,
} from '../types';
import nicheTemplatesData from './niche-templates.json';

// =============================================================================
// TYPES
// =============================================================================

interface PromptBuilderConfig {
  readonly enableEnhancement?: boolean;
  readonly enableQualityModifiers?: boolean;
  readonly maxPromptLength?: number;
}

interface BuiltPrompt {
  readonly text: string;
  readonly enhancedText: string;
  readonly templateId?: string;
  readonly variables?: Record<string, string>;
  readonly niche?: string;
  readonly warnings: string[];
}

// =============================================================================
// PROMPT BUILDER CLASS
// =============================================================================

export class PromptBuilder {
  private config: PromptBuilderConfig;
  private templates: Map<string, PromptTemplate> = new Map();
  private nicheTemplates: Map<string, NicheTemplates> = new Map();

  constructor(config: PromptBuilderConfig = {}) {
    this.config = {
      enableEnhancement: true,
      enableQualityModifiers: true,
      maxPromptLength: 1000,
      ...config,
    };

    // Load templates
    this.loadTemplates();
  }

  /**
   * Build a prompt from raw text or template
   */
  build(input: string | DesignPrompt, options?: GenerationOptions): BuiltPrompt {
    const warnings: string[] = [];

    // Handle string input
    if (typeof input === 'string') {
      const text = this.sanitizePrompt(input);
      const enhancedText = this.config.enableEnhancement
        ? this.enhancePrompt(text, options)
        : text;

      return {
        text,
        enhancedText,
        niche: options?.niche,
        warnings,
      };
    }

    // Handle template-based prompt
    let text = input.text;
    let templateId: string | undefined;
    let variables: Record<string, string> | undefined;

    // If template specified, use it
    if (input.templateId) {
      const template = this.templates.get(input.templateId);

      if (template) {
        const result = this.interpolateTemplate(template, input.variables || {});
        text = result.text;
        templateId = template.id;
        variables = input.variables;
        warnings.push(...result.warnings);
      } else {
        warnings.push(`Template not found: ${input.templateId}`);
      }
    }

    // Sanitize and enhance
    text = this.sanitizePrompt(text);
    const enhancedText = this.config.enableEnhancement
      ? this.enhancePrompt(text, options, input.niche)
      : text;

    // Check length
    if (enhancedText.length > (this.config.maxPromptLength ?? 1000)) {
      warnings.push(
        `Prompt exceeds maximum length of ${this.config.maxPromptLength} characters`
      );
    }

    return {
      text,
      enhancedText,
      templateId,
      variables,
      niche: input.niche,
      warnings,
    };
  }

  /**
   * Get templates for a specific niche
   */
  getTemplatesForNiche(niche: string): PromptTemplate[] {
    const nicheData = this.nicheTemplates.get(niche.toLowerCase());

    if (!nicheData) {
      return [];
    }

    return nicheData.templates;
  }

  /**
   * Get all available niches
   */
  getNiches(): string[] {
    return Array.from(this.nicheTemplates.keys());
  }

  /**
   * Get a specific template by ID
   */
  getTemplate(templateId: string): PromptTemplate | undefined {
    return this.templates.get(templateId);
  }

  /**
   * Get template suggestions based on keywords
   */
  suggestTemplates(
    keywords: string[],
    niche?: string,
    limit: number = 5
  ): PromptTemplate[] {
    const lowercaseKeywords = keywords.map((k) => k.toLowerCase());

    // Filter templates
    let candidates = Array.from(this.templates.values());

    // Filter by niche if specified
    if (niche) {
      candidates = candidates.filter(
        (t) => t.niche.toLowerCase() === niche.toLowerCase()
      );
    }

    // Score templates by keyword matches
    const scored = candidates.map((template) => {
      let score = 0;

      // Check template name
      for (const keyword of lowercaseKeywords) {
        if (template.name.toLowerCase().includes(keyword)) {
          score += 3;
        }
      }

      // Check template tags
      for (const tag of template.tags) {
        for (const keyword of lowercaseKeywords) {
          if (tag.toLowerCase().includes(keyword)) {
            score += 2;
          }
        }
      }

      // Check template text
      for (const keyword of lowercaseKeywords) {
        if (template.template.toLowerCase().includes(keyword)) {
          score += 1;
        }
      }

      return { template, score };
    });

    // Sort by score and return top results
    return scored
      .filter((s) => s.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map((s) => s.template);
  }

  /**
   * Get random template for a niche
   */
  getRandomTemplate(niche: string): PromptTemplate | undefined {
    const templates = this.getTemplatesForNiche(niche);

    if (templates.length === 0) {
      return undefined;
    }

    const index = Math.floor(Math.random() * templates.length);
    return templates[index];
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  /**
   * Load templates from JSON data
   */
  private loadTemplates(): void {
    const data = nicheTemplatesData as { niches: NicheTemplates[] };

    for (const nicheData of data.niches) {
      // Store niche templates
      this.nicheTemplates.set(nicheData.niche.toLowerCase(), nicheData);

      // Index individual templates
      for (const template of nicheData.templates) {
        this.templates.set(template.id, template);
      }
    }
  }

  /**
   * Interpolate template variables
   */
  private interpolateTemplate(
    template: PromptTemplate,
    variables: Record<string, string>
  ): { text: string; warnings: string[] } {
    const warnings: string[] = [];
    let text = template.template;

    // Process each variable in the template
    for (const variable of template.variables) {
      const placeholder = `{{${variable.name}}}`;
      const value = variables[variable.name] || variable.default;

      if (value) {
        // Validate value if validation rules exist
        if (variable.validation) {
          if (
            variable.validation.minLength &&
            value.length < variable.validation.minLength
          ) {
            warnings.push(
              `Variable "${variable.name}" is shorter than minimum length ${variable.validation.minLength}`
            );
          }

          if (
            variable.validation.maxLength &&
            value.length > variable.validation.maxLength
          ) {
            warnings.push(
              `Variable "${variable.name}" exceeds maximum length ${variable.validation.maxLength}`
            );
          }

          if (
            variable.validation.pattern &&
            !new RegExp(variable.validation.pattern).test(value)
          ) {
            warnings.push(
              `Variable "${variable.name}" does not match required pattern`
            );
          }
        }

        text = text.replace(new RegExp(placeholder, 'g'), value);
      } else if (variable.required) {
        warnings.push(`Required variable "${variable.name}" is missing`);
        text = text.replace(new RegExp(placeholder, 'g'), `[${variable.name}]`);
      } else {
        // Remove optional placeholder
        text = text.replace(new RegExp(placeholder, 'g'), '');
      }
    }

    // Clean up any extra spaces
    text = text.replace(/\s+/g, ' ').trim();

    return { text, warnings };
  }

  /**
   * Sanitize prompt text
   */
  private sanitizePrompt(text: string): string {
    // Remove potentially problematic characters
    let sanitized = text
      .replace(/[\x00-\x1F\x7F]/g, '') // Control characters
      .replace(/[<>]/g, '') // HTML-like brackets
      .trim();

    // Collapse multiple spaces
    sanitized = sanitized.replace(/\s+/g, ' ');

    return sanitized;
  }

  /**
   * Enhance prompt with quality modifiers
   */
  private enhancePrompt(
    text: string,
    options?: GenerationOptions,
    niche?: string
  ): string {
    const enhancements: string[] = [];

    // Add quality modifiers
    if (this.config.enableQualityModifiers) {
      enhancements.push('high quality', 'detailed', 'professional');
    }

    // Add niche-specific style
    const nicheStyle = niche || options?.niche;
    if (nicheStyle) {
      const nicheData = this.nicheTemplates.get(nicheStyle.toLowerCase());
      if (nicheData && nicheData.commonStyles.length > 0) {
        // Add first common style
        enhancements.push(nicheData.commonStyles[0]);
      }
    }

    // Add product type context
    if (options?.productType) {
      enhancements.push(`suitable for ${options.productType} printing`);
    }

    // Add custom style
    if (options?.style) {
      enhancements.push(options.style);
    }

    // Combine
    if (enhancements.length > 0) {
      return `${text}, ${enhancements.join(', ')}`;
    }

    return text;
  }

  /**
   * Create a new template programmatically
   */
  createTemplate(
    niche: string,
    name: string,
    template: string,
    variables: TemplateVariable[],
    options: {
      category?: string;
      style?: string;
      negativePrompt?: string;
      tags?: string[];
    } = {}
  ): PromptTemplate {
    const id = `${niche.toLowerCase()}-${name.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`;

    const newTemplate: PromptTemplate = {
      id,
      name,
      niche,
      category: options.category || 'custom',
      template,
      variables,
      style: options.style,
      negativePrompt: options.negativePrompt,
      tags: options.tags || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Add to cache
    this.templates.set(id, newTemplate);

    return newTemplate;
  }

  /**
   * Get style suggestions for a niche
   */
  getStylesForNiche(niche: string): string[] {
    const nicheData = this.nicheTemplates.get(niche.toLowerCase());

    if (!nicheData) {
      return [];
    }

    return nicheData.commonStyles;
  }

  /**
   * Get recommended dimensions for a niche
   */
  getRecommendedDimensions(niche: string): { width: number; height: number } {
    const nicheData = this.nicheTemplates.get(niche.toLowerCase());

    if (!nicheData || !nicheData.recommendedDimensions) {
      return { width: 1024, height: 1024 };
    }

    return nicheData.recommendedDimensions;
  }
}

// =============================================================================
// EXPORTS
// =============================================================================

export default PromptBuilder;

// Export utility functions
export function createSimplePrompt(
  subject: string,
  style?: string,
  modifiers?: string[]
): string {
  const parts = [subject];

  if (style) {
    parts.push(style);
  }

  if (modifiers && modifiers.length > 0) {
    parts.push(...modifiers);
  }

  return parts.join(', ');
}

export function combinePrompts(prompts: string[], separator: string = ', '): string {
  return prompts.filter((p) => p.trim().length > 0).join(separator);
}

export function addQualityModifiers(prompt: string): string {
  const modifiers = [
    'high quality',
    'highly detailed',
    'professional',
    'sharp focus',
    '8k resolution',
  ];

  return `${prompt}, ${modifiers.join(', ')}`;
}

export function addPODModifiers(prompt: string, productType?: string): string {
  const modifiers = [
    'clean design',
    'suitable for printing',
    'isolated on background',
    'no text unless specified',
  ];

  if (productType) {
    modifiers.unshift(`design for ${productType}`);
  }

  return `${prompt}, ${modifiers.join(', ')}`;
}
