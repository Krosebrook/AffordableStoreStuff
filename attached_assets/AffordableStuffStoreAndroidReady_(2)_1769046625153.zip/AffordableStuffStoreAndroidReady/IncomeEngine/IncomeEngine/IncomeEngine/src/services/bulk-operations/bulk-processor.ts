/**
 * Bulk Processor
 * Main batch operation handler with queue support for processing 100+ products
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EventEmitter } from 'events';
import {
  BulkOperation,
  BulkOperationItem,
  BulkOperationConfig,
  BulkOperationResult,
  BulkItemResult,
  BulkOperationStatus,
  BulkOperationType,
  BulkPriority,
  BulkOperationError,
  CreateBulkOperationRequest,
  BulkOperationItemInput,
  BulkOperationQuery,
  BulkOperationListResult,
  QueuedBulkOperation,
  BulkOperationQueueStats,
  PlatformOperationResult,
  PlatformRateLimitStatus,
  DEFAULT_BULK_CONFIG,
} from './types';
import { ProgressTracker, createProgressTracker } from './progress-tracker';
import { RollbackManager, createRollbackManager, RollbackManagerConfig } from './rollback-manager';
import {
  ConnectorName,
  createConnector,
  ConnectorFactoryConfig,
  getRateLimitManager,
  RateLimitManager,
} from '../../connectors/index';
import { ProductInput, NormalizedProduct, ConnectorError } from '../../connectors/core/types';

// ============================================================================
// Types
// ============================================================================

export interface BulkProcessorConfig {
  supabaseUrl: string;
  supabaseKey: string;
  connectorConfigs: Map<ConnectorName, ConnectorFactoryConfig>;
  maxConcurrentOperations?: number;
  defaultConfig?: Partial<BulkOperationConfig>;
}

interface ProcessingState {
  operation: BulkOperation;
  abortController: AbortController;
  startTime: number;
}

// ============================================================================
// Bulk Processor Class
// ============================================================================

export class BulkProcessor extends EventEmitter {
  private supabase: SupabaseClient;
  private progressTracker: ProgressTracker;
  private rollbackManager: RollbackManager;
  private rateLimitManager: RateLimitManager;
  private config: BulkProcessorConfig;
  private activeOperations: Map<string, ProcessingState> = new Map();
  private operationQueue: QueuedBulkOperation[] = [];
  private isProcessingQueue: boolean = false;
  private queueProcessorInterval: NodeJS.Timeout | null = null;

  constructor(config: BulkProcessorConfig) {
    super();
    this.config = config;
    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);
    this.progressTracker = createProgressTracker(config.supabaseUrl, config.supabaseKey);
    this.rateLimitManager = getRateLimitManager();

    const rollbackConfig: RollbackManagerConfig = {
      supabaseUrl: config.supabaseUrl,
      supabaseKey: config.supabaseKey,
      maxConcurrency: 5,
      retryAttempts: 3,
      retryDelayMs: 1000,
      connectorConfigs: config.connectorConfigs,
    };
    this.rollbackManager = createRollbackManager(rollbackConfig, this.progressTracker);

    // Register platform rate limits
    this.registerPlatformRateLimits();
  }

  // ============================================================================
  // Operation Creation
  // ============================================================================

  /**
   * Create a new bulk operation
   */
  async createOperation(request: CreateBulkOperationRequest): Promise<BulkOperation> {
    const now = new Date();
    const operationConfig = {
      ...DEFAULT_BULK_CONFIG,
      ...this.config.defaultConfig,
      ...request.config,
    };

    // Calculate total batches
    const totalBatches = Math.ceil(request.items.length / operationConfig.batchSize);

    const operation: BulkOperation = {
      id: this.generateOperationId(),
      type: request.type,
      status: 'pending',
      priority: request.priority || 'normal',
      config: operationConfig,
      items: request.items.map((input, index) => this.createOperationItem(input, request, index)),
      progress: {
        total: request.items.length,
        processed: 0,
        successful: 0,
        failed: 0,
        skipped: 0,
        pending: request.items.length,
        percent: 0,
        currentBatch: 0,
        totalBatches,
        rateLimitPaused: false,
      },
      metadata: {
        ...request.metadata,
      },
      createdAt: now,
      updatedAt: now,
    };

    // Persist to database
    await this.persistOperation(operation);

    // Initialize progress tracking
    this.progressTracker.initializeOperation(operation);

    this.emit('operation:created', { operation });

    return operation;
  }

  private createOperationItem(
    input: BulkOperationItemInput,
    request: CreateBulkOperationRequest,
    index: number
  ): BulkOperationItem {
    return {
      id: `item-${Date.now()}-${index}-${Math.random().toString(36).substr(2, 9)}`,
      operationType: request.type,
      status: 'pending',
      productId: input.productId,
      externalId: input.externalId,
      data: input.data,
      targetPlatforms: input.overrideTargetPlatforms || request.targetPlatforms,
      platformResults: [],
      retryCount: 0,
      createdAt: new Date(),
    };
  }

  // ============================================================================
  // Operation Execution
  // ============================================================================

  /**
   * Start processing an operation immediately
   */
  async startOperation(operationId: string): Promise<void> {
    const operation = await this.getOperation(operationId);
    if (!operation) {
      throw new Error(`Operation not found: ${operationId}`);
    }

    if (operation.status !== 'pending' && operation.status !== 'queued') {
      throw new Error(`Operation ${operationId} is not in a startable state: ${operation.status}`);
    }

    // Check concurrent operation limit
    const maxConcurrent = this.config.maxConcurrentOperations || 5;
    if (this.activeOperations.size >= maxConcurrent) {
      // Add to queue instead
      await this.queueOperation(operation);
      return;
    }

    await this.executeOperation(operation);
  }

  /**
   * Queue an operation for later processing
   */
  async queueOperation(operation: BulkOperation): Promise<void> {
    operation.status = 'queued';
    operation.updatedAt = new Date();

    await this.persistOperation(operation);

    const queuedOp: QueuedBulkOperation = {
      ...operation,
      queuePosition: this.operationQueue.length + 1,
      estimatedStartTime: this.estimateStartTime(),
    };

    this.operationQueue.push(queuedOp);
    this.sortQueue();

    this.emit('operation:queued', { operationId: operation.id, position: queuedOp.queuePosition });
  }

  /**
   * Execute a bulk operation
   */
  private async executeOperation(operation: BulkOperation): Promise<void> {
    const abortController = new AbortController();
    const processingState: ProcessingState = {
      operation,
      abortController,
      startTime: Date.now(),
    };

    this.activeOperations.set(operation.id, processingState);

    try {
      await this.progressTracker.startOperation(operation.id);
      operation.status = 'processing';
      operation.startedAt = new Date();

      const result = await this.processItems(operation, abortController.signal);

      // Handle rollback if needed
      if (!result.success && operation.config.rollbackOnFailure && !operation.config.dryRun) {
        result.rollbackPerformed = true;
        const rollbackResult = await this.rollbackManager.rollbackOperation(operation);
        result.rollbackSuccess = rollbackResult.success;
      }

      operation.result = result;
      await this.progressTracker.completeOperation(operation.id, result);

    } catch (error) {
      const errors: BulkOperationError[] = [{
        code: 'OPERATION_ERROR',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date(),
      }];
      await this.progressTracker.failOperation(operation.id, errors);

    } finally {
      this.activeOperations.delete(operation.id);
      this.emit('operation:finished', { operationId: operation.id });

      // Process next queued operation
      this.processNextInQueue();
    }
  }

  /**
   * Process all items in batches
   */
  private async processItems(
    operation: BulkOperation,
    signal: AbortSignal
  ): Promise<BulkOperationResult> {
    const { config, items } = operation;
    const startTime = Date.now();
    const itemResults: BulkItemResult[] = [];
    const errors: BulkOperationError[] = [];

    // Split items into batches
    const batches = this.createBatches(items, config.batchSize);
    operation.progress.totalBatches = batches.length;

    for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
      if (signal.aborted) {
        break;
      }

      const batch = batches[batchIndex];
      await this.progressTracker.startBatch(operation.id, batchIndex + 1);

      // Process batch with concurrency control
      const batchResults = await this.processBatch(
        operation,
        batch,
        config.concurrency,
        signal
      );

      itemResults.push(...batchResults.results);
      errors.push(...batchResults.errors);

      await this.progressTracker.completeBatch(operation.id, batchIndex + 1);

      // Check if we should stop on error
      if (!config.continueOnError && batchResults.errors.length > 0) {
        break;
      }

      // Check timeout
      if (Date.now() - startTime > config.timeoutMs) {
        errors.push({
          code: 'TIMEOUT',
          message: `Operation timed out after ${config.timeoutMs}ms`,
          timestamp: new Date(),
        });
        break;
      }
    }

    const successful = itemResults.filter((r) => r.success).length;
    const failed = itemResults.filter((r) => !r.success).length;
    const skipped = items.length - itemResults.length;

    return {
      success: failed === 0 && errors.length === 0,
      total: items.length,
      successful,
      failed,
      skipped,
      duration: Date.now() - startTime,
      rollbackPerformed: false,
      itemResults,
      errors,
    };
  }

  /**
   * Process a batch of items with concurrency control
   */
  private async processBatch(
    operation: BulkOperation,
    batch: BulkOperationItem[],
    concurrency: number,
    signal: AbortSignal
  ): Promise<{ results: BulkItemResult[]; errors: BulkOperationError[] }> {
    const results: BulkItemResult[] = [];
    const errors: BulkOperationError[] = [];

    // Process in concurrent groups
    for (let i = 0; i < batch.length; i += concurrency) {
      if (signal.aborted) break;

      const group = batch.slice(i, i + concurrency);
      const groupPromises = group.map((item) =>
        this.processItem(operation, item, signal)
      );

      const groupResults = await Promise.allSettled(groupPromises);

      for (let j = 0; j < groupResults.length; j++) {
        const result = groupResults[j];
        const item = group[j];

        if (result.status === 'fulfilled') {
          results.push(result.value);
          if (!result.value.success && result.value.error) {
            errors.push({
              itemId: item.id,
              code: result.value.error.code,
              message: result.value.error.message,
              platform: result.value.error.platform,
              timestamp: new Date(),
            });
          }
        } else {
          results.push({
            itemId: item.id,
            productId: item.productId,
            success: false,
            platforms: [],
            error: {
              code: 'PROCESSING_ERROR',
              message: result.reason?.message || 'Unknown error',
              retryable: false,
            },
          });
          errors.push({
            itemId: item.id,
            code: 'PROCESSING_ERROR',
            message: result.reason?.message || 'Unknown error',
            timestamp: new Date(),
          });
        }
      }
    }

    return { results, errors };
  }

  /**
   * Process a single item across all target platforms
   */
  private async processItem(
    operation: BulkOperation,
    item: BulkOperationItem,
    signal: AbortSignal
  ): Promise<BulkItemResult> {
    await this.progressTracker.startItem(operation.id, item.id);

    const platformResults: PlatformOperationResult[] = [];
    let hasError = false;

    // Capture state for rollback if needed
    if (operation.config.rollbackOnFailure && !operation.config.dryRun) {
      if (item.operationType === 'update' || item.operationType === 'delete') {
        await this.rollbackManager.captureCurrentState(
          operation.id,
          item,
          item.targetPlatforms
        );
      }
    }

    for (const platform of item.targetPlatforms) {
      if (signal.aborted) break;

      await this.progressTracker.startItem(operation.id, item.id, platform);

      const platformResult = await this.processItemForPlatform(
        operation,
        item,
        platform
      );

      platformResults.push(platformResult);
      item.platformResults.push(platformResult);

      if (!platformResult.success) {
        hasError = true;
        if (!operation.config.continueOnError) {
          break;
        }
      }
    }

    const result: BulkItemResult = {
      itemId: item.id,
      productId: item.productId,
      success: !hasError,
      platforms: platformResults,
    };

    if (hasError) {
      const failedPlatform = platformResults.find((p) => !p.success);
      if (failedPlatform?.error) {
        result.error = {
          code: failedPlatform.error.code,
          message: failedPlatform.error.message,
          platform: failedPlatform.platform,
          retryable: failedPlatform.error.retryable,
        };
      }
      await this.progressTracker.failItem(operation.id, item.id, result.error!);
    } else {
      await this.progressTracker.completeItem(operation.id, item.id);
    }

    return result;
  }

  /**
   * Process an item for a specific platform
   */
  private async processItemForPlatform(
    operation: BulkOperation,
    item: BulkOperationItem,
    platform: ConnectorName
  ): Promise<PlatformOperationResult> {
    const startTime = Date.now();
    let retries = 0;
    let rateLimitHit = false;

    const connectorConfig = this.config.connectorConfigs.get(platform);
    if (!connectorConfig) {
      return {
        platform,
        success: false,
        error: {
          code: 'NO_CONNECTOR_CONFIG',
          message: `No connector configuration for platform: ${platform}`,
          retryable: false,
        },
        duration: Date.now() - startTime,
        retries: 0,
        rateLimitHit: false,
      };
    }

    // Dry run mode
    if (operation.config.dryRun) {
      await this.sleep(100); // Simulate processing
      return {
        platform,
        success: true,
        externalId: 'dry-run-id',
        duration: Date.now() - startTime,
        retries: 0,
        rateLimitHit: false,
      };
    }

    // Rate limit check
    if (operation.config.respectRateLimits) {
      const canProceed = await this.rateLimitManager.acquire(platform);
      if (!canProceed) {
        rateLimitHit = true;
        const waitTime = this.rateLimitManager.getEstimatedWaitTime(platform);
        await this.progressTracker.hitRateLimit(operation.id, platform, waitTime);
        await this.sleep(waitTime);
        await this.progressTracker.resumeFromRateLimit(operation.id);
      }
    }

    // Execute with retries
    while (retries <= operation.config.maxRetries) {
      try {
        const connector = createConnector(platform, connectorConfig);
        let result: { success: boolean; data?: any; error?: ConnectorError };

        switch (item.operationType) {
          case 'create':
          case 'publish':
            result = await connector.createProduct(item.data as ProductInput);
            if (result.success && result.data) {
              // Store rollback data for newly created items
              if (operation.config.rollbackOnFailure) {
                await this.rollbackManager.storeRollbackData(operation.id, item, [{
                  platform,
                  externalId: result.data.externalId,
                  action: 'delete',
                  completed: false,
                }]);
              }
              return {
                platform,
                success: true,
                externalId: result.data.externalId,
                externalUrl: result.data.externalUrl,
                duration: Date.now() - startTime,
                retries,
                rateLimitHit,
              };
            }
            break;

          case 'update':
          case 'sync':
            if (!item.externalId) {
              return {
                platform,
                success: false,
                error: {
                  code: 'MISSING_EXTERNAL_ID',
                  message: 'External ID required for update operation',
                  retryable: false,
                },
                duration: Date.now() - startTime,
                retries,
                rateLimitHit,
              };
            }
            result = await connector.updateProduct(
              item.externalId,
              item.data as ProductInput
            );
            if (result.success) {
              return {
                platform,
                success: true,
                externalId: item.externalId,
                duration: Date.now() - startTime,
                retries,
                rateLimitHit,
              };
            }
            break;

          case 'delete':
            if (!item.externalId) {
              return {
                platform,
                success: false,
                error: {
                  code: 'MISSING_EXTERNAL_ID',
                  message: 'External ID required for delete operation',
                  retryable: false,
                },
                duration: Date.now() - startTime,
                retries,
                rateLimitHit,
              };
            }
            result = await connector.deleteProduct(item.externalId);
            if (result.success) {
              return {
                platform,
                success: true,
                externalId: item.externalId,
                duration: Date.now() - startTime,
                retries,
                rateLimitHit,
              };
            }
            break;

          default:
            return {
              platform,
              success: false,
              error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Unsupported operation type: ${item.operationType}`,
                retryable: false,
              },
              duration: Date.now() - startTime,
              retries,
              rateLimitHit,
            };
        }

        // Handle error from result
        if (result.error) {
          if (!result.error.retryable || retries >= operation.config.maxRetries) {
            return {
              platform,
              success: false,
              error: result.error,
              duration: Date.now() - startTime,
              retries,
              rateLimitHit,
            };
          }
          retries++;
          await this.progressTracker.retryItem(operation.id, item.id, retries);
          await this.sleep(operation.config.retryDelayMs * Math.pow(2, retries - 1));
          continue;
        }

      } catch (error) {
        if (retries >= operation.config.maxRetries) {
          return {
            platform,
            success: false,
            error: {
              code: 'CONNECTOR_ERROR',
              message: error instanceof Error ? error.message : 'Unknown error',
              retryable: false,
            },
            duration: Date.now() - startTime,
            retries,
            rateLimitHit,
          };
        }
        retries++;
        await this.progressTracker.retryItem(operation.id, item.id, retries);
        await this.sleep(operation.config.retryDelayMs * Math.pow(2, retries - 1));
      }
    }

    return {
      platform,
      success: false,
      error: {
        code: 'MAX_RETRIES_EXCEEDED',
        message: `Max retries (${operation.config.maxRetries}) exceeded`,
        retryable: false,
      },
      duration: Date.now() - startTime,
      retries,
      rateLimitHit,
    };
  }

  // ============================================================================
  // Operation Control
  // ============================================================================

  /**
   * Cancel an operation
   */
  async cancelOperation(operationId: string, reason?: string): Promise<void> {
    const state = this.activeOperations.get(operationId);
    if (state) {
      state.abortController.abort();
    }

    await this.progressTracker.cancelOperation(operationId, reason);

    // Remove from queue if queued
    const queueIndex = this.operationQueue.findIndex((op) => op.id === operationId);
    if (queueIndex !== -1) {
      this.operationQueue.splice(queueIndex, 1);
      this.updateQueuePositions();
    }

    this.emit('operation:cancelled', { operationId, reason });
  }

  /**
   * Pause an operation (for future resume)
   */
  async pauseOperation(operationId: string): Promise<void> {
    // For now, pausing cancels the operation
    // Future: implement checkpoint-based resumable operations
    await this.cancelOperation(operationId, 'Paused by user');
  }

  /**
   * Trigger rollback for a completed operation
   */
  async rollbackOperation(operationId: string): Promise<void> {
    const operation = await this.getOperation(operationId);
    if (!operation) {
      throw new Error(`Operation not found: ${operationId}`);
    }

    if (!this.rollbackManager.canRollback(operation)) {
      throw new Error(`Cannot rollback operation: ${operationId}`);
    }

    const result = await this.rollbackManager.rollbackOperation(operation);
    this.emit('operation:rolledback', { operationId, result });
  }

  // ============================================================================
  // Queue Management
  // ============================================================================

  /**
   * Start the queue processor
   */
  startQueueProcessor(intervalMs: number = 5000): void {
    if (this.queueProcessorInterval) {
      clearInterval(this.queueProcessorInterval);
    }

    this.queueProcessorInterval = setInterval(() => {
      this.processNextInQueue();
    }, intervalMs);

    // Process immediately
    this.processNextInQueue();
  }

  /**
   * Stop the queue processor
   */
  stopQueueProcessor(): void {
    if (this.queueProcessorInterval) {
      clearInterval(this.queueProcessorInterval);
      this.queueProcessorInterval = null;
    }
  }

  private async processNextInQueue(): Promise<void> {
    if (this.isProcessingQueue) return;
    this.isProcessingQueue = true;

    try {
      const maxConcurrent = this.config.maxConcurrentOperations || 5;

      while (
        this.operationQueue.length > 0 &&
        this.activeOperations.size < maxConcurrent
      ) {
        const nextOp = this.operationQueue.shift();
        if (nextOp) {
          this.updateQueuePositions();
          await this.executeOperation(nextOp);
        }
      }
    } finally {
      this.isProcessingQueue = false;
    }
  }

  private sortQueue(): void {
    const priorityOrder: Record<BulkPriority, number> = {
      critical: 4,
      high: 3,
      normal: 2,
      low: 1,
    };

    this.operationQueue.sort((a, b) => {
      const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
      if (priorityDiff !== 0) return priorityDiff;
      return a.createdAt.getTime() - b.createdAt.getTime();
    });

    this.updateQueuePositions();
  }

  private updateQueuePositions(): void {
    this.operationQueue.forEach((op, index) => {
      op.queuePosition = index + 1;
    });
  }

  private estimateStartTime(): Date {
    // Estimate based on average operation time and queue position
    const avgOperationTimeMs = 5 * 60 * 1000; // 5 minutes default
    const position = this.operationQueue.length;
    return new Date(Date.now() + position * avgOperationTimeMs);
  }

  // ============================================================================
  // Query Methods
  // ============================================================================

  /**
   * Get an operation by ID
   */
  async getOperation(operationId: string): Promise<BulkOperation | null> {
    // Check active operations first
    const active = this.activeOperations.get(operationId);
    if (active) return active.operation;

    // Check queue
    const queued = this.operationQueue.find((op) => op.id === operationId);
    if (queued) return queued;

    // Load from database
    const { data, error } = await this.supabase
      .from('bulk_operations')
      .select('*')
      .eq('id', operationId)
      .single();

    if (error || !data) return null;

    return this.mapDbRowToOperation(data);
  }

  /**
   * List operations with filtering
   */
  async listOperations(query: BulkOperationQuery = {}): Promise<BulkOperationListResult> {
    let dbQuery = this.supabase.from('bulk_operations').select('*', { count: 'exact' });

    if (query.status) {
      const statuses = Array.isArray(query.status) ? query.status : [query.status];
      dbQuery = dbQuery.in('status', statuses);
    }

    if (query.type) {
      const types = Array.isArray(query.type) ? query.type : [query.type];
      dbQuery = dbQuery.in('type', types);
    }

    if (query.priority) {
      const priorities = Array.isArray(query.priority) ? query.priority : [query.priority];
      dbQuery = dbQuery.in('priority', priorities);
    }

    if (query.createdAfter) {
      dbQuery = dbQuery.gte('created_at', query.createdAfter.toISOString());
    }

    if (query.createdBefore) {
      dbQuery = dbQuery.lte('created_at', query.createdBefore.toISOString());
    }

    const sortBy = query.sortBy || 'createdAt';
    const sortOrder = query.sortOrder || 'desc';
    const dbSortColumn = sortBy === 'createdAt' ? 'created_at' : sortBy === 'updatedAt' ? 'updated_at' : sortBy;
    dbQuery = dbQuery.order(dbSortColumn, { ascending: sortOrder === 'asc' });

    const limit = query.limit || 20;
    const offset = query.offset || 0;
    dbQuery = dbQuery.range(offset, offset + limit - 1);

    const { data, count, error } = await dbQuery;

    if (error) {
      console.error('Failed to list operations:', error);
      return { operations: [], total: 0, limit, offset, hasMore: false };
    }

    const operations = (data || []).map((row) => this.mapDbRowToOperation(row));

    return {
      operations,
      total: count || 0,
      limit,
      offset,
      hasMore: offset + operations.length < (count || 0),
    };
  }

  /**
   * Get queue statistics
   */
  async getQueueStats(): Promise<BulkOperationQueueStats> {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const { data: recentOps } = await this.supabase
      .from('bulk_operations')
      .select('status, progress, created_at, started_at, completed_at')
      .gte('created_at', oneDayAgo.toISOString());

    const ops = recentOps || [];

    const completed = ops.filter((op) => op.status === 'completed');
    const failed = ops.filter((op) => op.status === 'failed');

    let avgProcessingTime = 0;
    let avgItems = 0;

    if (completed.length > 0) {
      const totalTime = completed.reduce((sum, op) => {
        if (op.started_at && op.completed_at) {
          return sum + (new Date(op.completed_at).getTime() - new Date(op.started_at).getTime());
        }
        return sum;
      }, 0);
      avgProcessingTime = totalTime / completed.length;

      const totalItems = completed.reduce((sum, op) => sum + (op.progress?.total || 0), 0);
      avgItems = totalItems / completed.length;
    }

    const oldestPending = this.operationQueue[0];
    const oldestAge = oldestPending
      ? Date.now() - oldestPending.createdAt.getTime()
      : 0;

    return {
      totalOperations: ops.length,
      pendingOperations: this.operationQueue.length,
      processingOperations: this.activeOperations.size,
      completedOperations24h: completed.length,
      failedOperations24h: failed.length,
      averageProcessingTimeMs: avgProcessingTime,
      averageItemsPerOperation: avgItems,
      oldestOperationAge: oldestAge,
    };
  }

  /**
   * Get rate limit status for platforms
   */
  getRateLimitStatus(platforms?: ConnectorName[]): PlatformRateLimitStatus[] {
    const targetPlatforms = platforms || Array.from(this.config.connectorConfigs.keys());

    return targetPlatforms.map((platform) => {
      const status = this.rateLimitManager.getStatus(platform);
      return {
        platform,
        isLimited: this.rateLimitManager.isRateLimited(platform),
        remainingRequests: status?.remaining || 0,
        resetAt: status?.resetAt,
        estimatedWaitMs: this.rateLimitManager.getEstimatedWaitTime(platform),
      };
    });
  }

  // ============================================================================
  // Persistence
  // ============================================================================

  private async persistOperation(operation: BulkOperation): Promise<void> {
    try {
      await this.supabase
        .from('bulk_operations')
        .upsert({
          id: operation.id,
          type: operation.type,
          status: operation.status,
          priority: operation.priority,
          config: operation.config,
          progress: operation.progress,
          result: operation.result,
          metadata: operation.metadata,
          created_at: operation.createdAt.toISOString(),
          updated_at: operation.updatedAt.toISOString(),
          started_at: operation.startedAt?.toISOString(),
          completed_at: operation.completedAt?.toISOString(),
        }, { onConflict: 'id' });

      // Persist items separately (for large operations)
      if (operation.items.length > 0) {
        const itemRows = operation.items.map((item) => ({
          id: item.id,
          operation_id: operation.id,
          operation_type: item.operationType,
          status: item.status,
          product_id: item.productId,
          external_id: item.externalId,
          data: item.data,
          target_platforms: item.targetPlatforms,
          platform_results: item.platformResults,
          retry_count: item.retryCount,
          error: item.error,
          created_at: item.createdAt.toISOString(),
          started_at: item.startedAt?.toISOString(),
          completed_at: item.completedAt?.toISOString(),
        }));

        await this.supabase.from('bulk_operation_items').upsert(itemRows, { onConflict: 'id' });
      }
    } catch (error) {
      console.error('Failed to persist operation:', error);
    }
  }

  private mapDbRowToOperation(row: Record<string, unknown>): BulkOperation {
    return {
      id: row.id as string,
      type: row.type as BulkOperationType,
      status: row.status as BulkOperationStatus,
      priority: row.priority as BulkPriority,
      config: row.config as BulkOperationConfig,
      items: [], // Items loaded separately if needed
      progress: row.progress as any,
      result: row.result as any,
      metadata: row.metadata as any,
      createdAt: new Date(row.created_at as string),
      updatedAt: new Date(row.updated_at as string),
      startedAt: row.started_at ? new Date(row.started_at as string) : undefined,
      completedAt: row.completed_at ? new Date(row.completed_at as string) : undefined,
    };
  }

  // ============================================================================
  // Helpers
  // ============================================================================

  private createBatches<T>(items: T[], batchSize: number): T[][] {
    const batches: T[][] = [];
    for (let i = 0; i < items.length; i += batchSize) {
      batches.push(items.slice(i, i + batchSize));
    }
    return batches;
  }

  private generateOperationId(): string {
    return `bulk-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  private registerPlatformRateLimits(): void {
    // Register known platform rate limits
    const platformLimits: Record<string, { requestsPerMinute: number }> = {
      printify: { requestsPerMinute: 60 },
      etsy: { requestsPerMinute: 30 },
      shopify: { requestsPerMinute: 40 },
      gumroad: { requestsPerMinute: 60 },
      woocommerce: { requestsPerMinute: 120 },
      'tiktok-shop': { requestsPerMinute: 30 },
      'creative-fabrica': { requestsPerMinute: 30 },
      redbubble: { requestsPerMinute: 10 }, // Browser-based, slower
      teepublic: { requestsPerMinute: 10 },
      society6: { requestsPerMinute: 10 },
      'amazon-kdp': { requestsPerMinute: 5 }, // Very slow, browser-based
    };

    for (const [platform, limits] of Object.entries(platformLimits)) {
      this.rateLimitManager.registerPlatform(platform, limits);
    }
  }

  /**
   * Subscribe to progress events
   */
  subscribeToProgress(
    operationId: string,
    handler: (event: any) => void
  ): () => void {
    return this.progressTracker.subscribe(operationId, handler);
  }
}

// ============================================================================
// Factory Functions
// ============================================================================

let instance: BulkProcessor | null = null;

/**
 * Get the global BulkProcessor instance
 */
export function getBulkProcessor(config: BulkProcessorConfig): BulkProcessor {
  if (!instance) {
    instance = new BulkProcessor(config);
  }
  return instance;
}

/**
 * Create a new BulkProcessor instance
 */
export function createBulkProcessor(config: BulkProcessorConfig): BulkProcessor {
  return new BulkProcessor(config);
}

export default BulkProcessor;
