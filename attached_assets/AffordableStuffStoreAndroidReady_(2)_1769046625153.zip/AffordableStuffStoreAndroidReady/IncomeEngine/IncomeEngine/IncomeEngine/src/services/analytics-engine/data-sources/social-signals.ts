/**
 * ============================================================================
 * SOCIAL SIGNALS DATA SOURCE
 * ============================================================================
 * Integration with Reddit, Twitter, and other social platforms for trend data
 */

import type { SocialSignal, DataPoint } from '../types.js';

export interface SocialSignalsConfig {
  redditEnabled: boolean;
  twitterEnabled: boolean;
  tiktokEnabled: boolean;
  cacheEnabled: boolean;
  cacheTtlMinutes: number;
  maxRetries: number;
}

export interface RedditConfig {
  clientId?: string;
  clientSecret?: string;
  userAgent: string;
}

export interface TwitterConfig {
  bearerToken?: string;
}

export interface SocialQuery {
  keyword: string;
  platforms: ('reddit' | 'twitter' | 'tiktok')[];
  subreddits?: string[];
  timeRange?: 'hour' | 'day' | 'week' | 'month';
}

interface CacheEntry {
  data: SocialSignal[];
  expiresAt: Date;
}

export class SocialSignalsDataSource {
  private readonly config: SocialSignalsConfig;
  private cache: Map<string, CacheEntry> = new Map();

  constructor(config?: Partial<SocialSignalsConfig>) {
    this.config = {
      redditEnabled: config?.redditEnabled ?? true,
      twitterEnabled: config?.twitterEnabled ?? true,
      tiktokEnabled: config?.tiktokEnabled ?? false,
      cacheEnabled: config?.cacheEnabled ?? true,
      cacheTtlMinutes: config?.cacheTtlMinutes ?? 30,
      maxRetries: config?.maxRetries ?? 3,
    };
  }

  /**
   * Fetch social signals for a keyword
   */
  async fetchSignals(query: SocialQuery): Promise<SocialSignal[]> {
    const cacheKey = this.getCacheKey(query);

    // Check cache
    if (this.config.cacheEnabled) {
      const cached = this.cache.get(cacheKey);
      if (cached && cached.expiresAt > new Date()) {
        return cached.data;
      }
    }

    const signals: SocialSignal[] = [];

    // Fetch from each enabled platform
    for (const platform of query.platforms) {
      try {
        let signal: SocialSignal | null = null;

        switch (platform) {
          case 'reddit':
            if (this.config.redditEnabled) {
              signal = await this.fetchRedditSignal(
                query.keyword,
                query.subreddits,
                query.timeRange
              );
            }
            break;
          case 'twitter':
            if (this.config.twitterEnabled) {
              signal = await this.fetchTwitterSignal(query.keyword, query.timeRange);
            }
            break;
          case 'tiktok':
            if (this.config.tiktokEnabled) {
              signal = await this.fetchTikTokSignal(query.keyword);
            }
            break;
        }

        if (signal) {
          signals.push(signal);
        }
      } catch (error) {
        console.warn(`Failed to fetch ${platform} signal:`, error);
      }
    }

    // Cache results
    if (this.config.cacheEnabled && signals.length > 0) {
      this.cache.set(cacheKey, {
        data: signals,
        expiresAt: new Date(
          Date.now() + this.config.cacheTtlMinutes * 60 * 1000
        ),
      });
    }

    return signals;
  }

  /**
   * Fetch signals for multiple keywords
   */
  async fetchMultiple(
    keywords: string[],
    platforms: ('reddit' | 'twitter' | 'tiktok')[] = ['reddit', 'twitter']
  ): Promise<Map<string, SocialSignal[]>> {
    const results = new Map<string, SocialSignal[]>();

    for (const keyword of keywords) {
      const signals = await this.fetchSignals({ keyword, platforms });
      results.set(keyword, signals);
    }

    return results;
  }

  /**
   * Fetch Reddit signal
   */
  private async fetchRedditSignal(
    keyword: string,
    subreddits?: string[],
    timeRange?: string
  ): Promise<SocialSignal> {
    // In production, this would use Reddit's API
    // For now, generate simulated data

    const signal = this.generateSimulatedRedditSignal(keyword);
    return signal;
  }

  /**
   * Generate simulated Reddit signal
   */
  private generateSimulatedRedditSignal(keyword: string): SocialSignal {
    // Simulate Reddit metrics based on keyword characteristics
    const keywordScore = this.calculateKeywordScore(keyword);

    const mentionCount = Math.round(
      50 + Math.random() * 200 * keywordScore
    );
    const sentimentScore = (Math.random() * 2 - 1) * 0.5; // -0.5 to 0.5
    const engagementScore =
      mentionCount > 100 ? 0.7 + Math.random() * 0.3 : 0.3 + Math.random() * 0.4;
    const influencerMentions = Math.round(mentionCount * 0.05 * Math.random());
    const viralPotential = this.calculateViralPotential(
      mentionCount,
      engagementScore,
      sentimentScore
    );

    return {
      platform: 'reddit',
      keyword,
      mentionCount,
      sentimentScore,
      engagementScore,
      influencerMentions,
      viralPotential,
      fetchedAt: new Date(),
    };
  }

  /**
   * Fetch Twitter signal
   */
  private async fetchTwitterSignal(
    keyword: string,
    timeRange?: string
  ): Promise<SocialSignal> {
    // In production, this would use Twitter's API v2
    // For now, generate simulated data

    return this.generateSimulatedTwitterSignal(keyword);
  }

  /**
   * Generate simulated Twitter signal
   */
  private generateSimulatedTwitterSignal(keyword: string): SocialSignal {
    const keywordScore = this.calculateKeywordScore(keyword);

    const mentionCount = Math.round(
      100 + Math.random() * 500 * keywordScore
    );
    const sentimentScore = (Math.random() * 2 - 1) * 0.6;
    const engagementScore =
      mentionCount > 200 ? 0.6 + Math.random() * 0.4 : 0.2 + Math.random() * 0.5;
    const influencerMentions = Math.round(mentionCount * 0.02 * Math.random());
    const viralPotential = this.calculateViralPotential(
      mentionCount,
      engagementScore,
      sentimentScore
    );

    return {
      platform: 'twitter',
      keyword,
      mentionCount,
      sentimentScore,
      engagementScore,
      influencerMentions,
      viralPotential,
      fetchedAt: new Date(),
    };
  }

  /**
   * Fetch TikTok signal
   */
  private async fetchTikTokSignal(keyword: string): Promise<SocialSignal> {
    // TikTok API access is limited
    // This would typically use web scraping or third-party APIs
    return this.generateSimulatedTikTokSignal(keyword);
  }

  /**
   * Generate simulated TikTok signal
   */
  private generateSimulatedTikTokSignal(keyword: string): SocialSignal {
    const keywordScore = this.calculateKeywordScore(keyword);

    // TikTok typically has higher virality potential
    const mentionCount = Math.round(
      200 + Math.random() * 1000 * keywordScore
    );
    const sentimentScore = 0.2 + Math.random() * 0.6; // Generally more positive
    const engagementScore = 0.5 + Math.random() * 0.5; // Higher engagement on TikTok
    const influencerMentions = Math.round(mentionCount * 0.01 * Math.random());
    const viralPotential = this.calculateViralPotential(
      mentionCount,
      engagementScore,
      sentimentScore
    ) * 1.2; // TikTok has higher viral potential

    return {
      platform: 'tiktok',
      keyword,
      mentionCount,
      sentimentScore,
      engagementScore: Math.min(1, engagementScore),
      influencerMentions,
      viralPotential: Math.min(1, viralPotential),
      fetchedAt: new Date(),
    };
  }

  /**
   * Calculate keyword score based on characteristics
   */
  private calculateKeywordScore(keyword: string): number {
    // Simple heuristic based on keyword characteristics
    let score = 0.5;

    // Longer keywords tend to be more specific/niche
    if (keyword.length > 15) score += 0.1;
    if (keyword.length < 5) score -= 0.1;

    // Common trending topics
    const trendingWords = [
      'ai', 'crypto', 'nft', 'sustainable', 'organic',
      'minimalist', 'vintage', 'custom', 'handmade', 'eco'
    ];
    for (const word of trendingWords) {
      if (keyword.toLowerCase().includes(word)) {
        score += 0.2;
        break;
      }
    }

    return Math.max(0.2, Math.min(1.5, score));
  }

  /**
   * Calculate viral potential
   */
  private calculateViralPotential(
    mentions: number,
    engagement: number,
    sentiment: number
  ): number {
    // Viral potential based on:
    // - Number of mentions (volume)
    // - Engagement rate
    // - Positive sentiment

    const volumeScore = Math.min(1, mentions / 500);
    const sentimentBoost = sentiment > 0 ? sentiment * 0.3 : 0;

    return Math.min(1, volumeScore * 0.3 + engagement * 0.5 + sentimentBoost + 0.1);
  }

  /**
   * Aggregate signals across platforms
   */
  aggregateSignals(signals: SocialSignal[]): {
    combinedScore: number;
    dominantPlatform: string;
    overallSentiment: number;
    viralPotential: number;
    totalMentions: number;
  } {
    if (signals.length === 0) {
      return {
        combinedScore: 0,
        dominantPlatform: 'none',
        overallSentiment: 0,
        viralPotential: 0,
        totalMentions: 0,
      };
    }

    const totalMentions = signals.reduce((sum, s) => sum + s.mentionCount, 0);

    // Weight by mention count
    let weightedSentiment = 0;
    let weightedViralPotential = 0;
    let weightedEngagement = 0;

    for (const signal of signals) {
      const weight = signal.mentionCount / totalMentions;
      weightedSentiment += signal.sentimentScore * weight;
      weightedViralPotential += signal.viralPotential * weight;
      weightedEngagement += signal.engagementScore * weight;
    }

    // Find dominant platform
    const dominantPlatform = signals.reduce((max, s) =>
      s.mentionCount > max.mentionCount ? s : max
    ).platform;

    // Combined score
    const combinedScore =
      weightedEngagement * 0.4 +
      weightedViralPotential * 0.4 +
      (weightedSentiment + 1) / 2 * 0.2;

    return {
      combinedScore,
      dominantPlatform,
      overallSentiment: weightedSentiment,
      viralPotential: weightedViralPotential,
      totalMentions,
    };
  }

  /**
   * Convert signals to DataPoints for time series analysis
   */
  toDataPoints(signals: SocialSignal[]): DataPoint[] {
    return signals.map(s => ({
      timestamp: s.fetchedAt,
      value: s.engagementScore * 100,
      source: s.platform,
      metadata: {
        mentionCount: s.mentionCount,
        sentimentScore: s.sentimentScore,
        viralPotential: s.viralPotential,
      },
    }));
  }

  /**
   * Get trending topics from social platforms
   */
  async getTrendingTopics(platforms?: ('reddit' | 'twitter' | 'tiktok')[]): Promise<{
    platform: string;
    topics: string[];
  }[]> {
    const targetPlatforms = platforms ?? ['reddit', 'twitter'];
    const results: { platform: string; topics: string[] }[] = [];

    if (targetPlatforms.includes('reddit') && this.config.redditEnabled) {
      results.push({
        platform: 'reddit',
        topics: this.getSimulatedRedditTrending(),
      });
    }

    if (targetPlatforms.includes('twitter') && this.config.twitterEnabled) {
      results.push({
        platform: 'twitter',
        topics: this.getSimulatedTwitterTrending(),
      });
    }

    if (targetPlatforms.includes('tiktok') && this.config.tiktokEnabled) {
      results.push({
        platform: 'tiktok',
        topics: this.getSimulatedTikTokTrending(),
      });
    }

    return results;
  }

  /**
   * Get simulated Reddit trending topics
   */
  private getSimulatedRedditTrending(): string[] {
    return [
      'side hustle ideas',
      'passive income',
      'etsy sellers',
      'print on demand',
      'digital products',
      'ai art',
      'dropshipping',
      'affiliate marketing',
      'online business',
      'e-commerce tips',
    ];
  }

  /**
   * Get simulated Twitter trending topics
   */
  private getSimulatedTwitterTrending(): string[] {
    return [
      'entrepreneur life',
      'small business saturday',
      'shop small',
      'handmade',
      'creator economy',
      'side gig',
      'work from home',
      'digital nomad',
      'startup',
      'ecommerce',
    ];
  }

  /**
   * Get simulated TikTok trending topics
   */
  private getSimulatedTikTokTrending(): string[] {
    return [
      'small business check',
      'pack an order with me',
      'day in my life entrepreneur',
      'side hustle tips',
      'passive income ideas',
      'print on demand tutorial',
      'etsy tips',
      'starting a business',
      'money making apps',
      'work from home jobs',
    ];
  }

  /**
   * Generate cache key
   */
  private getCacheKey(query: SocialQuery): string {
    return `${query.keyword}:${query.platforms.join(',')}:${query.timeRange ?? 'day'}`;
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.clear();
  }

  /**
   * Analyze sentiment for a keyword across platforms
   */
  async analyzeSentiment(keyword: string): Promise<{
    overall: number;
    byPlatform: Record<string, number>;
    trend: 'improving' | 'declining' | 'stable';
  }> {
    const signals = await this.fetchSignals({
      keyword,
      platforms: ['reddit', 'twitter'],
    });

    const byPlatform: Record<string, number> = {};
    let totalSentiment = 0;

    for (const signal of signals) {
      byPlatform[signal.platform] = signal.sentimentScore;
      totalSentiment += signal.sentimentScore;
    }

    const overall = signals.length > 0 ? totalSentiment / signals.length : 0;

    // Simulate trend (would need historical data in production)
    let trend: 'improving' | 'declining' | 'stable' = 'stable';
    if (overall > 0.2) trend = 'improving';
    else if (overall < -0.2) trend = 'declining';

    return { overall, byPlatform, trend };
  }
}

/**
 * Factory function
 */
export function createSocialSignalsDataSource(
  config?: Partial<SocialSignalsConfig>
): SocialSignalsDataSource {
  return new SocialSignalsDataSource(config);
}
