/**
 * ============================================================================
 * DEMAND PREDICTOR
 * ============================================================================
 * Product demand forecasting with driver analysis
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  DemandForecast,
  DemandDriver,
  PredictionPoint,
  DataPoint,
  ConfidenceLevel,
  SeasonalPattern,
} from '../types.js';
import {
  createMovingAverageModel,
  createExponentialSmoothingModel,
  createLinearRegressionModel,
  createSeasonalDecompositionModel,
  detectSeasonality,
} from '../ml-models/index.js';

export interface DemandPredictorConfig {
  defaultHorizon: number;
  minDataPoints: number;
  confidenceLevel: number;
  includePriceElasticity: boolean;
  includeSeasonalAdjustment: boolean;
}

export interface DemandDataPoint {
  productId: string;
  date: Date;
  units: number;
  price?: number;
  platform?: string;
  promotion?: boolean;
  category?: string;
}

export interface DemandDriverInput {
  name: string;
  type: 'price' | 'promotion' | 'season' | 'trend' | 'competition' | 'external';
  values: { date: Date; value: number }[];
}

export class DemandPredictor {
  private readonly config: DemandPredictorConfig;

  constructor(config?: Partial<DemandPredictorConfig>) {
    this.config = {
      defaultHorizon: config?.defaultHorizon ?? 30,
      minDataPoints: config?.minDataPoints ?? 14,
      confidenceLevel: config?.confidenceLevel ?? 0.95,
      includePriceElasticity: config?.includePriceElasticity ?? true,
      includeSeasonalAdjustment: config?.includeSeasonalAdjustment ?? true,
    };
  }

  /**
   * Generate demand forecast for a product
   */
  async forecast(
    demandData: DemandDataPoint[],
    productId: string,
    horizon: number = this.config.defaultHorizon,
    drivers?: DemandDriverInput[]
  ): Promise<DemandForecast> {
    // Filter and sort data
    const filteredData = demandData
      .filter(d => d.productId === productId)
      .sort((a, b) => a.date.getTime() - b.date.getTime());

    if (filteredData.length < this.config.minDataPoints) {
      throw new Error(
        `Insufficient data: need at least ${this.config.minDataPoints} data points, got ${filteredData.length}`
      );
    }

    // Convert to DataPoints
    const dataPoints: DataPoint[] = filteredData.map(d => ({
      timestamp: d.date,
      value: d.units,
      source: d.platform ?? 'internal',
    }));

    // Detect seasonality
    const seasonality = detectSeasonality(dataPoints, [7, 30, 365]);

    // Generate base forecast
    const baseForecast = await this.generateBaseForecast(
      dataPoints,
      horizon,
      seasonality
    );

    // Analyze demand drivers
    const demandDrivers = await this.analyzeDemandDrivers(
      filteredData,
      drivers
    );

    // Adjust forecast based on drivers
    const adjustedForecast = this.adjustForecastWithDrivers(
      baseForecast,
      demandDrivers
    );

    // Calculate total predicted units
    const predictedUnits = adjustedForecast.reduce(
      (sum, p) => sum + p.value,
      0
    );

    // Identify peak and low demand dates
    const { peakDates, lowDates } = this.identifyDemandExtremes(
      adjustedForecast
    );

    // Calculate confidence
    const confidence = this.calculateConfidence(dataPoints, seasonality);
    const confidenceLevel = this.getConfidenceLevel(confidence);

    return {
      id: uuidv4(),
      type: 'demand',
      targetEntity: `product:${productId}`,
      predictions: adjustedForecast,
      confidence,
      confidenceLevel,
      modelUsed: seasonality ? 'seasonal_decomposition' : 'exponential_smoothing',
      dataPointsUsed: dataPoints.length,
      generatedAt: new Date(),
      validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000),
      productId,
      predictedUnits: Math.round(predictedUnits),
      demandDrivers,
      peakDemandDates: peakDates,
      lowDemandDates: lowDates,
    };
  }

  /**
   * Generate base forecast using appropriate model
   */
  private async generateBaseForecast(
    dataPoints: DataPoint[],
    horizon: number,
    seasonality: { period: number; strength: number } | null
  ): Promise<PredictionPoint[]> {
    if (
      seasonality &&
      seasonality.strength > 0.3 &&
      dataPoints.length >= seasonality.period * 2
    ) {
      // Use seasonal decomposition
      const model = createSeasonalDecompositionModel({
        period: seasonality.period,
        method: 'additive',
      });
      const result = model.getModelResult(dataPoints, horizon);
      return result.predictions;
    }

    // Use exponential smoothing with trend
    const model = createExponentialSmoothingModel({
      alpha: 0.3,
      beta: 0.1,
    });
    const result = model.getModelResult(dataPoints, horizon);
    return result.predictions;
  }

  /**
   * Analyze demand drivers and their impact
   */
  private async analyzeDemandDrivers(
    demandData: DemandDataPoint[],
    externalDrivers?: DemandDriverInput[]
  ): Promise<DemandDriver[]> {
    const drivers: DemandDriver[] = [];

    // Analyze price elasticity
    if (this.config.includePriceElasticity) {
      const priceDriver = this.analyzePriceElasticity(demandData);
      if (priceDriver) {
        drivers.push(priceDriver);
      }
    }

    // Analyze promotional impact
    const promotionDriver = this.analyzePromotionalImpact(demandData);
    if (promotionDriver) {
      drivers.push(promotionDriver);
    }

    // Analyze day-of-week pattern
    const dayOfWeekDriver = this.analyzeDayOfWeekPattern(demandData);
    if (dayOfWeekDriver) {
      drivers.push(dayOfWeekDriver);
    }

    // Analyze trend
    const trendDriver = this.analyzeTrend(demandData);
    if (trendDriver) {
      drivers.push(trendDriver);
    }

    // Add external drivers if provided
    if (externalDrivers) {
      for (const driver of externalDrivers) {
        const impact = this.calculateDriverImpact(
          demandData,
          driver
        );
        if (impact !== null) {
          drivers.push({
            factor: driver.name,
            impact,
            confidence: 0.7,
            description: `External factor: ${driver.name}`,
          });
        }
      }
    }

    return drivers;
  }

  /**
   * Analyze price elasticity of demand
   */
  private analyzePriceElasticity(
    demandData: DemandDataPoint[]
  ): DemandDriver | null {
    const dataWithPrice = demandData.filter(d => d.price !== undefined);

    if (dataWithPrice.length < 10) {
      return null;
    }

    // Calculate price elasticity using simple regression
    const priceValues = dataWithPrice.map(d => d.price!);
    const demandValues = dataWithPrice.map(d => d.units);

    const avgPrice = priceValues.reduce((a, b) => a + b, 0) / priceValues.length;
    const avgDemand = demandValues.reduce((a, b) => a + b, 0) / demandValues.length;

    // Calculate price change vs demand change
    let sumPriceChange = 0;
    let sumDemandChange = 0;
    let count = 0;

    for (let i = 1; i < dataWithPrice.length; i++) {
      const priceChange =
        (dataWithPrice[i].price! - dataWithPrice[i - 1].price!) /
        dataWithPrice[i - 1].price!;
      const demandChange =
        (dataWithPrice[i].units - dataWithPrice[i - 1].units) /
        dataWithPrice[i - 1].units;

      if (Math.abs(priceChange) > 0.01) {
        sumPriceChange += priceChange;
        sumDemandChange += demandChange;
        count++;
      }
    }

    if (count === 0 || sumPriceChange === 0) {
      return null;
    }

    // Elasticity = % change in demand / % change in price
    const elasticity = sumDemandChange / sumPriceChange;

    return {
      factor: 'price',
      impact: Math.max(-1, Math.min(1, elasticity * -0.5)), // Normalize and invert
      confidence: Math.min(1, count / 20),
      description:
        elasticity < 0
          ? 'Higher prices tend to decrease demand'
          : 'Demand is relatively price inelastic',
    };
  }

  /**
   * Analyze promotional impact
   */
  private analyzePromotionalImpact(
    demandData: DemandDataPoint[]
  ): DemandDriver | null {
    const promoData = demandData.filter(d => d.promotion === true);
    const nonPromoData = demandData.filter(d => d.promotion !== true);

    if (promoData.length < 5 || nonPromoData.length < 5) {
      return null;
    }

    const avgPromoUnits =
      promoData.reduce((sum, d) => sum + d.units, 0) / promoData.length;
    const avgNonPromoUnits =
      nonPromoData.reduce((sum, d) => sum + d.units, 0) / nonPromoData.length;

    const lift =
      avgNonPromoUnits > 0
        ? (avgPromoUnits - avgNonPromoUnits) / avgNonPromoUnits
        : 0;

    return {
      factor: 'promotion',
      impact: Math.max(-1, Math.min(1, lift)),
      confidence: Math.min(1, (promoData.length + nonPromoData.length) / 30),
      description:
        lift > 0
          ? `Promotions increase demand by ~${Math.round(lift * 100)}%`
          : 'Promotions have minimal impact on demand',
    };
  }

  /**
   * Analyze day-of-week demand pattern
   */
  private analyzeDayOfWeekPattern(
    demandData: DemandDataPoint[]
  ): DemandDriver | null {
    if (demandData.length < 14) {
      return null;
    }

    const dayDemand: number[][] = [[], [], [], [], [], [], []];

    for (const d of demandData) {
      const dayOfWeek = d.date.getDay();
      dayDemand[dayOfWeek].push(d.units);
    }

    const dayAverages = dayDemand.map(day =>
      day.length > 0 ? day.reduce((a, b) => a + b, 0) / day.length : 0
    );

    const overallAvg =
      demandData.reduce((sum, d) => sum + d.units, 0) / demandData.length;

    // Calculate day-of-week effect
    const maxDayAvg = Math.max(...dayAverages);
    const minDayAvg = Math.min(...dayAverages.filter(a => a > 0));
    const variation = overallAvg > 0 ? (maxDayAvg - minDayAvg) / overallAvg : 0;

    if (variation < 0.1) {
      return null;
    }

    const dayNames = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ];
    const peakDay = dayNames[dayAverages.indexOf(maxDayAvg)];

    return {
      factor: 'day_of_week',
      impact: Math.min(1, variation),
      confidence: 0.8,
      description: `Demand peaks on ${peakDay}s with ${Math.round(variation * 100)}% variation`,
    };
  }

  /**
   * Analyze overall trend
   */
  private analyzeTrend(demandData: DemandDataPoint[]): DemandDriver | null {
    if (demandData.length < 14) {
      return null;
    }

    const dataPoints: DataPoint[] = demandData.map(d => ({
      timestamp: d.date,
      value: d.units,
      source: 'internal',
    }));

    const lrModel = createLinearRegressionModel();
    const trend = lrModel.detectTrend(dataPoints);

    if (!trend.isSignificant) {
      return null;
    }

    return {
      factor: 'trend',
      impact: trend.direction === 'rising' ? trend.strength : -trend.strength,
      confidence: trend.coefficients.rSquared,
      description:
        trend.direction === 'rising'
          ? `Demand is trending upward (${Math.round(trend.changePerPeriod)} units/day)`
          : `Demand is trending downward (${Math.round(Math.abs(trend.changePerPeriod))} units/day)`,
    };
  }

  /**
   * Calculate driver impact from external data
   */
  private calculateDriverImpact(
    demandData: DemandDataPoint[],
    driver: DemandDriverInput
  ): number | null {
    // Match driver values to demand data by date
    const matched: { demand: number; driverValue: number }[] = [];

    for (const demand of demandData) {
      const driverValue = driver.values.find(
        v =>
          v.date.getFullYear() === demand.date.getFullYear() &&
          v.date.getMonth() === demand.date.getMonth() &&
          v.date.getDate() === demand.date.getDate()
      );

      if (driverValue) {
        matched.push({ demand: demand.units, driverValue: driverValue.value });
      }
    }

    if (matched.length < 10) {
      return null;
    }

    // Calculate correlation
    const avgDemand =
      matched.reduce((sum, m) => sum + m.demand, 0) / matched.length;
    const avgDriver =
      matched.reduce((sum, m) => sum + m.driverValue, 0) / matched.length;

    let numerator = 0;
    let demandDenominator = 0;
    let driverDenominator = 0;

    for (const m of matched) {
      numerator += (m.demand - avgDemand) * (m.driverValue - avgDriver);
      demandDenominator += Math.pow(m.demand - avgDemand, 2);
      driverDenominator += Math.pow(m.driverValue - avgDriver, 2);
    }

    const denominator = Math.sqrt(demandDenominator * driverDenominator);
    if (denominator === 0) {
      return null;
    }

    return numerator / denominator;
  }

  /**
   * Adjust forecast based on demand drivers
   */
  private adjustForecastWithDrivers(
    baseForecast: PredictionPoint[],
    drivers: DemandDriver[]
  ): PredictionPoint[] {
    // Calculate overall adjustment factor from significant drivers
    const significantDrivers = drivers.filter(d => Math.abs(d.impact) > 0.1);

    if (significantDrivers.length === 0) {
      return baseForecast;
    }

    // Simple weighted average of driver impacts
    const totalImpact = significantDrivers.reduce(
      (sum, d) => sum + d.impact * d.confidence,
      0
    );
    const totalWeight = significantDrivers.reduce(
      (sum, d) => sum + d.confidence,
      0
    );
    const avgImpact = totalWeight > 0 ? totalImpact / totalWeight : 0;

    // Apply adjustment (limited to +/- 50%)
    const adjustmentFactor = 1 + Math.max(-0.5, Math.min(0.5, avgImpact));

    return baseForecast.map(p => ({
      ...p,
      value: p.value * adjustmentFactor,
      lowerBound: p.lowerBound * adjustmentFactor,
      upperBound: p.upperBound * adjustmentFactor,
    }));
  }

  /**
   * Identify peak and low demand dates
   */
  private identifyDemandExtremes(
    forecast: PredictionPoint[]
  ): { peakDates: Date[]; lowDates: Date[] } {
    if (forecast.length === 0) {
      return { peakDates: [], lowDates: [] };
    }

    const avgDemand =
      forecast.reduce((sum, p) => sum + p.value, 0) / forecast.length;
    const threshold = avgDemand * 0.3;

    const peakDates = forecast
      .filter(p => p.value > avgDemand + threshold)
      .map(p => p.date);

    const lowDates = forecast
      .filter(p => p.value < avgDemand - threshold)
      .map(p => p.date);

    return { peakDates, lowDates };
  }

  /**
   * Calculate forecast confidence
   */
  private calculateConfidence(
    dataPoints: DataPoint[],
    seasonality: { period: number; strength: number } | null
  ): number {
    let confidence = 0;

    // Data quantity score (0-0.4)
    const dataScore = Math.min(0.4, dataPoints.length / 100);
    confidence += dataScore;

    // Data consistency score (0-0.3)
    const values = dataPoints.map(d => d.value);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance =
      values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
    const cv = mean > 0 ? Math.sqrt(variance) / mean : 1;
    const consistencyScore = Math.max(0, 0.3 * (1 - cv));
    confidence += consistencyScore;

    // Seasonality detection score (0-0.3)
    if (seasonality && seasonality.strength > 0.3) {
      confidence += 0.3 * seasonality.strength;
    } else {
      confidence += 0.15; // Partial credit if no clear seasonality
    }

    return Math.min(1, confidence);
  }

  /**
   * Get confidence level label
   */
  private getConfidenceLevel(confidence: number): ConfidenceLevel {
    if (confidence >= 0.9) return 'very_high';
    if (confidence >= 0.75) return 'high';
    if (confidence >= 0.5) return 'medium';
    return 'low';
  }

  /**
   * Forecast demand for multiple products
   */
  async forecastMultiple(
    demandData: DemandDataPoint[],
    productIds: string[],
    horizon: number = this.config.defaultHorizon
  ): Promise<DemandForecast[]> {
    const forecasts: DemandForecast[] = [];

    for (const productId of productIds) {
      try {
        const forecast = await this.forecast(demandData, productId, horizon);
        forecasts.push(forecast);
      } catch (error) {
        console.warn(`Failed to forecast demand for ${productId}:`, error);
      }
    }

    return forecasts;
  }

  /**
   * Compare demand across products
   */
  async compareDemand(
    demandData: DemandDataPoint[],
    productIds: string[]
  ): Promise<{
    productId: string;
    avgDailyDemand: number;
    trend: 'rising' | 'falling' | 'stable';
    volatility: number;
  }[]> {
    const comparisons = [];

    for (const productId of productIds) {
      const productData = demandData
        .filter(d => d.productId === productId)
        .sort((a, b) => a.date.getTime() - b.date.getTime());

      if (productData.length < 7) continue;

      const values = productData.map(d => d.units);
      const avgDailyDemand = values.reduce((a, b) => a + b, 0) / values.length;

      // Calculate trend
      const firstHalf = values.slice(0, Math.floor(values.length / 2));
      const secondHalf = values.slice(Math.floor(values.length / 2));
      const firstAvg = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length;
      const secondAvg = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length;

      let trend: 'rising' | 'falling' | 'stable';
      const changePercent = (secondAvg - firstAvg) / firstAvg;
      if (changePercent > 0.1) {
        trend = 'rising';
      } else if (changePercent < -0.1) {
        trend = 'falling';
      } else {
        trend = 'stable';
      }

      // Calculate volatility (coefficient of variation)
      const mean = avgDailyDemand;
      const variance =
        values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
      const volatility = mean > 0 ? Math.sqrt(variance) / mean : 0;

      comparisons.push({
        productId,
        avgDailyDemand,
        trend,
        volatility,
      });
    }

    // Sort by average demand descending
    return comparisons.sort((a, b) => b.avgDailyDemand - a.avgDailyDemand);
  }
}

/**
 * Factory function for demand predictor
 */
export function createDemandPredictor(
  config?: Partial<DemandPredictorConfig>
): DemandPredictor {
  return new DemandPredictor(config);
}
