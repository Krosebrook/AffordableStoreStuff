/**
 * ============================================================================
 * BULK OPERATIONS SERVICE INDEX
 * Batch processing for 100+ products with queue support, progress tracking,
 * and rollback capabilities
 * ============================================================================
 */

// Types
export * from './types';

// Progress Tracker
export {
  ProgressTracker,
  getProgressTracker,
  createProgressTracker,
} from './progress-tracker';

// Rollback Manager
export {
  RollbackManager,
  getRollbackManager,
  createRollbackManager,
  type RollbackResult,
  type RollbackError,
  type RollbackManagerConfig,
} from './rollback-manager';

// Bulk Processor (Main Entry Point)
export {
  BulkProcessor,
  getBulkProcessor,
  createBulkProcessor,
  type BulkProcessorConfig,
} from './bulk-processor';

// Re-export defaults
export { default as progressTracker } from './progress-tracker';
export { default as rollbackManager } from './rollback-manager';
export { default as bulkProcessor } from './bulk-processor';

// ============================================================================
// Quick Start Usage Example
// ============================================================================
/*
import {
  createBulkProcessor,
  BulkProcessorConfig,
  CreateBulkOperationRequest,
} from './services/bulk-operations';
import { ConnectorName, ConnectorFactoryConfig } from './connectors';

// 1. Configure the bulk processor
const config: BulkProcessorConfig = {
  supabaseUrl: process.env.SUPABASE_URL!,
  supabaseKey: process.env.SUPABASE_SERVICE_KEY!,
  connectorConfigs: new Map<ConnectorName, ConnectorFactoryConfig>([
    ['printify', { credentials: { apiKey: process.env.PRINTIFY_API_KEY } }],
    ['etsy', { credentials: { accessToken: process.env.ETSY_ACCESS_TOKEN } }],
  ]),
  maxConcurrentOperations: 3,
};

const processor = createBulkProcessor(config);

// 2. Create a bulk operation
const request: CreateBulkOperationRequest = {
  type: 'create',
  targetPlatforms: ['printify', 'etsy'],
  items: products.map(product => ({
    data: {
      title: product.title,
      description: product.description,
      productType: 't-shirt',
      images: product.images,
      pricing: { price: product.price, taxable: true },
      tags: product.tags,
    },
  })),
  config: {
    batchSize: 10,
    concurrency: 3,
    continueOnError: true,
    rollbackOnFailure: false,
    notifyOnCompletion: true,
    webhookUrl: 'https://your-webhook.com/bulk-complete',
  },
  priority: 'normal',
};

const operation = await processor.createOperation(request);

// 3. Subscribe to progress updates
const unsubscribe = processor.subscribeToProgress(operation.id, (event) => {
  console.log(`Progress: ${event.data.progress?.percent}%`);
});

// 4. Start the operation
await processor.startOperation(operation.id);

// 5. Check status
const status = await processor.getOperation(operation.id);
console.log(`Status: ${status?.status}, Result:`, status?.result);

// 6. Clean up
unsubscribe();
*/
