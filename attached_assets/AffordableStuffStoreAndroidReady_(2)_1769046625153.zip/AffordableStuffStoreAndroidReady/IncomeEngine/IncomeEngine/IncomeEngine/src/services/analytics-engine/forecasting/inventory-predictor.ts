/**
 * ============================================================================
 * INVENTORY PREDICTOR
 * ============================================================================
 * Stock level forecasting and reorder point optimization
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  InventoryForecast,
  InventoryLevel,
  PredictionPoint,
  DataPoint,
  ConfidenceLevel,
} from '../types.js';
import {
  createMovingAverageModel,
  createExponentialSmoothingModel,
  detectSeasonality,
} from '../ml-models/index.js';

export interface InventoryPredictorConfig {
  defaultLeadTimeDays: number;
  safetyStockMultiplier: number;
  reorderPointBuffer: number;
  minDataPoints: number;
  defaultServiceLevel: number; // Target service level (e.g., 0.95 for 95%)
}

export interface InventoryDataPoint {
  productId: string;
  platform: string;
  date: Date;
  stockLevel: number;
  unitsSold: number;
  unitsReceived?: number;
}

export interface StockoutPrediction {
  productId: string;
  platform: string;
  currentStock: number;
  dailyDemand: number;
  predictedStockoutDate: Date | null;
  daysUntilStockout: number | null;
  confidence: number;
}

export interface ReorderRecommendation {
  productId: string;
  platform: string;
  currentStock: number;
  reorderPoint: number;
  suggestedOrderQuantity: number;
  suggestedOrderDate: Date;
  estimatedCost?: number;
  urgency: 'low' | 'medium' | 'high' | 'critical';
}

export class InventoryPredictor {
  private readonly config: InventoryPredictorConfig;

  constructor(config?: Partial<InventoryPredictorConfig>) {
    this.config = {
      defaultLeadTimeDays: config?.defaultLeadTimeDays ?? 7,
      safetyStockMultiplier: config?.safetyStockMultiplier ?? 1.5,
      reorderPointBuffer: config?.reorderPointBuffer ?? 0.2,
      minDataPoints: config?.minDataPoints ?? 14,
      defaultServiceLevel: config?.defaultServiceLevel ?? 0.95,
    };
  }

  /**
   * Generate inventory forecast for a product
   */
  async forecast(
    inventoryData: InventoryDataPoint[],
    productId: string,
    platform: string,
    horizon: number = 30
  ): Promise<InventoryForecast> {
    // Filter and sort data
    const filteredData = inventoryData
      .filter(d => d.productId === productId && d.platform === platform)
      .sort((a, b) => a.date.getTime() - b.date.getTime());

    if (filteredData.length < this.config.minDataPoints) {
      throw new Error(
        `Insufficient data: need at least ${this.config.minDataPoints} data points, got ${filteredData.length}`
      );
    }

    // Convert to DataPoints for demand forecasting
    const demandData: DataPoint[] = filteredData.map(d => ({
      timestamp: d.date,
      value: d.unitsSold,
      source: 'internal',
    }));

    // Forecast daily demand
    const demandForecast = await this.forecastDemand(demandData, horizon);

    // Get current stock level
    const currentStock = filteredData[filteredData.length - 1].stockLevel;

    // Predict stockout date
    const stockoutPrediction = this.predictStockout(
      currentStock,
      demandForecast
    );

    // Calculate reorder recommendations
    const avgDailyDemand = this.calculateAverageDemand(demandData);
    const suggestedReorderDate = this.calculateReorderDate(
      currentStock,
      avgDailyDemand,
      this.config.defaultLeadTimeDays
    );

    const suggestedReorderQuantity = this.calculateReorderQuantity(
      avgDailyDemand,
      demandData
    );

    // Calculate confidence
    const confidence = this.calculateForecastConfidence(demandData);
    const confidenceLevel = this.getConfidenceLevel(confidence);

    // Create inventory forecast for stock levels
    const stockPredictions = this.predictStockLevels(
      currentStock,
      demandForecast
    );

    return {
      id: uuidv4(),
      type: 'inventory',
      targetEntity: `${productId}:${platform}`,
      predictions: stockPredictions,
      confidence,
      confidenceLevel,
      modelUsed: 'exponential_smoothing',
      dataPointsUsed: filteredData.length,
      generatedAt: new Date(),
      validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000),
      productId,
      platform,
      currentStock,
      predictedStockout: stockoutPrediction,
      suggestedReorderDate,
      suggestedReorderQuantity,
      dailyDemandForecast: demandForecast,
    };
  }

  /**
   * Forecast daily demand
   */
  private async forecastDemand(
    demandData: DataPoint[],
    horizon: number
  ): Promise<PredictionPoint[]> {
    // Detect seasonality
    const seasonality = detectSeasonality(demandData, [7]);

    if (seasonality && seasonality.strength > 0.3 && demandData.length >= 14) {
      // Use Holt-Winters for seasonal data
      const model = createExponentialSmoothingModel({
        alpha: 0.3,
        beta: 0.1,
        gamma: 0.1,
        seasonalPeriods: seasonality.period,
        seasonalType: 'additive',
      });
      const result = model.getModelResult(demandData, horizon);
      return result.predictions;
    }

    // Use exponential smoothing for non-seasonal data
    const model = createExponentialSmoothingModel({
      alpha: 0.3,
      beta: 0.1,
    });
    const result = model.getModelResult(demandData, horizon);
    return result.predictions;
  }

  /**
   * Predict when stockout will occur
   */
  private predictStockout(
    currentStock: number,
    demandForecast: PredictionPoint[]
  ): Date | null {
    let remainingStock = currentStock;

    for (const prediction of demandForecast) {
      remainingStock -= prediction.value;
      if (remainingStock <= 0) {
        return prediction.date;
      }
    }

    return null; // No stockout predicted within horizon
  }

  /**
   * Predict stock levels over the forecast horizon
   */
  private predictStockLevels(
    currentStock: number,
    demandForecast: PredictionPoint[]
  ): PredictionPoint[] {
    let runningStock = currentStock;

    return demandForecast.map(demand => {
      runningStock -= demand.value;
      const stockLevel = Math.max(0, runningStock);

      // Calculate bounds based on demand uncertainty
      const demandUncertainty = demand.upperBound - demand.value;
      const lowerStock = Math.max(0, runningStock - demandUncertainty);
      const upperStock = Math.max(0, runningStock + demandUncertainty);

      return {
        date: demand.date,
        value: stockLevel,
        lowerBound: lowerStock,
        upperBound: upperStock,
      };
    });
  }

  /**
   * Calculate average daily demand
   */
  private calculateAverageDemand(demandData: DataPoint[]): number {
    if (demandData.length === 0) return 0;
    return demandData.reduce((sum, d) => sum + d.value, 0) / demandData.length;
  }

  /**
   * Calculate demand standard deviation
   */
  private calculateDemandStdDev(demandData: DataPoint[]): number {
    if (demandData.length < 2) return 0;
    const mean = this.calculateAverageDemand(demandData);
    const variance =
      demandData.reduce((sum, d) => sum + Math.pow(d.value - mean, 2), 0) /
      demandData.length;
    return Math.sqrt(variance);
  }

  /**
   * Calculate when to place reorder
   */
  private calculateReorderDate(
    currentStock: number,
    avgDailyDemand: number,
    leadTimeDays: number
  ): Date | undefined {
    if (avgDailyDemand <= 0) return undefined;

    // Calculate reorder point with safety stock
    const safetyStock = avgDailyDemand * leadTimeDays * this.config.safetyStockMultiplier;
    const reorderPoint = avgDailyDemand * leadTimeDays + safetyStock;

    // Calculate days until reorder point
    const daysUntilReorder = (currentStock - reorderPoint) / avgDailyDemand;

    if (daysUntilReorder <= 0) {
      // Should reorder now
      return new Date();
    }

    const reorderDate = new Date();
    reorderDate.setDate(reorderDate.getDate() + Math.floor(daysUntilReorder));
    return reorderDate;
  }

  /**
   * Calculate optimal reorder quantity using Economic Order Quantity (EOQ)
   */
  private calculateReorderQuantity(
    avgDailyDemand: number,
    demandData: DataPoint[]
  ): number {
    // Simplified EOQ calculation
    const annualDemand = avgDailyDemand * 365;

    // Assume holding cost is 20% of item value per year
    // and ordering cost is fixed at 50 units
    const orderingCost = 50;
    const holdingCostRate = 0.2;
    const estimatedUnitCost = 10; // Default assumption

    const holdingCost = estimatedUnitCost * holdingCostRate;

    // EOQ formula: sqrt(2 * D * S / H)
    const eoq = Math.sqrt((2 * annualDemand * orderingCost) / holdingCost);

    // Add safety stock buffer
    const stdDev = this.calculateDemandStdDev(demandData);
    const safetyStock = stdDev * this.config.safetyStockMultiplier;

    return Math.ceil(eoq + safetyStock);
  }

  /**
   * Calculate forecast confidence
   */
  private calculateForecastConfidence(demandData: DataPoint[]): number {
    // Confidence based on:
    // 1. Amount of historical data
    // 2. Stability of demand pattern

    const dataPoints = demandData.length;
    const dataConfidence = Math.min(1, dataPoints / 30);

    const stdDev = this.calculateDemandStdDev(demandData);
    const mean = this.calculateAverageDemand(demandData);
    const cv = mean > 0 ? stdDev / mean : 1; // Coefficient of variation
    const stabilityConfidence = Math.max(0, 1 - cv);

    return dataConfidence * 0.4 + stabilityConfidence * 0.6;
  }

  /**
   * Get confidence level label
   */
  private getConfidenceLevel(confidence: number): ConfidenceLevel {
    if (confidence >= 0.9) return 'very_high';
    if (confidence >= 0.75) return 'high';
    if (confidence >= 0.5) return 'medium';
    return 'low';
  }

  /**
   * Get all products at risk of stockout
   */
  async getStockoutRisks(
    inventoryData: InventoryDataPoint[],
    daysThreshold: number = 14
  ): Promise<StockoutPrediction[]> {
    // Group by product and platform
    const grouped = this.groupByProductPlatform(inventoryData);
    const predictions: StockoutPrediction[] = [];

    for (const [key, data] of grouped) {
      const [productId, platform] = key.split(':');

      try {
        const sortedData = data.sort(
          (a, b) => a.date.getTime() - b.date.getTime()
        );

        const currentStock = sortedData[sortedData.length - 1].stockLevel;
        const demandData: DataPoint[] = sortedData.map(d => ({
          timestamp: d.date,
          value: d.unitsSold,
          source: 'internal',
        }));

        const avgDailyDemand = this.calculateAverageDemand(demandData);
        const daysUntilStockout =
          avgDailyDemand > 0 ? currentStock / avgDailyDemand : null;

        const stockoutDate =
          daysUntilStockout !== null
            ? new Date(Date.now() + daysUntilStockout * 24 * 60 * 60 * 1000)
            : null;

        const confidence = this.calculateForecastConfidence(demandData);

        if (daysUntilStockout !== null && daysUntilStockout <= daysThreshold) {
          predictions.push({
            productId,
            platform,
            currentStock,
            dailyDemand: avgDailyDemand,
            predictedStockoutDate: stockoutDate,
            daysUntilStockout,
            confidence,
          });
        }
      } catch (error) {
        console.warn(`Failed to analyze ${key}:`, error);
      }
    }

    // Sort by urgency (days until stockout)
    return predictions.sort((a, b) => {
      const aDays = a.daysUntilStockout ?? Infinity;
      const bDays = b.daysUntilStockout ?? Infinity;
      return aDays - bDays;
    });
  }

  /**
   * Get reorder recommendations for all products
   */
  async getReorderRecommendations(
    inventoryData: InventoryDataPoint[],
    inventoryLevels?: InventoryLevel[]
  ): Promise<ReorderRecommendation[]> {
    const grouped = this.groupByProductPlatform(inventoryData);
    const recommendations: ReorderRecommendation[] = [];

    for (const [key, data] of grouped) {
      const [productId, platform] = key.split(':');

      try {
        const sortedData = data.sort(
          (a, b) => a.date.getTime() - b.date.getTime()
        );

        const currentStock = sortedData[sortedData.length - 1].stockLevel;
        const demandData: DataPoint[] = sortedData.map(d => ({
          timestamp: d.date,
          value: d.unitsSold,
          source: 'internal',
        }));

        const avgDailyDemand = this.calculateAverageDemand(demandData);

        // Get lead time from inventory levels if available
        const inventoryLevel = inventoryLevels?.find(
          l => l.productId === productId && l.platform === platform
        );
        const leadTime =
          inventoryLevel?.leadTimeDays ?? this.config.defaultLeadTimeDays;

        // Calculate reorder point
        const safetyStock =
          avgDailyDemand * leadTime * this.config.safetyStockMultiplier;
        const reorderPoint = avgDailyDemand * leadTime + safetyStock;

        // Only recommend if below or near reorder point
        const buffer = reorderPoint * this.config.reorderPointBuffer;
        if (currentStock <= reorderPoint + buffer) {
          const suggestedOrderDate = this.calculateReorderDate(
            currentStock,
            avgDailyDemand,
            leadTime
          );

          const suggestedOrderQuantity = this.calculateReorderQuantity(
            avgDailyDemand,
            demandData
          );

          // Determine urgency
          const daysUntilStockout =
            avgDailyDemand > 0 ? currentStock / avgDailyDemand : Infinity;
          let urgency: 'low' | 'medium' | 'high' | 'critical';

          if (daysUntilStockout <= leadTime) {
            urgency = 'critical';
          } else if (daysUntilStockout <= leadTime * 1.5) {
            urgency = 'high';
          } else if (daysUntilStockout <= leadTime * 2) {
            urgency = 'medium';
          } else {
            urgency = 'low';
          }

          recommendations.push({
            productId,
            platform,
            currentStock,
            reorderPoint: Math.ceil(reorderPoint),
            suggestedOrderQuantity,
            suggestedOrderDate: suggestedOrderDate ?? new Date(),
            urgency,
          });
        }
      } catch (error) {
        console.warn(`Failed to analyze ${key}:`, error);
      }
    }

    // Sort by urgency
    const urgencyOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    return recommendations.sort(
      (a, b) => urgencyOrder[a.urgency] - urgencyOrder[b.urgency]
    );
  }

  /**
   * Group inventory data by product and platform
   */
  private groupByProductPlatform(
    data: InventoryDataPoint[]
  ): Map<string, InventoryDataPoint[]> {
    const groups = new Map<string, InventoryDataPoint[]>();

    for (const item of data) {
      const key = `${item.productId}:${item.platform}`;
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key)!.push(item);
    }

    return groups;
  }

  /**
   * Analyze inventory health
   */
  async analyzeInventoryHealth(
    inventoryData: InventoryDataPoint[]
  ): Promise<{
    totalProducts: number;
    healthyProducts: number;
    atRiskProducts: number;
    criticalProducts: number;
    averageDaysOfStock: number;
    totalValue?: number;
  }> {
    const grouped = this.groupByProductPlatform(inventoryData);
    let healthyCount = 0;
    let atRiskCount = 0;
    let criticalCount = 0;
    let totalDaysOfStock = 0;

    for (const [_, data] of grouped) {
      const sortedData = data.sort(
        (a, b) => a.date.getTime() - b.date.getTime()
      );
      const currentStock = sortedData[sortedData.length - 1].stockLevel;
      const demandData: DataPoint[] = sortedData.map(d => ({
        timestamp: d.date,
        value: d.unitsSold,
        source: 'internal',
      }));

      const avgDailyDemand = this.calculateAverageDemand(demandData);
      const daysOfStock =
        avgDailyDemand > 0 ? currentStock / avgDailyDemand : Infinity;

      totalDaysOfStock += Math.min(daysOfStock, 365);

      if (daysOfStock <= 7) {
        criticalCount++;
      } else if (daysOfStock <= 14) {
        atRiskCount++;
      } else {
        healthyCount++;
      }
    }

    const totalProducts = grouped.size;

    return {
      totalProducts,
      healthyProducts: healthyCount,
      atRiskProducts: atRiskCount,
      criticalProducts: criticalCount,
      averageDaysOfStock:
        totalProducts > 0 ? totalDaysOfStock / totalProducts : 0,
    };
  }
}

/**
 * Factory function for inventory predictor
 */
export function createInventoryPredictor(
  config?: Partial<InventoryPredictorConfig>
): InventoryPredictor {
  return new InventoryPredictor(config);
}
