/**
 * ============================================================================
 * DATA SOURCES - INDEX
 * ============================================================================
 * Export all data source modules
 */

// Google Trends
export {
  GoogleTrendsDataSource,
  createGoogleTrendsDataSource,
  type GoogleTrendsConfig,
  type TrendsRequest,
} from './google-trends.js';

// Social Signals
export {
  SocialSignalsDataSource,
  createSocialSignalsDataSource,
  type SocialSignalsConfig,
  type SocialQuery,
  type RedditConfig,
  type TwitterConfig,
} from './social-signals.js';

// Internal Data
export {
  InternalDataSource,
  createInternalDataSource,
  type InternalDataConfig,
  type DateRange,
  type SalesQuery,
} from './internal-data.js';

// Re-export types
export type {
  GoogleTrendsData,
  SocialSignal,
  DataPoint,
  TimeSeriesData,
  InternalSalesData,
} from '../types.js';
