/**
 * ============================================================================
 * TIMING SUGGESTER
 * ============================================================================
 * Optimal timing recommendations for publishing, promotions, and activities
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  TimingRecommendation,
  ActionItem,
  ConfidenceLevel,
  DataPoint,
} from '../types.js';

export interface TimingSuggesterConfig {
  timezone: string;
  minDataPoints: number;
  peakThreshold: number; // Multiplier above average to be considered peak
  troughThreshold: number; // Multiplier below average to be considered trough
}

export interface ActivityData {
  activity: 'publish' | 'promote' | 'email' | 'social' | 'restock' | 'custom';
  timestamp: Date;
  metric: number; // Could be sales, views, engagement, etc.
  platform?: string;
}

export interface TimeSlotScore {
  dayOfWeek: number; // 0-6 (Sunday-Saturday)
  hourOfDay: number; // 0-23
  score: number; // 0-100
  sampleSize: number;
}

export interface TimingAnalysis {
  activity: string;
  optimalSlots: TimeSlotScore[];
  worstSlots: TimeSlotScore[];
  peakDays: number[];
  peakHours: number[];
  weekdayVsWeekend: {
    weekday: number;
    weekend: number;
    better: 'weekday' | 'weekend' | 'equal';
  };
  seasonality?: {
    bestMonths: number[];
    worstMonths: number[];
  };
}

export class TimingSuggester {
  private readonly config: TimingSuggesterConfig;
  private readonly dayNames = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];

  constructor(config?: Partial<TimingSuggesterConfig>) {
    this.config = {
      timezone: config?.timezone ?? 'America/New_York',
      minDataPoints: config?.minDataPoints ?? 30,
      peakThreshold: config?.peakThreshold ?? 1.2,
      troughThreshold: config?.troughThreshold ?? 0.8,
    };
  }

  /**
   * Suggest optimal timing for an activity
   */
  async suggestTiming(
    activityData: ActivityData[],
    activity: ActivityData['activity']
  ): Promise<TimingRecommendation> {
    const filteredData = activityData.filter(d => d.activity === activity);

    if (filteredData.length < this.config.minDataPoints) {
      // Not enough data, return default recommendation
      return this.getDefaultRecommendation(activity);
    }

    const analysis = this.analyzeTimingPatterns(filteredData, activity);
    return this.analysisToRecommendation(analysis);
  }

  /**
   * Suggest timing for multiple activities
   */
  async suggestMultiple(
    activityData: ActivityData[]
  ): Promise<TimingRecommendation[]> {
    const activities = [
      ...new Set(activityData.map(d => d.activity)),
    ] as ActivityData['activity'][];
    const recommendations: TimingRecommendation[] = [];

    for (const activity of activities) {
      const recommendation = await this.suggestTiming(activityData, activity);
      recommendations.push(recommendation);
    }

    return recommendations;
  }

  /**
   * Analyze timing patterns
   */
  private analyzeTimingPatterns(
    data: ActivityData[],
    activity: string
  ): TimingAnalysis {
    // Calculate scores for each time slot
    const slotScores = this.calculateSlotScores(data);

    // Find optimal and worst slots
    const sortedSlots = [...slotScores].sort((a, b) => b.score - a.score);
    const optimalSlots = sortedSlots.slice(0, 5);
    const worstSlots = sortedSlots.slice(-5).reverse();

    // Find peak days and hours
    const peakDays = this.findPeakDays(slotScores);
    const peakHours = this.findPeakHours(slotScores);

    // Compare weekday vs weekend
    const weekdayVsWeekend = this.compareWeekdayWeekend(slotScores);

    // Analyze monthly seasonality if enough data
    const seasonality = this.analyzeSeasonality(data);

    return {
      activity,
      optimalSlots,
      worstSlots,
      peakDays,
      peakHours,
      weekdayVsWeekend,
      seasonality,
    };
  }

  /**
   * Calculate scores for each time slot
   */
  private calculateSlotScores(data: ActivityData[]): TimeSlotScore[] {
    const slots: Map<string, { total: number; count: number }> = new Map();

    // Aggregate metrics by time slot
    for (const d of data) {
      const dayOfWeek = d.timestamp.getDay();
      const hourOfDay = d.timestamp.getHours();
      const key = `${dayOfWeek}-${hourOfDay}`;

      const existing = slots.get(key) ?? { total: 0, count: 0 };
      slots.set(key, {
        total: existing.total + d.metric,
        count: existing.count + 1,
      });
    }

    // Convert to scores
    const scores: TimeSlotScore[] = [];
    const averages: number[] = [];

    for (const [key, value] of slots) {
      const [day, hour] = key.split('-').map(Number);
      const avg = value.total / value.count;
      averages.push(avg);

      scores.push({
        dayOfWeek: day,
        hourOfDay: hour,
        score: avg,
        sampleSize: value.count,
      });
    }

    // Normalize scores to 0-100
    const maxAvg = Math.max(...averages);
    const minAvg = Math.min(...averages);
    const range = maxAvg - minAvg;

    for (const score of scores) {
      score.score =
        range > 0 ? ((score.score - minAvg) / range) * 100 : 50;
    }

    return scores;
  }

  /**
   * Find peak days
   */
  private findPeakDays(scores: TimeSlotScore[]): number[] {
    const dayScores: Record<number, { total: number; count: number }> = {};

    for (const score of scores) {
      if (!dayScores[score.dayOfWeek]) {
        dayScores[score.dayOfWeek] = { total: 0, count: 0 };
      }
      dayScores[score.dayOfWeek].total += score.score;
      dayScores[score.dayOfWeek].count++;
    }

    const dayAverages = Object.entries(dayScores)
      .map(([day, data]) => ({
        day: Number(day),
        avg: data.total / data.count,
      }))
      .sort((a, b) => b.avg - a.avg);

    const overallAvg =
      dayAverages.reduce((sum, d) => sum + d.avg, 0) / dayAverages.length;
    const threshold = overallAvg * this.config.peakThreshold;

    return dayAverages
      .filter(d => d.avg >= threshold)
      .map(d => d.day);
  }

  /**
   * Find peak hours
   */
  private findPeakHours(scores: TimeSlotScore[]): number[] {
    const hourScores: Record<number, { total: number; count: number }> = {};

    for (const score of scores) {
      if (!hourScores[score.hourOfDay]) {
        hourScores[score.hourOfDay] = { total: 0, count: 0 };
      }
      hourScores[score.hourOfDay].total += score.score;
      hourScores[score.hourOfDay].count++;
    }

    const hourAverages = Object.entries(hourScores)
      .map(([hour, data]) => ({
        hour: Number(hour),
        avg: data.total / data.count,
      }))
      .sort((a, b) => b.avg - a.avg);

    const overallAvg =
      hourAverages.reduce((sum, h) => sum + h.avg, 0) / hourAverages.length;
    const threshold = overallAvg * this.config.peakThreshold;

    return hourAverages
      .filter(h => h.avg >= threshold)
      .map(h => h.hour);
  }

  /**
   * Compare weekday vs weekend performance
   */
  private compareWeekdayWeekend(scores: TimeSlotScore[]): {
    weekday: number;
    weekend: number;
    better: 'weekday' | 'weekend' | 'equal';
  } {
    const weekdayScores: number[] = [];
    const weekendScores: number[] = [];

    for (const score of scores) {
      if (score.dayOfWeek === 0 || score.dayOfWeek === 6) {
        weekendScores.push(score.score);
      } else {
        weekdayScores.push(score.score);
      }
    }

    const weekdayAvg =
      weekdayScores.length > 0
        ? weekdayScores.reduce((a, b) => a + b, 0) / weekdayScores.length
        : 50;
    const weekendAvg =
      weekendScores.length > 0
        ? weekendScores.reduce((a, b) => a + b, 0) / weekendScores.length
        : 50;

    let better: 'weekday' | 'weekend' | 'equal';
    if (weekdayAvg > weekendAvg * 1.1) {
      better = 'weekday';
    } else if (weekendAvg > weekdayAvg * 1.1) {
      better = 'weekend';
    } else {
      better = 'equal';
    }

    return {
      weekday: Math.round(weekdayAvg),
      weekend: Math.round(weekendAvg),
      better,
    };
  }

  /**
   * Analyze monthly seasonality
   */
  private analyzeSeasonality(
    data: ActivityData[]
  ): { bestMonths: number[]; worstMonths: number[] } | undefined {
    // Need at least 90 days of data
    if (data.length < 90) return undefined;

    const monthScores: Record<number, { total: number; count: number }> = {};

    for (const d of data) {
      const month = d.timestamp.getMonth();
      if (!monthScores[month]) {
        monthScores[month] = { total: 0, count: 0 };
      }
      monthScores[month].total += d.metric;
      monthScores[month].count++;
    }

    const monthAverages = Object.entries(monthScores)
      .map(([month, data]) => ({
        month: Number(month),
        avg: data.total / data.count,
      }))
      .sort((a, b) => b.avg - a.avg);

    if (monthAverages.length < 4) return undefined;

    const overallAvg =
      monthAverages.reduce((sum, m) => sum + m.avg, 0) / monthAverages.length;

    return {
      bestMonths: monthAverages
        .filter(m => m.avg >= overallAvg * 1.15)
        .map(m => m.month),
      worstMonths: monthAverages
        .filter(m => m.avg <= overallAvg * 0.85)
        .map(m => m.month),
    };
  }

  /**
   * Convert analysis to recommendation
   */
  private analysisToRecommendation(
    analysis: TimingAnalysis
  ): TimingRecommendation {
    const confidence = this.calculateConfidence(analysis);
    const confidenceLevel = this.getConfidenceLevel(confidence);

    const optimalTimes = analysis.optimalSlots.map(s => ({
      dayOfWeek: s.dayOfWeek,
      hourOfDay: s.hourOfDay,
      score: Math.round(s.score),
    }));

    const avoidTimes = analysis.worstSlots.map(s => ({
      dayOfWeek: s.dayOfWeek,
      hourOfDay: s.hourOfDay,
      reason: `Low performance score: ${Math.round(s.score)}/100`,
    }));

    const actionItems = this.generateActionItems(analysis);

    return {
      id: uuidv4(),
      type: 'timing',
      title: `Optimal ${analysis.activity} timing`,
      description: this.generateDescription(analysis),
      confidence,
      confidenceLevel,
      potentialImpact: this.formatPotentialImpact(analysis),
      riskLevel: 'low',
      actionItems,
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // Valid for 30 days
      createdAt: new Date(),
      activity: analysis.activity,
      optimalTimes,
      avoidTimes,
    };
  }

  /**
   * Calculate recommendation confidence
   */
  private calculateConfidence(analysis: TimingAnalysis): number {
    let confidence = 0.5;

    // More data points = higher confidence
    const totalSamples = analysis.optimalSlots.reduce(
      (sum, s) => sum + s.sampleSize,
      0
    );
    confidence += Math.min(0.25, totalSamples / 200);

    // Clear peak patterns = higher confidence
    if (analysis.peakDays.length > 0 && analysis.peakDays.length <= 3) {
      confidence += 0.1;
    }
    if (analysis.peakHours.length > 0 && analysis.peakHours.length <= 4) {
      confidence += 0.1;
    }

    // Strong weekday/weekend difference = higher confidence
    if (analysis.weekdayVsWeekend.better !== 'equal') {
      confidence += 0.05;
    }

    return Math.max(0, Math.min(1, confidence));
  }

  /**
   * Get confidence level label
   */
  private getConfidenceLevel(confidence: number): ConfidenceLevel {
    if (confidence >= 0.85) return 'very_high';
    if (confidence >= 0.7) return 'high';
    if (confidence >= 0.5) return 'medium';
    return 'low';
  }

  /**
   * Generate description
   */
  private generateDescription(analysis: TimingAnalysis): string {
    const bestSlot = analysis.optimalSlots[0];
    const peakDayNames = analysis.peakDays.map(d => this.dayNames[d]).join(', ');

    let desc = `Best time to ${analysis.activity}: `;
    desc += `${this.dayNames[bestSlot.dayOfWeek]} at ${this.formatHour(bestSlot.hourOfDay)}. `;

    if (analysis.peakDays.length > 0) {
      desc += `Peak days: ${peakDayNames}. `;
    }

    if (analysis.weekdayVsWeekend.better !== 'equal') {
      desc += `${analysis.weekdayVsWeekend.better === 'weekday' ? 'Weekdays' : 'Weekends'} perform ${Math.abs(analysis.weekdayVsWeekend.weekday - analysis.weekdayVsWeekend.weekend)}% better. `;
    }

    return desc;
  }

  /**
   * Format potential impact
   */
  private formatPotentialImpact(analysis: TimingAnalysis): string {
    const bestScore = analysis.optimalSlots[0]?.score ?? 50;
    const worstScore = analysis.worstSlots[0]?.score ?? 50;
    const improvement = Math.round(bestScore - worstScore);

    return `Up to ${improvement}% better performance with optimal timing`;
  }

  /**
   * Generate action items
   */
  private generateActionItems(analysis: TimingAnalysis): ActionItem[] {
    const items: ActionItem[] = [];
    const bestSlot = analysis.optimalSlots[0];

    items.push({
      id: uuidv4(),
      action: `Schedule ${analysis.activity} for ${this.dayNames[bestSlot.dayOfWeek]} at ${this.formatHour(bestSlot.hourOfDay)}`,
      priority: 'high',
      estimatedEffort: '5 minutes',
      completed: false,
    });

    if (analysis.weekdayVsWeekend.better === 'weekend') {
      items.push({
        id: uuidv4(),
        action: 'Prepare content during weekdays for weekend publishing',
        priority: 'medium',
        estimatedEffort: 'Ongoing',
        completed: false,
      });
    }

    if (analysis.worstSlots.length > 0) {
      const worstDay = this.dayNames[analysis.worstSlots[0].dayOfWeek];
      items.push({
        id: uuidv4(),
        action: `Avoid ${analysis.activity} on ${worstDay} during ${this.formatHour(analysis.worstSlots[0].hourOfDay)}`,
        priority: 'medium',
        estimatedEffort: 'Ongoing awareness',
        completed: false,
      });
    }

    return items;
  }

  /**
   * Format hour for display
   */
  private formatHour(hour: number): string {
    if (hour === 0) return '12 AM';
    if (hour === 12) return '12 PM';
    if (hour < 12) return `${hour} AM`;
    return `${hour - 12} PM`;
  }

  /**
   * Get default recommendation when insufficient data
   */
  private getDefaultRecommendation(
    activity: ActivityData['activity']
  ): TimingRecommendation {
    const defaults: Record<string, { day: number; hour: number }> = {
      publish: { day: 2, hour: 10 }, // Tuesday 10 AM
      promote: { day: 4, hour: 14 }, // Thursday 2 PM
      email: { day: 2, hour: 9 }, // Tuesday 9 AM
      social: { day: 3, hour: 12 }, // Wednesday 12 PM
      restock: { day: 1, hour: 8 }, // Monday 8 AM
      custom: { day: 3, hour: 10 }, // Wednesday 10 AM
    };

    const defaultTime = defaults[activity] ?? defaults.custom;

    return {
      id: uuidv4(),
      type: 'timing',
      title: `Recommended ${activity} timing (default)`,
      description: `Based on general best practices. Collect more data for personalized recommendations.`,
      confidence: 0.4,
      confidenceLevel: 'low',
      potentialImpact: 'Moderate improvement expected',
      riskLevel: 'low',
      actionItems: [
        {
          id: uuidv4(),
          action: `Track ${activity} performance for 30+ days`,
          priority: 'medium',
          estimatedEffort: 'Ongoing',
          completed: false,
        },
      ],
      validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      createdAt: new Date(),
      activity,
      optimalTimes: [
        {
          dayOfWeek: defaultTime.day,
          hourOfDay: defaultTime.hour,
          score: 70,
        },
      ],
      avoidTimes: [],
    };
  }
}

/**
 * Factory function
 */
export function createTimingSuggester(
  config?: Partial<TimingSuggesterConfig>
): TimingSuggester {
  return new TimingSuggester(config);
}
