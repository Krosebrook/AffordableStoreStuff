/**
 * ============================================================================
 * REPLICATE FLUX PROVIDER
 * ============================================================================
 *
 * Integration with Replicate's Flux image generation models.
 * Supports Flux Pro, Flux Dev, and Flux Schnell variants.
 */

import Replicate from 'replicate';
import {
  ProviderName,
  ProviderConfig,
  ProviderCapabilities,
  GenerationOptions,
  GenerationResult,
  GenerationCost,
  ImageDimensions,
  ProviderHealth,
  FluxModel,
} from '../types';
import { BaseProvider } from './base-provider';

// =============================================================================
// TYPES
// =============================================================================

interface ReplicateFluxConfig extends ProviderConfig {
  readonly defaultModel?: FluxModel;
}

interface FluxPrediction {
  id: string;
  status: 'starting' | 'processing' | 'succeeded' | 'failed' | 'canceled';
  output?: string | string[];
  error?: string;
  metrics?: {
    predict_time?: number;
  };
}

// =============================================================================
// MODEL CONFIGURATIONS
// =============================================================================

const FLUX_MODELS: Record<
  FluxModel,
  {
    version: string;
    displayName: string;
    costPerGeneration: number;
    maxSteps: number;
    defaultSteps: number;
    supportsDimensions: boolean;
  }
> = {
  'flux-pro': {
    version: 'black-forest-labs/flux-pro',
    displayName: 'Flux Pro',
    costPerGeneration: 0.055,
    maxSteps: 50,
    defaultSteps: 25,
    supportsDimensions: true,
  },
  'flux-dev': {
    version: 'black-forest-labs/flux-dev',
    displayName: 'Flux Dev',
    costPerGeneration: 0.025,
    maxSteps: 50,
    defaultSteps: 28,
    supportsDimensions: true,
  },
  'flux-schnell': {
    version: 'black-forest-labs/flux-schnell',
    displayName: 'Flux Schnell',
    costPerGeneration: 0.003,
    maxSteps: 4,
    defaultSteps: 4,
    supportsDimensions: true,
  },
};

// =============================================================================
// REPLICATE FLUX PROVIDER
// =============================================================================

export class ReplicateFluxProvider extends BaseProvider {
  readonly name: ProviderName = 'replicate-flux';
  readonly displayName = 'Replicate Flux';

  readonly capabilities: ProviderCapabilities = {
    maxWidth: 2048,
    maxHeight: 2048,
    supportedFormats: ['png', 'jpg', 'webp'] as const,
    supportedStyles: ['photorealistic', 'artistic', 'illustration', 'anime'] as const,
    supportsNegativePrompt: true,
    supportsBatchGeneration: true,
    maxBatchSize: 4,
    supportsImageToImage: true,
    supportsInpainting: false,
  };

  private client: Replicate;
  private defaultModel: FluxModel;

  constructor(config: ReplicateFluxConfig) {
    super(config);

    this.client = new Replicate({
      auth: config.apiKey,
    });

    this.defaultModel = config.defaultModel ?? 'flux-pro';
  }

  /**
   * Generate an image using Flux
   */
  async generate(
    prompt: string,
    options: GenerationOptions
  ): Promise<GenerationResult> {
    const startTime = Date.now();
    const designId = this.generateDesignId();
    const metadata = this.createMetadata(options);

    try {
      // Resolve generation parameters
      const model = this.resolveModel(options);
      const modelConfig = FLUX_MODELS[model];
      const dimensions = this.resolveDimensions(options);
      const format = this.resolveFormat(options);

      // Build input parameters
      const input = this.buildInput(prompt, options, model, dimensions);

      this.log('info', `Starting generation: ${designId}`, {
        model,
        dimensions,
        steps: input.num_inference_steps,
        promptLength: prompt.length,
      });

      // Run prediction with retry
      const output = await this.executeWithRetry(async () => {
        return await this.client.run(modelConfig.version as `${string}/${string}`, {
          input,
        });
      });

      const generationTimeMs = Date.now() - startTime;

      // Extract image URL from output
      const imageUrl = this.extractImageUrl(output);

      if (!imageUrl) {
        throw new Error('No image URL returned from Flux');
      }

      this.log('info', `Generation complete: ${designId}`, {
        generationTimeMs,
        model,
      });

      return {
        success: true,
        designId,
        imageUrl,
        provider: this.name,
        model,
        prompt,
        enhancedPrompt: input.prompt,
        dimensions,
        format,
        generationTimeMs,
        cost: this.calculateCost(model),
        metadata: {
          ...metadata,
          seed: input.seed,
          steps: input.num_inference_steps,
          guidanceScale: input.guidance_scale,
        },
      };
    } catch (error) {
      const generationTimeMs = Date.now() - startTime;
      const genError = this.mapException(error);

      this.log('error', `Generation failed: ${designId}`, {
        error: genError,
        generationTimeMs,
      });

      return {
        success: false,
        designId,
        provider: this.name,
        model: this.resolveModel(options),
        prompt,
        dimensions: this.resolveDimensions(options),
        format: 'png',
        generationTimeMs,
        cost: { amount: 0, currency: 'USD', provider: this.name, model: this.resolveModel(options) },
        metadata,
        error: genError,
      };
    }
  }

  /**
   * Check provider health
   */
  async healthCheck(): Promise<ProviderHealth> {
    const startTime = Date.now();

    try {
      // Get collection to verify API access
      const collections = await this.client.collections.list();

      // Just need to verify we can make an API call
      const hasResults = collections !== undefined;

      this.lastHealthCheck = {
        name: this.name,
        isHealthy: hasResults,
        lastCheckAt: new Date(),
        responseTimeMs: Date.now() - startTime,
        consecutiveFailures: 0,
      };
    } catch (error) {
      this.lastHealthCheck = {
        name: this.name,
        isHealthy: false,
        lastCheckAt: new Date(),
        responseTimeMs: Date.now() - startTime,
        consecutiveFailures: this.consecutiveFailures + 1,
      };
    }

    return this.lastHealthCheck;
  }

  /**
   * Estimate cost for generation
   */
  estimateCost(options: GenerationOptions): GenerationCost {
    const model = this.resolveModel(options);
    return this.calculateCost(model);
  }

  /**
   * Validate API credentials
   */
  async validateCredentials(): Promise<boolean> {
    try {
      await this.client.collections.list();
      return true;
    } catch {
      return false;
    }
  }

  // ===========================================================================
  // PRIVATE HELPERS
  // ===========================================================================

  /**
   * Resolve which Flux model to use
   */
  private resolveModel(options: GenerationOptions): FluxModel {
    if (options.model && options.model in FLUX_MODELS) {
      return options.model as FluxModel;
    }
    return this.defaultModel;
  }

  /**
   * Build input parameters for Flux
   */
  private buildInput(
    prompt: string,
    options: GenerationOptions,
    model: FluxModel,
    dimensions: ImageDimensions
  ): Record<string, unknown> {
    const modelConfig = FLUX_MODELS[model];

    // Enhance prompt for POD
    const enhancedPrompt = this.enhancePrompt(prompt, options);

    const input: Record<string, unknown> = {
      prompt: enhancedPrompt,
      width: dimensions.width,
      height: dimensions.height,
      num_inference_steps: Math.min(
        options.steps ?? modelConfig.defaultSteps,
        modelConfig.maxSteps
      ),
      guidance_scale: options.guidanceScale ?? 3.5,
      output_format: this.resolveFormat(options),
      output_quality: 100,
    };

    // Add seed if provided for reproducibility
    if (options.seed !== undefined) {
      input.seed = options.seed;
    }

    // Add negative prompt for Flux Pro/Dev
    if (options.negativePrompt && model !== 'flux-schnell') {
      input.negative_prompt = options.negativePrompt;
    }

    return input;
  }

  /**
   * Enhance prompt for better POD design results
   */
  private enhancePrompt(prompt: string, options: GenerationOptions): string {
    const enhancements: string[] = [];

    // Add quality modifiers
    enhancements.push('high quality', 'detailed', 'professional');

    // Add style context for POD
    if (options.productType) {
      enhancements.push(
        `design for ${options.productType}`,
        'suitable for printing'
      );
    }

    // Add niche context
    if (options.niche) {
      enhancements.push(options.niche);
    }

    // Add style if specified
    if (options.style) {
      enhancements.push(options.style);
    }

    // Combine: prompt first, then enhancements
    const enhancementStr = enhancements.join(', ');
    return `${prompt}, ${enhancementStr}`;
  }

  /**
   * Extract image URL from Replicate output
   */
  private extractImageUrl(output: unknown): string | null {
    if (typeof output === 'string') {
      return output;
    }

    if (Array.isArray(output) && output.length > 0) {
      return output[0];
    }

    if (typeof output === 'object' && output !== null) {
      const obj = output as Record<string, unknown>;
      if (typeof obj.url === 'string') {
        return obj.url;
      }
      if (Array.isArray(obj.output) && obj.output.length > 0) {
        return obj.output[0];
      }
    }

    return null;
  }

  /**
   * Calculate generation cost
   */
  private calculateCost(model: FluxModel): GenerationCost {
    const modelConfig = FLUX_MODELS[model];

    return {
      amount: modelConfig.costPerGeneration,
      currency: 'USD',
      provider: this.name,
      model,
      breakdown: {
        basePrice: modelConfig.costPerGeneration,
      },
    };
  }

  /**
   * Get default negative prompt for POD designs
   */
  getDefaultNegativePrompt(): string {
    return [
      'blurry',
      'low quality',
      'distorted',
      'watermark',
      'signature',
      'text',
      'words',
      'letters',
      'logo',
      'trademark',
      'copyright',
      'border',
      'frame',
      'cropped',
      'out of frame',
      'deformed',
      'ugly',
      'mutation',
      'disfigured',
    ].join(', ');
  }
}

export default ReplicateFluxProvider;
