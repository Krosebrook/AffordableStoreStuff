/**
 * ============================================================================
 * EXPONENTIAL SMOOTHING MODEL
 * ============================================================================
 * Single, Double (Holt's), and Triple (Holt-Winters) exponential smoothing
 * for time series forecasting with trend and seasonality handling
 */

import type { DataPoint, PredictionPoint, ModelResult } from '../types.js';

export interface ExponentialSmoothingOptions {
  alpha: number; // Level smoothing (0 < alpha <= 1)
  beta?: number; // Trend smoothing (0 < beta <= 1) for Holt's method
  gamma?: number; // Seasonal smoothing (0 < gamma <= 1) for Holt-Winters
  seasonalPeriods?: number; // Number of periods in a season (e.g., 7 for weekly, 12 for monthly)
  seasonalType?: 'additive' | 'multiplicative';
  damped?: boolean; // Use damped trend
  phi?: number; // Damping factor (0 < phi < 1)
  confidenceLevel?: number;
}

export class ExponentialSmoothingModel {
  private readonly alpha: number;
  private readonly beta: number;
  private readonly gamma: number;
  private readonly seasonalPeriods: number;
  private readonly seasonalType: 'additive' | 'multiplicative';
  private readonly damped: boolean;
  private readonly phi: number;
  private readonly confidenceLevel: number;

  // Fitted values
  private level: number = 0;
  private trend: number = 0;
  private seasonals: number[] = [];
  private residuals: number[] = [];
  private fitted: boolean = false;

  constructor(options: ExponentialSmoothingOptions) {
    this.alpha = Math.max(0.01, Math.min(1, options.alpha));
    this.beta = options.beta !== undefined ? Math.max(0, Math.min(1, options.beta)) : 0;
    this.gamma = options.gamma !== undefined ? Math.max(0, Math.min(1, options.gamma)) : 0;
    this.seasonalPeriods = options.seasonalPeriods ?? 0;
    this.seasonalType = options.seasonalType ?? 'additive';
    this.damped = options.damped ?? false;
    this.phi = options.phi ?? 0.98;
    this.confidenceLevel = options.confidenceLevel ?? 0.95;
  }

  /**
   * Get the model type based on parameters
   */
  getModelType(): 'simple' | 'holt' | 'holt_winters' {
    if (this.gamma > 0 && this.seasonalPeriods > 0) {
      return 'holt_winters';
    } else if (this.beta > 0) {
      return 'holt';
    }
    return 'simple';
  }

  /**
   * Simple Exponential Smoothing (SES)
   */
  private fitSimple(values: number[]): number[] {
    const fitted: number[] = [];
    this.level = values[0];
    fitted.push(this.level);

    for (let i = 1; i < values.length; i++) {
      this.level = this.alpha * values[i] + (1 - this.alpha) * this.level;
      fitted.push(this.level);
    }

    return fitted;
  }

  /**
   * Double Exponential Smoothing (Holt's method)
   */
  private fitHolt(values: number[]): number[] {
    if (values.length < 2) {
      return this.fitSimple(values);
    }

    const fitted: number[] = [];

    // Initialize level and trend
    this.level = values[0];
    this.trend = values[1] - values[0];
    fitted.push(this.level + this.trend);

    for (let i = 1; i < values.length; i++) {
      const prevLevel = this.level;

      this.level = this.alpha * values[i] + (1 - this.alpha) * (prevLevel + (this.damped ? this.phi : 1) * this.trend);
      this.trend = this.beta * (this.level - prevLevel) + (1 - this.beta) * (this.damped ? this.phi : 1) * this.trend;

      fitted.push(this.level + (this.damped ? this.phi : 1) * this.trend);
    }

    return fitted;
  }

  /**
   * Triple Exponential Smoothing (Holt-Winters method)
   */
  private fitHoltWinters(values: number[]): number[] {
    const m = this.seasonalPeriods;

    if (values.length < 2 * m) {
      // Not enough data for seasonal model, fall back to Holt's
      return this.fitHolt(values);
    }

    const fitted: number[] = [];

    // Initialize level and trend using first two seasons
    let sumFirst = 0;
    let sumSecond = 0;
    for (let i = 0; i < m; i++) {
      sumFirst += values[i];
      sumSecond += values[m + i];
    }
    this.level = sumFirst / m;
    this.trend = (sumSecond - sumFirst) / (m * m);

    // Initialize seasonal components
    this.seasonals = new Array(m).fill(0);
    if (this.seasonalType === 'multiplicative') {
      for (let i = 0; i < m; i++) {
        let seasonSum = 0;
        let count = 0;
        for (let j = i; j < values.length; j += m) {
          const avg = values.slice(Math.max(0, j - Math.floor(m / 2)), j + Math.ceil(m / 2))
            .reduce((a, b) => a + b, 0) / m;
          if (avg !== 0) {
            seasonSum += values[j] / avg;
            count++;
          }
        }
        this.seasonals[i] = count > 0 ? seasonSum / count : 1;
      }
    } else {
      for (let i = 0; i < m; i++) {
        let seasonSum = 0;
        let count = 0;
        for (let j = i; j < values.length; j += m) {
          const avg = values.slice(Math.max(0, j - Math.floor(m / 2)), j + Math.ceil(m / 2))
            .reduce((a, b) => a + b, 0) / m;
          seasonSum += values[j] - avg;
          count++;
        }
        this.seasonals[i] = count > 0 ? seasonSum / count : 0;
      }
    }

    // Fit the model
    for (let i = 0; i < values.length; i++) {
      const seasonIdx = i % m;
      const prevLevel = this.level;
      const seasonVal = this.seasonals[seasonIdx];

      let yHat: number;
      if (this.seasonalType === 'multiplicative') {
        this.level = this.alpha * (values[i] / seasonVal) + (1 - this.alpha) * (prevLevel + (this.damped ? this.phi : 1) * this.trend);
        this.trend = this.beta * (this.level - prevLevel) + (1 - this.beta) * (this.damped ? this.phi : 1) * this.trend;
        this.seasonals[seasonIdx] = this.gamma * (values[i] / this.level) + (1 - this.gamma) * seasonVal;
        yHat = (this.level + (this.damped ? this.phi : 1) * this.trend) * this.seasonals[seasonIdx];
      } else {
        this.level = this.alpha * (values[i] - seasonVal) + (1 - this.alpha) * (prevLevel + (this.damped ? this.phi : 1) * this.trend);
        this.trend = this.beta * (this.level - prevLevel) + (1 - this.beta) * (this.damped ? this.phi : 1) * this.trend;
        this.seasonals[seasonIdx] = this.gamma * (values[i] - this.level) + (1 - this.gamma) * seasonVal;
        yHat = this.level + (this.damped ? this.phi : 1) * this.trend + this.seasonals[seasonIdx];
      }

      fitted.push(yHat);
    }

    return fitted;
  }

  /**
   * Fit the model to the data
   */
  fit(dataPoints: DataPoint[]): number[] {
    const values = dataPoints.map(dp => dp.value);

    if (values.length === 0) {
      throw new Error('No data points provided');
    }

    let fittedValues: number[];
    const modelType = this.getModelType();

    switch (modelType) {
      case 'holt_winters':
        fittedValues = this.fitHoltWinters(values);
        break;
      case 'holt':
        fittedValues = this.fitHolt(values);
        break;
      default:
        fittedValues = this.fitSimple(values);
    }

    // Calculate residuals
    this.residuals = values.map((v, i) => v - fittedValues[i]);
    this.fitted = true;

    return fittedValues;
  }

  /**
   * Get Z-score for confidence level
   */
  private getZScore(): number {
    const zScores: Record<number, number> = {
      0.90: 1.645,
      0.95: 1.96,
      0.99: 2.576,
    };
    return zScores[this.confidenceLevel] ?? 1.96;
  }

  /**
   * Calculate residual standard error
   */
  private getResidualStd(): number {
    if (this.residuals.length === 0) {
      return 0;
    }
    const mean = this.residuals.reduce((a, b) => a + b, 0) / this.residuals.length;
    const variance = this.residuals.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / this.residuals.length;
    return Math.sqrt(variance);
  }

  /**
   * Forecast future values
   */
  forecast(dataPoints: DataPoint[], horizon: number): PredictionPoint[] {
    // Fit if not already fitted
    if (!this.fitted) {
      this.fit(dataPoints);
    }

    const predictions: PredictionPoint[] = [];
    const lastDate = dataPoints[dataPoints.length - 1].timestamp;
    const residualStd = this.getResidualStd();
    const zScore = this.getZScore();
    const modelType = this.getModelType();
    const m = this.seasonalPeriods;

    let cumulativePhiPower = this.damped ? this.phi : 1;

    for (let h = 1; h <= horizon; h++) {
      let prediction: number;

      if (modelType === 'holt_winters' && m > 0) {
        const seasonIdx = (dataPoints.length + h - 1) % m;
        if (this.seasonalType === 'multiplicative') {
          prediction = (this.level + cumulativePhiPower * this.trend) * this.seasonals[seasonIdx];
        } else {
          prediction = this.level + cumulativePhiPower * this.trend + this.seasonals[seasonIdx];
        }
      } else if (modelType === 'holt') {
        prediction = this.level + cumulativePhiPower * this.trend;
      } else {
        prediction = this.level;
      }

      // Increase uncertainty for further horizons
      const uncertaintyMultiplier = Math.sqrt(h);
      const margin = zScore * residualStd * uncertaintyMultiplier;

      const predictionDate = new Date(lastDate);
      predictionDate.setDate(predictionDate.getDate() + h);

      predictions.push({
        date: predictionDate,
        value: prediction,
        lowerBound: prediction - margin,
        upperBound: prediction + margin,
      });

      if (this.damped) {
        cumulativePhiPower += Math.pow(this.phi, h);
      } else {
        cumulativePhiPower = h;
      }
    }

    return predictions;
  }

  /**
   * Calculate error metrics
   */
  private calculateErrorMetrics(actual: number[], predicted: number[]): {
    mse: number;
    mae: number;
    mape: number;
  } {
    if (actual.length !== predicted.length || actual.length === 0) {
      return { mse: 0, mae: 0, mape: 0 };
    }

    let sumSquaredError = 0;
    let sumAbsoluteError = 0;
    let sumPercentageError = 0;
    let validPercentageCount = 0;

    for (let i = 0; i < actual.length; i++) {
      const error = actual[i] - predicted[i];
      sumSquaredError += error * error;
      sumAbsoluteError += Math.abs(error);

      if (actual[i] !== 0) {
        sumPercentageError += Math.abs(error / actual[i]);
        validPercentageCount++;
      }
    }

    const n = actual.length;
    return {
      mse: sumSquaredError / n,
      mae: sumAbsoluteError / n,
      mape: validPercentageCount > 0 ? sumPercentageError / validPercentageCount : 0,
    };
  }

  /**
   * Generate full model result with metrics
   */
  getModelResult(dataPoints: DataPoint[], horizon: number = 7): ModelResult {
    const values = dataPoints.map(dp => dp.value);
    const fittedValues = this.fit(dataPoints);
    const errors = this.calculateErrorMetrics(values, fittedValues);
    const predictions = this.forecast(dataPoints, horizon);

    return {
      model: 'exponential_smoothing',
      predictions,
      accuracy: Math.max(0, 1 - errors.mape),
      mse: errors.mse,
      mae: errors.mae,
      mape: errors.mape,
      trainingDataPoints: dataPoints.length,
      generatedAt: new Date(),
    };
  }

  /**
   * Optimize parameters using grid search
   */
  static optimizeParameters(
    dataPoints: DataPoint[],
    options?: {
      seasonalPeriods?: number;
      seasonalType?: 'additive' | 'multiplicative';
      includeHoltWinters?: boolean;
    }
  ): ExponentialSmoothingOptions {
    const values = dataPoints.map(dp => dp.value);
    const n = values.length;

    // Split data for validation
    const trainSize = Math.floor(n * 0.8);
    const trainData = dataPoints.slice(0, trainSize);
    const testData = dataPoints.slice(trainSize);
    const testValues = testData.map(dp => dp.value);

    let bestMape = Infinity;
    let bestParams: ExponentialSmoothingOptions = { alpha: 0.3 };

    const alphaRange = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9];
    const betaRange = [0, 0.1, 0.2, 0.3, 0.4, 0.5];
    const gammaRange = options?.includeHoltWinters ? [0, 0.1, 0.2, 0.3, 0.4] : [0];

    for (const alpha of alphaRange) {
      for (const beta of betaRange) {
        for (const gamma of gammaRange) {
          try {
            const model = new ExponentialSmoothingModel({
              alpha,
              beta: beta > 0 ? beta : undefined,
              gamma: gamma > 0 ? gamma : undefined,
              seasonalPeriods: options?.seasonalPeriods,
              seasonalType: options?.seasonalType,
            });

            model.fit(trainData);
            const predictions = model.forecast(trainData, testData.length);
            const predictedValues = predictions.map(p => p.value);

            // Calculate MAPE on test set
            let mape = 0;
            let count = 0;
            for (let i = 0; i < testValues.length; i++) {
              if (testValues[i] !== 0) {
                mape += Math.abs((testValues[i] - predictedValues[i]) / testValues[i]);
                count++;
              }
            }
            mape = count > 0 ? mape / count : Infinity;

            if (mape < bestMape) {
              bestMape = mape;
              bestParams = {
                alpha,
                beta: beta > 0 ? beta : undefined,
                gamma: gamma > 0 ? gamma : undefined,
                seasonalPeriods: options?.seasonalPeriods,
                seasonalType: options?.seasonalType,
              };
            }
          } catch {
            // Skip invalid parameter combinations
          }
        }
      }
    }

    return bestParams;
  }
}

/**
 * Factory function for creating exponential smoothing models
 */
export function createExponentialSmoothingModel(
  options?: Partial<ExponentialSmoothingOptions>
): ExponentialSmoothingModel {
  return new ExponentialSmoothingModel({
    alpha: options?.alpha ?? 0.3,
    beta: options?.beta,
    gamma: options?.gamma,
    seasonalPeriods: options?.seasonalPeriods,
    seasonalType: options?.seasonalType ?? 'additive',
    damped: options?.damped ?? false,
    phi: options?.phi ?? 0.98,
    confidenceLevel: options?.confidenceLevel ?? 0.95,
  });
}

/**
 * Convenience function for simple exponential smoothing forecast
 */
export function simpleExponentialSmoothing(
  dataPoints: DataPoint[],
  horizon: number,
  alpha: number = 0.3
): PredictionPoint[] {
  const model = new ExponentialSmoothingModel({ alpha });
  model.fit(dataPoints);
  return model.forecast(dataPoints, horizon);
}

/**
 * Convenience function for Holt's method forecast
 */
export function holtsMethod(
  dataPoints: DataPoint[],
  horizon: number,
  alpha: number = 0.3,
  beta: number = 0.1
): PredictionPoint[] {
  const model = new ExponentialSmoothingModel({ alpha, beta });
  model.fit(dataPoints);
  return model.forecast(dataPoints, horizon);
}

/**
 * Convenience function for Holt-Winters forecast
 */
export function holtWinters(
  dataPoints: DataPoint[],
  horizon: number,
  seasonalPeriods: number,
  alpha: number = 0.3,
  beta: number = 0.1,
  gamma: number = 0.1,
  seasonalType: 'additive' | 'multiplicative' = 'additive'
): PredictionPoint[] {
  const model = new ExponentialSmoothingModel({
    alpha,
    beta,
    gamma,
    seasonalPeriods,
    seasonalType,
  });
  model.fit(dataPoints);
  return model.forecast(dataPoints, horizon);
}
