/**
 * ============================================================================
 * IMAGE UPSCALER
 * ============================================================================
 *
 * Image upscaling service using AI-powered upscaling models.
 * Supports Replicate ESRGAN and Stability AI upscaling.
 */

import Replicate from 'replicate';
import {
  UpscaleOptions,
  UpscaleResult,
  ImageDimensions,
  GenerationError,
} from '../types';

// =============================================================================
// TYPES
// =============================================================================

interface UpscalerConfig {
  readonly replicateApiKey?: string;
  readonly stabilityApiKey?: string;
  readonly defaultProvider?: 'replicate-esrgan' | 'stability-esrgan';
  readonly maxInputSizeMB?: number;
  readonly timeout?: number;
}

type UpscaleProvider = 'replicate-esrgan' | 'stability-esrgan';

// =============================================================================
// PRICING
// =============================================================================

const UPSCALE_PRICING: Record<UpscaleProvider, Record<number, number>> = {
  'replicate-esrgan': {
    2: 0.005, // 2x upscale
    4: 0.01, // 4x upscale
  },
  'stability-esrgan': {
    2: 0.01,
    4: 0.02,
  },
};

// =============================================================================
// UPSCALER CLASS
// =============================================================================

export class Upscaler {
  private config: UpscalerConfig;
  private replicateClient?: Replicate;

  constructor(supabaseUrl?: string, supabaseKey?: string, config: UpscalerConfig = {}) {
    this.config = {
      defaultProvider: 'replicate-esrgan',
      maxInputSizeMB: 10,
      timeout: 120000,
      ...config,
    };

    // Initialize Replicate client if API key provided
    if (config.replicateApiKey) {
      this.replicateClient = new Replicate({
        auth: config.replicateApiKey,
      });
    }
  }

  /**
   * Upscale an image
   */
  async upscale(
    imageUrl: string,
    options: UpscaleOptions = { scale: 2 }
  ): Promise<UpscaleResult> {
    const startTime = Date.now();
    const provider = options.provider ?? this.config.defaultProvider ?? 'replicate-esrgan';

    try {
      // Validate scale factor
      if (options.scale !== 2 && options.scale !== 4) {
        throw new Error('Scale must be 2 or 4');
      }

      // Get original dimensions (estimated from URL or metadata)
      const originalDimensions = await this.estimateDimensions(imageUrl);

      // Calculate upscaled dimensions
      const upscaledDimensions: ImageDimensions = {
        width: originalDimensions.width * options.scale,
        height: originalDimensions.height * options.scale,
      };

      // Route to appropriate provider
      let result: { url?: string; base64?: string };

      if (provider === 'replicate-esrgan') {
        result = await this.upscaleWithReplicate(imageUrl, options);
      } else {
        result = await this.upscaleWithStability(imageUrl, options);
      }

      const processingTimeMs = Date.now() - startTime;

      return {
        success: true,
        originalUrl: imageUrl,
        upscaledUrl: result.url,
        upscaledBase64: result.base64,
        originalDimensions,
        upscaledDimensions,
        scale: options.scale,
        processingTimeMs,
        cost: UPSCALE_PRICING[provider][options.scale],
      };
    } catch (error) {
      const processingTimeMs = Date.now() - startTime;

      return {
        success: false,
        originalUrl: imageUrl,
        originalDimensions: { width: 0, height: 0 },
        upscaledDimensions: { width: 0, height: 0 },
        scale: options.scale,
        processingTimeMs,
        cost: 0,
        error: this.mapError(error),
      };
    }
  }

  /**
   * Upscale multiple images in batch
   */
  async upscaleBatch(
    imageUrls: string[],
    options: UpscaleOptions = { scale: 2 },
    concurrency: number = 3
  ): Promise<UpscaleResult[]> {
    const results: UpscaleResult[] = [];

    // Process in batches for concurrency control
    for (let i = 0; i < imageUrls.length; i += concurrency) {
      const batch = imageUrls.slice(i, i + concurrency);
      const batchResults = await Promise.all(
        batch.map((url) => this.upscale(url, options))
      );
      results.push(...batchResults);
    }

    return results;
  }

  /**
   * Check if upscaler is available
   */
  isAvailable(): boolean {
    return !!(this.config.replicateApiKey || this.config.stabilityApiKey);
  }

  /**
   * Get available providers
   */
  getAvailableProviders(): UpscaleProvider[] {
    const providers: UpscaleProvider[] = [];

    if (this.config.replicateApiKey) {
      providers.push('replicate-esrgan');
    }

    if (this.config.stabilityApiKey) {
      providers.push('stability-esrgan');
    }

    return providers;
  }

  /**
   * Estimate cost for upscaling
   */
  estimateCost(scale: 2 | 4, provider?: UpscaleProvider): number {
    const useProvider = provider ?? this.config.defaultProvider ?? 'replicate-esrgan';
    return UPSCALE_PRICING[useProvider][scale];
  }

  // ===========================================================================
  // PRIVATE METHODS
  // ===========================================================================

  /**
   * Upscale using Replicate ESRGAN
   */
  private async upscaleWithReplicate(
    imageUrl: string,
    options: UpscaleOptions
  ): Promise<{ url?: string; base64?: string }> {
    if (!this.replicateClient) {
      throw new Error('Replicate client not configured');
    }

    // Use Real-ESRGAN model for upscaling
    const modelVersion =
      options.scale === 4
        ? 'nightmareai/real-esrgan:42fed1c4974146d4d2414e2be2c5277c7fcf05fcc3a73abf41610695738c1d7b'
        : 'nightmareai/real-esrgan:42fed1c4974146d4d2414e2be2c5277c7fcf05fcc3a73abf41610695738c1d7b';

    const input: Record<string, unknown> = {
      image: imageUrl,
      scale: options.scale,
    };

    // Add face enhancement if requested
    if (options.enhanceFace) {
      input.face_enhance = true;
    }

    const output = await this.replicateClient.run(
      modelVersion as `${string}/${string}:${string}`,
      { input }
    );

    // Extract URL from output
    const url = typeof output === 'string' ? output : Array.isArray(output) ? output[0] : undefined;

    return { url };
  }

  /**
   * Upscale using Stability AI
   */
  private async upscaleWithStability(
    imageUrl: string,
    options: UpscaleOptions
  ): Promise<{ url?: string; base64?: string }> {
    if (!this.config.stabilityApiKey) {
      throw new Error('Stability API key not configured');
    }

    // Fetch the image and convert to base64
    const imageResponse = await fetch(imageUrl);
    const imageBuffer = await imageResponse.arrayBuffer();
    const imageBase64 = Buffer.from(imageBuffer).toString('base64');

    // Call Stability upscale API
    const formData = new FormData();
    formData.append('image', new Blob([imageBuffer]), 'image.png');
    formData.append('width', String(options.scale === 4 ? 4096 : 2048));

    const response = await fetch(
      'https://api.stability.ai/v2beta/stable-image/upscale/conservative',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.config.stabilityApiKey}`,
          Accept: 'application/json',
        },
        body: formData,
      }
    );

    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: response.statusText }));
      throw new Error(`Stability API Error: ${error.message || response.statusText}`);
    }

    const result = await response.json();

    return { base64: result.image };
  }

  /**
   * Estimate image dimensions from URL or fetch metadata
   */
  private async estimateDimensions(imageUrl: string): Promise<ImageDimensions> {
    // For data URLs, try to parse dimensions
    if (imageUrl.startsWith('data:')) {
      // Default estimation for data URLs
      return { width: 1024, height: 1024 };
    }

    // For regular URLs, we'd need to fetch and check
    // For now, return a default estimation
    // In production, you'd want to actually fetch image metadata
    return { width: 1024, height: 1024 };
  }

  /**
   * Map error to GenerationError
   */
  private mapError(error: unknown): GenerationError {
    if (error instanceof Error) {
      return {
        code: 'UPSCALE_ERROR',
        message: error.message,
        retryable: true,
        details: { name: error.name },
      };
    }

    return {
      code: 'UNKNOWN_ERROR',
      message: String(error),
      retryable: false,
    };
  }
}

// =============================================================================
// EXPORTS
// =============================================================================

// Alias for backward compatibility
export { Upscaler as ImageUpscaler };

export default Upscaler;

/**
 * Create a simple upscaler with Replicate
 */
export function createReplicateUpscaler(apiKey: string): Upscaler {
  return new Upscaler(undefined, undefined, {
    replicateApiKey: apiKey,
    defaultProvider: 'replicate-esrgan',
  });
}

/**
 * Create a simple upscaler with Stability
 */
export function createStabilityUpscaler(apiKey: string): Upscaler {
  return new Upscaler(undefined, undefined, {
    stabilityApiKey: apiKey,
    defaultProvider: 'stability-esrgan',
  });
}
