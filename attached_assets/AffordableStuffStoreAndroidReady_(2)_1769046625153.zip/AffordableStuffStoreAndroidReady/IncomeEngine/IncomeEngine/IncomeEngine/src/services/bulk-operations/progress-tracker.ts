/**
 * Progress Tracker
 * Track bulk operation progress with webhook notifications
 */

import { EventEmitter } from 'events';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  sendWebhook,
  WebhookPayload,
  WebhookConfig,
} from '../../connectors/utils/webhook';
import {
  BulkOperation,
  BulkOperationProgress,
  BulkOperationResult,
  BulkOperationStatus,
  BulkOperationError,
  BulkItemStatus,
  ProgressEvent,
  ProgressEventType,
  ProgressEventData,
  ProgressEventHandler,
  BulkOperationWebhookPayload,
  BulkOperationAuditEntry,
} from './types';
import { ConnectorName } from '../../connectors/index';

// ============================================================================
// Constants
// ============================================================================

const PROGRESS_UPDATE_DEBOUNCE_MS = 500;
const WEBHOOK_RETRY_ATTEMPTS = 3;
const WEBHOOK_TIMEOUT_MS = 10000;

// ============================================================================
// Progress Tracker Class
// ============================================================================

export class ProgressTracker extends EventEmitter {
  private supabase: SupabaseClient | null = null;
  private operations: Map<string, BulkOperation> = new Map();
  private progressUpdateTimers: Map<string, NodeJS.Timeout> = new Map();
  private eventHandlers: Map<string, Set<ProgressEventHandler>> = new Map();
  private startTimes: Map<string, number> = new Map();
  private itemStartTimes: Map<string, number> = new Map();

  constructor(supabaseUrl?: string, supabaseKey?: string) {
    super();
    if (supabaseUrl && supabaseKey) {
      this.supabase = createClient(supabaseUrl, supabaseKey);
    }
  }

  // ============================================================================
  // Operation Lifecycle
  // ============================================================================

  /**
   * Initialize tracking for a bulk operation
   */
  initializeOperation(operation: BulkOperation): void {
    this.operations.set(operation.id, operation);
    this.startTimes.set(operation.id, Date.now());
    this.eventHandlers.set(operation.id, new Set());
  }

  /**
   * Start tracking an operation
   */
  async startOperation(operationId: string): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) {
      throw new Error(`Operation not found: ${operationId}`);
    }

    operation.status = 'processing';
    operation.startedAt = new Date();
    operation.progress = this.createInitialProgress(operation.items.length);

    await this.persistProgress(operation);
    await this.emitEvent({
      type: 'operation:started',
      operationId,
      timestamp: new Date(),
      data: { progress: operation.progress },
    });

    await this.sendWebhookNotification(operation, 'bulk_operation_started');
    await this.logAudit(operationId, 'started');
  }

  /**
   * Complete an operation
   */
  async completeOperation(
    operationId: string,
    result: BulkOperationResult
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) {
      throw new Error(`Operation not found: ${operationId}`);
    }

    operation.status = result.success ? 'completed' : 'partial';
    operation.completedAt = new Date();
    operation.result = result;
    operation.progress.percent = 100;

    await this.persistProgress(operation);
    await this.emitEvent({
      type: 'operation:completed',
      operationId,
      timestamp: new Date(),
      data: { progress: operation.progress, result },
    });

    await this.sendWebhookNotification(operation, 'bulk_operation_completed');
    await this.logAudit(operationId, 'completed', { result });

    this.cleanup(operationId);
  }

  /**
   * Fail an operation
   */
  async failOperation(
    operationId: string,
    errors: BulkOperationError[]
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) {
      throw new Error(`Operation not found: ${operationId}`);
    }

    operation.status = 'failed';
    operation.completedAt = new Date();

    await this.persistProgress(operation);
    await this.emitEvent({
      type: 'operation:failed',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        error: errors[0] ? {
          code: errors[0].code,
          message: errors[0].message,
          retryable: false,
        } : undefined,
      },
    });

    await this.sendWebhookNotification(operation, 'bulk_operation_failed');
    await this.logAudit(operationId, 'failed', { errors });

    this.cleanup(operationId);
  }

  /**
   * Cancel an operation
   */
  async cancelOperation(operationId: string, reason?: string): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) {
      throw new Error(`Operation not found: ${operationId}`);
    }

    operation.status = 'cancelled';
    operation.completedAt = new Date();

    await this.persistProgress(operation);
    await this.emitEvent({
      type: 'operation:cancelled',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        metadata: { reason },
      },
    });

    await this.logAudit(operationId, 'cancelled', { reason });
    this.cleanup(operationId);
  }

  // ============================================================================
  // Batch Progress
  // ============================================================================

  /**
   * Start a batch
   */
  async startBatch(operationId: string, batchNumber: number): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    operation.progress.currentBatch = batchNumber;

    await this.emitEvent({
      type: 'batch:started',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        batchNumber,
      },
    });
  }

  /**
   * Complete a batch
   */
  async completeBatch(operationId: string, batchNumber: number): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    await this.emitEvent({
      type: 'batch:completed',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        batchNumber,
      },
    });

    await this.debouncedPersist(operationId);
  }

  // ============================================================================
  // Item Progress
  // ============================================================================

  /**
   * Start processing an item
   */
  async startItem(
    operationId: string,
    itemId: string,
    platform?: ConnectorName
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    this.itemStartTimes.set(`${operationId}:${itemId}`, Date.now());
    operation.progress.currentItemId = itemId;
    operation.progress.currentPlatform = platform;

    const item = operation.items.find((i) => i.id === itemId);
    if (item) {
      item.status = 'processing';
      item.startedAt = new Date();
    }

    await this.emitEvent({
      type: 'item:started',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        itemId,
        platform,
      },
    });
  }

  /**
   * Complete an item successfully
   */
  async completeItem(operationId: string, itemId: string): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    const item = operation.items.find((i) => i.id === itemId);
    if (item) {
      item.status = 'completed';
      item.completedAt = new Date();
    }

    operation.progress.processed++;
    operation.progress.successful++;
    operation.progress.pending = operation.progress.total - operation.progress.processed;
    this.updatePercent(operation);
    this.updateEstimatedTime(operation);

    await this.emitEvent({
      type: 'item:completed',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        itemId,
      },
    });

    this.itemStartTimes.delete(`${operationId}:${itemId}`);
    await this.debouncedPersist(operationId);
    await this.maybeNotifyProgress(operation);
  }

  /**
   * Fail an item
   */
  async failItem(
    operationId: string,
    itemId: string,
    error: { code: string; message: string; platform?: ConnectorName; retryable: boolean }
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    const item = operation.items.find((i) => i.id === itemId);
    if (item) {
      item.status = 'failed';
      item.completedAt = new Date();
      item.error = error;
    }

    operation.progress.processed++;
    operation.progress.failed++;
    operation.progress.pending = operation.progress.total - operation.progress.processed;
    this.updatePercent(operation);
    this.updateEstimatedTime(operation);

    await this.emitEvent({
      type: 'item:failed',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        itemId,
        error,
      },
    });

    this.itemStartTimes.delete(`${operationId}:${itemId}`);
    await this.debouncedPersist(operationId);
  }

  /**
   * Skip an item
   */
  async skipItem(
    operationId: string,
    itemId: string,
    reason?: string
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    const item = operation.items.find((i) => i.id === itemId);
    if (item) {
      item.status = 'skipped';
      item.completedAt = new Date();
    }

    operation.progress.processed++;
    operation.progress.skipped++;
    operation.progress.pending = operation.progress.total - operation.progress.processed;
    this.updatePercent(operation);
    this.updateEstimatedTime(operation);

    await this.emitEvent({
      type: 'item:skipped',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        itemId,
        metadata: { reason },
      },
    });

    await this.debouncedPersist(operationId);
  }

  /**
   * Retry an item
   */
  async retryItem(
    operationId: string,
    itemId: string,
    retryCount: number
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    const item = operation.items.find((i) => i.id === itemId);
    if (item) {
      item.retryCount = retryCount;
      item.status = 'pending';
    }

    await this.emitEvent({
      type: 'item:retrying',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        itemId,
        retryCount,
      },
    });
  }

  // ============================================================================
  // Rate Limit Handling
  // ============================================================================

  /**
   * Record rate limit hit
   */
  async hitRateLimit(
    operationId: string,
    platform: ConnectorName,
    waitTimeMs: number
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    operation.progress.rateLimitPaused = true;
    operation.progress.rateLimitResumeAt = new Date(Date.now() + waitTimeMs);

    await this.emitEvent({
      type: 'ratelimit:hit',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        platform,
        waitTimeMs,
      },
    });

    await this.debouncedPersist(operationId);
  }

  /**
   * Resume after rate limit
   */
  async resumeFromRateLimit(operationId: string): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    operation.progress.rateLimitPaused = false;
    operation.progress.rateLimitResumeAt = undefined;

    await this.emitEvent({
      type: 'ratelimit:resumed',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
      },
    });
  }

  // ============================================================================
  // Rollback Progress
  // ============================================================================

  /**
   * Start rollback
   */
  async startRollback(operationId: string): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    operation.status = 'rolling_back';

    await this.emitEvent({
      type: 'rollback:started',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
      },
    });

    await this.logAudit(operationId, 'rollback_started');
  }

  /**
   * Complete rollback
   */
  async completeRollback(
    operationId: string,
    success: boolean
  ): Promise<void> {
    const operation = this.operations.get(operationId);
    if (!operation) return;

    await this.emitEvent({
      type: success ? 'rollback:completed' : 'rollback:failed',
      operationId,
      timestamp: new Date(),
      data: {
        progress: operation.progress,
        metadata: { success },
      },
    });

    await this.logAudit(operationId, 'rollback_completed', { success });
  }

  // ============================================================================
  // Event Subscription
  // ============================================================================

  /**
   * Subscribe to progress events for an operation
   */
  subscribe(operationId: string, handler: ProgressEventHandler): () => void {
    let handlers = this.eventHandlers.get(operationId);
    if (!handlers) {
      handlers = new Set();
      this.eventHandlers.set(operationId, handlers);
    }
    handlers.add(handler);

    // Return unsubscribe function
    return () => {
      handlers?.delete(handler);
    };
  }

  /**
   * Subscribe to all operations
   */
  subscribeAll(handler: ProgressEventHandler): () => void {
    this.on('progress', handler);
    return () => {
      this.off('progress', handler);
    };
  }

  // ============================================================================
  // Query Methods
  // ============================================================================

  /**
   * Get current progress for an operation
   */
  getProgress(operationId: string): BulkOperationProgress | null {
    const operation = this.operations.get(operationId);
    return operation?.progress || null;
  }

  /**
   * Get operation status
   */
  getStatus(operationId: string): BulkOperationStatus | null {
    const operation = this.operations.get(operationId);
    return operation?.status || null;
  }

  /**
   * Get item status
   */
  getItemStatus(operationId: string, itemId: string): BulkItemStatus | null {
    const operation = this.operations.get(operationId);
    const item = operation?.items.find((i) => i.id === itemId);
    return item?.status || null;
  }

  /**
   * Check if operation is active
   */
  isActive(operationId: string): boolean {
    const status = this.getStatus(operationId);
    return status === 'processing' || status === 'rolling_back';
  }

  /**
   * Get elapsed time in ms
   */
  getElapsedTime(operationId: string): number {
    const startTime = this.startTimes.get(operationId);
    return startTime ? Date.now() - startTime : 0;
  }

  // ============================================================================
  // Private Methods
  // ============================================================================

  private createInitialProgress(totalItems: number): BulkOperationProgress {
    const batchSize = 10; // Default, will be overridden by config
    return {
      total: totalItems,
      processed: 0,
      successful: 0,
      failed: 0,
      skipped: 0,
      pending: totalItems,
      percent: 0,
      currentBatch: 0,
      totalBatches: Math.ceil(totalItems / batchSize),
      rateLimitPaused: false,
    };
  }

  private updatePercent(operation: BulkOperation): void {
    if (operation.progress.total > 0) {
      operation.progress.percent = Math.round(
        (operation.progress.processed / operation.progress.total) * 100
      );
    }
  }

  private updateEstimatedTime(operation: BulkOperation): void {
    const elapsedMs = this.getElapsedTime(operation.id);
    if (operation.progress.processed > 0 && operation.progress.pending > 0) {
      const avgTimePerItem = elapsedMs / operation.progress.processed;
      operation.progress.estimatedTimeRemainingMs = Math.round(
        avgTimePerItem * operation.progress.pending
      );
    }
  }

  private async emitEvent(event: ProgressEvent): Promise<void> {
    // Emit to operation-specific handlers
    const handlers = this.eventHandlers.get(event.operationId);
    if (handlers) {
      for (const handler of handlers) {
        try {
          await handler(event);
        } catch (error) {
          console.error('Progress event handler error:', error);
        }
      }
    }

    // Emit to global listeners
    this.emit('progress', event);
    this.emit(event.type, event);
  }

  private async debouncedPersist(operationId: string): Promise<void> {
    // Clear existing timer
    const existingTimer = this.progressUpdateTimers.get(operationId);
    if (existingTimer) {
      clearTimeout(existingTimer);
    }

    // Set new debounced timer
    const timer = setTimeout(async () => {
      const operation = this.operations.get(operationId);
      if (operation) {
        await this.persistProgress(operation);
      }
      this.progressUpdateTimers.delete(operationId);
    }, PROGRESS_UPDATE_DEBOUNCE_MS);

    this.progressUpdateTimers.set(operationId, timer);
  }

  private async persistProgress(operation: BulkOperation): Promise<void> {
    if (!this.supabase) return;

    operation.updatedAt = new Date();

    try {
      await this.supabase
        .from('bulk_operations')
        .upsert({
          id: operation.id,
          type: operation.type,
          status: operation.status,
          priority: operation.priority,
          config: operation.config,
          progress: operation.progress,
          result: operation.result,
          metadata: operation.metadata,
          created_at: operation.createdAt.toISOString(),
          updated_at: operation.updatedAt.toISOString(),
          started_at: operation.startedAt?.toISOString(),
          completed_at: operation.completedAt?.toISOString(),
        }, { onConflict: 'id' });
    } catch (error) {
      console.error('Failed to persist progress:', error);
    }
  }

  private async maybeNotifyProgress(operation: BulkOperation): Promise<void> {
    // Send progress webhook at 25%, 50%, 75%
    const milestones = [25, 50, 75];
    const percent = operation.progress.percent;

    for (const milestone of milestones) {
      if (percent >= milestone && percent < milestone + 5) {
        await this.sendWebhookNotification(operation, 'bulk_operation_progress');
        break;
      }
    }
  }

  private async sendWebhookNotification(
    operation: BulkOperation,
    event: BulkOperationWebhookPayload['event']
  ): Promise<void> {
    if (!operation.config.notifyOnCompletion && event !== 'bulk_operation_completed') {
      return;
    }

    const webhookUrl = operation.config.webhookUrl;
    if (!webhookUrl) return;

    const payload: WebhookPayload = {
      event: event as any,
      timestamp: new Date().toISOString(),
      data: {
        operationId: operation.id,
        operationType: operation.type,
        status: operation.status,
        progress: operation.progress,
        result: operation.result,
      },
      metadata: {
        source: 'income-engine',
        version: '2.0.0',
        idempotencyKey: `${event}-${operation.id}-${Date.now()}`,
      },
    };

    const config: WebhookConfig = {
      url: webhookUrl,
      secret: operation.config.webhookSecret,
      retryAttempts: WEBHOOK_RETRY_ATTEMPTS,
      timeoutMs: WEBHOOK_TIMEOUT_MS,
    };

    try {
      await sendWebhook(config, payload);
    } catch (error) {
      console.error('Failed to send webhook notification:', error);
    }
  }

  private async logAudit(
    operationId: string,
    action: BulkOperationAuditEntry['action'],
    details?: Record<string, unknown>
  ): Promise<void> {
    if (!this.supabase) return;

    try {
      await this.supabase.from('bulk_operation_audit').insert({
        operation_id: operationId,
        action,
        actor: 'system',
        details,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Failed to log audit:', error);
    }
  }

  private cleanup(operationId: string): void {
    const timer = this.progressUpdateTimers.get(operationId);
    if (timer) {
      clearTimeout(timer);
      this.progressUpdateTimers.delete(operationId);
    }

    this.startTimes.delete(operationId);
    this.eventHandlers.delete(operationId);

    // Keep operation in memory for a while for queries
    setTimeout(() => {
      this.operations.delete(operationId);
    }, 5 * 60 * 1000); // 5 minutes
  }
}

// ============================================================================
// Singleton Instance
// ============================================================================

let instance: ProgressTracker | null = null;

/**
 * Get the global ProgressTracker instance
 */
export function getProgressTracker(
  supabaseUrl?: string,
  supabaseKey?: string
): ProgressTracker {
  if (!instance) {
    instance = new ProgressTracker(supabaseUrl, supabaseKey);
  }
  return instance;
}

/**
 * Create a new ProgressTracker instance
 */
export function createProgressTracker(
  supabaseUrl?: string,
  supabaseKey?: string
): ProgressTracker {
  return new ProgressTracker(supabaseUrl, supabaseKey);
}

export default ProgressTracker;
