/**
 * ============================================================================
 * NICHE SUGGESTER
 * ============================================================================
 * Suggests profitable niches based on trend analysis and competition data
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  NicheRecommendation,
  ActionItem,
  TrendSignal,
  ConfidenceLevel,
  TrendDirection,
  SeasonalPattern,
} from '../types.js';
import { createTrendPredictor, type TrendDataPoint } from '../forecasting/index.js';
import { createGoogleTrendsDataSource } from '../data-sources/index.js';

export interface NicheSuggesterConfig {
  minTrendScore: number;
  minVelocity: number;
  maxCompetition: 'low' | 'medium' | 'high';
  preferRising: boolean;
  maxSuggestions: number;
}

export interface NicheAnalysis {
  niche: string;
  score: number;
  trendDirection: TrendDirection;
  velocity: number;
  competitionLevel: 'low' | 'medium' | 'high';
  searchVolume: number;
  profitPotential: 'low' | 'medium' | 'high' | 'very_high';
  relatedKeywords: string[];
  suggestedProducts: string[];
  seasonality?: SeasonalPattern;
}

export class NicheSuggester {
  private readonly config: NicheSuggesterConfig;
  private trendPredictor = createTrendPredictor();
  private googleTrends = createGoogleTrendsDataSource();

  constructor(config?: Partial<NicheSuggesterConfig>) {
    this.config = {
      minTrendScore: config?.minTrendScore ?? 30,
      minVelocity: config?.minVelocity ?? 0,
      maxCompetition: config?.maxCompetition ?? 'high',
      preferRising: config?.preferRising ?? true,
      maxSuggestions: config?.maxSuggestions ?? 10,
    };
  }

  /**
   * Suggest profitable niches based on trend data
   */
  async suggestNiches(
    trendData: TrendDataPoint[],
    options?: {
      category?: string;
      existingNiches?: string[];
    }
  ): Promise<NicheRecommendation[]> {
    // Get unique keywords from trend data
    const keywords = [...new Set(trendData.map(d => d.keyword))];

    // Analyze each niche
    const analyses: NicheAnalysis[] = [];

    for (const keyword of keywords) {
      try {
        const analysis = await this.analyzeNiche(keyword, trendData);
        if (this.meetsThresholds(analysis)) {
          analyses.push(analysis);
        }
      } catch (error) {
        console.warn(`Failed to analyze niche "${keyword}":`, error);
      }
    }

    // Sort by opportunity score
    const sorted = analyses.sort((a, b) => {
      const scoreA = this.calculateOpportunityScore(a);
      const scoreB = this.calculateOpportunityScore(b);
      return scoreB - scoreA;
    });

    // Filter out existing niches if provided
    const filtered = options?.existingNiches
      ? sorted.filter(a => !options.existingNiches!.includes(a.niche))
      : sorted;

    // Convert to recommendations
    return filtered
      .slice(0, this.config.maxSuggestions)
      .map(analysis => this.analysisToRecommendation(analysis));
  }

  /**
   * Analyze a single niche
   */
  async analyzeNiche(
    keyword: string,
    trendData: TrendDataPoint[]
  ): Promise<NicheAnalysis> {
    // Get trend analysis
    const keywordData = trendData.filter(d => d.keyword === keyword);
    let trendDirection: TrendDirection = 'stable';
    let velocity = 0;
    let score = 50;
    let relatedKeywords: string[] = [];

    if (keywordData.length >= 7) {
      try {
        const analysis = await this.trendPredictor.analyzeKeyword(
          trendData,
          keyword
        );
        trendDirection = analysis.aggregateDirection;
        score = analysis.aggregateScore;

        // Get velocity from signals
        if (analysis.signals.length > 0) {
          velocity = Math.max(...analysis.signals.map(s => s.velocity));
          relatedKeywords = analysis.signals[0].relatedKeywords;
        }
      } catch {
        // Use simple calculation
        const values = keywordData.map(d => d.score);
        score = values.reduce((a, b) => a + b, 0) / values.length;
      }
    }

    // Get related keywords from Google Trends if not available
    if (relatedKeywords.length === 0) {
      try {
        const trendsData = await this.googleTrends.fetchTrends({ keyword });
        relatedKeywords = trendsData.relatedQueries.slice(0, 5).map(q => q.query);
      } catch {
        relatedKeywords = this.generateRelatedKeywords(keyword);
      }
    }

    // Estimate competition level
    const competitionLevel = this.estimateCompetition(keyword, score);

    // Estimate search volume (normalized score)
    const searchVolume = Math.round(score * 1000);

    // Calculate profit potential
    const profitPotential = this.calculateProfitPotential(
      score,
      velocity,
      competitionLevel
    );

    // Generate product suggestions
    const suggestedProducts = this.generateProductSuggestions(
      keyword,
      relatedKeywords
    );

    return {
      niche: keyword,
      score,
      trendDirection,
      velocity,
      competitionLevel,
      searchVolume,
      profitPotential,
      relatedKeywords,
      suggestedProducts,
    };
  }

  /**
   * Check if niche meets configuration thresholds
   */
  private meetsThresholds(analysis: NicheAnalysis): boolean {
    // Check score
    if (analysis.score < this.config.minTrendScore) {
      return false;
    }

    // Check velocity if preferring rising
    if (this.config.preferRising && analysis.velocity < this.config.minVelocity) {
      return false;
    }

    // Check competition
    const competitionOrder = { low: 0, medium: 1, high: 2 };
    if (
      competitionOrder[analysis.competitionLevel] >
      competitionOrder[this.config.maxCompetition]
    ) {
      return false;
    }

    return true;
  }

  /**
   * Calculate opportunity score for ranking
   */
  private calculateOpportunityScore(analysis: NicheAnalysis): number {
    const competitionMultiplier = {
      low: 1.5,
      medium: 1.0,
      high: 0.7,
    };

    const directionMultiplier = {
      rising: 1.3,
      stable: 1.0,
      falling: 0.6,
      volatile: 0.8,
    };

    const profitMultiplier = {
      low: 0.5,
      medium: 1.0,
      high: 1.5,
      very_high: 2.0,
    };

    return (
      analysis.score *
      competitionMultiplier[analysis.competitionLevel] *
      directionMultiplier[analysis.trendDirection] *
      profitMultiplier[analysis.profitPotential] *
      (1 + analysis.velocity)
    );
  }

  /**
   * Estimate competition level
   */
  private estimateCompetition(
    keyword: string,
    trendScore: number
  ): 'low' | 'medium' | 'high' {
    // Higher trend scores often indicate more competition
    // Longer, more specific keywords tend to have less competition

    const wordCount = keyword.split(' ').length;
    const isLongTail = wordCount >= 3;

    if (trendScore > 70) {
      return isLongTail ? 'medium' : 'high';
    } else if (trendScore > 40) {
      return isLongTail ? 'low' : 'medium';
    }
    return 'low';
  }

  /**
   * Calculate profit potential
   */
  private calculateProfitPotential(
    score: number,
    velocity: number,
    competition: 'low' | 'medium' | 'high'
  ): 'low' | 'medium' | 'high' | 'very_high' {
    const competitionBonus = {
      low: 30,
      medium: 10,
      high: -10,
    };

    const adjustedScore =
      score + velocity * 50 + competitionBonus[competition];

    if (adjustedScore >= 100) return 'very_high';
    if (adjustedScore >= 70) return 'high';
    if (adjustedScore >= 40) return 'medium';
    return 'low';
  }

  /**
   * Generate related keywords if not available
   */
  private generateRelatedKeywords(keyword: string): string[] {
    const prefixes = ['best', 'cheap', 'custom', 'unique', 'handmade'];
    const suffixes = ['ideas', 'gifts', 'designs', 'products'];

    const related: string[] = [];
    for (const prefix of prefixes.slice(0, 3)) {
      related.push(`${prefix} ${keyword}`);
    }
    for (const suffix of suffixes.slice(0, 2)) {
      related.push(`${keyword} ${suffix}`);
    }

    return related;
  }

  /**
   * Generate product suggestions based on niche
   */
  private generateProductSuggestions(
    keyword: string,
    relatedKeywords: string[]
  ): string[] {
    const productTypes = [
      't-shirt',
      'mug',
      'poster',
      'sticker',
      'phone case',
      'tote bag',
      'hoodie',
      'digital download',
    ];

    const suggestions = productTypes.slice(0, 5).map(type => `${keyword} ${type}`);

    // Add variations from related keywords
    for (const related of relatedKeywords.slice(0, 2)) {
      suggestions.push(`${related} design`);
    }

    return suggestions;
  }

  /**
   * Convert analysis to recommendation
   */
  private analysisToRecommendation(
    analysis: NicheAnalysis
  ): NicheRecommendation {
    const confidence = this.calculateConfidence(analysis);
    const confidenceLevel = this.getConfidenceLevel(confidence);

    const potentialRevenue = this.estimatePotentialRevenue(analysis);
    const potentialImpact = this.formatPotentialImpact(
      analysis.profitPotential,
      potentialRevenue
    );

    const actionItems = this.generateActionItems(analysis);

    return {
      id: uuidv4(),
      type: 'niche',
      title: `Explore "${analysis.niche}" niche`,
      description: this.generateDescription(analysis),
      confidence,
      confidenceLevel,
      potentialImpact,
      estimatedRevenue: potentialRevenue,
      riskLevel: this.calculateRiskLevel(analysis),
      actionItems,
      validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Valid for 7 days
      createdAt: new Date(),
      niche: analysis.niche,
      keywords: [analysis.niche, ...analysis.relatedKeywords],
      competitionLevel: analysis.competitionLevel,
      searchVolume: analysis.searchVolume,
      trendDirection: analysis.trendDirection,
      seasonality: analysis.seasonality,
      suggestedProducts: analysis.suggestedProducts,
    };
  }

  /**
   * Calculate recommendation confidence
   */
  private calculateConfidence(analysis: NicheAnalysis): number {
    let confidence = 0.5;

    // Higher score = higher confidence
    confidence += analysis.score / 200;

    // Rising trends = higher confidence
    if (analysis.trendDirection === 'rising') {
      confidence += 0.15;
    } else if (analysis.trendDirection === 'falling') {
      confidence -= 0.15;
    }

    // Lower competition = higher confidence
    if (analysis.competitionLevel === 'low') {
      confidence += 0.1;
    } else if (analysis.competitionLevel === 'high') {
      confidence -= 0.1;
    }

    return Math.max(0, Math.min(1, confidence));
  }

  /**
   * Get confidence level label
   */
  private getConfidenceLevel(confidence: number): ConfidenceLevel {
    if (confidence >= 0.85) return 'very_high';
    if (confidence >= 0.7) return 'high';
    if (confidence >= 0.5) return 'medium';
    return 'low';
  }

  /**
   * Estimate potential revenue
   */
  private estimatePotentialRevenue(analysis: NicheAnalysis): number {
    const baseRevenue = {
      low: 100,
      medium: 500,
      high: 2000,
      very_high: 5000,
    };

    return baseRevenue[analysis.profitPotential];
  }

  /**
   * Format potential impact string
   */
  private formatPotentialImpact(
    profitPotential: string,
    revenue: number
  ): string {
    return `${profitPotential.replace('_', ' ')} potential - est. $${revenue}/month`;
  }

  /**
   * Calculate risk level
   */
  private calculateRiskLevel(
    analysis: NicheAnalysis
  ): 'low' | 'medium' | 'high' {
    if (
      analysis.competitionLevel === 'high' ||
      analysis.trendDirection === 'falling'
    ) {
      return 'high';
    }
    if (
      analysis.competitionLevel === 'medium' ||
      analysis.trendDirection === 'volatile'
    ) {
      return 'medium';
    }
    return 'low';
  }

  /**
   * Generate description for recommendation
   */
  private generateDescription(analysis: NicheAnalysis): string {
    const direction = {
      rising: 'growing in popularity',
      stable: 'maintaining steady interest',
      falling: 'declining in interest',
      volatile: 'showing fluctuating interest',
    };

    const competition = {
      low: 'low competition',
      medium: 'moderate competition',
      high: 'high competition',
    };

    return `The "${analysis.niche}" niche is ${direction[analysis.trendDirection]} with ${competition[analysis.competitionLevel]}. ` +
      `Current trend score: ${Math.round(analysis.score)}/100. ` +
      `Consider products like: ${analysis.suggestedProducts.slice(0, 3).join(', ')}.`;
  }

  /**
   * Generate action items
   */
  private generateActionItems(analysis: NicheAnalysis): ActionItem[] {
    const items: ActionItem[] = [
      {
        id: uuidv4(),
        action: `Research "${analysis.niche}" competitor products on Etsy and Amazon`,
        priority: 'high',
        estimatedEffort: '1-2 hours',
        completed: false,
      },
      {
        id: uuidv4(),
        action: `Create 2-3 test designs for ${analysis.suggestedProducts[0]}`,
        priority: 'high',
        estimatedEffort: '2-4 hours',
        completed: false,
      },
      {
        id: uuidv4(),
        action: `Set up keyword tracking for "${analysis.niche}" and related terms`,
        priority: 'medium',
        estimatedEffort: '30 minutes',
        completed: false,
      },
    ];

    if (analysis.trendDirection === 'rising') {
      items.push({
        id: uuidv4(),
        action: 'Prioritize quick launch to capture rising trend momentum',
        priority: 'urgent',
        estimatedEffort: '1 day',
        completed: false,
      });
    }

    if (analysis.competitionLevel === 'low') {
      items.push({
        id: uuidv4(),
        action: 'Consider expanding to multiple product types quickly',
        priority: 'medium',
        estimatedEffort: '1-2 days',
        completed: false,
      });
    }

    return items;
  }

  /**
   * Get top niches by category
   */
  async getTopNichesByCategory(
    trendData: TrendDataPoint[],
    categories: string[]
  ): Promise<Map<string, NicheRecommendation[]>> {
    const results = new Map<string, NicheRecommendation[]>();

    for (const category of categories) {
      const categoryData = trendData.filter(
        d => (d.metadata as { category?: string })?.category === category
      );

      if (categoryData.length > 0) {
        const recommendations = await this.suggestNiches(categoryData, {
          category,
        });
        results.set(category, recommendations.slice(0, 5));
      }
    }

    return results;
  }
}

/**
 * Factory function
 */
export function createNicheSuggester(
  config?: Partial<NicheSuggesterConfig>
): NicheSuggester {
  return new NicheSuggester(config);
}
