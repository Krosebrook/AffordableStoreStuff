/**
 * ============================================================================
 * PREDICTIVE ANALYTICS ENGINE - TYPE DEFINITIONS
 * ============================================================================
 * TypeScript interfaces for the forecasting and analytics system
 */

// =============================================================================
// CORE FORECAST TYPES
// =============================================================================

export type ForecastType = 'revenue' | 'demand' | 'trend' | 'inventory';
export type ModelType = 'moving_average' | 'exponential_smoothing' | 'linear_regression' | 'seasonal_decomposition';
export type RecommendationType = 'niche' | 'price' | 'timing' | 'action';
export type TrendDirection = 'rising' | 'falling' | 'stable' | 'volatile';
export type ConfidenceLevel = 'low' | 'medium' | 'high' | 'very_high';

export interface PredictionPoint {
  date: Date;
  value: number;
  lowerBound: number;
  upperBound: number;
}

export interface Forecast {
  id: string;
  type: ForecastType;
  targetEntity: string;
  predictions: PredictionPoint[];
  confidence: number;
  confidenceLevel: ConfidenceLevel;
  modelUsed: ModelType;
  dataPointsUsed: number;
  generatedAt: Date;
  validUntil: Date;
  metadata?: Record<string, unknown>;
}

// =============================================================================
// TREND TYPES
// =============================================================================

export interface TrendSignal {
  id: string;
  keyword: string;
  source: 'google_trends' | 'reddit' | 'twitter' | 'internal' | 'combined';
  currentScore: number;
  previousScore: number;
  changePercent: number;
  direction: TrendDirection;
  velocity: number; // Rate of change
  momentum: number; // Acceleration of change
  seasonality?: SeasonalPattern;
  relatedKeywords: string[];
  lastUpdated: Date;
}

export interface SeasonalPattern {
  type: 'daily' | 'weekly' | 'monthly' | 'yearly';
  peakPeriods: string[]; // e.g., ['December', 'January'] for yearly
  troughPeriods: string[];
  amplitude: number; // 0-1 strength of seasonality
}

export interface TrendAnalysis {
  keyword: string;
  signals: TrendSignal[];
  aggregateScore: number;
  aggregateDirection: TrendDirection;
  confidenceLevel: ConfidenceLevel;
  forecast: PredictionPoint[];
  recommendations: string[];
  analyzedAt: Date;
}

// =============================================================================
// RECOMMENDATION TYPES
// =============================================================================

export interface Recommendation {
  id: string;
  type: RecommendationType;
  title: string;
  description: string;
  confidence: number;
  confidenceLevel: ConfidenceLevel;
  potentialImpact: string;
  estimatedRevenue?: number;
  riskLevel: 'low' | 'medium' | 'high';
  actionItems: ActionItem[];
  validUntil: Date;
  createdAt: Date;
  metadata?: Record<string, unknown>;
}

export interface ActionItem {
  id: string;
  action: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedEffort: string; // e.g., '1 hour', '2-3 days'
  deadline?: Date;
  completed: boolean;
}

export interface NicheRecommendation extends Recommendation {
  type: 'niche';
  niche: string;
  keywords: string[];
  competitionLevel: 'low' | 'medium' | 'high';
  searchVolume: number;
  trendDirection: TrendDirection;
  seasonality?: SeasonalPattern;
  suggestedProducts: string[];
}

export interface PriceRecommendation extends Recommendation {
  type: 'price';
  productId: string;
  currentPrice: number;
  recommendedPrice: number;
  priceRange: { min: number; max: number };
  elasticity: number; // Price elasticity estimate
  competitorPrices: number[];
}

export interface TimingRecommendation extends Recommendation {
  type: 'timing';
  activity: string;
  optimalTimes: { dayOfWeek: number; hourOfDay: number; score: number }[];
  avoidTimes: { dayOfWeek: number; hourOfDay: number; reason: string }[];
}

// =============================================================================
// DATA SOURCE TYPES
// =============================================================================

export interface DataPoint {
  timestamp: Date;
  value: number;
  source: string;
  metadata?: Record<string, unknown>;
}

export interface TimeSeriesData {
  entityId: string;
  entityType: string;
  dataPoints: DataPoint[];
  startDate: Date;
  endDate: Date;
  granularity: 'hourly' | 'daily' | 'weekly' | 'monthly';
}

export interface GoogleTrendsData {
  keyword: string;
  timelineData: { date: Date; value: number }[];
  relatedQueries: { query: string; value: number }[];
  relatedTopics: { topic: string; value: number }[];
  geoData?: { location: string; value: number }[];
  fetchedAt: Date;
}

export interface SocialSignal {
  platform: 'reddit' | 'twitter' | 'tiktok';
  keyword: string;
  mentionCount: number;
  sentimentScore: number; // -1 to 1
  engagementScore: number;
  influencerMentions: number;
  viralPotential: number; // 0 to 1
  fetchedAt: Date;
}

export interface InternalSalesData {
  productId: string;
  platform: string;
  revenue: number;
  units: number;
  date: Date;
  metadata?: Record<string, unknown>;
}

// =============================================================================
// ML MODEL TYPES
// =============================================================================

export interface ModelConfig {
  type: ModelType;
  parameters: Record<string, number | string | boolean>;
  minDataPoints: number;
  maxDataPoints?: number;
}

export interface ModelResult {
  model: ModelType;
  predictions: PredictionPoint[];
  accuracy: number;
  mse: number; // Mean Squared Error
  mae: number; // Mean Absolute Error
  mape: number; // Mean Absolute Percentage Error
  trainingDataPoints: number;
  generatedAt: Date;
}

export interface MovingAverageConfig extends ModelConfig {
  type: 'moving_average';
  parameters: {
    windowSize: number;
    weights?: number[];
  };
}

export interface ExponentialSmoothingConfig extends ModelConfig {
  type: 'exponential_smoothing';
  parameters: {
    alpha: number; // Level smoothing
    beta?: number; // Trend smoothing (for Holt's method)
    gamma?: number; // Seasonal smoothing (for Holt-Winters)
    seasonalPeriods?: number;
  };
}

export interface LinearRegressionConfig extends ModelConfig {
  type: 'linear_regression';
  parameters: {
    includeIntercept: boolean;
    regularization?: 'none' | 'l1' | 'l2';
    regularizationStrength?: number;
  };
}

export interface SeasonalDecompositionConfig extends ModelConfig {
  type: 'seasonal_decomposition';
  parameters: {
    period: number;
    method: 'additive' | 'multiplicative';
    trendSmoothingWindow?: number;
  };
}

// =============================================================================
// INVENTORY TYPES
// =============================================================================

export interface InventoryLevel {
  productId: string;
  platform: string;
  currentStock: number;
  reservedStock: number;
  availableStock: number;
  reorderPoint: number;
  reorderQuantity: number;
  leadTimeDays: number;
  lastUpdated: Date;
}

export interface InventoryForecast extends Forecast {
  type: 'inventory';
  productId: string;
  platform: string;
  currentStock: number;
  predictedStockout?: Date;
  suggestedReorderDate?: Date;
  suggestedReorderQuantity?: number;
  dailyDemandForecast: PredictionPoint[];
}

// =============================================================================
// REVENUE TYPES
// =============================================================================

export interface RevenueForecast extends Forecast {
  type: 'revenue';
  totalPredictedRevenue: number;
  revenueByPlatform: Record<string, number>;
  revenueByProduct: Record<string, number>;
  growthRate: number;
  seasonalFactors: Record<string, number>;
}

export interface RevenueBreakdown {
  period: string;
  totalRevenue: number;
  byPlatform: { platform: string; revenue: number; units: number }[];
  byProduct: { productId: string; title: string; revenue: number; units: number }[];
  byCategory: { category: string; revenue: number }[];
  comparedToPrevious: {
    percentChange: number;
    absoluteChange: number;
  };
}

// =============================================================================
// DEMAND TYPES
// =============================================================================

export interface DemandForecast extends Forecast {
  type: 'demand';
  productId: string;
  predictedUnits: number;
  demandDrivers: DemandDriver[];
  peakDemandDates: Date[];
  lowDemandDates: Date[];
}

export interface DemandDriver {
  factor: string;
  impact: number; // -1 to 1, negative = decreases demand
  confidence: number;
  description: string;
}

// =============================================================================
// API TYPES
// =============================================================================

export interface AnalyticsRequest {
  type: ForecastType;
  entityId?: string;
  startDate?: Date;
  endDate?: Date;
  horizon?: number; // Days to forecast
  models?: ModelType[];
  includeRecommendations?: boolean;
}

export interface AnalyticsResponse<T = Forecast> {
  success: boolean;
  data?: T;
  error?: string;
  generatedAt: Date;
  processingTimeMs: number;
}

export interface TrendRequest {
  keywords: string[];
  sources?: ('google_trends' | 'reddit' | 'twitter' | 'internal')[];
  timeRange?: 'day' | 'week' | 'month' | 'quarter' | 'year';
  geo?: string; // ISO country code
}

export interface TrendResponse {
  success: boolean;
  trends: TrendAnalysis[];
  topRising: TrendSignal[];
  topFalling: TrendSignal[];
  recommendations: Recommendation[];
  fetchedAt: Date;
}

export interface RecommendationRequest {
  types?: RecommendationType[];
  limit?: number;
  minConfidence?: number;
  includeCompleted?: boolean;
}

export interface RecommendationResponse {
  success: boolean;
  recommendations: Recommendation[];
  totalCount: number;
  generatedAt: Date;
}

// =============================================================================
// ENGINE CONFIGURATION
// =============================================================================

export interface AnalyticsEngineConfig {
  supabaseUrl: string;
  supabaseKey: string;
  cacheEnabled: boolean;
  cacheTtlMinutes: number;
  defaultForecastHorizon: number;
  confidenceThresholds: {
    low: number;
    medium: number;
    high: number;
    veryHigh: number;
  };
  dataSourceWeights: {
    googleTrends: number;
    reddit: number;
    twitter: number;
    internal: number;
  };
  modelDefaults: Record<ModelType, ModelConfig>;
}

export interface EngineStatus {
  initialized: boolean;
  lastUpdate: Date;
  dataSourceStatus: Record<string, 'healthy' | 'degraded' | 'offline'>;
  cachedForecasts: number;
  pendingRequests: number;
  errors: { source: string; message: string; timestamp: Date }[];
}
