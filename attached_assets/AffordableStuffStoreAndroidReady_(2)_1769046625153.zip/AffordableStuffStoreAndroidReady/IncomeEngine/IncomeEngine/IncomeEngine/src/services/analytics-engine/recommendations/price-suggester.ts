/**
 * ============================================================================
 * PRICE SUGGESTER
 * ============================================================================
 * Optimal price recommendations based on market data and elasticity analysis
 */

import { v4 as uuidv4 } from 'uuid';
import type {
  PriceRecommendation,
  ActionItem,
  ConfidenceLevel,
} from '../types.js';

export interface PriceSuggesterConfig {
  defaultMarginTarget: number; // Target profit margin (e.g., 0.3 for 30%)
  minPriceFloor: number;
  maxPriceCeiling: number;
  competitorWeight: number; // How much to weigh competitor prices
  elasticityWeight: number; // How much to weigh price elasticity
}

export interface ProductPricingData {
  productId: string;
  currentPrice: number;
  cost: number;
  salesHistory: { date: Date; units: number; price: number }[];
  competitorPrices?: number[];
  category?: string;
  platform?: string;
}

export interface PriceAnalysis {
  productId: string;
  currentPrice: number;
  optimalPrice: number;
  priceRange: { min: number; max: number };
  elasticity: number;
  currentMargin: number;
  optimalMargin: number;
  expectedRevenueChange: number;
  expectedUnitChange: number;
  competitorPosition: 'below' | 'at' | 'above';
}

export class PriceSuggester {
  private readonly config: PriceSuggesterConfig;

  constructor(config?: Partial<PriceSuggesterConfig>) {
    this.config = {
      defaultMarginTarget: config?.defaultMarginTarget ?? 0.4,
      minPriceFloor: config?.minPriceFloor ?? 5,
      maxPriceCeiling: config?.maxPriceCeiling ?? 500,
      competitorWeight: config?.competitorWeight ?? 0.3,
      elasticityWeight: config?.elasticityWeight ?? 0.4,
    };
  }

  /**
   * Generate price recommendation for a product
   */
  async suggestPrice(
    pricingData: ProductPricingData
  ): Promise<PriceRecommendation> {
    const analysis = this.analyzePrice(pricingData);
    return this.analysisToRecommendation(analysis, pricingData);
  }

  /**
   * Suggest prices for multiple products
   */
  async suggestPrices(
    products: ProductPricingData[]
  ): Promise<PriceRecommendation[]> {
    const recommendations: PriceRecommendation[] = [];

    for (const product of products) {
      try {
        const recommendation = await this.suggestPrice(product);
        recommendations.push(recommendation);
      } catch (error) {
        console.warn(
          `Failed to suggest price for ${product.productId}:`,
          error
        );
      }
    }

    // Sort by expected revenue change (highest potential first)
    return recommendations.sort(
      (a, b) => (b.estimatedRevenue ?? 0) - (a.estimatedRevenue ?? 0)
    );
  }

  /**
   * Analyze price for a product
   */
  private analyzePrice(pricingData: ProductPricingData): PriceAnalysis {
    const {
      productId,
      currentPrice,
      cost,
      salesHistory,
      competitorPrices,
    } = pricingData;

    // Calculate price elasticity
    const elasticity = this.calculatePriceElasticity(salesHistory);

    // Calculate current margin
    const currentMargin = (currentPrice - cost) / currentPrice;

    // Calculate optimal price based on multiple factors
    const optimalPrice = this.calculateOptimalPrice(
      currentPrice,
      cost,
      elasticity,
      competitorPrices
    );

    // Calculate optimal margin
    const optimalMargin = (optimalPrice - cost) / optimalPrice;

    // Calculate price range
    const priceRange = this.calculatePriceRange(
      cost,
      competitorPrices,
      elasticity
    );

    // Estimate revenue change
    const { revenueChange, unitChange } = this.estimateChanges(
      currentPrice,
      optimalPrice,
      salesHistory,
      elasticity
    );

    // Determine competitor position
    const competitorPosition = this.determineCompetitorPosition(
      optimalPrice,
      competitorPrices
    );

    return {
      productId,
      currentPrice,
      optimalPrice,
      priceRange,
      elasticity,
      currentMargin,
      optimalMargin,
      expectedRevenueChange: revenueChange,
      expectedUnitChange: unitChange,
      competitorPosition,
    };
  }

  /**
   * Calculate price elasticity from sales history
   */
  private calculatePriceElasticity(
    salesHistory: { date: Date; units: number; price: number }[]
  ): number {
    if (salesHistory.length < 10) {
      // Not enough data, return assumed elasticity
      return -1.5; // Typical consumer goods elasticity
    }

    // Find price changes and corresponding demand changes
    const changes: { priceChange: number; demandChange: number }[] = [];

    for (let i = 1; i < salesHistory.length; i++) {
      const prevPrice = salesHistory[i - 1].price;
      const currPrice = salesHistory[i].price;
      const prevUnits = salesHistory[i - 1].units;
      const currUnits = salesHistory[i].units;

      if (
        prevPrice !== currPrice &&
        prevPrice > 0 &&
        prevUnits > 0
      ) {
        const priceChange = (currPrice - prevPrice) / prevPrice;
        const demandChange = (currUnits - prevUnits) / prevUnits;

        changes.push({ priceChange, demandChange });
      }
    }

    if (changes.length === 0) {
      return -1.5; // Default elasticity
    }

    // Calculate average elasticity
    const elasticities = changes.map(c =>
      c.priceChange !== 0 ? c.demandChange / c.priceChange : 0
    );

    const avgElasticity =
      elasticities.reduce((a, b) => a + b, 0) / elasticities.length;

    // Clamp to reasonable range
    return Math.max(-5, Math.min(-0.1, avgElasticity));
  }

  /**
   * Calculate optimal price
   */
  private calculateOptimalPrice(
    currentPrice: number,
    cost: number,
    elasticity: number,
    competitorPrices?: number[]
  ): number {
    // Method 1: Markup pricing (based on target margin)
    const markupPrice = cost / (1 - this.config.defaultMarginTarget);

    // Method 2: Elasticity-based pricing (profit maximization)
    // Optimal price = marginal cost * elasticity / (elasticity + 1)
    const elasticityPrice =
      elasticity < -1 ? (cost * elasticity) / (elasticity + 1) : markupPrice;

    // Method 3: Competitor-based pricing
    let competitorPrice = currentPrice;
    if (competitorPrices && competitorPrices.length > 0) {
      const avgCompetitorPrice =
        competitorPrices.reduce((a, b) => a + b, 0) / competitorPrices.length;
      // Price slightly below average competitor
      competitorPrice = avgCompetitorPrice * 0.95;
    }

    // Weighted combination
    const baseWeight = 1 - this.config.competitorWeight - this.config.elasticityWeight;
    const optimalPrice =
      markupPrice * baseWeight +
      elasticityPrice * this.config.elasticityWeight +
      competitorPrice * this.config.competitorWeight;

    // Ensure minimum margin and apply floor/ceiling
    const minPrice = Math.max(
      this.config.minPriceFloor,
      cost * 1.1 // At least 10% margin
    );
    const maxPrice = Math.min(
      this.config.maxPriceCeiling,
      competitorPrices
        ? Math.max(...competitorPrices) * 1.2
        : currentPrice * 2
    );

    return Math.round(Math.max(minPrice, Math.min(maxPrice, optimalPrice)) * 100) / 100;
  }

  /**
   * Calculate acceptable price range
   */
  private calculatePriceRange(
    cost: number,
    competitorPrices?: number[],
    elasticity?: number
  ): { min: number; max: number } {
    const minPrice = cost * 1.2; // Minimum 20% margin

    let maxPrice = cost * 3; // Default 3x markup max

    if (competitorPrices && competitorPrices.length > 0) {
      maxPrice = Math.max(...competitorPrices) * 1.1;
    }

    return {
      min: Math.round(minPrice * 100) / 100,
      max: Math.round(maxPrice * 100) / 100,
    };
  }

  /**
   * Estimate revenue and unit changes
   */
  private estimateChanges(
    currentPrice: number,
    optimalPrice: number,
    salesHistory: { date: Date; units: number; price: number }[],
    elasticity: number
  ): { revenueChange: number; unitChange: number } {
    // Calculate average units sold
    const avgUnits =
      salesHistory.length > 0
        ? salesHistory.reduce((sum, s) => sum + s.units, 0) /
          salesHistory.length
        : 10;

    // Calculate price change percentage
    const priceChangePercent = (optimalPrice - currentPrice) / currentPrice;

    // Estimate unit change based on elasticity
    const unitChangePercent = priceChangePercent * elasticity;
    const newUnits = avgUnits * (1 + unitChangePercent);

    // Calculate revenue change
    const currentRevenue = currentPrice * avgUnits;
    const newRevenue = optimalPrice * newUnits;
    const revenueChange = newRevenue - currentRevenue;

    return {
      revenueChange: Math.round(revenueChange * 100) / 100,
      unitChange: Math.round((newUnits - avgUnits) * 10) / 10,
    };
  }

  /**
   * Determine position relative to competitors
   */
  private determineCompetitorPosition(
    price: number,
    competitorPrices?: number[]
  ): 'below' | 'at' | 'above' {
    if (!competitorPrices || competitorPrices.length === 0) {
      return 'at';
    }

    const avgCompetitor =
      competitorPrices.reduce((a, b) => a + b, 0) / competitorPrices.length;

    if (price < avgCompetitor * 0.95) return 'below';
    if (price > avgCompetitor * 1.05) return 'above';
    return 'at';
  }

  /**
   * Convert analysis to recommendation
   */
  private analysisToRecommendation(
    analysis: PriceAnalysis,
    pricingData: ProductPricingData
  ): PriceRecommendation {
    const priceDiff = analysis.optimalPrice - analysis.currentPrice;
    const priceDiffPercent =
      (priceDiff / analysis.currentPrice) * 100;

    const confidence = this.calculateConfidence(analysis, pricingData);
    const confidenceLevel = this.getConfidenceLevel(confidence);
    const riskLevel = this.calculateRiskLevel(analysis, priceDiffPercent);

    const actionItems = this.generateActionItems(analysis, priceDiffPercent);

    return {
      id: uuidv4(),
      type: 'price',
      title: this.generateTitle(analysis, priceDiffPercent),
      description: this.generateDescription(analysis, priceDiffPercent),
      confidence,
      confidenceLevel,
      potentialImpact: this.formatPotentialImpact(analysis),
      estimatedRevenue: analysis.expectedRevenueChange,
      riskLevel,
      actionItems,
      validUntil: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // Valid for 14 days
      createdAt: new Date(),
      productId: analysis.productId,
      currentPrice: analysis.currentPrice,
      recommendedPrice: analysis.optimalPrice,
      priceRange: analysis.priceRange,
      elasticity: analysis.elasticity,
      competitorPrices: pricingData.competitorPrices ?? [],
    };
  }

  /**
   * Calculate recommendation confidence
   */
  private calculateConfidence(
    analysis: PriceAnalysis,
    pricingData: ProductPricingData
  ): number {
    let confidence = 0.5;

    // More sales history = higher confidence
    const dataPoints = pricingData.salesHistory.length;
    confidence += Math.min(0.2, dataPoints / 100);

    // Competitor data available = higher confidence
    if (pricingData.competitorPrices && pricingData.competitorPrices.length > 0) {
      confidence += 0.15;
    }

    // Clear elasticity signal = higher confidence
    if (Math.abs(analysis.elasticity) > 0.5 && Math.abs(analysis.elasticity) < 3) {
      confidence += 0.1;
    }

    // Small price change = higher confidence
    const priceChangePercent = Math.abs(
      (analysis.optimalPrice - analysis.currentPrice) / analysis.currentPrice
    );
    if (priceChangePercent < 0.15) {
      confidence += 0.1;
    }

    return Math.max(0, Math.min(1, confidence));
  }

  /**
   * Get confidence level label
   */
  private getConfidenceLevel(confidence: number): ConfidenceLevel {
    if (confidence >= 0.85) return 'very_high';
    if (confidence >= 0.7) return 'high';
    if (confidence >= 0.5) return 'medium';
    return 'low';
  }

  /**
   * Calculate risk level
   */
  private calculateRiskLevel(
    analysis: PriceAnalysis,
    priceDiffPercent: number
  ): 'low' | 'medium' | 'high' {
    const absChange = Math.abs(priceDiffPercent);

    if (absChange > 30) return 'high';
    if (absChange > 15) return 'medium';
    return 'low';
  }

  /**
   * Generate title
   */
  private generateTitle(
    analysis: PriceAnalysis,
    priceDiffPercent: number
  ): string {
    if (Math.abs(priceDiffPercent) < 3) {
      return `Keep current price for product ${analysis.productId}`;
    }

    const direction = priceDiffPercent > 0 ? 'Increase' : 'Decrease';
    return `${direction} price for product ${analysis.productId}`;
  }

  /**
   * Generate description
   */
  private generateDescription(
    analysis: PriceAnalysis,
    priceDiffPercent: number
  ): string {
    if (Math.abs(priceDiffPercent) < 3) {
      return `Current price of $${analysis.currentPrice.toFixed(2)} is within optimal range. ` +
        `Current margin: ${(analysis.currentMargin * 100).toFixed(1)}%.`;
    }

    const direction = priceDiffPercent > 0 ? 'increase' : 'decrease';
    const absPercent = Math.abs(priceDiffPercent).toFixed(1);

    return `Recommend ${direction} from $${analysis.currentPrice.toFixed(2)} to ` +
      `$${analysis.optimalPrice.toFixed(2)} (${absPercent}% ${direction}). ` +
      `Expected revenue impact: ${analysis.expectedRevenueChange >= 0 ? '+' : ''}` +
      `$${analysis.expectedRevenueChange.toFixed(2)}/month. ` +
      `Price elasticity: ${analysis.elasticity.toFixed(2)}.`;
  }

  /**
   * Format potential impact
   */
  private formatPotentialImpact(analysis: PriceAnalysis): string {
    const revenueImpact = analysis.expectedRevenueChange >= 0 ? '+' : '';
    return `${revenueImpact}$${analysis.expectedRevenueChange.toFixed(0)}/month revenue`;
  }

  /**
   * Generate action items
   */
  private generateActionItems(
    analysis: PriceAnalysis,
    priceDiffPercent: number
  ): ActionItem[] {
    const items: ActionItem[] = [];

    if (Math.abs(priceDiffPercent) < 3) {
      items.push({
        id: uuidv4(),
        action: 'Monitor competitor prices weekly for changes',
        priority: 'low',
        estimatedEffort: '15 minutes',
        completed: false,
      });
      return items;
    }

    if (Math.abs(priceDiffPercent) > 20) {
      items.push({
        id: uuidv4(),
        action: 'Implement price change gradually over 2-4 weeks',
        priority: 'high',
        estimatedEffort: '30 minutes',
        completed: false,
      });
    } else {
      items.push({
        id: uuidv4(),
        action: 'Update price on all platforms',
        priority: 'high',
        estimatedEffort: '15 minutes',
        completed: false,
      });
    }

    items.push({
      id: uuidv4(),
      action: 'Update product listings to reflect value proposition',
      priority: 'medium',
      estimatedEffort: '30 minutes',
      completed: false,
    });

    items.push({
      id: uuidv4(),
      action: 'Monitor sales for 2 weeks after price change',
      priority: 'high',
      estimatedEffort: '10 minutes daily',
      deadline: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      completed: false,
    });

    return items;
  }

  /**
   * Find products with pricing opportunities
   */
  async findPricingOpportunities(
    products: ProductPricingData[],
    minRevenueChange: number = 50
  ): Promise<PriceRecommendation[]> {
    const recommendations = await this.suggestPrices(products);

    return recommendations.filter(
      r => Math.abs(r.estimatedRevenue ?? 0) >= minRevenueChange
    );
  }
}

/**
 * Factory function
 */
export function createPriceSuggester(
  config?: Partial<PriceSuggesterConfig>
): PriceSuggester {
  return new PriceSuggester(config);
}
