/**
 * ============================================================================
 * INTERNAL DATA SOURCE
 * ============================================================================
 * Access to historical sales, revenue, and inventory data from the database
 */

import type {
  DataPoint,
  TimeSeriesData,
  InternalSalesData,
} from '../types.js';
import type { RevenueData } from '../forecasting/revenue-predictor.js';
import type { InventoryDataPoint } from '../forecasting/inventory-predictor.js';
import type { DemandDataPoint } from '../forecasting/demand-predictor.js';
import type { TrendDataPoint } from '../forecasting/trend-predictor.js';

export interface InternalDataConfig {
  supabaseUrl?: string;
  supabaseKey?: string;
  cacheEnabled: boolean;
  cacheTtlMinutes: number;
}

export interface DateRange {
  start: Date;
  end: Date;
}

export interface SalesQuery {
  productId?: string;
  platform?: string;
  dateRange?: DateRange;
  groupBy?: 'day' | 'week' | 'month';
}

interface CacheEntry<T> {
  data: T;
  expiresAt: Date;
}

/**
 * Internal data source for accessing historical data
 */
export class InternalDataSource {
  private readonly config: InternalDataConfig;
  private cache: Map<string, CacheEntry<unknown>> = new Map();

  constructor(config?: Partial<InternalDataConfig>) {
    this.config = {
      supabaseUrl: config?.supabaseUrl ?? process.env.SUPABASE_URL,
      supabaseKey: config?.supabaseKey ?? process.env.SUPABASE_SERVICE_KEY,
      cacheEnabled: config?.cacheEnabled ?? true,
      cacheTtlMinutes: config?.cacheTtlMinutes ?? 15,
    };
  }

  /**
   * Get revenue data for forecasting
   */
  async getRevenueData(query?: SalesQuery): Promise<RevenueData[]> {
    const cacheKey = `revenue:${JSON.stringify(query ?? {})}`;

    if (this.config.cacheEnabled) {
      const cached = this.getCached<RevenueData[]>(cacheKey);
      if (cached) return cached;
    }

    try {
      // In production, this would query the database
      const data = await this.fetchRevenueFromDatabase(query);
      this.setCache(cacheKey, data);
      return data;
    } catch (error) {
      console.warn('Failed to fetch revenue data:', error);
      // Return simulated data for development
      return this.generateSimulatedRevenueData(query);
    }
  }

  /**
   * Get inventory data for forecasting
   */
  async getInventoryData(query?: SalesQuery): Promise<InventoryDataPoint[]> {
    const cacheKey = `inventory:${JSON.stringify(query ?? {})}`;

    if (this.config.cacheEnabled) {
      const cached = this.getCached<InventoryDataPoint[]>(cacheKey);
      if (cached) return cached;
    }

    try {
      const data = await this.fetchInventoryFromDatabase(query);
      this.setCache(cacheKey, data);
      return data;
    } catch (error) {
      console.warn('Failed to fetch inventory data:', error);
      return this.generateSimulatedInventoryData(query);
    }
  }

  /**
   * Get demand data for forecasting
   */
  async getDemandData(query?: SalesQuery): Promise<DemandDataPoint[]> {
    const cacheKey = `demand:${JSON.stringify(query ?? {})}`;

    if (this.config.cacheEnabled) {
      const cached = this.getCached<DemandDataPoint[]>(cacheKey);
      if (cached) return cached;
    }

    try {
      const data = await this.fetchDemandFromDatabase(query);
      this.setCache(cacheKey, data);
      return data;
    } catch (error) {
      console.warn('Failed to fetch demand data:', error);
      return this.generateSimulatedDemandData(query);
    }
  }

  /**
   * Get trend data from internal sources
   */
  async getTrendData(keywords: string[]): Promise<TrendDataPoint[]> {
    const cacheKey = `trends:${keywords.join(',')}`;

    if (this.config.cacheEnabled) {
      const cached = this.getCached<TrendDataPoint[]>(cacheKey);
      if (cached) return cached;
    }

    try {
      const data = await this.fetchTrendsFromDatabase(keywords);
      this.setCache(cacheKey, data);
      return data;
    } catch (error) {
      console.warn('Failed to fetch trend data:', error);
      return this.generateSimulatedTrendData(keywords);
    }
  }

  /**
   * Get time series data
   */
  async getTimeSeriesData(
    entityId: string,
    entityType: 'product' | 'platform' | 'category',
    metric: 'revenue' | 'units' | 'views',
    dateRange?: DateRange,
    granularity: 'hourly' | 'daily' | 'weekly' | 'monthly' = 'daily'
  ): Promise<TimeSeriesData> {
    const cacheKey = `timeseries:${entityId}:${entityType}:${metric}:${granularity}`;

    if (this.config.cacheEnabled) {
      const cached = this.getCached<TimeSeriesData>(cacheKey);
      if (cached) return cached;
    }

    // Generate time series data
    const range = dateRange ?? this.getDefaultDateRange();
    const dataPoints = this.generateTimeSeriesPoints(
      metric,
      range,
      granularity
    );

    const data: TimeSeriesData = {
      entityId,
      entityType,
      dataPoints,
      startDate: range.start,
      endDate: range.end,
      granularity,
    };

    this.setCache(cacheKey, data);
    return data;
  }

  /**
   * Get sales aggregates
   */
  async getSalesAggregates(
    dateRange?: DateRange
  ): Promise<{
    totalRevenue: number;
    totalUnits: number;
    avgOrderValue: number;
    topProducts: { productId: string; revenue: number; units: number }[];
    topPlatforms: { platform: string; revenue: number; units: number }[];
  }> {
    const range = dateRange ?? this.getDefaultDateRange();
    const revenueData = await this.getRevenueData({ dateRange: range });

    const totalRevenue = revenueData.reduce((sum, d) => sum + d.revenue, 0);
    const totalUnits = revenueData.reduce((sum, d) => sum + (d.units ?? 0), 0);
    const avgOrderValue = totalUnits > 0 ? totalRevenue / totalUnits : 0;

    // Aggregate by product
    const productMap = new Map<string, { revenue: number; units: number }>();
    for (const d of revenueData) {
      const key = d.productId ?? 'unknown';
      const existing = productMap.get(key) ?? { revenue: 0, units: 0 };
      productMap.set(key, {
        revenue: existing.revenue + d.revenue,
        units: existing.units + (d.units ?? 0),
      });
    }

    // Aggregate by platform
    const platformMap = new Map<string, { revenue: number; units: number }>();
    for (const d of revenueData) {
      const key = d.platform ?? 'unknown';
      const existing = platformMap.get(key) ?? { revenue: 0, units: 0 };
      platformMap.set(key, {
        revenue: existing.revenue + d.revenue,
        units: existing.units + (d.units ?? 0),
      });
    }

    const topProducts = Array.from(productMap.entries())
      .map(([productId, data]) => ({ productId, ...data }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    const topPlatforms = Array.from(platformMap.entries())
      .map(([platform, data]) => ({ platform, ...data }))
      .sort((a, b) => b.revenue - a.revenue);

    return {
      totalRevenue,
      totalUnits,
      avgOrderValue,
      topProducts,
      topPlatforms,
    };
  }

  /**
   * Get product performance metrics
   */
  async getProductPerformance(
    productId: string,
    dateRange?: DateRange
  ): Promise<{
    totalRevenue: number;
    totalUnits: number;
    avgPrice: number;
    platformBreakdown: Record<string, { revenue: number; units: number }>;
    dailyTrend: DataPoint[];
  }> {
    const range = dateRange ?? this.getDefaultDateRange();
    const revenueData = await this.getRevenueData({
      productId,
      dateRange: range,
    });

    const totalRevenue = revenueData.reduce((sum, d) => sum + d.revenue, 0);
    const totalUnits = revenueData.reduce((sum, d) => sum + (d.units ?? 0), 0);
    const avgPrice = totalUnits > 0 ? totalRevenue / totalUnits : 0;

    // Platform breakdown
    const platformBreakdown: Record<string, { revenue: number; units: number }> = {};
    for (const d of revenueData) {
      const key = d.platform ?? 'unknown';
      if (!platformBreakdown[key]) {
        platformBreakdown[key] = { revenue: 0, units: 0 };
      }
      platformBreakdown[key].revenue += d.revenue;
      platformBreakdown[key].units += d.units ?? 0;
    }

    // Daily trend
    const dailyTrend = this.aggregateByDay(revenueData);

    return {
      totalRevenue,
      totalUnits,
      avgPrice,
      platformBreakdown,
      dailyTrend,
    };
  }

  /**
   * Fetch revenue from database (placeholder)
   */
  private async fetchRevenueFromDatabase(
    query?: SalesQuery
  ): Promise<RevenueData[]> {
    // In production, this would query Supabase
    // const { data, error } = await supabase
    //   .from('sales')
    //   .select('*')
    //   .gte('date', query?.dateRange?.start.toISOString())
    //   .lte('date', query?.dateRange?.end.toISOString());

    throw new Error('Database not configured');
  }

  /**
   * Fetch inventory from database (placeholder)
   */
  private async fetchInventoryFromDatabase(
    query?: SalesQuery
  ): Promise<InventoryDataPoint[]> {
    throw new Error('Database not configured');
  }

  /**
   * Fetch demand from database (placeholder)
   */
  private async fetchDemandFromDatabase(
    query?: SalesQuery
  ): Promise<DemandDataPoint[]> {
    throw new Error('Database not configured');
  }

  /**
   * Fetch trends from database (placeholder)
   */
  private async fetchTrendsFromDatabase(
    keywords: string[]
  ): Promise<TrendDataPoint[]> {
    throw new Error('Database not configured');
  }

  /**
   * Generate simulated revenue data
   */
  private generateSimulatedRevenueData(query?: SalesQuery): RevenueData[] {
    const range = query?.dateRange ?? this.getDefaultDateRange();
    const data: RevenueData[] = [];
    const platforms = ['printify', 'etsy', 'gumroad', 'shopify'];
    const productIds = ['prod-1', 'prod-2', 'prod-3', 'prod-4', 'prod-5'];

    const currentDate = new Date(range.start);
    while (currentDate <= range.end) {
      // Generate 2-5 transactions per day
      const transactionsToday = Math.floor(Math.random() * 4) + 2;

      for (let i = 0; i < transactionsToday; i++) {
        const platform = platforms[Math.floor(Math.random() * platforms.length)];
        const productId = productIds[Math.floor(Math.random() * productIds.length)];
        const units = Math.floor(Math.random() * 5) + 1;
        const pricePerUnit = 15 + Math.random() * 35;

        data.push({
          date: new Date(currentDate),
          revenue: units * pricePerUnit,
          platform,
          productId,
          units,
        });
      }

      currentDate.setDate(currentDate.getDate() + 1);
    }

    return data;
  }

  /**
   * Generate simulated inventory data
   */
  private generateSimulatedInventoryData(
    query?: SalesQuery
  ): InventoryDataPoint[] {
    const range = query?.dateRange ?? this.getDefaultDateRange();
    const data: InventoryDataPoint[] = [];
    const platforms = ['printify', 'shopify'];
    const productIds = ['prod-1', 'prod-2', 'prod-3'];

    for (const productId of productIds) {
      for (const platform of platforms) {
        let stockLevel = 100 + Math.floor(Math.random() * 100);
        const currentDate = new Date(range.start);

        while (currentDate <= range.end) {
          const unitsSold = Math.floor(Math.random() * 10);
          const unitsReceived = Math.random() > 0.9 ? 50 : 0;

          stockLevel = Math.max(0, stockLevel - unitsSold + unitsReceived);

          data.push({
            productId,
            platform,
            date: new Date(currentDate),
            stockLevel,
            unitsSold,
            unitsReceived: unitsReceived > 0 ? unitsReceived : undefined,
          });

          currentDate.setDate(currentDate.getDate() + 1);
        }
      }
    }

    return data;
  }

  /**
   * Generate simulated demand data
   */
  private generateSimulatedDemandData(query?: SalesQuery): DemandDataPoint[] {
    const range = query?.dateRange ?? this.getDefaultDateRange();
    const data: DemandDataPoint[] = [];
    const productIds = ['prod-1', 'prod-2', 'prod-3', 'prod-4', 'prod-5'];
    const platforms = ['printify', 'etsy', 'gumroad'];

    for (const productId of productIds) {
      const baseDemand = 5 + Math.floor(Math.random() * 15);
      const currentDate = new Date(range.start);

      while (currentDate <= range.end) {
        const dayOfWeek = currentDate.getDay();
        const weekendEffect = dayOfWeek === 0 || dayOfWeek === 6 ? 0.8 : 1;
        const randomness = 0.7 + Math.random() * 0.6;
        const trend = 1 + (currentDate.getTime() - range.start.getTime()) /
          (range.end.getTime() - range.start.getTime()) * 0.1;

        const units = Math.max(
          0,
          Math.round(baseDemand * weekendEffect * randomness * trend)
        );

        const promotion = Math.random() > 0.9;
        const platform = platforms[Math.floor(Math.random() * platforms.length)];
        const basePrice = 20 + Math.random() * 30;
        const price = promotion ? basePrice * 0.8 : basePrice;

        data.push({
          productId,
          date: new Date(currentDate),
          units: promotion ? Math.round(units * 1.5) : units,
          price,
          platform,
          promotion,
          category: 'apparel',
        });

        currentDate.setDate(currentDate.getDate() + 1);
      }
    }

    return data;
  }

  /**
   * Generate simulated trend data
   */
  private generateSimulatedTrendData(keywords: string[]): TrendDataPoint[] {
    const data: TrendDataPoint[] = [];
    const range = this.getDefaultDateRange();

    for (const keyword of keywords) {
      const baseScore = 30 + Math.random() * 40;
      const currentDate = new Date(range.start);

      while (currentDate <= range.end) {
        const trend = (currentDate.getTime() - range.start.getTime()) /
          (range.end.getTime() - range.start.getTime()) * 20;
        const noise = Math.random() * 20 - 10;
        const score = Math.max(0, Math.min(100, baseScore + trend + noise));

        data.push({
          keyword,
          source: 'internal',
          date: new Date(currentDate),
          score: Math.round(score),
        });

        currentDate.setDate(currentDate.getDate() + 1);
      }
    }

    return data;
  }

  /**
   * Generate time series points
   */
  private generateTimeSeriesPoints(
    metric: string,
    dateRange: DateRange,
    granularity: string
  ): DataPoint[] {
    const points: DataPoint[] = [];
    const currentDate = new Date(dateRange.start);
    const increment = granularity === 'hourly' ? 1 : granularity === 'weekly' ? 7 : 1;

    let baseValue = 100;
    while (currentDate <= dateRange.end) {
      baseValue = baseValue * (0.95 + Math.random() * 0.1);
      const noise = baseValue * (Math.random() * 0.2 - 0.1);

      points.push({
        timestamp: new Date(currentDate),
        value: baseValue + noise,
        source: 'internal',
      });

      if (granularity === 'hourly') {
        currentDate.setHours(currentDate.getHours() + 1);
      } else if (granularity === 'weekly') {
        currentDate.setDate(currentDate.getDate() + 7);
      } else if (granularity === 'monthly') {
        currentDate.setMonth(currentDate.getMonth() + 1);
      } else {
        currentDate.setDate(currentDate.getDate() + 1);
      }
    }

    return points;
  }

  /**
   * Aggregate data by day
   */
  private aggregateByDay(revenueData: RevenueData[]): DataPoint[] {
    const dayMap = new Map<string, number>();

    for (const d of revenueData) {
      const key = d.date.toISOString().split('T')[0];
      dayMap.set(key, (dayMap.get(key) ?? 0) + d.revenue);
    }

    return Array.from(dayMap.entries())
      .map(([dateStr, value]) => ({
        timestamp: new Date(dateStr),
        value,
        source: 'internal',
      }))
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  /**
   * Get default date range (last 30 days)
   */
  private getDefaultDateRange(): DateRange {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - 30);
    return { start, end };
  }

  /**
   * Get cached value
   */
  private getCached<T>(key: string): T | null {
    const entry = this.cache.get(key) as CacheEntry<T> | undefined;
    if (entry && entry.expiresAt > new Date()) {
      return entry.data;
    }
    return null;
  }

  /**
   * Set cache value
   */
  private setCache<T>(key: string, data: T): void {
    this.cache.set(key, {
      data,
      expiresAt: new Date(
        Date.now() + this.config.cacheTtlMinutes * 60 * 1000
      ),
    });
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.clear();
  }
}

/**
 * Factory function
 */
export function createInternalDataSource(
  config?: Partial<InternalDataConfig>
): InternalDataSource {
  return new InternalDataSource(config);
}
