/**
 * ============================================================================
 * STABILITY AI SD3 PROVIDER
 * ============================================================================
 *
 * Integration with Stability AI's Stable Diffusion 3 image generation API.
 * Supports SD3, SD3 Turbo, SD3 Large, and SD3 Large Turbo variants.
 */

import {
  ProviderName,
  ProviderConfig,
  ProviderCapabilities,
  GenerationOptions,
  GenerationResult,
  GenerationCost,
  ImageDimensions,
  ProviderHealth,
  StabilityModel,
  ImageFormat,
} from '../types';
import { BaseProvider } from './base-provider';

// =============================================================================
// TYPES
// =============================================================================

interface StabilityConfig extends ProviderConfig {
  readonly defaultModel?: StabilityModel;
}

interface StabilityResponse {
  image: string; // base64 encoded
  finish_reason: 'SUCCESS' | 'CONTENT_FILTERED' | 'ERROR';
  seed: number;
}

// =============================================================================
// MODEL CONFIGURATIONS
// =============================================================================

const STABILITY_MODELS: Record<
  StabilityModel,
  {
    endpoint: string;
    displayName: string;
    costPerMegapixel: number;
    defaultSteps: number;
    maxSteps: number;
    minWidth: number;
    minHeight: number;
    supportsCfgScale: boolean;
  }
> = {
  sd3: {
    endpoint: 'sd3',
    displayName: 'Stable Diffusion 3',
    costPerMegapixel: 0.035,
    defaultSteps: 28,
    maxSteps: 50,
    minWidth: 512,
    minHeight: 512,
    supportsCfgScale: true,
  },
  'sd3-turbo': {
    endpoint: 'sd3-turbo',
    displayName: 'SD3 Turbo',
    costPerMegapixel: 0.02,
    defaultSteps: 4,
    maxSteps: 8,
    minWidth: 512,
    minHeight: 512,
    supportsCfgScale: false,
  },
  'sd3-large': {
    endpoint: 'sd3-large',
    displayName: 'SD3 Large',
    costPerMegapixel: 0.065,
    defaultSteps: 40,
    maxSteps: 60,
    minWidth: 512,
    minHeight: 512,
    supportsCfgScale: true,
  },
  'sd3-large-turbo': {
    endpoint: 'sd3-large-turbo',
    displayName: 'SD3 Large Turbo',
    costPerMegapixel: 0.04,
    defaultSteps: 4,
    maxSteps: 8,
    minWidth: 512,
    minHeight: 512,
    supportsCfgScale: false,
  },
};

// =============================================================================
// STABILITY AI PROVIDER
// =============================================================================

export class StabilitySD3Provider extends BaseProvider {
  readonly name: ProviderName = 'stability-sd3';
  readonly displayName = 'Stability AI SD3';

  readonly capabilities: ProviderCapabilities = {
    maxWidth: 2048,
    maxHeight: 2048,
    supportedFormats: ['png', 'jpg', 'webp'] as const,
    supportedStyles: [
      'photographic',
      'cinematic',
      'anime',
      'digital-art',
      'comic-book',
      'fantasy-art',
      'neon-punk',
      '3d-model',
      'pixel-art',
    ] as const,
    supportsNegativePrompt: true,
    supportsBatchGeneration: true,
    maxBatchSize: 10,
    supportsImageToImage: true,
    supportsInpainting: true,
  };

  private baseUrl = 'https://api.stability.ai/v2beta/stable-image/generate';
  private defaultModel: StabilityModel;

  constructor(config: StabilityConfig) {
    super(config);
    this.defaultModel = config.defaultModel ?? 'sd3';
  }

  /**
   * Generate an image using SD3
   */
  async generate(
    prompt: string,
    options: GenerationOptions
  ): Promise<GenerationResult> {
    const startTime = Date.now();
    const designId = this.generateDesignId();
    const metadata = this.createMetadata(options);

    try {
      // Resolve generation parameters
      const model = this.resolveModel(options);
      const modelConfig = STABILITY_MODELS[model];
      const dimensions = this.resolveDimensions(options);
      const format = this.resolveFormat(options);

      // Build form data
      const formData = this.buildFormData(prompt, options, model, dimensions, format);

      this.log('info', `Starting generation: ${designId}`, {
        model,
        dimensions,
        promptLength: prompt.length,
      });

      // Make API request with retry
      const response = await this.executeWithRetry(async () => {
        const res = await fetch(`${this.baseUrl}/${modelConfig.endpoint}`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${this.config.apiKey}`,
            Accept: 'application/json',
          },
          body: formData,
        });

        if (!res.ok) {
          const error = await res.json().catch(() => ({ message: res.statusText }));
          throw this.createApiError(res.status, error);
        }

        return res.json();
      });

      const generationTimeMs = Date.now() - startTime;
      const result = response as StabilityResponse;

      // Check for content filtering
      if (result.finish_reason === 'CONTENT_FILTERED') {
        throw new Error('Image generation was blocked by content filter');
      }

      this.log('info', `Generation complete: ${designId}`, {
        generationTimeMs,
        seed: result.seed,
      });

      // Convert base64 to data URL
      const imageBase64 = result.image;
      const mimeType = format === 'jpg' ? 'image/jpeg' : `image/${format}`;

      return {
        success: true,
        designId,
        imageBase64,
        imageUrl: `data:${mimeType};base64,${imageBase64}`,
        provider: this.name,
        model,
        prompt,
        enhancedPrompt: this.enhancePrompt(prompt, options),
        dimensions,
        format,
        generationTimeMs,
        cost: this.calculateCost(model, dimensions),
        metadata: {
          ...metadata,
          seed: result.seed,
        },
      };
    } catch (error) {
      const generationTimeMs = Date.now() - startTime;
      const genError = this.mapException(error);

      this.log('error', `Generation failed: ${designId}`, {
        error: genError,
        generationTimeMs,
      });

      return {
        success: false,
        designId,
        provider: this.name,
        model: this.resolveModel(options),
        prompt,
        dimensions: this.resolveDimensions(options),
        format: 'png',
        generationTimeMs,
        cost: { amount: 0, currency: 'USD', provider: this.name, model: this.resolveModel(options) },
        metadata,
        error: genError,
      };
    }
  }

  /**
   * Check provider health
   */
  async healthCheck(): Promise<ProviderHealth> {
    const startTime = Date.now();

    try {
      // Use account endpoint as health check
      const res = await fetch('https://api.stability.ai/v1/user/account', {
        headers: {
          Authorization: `Bearer ${this.config.apiKey}`,
        },
      });

      this.lastHealthCheck = {
        name: this.name,
        isHealthy: res.ok,
        lastCheckAt: new Date(),
        responseTimeMs: Date.now() - startTime,
        consecutiveFailures: res.ok ? 0 : this.consecutiveFailures + 1,
      };
    } catch (error) {
      this.lastHealthCheck = {
        name: this.name,
        isHealthy: false,
        lastCheckAt: new Date(),
        responseTimeMs: Date.now() - startTime,
        consecutiveFailures: this.consecutiveFailures + 1,
      };
    }

    return this.lastHealthCheck;
  }

  /**
   * Estimate cost for generation
   */
  estimateCost(options: GenerationOptions): GenerationCost {
    const model = this.resolveModel(options);
    const dimensions = this.resolveDimensions(options);
    return this.calculateCost(model, dimensions);
  }

  /**
   * Validate API credentials
   */
  async validateCredentials(): Promise<boolean> {
    try {
      const res = await fetch('https://api.stability.ai/v1/user/account', {
        headers: {
          Authorization: `Bearer ${this.config.apiKey}`,
        },
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  // ===========================================================================
  // PRIVATE HELPERS
  // ===========================================================================

  /**
   * Resolve which model to use
   */
  private resolveModel(options: GenerationOptions): StabilityModel {
    if (options.model && options.model in STABILITY_MODELS) {
      return options.model as StabilityModel;
    }
    return this.defaultModel;
  }

  /**
   * Build form data for API request
   */
  private buildFormData(
    prompt: string,
    options: GenerationOptions,
    model: StabilityModel,
    dimensions: ImageDimensions,
    format: ImageFormat
  ): FormData {
    const modelConfig = STABILITY_MODELS[model];
    const formData = new FormData();

    // Core parameters
    formData.append('prompt', this.enhancePrompt(prompt, options));
    formData.append('output_format', format);
    formData.append('aspect_ratio', this.dimensionsToAspectRatio(dimensions));

    // Negative prompt
    if (options.negativePrompt) {
      formData.append('negative_prompt', options.negativePrompt);
    } else {
      formData.append('negative_prompt', this.getDefaultNegativePrompt());
    }

    // CFG scale (only for non-turbo models)
    if (modelConfig.supportsCfgScale && options.guidanceScale) {
      formData.append('cfg_scale', String(options.guidanceScale));
    }

    // Seed for reproducibility
    if (options.seed !== undefined) {
      formData.append('seed', String(options.seed));
    }

    // Style preset
    if (options.style && this.isValidStyle(options.style)) {
      formData.append('style_preset', options.style);
    }

    return formData;
  }

  /**
   * Convert dimensions to Stability aspect ratio string
   */
  private dimensionsToAspectRatio(dimensions: ImageDimensions): string {
    const { width, height } = dimensions;
    const ratio = width / height;

    // Map to supported aspect ratios
    if (ratio >= 1.7) return '16:9';
    if (ratio >= 1.4) return '3:2';
    if (ratio >= 1.2) return '4:3';
    if (ratio >= 0.95) return '1:1';
    if (ratio >= 0.7) return '3:4';
    if (ratio >= 0.55) return '2:3';
    return '9:16';
  }

  /**
   * Check if style is valid
   */
  private isValidStyle(style: string): boolean {
    return this.capabilities.supportedStyles.includes(style);
  }

  /**
   * Enhance prompt for better POD design results
   */
  private enhancePrompt(prompt: string, options: GenerationOptions): string {
    const enhancements: string[] = [];

    // Add quality modifiers
    enhancements.push('highly detailed', 'professional quality');

    // Add style context for POD
    if (options.productType) {
      enhancements.push(
        `design suitable for ${options.productType} printing`
      );
    }

    // Add niche context
    if (options.niche) {
      enhancements.push(options.niche);
    }

    // Combine: prompt first, then enhancements
    const enhancementStr = enhancements.join(', ');
    return `${prompt}, ${enhancementStr}`;
  }

  /**
   * Get default negative prompt for POD designs
   */
  private getDefaultNegativePrompt(): string {
    return [
      'blurry',
      'low quality',
      'low resolution',
      'distorted',
      'watermark',
      'signature',
      'text',
      'words',
      'letters',
      'logo',
      'trademark',
      'copyright',
      'nsfw',
      'nude',
      'border',
      'frame',
      'cropped',
      'out of frame',
      'deformed',
      'ugly',
      'mutation',
      'disfigured',
      'bad anatomy',
      'bad proportions',
      'extra limbs',
    ].join(', ');
  }

  /**
   * Calculate generation cost based on megapixels
   */
  private calculateCost(
    model: StabilityModel,
    dimensions: ImageDimensions
  ): GenerationCost {
    const modelConfig = STABILITY_MODELS[model];

    // Calculate megapixels
    const megapixels = (dimensions.width * dimensions.height) / 1000000;

    // Round up to nearest 0.1 megapixel
    const billedMegapixels = Math.ceil(megapixels * 10) / 10;

    const amount = billedMegapixels * modelConfig.costPerMegapixel;

    return {
      amount: Math.round(amount * 1000) / 1000, // Round to 3 decimal places
      currency: 'USD',
      provider: this.name,
      model,
      breakdown: {
        basePrice: modelConfig.costPerMegapixel,
        sizeMultiplier: billedMegapixels,
      },
    };
  }

  /**
   * Create an error from API response
   */
  private createApiError(status: number, error: unknown): Error {
    const message =
      typeof error === 'object' && error !== null
        ? (error as Record<string, unknown>).message || 'Unknown error'
        : String(error);

    const err = new Error(`Stability API Error (${status}): ${message}`);
    (err as Error & { status: number }).status = status;
    return err;
  }
}

export default StabilitySD3Provider;
