/**
 * ============================================================================
 * MOVING AVERAGE MODEL
 * ============================================================================
 * Simple and weighted moving average implementations for time series forecasting
 */

import type { DataPoint, PredictionPoint, ModelResult, MovingAverageConfig } from '../types.js';

export interface MovingAverageOptions {
  windowSize: number;
  weights?: number[];
  confidenceLevel?: number; // 0.95 for 95% confidence interval
}

export class MovingAverageModel {
  private readonly windowSize: number;
  private readonly weights: number[];
  private readonly confidenceLevel: number;

  constructor(options: MovingAverageOptions) {
    this.windowSize = options.windowSize;
    this.confidenceLevel = options.confidenceLevel ?? 0.95;

    // Normalize weights or use equal weights
    if (options.weights && options.weights.length === options.windowSize) {
      const sum = options.weights.reduce((a, b) => a + b, 0);
      this.weights = options.weights.map(w => w / sum);
    } else {
      // Equal weights for simple moving average
      this.weights = Array(this.windowSize).fill(1 / this.windowSize);
    }
  }

  /**
   * Calculate Simple Moving Average (SMA)
   */
  calculateSMA(data: number[]): number[] {
    if (data.length < this.windowSize) {
      return [];
    }

    const result: number[] = [];
    for (let i = this.windowSize - 1; i < data.length; i++) {
      const window = data.slice(i - this.windowSize + 1, i + 1);
      const avg = window.reduce((sum, val) => sum + val, 0) / this.windowSize;
      result.push(avg);
    }
    return result;
  }

  /**
   * Calculate Weighted Moving Average (WMA)
   */
  calculateWMA(data: number[]): number[] {
    if (data.length < this.windowSize) {
      return [];
    }

    const result: number[] = [];
    for (let i = this.windowSize - 1; i < data.length; i++) {
      const window = data.slice(i - this.windowSize + 1, i + 1);
      const weightedSum = window.reduce((sum, val, idx) => sum + val * this.weights[idx], 0);
      result.push(weightedSum);
    }
    return result;
  }

  /**
   * Calculate Exponential Moving Average (EMA)
   */
  calculateEMA(data: number[], span?: number): number[] {
    const effectiveSpan = span ?? this.windowSize;
    const alpha = 2 / (effectiveSpan + 1);

    if (data.length === 0) {
      return [];
    }

    const result: number[] = [data[0]];
    for (let i = 1; i < data.length; i++) {
      const ema = alpha * data[i] + (1 - alpha) * result[i - 1];
      result.push(ema);
    }
    return result;
  }

  /**
   * Calculate standard deviation of residuals for confidence intervals
   */
  private calculateResidualStd(actual: number[], predicted: number[]): number {
    if (actual.length !== predicted.length || actual.length === 0) {
      return 0;
    }

    const residuals = actual.map((a, i) => a - predicted[i]);
    const mean = residuals.reduce((sum, r) => sum + r, 0) / residuals.length;
    const variance = residuals.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / residuals.length;
    return Math.sqrt(variance);
  }

  /**
   * Get Z-score for confidence level
   */
  private getZScore(): number {
    // Common Z-scores for confidence levels
    const zScores: Record<number, number> = {
      0.90: 1.645,
      0.95: 1.96,
      0.99: 2.576,
    };
    return zScores[this.confidenceLevel] ?? 1.96;
  }

  /**
   * Forecast future values using moving average
   */
  forecast(dataPoints: DataPoint[], horizon: number): PredictionPoint[] {
    const values = dataPoints.map(dp => dp.value);

    if (values.length < this.windowSize) {
      throw new Error(`Insufficient data: need at least ${this.windowSize} points, got ${values.length}`);
    }

    // Calculate historical MA for error estimation
    const historicalMA = this.calculateWMA(values);
    const alignedActual = values.slice(this.windowSize - 1);
    const residualStd = this.calculateResidualStd(alignedActual, historicalMA);
    const zScore = this.getZScore();

    // Get the last window for forecasting
    const lastWindow = values.slice(-this.windowSize);
    const predictions: PredictionPoint[] = [];
    const currentWindow = [...lastWindow];
    const lastDate = dataPoints[dataPoints.length - 1].timestamp;

    for (let h = 1; h <= horizon; h++) {
      // Calculate weighted average of current window
      const prediction = currentWindow.reduce((sum, val, idx) => {
        return sum + val * this.weights[idx];
      }, 0);

      // Increase uncertainty for further horizons
      const uncertaintyMultiplier = Math.sqrt(h);
      const margin = zScore * residualStd * uncertaintyMultiplier;

      const predictionDate = new Date(lastDate);
      predictionDate.setDate(predictionDate.getDate() + h);

      predictions.push({
        date: predictionDate,
        value: prediction,
        lowerBound: prediction - margin,
        upperBound: prediction + margin,
      });

      // Slide window for next prediction
      currentWindow.shift();
      currentWindow.push(prediction);
    }

    return predictions;
  }

  /**
   * Fit model and generate results with error metrics
   */
  fit(dataPoints: DataPoint[], horizon: number = 7): ModelResult {
    const startTime = Date.now();
    const values = dataPoints.map(dp => dp.value);

    // Calculate historical predictions for error metrics
    const historicalMA = this.calculateWMA(values);
    const alignedActual = values.slice(this.windowSize - 1);

    // Calculate error metrics
    const errors = this.calculateErrorMetrics(alignedActual, historicalMA);

    // Generate forecasts
    const predictions = this.forecast(dataPoints, horizon);

    return {
      model: 'moving_average',
      predictions,
      accuracy: 1 - errors.mape,
      mse: errors.mse,
      mae: errors.mae,
      mape: errors.mape,
      trainingDataPoints: dataPoints.length,
      generatedAt: new Date(),
    };
  }

  /**
   * Calculate error metrics
   */
  private calculateErrorMetrics(actual: number[], predicted: number[]): {
    mse: number;
    mae: number;
    mape: number;
  } {
    if (actual.length !== predicted.length || actual.length === 0) {
      return { mse: 0, mae: 0, mape: 0 };
    }

    let sumSquaredError = 0;
    let sumAbsoluteError = 0;
    let sumPercentageError = 0;
    let validPercentageCount = 0;

    for (let i = 0; i < actual.length; i++) {
      const error = actual[i] - predicted[i];
      sumSquaredError += error * error;
      sumAbsoluteError += Math.abs(error);

      if (actual[i] !== 0) {
        sumPercentageError += Math.abs(error / actual[i]);
        validPercentageCount++;
      }
    }

    const n = actual.length;
    return {
      mse: sumSquaredError / n,
      mae: sumAbsoluteError / n,
      mape: validPercentageCount > 0 ? sumPercentageError / validPercentageCount : 0,
    };
  }

  /**
   * Detect trend from moving average
   */
  detectTrend(dataPoints: DataPoint[]): {
    direction: 'rising' | 'falling' | 'stable';
    strength: number;
    changeRate: number;
  } {
    const values = dataPoints.map(dp => dp.value);
    const ma = this.calculateWMA(values);

    if (ma.length < 2) {
      return { direction: 'stable', strength: 0, changeRate: 0 };
    }

    // Calculate average change rate
    const changes: number[] = [];
    for (let i = 1; i < ma.length; i++) {
      if (ma[i - 1] !== 0) {
        changes.push((ma[i] - ma[i - 1]) / ma[i - 1]);
      }
    }

    const avgChangeRate = changes.length > 0
      ? changes.reduce((sum, c) => sum + c, 0) / changes.length
      : 0;

    // Determine direction and strength
    const absRate = Math.abs(avgChangeRate);
    let direction: 'rising' | 'falling' | 'stable';
    let strength: number;

    if (absRate < 0.01) {
      direction = 'stable';
      strength = 0;
    } else if (avgChangeRate > 0) {
      direction = 'rising';
      strength = Math.min(absRate * 10, 1);
    } else {
      direction = 'falling';
      strength = Math.min(absRate * 10, 1);
    }

    return {
      direction,
      strength,
      changeRate: avgChangeRate,
    };
  }
}

/**
 * Create a pre-configured moving average model
 */
export function createMovingAverageModel(config?: Partial<MovingAverageOptions>): MovingAverageModel {
  return new MovingAverageModel({
    windowSize: config?.windowSize ?? 7,
    weights: config?.weights,
    confidenceLevel: config?.confidenceLevel ?? 0.95,
  });
}

/**
 * Convenience function for quick SMA calculation
 */
export function simpleMovingAverage(data: number[], windowSize: number): number[] {
  const model = new MovingAverageModel({ windowSize });
  return model.calculateSMA(data);
}

/**
 * Convenience function for quick EMA calculation
 */
export function exponentialMovingAverage(data: number[], span: number): number[] {
  const model = new MovingAverageModel({ windowSize: span });
  return model.calculateEMA(data, span);
}
