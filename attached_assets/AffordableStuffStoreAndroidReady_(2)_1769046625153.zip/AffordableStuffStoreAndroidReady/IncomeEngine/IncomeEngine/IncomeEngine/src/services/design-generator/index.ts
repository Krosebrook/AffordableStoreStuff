/**
 * ============================================================================
 * DESIGN GENERATOR SERVICE
 * ============================================================================
 *
 * Main orchestrator for AI-powered design generation with provider failover,
 * cost tracking, quality validation, and batch processing capabilities.
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  ProviderName,
  ProviderConfig,
  GenerationOptions,
  GenerationResult,
  BatchOptions,
  BatchResult,
  GenerationCost,
  DesignPrompt,
  ProviderHealth,
  ProviderStatus,
  FailoverEvent,
  GenerationEvent,
  GenerationEventHandler,
  DesignRecord,
} from './types';
import { BaseProvider } from './providers/base-provider';
import { OpenAIDalleProvider } from './providers/openai-dalle';
import { ReplicateFluxProvider } from './providers/replicate-flux';
import { StabilitySD3Provider } from './providers/stability-sd3';
import { PromptBuilder } from './templates/prompt-builder';
import { QualityChecker } from './validation/quality-checker';
import { PlatformValidator } from './validation/platform-validator';
import { Upscaler } from './post-processing/upscaler';
import { BackgroundRemover } from './post-processing/background-remover';

// =============================================================================
// TYPES
// =============================================================================

interface DesignGeneratorConfig {
  readonly supabaseUrl: string;
  readonly supabaseKey: string;
  readonly providers: {
    readonly openai?: {
      readonly apiKey: string;
      readonly organizationId?: string;
    };
    readonly replicate?: {
      readonly apiKey: string;
      readonly defaultModel?: 'flux-pro' | 'flux-dev' | 'flux-schnell';
    };
    readonly stability?: {
      readonly apiKey: string;
      readonly defaultModel?: 'sd3' | 'sd3-turbo' | 'sd3-large' | 'sd3-large-turbo';
    };
  };
  readonly qualityThreshold?: number;
  readonly enableQualityCheck?: boolean;
  readonly maxFailoverAttempts?: number;
  readonly batchConcurrency?: number;
}

interface ProviderWithPriority {
  provider: BaseProvider;
  priority: number;
  name: ProviderName;
}

// =============================================================================
// DESIGN GENERATOR CLASS
// =============================================================================

export class DesignGenerator {
  private supabase: SupabaseClient;
  private providers: Map<ProviderName, BaseProvider> = new Map();
  private providerOrder: ProviderName[] = [];
  private promptBuilder: PromptBuilder;
  private qualityChecker: QualityChecker;
  private platformValidator: PlatformValidator;
  private upscaler: Upscaler;
  private backgroundRemover: BackgroundRemover;
  private eventHandlers: GenerationEventHandler[] = [];
  private config: DesignGeneratorConfig;

  // Failover state
  private failoverHistory: FailoverEvent[] = [];
  private providerHealthCache: Map<ProviderName, ProviderHealth> = new Map();

  constructor(config: DesignGeneratorConfig) {
    this.config = {
      qualityThreshold: 0.7,
      enableQualityCheck: true,
      maxFailoverAttempts: 3,
      batchConcurrency: 3,
      ...config,
    };

    this.supabase = createClient(config.supabaseUrl, config.supabaseKey);

    // Initialize providers
    this.initializeProviders();

    // Initialize support services
    this.promptBuilder = new PromptBuilder();
    this.qualityChecker = new QualityChecker(config.supabaseUrl, config.supabaseKey);
    this.platformValidator = new PlatformValidator();
    this.upscaler = new Upscaler(config.supabaseUrl, config.supabaseKey);
    this.backgroundRemover = new BackgroundRemover(config.supabaseUrl, config.supabaseKey);
  }

  // ===========================================================================
  // MAIN GENERATION METHODS
  // ===========================================================================

  /**
   * Generate a design with automatic provider failover
   */
  async generate(
    prompt: string | DesignPrompt,
    options: GenerationOptions = {}
  ): Promise<GenerationResult> {
    // Build enhanced prompt
    const builtPrompt = this.promptBuilder.build(prompt, options);

    // Get provider order (with failover support)
    const providers = this.getProviderOrder(options.provider);

    if (providers.length === 0) {
      return this.createFailedResult(
        'No providers available',
        builtPrompt.enhancedText,
        options
      );
    }

    let lastError: GenerationResult | null = null;
    let failoverAttempts = 0;

    for (const providerName of providers) {
      if (failoverAttempts >= (this.config.maxFailoverAttempts ?? 3)) {
        break;
      }

      const provider = this.providers.get(providerName);
      if (!provider || !provider.isAvailable()) {
        continue;
      }

      // Emit event
      await this.emitEvent({
        type: failoverAttempts === 0 ? 'started' : 'failover',
        designId: '',
        provider: providerName,
        timestamp: new Date(),
        data: { prompt: builtPrompt.text, attempt: failoverAttempts + 1 },
      });

      try {
        // Generate with this provider
        const result = await provider.generate(builtPrompt.enhancedText, options);

        if (result.success) {
          // Track cost
          await this.trackCost(result);

          // Quality check if enabled
          if (this.config.enableQualityCheck && result.imageUrl) {
            const qualityResult = await this.qualityChecker.check(
              result.imageUrl,
              builtPrompt.text,
              options
            );

            // Attach quality score
            const resultWithQuality: GenerationResult = {
              ...result,
              qualityScore: qualityResult.overallScore,
              metadata: {
                ...result.metadata,
                failoverAttempts: failoverAttempts,
                originalProvider: failoverAttempts > 0 ? providers[0] : undefined,
              },
            };

            // Check if quality meets threshold
            if (qualityResult.overallScore < (this.config.qualityThreshold ?? 0.7)) {
              // Quality too low, try next provider
              lastError = {
                ...resultWithQuality,
                success: false,
                error: {
                  code: 'QUALITY_BELOW_THRESHOLD',
                  message: `Quality score ${qualityResult.overallScore} below threshold ${this.config.qualityThreshold}`,
                  provider: providerName,
                  retryable: true,
                },
              };

              failoverAttempts++;
              continue;
            }

            // Save to database
            await this.saveGeneration(resultWithQuality);

            // Emit success event
            await this.emitEvent({
              type: 'completed',
              designId: resultWithQuality.designId,
              provider: providerName,
              timestamp: new Date(),
              data: { qualityScore: qualityResult.overallScore },
            });

            return resultWithQuality;
          }

          // Save without quality check
          await this.saveGeneration(result);

          await this.emitEvent({
            type: 'completed',
            designId: result.designId,
            provider: providerName,
            timestamp: new Date(),
          });

          return result;
        } else {
          lastError = result;
          failoverAttempts++;

          // Log failover
          if (failoverAttempts < providers.length) {
            const nextProvider = providers[failoverAttempts];
            this.logFailover(providerName, nextProvider, result.error?.message ?? 'Unknown error');
          }
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);

        lastError = this.createFailedResult(errorMsg, builtPrompt.enhancedText, options);
        failoverAttempts++;

        await this.emitEvent({
          type: 'failed',
          designId: '',
          provider: providerName,
          timestamp: new Date(),
          data: { error: errorMsg },
        });
      }
    }

    // All providers failed
    return lastError ?? this.createFailedResult(
      'All providers failed',
      builtPrompt.enhancedText,
      options
    );
  }

  /**
   * Generate multiple designs in batch
   */
  async generateBatch(
    prompts: Array<string | DesignPrompt>,
    options: BatchOptions = {}
  ): Promise<BatchResult> {
    const batchId = this.generateBatchId();
    const startTime = Date.now();
    const concurrency = options.concurrency ?? this.config.batchConcurrency ?? 3;

    const results: GenerationResult[] = [];
    let totalCost: GenerationCost = {
      amount: 0,
      currency: 'USD',
      provider: 'openai-dalle',
      model: 'mixed',
    };

    // Process in batches for concurrency control
    for (let i = 0; i < prompts.length; i += concurrency) {
      const batch = prompts.slice(i, i + concurrency);

      const batchResults = await Promise.all(
        batch.map(async (prompt) => {
          try {
            return await this.generate(prompt, options);
          } catch (error) {
            if (options.stopOnError) {
              throw error;
            }
            return this.createFailedResult(
              error instanceof Error ? error.message : String(error),
              typeof prompt === 'string' ? prompt : prompt.text,
              options
            );
          }
        })
      );

      results.push(...batchResults);

      // Aggregate costs
      for (const result of batchResults) {
        if (result.success && result.cost) {
          totalCost = {
            ...totalCost,
            amount: totalCost.amount + result.cost.amount,
          };
        }
      }
    }

    // Retry failed items if configured
    if (options.retryFailedItems) {
      const failedIndices = results
        .map((r, i) => (r.success ? -1 : i))
        .filter((i) => i >= 0);

      for (const index of failedIndices) {
        const retryResult = await this.generate(prompts[index], options);
        if (retryResult.success) {
          results[index] = retryResult;
          totalCost = {
            ...totalCost,
            amount: totalCost.amount + (retryResult.cost?.amount ?? 0),
          };
        }
      }
    }

    const totalSuccessful = results.filter((r) => r.success).length;
    const totalFailed = results.length - totalSuccessful;

    return {
      success: totalFailed === 0,
      batchId,
      totalRequested: prompts.length,
      totalSuccessful,
      totalFailed,
      results,
      totalCost,
      totalTimeMs: Date.now() - startTime,
    };
  }

  // ===========================================================================
  // PROVIDER MANAGEMENT
  // ===========================================================================

  /**
   * Initialize all configured providers
   */
  private initializeProviders(): void {
    const providersWithPriority: ProviderWithPriority[] = [];

    // OpenAI DALL-E
    if (this.config.providers.openai?.apiKey) {
      const config: ProviderConfig = {
        name: 'openai-dalle',
        displayName: 'OpenAI DALL-E 3',
        apiKey: this.config.providers.openai.apiKey,
        priority: 1,
        isEnabled: true,
        capabilities: {
          maxWidth: 1792,
          maxHeight: 1792,
          supportedFormats: ['png', 'webp'],
          supportedStyles: ['vivid', 'natural'],
          supportsNegativePrompt: false,
          supportsBatchGeneration: false,
          maxBatchSize: 1,
          supportsImageToImage: false,
          supportsInpainting: false,
        },
      };

      const provider = new OpenAIDalleProvider({
        ...config,
        organizationId: this.config.providers.openai.organizationId,
      });

      this.providers.set('openai-dalle', provider);
      providersWithPriority.push({ provider, priority: 1, name: 'openai-dalle' });
    }

    // Replicate Flux
    if (this.config.providers.replicate?.apiKey) {
      const config: ProviderConfig = {
        name: 'replicate-flux',
        displayName: 'Replicate Flux',
        apiKey: this.config.providers.replicate.apiKey,
        priority: 2,
        isEnabled: true,
        capabilities: {
          maxWidth: 2048,
          maxHeight: 2048,
          supportedFormats: ['png', 'jpg', 'webp'],
          supportedStyles: ['photorealistic', 'artistic', 'illustration', 'anime'],
          supportsNegativePrompt: true,
          supportsBatchGeneration: true,
          maxBatchSize: 4,
          supportsImageToImage: true,
          supportsInpainting: false,
        },
      };

      const provider = new ReplicateFluxProvider({
        ...config,
        defaultModel: this.config.providers.replicate.defaultModel,
      });

      this.providers.set('replicate-flux', provider);
      providersWithPriority.push({ provider, priority: 2, name: 'replicate-flux' });
    }

    // Stability AI SD3
    if (this.config.providers.stability?.apiKey) {
      const config: ProviderConfig = {
        name: 'stability-sd3',
        displayName: 'Stability AI SD3',
        apiKey: this.config.providers.stability.apiKey,
        priority: 3,
        isEnabled: true,
        capabilities: {
          maxWidth: 2048,
          maxHeight: 2048,
          supportedFormats: ['png', 'jpg', 'webp'],
          supportedStyles: [
            'photographic',
            'cinematic',
            'anime',
            'digital-art',
            'comic-book',
            'fantasy-art',
            'neon-punk',
            '3d-model',
            'pixel-art',
          ],
          supportsNegativePrompt: true,
          supportsBatchGeneration: true,
          maxBatchSize: 10,
          supportsImageToImage: true,
          supportsInpainting: true,
        },
      };

      const provider = new StabilitySD3Provider({
        ...config,
        defaultModel: this.config.providers.stability.defaultModel,
      });

      this.providers.set('stability-sd3', provider);
      providersWithPriority.push({ provider, priority: 3, name: 'stability-sd3' });
    }

    // Sort by priority and set provider order
    providersWithPriority.sort((a, b) => a.priority - b.priority);
    this.providerOrder = providersWithPriority.map((p) => p.name);
  }

  /**
   * Get provider order with failover support
   */
  private getProviderOrder(preferredProvider?: ProviderName): ProviderName[] {
    if (preferredProvider && this.providers.has(preferredProvider)) {
      // Put preferred provider first, then others
      return [
        preferredProvider,
        ...this.providerOrder.filter((p) => p !== preferredProvider),
      ];
    }

    return [...this.providerOrder];
  }

  /**
   * Run health checks on all providers
   */
  async runHealthChecks(): Promise<Map<ProviderName, ProviderHealth>> {
    const results = new Map<ProviderName, ProviderHealth>();

    for (const [name, provider] of this.providers) {
      const health = await provider.healthCheck();
      results.set(name, health);
      this.providerHealthCache.set(name, health);
    }

    return results;
  }

  /**
   * Get provider status
   */
  async getProviderStatus(): Promise<ProviderStatus> {
    const providers: ProviderHealth[] = [];

    for (const [name, provider] of this.providers) {
      providers.push(
        this.providerHealthCache.get(name) ?? provider.getHealth()
      );
    }

    return {
      providers,
      activeProvider: this.providerOrder[0],
      failoverHistory: this.failoverHistory.slice(-10),
    };
  }

  // ===========================================================================
  // COST TRACKING
  // ===========================================================================

  /**
   * Track generation cost
   */
  private async trackCost(result: GenerationResult): Promise<void> {
    if (!result.cost || result.cost.amount === 0) return;

    try {
      await this.supabase.from('cost_events').insert({
        service_name: result.provider,
        operation: 'image_generation',
        cost_usd: result.cost.amount,
        product_id: null,
        metadata: {
          model: result.model,
          designId: result.designId,
          dimensions: result.dimensions,
          breakdown: result.cost.breakdown,
        },
      });
    } catch (error) {
      console.error('Failed to track cost:', error);
    }
  }

  /**
   * Estimate cost for a generation
   */
  estimateCost(options: GenerationOptions = {}): GenerationCost {
    const providerName = options.provider ?? this.providerOrder[0];
    const provider = this.providers.get(providerName);

    if (!provider) {
      return {
        amount: 0,
        currency: 'USD',
        provider: providerName,
        model: 'unknown',
      };
    }

    return provider.estimateCost(options);
  }

  // ===========================================================================
  // DATABASE OPERATIONS
  // ===========================================================================

  /**
   * Save generation to database
   */
  private async saveGeneration(result: GenerationResult): Promise<void> {
    const record: Partial<DesignRecord> = {
      id: result.designId,
      prompt: result.prompt,
      enhancedPrompt: result.enhancedPrompt,
      provider: result.provider,
      model: result.model,
      imageUrl: result.imageUrl ?? '',
      width: result.dimensions.width,
      height: result.dimensions.height,
      format: result.format,
      fileSizeBytes: 0, // Would need to fetch to get actual size
      generationTimeMs: result.generationTimeMs,
      costAmount: result.cost.amount,
      costCurrency: result.cost.currency,
      qualityScore: result.qualityScore,
      niche: result.metadata.niche,
      productType: result.metadata.productType,
      tags: result.metadata.tags ?? [],
      metadata: result.metadata as unknown as Record<string, unknown>,
      status: 'completed',
    };

    try {
      await this.supabase.from('design_generations').insert(record);
    } catch (error) {
      console.error('Failed to save generation:', error);
    }
  }

  /**
   * Get generation history
   */
  async getHistory(options: {
    limit?: number;
    offset?: number;
    niche?: string;
    provider?: ProviderName;
    status?: string;
  } = {}): Promise<DesignRecord[]> {
    let query = this.supabase
      .from('design_generations')
      .select('*')
      .order('created_at', { ascending: false });

    if (options.limit) {
      query = query.limit(options.limit);
    }

    if (options.offset) {
      query = query.range(options.offset, options.offset + (options.limit ?? 10) - 1);
    }

    if (options.niche) {
      query = query.eq('niche', options.niche);
    }

    if (options.provider) {
      query = query.eq('provider', options.provider);
    }

    if (options.status) {
      query = query.eq('status', options.status);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Failed to get history:', error);
      return [];
    }

    return data ?? [];
  }

  // ===========================================================================
  // POST-PROCESSING
  // ===========================================================================

  /**
   * Upscale an image
   */
  async upscale(
    imageUrl: string,
    options: { scale?: 2 | 4 } = {}
  ): Promise<{ success: boolean; url?: string; error?: string }> {
    try {
      const result = await this.upscaler.upscale(imageUrl, options);
      return {
        success: result.success,
        url: result.upscaledUrl,
        error: result.error?.message,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  }

  /**
   * Remove background from an image
   */
  async removeBackground(
    imageUrl: string
  ): Promise<{ success: boolean; url?: string; error?: string }> {
    try {
      const result = await this.backgroundRemover.remove(imageUrl);
      return {
        success: result.success,
        url: result.processedUrl,
        error: result.error?.message,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  }

  // ===========================================================================
  // VALIDATION
  // ===========================================================================

  /**
   * Validate image for a platform
   * Note: This is a simplified validation that uses default image dimensions.
   * For full validation, fetch the image first to get actual dimensions.
   */
  async validateForPlatform(
    imageUrl: string,
    platform: string
  ): Promise<{
    valid: boolean;
    issues: Array<{ field: string; message: string; severity: string }>;
    recommendations: string[];
  }> {
    try {
      // Use default dimensions since we don't have the actual image info
      // In production, you would fetch the image to get real dimensions
      const defaultImageInfo = {
        width: 1024,
        height: 1024,
        format: 'png' as const,
      };

      const result = this.platformValidator.validate(platform, defaultImageInfo);
      return {
        valid: result.valid,
        issues: result.issues.map((i) => ({
          field: i.field,
          message: i.message,
          severity: i.severity,
        })),
        recommendations: result.recommendations,
      };
    } catch (error) {
      return {
        valid: false,
        issues: [
          {
            field: 'validation',
            message: error instanceof Error ? error.message : String(error),
            severity: 'error',
          },
        ],
        recommendations: [],
      };
    }
  }

  // ===========================================================================
  // EVENTS
  // ===========================================================================

  /**
   * Register an event handler
   */
  onEvent(handler: GenerationEventHandler): void {
    this.eventHandlers.push(handler);
  }

  /**
   * Emit an event to all handlers
   */
  private async emitEvent(event: GenerationEvent): Promise<void> {
    for (const handler of this.eventHandlers) {
      try {
        await handler(event);
      } catch (error) {
        console.error('Event handler error:', error);
      }
    }
  }

  // ===========================================================================
  // UTILITIES
  // ===========================================================================

  /**
   * Log a failover event
   */
  private logFailover(
    fromProvider: ProviderName,
    toProvider: ProviderName,
    reason: string
  ): void {
    const event: FailoverEvent = {
      fromProvider,
      toProvider,
      reason,
      timestamp: new Date(),
    };

    this.failoverHistory.push(event);

    // Keep only last 100 events
    if (this.failoverHistory.length > 100) {
      this.failoverHistory = this.failoverHistory.slice(-100);
    }

    console.warn(
      `[DesignGenerator] Failover: ${fromProvider} -> ${toProvider}: ${reason}`
    );
  }

  /**
   * Create a failed result
   */
  private createFailedResult(
    message: string,
    prompt: string,
    options: GenerationOptions
  ): GenerationResult {
    return {
      success: false,
      designId: this.generateDesignId(),
      provider: options.provider ?? this.providerOrder[0] ?? 'openai-dalle',
      model: 'unknown',
      prompt,
      dimensions: options.dimensions ?? { width: 1024, height: 1024 },
      format: options.format ?? 'png',
      generationTimeMs: 0,
      cost: {
        amount: 0,
        currency: 'USD',
        provider: options.provider ?? this.providerOrder[0] ?? 'openai-dalle',
        model: 'unknown',
      },
      metadata: {
        requestId: this.generateRequestId(),
        timestamp: new Date(),
        niche: options.niche,
        productType: options.productType,
        tags: options.tags,
      },
      error: {
        code: 'GENERATION_FAILED',
        message,
        provider: options.provider ?? this.providerOrder[0],
        retryable: true,
      },
    };
  }

  /**
   * Generate unique design ID
   */
  private generateDesignId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 12);
    return `design-${timestamp}-${random}`;
  }

  /**
   * Generate unique request ID
   */
  private generateRequestId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 10);
    return `req-${timestamp}-${random}`;
  }

  /**
   * Generate unique batch ID
   */
  private generateBatchId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `batch-${timestamp}-${random}`;
  }

  // ===========================================================================
  // ACCESSORS
  // ===========================================================================

  /**
   * Get available niches
   */
  getNiches(): string[] {
    return this.promptBuilder.getNiches();
  }

  /**
   * Get templates for a niche
   */
  getTemplatesForNiche(niche: string): unknown[] {
    return this.promptBuilder.getTemplatesForNiche(niche);
  }

  /**
   * Get prompt builder
   */
  getPromptBuilder(): PromptBuilder {
    return this.promptBuilder;
  }

  /**
   * Get quality checker
   */
  getQualityChecker(): QualityChecker {
    return this.qualityChecker;
  }

  /**
   * Get platform validator
   */
  getPlatformValidator(): PlatformValidator {
    return this.platformValidator;
  }
}

// =============================================================================
// FACTORY FUNCTION
// =============================================================================

export function createDesignGenerator(config: DesignGeneratorConfig): DesignGenerator {
  return new DesignGenerator(config);
}

// =============================================================================
// EXPORTS
// =============================================================================

export { DesignGenerator };
export default DesignGenerator;

// Re-export types
export * from './types';
export { PromptBuilder } from './templates/prompt-builder';
export { QualityChecker } from './validation/quality-checker';
export { PlatformValidator } from './validation/platform-validator';
export { Upscaler } from './post-processing/upscaler';
export { BackgroundRemover } from './post-processing/background-remover';
