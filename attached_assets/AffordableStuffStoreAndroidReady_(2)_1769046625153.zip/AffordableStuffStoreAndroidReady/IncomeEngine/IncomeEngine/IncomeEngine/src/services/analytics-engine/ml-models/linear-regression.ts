/**
 * ============================================================================
 * LINEAR REGRESSION MODEL
 * ============================================================================
 * Simple and multiple linear regression for trend analysis and forecasting
 */

import type { DataPoint, PredictionPoint, ModelResult } from '../types.js';

export interface LinearRegressionOptions {
  includeIntercept?: boolean;
  regularization?: 'none' | 'l1' | 'l2';
  regularizationStrength?: number;
  confidenceLevel?: number;
}

export interface RegressionCoefficients {
  intercept: number;
  slope: number;
  rSquared: number;
  adjustedRSquared: number;
  standardError: number;
  pValue: number;
}

export class LinearRegressionModel {
  private readonly includeIntercept: boolean;
  private readonly regularization: 'none' | 'l1' | 'l2';
  private readonly regularizationStrength: number;
  private readonly confidenceLevel: number;

  // Fitted coefficients
  private intercept: number = 0;
  private slope: number = 0;
  private standardError: number = 0;
  private rSquared: number = 0;
  private fitted: boolean = false;

  constructor(options: LinearRegressionOptions = {}) {
    this.includeIntercept = options.includeIntercept ?? true;
    this.regularization = options.regularization ?? 'none';
    this.regularizationStrength = options.regularizationStrength ?? 0.01;
    this.confidenceLevel = options.confidenceLevel ?? 0.95;
  }

  /**
   * Calculate mean of an array
   */
  private mean(values: number[]): number {
    return values.reduce((sum, val) => sum + val, 0) / values.length;
  }

  /**
   * Calculate variance of an array
   */
  private variance(values: number[], mean: number): number {
    return values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
  }

  /**
   * Calculate covariance between two arrays
   */
  private covariance(x: number[], y: number[], xMean: number, yMean: number): number {
    let sum = 0;
    for (let i = 0; i < x.length; i++) {
      sum += (x[i] - xMean) * (y[i] - yMean);
    }
    return sum / x.length;
  }

  /**
   * Fit simple linear regression using ordinary least squares
   */
  fit(dataPoints: DataPoint[]): void {
    if (dataPoints.length < 2) {
      throw new Error('Need at least 2 data points for linear regression');
    }

    // Create numeric indices as x values (time series)
    const x = dataPoints.map((_, i) => i);
    const y = dataPoints.map(dp => dp.value);

    const xMean = this.mean(x);
    const yMean = this.mean(y);

    const xVariance = this.variance(x, xMean);
    const covar = this.covariance(x, y, xMean, yMean);

    // Calculate slope with optional regularization
    if (xVariance === 0) {
      this.slope = 0;
    } else {
      this.slope = covar / xVariance;

      // Apply L2 regularization (Ridge)
      if (this.regularization === 'l2') {
        this.slope = this.slope / (1 + this.regularizationStrength);
      }
    }

    // Calculate intercept
    if (this.includeIntercept) {
      this.intercept = yMean - this.slope * xMean;
    } else {
      this.intercept = 0;
    }

    // Calculate R-squared
    const predictions = x.map(xi => this.intercept + this.slope * xi);
    const ssRes = y.reduce((sum, yi, i) => sum + Math.pow(yi - predictions[i], 2), 0);
    const ssTot = y.reduce((sum, yi) => sum + Math.pow(yi - yMean, 2), 0);
    this.rSquared = ssTot === 0 ? 0 : 1 - ssRes / ssTot;

    // Calculate standard error
    const n = dataPoints.length;
    this.standardError = Math.sqrt(ssRes / (n - 2));

    this.fitted = true;
  }

  /**
   * Get Z-score for confidence level
   */
  private getZScore(): number {
    const zScores: Record<number, number> = {
      0.90: 1.645,
      0.95: 1.96,
      0.99: 2.576,
    };
    return zScores[this.confidenceLevel] ?? 1.96;
  }

  /**
   * Predict a single value
   */
  predict(x: number): number {
    return this.intercept + this.slope * x;
  }

  /**
   * Forecast future values
   */
  forecast(dataPoints: DataPoint[], horizon: number): PredictionPoint[] {
    if (!this.fitted) {
      this.fit(dataPoints);
    }

    const n = dataPoints.length;
    const lastDate = dataPoints[n - 1].timestamp;
    const xMean = (n - 1) / 2;
    const xVariance = this.variance(
      dataPoints.map((_, i) => i),
      xMean
    );

    const predictions: PredictionPoint[] = [];
    const zScore = this.getZScore();

    for (let h = 1; h <= horizon; h++) {
      const xNew = n - 1 + h;
      const prediction = this.predict(xNew);

      // Calculate prediction interval width
      // Uses formula for prediction interval in regression
      const xDeviation = xNew - xMean;
      const intervalFactor = Math.sqrt(1 + 1 / n + (xDeviation * xDeviation) / (n * xVariance));
      const margin = zScore * this.standardError * intervalFactor;

      const predictionDate = new Date(lastDate);
      predictionDate.setDate(predictionDate.getDate() + h);

      predictions.push({
        date: predictionDate,
        value: prediction,
        lowerBound: prediction - margin,
        upperBound: prediction + margin,
      });
    }

    return predictions;
  }

  /**
   * Get fitted values for the training data
   */
  getFittedValues(dataPoints: DataPoint[]): number[] {
    if (!this.fitted) {
      this.fit(dataPoints);
    }
    return dataPoints.map((_, i) => this.predict(i));
  }

  /**
   * Get regression coefficients and statistics
   */
  getCoefficients(dataPoints: DataPoint[]): RegressionCoefficients {
    if (!this.fitted) {
      this.fit(dataPoints);
    }

    const n = dataPoints.length;
    const k = this.includeIntercept ? 1 : 0;
    const adjustedRSquared =
      n > k + 1 ? 1 - ((1 - this.rSquared) * (n - 1)) / (n - k - 1) : this.rSquared;

    // Calculate t-statistic and p-value for slope
    const x = dataPoints.map((_, i) => i);
    const xMean = this.mean(x);
    const sxx = x.reduce((sum, xi) => sum + Math.pow(xi - xMean, 2), 0);
    const slopeStdError = sxx > 0 ? this.standardError / Math.sqrt(sxx) : 0;
    const tStatistic = slopeStdError > 0 ? Math.abs(this.slope / slopeStdError) : 0;

    // Approximate p-value using normal distribution for large n
    const pValue = 2 * (1 - this.normalCDF(tStatistic));

    return {
      intercept: this.intercept,
      slope: this.slope,
      rSquared: this.rSquared,
      adjustedRSquared,
      standardError: this.standardError,
      pValue,
    };
  }

  /**
   * Approximate cumulative distribution function for normal distribution
   */
  private normalCDF(x: number): number {
    // Approximation using error function
    const a1 = 0.254829592;
    const a2 = -0.284496736;
    const a3 = 1.421413741;
    const a4 = -1.453152027;
    const a5 = 1.061405429;
    const p = 0.3275911;

    const sign = x < 0 ? -1 : 1;
    x = Math.abs(x) / Math.sqrt(2);

    const t = 1 / (1 + p * x);
    const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);

    return 0.5 * (1 + sign * y);
  }

  /**
   * Calculate error metrics
   */
  private calculateErrorMetrics(actual: number[], predicted: number[]): {
    mse: number;
    mae: number;
    mape: number;
    rmse: number;
  } {
    if (actual.length !== predicted.length || actual.length === 0) {
      return { mse: 0, mae: 0, mape: 0, rmse: 0 };
    }

    let sumSquaredError = 0;
    let sumAbsoluteError = 0;
    let sumPercentageError = 0;
    let validPercentageCount = 0;

    for (let i = 0; i < actual.length; i++) {
      const error = actual[i] - predicted[i];
      sumSquaredError += error * error;
      sumAbsoluteError += Math.abs(error);

      if (actual[i] !== 0) {
        sumPercentageError += Math.abs(error / actual[i]);
        validPercentageCount++;
      }
    }

    const n = actual.length;
    const mse = sumSquaredError / n;
    return {
      mse,
      mae: sumAbsoluteError / n,
      mape: validPercentageCount > 0 ? sumPercentageError / validPercentageCount : 0,
      rmse: Math.sqrt(mse),
    };
  }

  /**
   * Generate full model result
   */
  getModelResult(dataPoints: DataPoint[], horizon: number = 7): ModelResult {
    this.fit(dataPoints);

    const values = dataPoints.map(dp => dp.value);
    const fittedValues = this.getFittedValues(dataPoints);
    const errors = this.calculateErrorMetrics(values, fittedValues);
    const predictions = this.forecast(dataPoints, horizon);

    return {
      model: 'linear_regression',
      predictions,
      accuracy: Math.max(0, 1 - errors.mape),
      mse: errors.mse,
      mae: errors.mae,
      mape: errors.mape,
      trainingDataPoints: dataPoints.length,
      generatedAt: new Date(),
    };
  }

  /**
   * Detect trend characteristics
   */
  detectTrend(dataPoints: DataPoint[]): {
    direction: 'rising' | 'falling' | 'stable';
    strength: number;
    isSignificant: boolean;
    changePerPeriod: number;
    coefficients: RegressionCoefficients;
  } {
    this.fit(dataPoints);
    const coefficients = this.getCoefficients(dataPoints);

    // Determine trend direction and strength
    const absSlope = Math.abs(this.slope);
    const avgValue = this.mean(dataPoints.map(dp => dp.value));
    const normalizedSlope = avgValue !== 0 ? absSlope / avgValue : 0;

    let direction: 'rising' | 'falling' | 'stable';
    let strength: number;

    if (normalizedSlope < 0.001) {
      direction = 'stable';
      strength = 0;
    } else if (this.slope > 0) {
      direction = 'rising';
      strength = Math.min(normalizedSlope * 100, 1);
    } else {
      direction = 'falling';
      strength = Math.min(normalizedSlope * 100, 1);
    }

    return {
      direction,
      strength,
      isSignificant: coefficients.pValue < 0.05,
      changePerPeriod: this.slope,
      coefficients,
    };
  }
}

/**
 * Multiple Linear Regression for multiple features
 */
export class MultipleLinearRegressionModel {
  private readonly regularization: 'none' | 'l1' | 'l2';
  private readonly regularizationStrength: number;
  private coefficients: number[] = [];
  private fitted: boolean = false;

  constructor(options: Omit<LinearRegressionOptions, 'includeIntercept'> = {}) {
    this.regularization = options.regularization ?? 'none';
    this.regularizationStrength = options.regularizationStrength ?? 0.01;
  }

  /**
   * Fit multiple linear regression using normal equations
   * y = X * beta
   */
  fit(X: number[][], y: number[]): void {
    if (X.length !== y.length || X.length === 0) {
      throw new Error('X and y must have the same number of samples');
    }

    const n = X.length;
    const p = X[0].length + 1; // Add 1 for intercept

    // Add intercept column (column of 1s)
    const XWithIntercept = X.map(row => [1, ...row]);

    // Calculate X'X
    const XtX = this.matrixMultiply(
      this.transpose(XWithIntercept),
      XWithIntercept
    );

    // Add regularization if specified
    if (this.regularization === 'l2') {
      for (let i = 1; i < p; i++) {
        XtX[i][i] += this.regularizationStrength;
      }
    }

    // Calculate X'y
    const Xty = this.matrixVectorMultiply(
      this.transpose(XWithIntercept),
      y
    );

    // Solve (X'X)^-1 * X'y
    const XtXInv = this.invertMatrix(XtX);
    this.coefficients = this.matrixVectorMultiply(XtXInv, Xty);
    this.fitted = true;
  }

  /**
   * Predict values
   */
  predict(X: number[][]): number[] {
    if (!this.fitted) {
      throw new Error('Model not fitted');
    }

    return X.map(row => {
      const rowWithIntercept = [1, ...row];
      return rowWithIntercept.reduce((sum, xi, i) => sum + xi * this.coefficients[i], 0);
    });
  }

  /**
   * Matrix transpose
   */
  private transpose(matrix: number[][]): number[][] {
    const rows = matrix.length;
    const cols = matrix[0].length;
    const result: number[][] = [];

    for (let j = 0; j < cols; j++) {
      result[j] = [];
      for (let i = 0; i < rows; i++) {
        result[j][i] = matrix[i][j];
      }
    }
    return result;
  }

  /**
   * Matrix multiplication
   */
  private matrixMultiply(A: number[][], B: number[][]): number[][] {
    const rowsA = A.length;
    const colsA = A[0].length;
    const colsB = B[0].length;
    const result: number[][] = [];

    for (let i = 0; i < rowsA; i++) {
      result[i] = [];
      for (let j = 0; j < colsB; j++) {
        let sum = 0;
        for (let k = 0; k < colsA; k++) {
          sum += A[i][k] * B[k][j];
        }
        result[i][j] = sum;
      }
    }
    return result;
  }

  /**
   * Matrix-vector multiplication
   */
  private matrixVectorMultiply(A: number[][], v: number[]): number[] {
    return A.map(row => row.reduce((sum, val, i) => sum + val * v[i], 0));
  }

  /**
   * Matrix inversion using Gauss-Jordan elimination
   */
  private invertMatrix(matrix: number[][]): number[][] {
    const n = matrix.length;
    const augmented: number[][] = matrix.map((row, i) => {
      const identity = Array(n).fill(0);
      identity[i] = 1;
      return [...row, ...identity];
    });

    // Forward elimination
    for (let i = 0; i < n; i++) {
      // Find pivot
      let maxRow = i;
      for (let k = i + 1; k < n; k++) {
        if (Math.abs(augmented[k][i]) > Math.abs(augmented[maxRow][i])) {
          maxRow = k;
        }
      }
      [augmented[i], augmented[maxRow]] = [augmented[maxRow], augmented[i]];

      if (Math.abs(augmented[i][i]) < 1e-10) {
        throw new Error('Matrix is singular');
      }

      // Scale row
      const scale = augmented[i][i];
      for (let j = 0; j < 2 * n; j++) {
        augmented[i][j] /= scale;
      }

      // Eliminate column
      for (let k = 0; k < n; k++) {
        if (k !== i) {
          const factor = augmented[k][i];
          for (let j = 0; j < 2 * n; j++) {
            augmented[k][j] -= factor * augmented[i][j];
          }
        }
      }
    }

    // Extract inverse
    return augmented.map(row => row.slice(n));
  }

  /**
   * Get coefficients
   */
  getCoefficients(): { intercept: number; weights: number[] } {
    if (!this.fitted) {
      throw new Error('Model not fitted');
    }
    return {
      intercept: this.coefficients[0],
      weights: this.coefficients.slice(1),
    };
  }
}

/**
 * Factory function for simple linear regression
 */
export function createLinearRegressionModel(
  options?: LinearRegressionOptions
): LinearRegressionModel {
  return new LinearRegressionModel(options);
}

/**
 * Convenience function for quick linear regression forecast
 */
export function linearRegressionForecast(
  dataPoints: DataPoint[],
  horizon: number
): PredictionPoint[] {
  const model = new LinearRegressionModel();
  model.fit(dataPoints);
  return model.forecast(dataPoints, horizon);
}
