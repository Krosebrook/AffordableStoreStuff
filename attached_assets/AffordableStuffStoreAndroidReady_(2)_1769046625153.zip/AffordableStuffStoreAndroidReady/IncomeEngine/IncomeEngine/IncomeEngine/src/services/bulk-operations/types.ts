/**
 * Bulk Operations Types
 * TypeScript interfaces for batch processing of products across platforms
 */

import { ConnectorName } from '../../connectors/index';
import { NormalizedProduct, ProductInput, ConnectorError } from '../../connectors/core/types';

// ============================================================================
// Operation Types
// ============================================================================

export type BulkOperationType = 'create' | 'update' | 'delete' | 'sync' | 'publish';
export type BulkOperationStatus = 'pending' | 'queued' | 'processing' | 'completed' | 'failed' | 'partial' | 'cancelled' | 'rolling_back';
export type BulkItemStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'skipped' | 'rolled_back';
export type BulkPriority = 'low' | 'normal' | 'high' | 'critical';

// ============================================================================
// Bulk Operation Configuration
// ============================================================================

export interface BulkOperationConfig {
  /** Maximum items per batch (default: 10) */
  batchSize: number;
  /** Number of concurrent batches (default: 3) */
  concurrency: number;
  /** Continue processing even if some items fail */
  continueOnError: boolean;
  /** Rollback all changes if any item fails */
  rollbackOnFailure: boolean;
  /** Simulate the operation without making changes */
  dryRun: boolean;
  /** Send webhook notification on completion */
  notifyOnCompletion: boolean;
  /** Custom webhook URL for notifications */
  webhookUrl?: string;
  /** Webhook secret for signing payloads */
  webhookSecret?: string;
  /** Maximum retries per item (default: 3) */
  maxRetries: number;
  /** Delay between retries in ms (default: 1000) */
  retryDelayMs: number;
  /** Overall operation timeout in ms (default: 30 minutes) */
  timeoutMs: number;
  /** Rate limit awareness - respect platform limits */
  respectRateLimits: boolean;
  /** Custom rate limit override (requests per minute) */
  customRateLimitRpm?: number;
}

export const DEFAULT_BULK_CONFIG: BulkOperationConfig = {
  batchSize: 10,
  concurrency: 3,
  continueOnError: true,
  rollbackOnFailure: false,
  dryRun: false,
  notifyOnCompletion: true,
  maxRetries: 3,
  retryDelayMs: 1000,
  timeoutMs: 30 * 60 * 1000, // 30 minutes
  respectRateLimits: true,
};

// ============================================================================
// Bulk Operation Items
// ============================================================================

export interface BulkOperationItem {
  id: string;
  operationType: BulkOperationType;
  status: BulkItemStatus;
  productId?: string;
  externalId?: string;
  data: ProductInput | Partial<NormalizedProduct>;
  targetPlatforms: ConnectorName[];
  platformResults: PlatformOperationResult[];
  retryCount: number;
  error?: BulkItemError;
  rollbackData?: RollbackData;
  startedAt?: Date;
  completedAt?: Date;
  createdAt: Date;
}

export interface PlatformOperationResult {
  platform: ConnectorName;
  success: boolean;
  externalId?: string;
  externalUrl?: string;
  error?: ConnectorError;
  duration: number;
  retries: number;
  rateLimitHit: boolean;
}

export interface BulkItemError {
  code: string;
  message: string;
  platform?: ConnectorName;
  retryable: boolean;
  details?: Record<string, unknown>;
}

// ============================================================================
// Rollback Data
// ============================================================================

export interface RollbackData {
  operationType: BulkOperationType;
  productId?: string;
  platformData: PlatformRollbackData[];
  createdAt: Date;
}

export interface PlatformRollbackData {
  platform: ConnectorName;
  externalId: string;
  previousState?: NormalizedProduct;
  action: 'delete' | 'restore' | 'update';
  completed: boolean;
  error?: string;
}

// ============================================================================
// Bulk Operation (Main Container)
// ============================================================================

export interface BulkOperation {
  id: string;
  type: BulkOperationType;
  status: BulkOperationStatus;
  priority: BulkPriority;
  config: BulkOperationConfig;
  items: BulkOperationItem[];
  progress: BulkOperationProgress;
  result?: BulkOperationResult;
  metadata: BulkOperationMetadata;
  createdAt: Date;
  updatedAt: Date;
  startedAt?: Date;
  completedAt?: Date;
}

export interface BulkOperationProgress {
  total: number;
  processed: number;
  successful: number;
  failed: number;
  skipped: number;
  pending: number;
  percent: number;
  currentBatch: number;
  totalBatches: number;
  estimatedTimeRemainingMs?: number;
  currentItemId?: string;
  currentPlatform?: ConnectorName;
  rateLimitPaused: boolean;
  rateLimitResumeAt?: Date;
}

export interface BulkOperationResult {
  success: boolean;
  total: number;
  successful: number;
  failed: number;
  skipped: number;
  duration: number;
  rollbackPerformed: boolean;
  rollbackSuccess?: boolean;
  itemResults: BulkItemResult[];
  errors: BulkOperationError[];
}

export interface BulkItemResult {
  itemId: string;
  productId?: string;
  success: boolean;
  platforms: PlatformOperationResult[];
  error?: BulkItemError;
}

export interface BulkOperationError {
  itemId?: string;
  platform?: ConnectorName;
  code: string;
  message: string;
  timestamp: Date;
}

export interface BulkOperationMetadata {
  createdBy?: string;
  source?: string;
  tags?: string[];
  notes?: string;
  externalReferenceId?: string;
  customData?: Record<string, unknown>;
}

// ============================================================================
// Bulk Operation Request
// ============================================================================

export interface CreateBulkOperationRequest {
  type: BulkOperationType;
  items: BulkOperationItemInput[];
  targetPlatforms: ConnectorName[];
  config?: Partial<BulkOperationConfig>;
  priority?: BulkPriority;
  metadata?: Partial<BulkOperationMetadata>;
  scheduledAt?: Date;
}

export interface BulkOperationItemInput {
  productId?: string;
  externalId?: string;
  data: ProductInput | Partial<NormalizedProduct>;
  overrideTargetPlatforms?: ConnectorName[];
}

// ============================================================================
// Progress Tracking Events
// ============================================================================

export type ProgressEventType =
  | 'operation:started'
  | 'operation:progress'
  | 'operation:completed'
  | 'operation:failed'
  | 'operation:cancelled'
  | 'batch:started'
  | 'batch:completed'
  | 'item:started'
  | 'item:completed'
  | 'item:failed'
  | 'item:skipped'
  | 'item:retrying'
  | 'rollback:started'
  | 'rollback:completed'
  | 'rollback:failed'
  | 'ratelimit:hit'
  | 'ratelimit:resumed';

export interface ProgressEvent {
  type: ProgressEventType;
  operationId: string;
  timestamp: Date;
  data: ProgressEventData;
}

export interface ProgressEventData {
  progress?: BulkOperationProgress;
  itemId?: string;
  batchNumber?: number;
  platform?: ConnectorName;
  error?: BulkItemError;
  result?: BulkOperationResult;
  retryCount?: number;
  waitTimeMs?: number;
  metadata?: Record<string, unknown>;
}

export type ProgressEventHandler = (event: ProgressEvent) => void | Promise<void>;

// ============================================================================
// Webhook Payload Types
// ============================================================================

export interface BulkOperationWebhookPayload {
  event: 'bulk_operation_started' | 'bulk_operation_progress' | 'bulk_operation_completed' | 'bulk_operation_failed';
  operationId: string;
  operationType: BulkOperationType;
  timestamp: string;
  data: {
    status: BulkOperationStatus;
    progress: BulkOperationProgress;
    result?: BulkOperationResult;
    errors?: BulkOperationError[];
  };
}

// ============================================================================
// Queue Types
// ============================================================================

export interface QueuedBulkOperation extends BulkOperation {
  queuePosition: number;
  estimatedStartTime?: Date;
}

export interface BulkOperationQueueStats {
  totalOperations: number;
  pendingOperations: number;
  processingOperations: number;
  completedOperations24h: number;
  failedOperations24h: number;
  averageProcessingTimeMs: number;
  averageItemsPerOperation: number;
  oldestOperationAge: number;
}

// ============================================================================
// Platform Rate Limit Types
// ============================================================================

export interface PlatformRateLimitStatus {
  platform: ConnectorName;
  isLimited: boolean;
  remainingRequests: number;
  resetAt?: Date;
  estimatedWaitMs: number;
}

export interface BulkRateLimitConfig {
  platform: ConnectorName;
  requestsPerMinute: number;
  requestsPerHour?: number;
  burstLimit?: number;
  cooldownMs?: number;
}

// ============================================================================
// Audit Types
// ============================================================================

export interface BulkOperationAuditEntry {
  id: string;
  operationId: string;
  action: 'created' | 'started' | 'progress' | 'completed' | 'failed' | 'cancelled' | 'rollback_started' | 'rollback_completed';
  itemId?: string;
  platform?: ConnectorName;
  previousValue?: unknown;
  newValue?: unknown;
  actor: 'system' | 'user' | 'webhook' | 'scheduler';
  details?: Record<string, unknown>;
  timestamp: Date;
}

// ============================================================================
// Filter and Query Types
// ============================================================================

export interface BulkOperationQuery {
  status?: BulkOperationStatus | BulkOperationStatus[];
  type?: BulkOperationType | BulkOperationType[];
  priority?: BulkPriority | BulkPriority[];
  platform?: ConnectorName | ConnectorName[];
  createdAfter?: Date;
  createdBefore?: Date;
  limit?: number;
  offset?: number;
  sortBy?: 'createdAt' | 'updatedAt' | 'priority' | 'progress';
  sortOrder?: 'asc' | 'desc';
}

export interface BulkOperationListResult {
  operations: BulkOperation[];
  total: number;
  limit: number;
  offset: number;
  hasMore: boolean;
}
