/**
 * Safeguards management tools for MCP server
 */

export const safeguardTools = [
  {
    name: 'check_safeguards',
    description: 'Get status of all 8 safeguard modules',
    inputSchema: {
      type: 'object',
      properties: {},
      required: [],
    },
  },
  {
    name: 'reset_safeguard',
    description: 'Reset a specific safeguard',
    inputSchema: {
      type: 'object',
      properties: {
        safeguard: {
          type: 'string',
          description: 'Safeguard to reset',
          enum: [
            'rate-limiter',
            'budget',
            'circuit-breaker',
            'quality-gate',
            'api-queue',
          ],
        },
        target: {
          type: 'string',
          description: 'Optional target (e.g., specific API or platform)',
        },
      },
      required: ['safeguard'],
    },
  },
];

export async function handleSafeguardTool(name, args, supabase) {
  switch (name) {
    case 'check_safeguards':
      return await checkSafeguards(supabase);
    case 'reset_safeguard':
      return await resetSafeguard(args.safeguard, args.target, supabase);
    default:
      throw new Error(`Unknown safeguard tool: ${name}`);
  }
}

async function checkSafeguards(supabase) {
  const safeguards = {
    'rate-limiter': { status: 'healthy', details: {} },
    'quality-gate': { status: 'healthy', details: {} },
    'trademark-screener': { status: 'healthy', details: {} },
    'api-queue': { status: 'healthy', details: {} },
    'provider-failover': { status: 'healthy', details: {} },
    'tax-compliance': { status: 'healthy', details: {} },
    'human-in-the-loop': { status: 'healthy', details: {} },
    'budget-circuit-breaker': { status: 'healthy', details: {} },
  };

  // Check rate limiter status
  const { data: rateLimits } = await supabase
    .from('api_rate_limits')
    .select('*')
    .gt('request_count', 0);

  if (rateLimits) {
    const nearLimit = rateLimits.filter(
      (r) => r.request_count > r.max_requests * 0.8
    );
    if (nearLimit.length > 0) {
      safeguards['rate-limiter'].status = 'warning';
      safeguards['rate-limiter'].details = {
        nearLimitApis: nearLimit.map((r) => r.api_name),
      };
    }
  }

  // Check budget status
  const { data: budget } = await supabase
    .from('budget_tracking')
    .select('*')
    .single();

  if (budget) {
    const usagePercent = (budget.current_spend / budget.daily_limit) * 100;
    safeguards['budget-circuit-breaker'].details = {
      currentSpend: budget.current_spend,
      dailyLimit: budget.daily_limit,
      usagePercent: Math.round(usagePercent),
    };

    if (usagePercent >= 90) {
      safeguards['budget-circuit-breaker'].status = 'critical';
    } else if (usagePercent >= 75) {
      safeguards['budget-circuit-breaker'].status = 'warning';
    }
  }

  // Check circuit breaker state
  const { data: circuitState } = await supabase
    .from('circuit_breaker_state')
    .select('*')
    .eq('is_open', true);

  if (circuitState && circuitState.length > 0) {
    safeguards['budget-circuit-breaker'].status = 'open';
    safeguards['budget-circuit-breaker'].details.openBreakers = circuitState.map(
      (c) => c.breaker_name
    );
  }

  // Check pending approvals
  const { count: pendingApprovals } = await supabase
    .from('approval_queue')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'pending');

  safeguards['human-in-the-loop'].details = {
    pendingApprovals: pendingApprovals || 0,
  };
  if (pendingApprovals > 10) {
    safeguards['human-in-the-loop'].status = 'attention';
  }

  // Check API queue depth
  const { count: queueDepth } = await supabase
    .from('api_request_queue')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'pending');

  safeguards['api-queue'].details = {
    pendingRequests: queueDepth || 0,
  };
  if (queueDepth > 100) {
    safeguards['api-queue'].status = 'backlogged';
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify({ safeguards }, null, 2),
      },
    ],
  };
}

async function resetSafeguard(safeguard, target, supabase) {
  let result;

  switch (safeguard) {
    case 'rate-limiter':
      if (target) {
        const { error } = await supabase
          .from('api_rate_limits')
          .update({ request_count: 0, reset_at: new Date().toISOString() })
          .eq('api_name', target);
        if (error) throw new Error(error.message);
        result = { reset: 'rate-limiter', target, success: true };
      } else {
        const { error } = await supabase
          .from('api_rate_limits')
          .update({ request_count: 0, reset_at: new Date().toISOString() })
          .neq('api_name', '');
        if (error) throw new Error(error.message);
        result = { reset: 'rate-limiter', target: 'all', success: true };
      }
      break;

    case 'budget':
      const { error: budgetError } = await supabase
        .from('budget_tracking')
        .update({ current_spend: 0, reset_at: new Date().toISOString() })
        .neq('id', '');
      if (budgetError) throw new Error(budgetError.message);
      result = { reset: 'budget', success: true };
      break;

    case 'circuit-breaker':
      const { error: cbError } = await supabase
        .from('circuit_breaker_state')
        .update({ is_open: false, closed_at: new Date().toISOString() })
        .eq('is_open', true);
      if (cbError) throw new Error(cbError.message);
      result = { reset: 'circuit-breaker', success: true };
      break;

    case 'api-queue':
      // Clear stale pending requests older than 1 hour
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
      const { error: queueError } = await supabase
        .from('api_request_queue')
        .update({ status: 'cancelled' })
        .eq('status', 'pending')
        .lt('created_at', oneHourAgo);
      if (queueError) throw new Error(queueError.message);
      result = { reset: 'api-queue', action: 'cancelled_stale', success: true };
      break;

    default:
      throw new Error(`Cannot reset safeguard: ${safeguard}`);
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify(result, null, 2),
      },
    ],
  };
}
