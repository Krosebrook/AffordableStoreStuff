/**
 * Product management tools for MCP server
 */

export const productTools = [
  {
    name: 'create_product',
    description: 'Create a product on specified platform',
    inputSchema: {
      type: 'object',
      properties: {
        platform: {
          type: 'string',
          description: 'Target platform',
          enum: [
            'printify',
            'etsy',
            'teepublic',
            'society6',
            'redbubble',
            'gumroad',
            'creative-fabrica',
            'amazon-kdp',
            'shopify',
            'woocommerce',
            'tiktok-shop',
          ],
        },
        product: {
          type: 'object',
          description: 'Product details',
          properties: {
            title: { type: 'string' },
            description: { type: 'string' },
            images: { type: 'array', items: { type: 'string' } },
            tags: { type: 'array', items: { type: 'string' } },
            price: { type: 'number' },
          },
          required: ['title'],
        },
      },
      required: ['platform', 'product'],
    },
  },
  {
    name: 'list_products',
    description: 'Fetch products from platform',
    inputSchema: {
      type: 'object',
      properties: {
        platform: {
          type: 'string',
          description: 'Platform to fetch from, or "all" for all platforms',
        },
        page: {
          type: 'number',
          description: 'Page number (default: 1)',
        },
        limit: {
          type: 'number',
          description: 'Items per page (default: 20)',
        },
        status: {
          type: 'string',
          description: 'Filter by status',
          enum: ['active', 'draft', 'pending', 'archived'],
        },
      },
      required: ['platform'],
    },
  },
];

export async function handleProductTool(name, args, supabase) {
  switch (name) {
    case 'create_product':
      return await createProduct(args.platform, args.product, supabase);
    case 'list_products':
      return await listProducts(
        args.platform,
        args.page || 1,
        args.limit || 20,
        args.status,
        supabase
      );
    default:
      throw new Error(`Unknown product tool: ${name}`);
  }
}

async function createProduct(platform, product, supabase) {
  // Insert product into queue for processing
  const { data, error } = await supabase
    .from('product_queue')
    .insert({
      platform: platform,
      title: product.title,
      description: product.description || '',
      images: product.images || [],
      tags: product.tags || [],
      price: product.price,
      status: 'pending',
      created_at: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create product: ${error.message}`);
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify({
          success: true,
          message: `Product "${product.title}" queued for ${platform}`,
          productId: data.id,
          status: 'pending',
          note: 'Product will be processed through safeguards before publishing',
        }),
      },
    ],
  };
}

async function listProducts(platform, page, limit, status, supabase) {
  let query = supabase
    .from('products')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range((page - 1) * limit, page * limit - 1);

  if (platform !== 'all') {
    query = query.eq('platform', platform);
  }

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error, count } = await query;

  if (error) {
    throw new Error(`Failed to fetch products: ${error.message}`);
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify({
          products: data,
          pagination: {
            page,
            limit,
            total: count,
            totalPages: Math.ceil(count / limit),
          },
        }, null, 2),
      },
    ],
  };
}
