/**
 * Workflow management tools for MCP server
 */

export const workflowTools = [
  {
    name: 'run_workflow',
    description: 'Execute an n8n workflow',
    inputSchema: {
      type: 'object',
      properties: {
        workflow: {
          type: 'string',
          description: 'Workflow to execute',
          enum: [
            'niche-scanner',
            'product-generator',
            'printify-publisher',
            'etsy-publisher',
            'gumroad-publisher',
            'revenue-aggregator',
            'daily-report',
            'batch-processor',
          ],
        },
        parameters: {
          type: 'object',
          description: 'Parameters to pass to the workflow',
        },
      },
      required: ['workflow'],
    },
  },
  {
    name: 'get_workflow_status',
    description: 'Check status of a workflow execution',
    inputSchema: {
      type: 'object',
      properties: {
        executionId: {
          type: 'string',
          description: 'Execution ID to check',
        },
      },
      required: ['executionId'],
    },
  },
];

// Workflow name to file mapping
const WORKFLOW_FILES = {
  'niche-scanner': '01-niche-scanner.json',
  'product-generator': '02-product-generator.json',
  'printify-publisher': '03-printify-publisher.json',
  'etsy-publisher': '04-etsy-publisher.json',
  'gumroad-publisher': '05-gumroad-publisher.json',
  'revenue-aggregator': '06-revenue-aggregator.json',
  'daily-report': '07-daily-report.json',
  'batch-processor': '08-batch-processor.json',
};

export async function handleWorkflowTool(name, args, supabase) {
  switch (name) {
    case 'run_workflow':
      return await runWorkflow(args.workflow, args.parameters || {}, supabase);
    case 'get_workflow_status':
      return await getWorkflowStatus(args.executionId, supabase);
    default:
      throw new Error(`Unknown workflow tool: ${name}`);
  }
}

async function runWorkflow(workflow, parameters, supabase) {
  // Create execution record
  const { data: execution, error } = await supabase
    .from('workflow_executions')
    .insert({
      workflow_name: workflow,
      workflow_file: WORKFLOW_FILES[workflow],
      parameters: parameters,
      status: 'queued',
      created_at: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to queue workflow: ${error.message}`);
  }

  // In a full implementation, this would trigger the n8n webhook
  // For now, we just queue it for the batch processor to pick up

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify({
          success: true,
          message: `Workflow "${workflow}" queued for execution`,
          executionId: execution.id,
          status: 'queued',
          workflowFile: WORKFLOW_FILES[workflow],
          parameters: parameters,
        }, null, 2),
      },
    ],
  };
}

async function getWorkflowStatus(executionId, supabase) {
  const { data, error } = await supabase
    .from('workflow_executions')
    .select('*')
    .eq('id', executionId)
    .single();

  if (error) {
    throw new Error(`Failed to fetch execution: ${error.message}`);
  }

  if (!data) {
    throw new Error(`Execution not found: ${executionId}`);
  }

  const result = {
    executionId: data.id,
    workflow: data.workflow_name,
    status: data.status,
    createdAt: data.created_at,
    startedAt: data.started_at,
    completedAt: data.completed_at,
  };

  if (data.status === 'completed') {
    result.result = data.result;
  } else if (data.status === 'failed') {
    result.error = data.error_message;
  } else if (data.status === 'running') {
    result.progress = data.progress || 0;
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify(result, null, 2),
      },
    ],
  };
}
