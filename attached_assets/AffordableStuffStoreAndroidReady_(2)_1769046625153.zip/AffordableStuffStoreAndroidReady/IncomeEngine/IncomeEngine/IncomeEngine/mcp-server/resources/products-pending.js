/**
 * Pending products resource
 */

export async function getProductsPending(supabase) {
  // Fetch products pending approval
  const { data: pendingApproval, error: approvalError } = await supabase
    .from('approval_queue')
    .select('*')
    .eq('status', 'pending')
    .order('created_at', { ascending: true })
    .limit(50);

  if (approvalError) {
    throw new Error(`Failed to fetch pending approvals: ${approvalError.message}`);
  }

  // Fetch products in processing queue
  const { data: processingQueue, error: queueError } = await supabase
    .from('product_queue')
    .select('*')
    .in('status', ['pending', 'processing'])
    .order('created_at', { ascending: true })
    .limit(50);

  if (queueError) {
    throw new Error(`Failed to fetch processing queue: ${queueError.message}`);
  }

  // Fetch products with quality issues
  const { data: qualityIssues, error: qualityError } = await supabase
    .from('products')
    .select('*')
    .lt('quality_score', 70)
    .eq('status', 'draft')
    .order('quality_score', { ascending: true })
    .limit(20);

  if (qualityError) {
    throw new Error(`Failed to fetch quality issues: ${qualityError.message}`);
  }

  const summary = {
    pendingApproval: pendingApproval?.length || 0,
    inProcessing: processingQueue?.length || 0,
    qualityIssues: qualityIssues?.length || 0,
    total: (pendingApproval?.length || 0) + (processingQueue?.length || 0),
  };

  return {
    contents: [
      {
        uri: 'products://pending',
        mimeType: 'application/json',
        text: JSON.stringify({
          summary,
          pendingApproval: pendingApproval || [],
          processingQueue: processingQueue || [],
          qualityIssues: qualityIssues || [],
        }, null, 2),
      },
    ],
  };
}
