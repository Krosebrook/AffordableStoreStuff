# Income Engine - AI Assistant Guide

## Project Overview

This is the **Income Engine** - a production-ready passive income automation platform for ecommerce and digital products. It supports 11 platform connectors, 8 safeguard systems, and integrates with AI services for design generation, predictive analytics, and pricing optimization.

### Architecture

```
D:\IncomeEngine\
├── src/
│   ├── client/           # React 18 PWA frontend
│   │   ├── components/   # Reusable UI components
│   │   ├── pages/        # Route-level page components
│   │   ├── hooks/        # Custom React hooks
│   │   ├── lib/          # Utilities (TanStack Query, etc.)
│   │   └── types/        # TypeScript type definitions
│   ├── server/           # Express.js API server
│   │   └── index.ts      # Main server with all API routes
│   ├── safeguards/       # 8 Safeguard modules + orchestrator
│   │   ├── orchestrator.ts
│   │   ├── rate-limiter.ts
│   │   ├── quality-gate.ts
│   │   ├── trademark-screener.ts
│   │   ├── api-queue.ts
│   │   ├── provider-failover.ts
│   │   ├── tax-compliance.ts
│   │   ├── human-in-the-loop.ts
│   │   └── budget-circuit-breaker.ts
│   └── connectors/       # Platform connector system
│       ├── adapters/     # 11 Platform adapters
│       ├── core/         # Base connector, types, utilities
│       ├── utils/        # Retry, error mapping, TOTP, webhooks
│       └── workflows/    # POD and Marketplace workflows
├── mcp-server/           # MCP server for AI integration
│   ├── index.js          # Main entry point
│   ├── tools/            # 9 MCP tools
│   └── resources/        # 4 MCP resources
├── database/             # SQL schemas and migrations
│   ├── schema-v2.sql     # Current schema (use this)
│   └── migrations/       # Incremental migrations
├── docs/                 # Documentation
│   ├── platform-guides/  # Per-platform setup guides
│   ├── ai-tools/         # AI integration docs
│   ├── API.md            # API documentation
│   ├── ARCHITECTURE.md   # System architecture
│   ├── DEPLOYMENT.md     # Deployment guide
│   └── RUNBOOK.md        # Operations runbook
├── android/              # Capacitor Android app
├── public/               # Static assets and PWA icons
└── *.json                # n8n workflow files (01-08)
```

### Tech Stack

- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS
- **Backend**: Express.js, TypeScript
- **Database**: Supabase (PostgreSQL with RLS)
- **Mobile**: Capacitor 6 for Android/iOS
- **State**: TanStack Query v5 with caching
- **AI Services**: OpenAI, Anthropic, Replicate, Stability AI
- **Deployment**: Replit Autoscale

## Key Concepts

### The 8 Safeguards

1. **Rate Limiter** (`rate-limiter.ts`) - Per-API request throttling
2. **Quality Gate** (`quality-gate.ts`) - Multi-rule quality scoring with AI
3. **Trademark Screener** (`trademark-screener.ts`) - USPTO TESS checking
4. **API Queue** (`api-queue.ts`) - Prioritized request queue with backoff
5. **Provider Failover** (`provider-failover.ts`) - Multi-provider redundancy
6. **Tax Compliance** (`tax-compliance.ts`) - Nexus tracking
7. **Human-in-the-Loop** (`human-in-the-loop.ts`) - Approval workflow
8. **Budget Circuit Breaker** (`budget-circuit-breaker.ts`) - Spending limits

Additional files in `src/safeguards/`:
- `orchestrator.legacy.ts` - Deprecated orchestrator (reference only)
- `safeguards-pipeline.json` - Pipeline configuration
- `__tests__/safeguards.test.ts` - Test suite

### Orchestrator

The `orchestrator.ts` coordinates all safeguards. Products flow through:
1. Rate limit check
2. Quality gate assessment
3. Trademark screening
4. Budget check
5. Human approval (if needed)
6. Publishing via queued API calls

### Platform Connectors (11 Total)

| Platform | Adapter File | Type | Auth | Workflow |
|----------|--------------|------|------|----------|
| Printify | `printify-adapter.ts` | POD | API Key | pod_digital |
| Etsy | `etsy-adapter.ts` | POD | OAuth 2.0 | pod_digital |
| TeePublic | `teepublic-adapter.ts` | POD | Playwright | pod_digital |
| Society6 | `society6-adapter.ts` | POD | Playwright | pod_digital |
| Redbubble | `redbubble-adapter.ts` | POD | Playwright | pod_digital |
| Gumroad | `gumroad-adapter.ts` | Digital | OAuth 2.0 | pod_digital |
| Creative Fabrica | `creative-fabrica-adapter.ts` | Digital | API Key | pod_digital |
| Amazon KDP | `amazon-kdp-adapter.ts` | Digital | Playwright + 2FA | marketplace |
| Shopify | `shopify-adapter.ts` | Marketplace | OAuth 2.0 | marketplace |
| WooCommerce | `woocommerce-adapter.ts` | Marketplace | API Key | marketplace |
| TikTok Shop | `tiktok-shop-adapter.ts` | Marketplace | OAuth 2.0 | marketplace |

### Workflow Engines

Two workflow engines coordinate multi-platform publishing:

1. **PODDigitalWorkflow** (`workflows/pod-digital-workflow.ts`)
   - Handles POD platforms (Printify, TeePublic, Society6, Redbubble)
   - Handles digital platforms (Gumroad, Creative Fabrica)
   - Parallel publishing to multiple targets
   - Cross-platform analytics

2. **MarketplaceWorkflow** (`workflows/marketplace-workflow.ts`)
   - Handles marketplace platforms (Shopify, WooCommerce, TikTok Shop, Amazon KDP)
   - Inventory synchronization across platforms
   - Order sync and fulfillment
   - Low stock alerts via webhooks

### Utility Services

Located in `src/connectors/utils/`:

- **TOTP** (`totp.ts`) - 2FA/OTP generation for platforms like Amazon KDP
- **Webhooks** (`webhook.ts`) - Queue-based notification delivery
- **Retry Handler** (`retry-handler.ts`) - Exponential backoff and circuit breaker
- **Error Mapper** (`error-mapper.ts`) - Platform-specific error normalization

## API Endpoints

### Health & Status
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check (required for Autoscale) |
| GET | `/api/status` | Full system status |

### Safeguards
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/budget` | Budget status |
| GET | `/api/approvals` | Approval queue |
| POST | `/api/approvals/:id/approve` | Approve a product |
| POST | `/api/approvals/:id/reject` | Reject a product |
| GET | `/api/providers` | Provider health |
| GET | `/api/queue` | API queue stats |

### Products
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/products/process` | Process product through safeguards |
| POST | `/api/products/:id/publish/pod` | Publish to POD platforms |
| POST | `/api/products/:id/publish/marketplace` | Publish to marketplaces |

### Connectors
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/connectors` | List available connectors |
| GET | `/api/connectors/:platform` | Get connector metadata |
| POST | `/api/connectors/:platform/test` | Test connection |
| POST | `/api/connectors/:platform/connect` | Connect platform |
| POST | `/api/connectors/:platform/disconnect` | Disconnect platform |
| GET | `/api/connectors/:platform/products` | List platform products |

### Analytics & Workflows
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/analytics/platforms` | Cross-platform analytics |
| POST | `/api/inventory/sync` | Sync inventory |
| GET | `/api/workflows/status` | Active workflow status |

## Coding Standards

### TypeScript

- Use strict mode (`strict: true` in tsconfig)
- Prefer `interface` over `type` for objects
- Use `readonly` for immutable data
- Export types from `types/index.ts`

### React Components

- Functional components only
- Use `memo()` for expensive renders
- Extract hooks to `hooks/` directory
- Use ErrorBoundary for error handling

### Naming Conventions

- Files: `kebab-case.ts` for utilities, `PascalCase.tsx` for components
- Components: `PascalCase`
- Hooks: `useCamelCase`
- Types/Interfaces: `PascalCase`
- Constants: `SCREAMING_SNAKE_CASE`

### File Organization

- One component per file
- Co-locate tests with source (`*.test.ts`)
- Group by feature, not by type

## Common Tasks

### Adding a New Safeguard

1. Create file in `src/safeguards/new-safeguard.ts`
2. Implement the safeguard class with `check()` method
3. Add to orchestrator in `orchestrator.ts`
4. Add database tables in `database/schema-v2.sql`
5. Add API endpoint in `src/server/index.ts`

### Adding a Platform Connector

1. Create adapter in `src/connectors/adapters/{platform}-adapter.ts`
2. Extend `BaseConnector` from `core/base-connector.ts`
3. Implement required methods:
   - `authenticate()`, `refreshAuth()`, `validateCredentials()`
   - `listProducts()`, `getProduct()`, `createProduct()`, `updateProduct()`, `deleteProduct()`
   - `normalizeProduct()`, `denormalizeProduct()`, `validateProductForPlatform()`
4. Add export to `src/connectors/index.ts`
5. Update `createConnector()` factory function
6. Update `getConnectorMetadata()` with new platform info
7. Add platform documentation in `docs/platform-guides/`

### Modifying the Database Schema

Database files:
- `database/schema.sql` - Original schema
- `database/schema-extensions.sql` - Extended features
- `database/schema-v2.sql` - Current version (use this)
- `database/migrations/` - Migration files:
  - `002-add-connector-tables.sql` - Platform connections, mappings, orders
  - `003-add-webhook-tables.sql` - Webhook queue, log, endpoints
  - `004-enhance-products-table.sql` - Inventory tracking, SKU generation
  - `005-add-2fa-support.sql` - TOTP credentials, auth logging

Steps:
1. Edit `database/schema-v2.sql` for new tables
2. Create migration in `database/migrations/`
3. Update TypeScript types in `src/client/types/`
4. Run Supabase migration: `npm run db:push`

### Adding a New API Endpoint

1. Add route in `src/server/index.ts`
2. Update TanStack Query hooks in `src/client/hooks/useQueries.ts`
3. Add query key to `QUERY_KEYS` in `lib/queryClient.ts`

## Environment Variables

See `.env.example` for complete list. Key categories:

### Required (Database & AI)
```
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...
SUPABASE_ANON_KEY=eyJhbGc...
OPENAI_API_KEY=sk-...
REPLICATE_API_TOKEN=r8_...
```

### Platform Credentials
```
# POD Platforms
PRINTIFY_API_KEY=
PRINTIFY_SHOP_ID=
ETSY_API_KEY=
ETSY_SHARED_SECRET=
ETSY_SHOP_ID=

# Digital Platforms
GUMROAD_ACCESS_TOKEN=
GUMROAD_CLIENT_ID=
GUMROAD_CLIENT_SECRET=
CREATIVE_FABRICA_API_KEY=

# Marketplace Platforms
SHOPIFY_API_KEY=
SHOPIFY_API_SECRET=
SHOPIFY_SHOP_DOMAIN=
WOOCOMMERCE_URL=
WOOCOMMERCE_KEY=
WOOCOMMERCE_SECRET=
TIKTOK_APP_KEY=
TIKTOK_APP_SECRET=
```

### Configuration
```
# Budget Limits
MAX_DAILY_AI_SPEND=5.00
MAX_MONTHLY_BUDGET=150.00
BUDGET_WARNING_THRESHOLD=0.75
BUDGET_CRITICAL_THRESHOLD=0.90

# Rate Limiting
RATE_LIMIT_WINDOW_MS=60000
DEFAULT_REQUESTS_PER_MINUTE=30

# Quality Gates
MIN_QUALITY_SCORE=70
AUTO_APPROVE_THRESHOLD=80

# Application
NODE_ENV=development
PORT=3000
SESSION_SECRET=your-random-secret
APP_BASE_URL=https://your-app.replit.app
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
```

## Do's and Don'ts

### Do

- Use TanStack Query for all API calls
- Wrap routes in ErrorBoundary
- Use database-driven costs (not hardcoded)
- Close Playwright browsers in finally blocks
- Use optimistic updates for better UX
- Add proper TypeScript types

### Don't

- Hardcode API costs or credentials
- Skip error handling on async operations
- Use `any` type (use `unknown` instead)
- Commit secrets to git
- Bypass safeguards in production
- Use inline styles (use Tailwind)

## Testing

```bash
# Run all tests
npm run test

# Run safeguard tests only
npm run test:safeguards

# Watch mode
npm run test:watch
```

## Building & Deployment

```bash
# Development
npm run dev

# Build for production
npm run build

# Android development
npm run android:dev

# Android release bundle
npm run android:bundle
```

## Mobile App Setup (Capacitor)

### Prerequisites
- Android Studio (for Android builds)
- Xcode (for iOS builds, macOS only)
- Node.js 20+

### Android Development
```bash
# Build web assets
npm run build

# Sync to Android project
npx cap sync android

# Open in Android Studio
npx cap open android

# Run on device/emulator
npx cap run android
```

### iOS Development
```bash
# Sync to iOS project
npx cap sync ios

# Open in Xcode
npx cap open ios
```

### Live Reload
```bash
# Start with live reload
npm run android:dev
```

## MCP Integration

This project includes a full MCP server for AI-assisted management.

### Setup

```bash
cd mcp-server
npm install
node index.js --test  # Verify
```

Configure in `.claude/mcp-servers.json`:

```json
{
  "servers": {
    "income-engine": {
      "command": "node",
      "args": ["mcp-server/index.js"],
      "env": {
        "SUPABASE_URL": "${SUPABASE_URL}",
        "SUPABASE_SERVICE_KEY": "${SUPABASE_SERVICE_KEY}"
      }
    }
  }
}
```

### Available Tools

| Tool | Description |
|------|-------------|
| `list_platforms` | Get all connected platforms with status |
| `connect_platform` | Connect/update a platform |
| `create_product` | Queue a product for processing |
| `list_products` | Fetch products from platforms |
| `get_analytics` | Get revenue and performance metrics |
| `check_safeguards` | Check status of all 8 safeguards |
| `reset_safeguard` | Reset rate-limiter, budget, or circuit-breaker |
| `run_workflow` | Execute an n8n workflow |
| `get_workflow_status` | Check workflow execution status |

### Resources

- `platforms://status` - Platform connection status
- `products://pending` - Products awaiting approval
- `analytics://dashboard` - Dashboard summary
- `budget://current` - Budget utilization

### Development

Add new tools in `mcp-server/tools/`. See `docs/ai-tools/MCP-INTEGRATION.md` for full documentation.

## n8n Workflows

Eight automated workflows are included:

| # | File | Description |
|---|------|-------------|
| 01 | `01-niche-scanner.json` | Scan for trending niches |
| 02 | `02-product-generator.json` | Generate product designs |
| 03 | `03-printify-publisher.json` | Publish to Printify |
| 04 | `04-etsy-publisher.json` | Publish to Etsy |
| 05 | `05-gumroad-publisher.json` | Publish to Gumroad |
| 06 | `06-revenue-aggregator.json` | Aggregate revenue data |
| 07 | `07-daily-report.json` | Generate daily reports |
| 08 | `08-batch-processor.json` | Process batch operations |

## Troubleshooting

### "Safeguards not configured"

Missing Supabase URL/key. Check Secrets tab in Replit.

### "Rate limited" errors

Check `api_rate_limits` table. Reset counters if needed.

### Circuit breaker won't close

Manually close via:
```sql
UPDATE circuit_breaker_state SET is_open = false WHERE breaker_name = 'budget_daily';
```

### Playwright browser hangs

The browser cleanup was fixed in `trademark-screener.ts`. Ensure you're using the latest code.

### Amazon KDP 2FA issues

The platform now supports TOTP. Configure your secret:
```sql
INSERT INTO totp_credentials (platform, email, secret_key)
VALUES ('amazon-kdp', 'your-email', 'YOUR_TOTP_SECRET');
```

### Webhook notifications not sending

Check the webhook queue:
```sql
SELECT * FROM webhook_queue WHERE status = 'failed' ORDER BY created_at DESC;
```

## Performance Tips

1. Use `useMemo` for expensive calculations
2. Enable React Query's background refetching
3. Use virtualization for long lists (100+ items)
4. Lazy load routes with `React.lazy()`
5. Keep bundle under 300KB (enforce in CI)

## Documentation

- **API Reference**: `docs/API.md`
- **Architecture Guide**: `docs/ARCHITECTURE.md`
- **Deployment Guide**: `docs/DEPLOYMENT.md`
- **Operations Runbook**: `docs/RUNBOOK.md`
- **Platform Guides**: `docs/platform-guides/`
- **AI Tools**: `docs/ai-tools/`

## Contact

For issues, see: https://github.com/Krosebrook/IncomeEngine/issues
