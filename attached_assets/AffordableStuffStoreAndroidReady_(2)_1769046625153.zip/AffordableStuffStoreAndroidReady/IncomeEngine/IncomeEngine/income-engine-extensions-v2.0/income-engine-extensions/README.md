# Income Engine Extensions v2.0

> **50+ Niches | 40+ Product Types | 8 Platforms**

Comprehensive extensions to the Income Engine passive income automation system.

---

## 📊 What's Included

### Niches (50+)

| Category | Count | Examples |
|----------|-------|----------|
| **Pets** | 10 | Dogs (30 breeds), Cats (15 breeds), Horses, Birds, Reptiles, Fish |
| **Occupations** | 15 | Teachers, Nurses, Doctors, Engineers, Lawyers, Chefs, Realtors |
| **Hobbies** | 15 | Gaming, Photography, Music, Art, Crafting, Gardening, Fishing |
| **Lifestyle** | 10 | Minimalist, Eco, LGBTQ+, Mental Health, Faith, Country |
| **Parenting** | 10 | Mom, Dad, Grandparents, Pregnancy, Baby, Teens, Adoption |
| **Seasonal** | 12 | Christmas, Halloween, Valentine's, Easter, Summer, Back-to-School |
| **Sports** | 12 | Fitness, Running, Soccer, Basketball, Baseball, Golf, Dance |
| **Food** | 8 | Baking, BBQ, Vegan, Beer, Whiskey, Tea, Hot Sauce |

### Sub-Niches (500+)

Each niche contains 8-30 sub-niches for targeted products:
- **Dog Breeds**: 30 breeds (golden retriever → chihuahua)
- **Teacher Types**: 17 specialties (elementary → STEM)
- **Gaming**: 14 sub-niches (8-bit → VR)

### Product Types (40+)

| Category | Products |
|----------|----------|
| **Apparel** | T-shirt, Hoodie, Tank, Sweatshirt, Polo, Leggings, Shorts |
| **Drinkware** | Mug, Tumbler, Wine Glass, Pint Glass, Rocks Glass, Water Bottle |
| **Home** | Blanket, Pillow, Poster, Canvas, Doormat, Towel, Ornament |
| **Accessories** | Tote, Backpack, Phone Case, Sticker, Badge Reel, Hat, Jewelry |
| **Kitchen** | Apron, Cutting Board, Oven Mitt, Coaster |
| **Kids** | Onesie, Kids T-shirt, Bib, Backpack, Lunchbox |
| **Digital** | Printable, Planner, Coloring Pages, Templates, SVG |
| **KDP Books** | Journal, Notebook, Planner, Coloring Book, Activity Book, Log Book |

### Platforms (8)

| Platform | Type | API | Automation Level |
|----------|------|-----|------------------|
| **Printify** | POD | ✅ Full | Fully automated |
| **Etsy** | Marketplace | ✅ OAuth | Fully automated |
| **Gumroad** | Digital | ✅ Full | Fully automated |
| **Amazon KDP** | Books | ❌ None | Semi-automated* |
| **Redbubble** | POD | ⚠️ Partner | Browser automation |
| **TeePublic** | POD | ⚠️ Limited | Browser automation |
| **Society6** | Art/Home | ⚠️ Partner | Browser automation |
| **Zazzle** | Custom | ⚠️ Partner | Browser automation |

*KDP: Cover + metadata generated automatically, manual upload to kdp.amazon.com

---

## 🚀 Quick Start

### 1. Install Extensions

```bash
# Copy to your income-engine directory
cp -r income-engine-extensions/* /path/to/income-engine/

# Install any new dependencies
npm install
```

### 2. Run Database Migration

```sql
-- In Supabase SQL Editor
-- Run AFTER base schema-extensions.sql
\i database/schema-extensions-v2.sql
```

### 3. Import New Workflows

Import these workflows into n8n:
- `workflows/09-redbubble-publisher.json`
- `workflows/10-kdp-book-generator.json`

### 4. Use Extended Niches

```typescript
import extensions from './income-engine-extensions';

// Get top 10 niches
const topNiches = extensions.helpers.getTopNiches(10);

// Get seasonal niches for this month
const seasonalNiches = extensions.helpers.getSeasonalNiches();

// Get low competition opportunities
const easyWins = extensions.helpers.getLowCompetitionNiches();

// Get products for a niche
const products = extensions.helpers.getBestProductsForNiche('dog-breed-specific');
```

---

## 📁 File Structure

```
income-engine-extensions/
├── index.ts                    # Main entry point
├── README.md                   # This file
│
├── niches/
│   ├── extended-niches-part1.ts  # Pets, Occupations, Hobbies, Lifestyle
│   └── extended-niches-part2.ts  # Parenting, Seasonal, Sports, Food
│
├── products/
│   └── extended-product-types.ts # 40+ product specifications
│
├── platforms/
│   ├── amazon-kdp.ts           # KDP book generation utilities
│   ├── redbubble.ts            # Redbubble connector
│   └── teepublic-society6.ts   # TeePublic + Society6 connectors
│
├── workflows/
│   ├── 09-redbubble-publisher.json
│   └── 10-kdp-book-generator.json
│
├── database/
│   └── schema-extensions-v2.sql  # New tables for platforms
│
└── templates/
    └── (product templates)
```

---

## 🎯 Niche Selection Strategy

### High-Opportunity Niches (Score 80+)

| Niche | Score | Competition | Best Products |
|-------|-------|-------------|---------------|
| christmas-holiday | 95 | High | Ornament, Sweater, Mug |
| dog-breed-specific | 92 | Medium | Mug, T-shirt, Blanket |
| halloween-spooky | 90 | High | T-shirt, Hoodie, Poster |
| mom-life-humor | 88 | Medium | Mug, T-shirt, Tumbler |
| gaming-retro | 88 | High | Poster, T-shirt, Mousepad |

### Low Competition Gems

| Niche | Score | Products | Why Low Competition |
|-------|-------|----------|---------------------|
| horse-equestrian | 75 | T-shirt, Hoodie, Blanket | Passionate niche, premium buyers |
| reptile-exotic | 62 | T-shirt, Poster, Sticker | Growing hobby, underserved |
| pharmacist-pharmacy | 62 | Mug, T-shirt, Badge Reel | Specific occupation, gift market |
| adoption-foster | 65 | T-shirt, Canvas, Mug | Emotional purchases, premium |
| whiskey-bourbon | 70 | Rocks Glass, T-shirt | Male demographic, premium |

### Seasonal Calendar

| Month | Peak Niches | Revenue Boost |
|-------|-------------|---------------|
| January | Fitness, Organization, Self-improvement | +30% |
| February | Valentine's, Couples, Galentines | +150% |
| March | St. Patrick's, Women's History | +150% |
| April | Easter, Earth Day, Spring | +100% |
| May | Mother's Day, Nurses Week, Teachers | +200% |
| June | Father's Day, Pride, Graduation | +200% |
| July | Independence Day, Summer | +100% |
| August | Back to School | +100% |
| September | Grandparents Day, Fall | +50% |
| October | Halloween | +150% |
| November | Veterans Day, Thanksgiving | +100% |
| December | Christmas, Hanukkah, Winter | +300% |

---

## 📦 Product Type Deep Dive

### Best Margins (POD)

| Product | Base Cost | Recommended Price | Margin |
|---------|-----------|-------------------|--------|
| Sticker | $1.50 | $4.99 | 70% |
| Poster | $4.00 | $19.99 | 80% |
| Canvas | $12.00 | $49.99 | 76% |
| Ornament | $6.00 | $19.99 | 70% |
| Digital Printable | $0.00 | $4.99 | 100% |

### Best Volume (POD)

| Product | Avg Sales/Month | Notes |
|---------|-----------------|-------|
| T-shirt | High | Universal appeal |
| Mug | High | Gift market staple |
| Sticker | Very High | Low price = impulse buys |
| Tote | Medium-High | Eco-conscious buyers |
| Tumbler | Medium-High | Everyday use item |

### KDP Book Economics

| Book Type | Pages | Print Cost | Min Price | Recommended | Royalty |
|-----------|-------|------------|-----------|-------------|---------|
| Journal (6x9) | 120 | $2.29 | $5.73 | $7.99 | $0.90 |
| Planner (8.5x11) | 120 | $2.89 | $7.23 | $12.99 | $2.31 |
| Coloring Book | 50 | $1.45 | $3.63 | $7.99 | $1.75 |
| Notebook | 120 | $2.29 | $5.73 | $6.99 | $0.51 |

---

## 🔧 Platform Integration Details

### Amazon KDP (Manual Upload)

The system generates:
1. ✅ SEO-optimized title, subtitle, description
2. ✅ 7 keywords (max allowed)
3. ✅ 2 BISAC categories
4. ✅ Cover image (correct dimensions)
5. ✅ Interior PDF template selection
6. ✅ Pricing recommendation

You manually:
1. Go to kdp.amazon.com
2. Create new Paperback
3. Upload generated cover + interior
4. Copy generated metadata
5. Publish

**Workflow**: `POST /webhook/generate-kdp-book`
```json
{
  "bookType": "journal",
  "niche": "dog-breed-specific",
  "subNiche": "golden-retriever",
  "trimSize": "6x9",
  "pageCount": 120
}
```

### Redbubble (Partner API / Browser)

Without partner API access, use browser automation:
1. Generate design + metadata
2. Use Puppeteer/Playwright to upload
3. Enable all product types
4. Set markup percentages

### TeePublic & Society6

Similar browser automation approach:
1. Generate design assets
2. Automate upload process
3. Tag and categorize
4. Set pricing/markup

---

## 💰 Revenue Projections (Extended)

### With 8 Platforms vs 3 Platforms

| Timeframe | 3 Platforms | 8 Platforms | Increase |
|-----------|-------------|-------------|----------|
| Month 1 | $50-150 | $100-300 | +100% |
| Month 3 | $300-700 | $600-1,400 | +100% |
| Month 6 | $800-1,500 | $1,500-3,000 | +100% |
| Month 12 | $1,500-3,000 | $3,000-6,000 | +100% |

### KDP Book Revenue

| Books Published | Monthly Sales | Royalty/Book | Monthly Revenue |
|-----------------|---------------|--------------|-----------------|
| 10 | 50 | $1.50 avg | $75 |
| 50 | 200 | $1.50 avg | $300 |
| 100 | 500 | $1.50 avg | $750 |
| 200 | 1,000 | $1.50 avg | $1,500 |

---

## ⚠️ Platform Compliance

### Trademark Safety

Each niche includes `avoidWords` - always check:
```typescript
const avoid = extensions.helpers.getAvoidWords('gaming-retro');
// ['violence', 'kill', 'death', 'murder']
```

### Platform-Specific Rules

| Platform | Key Restrictions |
|----------|-----------------|
| **Etsy** | Max 13 tags, no adult content in some categories |
| **Redbubble** | No fan art, no copyrighted characters |
| **TeePublic** | Content review before publish |
| **Amazon KDP** | No trademark terms, strict content guidelines |
| **Society6** | Artist agreement required |

---

## 🚧 Gaps & Limitations

| Gap | Impact | Workaround |
|-----|--------|------------|
| No Redbubble API | Medium | Browser automation or manual |
| KDP manual upload | Low | Batch upload tools available |
| Society6 Partner API | Medium | Browser automation |
| Zazzle complexity | Low | Template-based approach |
| Platform policy changes | Variable | Monitor announcements |

---

## 📈 Scaling Path

### Phase 1: Foundation (Month 1-2)
- 3 platforms (Printify → Etsy, Gumroad)
- 5 niches
- 100-200 products
- **Target: $300-500/month**

### Phase 2: Expansion (Month 3-4)
- Add Redbubble, TeePublic
- 10 niches
- 300-500 products
- Start KDP books (10-20)
- **Target: $800-1,200/month**

### Phase 3: Scale (Month 5-6)
- All 8 platforms
- 20+ niches
- 500-1,000 products
- 50+ KDP books
- **Target: $1,500-3,000/month**

### Phase 4: Optimization (Month 6+)
- Double down on winners
- Retire underperformers
- Seasonal campaigns
- Premium product focus
- **Target: $3,000-5,000/month**

---

## 📞 Support & Resources

- **Printify Docs**: https://developers.printify.com
- **Etsy API**: https://developer.etsy.com
- **KDP Help**: https://kdp.amazon.com/help
- **n8n Community**: https://community.n8n.io

---

*Income Engine Extensions v2.0 | 50+ Niches | 40+ Products | 8 Platforms*
