import React, { useState, Suspense, useEffect } from 'react';
import { AppMode } from './shared/types';
import { Spinner } from './shared/components/ui/Spinner';
import { Shell } from './shared/components/layout/Shell';
import { TutorialOverlay } from './shared/components/ui/TutorialOverlay';
import { useTutorial, TutorialStep } from './shared/hooks/useTutorial';
import { HelpCircle } from 'lucide-react';

// Lazy Load Features for Performance
const ImageEditor = React.lazy(() => import('./features/editor/components/ImageEditor').then(module => ({ default: module.ImageEditor })));
const MerchStudio = React.lazy(() => import('./features/merch/components/MerchStudio').then(module => ({ default: module.MerchStudio })));
const IntegrationCode = React.lazy(() => import('./features/integrations/components/IntegrationCode').then(module => ({ default: module.IntegrationCode })));

const LoadingScreen = () => (
  <div className="h-full w-full flex items-center justify-center min-h-[400px]">
    <Spinner className="w-12 h-12 text-blue-500" />
  </div>
);

const TUTORIAL_STEPS: TutorialStep[] = [
  {
    title: "Welcome to NanoGen",
    description: "Your AI-powered creative suite for rapid merchandise design and visual synthesis. Let's take a quick tour of the capabilities.",
    position: "center"
  },
  {
    targetId: "nav-creative",
    title: "Creative Editor",
    description: "Start here to edit images, remove backgrounds, or generate brand new assets using Gemini 3.",
    position: "bottom",
    requiredTab: "EDITOR"
  },
  {
    targetId: "editor-prompt-area",
    title: "Natural Language Control",
    description: "Just describe what you want. Drag and drop images here to have the AI analyze and describe them for you.",
    position: "right",
    requiredTab: "EDITOR"
  },
  {
    targetId: "nav-studio",
    title: "Merch Studio",
    description: "Once you have your assets, switch to the Merch Studio to visualize them on real-world products.",
    position: "bottom",
    requiredTab: "MERCH"
  },
  {
    targetId: "merch-sidebar",
    title: "Product Pipeline",
    description: "Upload logos, select products, and apply style presets. The AI handles lighting and perspective automatically.",
    position: "right",
    requiredTab: "MERCH"
  },
  {
    targetId: "merch-variations",
    title: "Variation Engine",
    description: "Generate multiple angles and lighting setups in parallel to find the perfect shot.",
    position: "top",
    requiredTab: "MERCH"
  },
  {
    targetId: "nav-api",
    title: "Developer API",
    description: "Ready to scale? Grab pre-configured code snippets to integrate this workflow into your own apps.",
    position: "bottom",
    requiredTab: "INTEGRATIONS"
  }
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppMode>('MERCH');
  const [lastPrompt, setLastPrompt] = useState<string>("");

  const { 
    isActive, 
    currentStep, 
    currentStepIndex, 
    nextStep, 
    prevStep, 
    skipTutorial, 
    restartTutorial,
    isFirstStep,
    isLastStep
  } = useTutorial(TUTORIAL_STEPS);

  // Auto-switch tabs based on tutorial requirement
  useEffect(() => {
    if (isActive && currentStep.requiredTab && currentStep.requiredTab !== activeTab) {
      setActiveTab(currentStep.requiredTab);
    }
  }, [isActive, currentStep, activeTab]);

  const handleImageGenerated = (url: string, prompt: string) => {
    setLastPrompt(prompt);
  };

  return (
    <>
      <Shell 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        headerAction={
          <button 
            onClick={restartTutorial}
            className="p-2 text-slate-500 hover:text-blue-400 hover:bg-blue-500/10 rounded-xl transition-colors"
            title="Restart Tutorial"
          >
            <HelpCircle className="w-5 h-5" />
          </button>
        }
      >
        <Suspense fallback={<LoadingScreen />}>
          {activeTab === 'EDITOR' && (
            <div className="h-full animate-fadeIn flex flex-col">
                <div className="mb-8 space-y-2">
                  <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">Creative Editor</h1>
                  <p className="text-slate-400 font-medium">Hyper-realistic image synthesis and contextual AI analysis.</p>
                </div>
                <div className="flex-1 min-h-0">
                  <ImageEditor onImageGenerated={handleImageGenerated} />
                </div>
            </div>
          )}

          {activeTab === 'MERCH' && (
            <div className="h-full animate-fadeIn flex flex-col">
                <div className="mb-8 space-y-2">
                  <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">Merch Studio</h1>
                  <p className="text-slate-400 font-medium">On-demand 3D product visualization and brand expansion.</p>
                </div>
                <div className="flex-1 min-h-0">
                  <MerchStudio onImageGenerated={handleImageGenerated} />
                </div>
            </div>
          )}

          {activeTab === 'INTEGRATIONS' && (
            <div className="h-full animate-fadeIn overflow-y-auto custom-scrollbar">
              <IntegrationCode lastPrompt={lastPrompt} />
            </div>
          )}
        </Suspense>
      </Shell>

      {isActive && (
        <TutorialOverlay 
          step={currentStep}
          currentStepIndex={currentStepIndex}
          totalSteps={TUTORIAL_STEPS.length}
          onNext={nextStep}
          onPrev={prevStep}
          onSkip={skipTutorial}
          isFirst={isFirstStep}
          isLast={isLastStep}
        />
      )}
    </>
  );
};

export default App;