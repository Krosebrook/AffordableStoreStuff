import React from 'react';
import { HelpCircle, Zap, ShieldCheck, Cpu, Code, Globe, Info } from 'lucide-react';
import { Card, Badge } from '@/shared/components/ui';

interface FAQItem {
  question: string;
  answer: string;
  icon: React.ReactNode;
  category: string;
}

const FAQ_DATA: FAQItem[] = [
  {
    category: "System Logic",
    icon: <Cpu className="w-4 h-4 text-blue-400" />,
    question: "How does the AI handle lighting and shadows?",
    answer: "NanoGen Studio utilizes Gemini 2.5 Flash's spatial understanding to perform 'environmental re-lighting'. It analyzes the light vectors in your background scene (ambient, directional, and specular) and mathematically maps those properties onto your logo texture for physical accuracy."
  },
  {
    category: "Strategic Usage",
    icon: <Zap className="w-4 h-4 text-amber-400" />,
    question: "When should I switch to the 'Pro' engine?",
    answer: "The Flash engine is optimized for speed and creative exploration. You should switch to 'Pro' (Gemini 3) when you require 4K resolution master files, precise text rendering within the image itself, or when your prompt requires 'Search Grounding' for real-world trending context."
  },
  {
    category: "Workflow",
    icon: <Code className="w-4 h-4 text-indigo-400" />,
    question: "How do I automate this for my own store?",
    answer: "Visit the 'Code Factory' tab. We provide production-ready snippets in Node.js, Python, and cURL. These snippets include logic for base64 normalization and Gemini API orchestration. Simply inject your API key and point it to your asset bucket."
  },
  {
    category: "Privacy",
    icon: <ShieldCheck className="w-4 h-4 text-emerald-400" />,
    question: "Are my store credentials and logos secure?",
    answer: "Absolutely. NanoGen Studio is a 'local-first' application. All platform keys (Shopify, Etsy, etc.) and design assets are stored exclusively in your browser's LocalStorage. No sensitive credentials ever touch our servers."
  },
  {
    category: "Capabilities",
    icon: <Globe className="w-4 h-4 text-purple-400" />,
    question: "Does it support complex material types like foil or embroidery?",
    answer: "Yes. By using the 'Visual Direction' field, you can specify material finishes. For example, typing 'Gold foil embossed' or 'Heavy thread embroidery' will trigger the AI to synthesize specific specular highlights and depth maps associated with those materials."
  },
  {
    category: "Integration",
    icon: <Info className="w-4 h-4 text-slate-400" />,
    question: "What is the 'Direct Publish' feature?",
    answer: "Direct Publish bypasses manual downloading. Once you've configured your platform keys, NanoGen connects to the respective merchant API to create a product draft, upload the high-res mockup, and populate SEO tags automatically."
  }
];

export const FAQ: React.FC = () => {
  return (
    <div className="space-y-10 py-12">
      <div className="flex flex-col md:flex-row items-end justify-between gap-4 px-4">
        <div className="space-y-2">
          <Badge variant="blue" icon={<HelpCircle className="w-3 h-3" />}>Technical FAQ</Badge>
          <h3 className="text-3xl font-black text-white uppercase tracking-tighter italic">Knowledge Base</h3>
          <p className="text-slate-500 text-sm font-medium">Deep dive into the architecture and best practices of NanoGen Studio.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-2">
        {FAQ_DATA.map((item, i) => (
          <Card 
            key={i} 
            className="group hover:border-blue-500/30 transition-all duration-500 bg-[#05070a]/50 backdrop-blur-sm border-slate-800/60"
            noPadding
          >
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 group-hover:bg-blue-600/10 group-hover:border-blue-500/20 transition-all">
                  {item.icon}
                </div>
                <span className="text-[9px] font-black text-slate-600 uppercase tracking-[0.2em] group-hover:text-blue-500 transition-colors">
                  {item.category}
                </span>
              </div>
              
              <div className="space-y-2">
                <h4 className="text-sm font-black text-slate-100 uppercase tracking-tight leading-tight group-hover:text-white">
                  {item.question}
                </h4>
                <p className="text-xs text-slate-500 font-medium leading-relaxed group-hover:text-slate-400 transition-colors">
                  {item.answer}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="mx-auto max-w-2xl text-center pt-8">
        <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-slate-800/30 border border-slate-700/50 backdrop-blur-sm">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Still have questions?</span>
          <a href="mailto:support@nanogen.studio" className="text-[10px] font-black text-blue-400 uppercase tracking-widest hover:text-blue-300 underline underline-offset-4">
            Contact Engineering
          </a>
        </div>
      </div>
    </div>
  );
};