import React, { useRef, useState, useEffect, useCallback } from 'react';
import { TextOverlayState } from '../hooks/useMerchState';

interface DraggableTextLayerProps {
  overlay: TextOverlayState;
  onChange: (overlay: TextOverlayState) => void;
  containerRef: React.RefObject<HTMLDivElement>;
}

export const DraggableTextLayer: React.FC<DraggableTextLayerProps> = ({ overlay, onChange, containerRef }) => {
  const elementRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const startPos = useRef({ x: 0, y: 0 });
  const rafRef = useRef<number | null>(null);

  // Helper to construct transforms
  const getTransform = useCallback((x: number, y: number, align: string, rotation: number, skew: number) => {
    let xOffset = '-50%';
    if (align === 'left') xOffset = '0%';
    if (align === 'right') xOffset = '-100%';
    
    // We use translate3d for GPU acceleration, but position is set via left/top
    // This transform handles the centering offset and rotation/skew
    return `translate3d(${xOffset}, -50%, 0) rotate(${rotation}deg) skewX(${skew}deg)`;
  }, []);

  // Sync React props to DOM when not dragging
  useEffect(() => {
    if (!isDragging && elementRef.current) {
      elementRef.current.style.left = `${overlay.x}%`;
      elementRef.current.style.top = `${overlay.y}%`;
    }
  }, [overlay.x, overlay.y, isDragging]);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0 || !elementRef.current || !containerRef.current) return;
    
    // Prevent default to stop text selection or native drag
    e.preventDefault();
    e.stopPropagation();

    // Capture the initial pointer position relative to viewport
    dragStart.current = { x: e.clientX, y: e.clientY };
    
    // Capture initial percentage position
    startPos.current = { x: overlay.x, y: overlay.y };
    
    setIsDragging(true);
    elementRef.current.setPointerCapture(e.pointerId);
    document.body.style.cursor = 'grabbing';
  };

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDragging || !containerRef.current || !elementRef.current) return;
    
    // Use requestAnimationFrame for smooth 60fps updates without React renders
    if (rafRef.current) return;

    rafRef.current = requestAnimationFrame(() => {
      if (!containerRef.current || !elementRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const dx = e.clientX - dragStart.current.x;
      const dy = e.clientY - dragStart.current.y;

      // Convert pixel delta to percentage delta
      const deltaXPercent = (dx / rect.width) * 100;
      const deltaYPercent = (dy / rect.height) * 100;

      let newX = startPos.current.x + deltaXPercent;
      let newY = startPos.current.y + deltaYPercent;

      // Clamp to canvas bounds
      newX = Math.max(0, Math.min(100, newX));
      newY = Math.max(0, Math.min(100, newY));

      // Direct DOM update
      elementRef.current.style.left = `${newX}%`;
      elementRef.current.style.top = `${newY}%`;

      rafRef.current = null;
    });
  }, [isDragging, containerRef]);

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    if (!isDragging || !containerRef.current || !elementRef.current) return;
    
    setIsDragging(false);
    document.body.style.cursor = '';
    elementRef.current.releasePointerCapture(e.pointerId);

    // Calculate final position to update parent state
    // We can read the style directly since we updated it in move
    const finalLeft = parseFloat(elementRef.current.style.left || '0');
    const finalTop = parseFloat(elementRef.current.style.top || '0');

    onChange({
      ...overlay,
      x: finalLeft,
      y: finalTop
    });
    
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
  }, [isDragging, containerRef, onChange, overlay]);

  const getRgbaColor = (hex: string, opacity: number) => {
    let r = 0, g = 0, b = 0;
    const h = hex.startsWith('#') ? hex.slice(1) : hex;
    if (h.length === 3) {
      r = parseInt(h[0] + h[0], 16);
      g = parseInt(h[1] + h[1], 16);
      b = parseInt(h[2] + h[2], 16);
    } else if (h.length === 6) {
      r = parseInt(h.substring(0, 2), 16);
      g = parseInt(h.substring(2, 4), 16);
      b = parseInt(h.substring(4, 6), 16);
    }
    return `rgba(${r}, ${g}, ${b}, ${opacity / 100})`;
  };

  const computedStyle: React.CSSProperties = {
    position: 'absolute',
    left: `${overlay.x}%`,
    top: `${overlay.y}%`,
    transform: getTransform(overlay.x, overlay.y, overlay.align, overlay.rotation, overlay.skewX),
    transformOrigin: 'center center',
    fontFamily: overlay.font,
    fontSize: `${overlay.size}px`,
    color: overlay.color,
    textAlign: overlay.align,
    opacity: (overlay.opacity ?? 100) / 100,
    backgroundColor: overlay.bgEnabled 
      ? getRgbaColor(overlay.bgColor, overlay.bgOpacity ?? 50) 
      : undefined,
    padding: overlay.bgEnabled ? `${overlay.bgPadding ?? 16}px` : undefined,
    borderRadius: overlay.bgEnabled ? `${overlay.bgRounding ?? 8}px` : undefined,
    mixBlendMode: overlay.blendMode as any,
    whiteSpace: 'pre-wrap',
    width: 'max-content',
    maxWidth: '100%',
    zIndex: 30,
    cursor: isDragging ? 'grabbing' : 'grab',
    userSelect: 'none',
    touchAction: 'none', // Crucial for Pointer Events
    // Visual improvement: add shadow if no background for better visibility against varying images
    textShadow: !overlay.bgEnabled ? '0px 2px 4px rgba(0,0,0,0.5)' : 'none'
  };

  // Inline decoration handling for better control (Canvas match)
  const textStyle: React.CSSProperties = {
    textDecoration: [
      overlay.underline ? 'underline' : '',
      overlay.strikethrough ? 'line-through' : ''
    ].filter(Boolean).join(' ') || 'none',
    textDecorationColor: overlay.color,
    textDecorationThickness: 'auto'
  };

  return (
    <div
      ref={elementRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      // Handle case where mouse leaves window/element during drag
      onPointerLeave={isDragging ? handlePointerUp : undefined} 
      style={computedStyle}
      className={`transition-shadow ${isDragging ? 'ring-2 ring-blue-500/50 rounded shadow-2xl' : 'hover:ring-1 hover:ring-blue-500/30'}`}
    >
      <span style={textStyle}>{overlay.text}</span>
    </div>
  );
};