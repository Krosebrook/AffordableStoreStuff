import React, { Suspense, useMemo, useRef } from 'react';
import { Canvas, useFrame, extend } from '@react-three/fiber';
import { 
  OrbitControls, 
  Stage, 
  Center, 
  useTexture, 
  PerspectiveCamera,
  Environment,
  ContactShadows,
  Float,
  PerformanceMonitor,
  shaderMaterial
} from '@react-three/drei';
import { 
  EffectComposer, 
  Bloom, 
  ChromaticAberration, 
  Noise, 
  Vignette 
} from '@react-three/postprocessing';
import * as THREE from 'three';
import { Spinner } from '@/shared/components/ui/Spinner';

// Custom Shader Material for "Holographic/Advanced" Product Look
const MerchShaderMaterial = shaderMaterial(
  {
    uTime: 0,
    uTexture: new THREE.Texture(),
    uFresnelColor: new THREE.Color('#3b82f6'),
    uOpacity: 1.0,
  },
  // Vertex Shader
  `
  varying vec2 vUv;
  varying vec3 vNormal;
  varying vec3 vViewPosition;
  
  void main() {
    vUv = uv;
    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
    vNormal = normalize(normalMatrix * normal);
    vViewPosition = -worldPosition.xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
  `,
  // Fragment Shader
  `
  uniform float uTime;
  uniform sampler2D uTexture;
  uniform vec3 uFresnelColor;
  uniform float uOpacity;
  
  varying vec2 vUv;
  varying vec3 vNormal;
  varying vec3 vViewPosition;

  void main() {
    vec4 texColor = texture2D(uTexture, vUv);
    
    // Fresnel Effect for holographic edges
    vec3 viewDir = normalize(vViewPosition);
    float fresnel = pow(1.0 - dot(vNormal, viewDir), 3.0);
    
    // Animated Scanlines
    float scanline = sin(vUv.y * 100.0 + uTime * 5.0) * 0.02;
    
    vec3 finalColor = mix(texColor.rgb, uFresnelColor, fresnel * 0.5);
    finalColor += scanline;
    
    gl_FragColor = vec4(finalColor, texColor.a * uOpacity);
  }
  `
);

extend({ MerchShaderMaterial });

interface Merch3DViewerProps {
  textureUrl: string;
  productId: string;
}

const ProductMesh: React.FC<{ textureUrl: string; productId: string }> = ({ textureUrl, productId }) => {
  const texture = useTexture(textureUrl);
  const materialRef = useRef<any>();

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uTime = state.clock.elapsedTime;
    }
  });
  
  const geometry = useMemo(() => {
    const id = productId.toLowerCase();
    if (id.includes('mug') || id.includes('bottle') || id.includes('tumbler')) {
      return <cylinderGeometry args={[1, 1, 2.5, 64]} />;
    } else if (id.includes('poster') || id.includes('canvas') || id.includes('print')) {
      return <boxGeometry args={[2, 3, 0.05]} />;
    } else if (id.includes('shirt') || id.includes('hoodie') || id.includes('beanie')) {
      return <boxGeometry args={[2.2, 2.5, 0.15]} />;
    } else if (id.includes('phone')) {
       return <boxGeometry args={[1, 2, 0.12]} />;
    }
    return <boxGeometry args={[2, 2, 0.1]} />;
  }, [productId]);

  return (
    <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.5}>
      <mesh castShadow receiveShadow>
        {geometry}
        {/* @ts-ignore */}
        <merchShaderMaterial 
          ref={materialRef} 
          uTexture={texture} 
          transparent 
          uOpacity={1}
        />
      </mesh>
    </Float>
  );
};

export const Merch3DViewer: React.FC<Merch3DViewerProps> = ({ textureUrl, productId }) => {
  const [dpr, setDpr] = React.useState(1.5);

  return (
    <div className="w-full h-full bg-[#020617] relative animate-fadeIn touch-none">
      <Suspense fallback={
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
          <Spinner className="w-10 h-10 text-blue-500" />
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Allocating GPU Buffers...</p>
        </div>
      }>
        <Canvas 
          shadows 
          dpr={dpr}
          gl={{ 
            antialias: true, 
            alpha: true,
            powerPreference: "high-performance",
            stencil: false,
            depth: true
          }}
          onCreated={({ gl }) => {
            gl.toneMapping = THREE.ACESFilmicToneMapping;
          }}
        >
          <PerformanceMonitor onDecline={() => setDpr(1)} onIncline={() => setDpr(2)} />
          
          <PerspectiveCamera makeDefault position={[0, 0, 8]} fov={35} />
          
          <Stage 
            intensity={0.4} 
            environment="city" 
            adjustCamera={false} 
            shadows={{ type: 'contact', opacity: 0.3, blur: 3 }}
          >
            <Center>
              <ProductMesh textureUrl={textureUrl} productId={productId} />
            </Center>
          </Stage>

          <EffectComposer disableNormalPass>
            <Bloom 
              luminanceThreshold={0.8} 
              mipmapBlur 
              intensity={0.5} 
              radius={0.4}
            />
            <ChromaticAberration 
              offset={new THREE.Vector2(0.001, 0.001)} 
            />
            <Noise opacity={0.02} />
            <Vignette eskil={false} offset={0.1} darkness={1.1} />
          </EffectComposer>

          <OrbitControls 
            enablePan={false}
            enableZoom={true}
            minPolarAngle={Math.PI / 4}
            maxPolarAngle={Math.PI / 1.5}
            makeDefault
            enableDamping={true}
            dampingFactor={0.08}
            rotateSpeed={0.7}
            zoomSpeed={1.0}
            domElement={document.body} 
          />
          
          <Environment preset="night" blur={0.8} />
          <ContactShadows position={[0, -2.8, 0]} opacity={0.5} scale={10} blur={2.5} far={4.5} />
        </Canvas>
      </Suspense>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-black/60 backdrop-blur-xl px-5 py-2.5 rounded-full border border-white/10 pointer-events-none shadow-2xl">
        <div className="relative">
          <div className="absolute inset-0 bg-blue-500/40 blur-md rounded-full animate-pulse" />
          <div className="w-2 h-2 rounded-full bg-blue-500 relative z-10" />
        </div>
        <div className="flex flex-col">
          <span className="text-[9px] font-black uppercase tracking-[0.2em] text-white">GPU Accelerated</span>
          <span className="text-[7px] font-bold uppercase tracking-widest text-slate-400">WebGL 2.0 • 60 FPS</span>
        </div>
      </div>
    </div>
  );
};
