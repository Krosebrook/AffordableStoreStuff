import { GoogleGenAI, GenerateContentResponse, Part } from "@google/genai";
import { AppError, ApiError, AuthenticationError, SafetyError, RateLimitError, ValidationError } from '../shared/utils/errors';
import { logger } from '../shared/utils/logger';

export interface GeminiRequest {
  model: string;
  prompt: string;
  parts?: Part[];
  config?: any;
}

export interface GeminiResult {
  text?: string;
  image?: string;
  groundingSources?: any[];
}

class GeminiService {
  private static instance: GeminiService;
  private readonly MAX_RETRIES = 3;

  private constructor() {}

  public static getInstance(): GeminiService {
    if (!GeminiService.instance) GeminiService.instance = new GeminiService();
    return GeminiService.instance;
  }

  /**
   * Primary method for model interaction with built-in resiliency.
   */
  public async execute(request: GeminiRequest): Promise<GeminiResult> {
    let lastError: any;

    for (let attempt = 0; attempt <= this.MAX_RETRIES; attempt++) {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: request.model,
          contents: { parts: request.parts || [{ text: request.prompt }] },
          config: request.config,
        });

        return this.parseResponse(response);
      } catch (error) {
        const normalized = this.mapError(error);
        lastError = normalized;

        // Immediately fail on non-transient errors
        if (!this.isTransient(normalized) || attempt === this.MAX_RETRIES) {
          throw normalized;
        }

        const delay = Math.pow(2, attempt) * 1000 + Math.random() * 500;
        logger.warn(`Gemini API Retry ${attempt + 1}/${this.MAX_RETRIES} after ${delay}ms: ${normalized.message}`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    throw lastError;
  }

  private isTransient(error: AppError): boolean {
    return (
      error instanceof RateLimitError ||
      (error instanceof ApiError && error.statusCode >= 500) ||
      error.message.includes('NETWORK_ERROR')
    );
  }

  private mapError(error: any): AppError {
    if (error instanceof AppError) return error;

    const rawMsg = error?.message || error?.toString() || "Unknown SDK error";
    const status = error?.status || error?.response?.status;
    const lowerMsg = rawMsg.toLowerCase();

    // 1. Quota & Rate Limits
    if (status === 429 || lowerMsg.includes("429") || lowerMsg.includes("quota")) {
      return new RateLimitError();
    }

    // 2. Authentication
    if (status === 401 || status === 403 || lowerMsg.includes("api key") || lowerMsg.includes("unauthenticated")) {
      return new AuthenticationError("ACCESS_DENIED: Your Gemini API key is invalid, expired, or unauthorized for this project.");
    }

    // 3. Safety & Content Policy
    if (lowerMsg.includes("safety") || lowerMsg.includes("blocked") || lowerMsg.includes("candidate")) {
      return new SafetyError("CONTENT_POLICY: The synthesis was interrupted by Gemini safety filters. Please refine your visual direction.");
    }

    // 4. Input Validation
    if (status === 400 || lowerMsg.includes("invalid argument")) {
      return new ValidationError("MALFORMED_REQUEST: The AI engine rejected the request parameters. Check asset resolution and prompt complexity.");
    }

    // 5. Server Capacity
    if ([500, 502, 503, 504].includes(status) || lowerMsg.includes("overloaded") || lowerMsg.includes("capacity")) {
      return new ApiError("ENGINE_OVERLOAD: Gemini servers are currently at peak capacity. Please retry in a few moments.", status || 503);
    }

    return new ApiError(`INTERNAL_GEMINI_ERROR: ${rawMsg}`, status || 500);
  }

  private parseResponse(response: GenerateContentResponse): GeminiResult {
    const candidate = response.candidates?.[0];

    if (response.promptFeedback?.blockReason) {
      throw new SafetyError(`PROMPT_FILTERED: Request blocked due to ${response.promptFeedback.blockReason}`);
    }

    if (!candidate) {
      throw new ApiError("ZERO_CANDIDATE_RESPONSE: The model failed to synthesize a valid candidate.", 500);
    }

    if (candidate.finishReason && candidate.finishReason !== "STOP" && candidate.finishReason !== "MAX_TOKENS") {
      if (candidate.finishReason === "SAFETY") throw new SafetyError("SAFETY_INTERRUPT: Generation blocked by regional safety standards.");
      if (candidate.finishReason === "RECITATION") throw new SafetyError("RECITATION_BLOCK: Content matched protected intellectual property.");
      throw new ApiError(`UNEXPECTED_FINISH_REASON: ${candidate.finishReason}`, 500);
    }

    const result: GeminiResult = {
      text: response.text,
      groundingSources: candidate.groundingMetadata?.groundingChunks
    };

    const imagePart = candidate.content?.parts.find(p => p.inlineData);
    if (imagePart?.inlineData?.data) {
      result.image = `data:image/png;base64,${imagePart.inlineData.data}`;
    }

    return result;
  }
}

export const geminiService = GeminiService.getInstance();
