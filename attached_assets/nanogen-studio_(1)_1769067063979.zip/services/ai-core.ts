
import { GoogleGenAI, Part } from "@google/genai";
import { geminiService } from "./gemini";
import { AppError, ApiError } from '../shared/utils/errors';
import { cleanBase64, getMimeType } from '../shared/utils/image';
import { SUPPORTED_MIME_TYPES } from '../shared/utils/file';
import { logger } from '../shared/utils/logger';

export type AIModel = 
  | 'gemini-3-flash-preview' 
  | 'gemini-3-pro-preview' 
  | 'gemini-2.5-flash-image' 
  | 'gemini-3-pro-image-preview'
  | 'gemini-2.5-flash-lite-latest'
  | 'veo-3.1-fast-generate-preview';

export type AspectRatio = "1:1" | "3:4" | "4:3" | "9:16" | "16:9" | "2:3" | "3:2" | "21:9";
export type ImageSize = "1K" | "2K" | "4K";

export interface AIRequestConfig {
  model: AIModel;
  aspectRatio?: AspectRatio;
  imageSize?: ImageSize;
  thinkingBudget?: number;
  maxOutputTokens?: number;
  useSearch?: boolean;
  systemInstruction?: string;
  responseMimeType?: string;
  maxRetries?: number;
  seed?: number;
  temperature?: number;
}

export interface AIResponse {
  text?: string;
  image?: string;
  groundingSources?: any[];
  finishReason?: string;
}

export interface MarketingCopyData {
  title: string;
  description: string;
  tags: string[];
}

class AICoreService {
  private static instance: AICoreService;

  private constructor() {}

  public static getInstance(): AICoreService {
    if (!AICoreService.instance) AICoreService.instance = new AICoreService();
    return AICoreService.instance;
  }

  public async generate(
    prompt: string,
    images: string[] = [],
    config: AIRequestConfig
  ): Promise<AIResponse> {
    const parts: Part[] = images.filter(Boolean).map(img => {
      const mimeType = getMimeType(img);
      if (!SUPPORTED_MIME_TYPES.includes(mimeType)) {
        throw new ApiError(`UNSUPPORTED_FORMAT: ${mimeType} is not a production-valid asset format.`, 400);
      }
      return { inlineData: { data: cleanBase64(img), mimeType } };
    });
    
    parts.push({ text: prompt || "Analyze assets and synthesize response." });

    const generationConfig: any = {
      systemInstruction: config.systemInstruction,
      responseMimeType: config.responseMimeType,
      temperature: config.temperature ?? 0.7,
      seed: config.seed,
    };

    if (config.thinkingBudget !== undefined) {
      generationConfig.thinkingConfig = { thinkingBudget: config.thinkingBudget };
      generationConfig.maxOutputTokens = (config.maxOutputTokens || config.thinkingBudget + 2048);
    } else if (config.maxOutputTokens) {
      generationConfig.maxOutputTokens = config.maxOutputTokens;
    }

    if (config.useSearch) generationConfig.tools = [{ googleSearch: {} }];

    if (config.model.includes('image')) {
      generationConfig.imageConfig = { 
        aspectRatio: config.aspectRatio || "1:1",
        ...(config.model === 'gemini-3-pro-image-preview' ? { imageSize: config.imageSize || "1K" } : {})
      };
    }

    const result = await geminiService.execute({
      model: config.model,
      prompt,
      parts,
      config: generationConfig
    });

    return result;
  }

  // Fix: Implement generateVideo to resolve the missing property error in useMerchState.ts
  /**
   * Generates a video using Veo models.
   * Handles long-running operations and polling until completion.
   */
  public async generateVideo(prompt: string, imageBase64?: string): Promise<string | null> {
    // A fresh GoogleGenAI instance is created right before the call to ensure the latest API key is used.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      logger.info("Initiating video generation operation...");
      
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        ...(imageBase64 ? {
          image: {
            imageBytes: cleanBase64(imageBase64),
            mimeType: getMimeType(imageBase64),
          }
        } : {}),
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      while (!operation.done) {
        // As per the SDK guidelines, we poll for the video operation completion every 10 seconds.
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (!downloadLink) {
        throw new ApiError("VIDEO_GENERATION_FAILED: No valid download link was returned from the video operation.", 500);
      }

      // Fetch the generated MP4 bytes. Note: The API key must be appended as a query parameter.
      const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
      if (!response.ok) {
        throw new ApiError(`VIDEO_FETCH_FAILED: Failed to download video content from ${downloadLink}. Status: ${response.status}`, response.status);
      }
      
      const blob = await response.blob();
      return URL.createObjectURL(blob);
    } catch (error) {
      logger.error("Video Generation Error:", error);
      // Specific error handling for API Key/Billing issues as requested in guidelines.
      if (error instanceof Error && error.message.includes("Requested entity was not found.")) {
        throw new ApiError("API_KEY_ERROR: Requested entity was not found. Your API key might be invalid, or the project does not have Veo enabled.", 403);
      }
      throw error;
    }
  }

  public async generateMarketingCopy(productName: string, image: string): Promise<MarketingCopyData> {
    const prompt = `Task: SEO Synthesis for ${productName}. 
    Analyze the visual aesthetic of the provided image and generate marketing copy.
    Output: JSON schema { "title": string, "description": string, "tags": string[] }`;

    const res = await this.generate(prompt, [image], {
      model: 'gemini-3-flash-preview',
      responseMimeType: "application/json",
      temperature: 0.8
    });

    try {
      return JSON.parse(res.text || "{}") as MarketingCopyData;
    } catch (e) {
      logger.error("JSON_PARSE_FAILURE in Marketing Engine:", res.text);
      throw new ApiError("DATA_DECODING_ERROR: Failed to parse generated marketing content.", 500);
    }
  }
}

export const aiCore = AICoreService.getInstance();
