import { useState, useEffect, useCallback } from 'react';
import { AppMode } from '@/shared/types';

export interface TutorialStep {
  targetId?: string; // ID of the DOM element to highlight. If undefined, shows a center modal.
  title: string;
  description: string;
  requiredTab?: AppMode; // Automatically switches tabs if defined
  position?: 'top' | 'bottom' | 'left' | 'right' | 'center';
}

const STORAGE_KEY = 'nanogen_tutorial_completed';

export const useTutorial = (steps: TutorialStep[]) => {
  const [isActive, setIsActive] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  // Check storage on mount
  useEffect(() => {
    const completed = localStorage.getItem(STORAGE_KEY);
    if (!completed) {
      // Slight delay to allow app to render before starting
      const t = setTimeout(() => setIsActive(true), 1000);
      return () => clearTimeout(t);
    }
  }, []);

  const nextStep = useCallback(() => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      completeTutorial();
    }
  }, [currentStepIndex, steps.length]);

  const prevStep = useCallback(() => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  }, [currentStepIndex]);

  const completeTutorial = useCallback(() => {
    setIsActive(false);
    localStorage.setItem(STORAGE_KEY, 'true');
    setCurrentStepIndex(0);
  }, []);

  const restartTutorial = useCallback(() => {
    setIsActive(true);
    setCurrentStepIndex(0);
  }, []);

  const skipTutorial = useCallback(() => {
    completeTutorial();
  }, [completeTutorial]);

  return {
    isActive,
    currentStepIndex,
    currentStep: steps[currentStepIndex],
    nextStep,
    prevStep,
    skipTutorial,
    restartTutorial,
    isFirstStep: currentStepIndex === 0,
    isLastStep: currentStepIndex === steps.length - 1
  };
};