import React, { useEffect, useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { TutorialStep } from '../../hooks/useTutorial';
import { Button } from './Button';
import { X, ChevronRight, ChevronLeft, Check } from 'lucide-react';

interface TutorialOverlayProps {
  step: TutorialStep;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
  isFirst: boolean;
  isLast: boolean;
  currentStepIndex: number;
  totalSteps: number;
}

export const TutorialOverlay: React.FC<TutorialOverlayProps> = ({
  step,
  onNext,
  onPrev,
  onSkip,
  isFirst,
  isLast,
  currentStepIndex,
  totalSteps
}) => {
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({ opacity: 0, visibility: 'hidden' });
  
  // Re-calculate target position on step change or window resize
  useEffect(() => {
    const update = () => {
      if (!step.targetId) {
        setTargetRect(null);
        return;
      }
      const el = document.getElementById(step.targetId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTargetRect(el.getBoundingClientRect());
      } else {
        // Retry once if element not found (e.g. during tab transition)
        setTimeout(() => {
          const retryEl = document.getElementById(step.targetId!);
          if (retryEl) setTargetRect(retryEl.getBoundingClientRect());
        }, 100);
      }
    };

    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('scroll', update);
    };
  }, [step.targetId, step.requiredTab]);

  // Positioning Engine
  useEffect(() => {
    const PADDING = 20;
    const GAP = 16;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    if (!targetRect) {
      setStyle({
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        opacity: 1,
        visibility: 'visible',
        position: 'fixed'
      });
      return;
    }

    // Estimate dimensions (Tooltip is roughly 360px wide)
    const cardWidth = Math.min(360, vw - (PADDING * 2));
    const cardHeight = 220; // Rough height including buttons

    let pos = step.position || 'bottom';
    const isMobile = vw < 640;
    
    // Force vertical layout on mobile to prevent side cut-offs
    if (isMobile && (pos === 'left' || pos === 'right')) {
      pos = 'bottom';
    }

    let top = 0;
    let left = 0;
    let transform = '';

    const calculate = (currentPos: string) => {
      switch (currentPos) {
        case 'top':
          top = targetRect.top - GAP - cardHeight;
          left = targetRect.left + targetRect.width / 2 - cardWidth / 2;
          break;
        case 'bottom':
          top = targetRect.bottom + GAP;
          left = targetRect.left + targetRect.width / 2 - cardWidth / 2;
          break;
        case 'left':
          top = targetRect.top + targetRect.height / 2 - cardHeight / 2;
          left = targetRect.left - GAP - cardWidth;
          break;
        case 'right':
          top = targetRect.top + targetRect.height / 2 - cardHeight / 2;
          left = targetRect.right + GAP;
          break;
        case 'center':
        default:
          top = vh / 2 - cardHeight / 2;
          left = vw / 2 - cardWidth / 2;
          break;
      }
    };

    calculate(pos);

    // Fallback logic: if out of bounds, try opposite
    if (top < PADDING || top + cardHeight > vh - PADDING || left < PADDING || left + cardWidth > vw - PADDING) {
      const opposites: Record<string, string> = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
      if (opposites[pos]) {
        calculate(opposites[pos]);
      }
    }

    // Strict clamping: ensure we stay in viewport no matter what
    left = Math.max(PADDING, Math.min(vw - cardWidth - PADDING, left));
    top = Math.max(PADDING, Math.min(vh - cardHeight - PADDING, top));

    setStyle({
      top: `${top}px`,
      left: `${left}px`,
      width: `${cardWidth}px`,
      opacity: 1,
      visibility: 'visible',
      position: 'fixed',
      transition: 'all 0.4s cubic-bezier(0.16, 1, 0.3, 1)'
    });
  }, [targetRect, step.position]);

  return createPortal(
    <div className="fixed inset-0 z-[9999] pointer-events-none overflow-hidden">
      {/* Dimmed Background & Spotlight */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] pointer-events-auto transition-opacity duration-500" />
      
      {targetRect && (
        <div 
          className="absolute transition-all duration-500 ease-in-out rounded-2xl pointer-events-none ring-[9999px] ring-black/60 border-2 border-blue-500/50 shadow-[0_0_30px_rgba(37,99,235,0.3)]"
          style={{
            top: targetRect.top - 8,
            left: targetRect.left - 8,
            width: targetRect.width + 16,
            height: targetRect.height + 16,
          }}
        />
      )}

      {/* Tooltip Container */}
      <div 
        ref={tooltipRef}
        className="pointer-events-auto flex flex-col"
        style={style}
      >
        <div className="bg-[#0f172a] border border-blue-500/30 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] p-6 sm:p-7 relative overflow-hidden group">
            {/* Subtle Gradient Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-transparent opacity-50" />
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                 <div className="px-3 py-1 bg-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest text-white shadow-lg border border-white/10">
                    Step {currentStepIndex + 1} of {totalSteps}
                 </div>
                 <button 
                    onClick={onSkip}
                    className="text-slate-500 hover:text-white transition-colors p-1"
                    aria-label="Close tutorial"
                 >
                    <X className="w-5 h-5" />
                 </button>
              </div>

              <h3 className="text-xl font-black text-white mb-3 leading-tight uppercase italic tracking-tight">
                {step.title}
              </h3>
              
              <p className="text-sm text-slate-400 leading-relaxed mb-8 font-medium">
                {step.description}
              </p>

              <div className="flex items-center justify-between gap-4">
                  <div className="flex gap-1.5">
                      {Array.from({ length: totalSteps }).map((_, i) => (
                          <div 
                              key={i}
                              className={`h-1 rounded-full transition-all duration-500 ${i === currentStepIndex ? 'w-6 bg-blue-500' : 'w-2 bg-slate-800'}`}
                          />
                      ))}
                  </div>
                  
                  <div className="flex gap-2">
                      {!isFirst && (
                          <button 
                              onClick={onPrev}
                              className="px-4 py-2 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors flex items-center gap-2"
                          >
                              <ChevronLeft className="w-3 h-3" /> Back
                          </button>
                      )}
                      <Button 
                          size="sm" 
                          onClick={onNext}
                          className="h-10 px-6 text-[10px] font-black uppercase tracking-widest"
                          icon={isLast ? <Check className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                      >
                          {isLast ? 'Finish' : 'Next'}
                      </Button>
                  </div>
              </div>
            </div>
        </div>
      </div>
    </div>,
    document.body
  );
};