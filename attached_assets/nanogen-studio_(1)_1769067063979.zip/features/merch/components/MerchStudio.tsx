import React from 'react';
import { useMerchController } from '../hooks/useMerchState';
import { MerchStudioSidebar } from './MerchStudioSidebar';
import { MerchStudioViewport } from './MerchStudioViewport';

interface MerchStudioProps {
  onImageGenerated: (url: string, prompt: string) => void;
}

export const MerchStudio: React.FC<MerchStudioProps> = ({ onImageGenerated }) => {
  const {
    logoImage, bgImage, selectedProduct, stylePreference,
    resultImage, loading, variations, isGeneratingVariations,
    activeError, errorSuggestion,
    isUploadingLogo, isUploadingBg,
    textOverlay,
    videoUrl, isVideoGenerating, marketingData, isMarketingGenerating, isPublishing, showPublishModal,
    setSelectedProduct, setStylePreference, setTextOverlay,
    handleLogoUpload, handleBgUpload, handleGenerate, handleGenerateVariations,
    handleGenerateVideo, handleGenerateMarketing, handlePublish, setShowPublishModal,
    clearLogo, clearBg, clearActiveError, raiseError, onReset
  } = useMerchController(onImageGenerated);

  return (
    <div 
      className="grid grid-cols-1 lg:grid-cols-[clamp(340px,30%,420px)_1fr] gap-8 xl:gap-12 h-full lg:h-[calc(100vh-180px)] min-h-0 w-full animate-fadeIn"
      aria-label="Merch Design Workspace"
    >
      {/* 
        Side Navigation & Controls
        - Mobile: Order 2 (Bottom) via order-last
        - Desktop: Order 1 (Left) via order-first
        - DOM Order: 1 (Maintains logical tab flow for screen readers)
      */}
      <aside 
        id="merch-sidebar"
        className="h-full min-h-0 overflow-hidden flex flex-col order-last lg:order-first"
        aria-label="Design Configuration"
      >
        <MerchStudioSidebar 
          logoImage={logoImage}
          bgImage={bgImage}
          selectedProduct={selectedProduct}
          stylePreference={stylePreference}
          textOverlay={textOverlay}
          loading={loading}
          resultImage={resultImage}
          isGeneratingVariations={isGeneratingVariations}
          isUploadingLogo={isUploadingLogo}
          isUploadingBg={isUploadingBg}
          activeError={activeError}
          errorSuggestion={errorSuggestion}
          marketingData={marketingData}
          isMarketingGenerating={isMarketingGenerating}
          onSelectProduct={setSelectedProduct}
          onStyleChange={setStylePreference}
          onTextOverlayChange={setTextOverlay}
          onLogoUpload={handleLogoUpload}
          onBgUpload={handleBgUpload}
          onGenerate={handleGenerate}
          onGenerateVariations={handleGenerateVariations}
          onGenerateMarketing={handleGenerateMarketing}
          onClearLogo={clearLogo}
          onClearBg={clearBg}
          onClearError={clearActiveError}
          onReset={onReset}
        />
      </aside>

      {/* 
        Main Preview Viewport
        - Mobile: Order 1 (Top)
        - Desktop: Order 2 (Right)
      */}
      <section 
        id="merch-viewport"
        className="h-full min-h-0 overflow-hidden flex flex-col"
        aria-label="Preview Canvas"
      >
        <MerchStudioViewport 
          logoImage={logoImage}
          loading={loading}
          resultImage={resultImage}
          variations={variations}
          isGeneratingVariations={isGeneratingVariations}
          activeError={activeError}
          errorSuggestion={errorSuggestion}
          selectedProduct={selectedProduct}
          stylePreference={stylePreference}
          textOverlay={textOverlay}
          videoUrl={videoUrl}
          isVideoGenerating={isVideoGenerating}
          isPublishing={isPublishing}
          showPublishModal={showPublishModal}
          onGenerateVariations={handleGenerateVariations}
          onTextOverlayChange={setTextOverlay}
          onGenerateVideo={handleGenerateVideo}
          onPublish={handlePublish}
          setShowPublishModal={setShowPublishModal}
          onError={raiseError}
          onClearError={clearActiveError}
        />
      </section>
    </div>
  );
};